// Databricks notebook source
val browserHostName = dbutils.notebook.getContext.tags.getOrElse("browserHostName","none")
var environment =""

if(browserHostName.contains("-dev-"))
{
  environment="dev"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-test-"))
{
  environment="test"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-prod-"))
{
  environment="prod"
  println("environment is set to : " + environment)
}

val curated_table = s"dhf_iot_curated_${environment}.device_status"


spark.sql(s"""
  merge into ${curated_table}
  using (
      select DEVC_KEY, PRGRM_INSTC_ID, DATA_CLCTN_ID, SRC_SYS_CD, MD5_HASH
      from ${curated_table}
      where STTS_EXPRTN_TS == '9999-1-1' and DEVC_UNAVLBL_FLAG == '0' and datediff(current_timestamp(),LAST_DEVC_ACTVTY_TS) > 8
  ) as lost_devices
  on ${curated_table}.DEVC_KEY = lost_devices.DEVC_KEY and ${curated_table}.PRGRM_INSTC_ID = lost_devices.PRGRM_INSTC_ID and ${curated_table}.DATA_CLCTN_ID = lost_devices.DATA_CLCTN_ID and ${curated_table}.SRC_SYS_CD = lost_devices.SRC_SYS_CD and ${curated_table}.MD5_HASH = lost_devices.MD5_HASH and ${curated_table}.STTS_EXPRTN_TS = '9999-1-1'
  when matched then update set
  ${curated_table}.DEVC_UNAVLBL_FLAG = '1',
  ${curated_table}.ETL_LAST_UPDT_DTS = current_timestamp()""")

// COMMAND ----------


