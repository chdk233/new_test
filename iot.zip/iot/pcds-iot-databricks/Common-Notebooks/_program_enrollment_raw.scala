// Databricks notebook source
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types._
import java.time.LocalDateTime
import scala.util.parsing.json._
import java.time
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import org.apache.commons.io.IOUtils
import java.time.{ZonedDateTime, ZoneId}

//added for email alerts
import javax.mail.Session
import javax.mail.Message
import javax.mail.MessagingException
import javax.mail.internet.AddressException
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.mail.internet.MimeUtility
import java.util.Properties

spark.conf.set("spark.sql.files.ignoreCorruptFiles", "true")   
spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")


val deltadatabase = dbutils.widgets.get("deltadatabase").toString
val deltadatabase_path = dbutils.widgets.get("deltadatabase_path").toString
val job_run_log = dbutils.widgets.get("job_run_log").toString
val job_run_log_path = dbutils.widgets.get("job_run_log_path").toString
val part_json_s3_file_loc = dbutils.widgets.get("part_json_s3_file_loc").toString
val enrl_file_path = dbutils.widgets.get("enrl_file_path").toString
val enrl_table = dbutils.widgets.get("enrl_table").toString
val athena_output_loc = dbutils.widgets.get("athena_output_loc").toString
val checkpointLocation = dbutils.widgets.get("checkpointLocation").toString
val kafkaBootStrapServers = dbutils.widgets.get("kafkaBootStrapServers").toString
val truststoreLocation = dbutils.widgets.get("truststoreLocation").toString
val keystoreLocation = dbutils.widgets.get("keystoreLocation").toString
val topic = dbutils.widgets.get("topic").toString
val secret_scope = dbutils.widgets.get("secret_scope").toString
val secret_truststorePassword = dbutils.widgets.get("secret_truststorePassword").toString
val secret_keystorePassword = dbutils.widgets.get("secret_keystorePassword").toString
val secret_keyPassword = dbutils.widgets.get("secret_keyPassword").toString
val starting_Offsets = dbutils.widgets.get("starting_Offsets").toString
val maxFilesPerTrigger = dbutils.widgets.get("maxFilesPerTrigger").toString
val includeExistingFiles = dbutils.widgets.get("includeExistingFiles").toString
val aws_accountid=dbutils.widgets.get("account_id").toString
val sns_arn=dbutils.widgets.get("sns_arn").toString

val date_today = ZonedDateTime.now(ZoneId.of("UTC"))
val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
val date_today_formatted = formatter format date_today
val environment = dbutils.widgets.get("environment").toString

spark.sql(s"set environment = '${environment}'")
spark.sql(s"set sns_arn = '${sns_arn}'")
spark.sql(s"set aws_accountid = '${aws_accountid}'")

// COMMAND ----------

val jobId=dbutils.notebook.getContext.tags.getOrElse("jobId","")
val runId=dbutils.notebook.getContext.tags.getOrElse("runId","")
val clusterId=dbutils.notebook.getContext.tags.getOrElse("clusterId","")

val truststorePassword     = dbutils.secrets.get(scope = secret_scope, key = secret_truststorePassword)
val keystorePassword       = dbutils.secrets.get(scope = secret_scope, key = secret_keystorePassword)
val keyPassword            = dbutils.secrets.get(scope = secret_scope, key = secret_keyPassword)

// COMMAND ----------

val streamingInputDF = spark.readStream
.format("kafka")
.option("kafka.bootstrap.servers", kafkaBootStrapServers)
.option("kafka.security.protocol","SSL")
.option("kafka.ssl.truststore.location",truststoreLocation)
.option("kafka.ssl.truststore.password", truststorePassword)
.option("kafka.ssl.keystore.location", keystoreLocation)
.option("kafka.ssl.keystore.password", keystorePassword)
.option("kafka.ssl.key.password", keyPassword)
.option("subscribe", topic)
.option("startingOffsets", starting_Offsets)
.option("maxOffsetsPerTrigger", maxFilesPerTrigger)
.option("failOnDataLoss","false")
.load()


// COMMAND ----------


def sendEmail(toEmails: String , fromEmail: String, subject: String, body: String): Unit = {
    
    val props = new Properties
    props.setProperty("mail.transport.protocol", "smtp");
    props.setProperty("mail.smtp.host", "mail-gw.ent.nwie.net");
    // props.put("mail.smtp.port", s"$mail_smtp_port");
    props.setProperty("mail.smtp.auth", "false");
    println("email--" +toEmails)
    val session = Session.getInstance(props)
    //var tolist= toEmails
    try {
      if(toEmails !=null){
      val messageBody = body
      val message = new MimeMessage(session)
      
        var toEmailList= toEmails.split(",").toList
      message.setFrom(new InternetAddress(fromEmail))
      for (toEmail <- toEmailList) {
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail))
      }
      message.setSubject(subject)
      // message.setHeader("Content-Type", "text/plain;")
      message.setText(messageBody)
      val transport = session.getTransport("smtp")
      
      transport.connect()
      transport.sendMessage(message, message.getAllRecipients)
      }else{
        println("Email list is empty.No email will be sent.")
      }
    } catch {
      case exception: Exception =>
        println("Mail delivery failed. " + exception)
    }
}

// COMMAND ----------

def parseJSONFile(raw_df: org.apache.spark.sql.Dataset[Row], batchId: Long) = {
  
  //Storing the input file in the S3 bucket for future reference.
  var jsonDF = raw_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)","CAST(topic AS STRING)","CAST(partition AS INT)","CAST(offset AS LONG)","CAST(timestamp AS timestamp)","CAST(timestampType AS INT)")
  
  
  jsonDF = jsonDF.withColumn("timestamp",(col("timestamp").cast("double")*1000).cast("long"))

  
  jsonDF.withColumn("db_load_date",current_date()).write.format("json").mode("append").partitionBy("db_load_date").save(part_json_s3_file_loc)
  
  
 val schema_data1 = """{"context":{"id":"a5f316b1-1c6c-40fb-85d5-4947070c167d","source":"SmartRideProcessing","time":1652118351898,"type":"com.nationwide.pls.telematics.auto.programs.v3.enrollment.vendor-enrolled"},"smartRideEnrollment":{"transactionType":"PolicyEnrollment","policy":{"policyNumber":"9112J 803348","policyState":"OH","drivers":[{"subjectId":1.0,"firstName":"Mobbile","lastName":"kafka","middleName":"","suffix":"","ecn":""}],"vehicles":[{"subjectId":1.0,"vin":"5TKZK92t888105399","year":"2021","make":"DODG","model":"CHARGER SX"}],"telematics":{"programs":[{"subjectId":1.0,"subjectType":"VEHICLE","enrollmentId":"282008","programType":"SmartMilesDevice","programStatus":"Active","enrollmentEffectiveDate":"2021-10-05","enrollmentProcessDate":"2022-05-09","programTermBeginDate":"2022-05-09","programTermEndDate":"2019-11-11","programEndDate":"2019-11-11","dataCollection":{"dataCollectionId":"b0ba6915-3b19-4647-a44f-4fa02ea93c08","vendorAccountId":"34","vendorAccountBeginDate":"2022-05-09","vendorAccountEndDate":"2019-11-11","vendor":"IMS","dataCollectionStatus":"Active","device":{"deviceId":"","deviceStatus":"NotShipped","deviceStatusDate":"2022-05-09","installGraceEndDate":"2022-05-09","lastRequestDate":"2022-05-09"}},"scoreAndDiscount":{"score":"997","scoreType":"DriverFinal","scoreModel":"NM1","scoreDate":"2021-05-06","discountPercent":"5"}}],"scoreAndDiscount":{"score":"997","scoreType":"DriverFinal","scoreModel":"SM1","scoreDate":"2021-05-06","discountPercent":"5"}}}}}"""
  

  
  val schemadf = spark.read.option("multiline",true).json(Seq(schema_data1).toDS)

   val convertedudf = udf((unicodestring: String) => unicodestring.replace("\u0000\u0000\u0000\u0001\uFFFD","").replace("\u0000\u0000\u0000\u0001]","").replace("\u0000\u0000\u0000\u0000\ufffd","").replace("\u0000\u0000\u0000\u0000[","").replace("\u0000\u0000\u0000\u0000\uFFFD","")) // business.policy-management.smartride.enrollments.v3.st
  
   //val convertedudf = udf((unicodestring: String) => unicodestring.replace("\u0000\u0000\u0000\u0000\ufffd","")) // business.policy-management.smartride.enrollments.v3

  //  val convertedudf = udf((unicodestring: String) => unicodestring.replace("\u0000\u0000\u0000\u0000[","").replace("\u0000\u0000\u0000\u0000\uFFFD","")) //for prod
   
  val cleansedDF = jsonDF.withColumn("cleansed_value",convertedudf(jsonDF("value"))).drop("value")
  
  val parsedDF1 = cleansedDF.withColumn("parsed_column",from_json(col("cleansed_value"),schema=schemadf.schema))
  
   val mainDF = parsedDF1.select($"topic",
                              $"partition",
                              $"offset",
                              $"key",
                              $"timestamp",
                              col("timestampType").alias("timestamp_type"),
                              col("parsed_column.context.id").alias("eventId"),
                              col("parsed_column.context.source").alias("eventsource"),
                              col("parsed_column.context.time").alias("eventtime"),
                              col("parsed_column.context.type").alias("eventtype"),
                              col("parsed_column.smartRideEnrollment.policy.policyNumber"),
                              col("parsed_column.smartRideEnrollment.policy.policyState"),
                              col("parsed_column.smartRideEnrollment.transactionType"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.score").alias("policy_score"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.scoreType").alias("policy_scoreType"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.scoreModel").alias("policy_scoreModel"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.ScoreDate").alias("policy_scoreDate"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.discountPercent").cast(DoubleType).alias("policy_discountPercent"))
  
val programsDataExplodedDF = parsedDF1.select(col("offset").alias("programOffset"),
                                         col("parsed_column.smartRideEnrollment.policy.policyNumber").alias("programPolicyNumber"),
                                         explode(col("parsed_column.smartRideEnrollment.policy.telematics.programs")))
  
val vehiclesExplodedDF = parsedDF1.select(col("offset").alias("vehicleOffset"),
                                         col("parsed_column.smartRideEnrollment.policy.policyNumber").alias("vehiclePolicyNumber"),
                                         explode(col("parsed_column.smartRideEnrollment.policy.vehicles")))
  
val driversExplodedDF = parsedDF1.select(col("offset").alias("driversOffset"),
                                 col("parsed_column.smartRideEnrollment.policy.policyNumber").alias("driversPolicyNumber"),
                                 explode(col("parsed_column.smartRideEnrollment.policy.drivers")))


  
val driversDF = driversExplodedDF.select("driversOffset",
                                        "driversPolicyNumber",
                                         "col.firstName",
                                         "col.middleName",
                                         "col.lastName",
                                         "col.suffix",
                                         "col.subjectId",
                                         "col.ecn"
                                        )
  
val vehicleDF = vehiclesExplodedDF.select("vehicleOffset",
                                         "vehiclePolicyNumber",
                                         "col.subjectId",
                                         "col.vin",
                                         "col.make",
                                         "col.model",
                                         "col.year")
  
var programDF1 = programsDataExplodedDF.select("programOffset",
                                              "programPolicyNumber",
                                              "col.enrollmentId",
                                              "col.programType",
                                              "col.programStatus",
                                              "col.programEndDate",
                                              "col.enrollmentEffectiveDate",
                                              "col.enrollmentProcessDate",
                                              "col.programTermBeginDate",
                                              "col.programTermEndDate",
                                              "col.subjectType",
                                              "col.subjectId",
                                              "col.dataCollection.dataCollectionId",
                                              "col.dataCollection.dataCollectionStatus",
                                              "col.dataCollection.vendor",
                                              "col.dataCollection.device.deviceId",
                                              "col.dataCollection.device.deviceStatus",
                                              "col.dataCollection.device.deviceStatusDate",
                                              "col.dataCollection.device.installGraceEndDate",
                                              "col.dataCollection.device.lastRequestDate",
                                              "col.dataCollection.vendorAccountId",
                                              "col.dataCollection.vendorAccountBeginDate",
                                              "col.dataCollection.vendorAccountEndDate",
                                              "col.scoreAndDiscount.score",
                                              "col.scoreAndDiscount.scoreType",
                                              "col.scoreAndDiscount.scoreModel",
                                              "col.scoreAndDiscount.ScoreDate",
                                              "col.scoreAndDiscount.discountpercent")
  
var programDF = programDF1.select(col("programOffset"),
                                  col("programPolicyNumber"),
                                  col("enrollmentId"),
                                  col("programType"),
                                  col("programStatus")
                                  ,col("programEndDate")
                                  ,col("enrollmentEffectiveDate")
                                  ,col("enrollmentProcessDate")
                                  ,col("programTermBeginDate")
                                  ,col("programTermEndDate")
                                  ,col("subjectId").alias("program_subject_id")
                                  ,col("subjectType")
                                  ,col("dataCollectionId")
                                  ,col("dataCollectionStatus")
                                  ,col("vendor")
                                  ,col("deviceId")
                                  ,col("deviceStatus")
                                  ,col("deviceStatusDate")
                                  ,col("installGraceEndDate")
                                  ,col("lastRequestDate").alias("lastRequestDate")
                                  ,col("vendorAccountId")
                                  ,col("vendorAccountBeginDate")
                                  ,col("vendorAccountEndDate")
                                  ,col("score").alias("program_score")
                                  ,col("scoreType").alias("program_scoreType")
                                  ,col("scoreModel").alias("program_scoreModel")
                                  ,col("ScoreDate").alias("program_scoreDate")
                                  ,col("discountpercent").alias("program_discountPercent")
                                  
                                 )
  
  programDF = programDF.withColumn("program_discountPercent",col("program_discountPercent").cast(DoubleType))
  
  var finalDF = mainDF.join(programDF,(mainDF("offset") === programDF("programOffset")) && (mainDF("policyNumber") === programDF("programPolicyNumber")) ).drop("programOffset","programPolicyNumber")
  
if(vehicleDF.count() > 0)  {
  
  val vehiclefinalDF =  finalDF.join(vehicleDF,(finalDF("offset") === vehicleDF("vehicleOffset")) && (finalDF("policyNumber") === vehicleDF("vehiclePolicyNumber"))  && (finalDF("program_subject_id") === vehicleDF("subjectId"))).drop("vehicleOffset","vehiclePolicyNumber","program_subject_id")
  
  val deltaDF = vehiclefinalDF.withColumn("db_load_time",current_timestamp()).withColumn("db_load_date",current_date())
  
  val valid_res_df = deltaDF.filter("(eventtype='com.nationwide.pls.telematics.auto.programs.v3.enrollment.scored' and program_scoreType='Estimated' and program_score is not null and program_score   between 0 and 999) or (eventtype!='com.nationwide.pls.telematics.auto.programs.v3.enrollment.scored' or program_scoreType!='Estimated')")

  val invalidDF=deltaDF.filter("eventtype='com.nationwide.pls.telematics.auto.programs.v3.enrollment.scored' and program_scoreType='Estimated' and (program_score is  null or program_score not between 0 and 999)")

  if (invalidDF.count()>0){

    val load_dt=invalidDF.selectExpr("db_load_date").distinct().collect().mkString("")
    val invalid_list="[program_score]"
    val sub=f"${environment}-Program enrollment Raw DQI check failure: : ${load_dt}"
    val msg=f"Invalid records found in Program enrollment Raw load for \nload_dt: ${load_dt} \nColumns: ${invalid_list}\n\n@run team ,Please raise a ticket with SRP team to get valid records \n\nThanks,\nIOT Team"

    sendEmail("NWLine-IoTA@nationwide.com,NWLine-Smart.Squad@nationwide.com","iot@nationwide.com", sub,msg)

    invalidDF.coalesce(1).write
    .format("delta")
    .mode("append")
    .partitionBy("db_load_date").saveAsTable(f"${deltadatabase}.program_enrollment_invalid") 
  }
  
  valid_res_df.coalesce(1).write
  .format("delta")
  .mode("append")
  .option("path",enrl_file_path)
  .partitionBy("db_load_date").saveAsTable(enrl_table)
    
}
  
if(driversDF.count() > 0){
  
  val  driversfinalDF = finalDF.join(driversDF,(finalDF("offset") === driversDF("driversOffset")) && (finalDF("policyNumber") === driversDF("driversPolicyNumber")) && (finalDF("program_subject_id") === driversDF("subjectId"))).drop("driversOffset","driversPolicyNumber","program_subject_id")
  
  val deltaDF = driversfinalDF.withColumn("db_load_time",current_timestamp()).withColumn("db_load_date",current_date())
  
  val valid_res_df = deltaDF.filter("(eventtype='com.nationwide.pls.telematics.auto.programs.v3.enrollment.scored' and program_scoreType='Estimated' and program_score is not null and program_score   between 0 and 999) or (eventtype!='com.nationwide.pls.telematics.auto.programs.v3.enrollment.scored' or program_scoreType!='Estimated')")

  val invalidDF=deltaDF.filter("eventtype='com.nationwide.pls.telematics.auto.programs.v3.enrollment.scored' and program_scoreType='Estimated' and (program_score is  null or program_score not between 0 and 999)")

  if (invalidDF.count()>0){
   
    val load_dt=invalidDF.selectExpr("db_load_date").distinct().collect().mkString("")
    val invalid_list="[program_score]"
    val sub=f"${environment}-Program enrollment Raw DQI check failure: : ${load_dt}"
    val msg=f"Invalid records found in Program enrollment Raw load for \nload_dt: ${load_dt} \nColumns: ${invalid_list}\n\n@run team ,Please raise a ticket with SRP team to get valid records \n\nThanks,\nIOT Team"

    sendEmail("NWLine-IoTA@nationwide.com,NWLine-Smart.Squad@nationwide.com","iot@nationwide.com" , sub,msg)

    invalidDF.coalesce(1).write
    .format("delta")
    .mode("append")
    .partitionBy("db_load_date").saveAsTable(f"${deltadatabase}.program_enrollment_invalid") 
  }
  
  valid_res_df.coalesce(1).write
  .format("delta")
  .mode("append")
  .option("path",enrl_file_path)
  .partitionBy("db_load_date").saveAsTable(enrl_table)
  
 }  
}


// COMMAND ----------

val streamingOutputDF = streamingInputDF.writeStream
  .trigger(Trigger.Once)
  .queryName("Enrollment_v3_FileStream")
  .format("delta")
  .outputMode( "append")
  .option("checkpointLocation", checkpointLocation)
  .foreachBatch(parseJSONFile _).start()

val dbLoadTime = time.LocalDateTime.now()
val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd%");
val formatDateTime = dbLoadTime.format(formatter);
Thread.sleep(120000)

val auditDF = spark.sql(s"select distinct offset from $enrl_table where db_load_time LIKE '$formatDateTime'")

if (auditDF.rdd.isEmpty){
  print("no data was loaded")
  spark.sql(s"set v3_Raw_AuditValue = 0")
}else {
  print("data loaded successfully")
  spark.sql(s"set v3_Raw_AuditValue = 1")
}

// COMMAND ----------

// MAGIC %py
// MAGIC import boto3
// MAGIC import time
// MAGIC
// MAGIC from datetime import datetime
// MAGIC now = datetime.now()
// MAGIC aws_accountid=spark.sql("select ${aws_accountid}").head()[0]
// MAGIC
// MAGIC def send_mail(topic_arn,subject,message):
// MAGIC   sts_client = boto3.client("sts",region_name='us-east-1',endpoint_url ='https://sts.us-east-1.amazonaws.com')
// MAGIC   # response2 = sts_client.assume_role(RoleArn=f'arn:aws:iam::{aws_accountid}:role/pcds-databricks-common-access',RoleSessionName='myDhfsession_pe')
// MAGIC   account_number = sts_client.get_caller_identity()["Account"]
// MAGIC   print(account_number)
// MAGIC   # sns_client = boto3.Session(region_name='us-east-1').client("sns",
// MAGIC                           # aws_access_key_id=response2.get('Credentials').get('AccessKeyId'),
// MAGIC                           # aws_secret_access_key=response2.get('Credentials').get('SecretAccessKey'),
// MAGIC                           # aws_session_token=response2.get('Credentials').get('SessionToken'))
// MAGIC   sns_client = boto3.Session(region_name='us-east-1').client("sns")
// MAGIC   topic_arn=topic_arn
// MAGIC   sns_client.publish(TopicArn = topic_arn, Message = message, Subject = subject)
// MAGIC
// MAGIC time.sleep(100)
// MAGIC v3_Raw_AuditValue = spark.sql("select ${v3_Raw_AuditValue}").head()[0]
// MAGIC sns_arn=spark.sql("select ${sns_arn}").head()[0]
// MAGIC environment = spark.sql("select ${environment}").head()[0]
// MAGIC environment = environment.upper()
// MAGIC
// MAGIC if v3_Raw_AuditValue == 0:
// MAGIC   print("The data is not loaded")
// MAGIC   send_mail(sns_arn,f"{environment} - Program Enrollment V3 Audit failure: Data not loaded for Program Enrollment Raw V3 ",f"Hi Team,\n\n No Data is loaded in the current run of Program Enrollment Raw V3 ,please check. \n \n Regards,\nSupport Team")
// MAGIC  
