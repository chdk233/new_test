// Databricks notebook source
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types._
import java.time.LocalDateTime
import scala.collection.mutable.ListBuffer
import scala.util.{Try, Success, Failure} 
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.streaming.StreamingQueryListener._
import scala.util.parsing.json._
import java.time
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit;
import java.io.{
  InputStream,
  ByteArrayInputStream,
  BufferedInputStream
}
import java.sql.Timestamp
import org.apache.commons.compress.compressors.{
  CompressorInputStream,
  CompressorStreamFactory
}
import org.apache.commons.compress.archivers.{
  ArchiveInputStream,
  ArchiveStreamFactory,
  ArchiveEntry
}
import org.apache.commons.io.input.CloseShieldInputStream
import org.apache.commons.io.IOUtils
import org.apache.spark.sql.expressions.Window
import java.time.{ZonedDateTime, ZoneId}
import java.time.format.DateTimeFormatter

spark.conf.set("spark.sql.files.ignoreCorruptFiles", "true")   
spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")

val deltadatabase = dbutils.widgets.get("deltadatabase").toString
val deltadatabase_path = dbutils.widgets.get("deltadatabase_path").toString
val job_run_log = dbutils.widgets.get("job_run_log").toString
val job_run_log_path = dbutils.widgets.get("job_run_log_path").toString
val part_json_s3_file_loc = dbutils.widgets.get("part_json_s3_file_loc").toString
val parq_s3_mnt_loc = dbutils.widgets.get("parq_s3_mnt_loc").toString
val enrl_file_path = dbutils.widgets.get("enrl_file_path").toString
val enrl_table = dbutils.widgets.get("enrl_table").toString
val athena_output_loc = dbutils.widgets.get("athena_output_loc").toString
val checkpointLocation = dbutils.widgets.get("checkpointLocation").toString
val kafkaBootStrapServers = dbutils.widgets.get("kafkaBootStrapServers").toString
val truststoreLocation = dbutils.widgets.get("truststoreLocation").toString
val keystoreLocation = dbutils.widgets.get("keystoreLocation").toString
val topic = dbutils.widgets.get("topic").toString
val secret_scope = dbutils.widgets.get("secret_scope").toString
val secret_truststorePassword = dbutils.widgets.get("secret_truststorePassword").toString
val secret_keystorePassword = dbutils.widgets.get("secret_keystorePassword").toString
val secret_keyPassword = dbutils.widgets.get("secret_keyPassword").toString
val starting_Offsets = dbutils.widgets.get("starting_Offsets").toString
val maxFilesPerTrigger = dbutils.widgets.get("maxFilesPerTrigger").toString
val includeExistingFiles = dbutils.widgets.get("includeExistingFiles").toString
val aws_accountid=dbutils.widgets.get("account_id").toString
val sns_arn=dbutils.widgets.get("sns_arn").toString

val date_today = ZonedDateTime.now(ZoneId.of("UTC"))
val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
val date_today_formatted = formatter format date_today

spark.sql(s"set sns_arn = '${sns_arn}'")
spark.sql(s"set aws_accountid = '${aws_accountid}'")

// COMMAND ----------

val jobId=dbutils.notebook.getContext.tags.getOrElse("jobId","")
val runId=dbutils.notebook.getContext.tags.getOrElse("runId","")
val clusterId=dbutils.notebook.getContext.tags.getOrElse("clusterId","")

val truststorePassword     = dbutils.secrets.get(scope = secret_scope, key = secret_truststorePassword)
val keystorePassword       = dbutils.secrets.get(scope = secret_scope, key = secret_keystorePassword)
val keyPassword            = dbutils.secrets.get(scope = secret_scope, key = secret_keyPassword)

// COMMAND ----------

val streamingInputDF = spark.readStream
.format("kafka")
.option("kafka.bootstrap.servers", kafkaBootStrapServers)
.option("kafka.security.protocol","SSL")
.option("kafka.ssl.truststore.location",truststoreLocation)
.option("kafka.ssl.truststore.password", truststorePassword)
.option("kafka.ssl.keystore.location", keystoreLocation)
.option("kafka.ssl.keystore.password", keystorePassword)
.option("kafka.ssl.key.password", keyPassword)
.option("subscribe", topic)
.option("startingOffsets", starting_Offsets)
.option("maxOffsetsPerTrigger", maxFilesPerTrigger)
.option("failOnDataLoss","false")
.load()



// COMMAND ----------

def parseJSONFile(raw_df: org.apache.spark.sql.Dataset[Row], batchId: Long) = {
  
  //Storing the input file in the S3 bucket for future reference.
  var jsonDF = raw_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)","CAST(topic AS STRING)","CAST(partition AS INT)","CAST(offset AS LONG)","CAST(timestamp AS timestamp)","CAST(timestampType AS INT)")
  
  
  jsonDF = jsonDF.withColumn("timestamp",(col("timestamp").cast("double")*1000).cast("long"))

  
           jsonDF.withColumn("db_load_date",current_date()).write.format("json").mode("append").partitionBy("db_load_date").save(part_json_s3_file_loc)
  
  
 val schema_data1 = """{"context":{"id":"a5f316b1-1c6c-40fb-85d5-4947070c167d","source":"SmartRideProcessing","time":1652118351898,"type":"com.nationwide.pls.telematics.auto.programs.v3.enrollment.vendor-enrolled"},"smartRideEnrollment":{"transactionType":"PolicyEnrollment","policy":{"policyNumber":"9112J 803348","policyState":"OH","drivers":[{"subjectId":1.0,"firstName":"Mobbile","lastName":"kafka","middleName":"","suffix":""}],"vehicles":[{"subjectId":1.0,"vin":"5TKZK92t888105399","year":"2021","make":"DODG","model":"CHARGER SX"}],"telematics":{"programs":[{"subjectId":1.0,"subjectType":"VEHICLE","enrollmentId":"282008","programType":"SmartMilesDevice","programStatus":"Active","enrollmentEffectiveDate":"2021-10-05","enrollmentProcessDate":"2022-05-09","programTermBeginDate":"2022-05-09","programTermEndDate":"2019-11-11","programEndDate":"2019-11-11","dataCollection":{"dataCollectionId":"b0ba6915-3b19-4647-a44f-4fa02ea93c08","vendorAccountId":"34","vendorAccountBeginDate":"2022-05-09","vendorAccountEndDate":"2019-11-11","vendor":"IMS","dataCollectionStatus":"Active","device":{"deviceId":"","deviceStatus":"NotShipped","deviceStatusDate":"2022-05-09","installGraceEndDate":"2022-05-09","lastRequestDate":"2022-05-09"}},"scoreAndDiscount":{"score":"997","scoreType":"DriverFinal","scoreModel":"NM1","scoreDate":"2021-05-06","discountPercent":"5"}}],"scoreAndDiscount":{"score":"997","scoreType":"DriverFinal","scoreModel":"SM1","scoreDate":"2021-05-06","discountPercent":"5"}}}}}"""
  

  
  val schemadf = spark.read.option("multiline",true).json(Seq(schema_data1).toDS)
  
  val convertedudf = udf((unicodestring: String) => unicodestring.replace("\u0000\u0000\u0000\u0000[",""))
  val cleansedDF = jsonDF.withColumn("cleansed_value",convertedudf(jsonDF("value"))).drop("value")
  
  val parsedDF1 = cleansedDF.withColumn("parsed_column",from_json(col("cleansed_value"),schema=schemadf.schema))
  
   val mainDF1 = parsedDF1.select($"topic",
                              $"partition",
                              $"offset",
                              $"key",
                              $"timestamp",
                              $"timestampType",
                              col("parsed_column.context.id").alias("EVNT_ID"),
                              col("parsed_column.context.source").alias("EVNT_SRC_CD"),
                              col("parsed_column.context.time").alias("EVNT_SYS_TS"),
                              col("parsed_column.context.type").alias("EVNT_TP_CD"),
                              col("parsed_column.smartRideEnrollment.policy.policyNumber").alias("PLCY_NB"),
                              col("parsed_column.smartRideEnrollment.policy.policyState").alias("PLCY_ST_CD"),
                              col("parsed_column.smartRideEnrollment.transactionType").alias("TRNSCTN_TP_CD"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.score").alias("PLCY_SCR_QTY"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.scoreType").alias("PLCY_SCR_TP_CD"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.scoreModel").alias("PLCY_SCR_MODL_CD"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.ScoreDate").alias("PLCY_SCR_DT"),
                              col("parsed_column.smartRideEnrollment.policy.telematics.scoreAndDiscount.discountPercent").cast(DoubleType).alias("PLCY_DISC_PCT"))
  

val mainDF = mainDF1.withColumnRenamed("offset","OFFST_NB").withColumnRenamed("timestamp","KFK_TS").withColumnRenamed("timestampType","TS_TP_CD").withColumnRenamed("partition","PRTN_NB").withColumnRenamed("topic","KFK_TOPIC_NM").withColumnRenamed("key","KFK_KEY")
  
val programsDataExplodedDF = parsedDF1.select(col("offset").alias("programOffset"),
                                         col("parsed_column.smartRideEnrollment.policy.policyNumber").alias("programPolicyNumber"),
                                         explode(col("parsed_column.smartRideEnrollment.policy.telematics.programs")))
  
val vehiclesExplodedDF = parsedDF1.select(col("offset").alias("vehicleOffset"),
                                         col("parsed_column.smartRideEnrollment.policy.policyNumber").alias("vehiclePolicyNumber"),
                                         explode(col("parsed_column.smartRideEnrollment.policy.vehicles")))
  
val driversExplodedDF = parsedDF1.select(col("offset").alias("driversOffset"),
                                 col("parsed_column.smartRideEnrollment.policy.policyNumber").alias("driversPolicyNumber"),
                                 explode(col("parsed_column.smartRideEnrollment.policy.drivers")))


  
val driversDF1 = driversExplodedDF.select("driversOffset",
                                        "driversPolicyNumber",
                                         "col.firstName",
                                         "col.middleName",
                                         "col.lastName",
                                         "col.suffix",
                                          "col.subjectId"
                                        )
  
val driversDF = driversDF1.select(
   col("driversOffset"),
   col("driversPolicyNumber"),
   col("firstName").alias("DRIVR_FRST_NM"),
   col("middleName").alias("DRIVR_MID_NM"),
   col("lastName").alias("DRIVR_LAST_NM"),
   col("suffix").alias("DRIVR_SFX"),
  col("subjectId").alias("SBJT_ID")
  
)
                                          

val vehicleDF1 = vehiclesExplodedDF.select("vehicleOffset",
                                         "vehiclePolicyNumber",
                                         "col.subjectId",
                                         "col.vin",
                                         "col.make",
                                         "col.model",
                                         "col.year")
  
val vehicleDF = vehicleDF1.select(
  col("vehicleOffset"),
  col("vehiclePolicyNumber"),
  col("subjectId").alias("SBJT_ID"),
  col("vin").alias("VIN_NB"),
  col("make").alias("VHCL_MAKE_CD"),
  col("model").alias("VHCL_MODL_CD"),
  col("year").alias("VHCL_YR")

)
  
var programDF1 = programsDataExplodedDF.select("programOffset",
                                              "programPolicyNumber",
                                              "col.enrollmentId",
                                              "col.programType",
                                              "col.programStatus",
                                              "col.programEndDate",
                                              "col.enrollmentEffectiveDate",
                                              "col.enrollmentProcessDate",
                                              "col.programTermBeginDate",
                                              "col.programTermEndDate",
                                              "col.subjectType",
                                              "col.subjectId",
                                              "col.dataCollection.dataCollectionId",
                                              "col.dataCollection.dataCollectionStatus",
                                              "col.dataCollection.vendor",
                                              "col.dataCollection.device.deviceId",
                                              "col.dataCollection.device.deviceStatus",
                                              "col.dataCollection.device.deviceStatusDate",
                                              "col.dataCollection.device.installGraceEndDate",
                                              "col.dataCollection.device.lastRequestDate",
                                              "col.dataCollection.vendorAccountId",
                                              "col.dataCollection.vendorAccountBeginDate",
                                              "col.dataCollection.vendorAccountEndDate",
                                              "col.scoreAndDiscount.score",
                                              "col.scoreAndDiscount.scoreType",
                                              "col.scoreAndDiscount.scoreModel",
                                              "col.scoreAndDiscount.ScoreDate",
                                              "col.scoreAndDiscount.discountpercent")
  
var programDF = programDF1.select(col("programOffset"),
                                  col("programPolicyNumber"),
                                  col("enrollmentId").alias("ENRLMNT_ID"),
                                 col("programType").alias("PRGRM_TP_CD"),
                                  col("programStatus").alias("PRGRM_STTS_CD")
                                  ,col("programEndDate").alias("PRGRM_END_DT")
                                  ,col("enrollmentEffectiveDate").alias("ENRLMNT_EFCTV_DT")
                                  ,col("enrollmentProcessDate").alias("ENRLMNT_PRCS_DT")
                                  ,col("programTermBeginDate").alias("PRGRM_TERM_BEG_DT")
                                  ,col("programTermEndDate").alias("PRGRM_TERM_END_DT")
                                  ,col("subjectId").alias("program_subject_id")
                                  ,col("subjectType").alias("SBJT_TP_CD")
                                  ,col("dataCollectionId").alias("DATA_CLCTN_ID")
                                  ,col("dataCollectionStatus").alias("DATA_CLCTN_STTS")
                                  ,col("vendor").alias("VNDR_CD")
                                  ,col("deviceId").alias("DEVC_ID")
                                  ,col("deviceStatus").alias("DEVC_STTS_CD")
                                  ,col("deviceStatusDate").alias("DEVC_STTS_DT")
                                  ,col("installGraceEndDate").alias("INSTL_GRC_END_DT")
                                  ,col("lastRequestDate").alias("LAST_RQST_DT")
                                  ,col("vendorAccountId").alias("VNDR_ACCT_ID")
                                  ,col("vendorAccountBeginDate").alias("VNDR_ACCT_BEG_DT")
                                  ,col("vendorAccountEndDate").alias("VNDR_ACCT_END_DT")
                                  ,col("score").alias("SCR_QTY")
                                  ,col("scoreType").alias("SCR_TP_CD")
                                  ,col("scoreModel").alias("SCR_MODL_CD")
                                  ,col("ScoreDate").alias("SCR_DT")
                                  ,col("discountpercent").alias("DISC_PCT")
                                  
                                 )
  
  programDF = programDF.withColumn("DISC_PCT",col("DISC_PCT").cast(DoubleType))
  
  var finalDF = mainDF.join(programDF,(mainDF("OFFST_NB") === programDF("programOffset")) && (mainDF("PLCY_NB") === programDF("programPolicyNumber")) ).drop("programOffset","programPolicyNumber")
  
var maxSK = spark.table(s"${enrl_table}").count()
var w  = Window.orderBy($"OFFST_NB",$"EVNT_SRC_CD",$"EVNT_TP_CD")
finalDF = finalDF.withColumn("PROGRAM_ENROLLMENT_ID", (row_number.over(w)+ maxSK).cast(LongType))

if(vehicleDF.count() > 0)  {
  
  val vehiclefinalDF =  finalDF.join(vehicleDF,(finalDF("OFFST_NB") === vehicleDF("vehicleOffset")) && (finalDF("PLCY_NB") === vehicleDF("vehiclePolicyNumber"))  && (finalDF("program_subject_id") === vehicleDF("SBJT_ID"))).drop("vehicleOffset","vehiclePolicyNumber","program_subject_id")
  
   val deltaDF = vehiclefinalDF.withColumn("LOAD_HR_TS",current_timestamp()).withColumn("ETL_LAST_UPDT_DTS",current_timestamp()).withColumn("LOAD_DT",current_date().cast("string"))
  
  val parqDF = deltaDF.dropDuplicates("OFFST_NB","DATA_CLCTN_ID","SBJT_ID")
  
  val lat_DF = parqDF.withColumn("PRGRM_TERM_END_DT",when(col("PRGRM_TERM_END_DT").isNull,"9999-01-01").otherwise(col("PRGRM_TERM_END_DT"))).withColumn("PRGRM_TERM_BEG_DT",when(col("PRGRM_TERM_BEG_DT").isNull,"1000-01-01").otherwise(col("PRGRM_TERM_BEG_DT"))).withColumn("DEVC_ID",when(col("DEVC_ID").isNull,"0").otherwise(col("DEVC_ID"))).withColumn("VIN_NB",when(col("VIN_NB").isNull,"0").otherwise(col("VIN_NB"))).withColumn("drivr_frst_nm",lit("").cast("string")).withColumn("drivr_last_nm",lit("").cast("string")).withColumn("drivr_mid_nm",lit("").cast("string")).withColumn("drivr_sfx",lit("").cast("string"))
  
  val new_loc = parq_s3_mnt_loc+"load_dt="+date_today_formatted+"/"
  
  var s3_df = lat_DF.select("kfk_topic_nm","kfk_key","prtn_nb","offst_nb","kfk_ts","ts_tp_cd","evnt_id","evnt_src_cd","evnt_sys_ts","evnt_tp_cd","plcy_nb","plcy_st_cd","trnsctn_tp_cd","sbjt_id","drivr_frst_nm","drivr_last_nm","drivr_mid_nm","drivr_sfx","enrlmnt_id","prgrm_tp_cd","prgrm_stts_cd","enrlmnt_efctv_dt","enrlmnt_prcs_dt","prgrm_end_dt","prgrm_term_beg_dt","prgrm_term_end_dt","vin_nb","vhcl_make_cd","vhcl_modl_cd","vhcl_yr","sbjt_tp_cd","data_clctn_id","vndr_acct_id","vndr_acct_beg_dt","vndr_acct_end_dt","data_clctn_stts","vndr_cd","devc_id","devc_stts_cd","devc_stts_dt","instl_grc_end_dt","last_rqst_dt","scr_qty","scr_tp_cd","scr_modl_cd","scr_dt","disc_pct","plcy_scr_qty","plcy_scr_tp_cd","plcy_scr_modl_cd","plcy_scr_dt","plcy_disc_pct","program_enrollment_id","load_hr_ts","etl_last_updt_dts","load_dt")
  
 lat_DF.coalesce(1).write
  .format("delta")
  .mode("append")
  .option("path",enrl_file_path)
  .partitionBy("LOAD_DT").saveAsTable(enrl_table)
  
  
 s3_df = s3_df.withColumnRenamed("LOAD_DT","load_dt") 
  s3_df.coalesce(1).write
  .mode("append")
  .partitionBy("load_dt")
  .parquet(parq_s3_mnt_loc)
  
}
  
if(driversDF.count() > 0){
  
 val  driversfinalDF = finalDF.join(driversDF,(finalDF("OFFST_NB") === driversDF("driversOffset")) && (finalDF("PLCY_NB") === driversDF("driversPolicyNumber")) && (finalDF("program_subject_id") === driversDF("SBJT_ID"))).drop("driversOffset","driversPolicyNumber","program_subject_id")
  
  val deltaDF = driversfinalDF.withColumn("LOAD_HR_TS",current_timestamp()).withColumn("ETL_LAST_UPDT_DTS",current_timestamp()).withColumn("LOAD_DT",current_date().cast("string"))
  
  val parqDF = deltaDF.dropDuplicates("OFFST_NB","DATA_CLCTN_ID","SBJT_ID")
  val lat_DF = parqDF.withColumn("PRGRM_TERM_END_DT",when(col("PRGRM_TERM_END_DT").isNull,"9999-01-01").otherwise(col("PRGRM_TERM_END_DT"))).withColumn("PRGRM_TERM_BEG_DT",when(col("PRGRM_TERM_BEG_DT").isNull,"1000-01-01").otherwise(col("PRGRM_TERM_BEG_DT"))).withColumn("DEVC_ID",when(col("DEVC_ID").isNull,"0").otherwise(col("DEVC_ID"))).withColumn("VIN_NB",lit("0")).withColumn("vhcl_make_cd",lit("").cast("string")).withColumn("vhcl_modl_cd",lit("").cast("string")).withColumn("vhcl_yr",lit("").cast("string"))
  
  val new_loc = parq_s3_mnt_loc+"load_dt="+date_today_formatted+"/"
   
  var s3_df = lat_DF.select("kfk_topic_nm","kfk_key","prtn_nb","offst_nb","kfk_ts","ts_tp_cd","evnt_id","evnt_src_cd","evnt_sys_ts","evnt_tp_cd","plcy_nb","plcy_st_cd","trnsctn_tp_cd","sbjt_id","drivr_frst_nm","drivr_last_nm","drivr_mid_nm","drivr_sfx","enrlmnt_id","prgrm_tp_cd","prgrm_stts_cd","enrlmnt_efctv_dt","enrlmnt_prcs_dt","prgrm_end_dt","prgrm_term_beg_dt","prgrm_term_end_dt","vin_nb","vhcl_make_cd","vhcl_modl_cd","vhcl_yr","sbjt_tp_cd","data_clctn_id","vndr_acct_id","vndr_acct_beg_dt","vndr_acct_end_dt","data_clctn_stts","vndr_cd","devc_id","devc_stts_cd","devc_stts_dt","instl_grc_end_dt","last_rqst_dt","scr_qty","scr_tp_cd","scr_modl_cd","scr_dt","disc_pct","plcy_scr_qty","plcy_scr_tp_cd","plcy_scr_modl_cd","plcy_scr_dt","plcy_disc_pct","program_enrollment_id","load_hr_ts","etl_last_updt_dts","load_dt")
  
  lat_DF.coalesce(1).write
  .format("delta")
  .mode("append")
  .option("path",enrl_file_path)
  .partitionBy("LOAD_DT").saveAsTable(enrl_table)

  
 s3_df = s3_df.withColumnRenamed("LOAD_DT","load_dt") 
  s3_df.coalesce(1).write
  .mode("append")
  .partitionBy("load_dt")
  .parquet(parq_s3_mnt_loc)
  
  
}

   
}


// COMMAND ----------

// MAGIC %py
// MAGIC def athena_query(athena_output_location,aws_id):
// MAGIC     import boto3
// MAGIC     import math
// MAGIC     import botocore
// MAGIC     try:
// MAGIC       aws_accountid = aws_id
// MAGIC       path = athena_output_location
// MAGIC         
// MAGIC       sts_client = boto3.client('sts',region_name='us-east-1',endpoint_url ='https://sts.us-east-1.amazonaws.com')
// MAGIC       response2 = sts_client.assume_role(RoleArn=f'arn:aws:iam::{aws_accountid}:role/pcds-databricks-common-access',RoleSessionName='myDhfsession')
// MAGIC 
// MAGIC       athena_client = boto3.client('athena',
// MAGIC                           aws_access_key_id=response2.get('Credentials').get('AccessKeyId'),
// MAGIC                           aws_secret_access_key=response2.get('Credentials').get('SecretAccessKey'),
// MAGIC                           aws_session_token=response2.get('Credentials').get('SessionToken'),region_name='us-east-1')
// MAGIC 
// MAGIC       query="msck repair table telematics_staging_db.program_enrollment;"
// MAGIC       params = {
// MAGIC         'region': 'us-east-1',
// MAGIC         'database': 'telematics_staging_db'
// MAGIC       }
// MAGIC       response = athena_client.start_query_execution(
// MAGIC         QueryString=query,
// MAGIC         QueryExecutionContext={
// MAGIC             'Database': params['database']
// MAGIC         },
// MAGIC         ResultConfiguration={
// MAGIC             'OutputLocation': path
// MAGIC         }
// MAGIC       )
// MAGIC       return response
// MAGIC     except botocore.exceptions.ClientError as err:
// MAGIC 
// MAGIC         if err.response['Error']['Code'] == 'InternalError': # Generic error
// MAGIC             # We grab the message, request ID, and HTTP code to give to customer support
// MAGIC             print('Error Message: {}'.format(err.response['Error']['Message']))
// MAGIC             print('Request ID: {}'.format(err.response['ResponseMetadata']['RequestId']))
// MAGIC             print('Http code: {}'.format(err.response['ResponseMetadata']['HTTPStatusCode']))
// MAGIC         else:
// MAGIC             print('Error Message: {}'.format(err.response['Error']['Message']))
// MAGIC             print('Request ID: {}'.format(err.response['ResponseMetadata']['RequestId']))
// MAGIC             print('Http code: {}'.format(err.response['ResponseMetadata']['HTTPStatusCode']))
// MAGIC         raise err
// MAGIC     return None
// MAGIC 
// MAGIC spark.udf.register("Boto3Athena", athena_query)

// COMMAND ----------

val streamingOutputDF = streamingInputDF.writeStream
  .trigger(Trigger.Once)
  .queryName("EnrollmentFileStream")
  .format("delta")
  .outputMode( "append")
  .option("checkpointLocation", checkpointLocation)
  .foreachBatch(parseJSONFile _).start()

val dbLoadTime = time.LocalDateTime.now()
val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH%");
val formatDateTime = dbLoadTime.format(formatter);
Thread.sleep(120000)

val auditDF = spark.sql(s"select distinct OFFST_NB from $enrl_table where LOAD_HR_TS LIKE '$formatDateTime'")
var s3_athena_query = spark.sql(s"select Boto3Athena('$athena_output_loc','$aws_accountid') s3_athena_query")
s3_athena_query.show(truncate=false)

if (auditDF.rdd.isEmpty){
  print("no data was loaded")
  spark.sql(s"set cmtAuditValue = 0")
}else {
  print("data loaded successfully")
  spark.sql(s"set cmtAuditValue = 1")
}

// COMMAND ----------

// MAGIC %py
// MAGIC import boto3
// MAGIC import time
// MAGIC 
// MAGIC from datetime import datetime
// MAGIC now = datetime.now()
// MAGIC aws_accountid=spark.sql("select ${aws_accountid}").head()[0]
// MAGIC def send_mail(topic_arn,subject,message):
// MAGIC   sts_client = boto3.client("sts",region_name='us-east-1',endpoint_url ='https://sts.us-east-1.amazonaws.com')
// MAGIC   response2 = sts_client.assume_role(RoleArn=f'arn:aws:iam::{aws_accountid}:role/dw-pl-cmt-TelematicS3FileMove-role',RoleSessionName='myDhfsession')
// MAGIC   account_number = sts_client.get_caller_identity()["Account"]
// MAGIC   print(account_number)
// MAGIC   sns_client = boto3.Session(region_name='us-east-1').client("sns",
// MAGIC                           aws_access_key_id=response2.get('Credentials').get('AccessKeyId'),
// MAGIC                           aws_secret_access_key=response2.get('Credentials').get('SecretAccessKey'),
// MAGIC                           aws_session_token=response2.get('Credentials').get('SessionToken'))
// MAGIC   topic_arn=topic_arn
// MAGIC   sns_client.publish(TopicArn = topic_arn, Message = message, Subject = subject)
// MAGIC 
// MAGIC time.sleep(100)
// MAGIC cmtAuditValue=spark.sql("select ${cmtAuditValue}").head()[0]
// MAGIC sns_arn=spark.sql("select ${sns_arn}").head()[0]
// MAGIC 
// MAGIC if cmtAuditValue == 0:
// MAGIC   print("Test The data is not loaded")
// MAGIC   send_mail(sns_arn,f"Program Enrollment Audit failure: Data not loaded for Program Enrollment V3 ",f"Hi Team,\n\n The data is not loaded for the current load time  for Program Enrollment V3 ,please check. \n \n Regards,\nSupport Team")
// MAGIC 
// MAGIC   
// MAGIC   
