// Databricks notebook source
val environment=dbutils.widgets.get("environment").toString

// COMMAND ----------

import java.time._


val rawTablesList=List(
s"dhf_iot_ims_raw_${environment}.tripsummary",
s"dhf_iot_ims_raw_${environment}.telemetrypoints",
s"dhf_iot_ims_raw_${environment}.telemetryevents",
s"dhf_iot_ims_raw_${environment}.nontripevent",
s"dhf_iot_ims_raw_${environment}.scoring",
s"dhf_iot_ims_raw_${environment}.histogramscoringintervals",
s"dhf_iot_tims_raw_${environment}.tripsummary",
s"dhf_iot_tims_raw_${environment}.telemetrypoints",
s"dhf_iot_fmc_raw_${environment}.tripsummary",
s"dhf_iot_fmc_raw_${environment}.telemetrypoints",
s"dhf_iot_octo_raw_${environment}.smartride_octo_tripsummary",
s"dhf_iot_octo_raw_${environment}.smartride_octo_tripevent",
s"dhf_iot_octo_raw_${environment}.smartride_octo_trippoint",
s"dhf_iot_octo_raw_${environment}.smartride_octo_cumulative"
)
val harmonizeTablesList=List(
s"dhf_iot_harmonized_${environment}.trip_summary_chlg",
s"dhf_iot_harmonized_${environment}.trip_point_chlg",
s"dhf_iot_harmonized_${environment}.trip_event_chlg",
s"dhf_iot_harmonized_${environment}.non_trip_event_chlg",
s"dhf_iot_harmonized_${environment}.scoring_chlg",
s"dhf_iot_harmonized_${environment}.histogram_scoring_interval_chlg",
s"dhf_iot_harmonized_${environment}.device_chlg",
s"dhf_iot_harmonized_${environment}.vehicle_chlg"
)
val curateTablesList=List(
//s"dhf_iot_curated_${environment}.ca_annual_mileage_scoring",
s"dhf_iot_curated_${environment}.ca_annual_mileage_scoring_chlg",
//s"dhf_iot_curated_${environment}.daily_mileage",
//s"dhf_iot_curated_${environment}.daily_mileage_chlg",
// s"dhf_iot_curated_${environment}.device_status",
s"dhf_iot_curated_${environment}.device_status_chlg",
// s"dhf_iot_curated_${environment}.device_summary",
s"dhf_iot_curated_${environment}.device_summary_chlg",
//s"dhf_iot_curated_${environment}.extracts_dailyscoring",
//s"dhf_iot_curated_${environment}.extracts_dailyscoring_chlg",
// s"dhf_iot_curated_${environment}.inbound_score_elements",
//s"dhf_iot_curated_${environment}.ods_program_instance",
// s"dhf_iot_curated_${environment}.outbound_score_elements",
s"dhf_iot_curated_${environment}.outbound_score_elements_chlg",
//s"dhf_iot_curated_${environment}.program_summary",
//s"dhf_iot_curated_${environment}.program_summary_chlg",
// s"dhf_iot_curated_${environment}.trip_detail",
s"dhf_iot_curated_${environment}.trip_detail_chlg",
// s"dhf_iot_harmonized_${environment}.trip_detail_seconds",
s"dhf_iot_harmonized_${environment}.trip_detail_seconds_chlg"
)
  


// COMMAND ----------

//Raw tables optimization
import java.time._

rawTablesList.foreach( table => {  
  val previous_date=LocalDate.now(ZoneOffset.UTC).minusDays(2).toString()
  var condition=s"where load_date >='${previous_date}'"
  val optimize_str= s"OPTIMIZE ${table} ${condition}"
  val vacuum_str=s"VACUUM ${table} RETAIN 168 HOURS"
  println(s"OPTIMIZE starts for ${table} ${condition}")
  spark.sql(optimize_str)
  println(s"OPTIMIZE completes for ${table} ${condition}") 
  
  println(s"VACUUM starts for ${table}")  
  spark.sql(vacuum_str)
  println(s"VACUUM completes for ${table} ") 
 
})


// COMMAND ----------

//Harmonize tables optimization
harmonizeTablesList.foreach( table => {  
  val previous_date=LocalDate.now(ZoneOffset.UTC).minusDays(1).toString()
// var condition=s"where LOAD_DT >='${previous_date}'"
  val optimize_str= s"OPTIMIZE ${table} "
  val vacuum_str=s"VACUUM ${table} RETAIN 168 HOURS"
  println(s"OPTIMIZE starts for ${table}")
  spark.sql(optimize_str)
  println(s"OPTIMIZE completes for ${table} ") 

  println(s"VACUUM starts for ${table}")  
  spark.sql(vacuum_str)
  println(s"VACUUM completes for ${table} ") 
 
})

// COMMAND ----------

//Curate tables optimization
curateTablesList.foreach( table => {  
 val previous_date=LocalDate.now(ZoneOffset.UTC).minusDays(1).toString()
// var condition=s"where LOAD_DT >='${previous_date}'"
  val optimize_str= s"OPTIMIZE ${table} "
  val vacuum_str=s"VACUUM ${table} RETAIN 168 HOURS"
  println(s"OPTIMIZE starts for ${table}")
  spark.sql(optimize_str)
  println(s"OPTIMIZE completes for ${table} ") 

  println(s"VACUUM starts for ${table}")  
  spark.sql(vacuum_str)
  println(s"VACUUM completes for ${table} ")  
 
})
