# Databricks notebook source
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import *
import datetime
import io
import re
import json
import zipfile
from pyspark.sql.types import *
import boto3
from datetime import datetime as dt
from pyspark.sql import functions as f
spark.conf.set("spark.sql.adaptive.enabled",True)
spark.conf.set("spark.databricks.io.cache.enabled", True)


# COMMAND ----------

schema=StructType([StructField("accelQuality",BooleanType(),True),StructField("fuelConsumption",StringType(),True),StructField("avgSpeed",StringType(),True),StructField("device",StructType([StructField("deviceIdentifier",StringType(),True),StructField("deviceIdentifierType",StringType(),True),StructField("deviceSerialNumber",StringType(),True),StructField("deviceType",StringType(),True)]),True),StructField("drivingDistance",StringType(),True),StructField("externalReferences",ArrayType(StructType([StructField("enterpriseReferenceExtraInfo",StringType(),True),StructField("enterpriseReferenceId",StringType(),True),StructField("type",StringType(),True)])),True),StructField("hdopAverage",StringType(),True),StructField("histogramScoringIntervals",ArrayType(StructType([StructField("occurrenceUnit",StringType(),True),StructField("occurrences",StringType(),True),StructField("roadType",StringType(),True),StructField("scoringComponent",StringType(),True),StructField("scoringComponentUnit",StringType(),True),StructField("scoringSubComponent",StringType(),True),StructField("thresholdLowerBound",StringType(),True),StructField("thresholdUpperBound",StringType(),True)])),True),StructField("maxSpeed",StringType(),True),StructField("measurementUnit",StructType([StructField("system",StringType(),True)]),True),StructField("milStatus",BooleanType(),True),StructField("scoring",StructType([StructField("individualComponentScores",ArrayType(StructType([StructField("component",StringType(),True),StructField("componentScore",StringType(),True)])),True),StructField("overallScore",StringType(),True),StructField("scoreAlgorithmProvider",StringType(),True),StructField("scoreUnit",StringType(),True)]),True),StructField("secondsOfIdling",StringType(),True),StructField("telemetryEvents",ArrayType(StructType([StructField("acceleration",StringType(),True),StructField("avgSpeed",StringType(),True),StructField("degreesLatitude",StringType(),True),StructField("degreesLongitude",StringType(),True),StructField("headingDegrees",StringType(),True),StructField("secondsOfDriving",StringType(),True),StructField("speed",StringType(),True),StructField("telemetryEventSeverityLevel",StringType(),True),StructField("telemetryEventType",StringType(),True),StructField("utcDateTime",StringType(),True)])),True),StructField("telemetryPoints",ArrayType(StructType([StructField("acceleration",StringType(),True),StructField("accelerometerData",StringType(),True),StructField("ambientTemperature",StringType(),True),StructField("barometericPressure",StringType(),True),StructField("coolantTemperature",StringType(),True),StructField("degreesLatitude",StringType(),True),StructField("degreesLongitude",StringType(),True),StructField("engineRPM",StringType(),True),StructField("fuelLevel",StringType(),True),StructField("hdop",StringType(),True),StructField("headingDegrees",StringType(),True),StructField("speed",StringType(),True),StructField("utcDateTime",StringType(),True)])),True),StructField("timeZoneOffset",StringType(),True),StructField("totalTripSeconds",StringType(),True),StructField("transportMode",StringType(),True),StructField("transportModeReason",StringType(),True),StructField("tripSummaryId",StringType(),True),StructField("utcEndDateTime",StringType(),True),StructField("utcStartDateTime",StringType(),True),StructField("vehicle",StructType([StructField("detectedVin",StringType(),True),StructField("enrolledVin",StringType(),True)]),True)])

schema2=StructType([StructField("accelquality",BooleanType(),True),StructField("fuelconsumption",StringType(),True),StructField("avgspeed",StringType(),True),StructField("device",StructType([StructField("deviceidentifier",StringType(),True),StructField("deviceidentifiertype",StringType(),True),StructField("deviceserialnumber",StringType(),True),StructField("devicetype",StringType(),True)]),True),StructField("drivingdistance",StringType(),True),StructField("externalreferences",ArrayType(StructType([StructField("enterprisereferenceextrainfo",StringType(),True),StructField("enterprisereferenceid",StringType(),True),StructField("type",StringType(),True)])),True),StructField("hdopaverage",StringType(),True),StructField("histogramscoringintervals",ArrayType(StructType([StructField("occurrenceunit",StringType(),True),StructField("occurrences",StringType(),True),StructField("roadtype",StringType(),True),StructField("scoringcomponent",StringType(),True),StructField("scoringcomponentunit",StringType(),True),StructField("scoringsubcomponent",StringType(),True),StructField("thresholdlowerbound",StringType(),True),StructField("thresholdupperbound",StringType(),True)])),True),StructField("maxspeed",StringType(),True),StructField("measurementunit",StructType([StructField("system",StringType(),True)]),True),StructField("milstatus",BooleanType(),True),StructField("scoring",StructType([StructField("individualcomponentscores",ArrayType(StructType([StructField("component",StringType(),True),StructField("componentscore",StringType(),True)])),True),StructField("overallscore",StringType(),True),StructField("scorealgorithmprovider",StringType(),True),StructField("scoreunit",StringType(),True)]),True),StructField("secondsofidling",StringType(),True),StructField("telemetryevents",ArrayType(StructType([StructField("acceleration",StringType(),True),StructField("avgspeed",StringType(),True),StructField("degreeslatitude",StringType(),True),StructField("degreeslongitude",StringType(),True),StructField("headingdegrees",StringType(),True),StructField("secondsofdriving",StringType(),True),StructField("speed",StringType(),True),StructField("telemetryeventseveritylevel",StringType(),True),StructField("telemetryeventtype",StringType(),True),StructField("utcdatetime",StringType(),True)])),True),StructField("telemetrypoints",ArrayType(StructType([StructField("acceleration",StringType(),True),StructField("accelerometerdata",StringType(),True),StructField("ambienttemperature",StringType(),True),StructField("barometericpressure",StringType(),True),StructField("coolanttemperature",StringType(),True),StructField("degreeslatitude",StringType(),True),StructField("degreeslongitude",StringType(),True),StructField("enginerpm",StringType(),True),StructField("fuellevel",StringType(),True),StructField("hdop",StringType(),True),StructField("headingdegrees",StringType(),True),StructField("speed",StringType(),True),StructField("utcdatetime",StringType(),True)])),True),StructField("timezoneoffset",StringType(),True),StructField("totaltripseconds",StringType(),True),StructField("transportmode",StringType(),True),StructField("transportmodereason",StringType(),True),StructField("tripsummaryid",StringType(),True),StructField("utcenddatetime",StringType(),True),StructField("utcstartdatetime",StringType(),True),StructField("vehicle",StructType([StructField("detectedvin",StringType(),True),StructField("enrolledvin",StringType(),True)]),True)])

# COMMAND ----------

schema_EVT=StructType([StructField("device",StructType([StructField("deviceIdentifier",StringType(),True),StructField("deviceIdentifierType",StringType(),True),StructField("deviceSerialNumber",StringType(),True),StructField("deviceType",StringType(),True)]),True),StructField("externalReferences",ArrayType(StructType([StructField("enterpriseReferenceExtraInfo",StringType(),True),StructField("enterpriseReferenceId",StringType(),True),StructField("type",StringType(),True)])),True),StructField("telemetryEvents",ArrayType(StructType([StructField("acceleration",StringType(),True),StructField("degreesLatitude",StringType(),True),StructField("degreesLongitude",StringType(),True),StructField("headingDegrees",StringType(),True),StructField("speed",StringType(),True),StructField("telemetryEventSeverityLevel",StringType(),True),StructField("telemetryEventType",StringType(),True),StructField("utcDateTime",StringType(),True)])),True),StructField("telemetrySetId",StringType(),True),StructField("vehicle",StructType([StructField("detectedVin",StringType(),True),StructField("enrolledVin",StringType(),True)]),True)])

# COMMAND ----------

json_df=spark.read.format("text").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_staging_db/smartmiles_staging_json/source_cd=IMS/").filter("batch_nb>=202207200000 and batch_nb<202208110000")
parse_df=json_df.filter("value like '%tripSummaryId%'").withColumn("parse_col",from_json("value",schema=schema)).select("parse_col.*","batch_nb")
parse_evt_df=json_df.filter("value like '%telemetrySetId%'").withColumn("parse_col",from_json("value",schema=schema_EVT)).select("parse_col.*","batch_nb")

parse_df2=json_df.filter("value like '%tripsummaryid%'").withColumn("parse_col",from_json("value",schema=schema2)).select("parse_col.*","batch_nb")
# display(json_df.filter("value like '%detectedvin%'").limit(3))


# COMMAND ----------

tripsummary_df=parse_df.withColumn("externalReferences_explode",explode_outer(col("externalReferences"))).select("*","vehicle.*","device.*","measurementUnit.*","externalReferences_explode.*")
tripsummary_df.createOrReplaceTempView("tripsummaryview")

tripsummary_df2=parse_df2.withColumn("externalReferences_explode",explode_outer(col("externalreferences"))).select("*","vehicle.*","device.*","measurementunit.*","externalReferences_explode.*")
tripsummary_df2.createOrReplaceTempView("tripsummaryview2")





# COMMAND ----------

tripsummary_raw_df=spark.sql("""select cast(tripSummaryId as string),cast(fuelConsumption as string),cast(milStatus as boolean),cast(accelQuality as boolean),cast(transportMode as string),cast(secondsOfIdling as string),cast(transportModeReason as string),cast(hdopAverage as string),cast(utcStartDateTime as string),cast(utcEndDateTime as string),cast(timeZoneOffset as string),cast(drivingDistance as string),cast(maxSpeed as string),cast(avgSpeed as string),cast(totalTripSeconds as bigint),cast(deviceSerialNumber as string),cast(deviceIdentifier as string),cast(deviceIdentifierType as string),cast(deviceType as string),cast(enterpriseReferenceId as string),cast(enterpriseReferenceExtraInfo as string),cast(type as string),cast(enrolledVin as string),cast(detectedVin as string),cast(system as string),"IMS_SM_5X" as SourceSystem,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date from tripsummaryview
WHERE tripSummaryId IS NOT NULL""")

tripsummary_raw_df.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.tripsummary")
# display(tripsummary_raw_df)

# COMMAND ----------

tripsummary_harmonize_df=spark.sql("""select  cast(monotonically_increasing_id() +1  + coalesce((select max(TRIP_SUMMARY_ID) from dhf_iot_harmonized_prod.trip_summary),0) as BIGINT) as TRIP_SUMMARY_ID, coalesce(tripSummaryId, "NOKEY") AS TRIP_SMRY_KEY,  coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin)) AS DEVC_KEY, cast(accelQuality as STRING) AS ACLRTN_QLTY_FL, cast(hdopAverage as decimal(15,6)) AS AVG_HDOP_QTY, cast(avgSpeed as decimal(18,5)) AS AVG_SPD_MPH_RT, cast(drivingDistance as decimal(15,6)) AS DRVNG_DISTNC_QTY, cast(fuelConsumption as decimal(15,6)) AS FUEL_CNSMPTN_QTY, cast(secondsOfIdling as decimal(15,6)) AS IDLING_SC_QTY, cast(milStatus as STRING) AS MLFNCTN_STTS_FL, cast(maxSpeed as decimal(18,5)) AS MAX_SPD_RT, cast(system as STRING) AS MSURET_UNIT_CD, cast(enterpriseReferenceId as STRING) AS PLCY_NB, cast(timeZoneOffset as decimal(10,2)) as TIME_ZONE_OFFST_NB, cast(totalTripSeconds as decimal(15,6)) AS TRIP_SC_QTY, cast(transportMode as STRING) AS TRNSPRT_MODE_CD, cast(transportModeReason as STRING) AS TRNSPRT_MODE_RSN_CD, coalesce(cast(utcStartDateTime as TIMESTAMP), to_timestamp("9999-12-31")) AS TRIP_START_TS, coalesce(cast(utcEndDateTime as TIMESTAMP), to_timestamp("9999-12-31")) AS TRIP_END_TS, coalesce(enrolledVin,detectedVin) AS VEH_KEY, 
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS,current_timestamp() AS ETL_ROW_EFF_DTS, 
current_timestamp() as ETL_LAST_UPDT_DTS from tripsummaryview
""")

tripsummary_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_summary")
# display(tripsummary_harmonize_df)

# COMMAND ----------

# vehicle_harmonize_df=spark.sql("""select distinct cast(monotonically_increasing_id() +1 + coalesce((select max(VEHICLE_ID) from dhf_iot_harmonized_prod.vehicle),0) as BIGINT) as VEHICLE_ID, COALESCE(enrolledVin,detectedVin,"NOKEY") AS VEH_KEY, COALESCE(detectedVin,enrolledVin) as DTCTD_VIN_NB, COALESCE(enrolledVin,detectedVin,"NOKEY") as ENRLD_VIN_NB, coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
# "IMS_SM_5X" AS SRC_SYS_CD, 
# coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS,current_timestamp() AS ETL_ROW_EFF_DTS, 
# current_timestamp() as ETL_LAST_UPDT_DTS from 
# (select *,row_number() over (partition by enrolledVin,detectedVin order by batch_nb desc) as row_number from tripsummaryview WHERE enrolledVin IS NOT NULL) where row_number=1""")

# vehicle_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.vehicle")
# # display(vehicle_harmonize_df)

# COMMAND ----------

# device_harmonize_df=spark.sql("""select distinct cast(monotonically_increasing_id() +1 + coalesce((select max(DEVICE_ID) from dhf_iot_harmonized_prod.device),0) as BIGINT) as DEVICE_ID, coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin), "NOKEY") AS DEVC_KEY, deviceIdentifier as DEVC_ID_NB, deviceIdentifierType as DEVC_ID_TP_CD, deviceType as DEVC_TP_CD, deviceSerialNumber as DEVC_SRL_NB, current_timestamp() AS ETL_ROW_EFF_DTS, 
# current_timestamp() as ETL_LAST_UPDT_DTS, 
# coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
# "IMS_SM_5X" AS SRC_SYS_CD, 
# coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS from 
# (select *,row_number() over (partition by deviceIdentifier,deviceSerialNumber order by batch_nb desc) as row_number from tripsummaryview WHERE tripSummaryId IS NOT NULL) where row_number=1 
# """)

# device_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.device")
# # display(device_harmonize_df)

# COMMAND ----------

tripsummary_harmonize_df2=spark.sql("""select  cast(monotonically_increasing_id() +1  + coalesce((select max(TRIP_SUMMARY_ID) from dhf_iot_harmonized_prod.trip_summary),0) as BIGINT) as TRIP_SUMMARY_ID, coalesce(tripSummaryId, "NOKEY") AS TRIP_SMRY_KEY,  coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin)) AS DEVC_KEY, cast(accelQuality as STRING) AS ACLRTN_QLTY_FL, cast(hdopAverage as decimal(15,6)) AS AVG_HDOP_QTY, cast(avgSpeed as decimal(18,5)) AS AVG_SPD_MPH_RT, cast(drivingDistance as decimal(15,6)) AS DRVNG_DISTNC_QTY, cast(fuelConsumption as decimal(15,6)) AS FUEL_CNSMPTN_QTY, cast(secondsOfIdling as decimal(15,6)) AS IDLING_SC_QTY, cast(milStatus as STRING) AS MLFNCTN_STTS_FL, cast(maxSpeed as decimal(18,5)) AS MAX_SPD_RT, cast(system as STRING) AS MSURET_UNIT_CD, cast(enterpriseReferenceId as STRING) AS PLCY_NB, cast(timeZoneOffset as decimal(10,2)) as TIME_ZONE_OFFST_NB, cast(totalTripSeconds as decimal(15,6)) AS TRIP_SC_QTY, cast(transportMode as STRING) AS TRNSPRT_MODE_CD, cast(transportModeReason as STRING) AS TRNSPRT_MODE_RSN_CD, coalesce(cast(utcStartDateTime as TIMESTAMP), to_timestamp("9999-12-31")) AS TRIP_START_TS, coalesce(cast(utcEndDateTime as TIMESTAMP), to_timestamp("9999-12-31")) AS TRIP_END_TS, coalesce(enrolledVin,detectedVin) AS VEH_KEY, 
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS,current_timestamp() AS ETL_ROW_EFF_DTS, 
current_timestamp() as ETL_LAST_UPDT_DTS from tripsummaryview2
""")

tripsummary_harmonize_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_summary")
# display(tripsummary_harmonize_df2)

# COMMAND ----------

tripsummary_raw_df2=spark.sql("""select cast(tripSummaryId as string),cast(fuelConsumption as string),cast(milStatus as boolean),cast(accelQuality as boolean),cast(transportMode as string),cast(secondsOfIdling as string),cast(transportModeReason as string),cast(hdopAverage as string),cast(utcStartDateTime as string),cast(utcEndDateTime as string),cast(timeZoneOffset as string),cast(drivingDistance as string),cast(maxSpeed as string),cast(avgSpeed as string),cast(totalTripSeconds as bigint),cast(deviceSerialNumber as string),cast(deviceIdentifier as string),cast(deviceIdentifierType as string),cast(deviceType as string),cast(enterpriseReferenceId as string),cast(enterpriseReferenceExtraInfo as string),cast(type as string),cast(enrolledVin as string),cast(detectedVin as string),cast(system as string),"IMS_SM_5X" as SourceSystem,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date from tripsummaryview2
WHERE tripSummaryId IS NOT NULL""")

tripsummary_raw_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.tripsummary")
# display(tripsummary_raw_df2)

# COMMAND ----------

# device_harmonize_df2=spark.sql("""select distinct cast(monotonically_increasing_id() +1 + coalesce((select max(DEVICE_ID) from dhf_iot_harmonized_prod.device),0) as BIGINT) as DEVICE_ID, coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin), "NOKEY") AS DEVC_KEY, deviceIdentifier as DEVC_ID_NB, deviceIdentifierType as DEVC_ID_TP_CD, deviceType as DEVC_TP_CD, deviceSerialNumber as DEVC_SRL_NB, current_timestamp() AS ETL_ROW_EFF_DTS, 
# current_timestamp() as ETL_LAST_UPDT_DTS, 
# coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
# "IMS_SM_5X" AS SRC_SYS_CD, 
# coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS from 
# (select *,row_number() over (partition by detectedvin order by batch_nb desc) as row_number from tripsummaryview2 WHERE detectedvin IS NOT NULL and coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin)) not in (select DEVC_KEY from dhf_iot_harmonized_prod.device) ) where row_number=1 
# """)

# device_harmonize_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.device")
# # display(device_harmonize_df2)

# COMMAND ----------

# vehicle_harmonize_df2=spark.sql("""select distinct cast(monotonically_increasing_id() +1 + coalesce((select max(VEHICLE_ID) from dhf_iot_harmonized_prod.vehicle),0) as BIGINT) as VEHICLE_ID, COALESCE(enrolledVin,detectedVin,"NOKEY") AS VEH_KEY, COALESCE(detectedVin,enrolledVin) as DTCTD_VIN_NB, COALESCE(enrolledVin,detectedVin,"NOKEY") as ENRLD_VIN_NB, coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
# "IMS_SM_5X" AS SRC_SYS_CD, 
# coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS,current_timestamp() AS ETL_ROW_EFF_DTS, 
# current_timestamp() as ETL_LAST_UPDT_DTS from 
# (select *,row_number() over (partition by enrolledVin,detectedVin order by batch_nb desc) as row_number from tripsummaryview2  WHERE detectedvin IS NOT NULL and COALESCE(enrolledVin,detectedVin) not in (select VEH_KEY from dhf_iot_harmonized_prod.vehicle)  ) where row_number=1""")

# vehicle_harmonize_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.vehicle")
# # display(vehicle_harmonize_df2)

# COMMAND ----------

tripevent_df=parse_df.withColumn("telemetryEvents_explode",explode_outer(col("telemetryEvents"))).select("tripSummaryId","telemetryEvents_explode.*","batch_nb","vehicle.*")
tripevent_df.createOrReplaceTempView("tripevent")




# COMMAND ----------

tripevent_raw_df=spark.sql("""select cast(tripSummaryId as string),cast(degreesLatitude as string),cast(degreesLongitude as string),cast(headingDegrees as string),cast(telemetryEventType as string),cast(utcDateTime as string),cast(speed as string),cast(acceleration as string),cast(secondsOfDriving as string),cast(telemetryEventSeverityLevel as string),cast( tripevent.avgSpeed as string) as telemetryEvents__avgSpeed ,"IMS_SM_5X" as SourceSystem,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date from tripevent 
WHERE tripSummaryId IS NOT NULL""")

tripevent_raw_df.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.telemetryevents")
# display(tripevent_raw_df)

# COMMAND ----------

tripevent_harmonize_df=spark.sql("""select  cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_EVENT_ID) from dhf_iot_harmonized_prod.trip_event),0) as BIGINT) as TRIP_EVENT_ID, cast(acceleration as decimal(18,5)) as ACLRTN_RT, cast(secondsOfDriving as decimal(15,6)) as DRVNG_SC_QTY, cast(telemetryEventSeverityLevel as STRING) as EVNT_SVRTY_CD,coalesce(telemetryEventType, "NOKEY") as EVNT_TP_CD, cast(headingDegrees as decimal(15,6)) as HEADNG_DEG_QTY, cast(speed as decimal(18,10)) as SPD_RT, tripSummaryId AS TRIP_SMRY_KEY, cast(tripevent.avgSpeed  as decimal(18,10)) as AVG_SPD_RT, coalesce(cast(utcDateTime as TIMESTAMP), to_timestamp("9999-12-31")) as UTC_TS, cast(degreesLatitude as decimal(18,10)) as LAT_NB, cast(degreesLongitude as decimal(18,10)) as LNGTD_NB,coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS, current_timestamp() AS ETL_ROW_EFF_DTS, 
current_timestamp() as ETL_LAST_UPDT_DTS, null as EVNT_STRT_TS, null as EVNT_END_TS, null as EVNT_DRTN_QTY from tripevent 
WHERE tripSummaryId IS NOT NULL""")

tripevent_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_event")
# display(tripevent_harmonize_df)

# COMMAND ----------

trippoint_df=parse_df.withColumn("telemetryPoints_explode",explode_outer(col("telemetryPoints"))).select("tripSummaryId","timeZoneOffset","device.*","telemetryPoints_explode.*","batch_nb","vehicle.*")
trippoint_df.createOrReplaceTempView("trippoint")

trippoint_df2=parse_df2.withColumn("telemetryPoints_explode",explode_outer(col("telemetrypoints"))).select("tripsummaryid","telemetryPoints_explode.*","batch_nb","vehicle.*")
trippoint_df2.createOrReplaceTempView("trippoint2")



# COMMAND ----------

trippoint_raw_df=spark.sql("""select cast(tripSummaryId as string),cast(engineRPM as string),cast(accelerometerData as string),cast(ambientTemperature as string),cast(barometericPressure as string),cast(coolantTemperature as string),cast(fuelLevel as string),cast(hdop as string),cast(utcDateTime as string),cast(degreesLatitude as string),cast(degreesLongitude as string),cast(speed as string),cast(headingdegrees as string),cast(acceleration as string),null as Accel_Longitudinal,null as Accel_Lateral,null as Accel_Vertical,"IMS_SM_5X" as SourceSystem,
cast(timeZoneOffset as string),
cast(deviceSerialNumber as string),
cast(deviceIdentifier as string),
enrolledVin,
detectedVin,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date
 from trippoint
WHERE tripSummaryId IS NOT NULL""")

trippoint_raw_df.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.telemetryPoints")
# display(trippoint_raw_df)

# COMMAND ----------

trippoint_harmonize_df=spark.sql("""select  cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_POINT_ID) from dhf_iot_harmonized_prod.trip_point),0) as BIGINT) as TRIP_POINT_ID,cast(acceleration as decimal(18,5)) as ACLRTN_RT, cast(ambientTemperature as decimal(15,6)) as AMBNT_TMPRTR_QTY, cast(barometericPressure as decimal(15,6)) as BRMTRC_PRESSR_QTY, cast(coolantTemperature as decimal(15,6)) as COOLNT_TMPRTR_QTY, cast(engineRPM as decimal(18,5)) as ENGIN_RPM_RT, cast(fuelLevel as decimal(15,6)) as FUEL_LVL_QTY, cast(headingDegrees as decimal(15,6)) as HEADNG_DEG_QTY, coalesce(cast(utcDateTime as TIMESTAMP), to_timestamp("9999-12-31")) as UTC_TS, cast(speed as decimal(18,10)) as SPD_RT, cast(accelerometerData as string) as ACLRTMTR_DATA_RT, cast(degreesLatitude as decimal(18,10)) as LAT_NB, cast(degreesLongitude as decimal(18,10)) as LNGTD_NB,  tripSummaryId AS TRIP_SMRY_KEY, cast(hdop as decimal(18,10)) as HDOP_QTY,coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin)) AS DEVC_KEY, cast(timeZoneOffset as decimal(10,2)) as TIME_ZONE_OFFST_NB, coalesce(enrolledVin,detectedVin) AS ENRLD_VIN_NB, coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS, current_timestamp() AS ETL_ROW_EFF_DTS, 
current_timestamp() as ETL_LAST_UPDT_DTS from trippoint
WHERE tripSummaryId IS NOT NULL""")

trippoint_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_point")
# display(trippoint_harmonize_df)

# COMMAND ----------

trippoint_raw_df2=spark.sql("""select cast(tripSummaryId as string),cast(engineRPM as string),cast(accelerometerData as string),cast(ambientTemperature as string),cast(barometericPressure as string),cast(coolantTemperature as string),cast(fuelLevel as string),cast(hdop as string),cast(utcDateTime as string),cast(degreesLatitude as string),cast(degreesLongitude as string),cast(speed as string),cast(headingdegrees as string),cast(acceleration as string),null as Accel_Longitudinal,null as Accel_Lateral,null as Accel_Vertical,"IMS_SM_5X" as SourceSystem,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date
 from trippoint2
WHERE tripSummaryId IS NOT NULL""")

trippoint_raw_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.telemetryPoints")
# display(trippoint_raw_df2)

# COMMAND ----------

trippoint_harmonize_df2=spark.sql("""select  cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_POINT_ID) from dhf_iot_harmonized_prod.trip_point),0) as BIGINT) as TRIP_POINT_ID,cast(acceleration as decimal(18,5)) as ACLRTN_RT, cast(ambientTemperature as decimal(15,6)) as AMBNT_TMPRTR_QTY, cast(barometericPressure as decimal(15,6)) as BRMTRC_PRESSR_QTY, cast(coolantTemperature as decimal(15,6)) as COOLNT_TMPRTR_QTY, cast(engineRPM as decimal(18,5)) as ENGIN_RPM_RT, cast(fuelLevel as decimal(15,6)) as FUEL_LVL_QTY, cast(headingDegrees as decimal(15,6)) as HEADNG_DEG_QTY, coalesce(cast(utcDateTime as TIMESTAMP), to_timestamp("9999-12-31")) as UTC_TS, cast(speed as decimal(18,10)) as SPD_RT, cast(accelerometerData as string) as ACLRTMTR_DATA_RT, cast(degreesLatitude as decimal(18,10)) as LAT_NB, cast(degreesLongitude as decimal(18,10)) as LNGTD_NB,  tripSummaryId AS TRIP_SMRY_KEY, cast(hdop as decimal(18,10)) as HDOP_QTY, coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS, current_timestamp() AS ETL_ROW_EFF_DTS, 
current_timestamp() as ETL_LAST_UPDT_DTS from trippoint2
WHERE tripSummaryId IS NOT NULL""")

trippoint_harmonize_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_point")
# display(trippoint_harmonize_df2)

# COMMAND ----------

scoring_main_df=parse_df.select("tripSummaryId", "scoring.*","batch_nb","vehicle.*").withColumn("individualComponentScores_explode",explode_outer(col("individualComponentScores")))

scoring_df=scoring_main_df.select("*","batch_nb","individualComponentScores_explode.*")
scoring_df.createOrReplaceTempView("scoringview")




# COMMAND ----------

scoring_raw_df=spark.sql("""select  cast(tripSummaryId as string),cast(scoreAlgorithmProvider as string),cast(scoreUnit as string),cast(overallScore as string),cast(component as string),cast(componentScore as string),"IMS_SM_5X" as SourceSystem,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date from scoringview where component is not null and componentScore is not null
and tripSummaryId IS NOT NULL""")

scoring_raw_df.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.scoring")
# display(scoring_raw_df)

# COMMAND ----------

scoring_harmonize_df=spark.sql("""select  cast(monotonically_increasing_id() +1 + coalesce((select max(SCORING_ID) from dhf_iot_harmonized_prod.SCORING),0) as BIGINT) as SCORING_ID,tripSummaryId AS TRIP_SMRY_KEY, scoreAlgorithmProvider as SCR_ALGRM_PRVDR_NM, scoreUnit as SCR_UNIT_CD, cast(overallScore as decimal(18,10))as OVRL_SCR_QTY, coalesce(component, "NOKEY") as INDV_CMPNT_SET_TP_VAL, cast(coalesce(componentScore ,0) as decimal(18,10)) as INDV_CMPNT_SET_SCR_QTY,coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS, current_timestamp() AS ETL_ROW_EFF_DTS, 
current_timestamp() as ETL_LAST_UPDT_DTS  from scoringview
where component is not null and componentScore is not null
and tripSummaryId IS NOT NULL""")

scoring_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.SCORING")
# display(scoring_harmonize_df)

# COMMAND ----------

histogramScoringIntervals_df=parse_df.withColumn("histogramScoringIntervals_explode",explode_outer(col("histogramScoringIntervals"))).select("tripSummaryId", "histogramScoringIntervals_explode.*","batch_nb","vehicle.*")


histogramScoringIntervals_df.createOrReplaceTempView("histogramScoringIntervalsview")


# COMMAND ----------

histogramScoringIntervals_raw_df=spark.sql("""select cast(tripSummaryId as string),cast(scoringComponent as string),cast(scoringSubComponent as string),cast(roadType as string),cast(thresholdLowerBound as string),cast(thresholdUpperBound as string),cast(scoringComponentUnit as string),cast(occurrences as string),cast(occurrenceUnit as string),"IMS_SM_5X" as SourceSystem,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date from histogramScoringIntervalsview where scoringComponent is not null
and tripSummaryId IS NOT NULL""")

histogramScoringIntervals_raw_df.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.histogramScoringIntervals")
# display(histogramScoringIntervals_raw_df)

# COMMAND ----------

histogramScoringIntervals_harmonize_df=spark.sql("""select  cast(monotonically_increasing_id() +1+ coalesce((select max(HISTOGRAM_SCORING_INTERVAL_ID) from dhf_iot_harmonized_prod.HISTOGRAM_SCORING_INTERVAL),0) as BIGINT) as HISTOGRAM_SCORING_INTERVAL_ID, tripSummaryId AS TRIP_SMRY_KEY, coalesce(scoringComponent, "NOKEY") as SCRG_CMPNT_TP_CD, scoringSubComponent as SCRG_SUB_CMPNT_TP_CD, roadType as ROAD_TP_DSC, cast(thresholdLowerBound as decimal(18,10)) as LOWER_BND_THRSHLD_QTY, cast(thresholdUpperBound as decimal(18,10)) as UPPER_BND_THRSHLD_QTY, scoringComponentUnit as SCRG_CMPNT_UNIT_CD, cast(occurrences as int) as OCRNC_CT, occurrenceUnit as OCRNC_UNIT_CD,coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS, current_timestamp() AS ETL_ROW_EFF_DTS,current_timestamp() as ETL_LAST_UPDT_DTS  from histogramScoringIntervalsview where scoringComponent is not null and tripSummaryId IS NOT NULL""")

histogramScoringIntervals_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.HISTOGRAM_SCORING_INTERVAL")
# display(histogramScoringIntervals_harmonize_df)

# COMMAND ----------

nonTripEvent_df=parse_evt_df.withColumn("externalReferences_explode",explode_outer(col("externalReferences"))).withColumn("telemetryEvents_explode",explode_outer(col("telemetryEvents"))).select("telemetrySetId","device.*","vehicle.*","externalReferences_explode.*","telemetryEvents_explode.*","batch_nb")


nonTripEvent_df.createOrReplaceTempView("nonTripEventview")


# COMMAND ----------

nonTripEvent_raw_df=spark.sql("""select cast(telemetrySetId as string),cast(degreesLatitude as string),cast(degreesLongitude as string),cast(headingDegrees as string),cast(telemetryEventType as string),cast(utcDateTime as string),cast(speed as string),cast(acceleration as string),cast(telemetryEventSeverityLevel as string),cast(enterpriseReferenceId as string),cast(enterpriseReferenceExtraInfo as string),cast(type as string),cast(deviceSerialNumber as string),cast(deviceIdentifier as string),cast(deviceIdentifierType as string),cast(deviceType as string),cast(enrolledVin as string),cast(detectedVin as string),"IMS_SM_5X" as SourceSystem,
current_timestamp() as db_load_time,
current_date() as db_load_date,
TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)) AS load_hour,
TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)) AS load_date from nonTripEventview
WHERE telemetrySetId IS NOT NULL""")

nonTripEvent_raw_df.write.format("delta").mode("append").saveAsTable("dhf_iot_ims_raw_prod.nontripevent")
# display(nonTripEvent_raw_df)

# COMMAND ----------

nonTripEvent_harmonize_df=spark.sql("""select  cast(monotonically_increasing_id() +1 + coalesce((select max(NON_TRIP_EVENT_ID) from dhf_iot_harmonized_prod.non_trip_event),0) as BIGINT) as NON_TRIP_EVENT_ID, coalesce(telemetrySetId, "NOKEY") as NON_TRIP_EVNT_KEY,case when coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin)) is null then "NOKEY" ELSE coalesce(deviceIdentifier,deviceSerialNumber,crc32(detectedvin)) END DEVC_KEY, cast(acceleration as decimal(18,5)) as ACLRTN_RT, cast(telemetryEventSeverityLevel as STRING) as EVNT_SVRTY_CD, coalesce(telemetryEventType, "NOKEY") AS EVNT_TP_CD, cast(headingDegrees as decimal(15,6)) as HEADNG_DEG_QTY, cast(speed as decimal(18,5)) as SPD_MPH_RT, coalesce(cast(utcDateTime as TIMESTAMP), to_timestamp("9999-12-31")) as UTC_TS, coalesce(enrolledVin,detectedVin) AS VEH_KEY, cast(degreesLatitude as decimal(18,10)) as LAT_NB, cast(degreesLongitude as decimal(18,10)) as LNGTD_NB,coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as LOAD_DT, 
"IMS_SM_5X" AS SRC_SYS_CD, 
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) as LOAD_HR_TS, current_timestamp() AS ETL_ROW_EFF_DTS, 
current_timestamp() as ETL_LAST_UPDT_DTS 
 from nonTripEventview
WHERE telemetrySetId IS NOT NULL""")

nonTripEvent_harmonize_df.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.non_trip_event")
# display(nonTripEvent_harmonize_df)
