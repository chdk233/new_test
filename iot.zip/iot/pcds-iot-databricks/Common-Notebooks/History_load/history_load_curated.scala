// Databricks notebook source
import spark.implicits._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import java.time.LocalDateTime
import org.apache.spark.sql.streaming.Trigger
import java.time.temporal.ChronoUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone
spark.conf.set("spark.sql.adaptive.enabled",true)
spark.conf.set("spark.databricks.io.cache.enabled", true)

// COMMAND ----------

// //smartmiles_trip_detail_second

// // val df=spark.read.format("delta").load("dbfs:/mnt/nw-pcdm-iot-dev-785562577411-read/smartmiles_trip_detail_second/")
// val df=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/smartmiles_trip_detail_second/").filter("batch_nb<202207200000")


// df.createOrReplaceTempView("smartmiles_trip_detail_second")

// val df2=spark.sql("""select 
// cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_DETAIL_SECONDS_ID) from dhf_iot_harmonized_prod.trip_detail_seconds),0) as BIGINT)  as TRIP_DETAIL_SECONDS_ID,
// cast(enrolled_vin_nb	as	string)	as	ENRLD_VIN_NB,
// cast(trip_summary_id	as	string)	as	TRIP_SMRY_KEY,
// cast(device_id	as	string)	as	DEVC_KEY,
// cast(position_ts	as	timestamp)	as	PSTN_TS,
// cast(position_offset_ts	as	timestamp)	as	PSTN_OFFST_TS,
// cast(time_zone_offset_nb	as	decimal(15,6))	as	TIME_ZONE_OFFST_NUM,
// cast(speed_mph_rt	as	decimal(18,10))	as	SPD_MPH_RT,
// cast(speed_kph_rt	as	decimal(18,10))	as	SPD_KPH_RT,
// cast(engine_rpm_rt	as	decimal(18,5))	as	ENGIN_RPM_RT,
// cast(mile_cn	as	decimal(18,10))	as	DISTNC_MPH,
// cast(kilometer_cn	as	decimal(18,10))	as	DISTNC_KPH,
// cast(fast_acceleration_cn	as	int)	as	FAST_ACLRTN_EVNT_COUNTR,
// cast(hard_brake_cn	as	int)	as	HARD_BRKE_COUNTR,
// cast(driving_second_cn	as	int)	as	DRVNG_SC_CNT,
// cast(idle_second_cn	as	int)	as	IDLE_SC_CNT,
// cast(stop_second_cn	as	int)	as	STOP_SC_CNT,
// cast(night_time_driving_second_cn	as	int)	as	NIGHT_TIME_DRVNG_SEC_CNT,
// cast(plausible_second_cn	as	int)	as	PLSBL_SC_CNT,
// cast(centroid_nb	as	int)	as	CNTRD_NUM,
// case when scrubbed_field_nb = '11001' then 'ASNRNS'
//      when scrubbed_field_nb = '10000' then 'NR'
//      when scrubbed_field_nb = '11000' then 'NRNS'
//      when scrubbed_field_nb = '1000' then 'NS'
//      when scrubbed_field_nb = '100' then 'AL'
//      when scrubbed_field_nb = '1001' then 'ASNRNS'
//      when scrubbed_field_nb = '10010' then 'NRSS'
//      when scrubbed_field_nb = '10' then 'SS'
//      when scrubbed_field_nb = '11100' then 'NRNSAL'
//      when scrubbed_field_nb = '110' then 'SSAL'
//      when scrubbed_field_nb = '1100' then 'NSAL'
//      when scrubbed_field_nb = '1101' then 'ASNSAL'
//      when scrubbed_field_nb = '10100' then 'NRAL'
//      when scrubbed_field_nb = '11101' then 'ASNRNSAL'
//      else '' end as SCRBD_FLD_DESC,
// cast(latitude_nb	as	decimal(24,16))	as	LAT_NB,
// cast(longitude_nb	as	decimal(24,16))	as	LNGTD_NB,
// case when source_cd='FMC' THEN 'FMC_SR'
//      when source_cd='TIMS' THEN 'TIMS_SR'
//      when source_cd='IMS' THEN 'IMS_SM_5X' END	SRC_SYS_CD,
// 0 as MSSNG_TOO_MANY_SEC_FLAG,
// current_timestamp() as ETL_ROW_EFF_DTS,
// current_timestamp() as ETL_LAST_UPDT_DTS,
// coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) AS LOAD_HR_TS,
// coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) AS LOAD_DT from smartmiles_trip_detail_second """)
// // display(df.filter("trip_summary_id='12de8316-d6b0-4094-bb0d-1ce06085829c'"))
// df2.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_detail_seconds")

// COMMAND ----------

//smartride_trip_detail_second

// val df3=spark.read.format("parquet").load("dbfs:/mnt/nw-pcdm-iot-dev-785562577411-read/smartride_tripdetail_seconds/")
val df3=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/smartride_tripdetail_seconds/").filter("batch>=202207200000 and batch<202208080000")


df3.createOrReplaceTempView("smartride_trip_detail_second")

val df4=spark.sql("""select 
cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_DETAIL_SECONDS_ID) from dhf_iot_harmonized_prod.trip_detail_seconds),0) as BIGINT)  as TRIP_DETAIL_SECONDS_ID,
cast(dataload_dt	as	timestamp) as	ETL_ROW_EFF_DTS,
cast(trip_nb	as	string) as	TRIP_SMRY_KEY,
cast(position_ts	as	timestamp) as	PSTN_TS,
cast(position_offset_ts	as	timestamp) as	PSTN_OFFST_TS,
cast(speed_mph	as	decimal(18,10)) as	SPD_MPH_RT,
cast(speed_kph	as	decimal(18,10)) as	SPD_KPH_RT,
cast(distance	as	decimal(18,10)) as	DISTNC_MPH,
cast(distance_kph	as	decimal(18,10)) as	DISTNC_KPH,
cast(nighttime_driving_ind	as	int) as	NIGHT_TIME_DRVNG_SEC_CNT,
cast(eventcounter_fa	as	int) as	FAST_ACLRTN_EVNT_COUNTR,
cast(eventcounter_hb	as	int) as	HARD_BRKE_COUNTR,
coalesce(cast(deviceserial_nb	as	string),"NOKEY") as	DEVC_KEY,
coalesce(enrolledvin_nb,detectedvin_nb) as	ENRLD_VIN_NB,
cast(tripzoneoffset_am	as	decimal(15,6)) as	TIME_ZONE_OFFST_NUM,
cast(enginerpm_qt	as	decimal(18,5)) as	ENGIN_RPM_RT,
cast(time_driving_ind	as	int) as	DRVNG_SC_CNT,
cast(time_idle_ind	as	int) as	IDLE_SC_CNT,
cast(plausible_ind	as	int) as	PLSBL_SC_CNT,
cast(centroid_nb	as	int) as	CNTRD_NUM,
case when scrubbed_fields = '11001' then 'ASNRNS'
     when scrubbed_fields = '10000' then 'NR'
     when scrubbed_fields = '11000' then 'NRNS'
     when scrubbed_fields = '1000' then 'NS'
     when scrubbed_fields = '100' then 'AL'
     when scrubbed_fields = '1001' then 'ASNRNS'
     when scrubbed_fields = '10010' then 'NRSS'
     when scrubbed_fields = '10' then 'SS'
     when scrubbed_fields = '11100' then 'NRNSAL'
     when scrubbed_fields = '110' then 'SSAL'
     when scrubbed_fields = '1100' then 'NSAL'
     when scrubbed_fields = '1101' then 'ASNSAL'
     when scrubbed_fields = '10100' then 'NRAL'
     when scrubbed_fields = '11101' then 'ASNRNSAL'
     else '' end as SCRBD_FLD_DESC,
cast(latitude_it	as	decimal(24,16)) as	LAT_NB,
cast(longitude_it	as	decimal(24,16)) as	LNGTD_NB,
cast(eventcounter_br	as	int) as	STOP_SC_CNT,
case when source_cd='OCTO' THEN 'OCTO_SR'
     when source_cd='IMS' THEN 'IMS_SR_4X' END	SRC_SYS_CD,
0 as	MSSNG_TOO_MANY_SEC_FLAG,
current_timestamp() as ETL_LAST_UPDT_DTS,
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch, 1, length(batch) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) AS LOAD_HR_TS,
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch, 1, length(batch) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) AS LOAD_DT from smartride_trip_detail_second
""")//.filter("LOAD_DT >='2021-01-08'")
// display(df4)
df4.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_detail_seconds")
// df3.count()

// COMMAND ----------

//smartride_garbage_tripdetail_second

val df5=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/smartride_garbage_tripdetail_seconds/").filter("batch>=202207200000 and batch<202208080000")

df5.createOrReplaceTempView("smartride_garbage_tripdetail_seconds1")

val df6=spark.sql("""select 
cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_DETAIL_SECONDS_ID) from dhf_iot_harmonized_prod.trip_detail_seconds),0) as BIGINT)  as TRIP_DETAIL_SECONDS_ID,
cast(dataload_dt	as	timestamp) as	ETL_ROW_EFF_DTS,
cast(trip_nb	as	string) as	TRIP_SMRY_KEY,
cast(position_ts	as	timestamp) as	PSTN_TS,
cast(position_offset_ts	as	timestamp) as	PSTN_OFFST_TS,
cast(speed_mph	as	decimal(18,10)) as	SPD_MPH_RT,
cast(speed_kph	as	decimal(18,10)) as	SPD_KPH_RT,
cast(distance	as	decimal(18,10)) as	DISTNC_MPH,
cast(distance_kph	as	decimal(18,10)) as	DISTNC_KPH,
cast(nighttime_driving_ind	as	int) as	NIGHT_TIME_DRVNG_SEC_CNT,
cast(eventcounter_fa	as	int) as	FAST_ACLRTN_EVNT_COUNTR,
cast(eventcounter_hb	as	int) as	HARD_BRKE_COUNTR,
COALESCE(cast(deviceserial_nb	as	string),"NOKEY") as	DEVC_KEY,
coalesce(enrolledvin_nb,detectedvin_nb) as	ENRLD_VIN_NB,
cast(tripzoneoffset_am	as	decimal(15,6)) as	TIME_ZONE_OFFST_NUM,
cast(enginerpm_qt	as	decimal(18,5)) as	ENGIN_RPM_RT,
cast(time_driving_ind	as	int) as	DRVNG_SC_CNT,
cast(time_idle_ind	as	int) as	IDLE_SC_CNT,
cast(plausible_ind	as	int) as	PLSBL_SC_CNT,
cast(centroid_nb	as	int) as	CNTRD_NUM,
case when scrubbed_fields = '11001' then 'ASNRNS'
     when scrubbed_fields = '10000' then 'NR'
     when scrubbed_fields = '11000' then 'NRNS'
     when scrubbed_fields = '1000' then 'NS'
     when scrubbed_fields = '100' then 'AL'
     when scrubbed_fields = '1001' then 'ASNRNS'
     when scrubbed_fields = '10010' then 'NRSS'
     when scrubbed_fields = '10' then 'SS'
     when scrubbed_fields = '11100' then 'NRNSAL'
     when scrubbed_fields = '110' then 'SSAL'
     when scrubbed_fields = '1100' then 'NSAL'
     when scrubbed_fields = '1101' then 'ASNSAL'
     when scrubbed_fields = '10100' then 'NRAL'
     when scrubbed_fields = '11101' then 'ASNRNSAL'
     else '' end as SCRBD_FLD_DESC,
cast(latitude_it	as	decimal(24,16)) as	LAT_NB,
cast(longitude_it	as	decimal(24,16)) as	LNGTD_NB,
cast(eventcounter_br	as	int) as	STOP_SC_CNT,
case when source_cd='OCTO' THEN 'OCTO_SR'
     when source_cd='IMS' THEN 'IMS_SR_4X' END	SRC_SYS_CD,
1 as	MSSNG_TOO_MANY_SEC_FLAG,
current_timestamp() as ETL_LAST_UPDT_DTS,
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch, 1, length(batch) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) AS LOAD_HR_TS,
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch, 1, length(batch) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) AS LOAD_DT from smartride_garbage_tripdetail_seconds1""")
// display(df6)
df6.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_detail_seconds")

// COMMAND ----------

// //smartmiles_garbage_trip_detail_second

// val df7=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/smartmiles_garbage_trip_detail_second/").filter("batch_nb<202207200000")

// df7.createOrReplaceTempView("smartmiles_garbage_trip_detail_second1")

// val df8=spark.sql("""select 
// cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_DETAIL_SECONDS_ID) from dhf_iot_harmonized_prod.trip_detail_seconds),0) as BIGINT)  as TRIP_DETAIL_SECONDS_ID,
// cast(enrolled_vin_nb	as	string)	as	ENRLD_VIN_NB,
// cast(trip_summary_id	as	string)	as	TRIP_SMRY_KEY,
// cast(device_id	as	string)	as	DEVC_KEY,
// cast(position_ts	as	timestamp)	as	PSTN_TS,
// cast(position_offset_ts	as	timestamp)	as	PSTN_OFFST_TS,
// cast(time_zone_offset_nb	as	decimal(15,6))	as	TIME_ZONE_OFFST_NUM,
// cast(speed_mph_rt	as	decimal(18,10))	as	SPD_MPH_RT,
// cast(speed_kph_rt	as	decimal(18,10))	as	SPD_KPH_RT,
// cast(engine_rpm_rt	as	decimal(18,5))	as	ENGIN_RPM_RT,
// cast(mile_cn	as	decimal(18,10))	as	DISTNC_MPH,
// cast(kilometer_cn	as	decimal(18,10))	as	DISTNC_KPH,
// cast(fast_acceleration_cn	as	int)	as	FAST_ACLRTN_EVNT_COUNTR,
// cast(hard_brake_cn	as	int)	as	HARD_BRKE_COUNTR,
// cast(driving_second_cn	as	int)	as	DRVNG_SC_CNT,
// cast(idle_second_cn	as	int)	as	IDLE_SC_CNT,
// cast(stop_second_cn	as	int)	as	STOP_SC_CNT,
// cast(night_time_driving_second_cn	as	int)	as	NIGHT_TIME_DRVNG_SEC_CNT,
// cast(plausible_second_cn	as	int)	as	PLSBL_SC_CNT,
// cast(centroid_nb	as	int)	as	CNTRD_NUM,
// case when scrubbed_field_nb = '11001' then 'ASNRNS'
//      when scrubbed_field_nb = '10000' then 'NR'
//      when scrubbed_field_nb = '11000' then 'NRNS'
//      when scrubbed_field_nb = '1000' then 'NS'
//      when scrubbed_field_nb = '100' then 'AL'
//      when scrubbed_field_nb = '1001' then 'ASNRNS'
//      when scrubbed_field_nb = '10010' then 'NRSS'
//      when scrubbed_field_nb = '10' then 'SS'
//      when scrubbed_field_nb = '11100' then 'NRNSAL'
//      when scrubbed_field_nb = '110' then 'SSAL'
//      when scrubbed_field_nb = '1100' then 'NSAL'
//      when scrubbed_field_nb = '1101' then 'ASNSAL'
//      when scrubbed_field_nb = '10100' then 'NRAL'
//      when scrubbed_field_nb = '11101' then 'ASNRNSAL'
//      else '' end as SCRBD_FLD_DESC,
// cast(latitude_nb	as	decimal(24,16))	as	LAT_NB,
// cast(longitude_nb	as	decimal(24,16))	as	LNGTD_NB,
// case when source_cd='FMC' THEN 'FMC_SR'
//      when source_cd='TIMS' THEN 'TIMS_SR'
//      when source_cd='IMS' THEN 'IMS_SM_5X' END	SRC_SYS_CD,
// 1 as MSSNG_TOO_MANY_SEC_FLAG,
// current_timestamp() as ETL_ROW_EFF_DTS,
// current_timestamp() as ETL_LAST_UPDT_DTS,
// coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) AS LOAD_HR_TS,
// coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) AS LOAD_DT from smartmiles_garbage_trip_detail_second1""")
// // display(df8)
// df8.write.format("delta").mode("append").saveAsTable("dhf_iot_harmonized_prod.trip_detail_seconds")

// COMMAND ----------

// // //smartmiles_device_status

// // val df=spark.read.format("delta").load("dbfs:/user/hive/warehouse/smartmiles_device_status")
// val smartmiles_device_statusdf=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/smartmiles_device_status")

// smartmiles_device_statusdf.createOrReplaceTempView("smartmiles_device_status1")

// val smartmiles_device_statusdf2=spark.sql("""select 
//  cast(monotonically_increasing_id() +1 + coalesce((select max(DEVICE_STATUS_ID) from dhf_iot_curated_prod.device_status),0) as BIGINT)   as DEVICE_STATUS_ID,
// cast(device_id	as	STRING) as	DEVC_KEY,
// cast(sr_pgm_instnc_id	as	BIGINT) as	PRGRM_INSTC_ID,
// cast(enrolled_vin_nb	as	STRING) as	ENRLD_VIN_NB,
// cast(connected_status_in	as	STRING) as	CNCTD_STTS_FLAG,
// cast(status_start_ts	as	TIMESTAMP) as	STTS_EFCTV_TS,
// cast(status_end_ts	as	TIMESTAMP) as	STTS_EXPRTN_TS,
// cast(last_device_activity_ts	as	TIMESTAMP) as	LAST_DEVC_ACTVTY_TS,
// cast(device_unavailable_in	as	STRING) as	DEVC_UNAVLBL_FLAG,
// "SMARTMILES_HISTORY" as SRC_SYS_CD,
// current_timestamp() as ETL_LAST_UPDT_DTS,
// current_timestamp() as ETL_ROW_EFF_DTS,
// date_trunc('hour', status_end_ts) as LOAD_HR_TS,
// TO_DATE(status_end_ts) AS LOAD_DT from smartmiles_device_status1
// """).filter("load_dt>='2022-07-20' and load_dt<2022-08-08")


// // display(smartmiles_device_statusdf2)
// smartmiles_device_statusdf2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.device_status")

// COMMAND ----------

// //smartride_devicestatus

// val df=spark.read.format("delta").load("dbfs:/user/hive/warehouse/smartride_device_status")
val smartride_devicestatusdf=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/devicestatus")

smartride_devicestatusdf.createOrReplaceTempView("smartride_devicestatus")

val smartride_devicestatusdf2=spark.sql("""select 
cast(monotonically_increasing_id() +1 + coalesce((select max(DEVICE_STATUS_ID) from dhf_iot_curated_prod.device_status),0) as BIGINT)   as DEVICE_STATUS_ID,
cast(sr_pgm_instnc_id	as	BIGINT) as	PRGRM_INSTC_ID,
COALESCE(cast(deviceserial_id	as	STRING),"NOKEY") as	DEVC_KEY,
cast(enrolledvin_nb	as	STRING) as	ENRLD_VIN_NB,
cast(status	as	STRING) as	CNCTD_STTS_FLAG,
cast(statusstart_ts	as	TIMESTAMP) as	STTS_EFCTV_TS,
cast(statusend_ts	as	TIMESTAMP) as	STTS_EXPRTN_TS,
cast(lastactivity_ts	as	TIMESTAMP) as	LAST_DEVC_ACTVTY_TS,
cast(loststatus_flag	as	STRING) as	DEVC_UNAVLBL_FLAG,
"SMARTRIDE_HISTORY" as SRC_SYS_CD,
current_timestamp() as ETL_LAST_UPDT_DTS,
current_timestamp() as ETL_ROW_EFF_DTS,
DATE_TRUNC("HOUR",statusend_ts) AS LOAD_HR_TS,
TO_DATE(statusend_ts) AS LOAD_DT from smartride_devicestatus """).filter("load_dt>='2022-07-20' and load_dt<'2022-08-08'")

// display(smartride_devicestatusdf2)
smartride_devicestatusdf2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.device_status")

// COMMAND ----------

// MAGIC %sql
// MAGIC select  ENRLD_VIN_NB, TRIP_SMRY_KEY, DEVC_KEY, UTC_TS as PSTN_TS, TIME_ZONE_OFFST_NB as TIME_ZONE_OFFST_NUM, SPD_RT as SPD_KPH_RT, ENGIN_RPM_RT, LAT_NB, LNGTD_NB, SRC_SYS_CD, LOAD_DT, LOAD_HR_TS from dhf_iot_harmonized_prod.TRIP_POINT where SRC_SYS_CD!='IMS_SR_4X'
// MAGIC union ALL
// MAGIC select  TS.VEH_KEY AS ENRLD_VIN_NB, TP.TRIP_SMRY_KEY, TS.DEVC_KEY, TP.UTC_TS as PSTN_TS, TS.TIME_ZONE_OFFST_NB as TIME_ZONE_OFFST_NUM, TP.SPD_RT as SPD_KPH_RT, TP.ENGIN_RPM_RT, TP.LAT_NB, TP.LNGTD_NB, TP.SRC_SYS_CD, TP.LOAD_DT, TP.LOAD_HR_TS from dhf_iot_harmonized_prod.TRIP_POINT TP inner join dhf_iot_harmonized_prod.TRIP_SUMMARY TS on TS.TRIP_SMRY_KEY = TP.TRIP_SMRY_KEY where TP.SRC_SYS_CD='IMS_SR_4X'

// COMMAND ----------

// //smartmiles_trip_detail

// val smartmiles_trip_detail_df=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/smartmiles_trip_detail").filter("batch_nb<202207200000")

// smartmiles_trip_detail_df.createOrReplaceTempView("smartmiles_trip_detail")

// val smartmiles_trip_detail_df_df2=spark.sql("""select 
// cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_DETAIL_ID) from dhf_iot_curated_prod.trip_detail),0) as BIGINT)   as TRIP_DETAIL_ID,
// cast(enrolled_vin_nb	as	STRING) as	  ENRLD_VIN_NB ,
// "NOKEY" as	  DEVC_KEY ,
// to_timestamp("9999-12-31") as	  PE_STRT_TS ,
// to_timestamp("9999-12-31") as	  PE_END_TS,
// cast(period_start_ts	as	TIMESTAMP) as	  PE_STRT_LCL_TS,
// cast(period_end_ts	as	TIMESTAMP) as	  PE_END_LCL_TS ,
// cast(mile_cn	as	DECIMAL(18,10)) as	  MILE_CT ,
// cast(adjusted_mile_cn	as	DECIMAL(15,10)) as	  ADJST_MILE_CT,
// cast(plausible_mile_cn	as	DECIMAL(15,10)) as	  PLSBL_MILE_CT ,
// cast(kilometer_cn	as	DECIMAL(18,10)) as	  KM_CT,
// case when DAYOFWEEK(period_end_ts)=1 and 00<=HOUR(period_end_ts) and HOUR(period_end_ts)<05 then CAST(kilometer_cn as decimal(15,6)) 
//      when DAYOFWEEK(period_end_ts)=7 and 00<=HOUR(period_end_ts) and HOUR(period_end_ts)<05 then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_1_SCR_QTY  ,
// case when DAYOFWEEK(period_end_ts)=1 and 05<=HOUR(period_end_ts) and HOUR(period_end_ts)<19 then CAST(kilometer_cn as decimal(15,6)) 
//      when DAYOFWEEK(period_end_ts)=7 and 05<=HOUR(period_end_ts) and HOUR(period_end_ts)<19 then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_2_SCR_QTY  ,
// case when DAYOFWEEK(period_end_ts)=1 and 19<=HOUR(period_end_ts) then CAST(kilometer_cn as decimal(15,6)) 
//      when DAYOFWEEK(period_end_ts)=7 and 19<=HOUR(period_end_ts) then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_3_SCR_QTY  ,
// case when DAYOFWEEK(period_end_ts)!=1 and DAYOFWEEK(period_end_ts)!=7 and 00<=HOUR(period_end_ts) and HOUR(period_end_ts)<05 then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_4_SCR_QTY  ,
// case when DAYOFWEEK(period_end_ts)!=1 and DAYOFWEEK(period_end_ts)!=7 and 05<=HOUR(period_end_ts) and HOUR(period_end_ts)<09 then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_5_SCR_QTY  ,
// case when DAYOFWEEK(period_end_ts)!=1 and DAYOFWEEK(period_end_ts)!=7 and 09<=HOUR(period_end_ts) and HOUR(period_end_ts)<16 then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_6_SCR_QTY  ,
// case when DAYOFWEEK(period_end_ts)!=1 and DAYOFWEEK(period_end_ts)!=7 and 16<=HOUR(period_end_ts) and HOUR(period_end_ts)<19 then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_7_SCR_QTY  ,
// case when DAYOFWEEK(period_end_ts)!=1 and DAYOFWEEK(period_end_ts)!=7 and 19<=HOUR(period_end_ts) then CAST(kilometer_cn as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_8_SCR_QTY  ,
// cast(night_time_driving_second_cn	as	INT) as	  NIGHT_TIME_DRVNG_SC_CT ,
// cast(fast_acceleration_cn	as	INT) as	  FAST_ACLRTN_CT ,
// cast(hard_brake_cn	as	INT) as	  HARD_BRKE_CT ,
// cast(driving_second_cn	as	INT) as	  DRVNG_SC_CT ,
// cast(idle_second_cn	as	INT) as	  IDLE_SC_CT ,
// cast(stop_second_cn	as	INT) as	  STOP_SC_CT ,
// cast(plausible_drive_second_cn	as	INT) as	  PLSBL_DRIV_SC_CT ,
// cast(plausible_idle_second_cn	as	BIGINT) as	  PLSBL_IDLE_SC_CT ,
// cast(idle_second_pc	as	DECIMAL(20,15)) as	  IDLE_TIME_RATIO ,
// cast(trip_report_json_tt	as	STRING) as	  TRIP_SC_JSON_TT ,
// cast(trip_summary_id	as	STRING) as	  TRIP_SMRY_KEY ,
// case when source_cd='FMC' THEN 'FMC_SR'
//      when source_cd='TIMS' THEN 'TIMS_SR'
//      when source_cd='IMS' THEN 'IMS_SM_5X' END	SRC_SYS_CD,
// current_timestamp() as ETL_ROW_EFF_DTS,
// current_timestamp() as ETL_LAST_UPDT_DTS,
// coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch_nb, 1, length(batch_nb) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) AS LOAD_HR_TS,
// coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch_nb, 1, length(batch_nb) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) AS LOAD_DT from smartmiles_trip_detail """)

// // display(smartmiles_trip_detail_df_df2)
// smartmiles_trip_detail_df_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.trip_detail")

// COMMAND ----------

//smartride_trip_details

val smartride_trip_details_df=spark.read.format("orc").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_db/smartride_trip_details").filter("batch>=202207200000 and batch<202208080000")

smartride_trip_details_df.createOrReplaceTempView("smartride_trip_detail")

val smartride_trip_details_df2=spark.sql("""select 
cast(monotonically_increasing_id() +1 + coalesce((select max(TRIP_DETAIL_ID) from dhf_iot_curated_prod.trip_detail),0) as BIGINT)   as TRIP_DETAIL_ID,
cast(enrolledvin_nb	as	STRING) as	  ENRLD_VIN_NB ,
"NOKEY" as	  DEVC_KEY ,
to_timestamp("9999-12-31") as	  PE_STRT_TS ,
to_timestamp("9999-12-31") as	  PE_END_TS,
cast(periodstart_ts	as	TIMESTAMP) as	  PE_STRT_LCL_TS,
cast(periodend_ts	as	TIMESTAMP) as	  PE_END_LCL_TS ,
cast(miles	as	DECIMAL(18,10)) as	  MILE_CT ,
cast(kilometers	as	DECIMAL(18,10)) as	  KM_CT,
case when DAYOFWEEK(periodend_ts)=1 and 00<=HOUR(periodend_ts) and HOUR(periodend_ts)<05 then CAST(kilometers as decimal(15,6)) 
     when DAYOFWEEK(periodend_ts)=7 and 00<=HOUR(periodend_ts) and HOUR(periodend_ts)<05 then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_1_SCR_QTY  ,
case when DAYOFWEEK(periodend_ts)=1 and 05<=HOUR(periodend_ts) and HOUR(periodend_ts)<19 then CAST(kilometers as decimal(15,6)) 
     when DAYOFWEEK(periodend_ts)=7 and 05<=HOUR(periodend_ts) and HOUR(periodend_ts)<19 then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_2_SCR_QTY  ,
case when DAYOFWEEK(periodend_ts)=1 and 19<=HOUR(periodend_ts) then CAST(kilometers as decimal(15,6)) 
     when DAYOFWEEK(periodend_ts)=7 and 19<=HOUR(periodend_ts) then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_3_SCR_QTY  ,
case when DAYOFWEEK(periodend_ts)!=1 and DAYOFWEEK(periodend_ts)!=7 and 00<=HOUR(periodend_ts) and HOUR(periodend_ts)<05 then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_4_SCR_QTY  ,
case when DAYOFWEEK(periodend_ts)!=1 and DAYOFWEEK(periodend_ts)!=7 and 05<=HOUR(periodend_ts) and HOUR(periodend_ts)<09 then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_5_SCR_QTY  ,
case when DAYOFWEEK(periodend_ts)!=1 and DAYOFWEEK(periodend_ts)!=7 and 09<=HOUR(periodend_ts) and HOUR(periodend_ts)<16 then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_6_SCR_QTY  ,
case when DAYOFWEEK(periodend_ts)!=1 and DAYOFWEEK(periodend_ts)!=7 and 16<=HOUR(periodend_ts) and HOUR(periodend_ts)<19 then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_7_SCR_QTY  ,
case when DAYOFWEEK(periodend_ts)!=1 and DAYOFWEEK(periodend_ts)!=7 and 19<=HOUR(periodend_ts) then CAST(kilometers as decimal(15,6)) else cast(0 as decimal(15,6)) end TIME_INTRV_8_SCR_QTY  ,
cast(night_time_driving_sec_ct	as	INT) as	  NIGHT_TIME_DRVNG_SC_CT ,
cast(fast_acceleration_ct	as	INT) as	  FAST_ACLRTN_CT ,
cast(hard_brake_ct	as	INT) as	  HARD_BRKE_CT ,
cast(drive_time_sec_ct	as	INT) as	  DRVNG_SC_CT ,
cast(idle_time_sec_ct	as	INT) as	  IDLE_SC_CT ,
cast(idle_time_ratio	as	DECIMAL(20,15)) as	  IDLE_TIME_RATIO ,
cast(trip_seconds_json	as	STRING) as	   TRIP_SC_JSON_TT,
cast(trip_nb	as	STRING) as	  TRIP_SMRY_KEY ,
case when source_cd='OCTO' THEN 'OCTO_SR'
   when source_cd='IMS' THEN 'IMS_SR_4X' END	SRC_SYS_CD,
current_timestamp() as ETL_ROW_EFF_DTS,
current_timestamp() as ETL_LAST_UPDT_DTS,
coalesce(TO_timestamp(CAST(UNIX_TIMESTAMP(concat(substring(batch, 1, length(batch) -2),"00"), 'yyyyMMddHHmm') AS TIMESTAMP)), to_timestamp("9999-12-31")) AS LOAD_HR_TS,
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(substring(batch, 1, length(batch) -4), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) AS LOAD_DT from smartride_trip_detail """)
// display(smartride_trip_details_df2)
smartride_trip_details_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.trip_detail")

// COMMAND ----------

// //smartmiles_daily_mileage

// val smartmiles_daily_mileage_df=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartmiles_daily_mileage").filter("load_dt> and load_dt<")

// smartmiles_daily_mileage_df.createOrReplaceTempView("smartmiles_daily_mileage_view")

// val smartmiles_daily_mileage_df2=spark.sql("""select 
// cast(monotonically_increasing_id() +1 + coalesce((select max(DAILY_MILEAGE_ID) from dhf_iot_curated_prod.DAILY_MILEAGE_HISTORY),0) as BIGINT)   as DAILY_MILEAGE_ID,
// current_timestamp() as ETL_ROW_EFF_DTS,
// current_timestamp() as ETL_LAST_UPDT_DTS,
// cast(	enrolled_vin_nb	as	STRING	) as	ENRLD_VIN_NB	,
// coalesce(cast(	mile_cn	as	BIGINT	),0) as	MILE_CT	,
// cast(	device_unavailable_in	as	INT	) as	DEVC_UNAVLBL_FL	,
// cast(	disconnected_status_in	as	INT	) as	DSCNCTD_STTS_FL	,
// cast(	trip_dt	as	DATE	) as	TRIP_DT	,
// "SMARTMILES_HISTORY" as SRC_SYS_CD,
// cast(load_dt	as	DATE) as	LOAD_DT,
// cast(load_dt	as	TIMESTAMP) as	LOAD_HR_TS
//  from smartmiles_daily_mileage_view """)

// // display(smartmiles_daily_mileage_df)
//  smartmiles_daily_mileage_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.DAILY_MILEAGE_HISTORY")

// COMMAND ----------

// //smartmiles_annual_mileage

// val smartmiles_annual_mileage_df=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartmiles_annual_mileage")//.filter("batch>=202101010000 and batch<202207200000")

// smartmiles_annual_mileage_df.createOrReplaceTempView("smartmiles_annual_mileage_view")

// val smartmiles_annual_mileage_df2=spark.sql("""select 
// cast(monotonically_increasing_id() +1 + coalesce((select max(CA_ANNUAL_MILG_SCR_ID) from dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY),0) as BIGINT)   as CA_ANNUAL_MILG_SCR_ID,
// current_timestamp() as ETL_ROW_EFF_DTS,
// current_timestamp() as ETL_LAST_UPDT_DTS,
// cast(sr_pgm_instnc_id	as	BIGINT) as	PRGRM_INSTC_ID,
// coalesce(cast(device_id	as	STRING),"NOKEY") as	DEVC_KEY,
// cast(enrolled_vin_nb	as	STRING) as	ENRLD_VIN_NB,
// cast(plcy_ratd_st_cd	as	STRING) as	PLCY_RT_ST_CD,
// cast(start_ts	as	TIMESTAMP) as	DEVC_FRST_TS,
// cast(end_ts	as	TIMESTAMP) as	DEVC_LAST_TS,
// cast(connected_day_cn	as	BIGINT) as	CNCTD_DY_CT,
// cast(device_connected_pc	as	DECIMAL(35 , 15)) as	DEVC_CNCTD_PCT,
// cast(device_disconnected_pc	as	DECIMAL(35 , 15)) as	DEVC_DSCNCTD_PCT,
// cast(plausible_speed_pcnt	as	DECIMAL(35 , 15)) as	PLSBL_SPD_PCT,
// cast(tier1_10avg	as	DECIMAL(10,0)) as	`TIER_1-10_AVG_CT`,
// cast(tier11_30avg	as	DECIMAL(10,0)) as	`TIER_11-30_AVG_CT`,
// cast(tier31_70avg	as	DECIMAL(10,0)) as	`TIER_31-70_AVG_CT`,
// cast(tier71_90avg	as	DECIMAL(10,0)) as	`TIER_71-90_AVG_CT`,
// cast(tier91_100avg	as	DECIMAL(10,0)) as	`TIER_91-100_AVG_CT`,
// cast(estimatedkilometers	as	DECIMAL(35 , 15)) as	ESTMT_MILES_DISTNC_CT,
// cast(estimatedmileage	as	DECIMAL(35 , 15)) as	ESTMT_KM_DISTNC_CT,
// "SMARTMILES_HISTORY" as SRC_SYS_CD,
// cast("9999-12-31" as date) as TRIP_STRT_DT,
// cast("9999-12-31" as date) as TRIP_END_DT,
// cast(load_date as date) as SCR_DT,
// cast(load_date	as	DATE) as	LOAD_DT,
// cast(load_date	as	TIMESTAMP) as	LOAD_HR_TS
//  from smartmiles_annual_mileage_view """)

// // display(smartmiles_annual_mileage_df2)
//  smartmiles_annual_mileage_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY")

// COMMAND ----------


// //smartmiles_annual_mileage_score

// val smartmiles_annual_mileage_score_df=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartmiles_annual_mileage_score").filter("score_date> and score_date<")

// smartmiles_annual_mileage_score_df.createOrReplaceTempView("smartmiles_annual_mileage_score_view")

// val smartmiles_annual_mileage_score_df2=spark.sql("""select 
// cast(monotonically_increasing_id() +1 + coalesce((select max(CA_ANNUAL_MILG_SCR_ID) from dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY),0) as BIGINT)   as CA_ANNUAL_MILG_SCR_ID,
// current_timestamp() as ETL_ROW_EFF_DTS,
// current_timestamp() as ETL_LAST_UPDT_DTS,
// coalesce(cast(	deviceserial_nb	as	STRING	),"NOKEY") as	DEVC_KEY	,
// cast(	policy_nb	as	STRING	) as	PLCY_NB	,
// coalesce(cast(	enrolledvin_nb	as	STRING	),"NOKEY") AS	ENRLD_VIN_NB	,
// coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(cast(score_dt as string), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as	SCR_DT	,
// coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(cast(tripstart_dt as string), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as	TRIP_STRT_DT	,
// coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(cast(tripend_dt as string), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as	TRIP_END_DT	,
// cast(	score_days	as	INT	) as	SCR_DAYS_CT	,
// cast(	percenttime_disconnected	as	DECIMAL(35 , 15)	) as	DSCNCTD_PCT	,
// cast(	score_2	as	INT	) as	SCR_2_QTY	,
// "NOKEY" AS PLCY_RT_ST_CD,
// cast("9999-12-31" as timestamp) as DEVC_FRST_TS,
// cast("9999-12-31" as timestamp) as DEVC_LAST_TS,
// "SMARTMILES_HISTORY" as SRC_SYS_CD,
// cast(score_date	as	DATE) as	LOAD_DT,
// cast(score_date	as	TIMESTAMP) as	LOAD_HR_TS
//  from smartmiles_annual_mileage_score_view """)

// // display(smartmiles_annual_mileage_score_df2)
//  smartmiles_annual_mileage_score_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY")

// COMMAND ----------

//smartride_annual_mileage

val smartride_annual_mileage_df=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartride_annual_mileage")//.filter("load_date> and load_date<")

smartride_annual_mileage_df.createOrReplaceTempView("smartride_annual_mileage_view")

val smartride_annual_mileage_df2=spark.sql("""select 
cast(monotonically_increasing_id() +1 + coalesce((select max(CA_ANNUAL_MILG_SCR_ID) from dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY),0) as BIGINT)   as CA_ANNUAL_MILG_SCR_ID,
current_timestamp() as ETL_ROW_EFF_DTS,
current_timestamp() as ETL_LAST_UPDT_DTS,
cast(	sr_pgm_instnc_id	as	BIGINT	) as	PRGRM_INSTC_ID	,
coalesce(cast(	deviceserial_id	as	STRING	),"NOKEY") as	DEVC_KEY	,
coalesce(cast(	enrolledvin_nb	as	STRING	),"NOKEY") as	ENRLD_VIN_NB	,
cast(	plcy_ratd_st_cd	as	STRING	) as	PLCY_RT_ST_CD	,
cast(	first_activity_date	as	TIMESTAMP	) as	DEVC_FRST_TS	,
cast(	last_activity_date	as	TIMESTAMP	) as	DEVC_LAST_TS	,
cast(	days_installed	as	BIGINT	) as	CNCTD_DY_CT	,
cast(	install_percentage	as	DECIMAL(35 , 15)	) as	DEVC_CNCTD_PCT	,
cast(	uninstall_percentage	as	DECIMAL(35 , 15)	) as	DEVC_DSCNCTD_PCT	,
cast(	plausible_speed_pcnt	as	DECIMAL(35 , 15)	) as	PLSBL_SPD_PCT	,
cast(	tier1_10avg	as	DECIMAL(10,0)	) as	`TIER_1-10_AVG_CT`	,
cast(	tier11_30avg	as	DECIMAL(10,0)	) as	`TIER_11-30_AVG_CT`	,
cast(	tier31_70avg	as	DECIMAL(10,0)	) as	`TIER_31-70_AVG_CT`	,
cast(	tier71_90avg	as	DECIMAL(10,0)	) as	`TIER_71-90_AVG_CT`	,
cast(	tier91_100avg	as	DECIMAL(10,0)	) as	`TIER_91-100_AVG_CT`	,
cast(	estimatedkilometers	as	DECIMAL(35 , 15)	) as	ESTMT_MILES_DISTNC_CT	,
cast(	estimatedmileage	as	DECIMAL(35 , 15)	) as	ESTMT_KM_DISTNC_CT	,
"SMARTRIDE_HISTORY" as SRC_SYS_CD,
cast("9999-12-31" as date) as TRIP_STRT_DT,
cast("9999-12-31" as date) as TRIP_END_DT,
cast(load_date as date) as SCR_DT,
cast(load_date	as	DATE) as	LOAD_DT,
cast(load_date	as	TIMESTAMP) as	LOAD_HR_TS
 from smartride_annual_mileage_view """).filter("load_dt>='2022-07-20' and load_dt<'2022-08-08'")

// display(smartride_annual_mileage_df2)
 smartride_annual_mileage_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY")

// COMMAND ----------


//smartride_annual_mileage_score

val smartride_annual_mileage_score_df=spark.read.format("parquet").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartride_annual_mileage_score")//.filter("score_date> and score_date<")

smartride_annual_mileage_score_df.createOrReplaceTempView("smartride_annual_mileage_score_view")

val smartride_annual_mileage_score_df2=spark.sql("""select 
cast(monotonically_increasing_id() +1 + coalesce((select max(CA_ANNUAL_MILG_SCR_ID) from dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY),0) as BIGINT)   as CA_ANNUAL_MILG_SCR_ID,
current_timestamp() as ETL_ROW_EFF_DTS,
current_timestamp() as ETL_LAST_UPDT_DTS,
coalesce(cast(	deviceserial_nb	as	STRING	),"NOKEY") as	DEVC_KEY	,
cast(	policy_nb	as	STRING	) as	PLCY_NB	,
coalesce(cast(	enrolledvin_nb	as	STRING	),"NOKEY") AS	ENRLD_VIN_NB	,
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(cast(score_dt as string), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as	SCR_DT	,
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(cast(tripstart_dt as string), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as	TRIP_STRT_DT	,
coalesce(TO_DATE(CAST(UNIX_TIMESTAMP(cast(tripend_dt as string), 'yyyyMMdd') AS TIMESTAMP)), to_date("9999-12-31")) as	TRIP_END_DT	,
cast(	score_days	as	INT	) as	SCR_DAYS_CT	,
cast(	percenttime_disconnected	as	DECIMAL(35 , 15)	) as	DSCNCTD_PCT	,
cast(	score_2	as	INT	) as	SCR_2_QTY	,
"NOKEY" AS PLCY_RT_ST_CD,
cast("9999-12-31" as timestamp) as DEVC_FRST_TS,
cast("9999-12-31" as timestamp) as DEVC_LAST_TS,
"SMARTRIDE_HISTORY" as SRC_SYS_CD,
cast(score_date	as	DATE) as	LOAD_DT,
cast(score_date	as	TIMESTAMP) as	LOAD_HR_TS
 from smartride_annual_mileage_score_view """).filter("load_dt>='2022-07-20' and load_dt<'2022-08-08'")

// display(smartride_annual_mileage_score_df2)
 smartride_annual_mileage_score_df2.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_HISTORY")

// COMMAND ----------

// val smartmiles_ca_annual_mileage_score_filedf=spark.read.format("text").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartmiles_ca_annual_mileage_score_file")
// smartmiles_ca_annual_mileage_score_filedf.write.format("delta").mode("append").saveAsTable("dhf_iot_curated_prod.CA_ANNUAL_MILEAGE_SCORING_EXTRACT_FILE_HISTORY")
// display(smartmiles_ca_annual_mileage_score_filedf)

// COMMAND ----------

// val smartmiles_daily_scoring_export_df=spark.read.format("text").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartmiles_daily_scoring_export")
// smartmiles_daily_scoring_export_df.write.format("delta").mode("overWrite").saveAsTable("dhf_iot_curated_prod.extracts_dailyscoring_hitsory")
// display(smartmiles_daily_scoring_export_df)

// COMMAND ----------

val smartride_scoring_daily_file_df=spark.read.format("text").load("dbfs:/mnt/dw-telematics-prod-read/warehouse/telematics_provide_db/smartride_scoring_daily_file")
smartride_scoring_daily_file_df.write.format("delta").mode("overWrite").saveAsTable("dhf_iot_curated_prod.extracts_dailyscoring_hitsory")
// display(smartride_scoring_daily_file_df)

// COMMAND ----------

// TO UPDATE TRIP_DETAIL
// COL: PE_STRT_TS,PE_END_TS,devc_key


val df_ts=spark.sql("select TRIP_SMRY_KEY,min(PSTN_TS) as PE_STRT_TS,max(PSTN_TS) as PE_END_TS,max(devc_key) as devc_key,max(ENRLD_VIN_NB) as ENRLD_VIN_NB,max(src_sys_cd) as src_sys_cd from dhf_iot_harmonized_prod.trip_detail_seconds where load_dt>='2022-07-20' and load_dt<'2022-08-08' group by TRIP_SMRY_KEY,SRC_SYS_CD")
df_ts.createOrReplaceTempView("table_ts")

spark.sql("""merge into dhf_iot_curated_prod.trip_detail a
                using table_ts b on a.TRIP_SMRY_KEY=b.TRIP_SMRY_KEY and a.src_sys_cd=b.src_sys_cd and a.load_dt>='2022-07-20' and a.load_dt<'2022-08-08'
                when matched then update set a.PE_STRT_TS=b.PE_STRT_TS , a.PE_END_TS=b.PE_END_TS,a.devc_key=b.devc_key""")

// COMMAND ----------

// TO UPDATE TRIP_DETAIL
// COL: PLSBL_MILE_CT,STOP_SC_CT,PLSBL_DRIV_SC_CT

val df_ct=spark.sql("select TRIP_SMRY_KEY,sum(DISTNC_MPH) as PLSBL_MILE_CT,sum(STOP_SC_CNT) as STOP_SC_CT,sum(DRVNG_SC_CNT) as PLSBL_DRIV_SC_CT,max(src_sys_cd) as src_sys_cd from dhf_iot_harmonized_prod.trip_detail_seconds where PLSBL_SC_CNT=1 and src_sys_cd ='IMS_SR_4X' and   load_dt>='2022-07-20' and load_dt<'2022-08-08' group by TRIP_SMRY_KEY")
df_ct.createOrReplaceTempView("table_ct")
spark.sql("""merge into dhf_iot_curated_prod.trip_detail a
                using table_ct b on a.TRIP_SMRY_KEY=b.TRIP_SMRY_KEY and a.src_sys_cd=b.src_sys_cd and a.load_dt>='2022-07-20' and a.load_dt<'2022-08-08'
                when matched then update set a.PLSBL_MILE_CT=b.PLSBL_MILE_CT , a.STOP_SC_CT=b.STOP_SC_CT,a.PLSBL_DRIV_SC_CT=b.PLSBL_DRIV_SC_CT""")
				

// COMMAND ----------

// TO UPDATE TRIP_DETAIL
// COL: PLSBL_MILE_CT,STOP_SC_CT,PLSBL_DRIV_SC_CT
val df_ct_0=spark.sql("select TRIP_SMRY_KEY,max(PLSBL_SC_CNT) as PLSBL_SC_CNT from dhf_iot_harmonized_prod.trip_detail_seconds where PLSBL_SC_CNT!=1 and src_sys_cd ='IMS_SR_4X' and   load_dt>='2022-07-20' and load_dt<'2022-08-08' group by TRIP_SMRY_KEY")
df_ct_0.createOrReplaceTempView("table_ct_0")
spark.sql("""merge into dhf_iot_curated_prod.trip_detail a
                using table_ct_0 b on a.TRIP_SMRY_KEY=b.TRIP_SMRY_KEY and a.PLSBL_MILE_CT is null and a.STOP_SC_CT is null and a.PLSBL_DRIV_SC_CT is null and a.load_dt>='2022-07-20' and a.load_dt<'2022-08-08'
                when matched then update set a.PLSBL_MILE_CT=0 , a.STOP_SC_CT=0,a.PLSBL_DRIV_SC_CT=0""")

// COMMAND ----------

// TO UPDATE TRIP_DETAIL
// COL: PLSBL_IDLE_SC_CT

val df_idl=spark.sql("select TRIP_SMRY_KEY,count(IDLE_SC_CNT) as PLSBL_IDLE_SC_CT from dhf_iot_harmonized_prod.trip_detail_seconds where IDLE_SC_CNT=1 and DRVNG_SC_CNT=1 and src_sys_cd ='IMS_SR_4X' and   load_dt>='2022-07-20' and load_dt<'2022-08-08'  group by TRIP_SMRY_KEY")
df_idl.createOrReplaceTempView("table_idl")
spark.sql("""merge into dhf_iot_curated_prod.trip_detail a
                using table_idl b on a.TRIP_SMRY_KEY=b.TRIP_SMRY_KEY and a.load_dt>='2022-07-20' and a.load_dt<'2022-08-08'
                when matched then update set a.PLSBL_IDLE_SC_CT=b.PLSBL_IDLE_SC_CT """)


// COMMAND ----------

// TO UPDATE TRIP_DETAIL
// COL: PLSBL_IDLE_SC_CT			
val df_idl_0=spark.sql("select TRIP_SMRY_KEY from dhf_iot_harmonized_prod.trip_detail_seconds where  src_sys_cd ='IMS_SR_4X' and   load_dt>='2022-07-20' and load_dt<'2022-08-08' group by TRIP_SMRY_KEY")
df_idl_0.createOrReplaceTempView("table_idl_0")
spark.sql("""merge into dhf_iot_curated_prod.trip_detail a
                using table_idl_0 b on a.TRIP_SMRY_KEY=b.TRIP_SMRY_KEY and a.PLSBL_IDLE_SC_CT is null and a.load_dt>='2022-07-20' and a.load_dt<'2022-08-08'
                when matched then update set a.PLSBL_IDLE_SC_CT=0 """)

// COMMAND ----------

// TO UPDATE TRIP_DETAIL
// COL: adjst_mile_ct
val df=spark.sql("""select TRIP_SMRY_KEY,TRIP_DETAIL_ID,case when TIME_INTRV_1_SCR_QTY!=0.000000 then (MILE_CT*2.7) else 0 end interval1_mi,
                           case when TIME_INTRV_2_SCR_QTY!=0.000000 then MILE_CT else 0 end interval2_mi,
                           case when TIME_INTRV_3_SCR_QTY!=0.000000 then (MILE_CT*1.1) else 0 end interval3_mi,
                           case when TIME_INTRV_4_SCR_QTY!=0.000000 then (MILE_CT*1.6) else 0 end interval4_mi,
                           case when TIME_INTRV_5_SCR_QTY!=0.000000 then (MILE_CT*1.1) else 0 end interval5_mi,
                           case when TIME_INTRV_6_SCR_QTY!=0.000000 then (MILE_CT*1.2) else 0 end interval6_mi,
                           case when TIME_INTRV_7_SCR_QTY!=0.000000 then (MILE_CT*1.4) else 0 end interval7_mi,
                           case when TIME_INTRV_8_SCR_QTY!=0.000000 then (MILE_CT*1.3) else 0 end interval8_mi
                         
                            from dhf_iot_CURATed_prod.trip_detail where src_sys_cd in ("IMS_SR_4X","OCTO_SR") and load_dt>='2022-07-20' and load_dt<'2022-08-08'""").selectExpr("TRIP_SMRY_KEY","TRIP_DETAIL_ID","interval1_mi+interval2_mi+interval3_mi+interval4_mi+interval5_mi+interval6_mi+interval7_mi+interval8_mi as adjst_mile_ct")
df.createOrReplaceTempView("table")
spark.sql("""merge into dhf_iot_curated_prod.trip_detail a
                using table b on a.TRIP_SMRY_KEY=b.TRIP_SMRY_KEY and a.TRIP_DETAIL_ID = b.TRIP_DETAIL_ID and a.load_dt>='2022-07-20' and a.load_dt<'2022-08-08'
                when matched then update set a.adjst_mile_ct=b.adjst_mile_ct""")

// COMMAND ----------

// TO UPDATE device_status
// COL: src_sys_cd
spark.sql("""merge into dhf_iot_curated_prod.device_status a using dhf_iot_harmonized_prod.vehicle b on a.ENRLD_VIN_NB=b.ENRLD_VIN_NB and a.load_dt>='2022-07-20' and a.load_dt<'2022-08-08'
         when matched update set a.src_sys_cd=b.src_sys_cd """)

// COMMAND ----------

// MAGIC %sql
// MAGIC MERGE into dhf_iot_curated_prod.trip_detail as target
// MAGIC USING (
// MAGIC       with t as(
// MAGIC       select *,row_number() over (partition by TRIP_SMRY_KEY order by TRIP_DETAIL_ID desc ) as dup from  dhf_iot_curated_prod.trip_detail where src_sys_cd='IMS_SR_4X' and load_dt>='2022-07-20' and load_dt<'2022-08-08'
// MAGIC       )
// MAGIC       select * from t where dup > 1
// MAGIC  
// MAGIC ) 
// MAGIC as source
// MAGIC ON source.TRIP_SMRY_KEY=target.TRIP_SMRY_KEY and source.TRIP_DETAIL_ID=target.TRIP_DETAIL_ID and source.SRC_SYS_CD=target.SRC_SYS_CD and source.load_dt=target.load_dt
// MAGIC WHEN MATCHED THEN DELETE	

// COMMAND ----------

// %sql
// MERGE into dhf_iot_harmonized_prod.trip_detail_seconds as target
// USING (
//       with t as(
//       select *,row_number() over (partition by TRIP_SMRY_KEy,ENRLD_VIN_NB,PSTN_TS order by TRIP_DETAIL_SECONDS_ID desc ) as dup from  dhf_iot_harmonized_prod.trip_detail_seconds where src_sys_cd='FMC_SR'
//       )
//       select * from t where dup > 1
 
// ) 
// as source
// ON source.TRIP_SMRY_KEY=target.TRIP_SMRY_KEY and source.ENRLD_VIN_NB=target.ENRLD_VIN_NB and source.PSTN_TS=target.PSTN_TS and source.TRIP_DETAIL_SECONDS_ID=target.TRIP_DETAIL_SECONDS_ID 
// WHEN MATCHED THEN DELETE

// COMMAND ----------

// %sql
// MERGE into dhf_iot_harmonized_prod.trip_detail_seconds as target
// USING (
//       with t as(
//       select *,row_number() over (partition by TRIP_SMRY_KEy,ENRLD_VIN_NB,PSTN_TS order by TRIP_DETAIL_SECONDS_ID desc ) as dup from  dhf_iot_harmonized_prod.trip_detail_seconds where src_sys_cd='TIMS_SR'
//       )
//       select * from t where dup > 1
 
// ) 
// as source
// ON source.TRIP_SMRY_KEY=target.TRIP_SMRY_KEY and source.ENRLD_VIN_NB=target.ENRLD_VIN_NB and source.PSTN_TS=target.PSTN_TS and source.TRIP_DETAIL_SECONDS_ID=target.TRIP_DETAIL_SECONDS_ID 
// WHEN MATCHED THEN DELETE

// COMMAND ----------

// %sql
// MERGE into dhf_iot_harmonized_prod.trip_detail_seconds as target
// USING (
//       with t as(
//       select *,row_number() over (partition by TRIP_SMRY_KEy,ENRLD_VIN_NB,PSTN_TS order by TRIP_DETAIL_SECONDS_ID desc ) as dup from  dhf_iot_harmonized_prod.trip_detail_seconds where src_sys_cd='IMS_SM_5X'
//       )
//       select * from t where dup > 1
 
// ) 
// as source
// ON source.TRIP_SMRY_KEY=target.TRIP_SMRY_KEY and source.ENRLD_VIN_NB=target.ENRLD_VIN_NB and source.PSTN_TS=target.PSTN_TS and source.TRIP_DETAIL_SECONDS_ID=target.TRIP_DETAIL_SECONDS_ID 
// WHEN MATCHED THEN DELETE

// COMMAND ----------

// MAGIC %sql
// MAGIC MERGE into dhf_iot_harmonized_prod.trip_detail_seconds as target
// MAGIC USING (
// MAGIC       with t as(
// MAGIC       select *,row_number() over (partition by TRIP_SMRY_KEy,ENRLD_VIN_NB,PSTN_TS order by TRIP_DETAIL_SECONDS_ID desc ) as dup from  dhf_iot_harmonized_prod.trip_detail_seconds where src_sys_cd='IMS_SR_4X' and load_dt>='2022-07-20' and load_dt<'2022-08-08'
// MAGIC       )
// MAGIC       select * from t where dup > 1
// MAGIC  
// MAGIC ) 
// MAGIC as source
// MAGIC ON source.TRIP_SMRY_KEY=target.TRIP_SMRY_KEY and source.ENRLD_VIN_NB=target.ENRLD_VIN_NB and source.PSTN_TS=target.PSTN_TS and source.TRIP_DETAIL_SECONDS_ID=target.TRIP_DETAIL_SECONDS_ID 
// MAGIC WHEN MATCHED THEN DELETE
