// Databricks notebook source
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types._
import java.time.LocalDateTime
import scala.collection.mutable.ListBuffer
import scala.util.{Try, Success, Failure} 
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.streaming.StreamingQueryListener._
import scala.util.parsing.json._
import java.time
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit;
import java.io.{
  InputStream,
  ByteArrayInputStream,
  BufferedInputStream
}
import java.sql.Timestamp
import org.apache.commons.compress.compressors.{
  CompressorInputStream,
  CompressorStreamFactory
}
import org.apache.commons.compress.archivers.{
  ArchiveInputStream,
  ArchiveStreamFactory,
  ArchiveEntry
}
import org.apache.commons.io.input.CloseShieldInputStream
import org.apache.commons.io.IOUtils
import org.apache.spark.sql.expressions.Window
import java.time.{ZonedDateTime, ZoneId}
import java.time.format.DateTimeFormatter

spark.conf.set("spark.sql.files.ignoreCorruptFiles", "true")   
spark.conf.set("spark.sql.files.ignoreMissingFiles", "true")


val deltadatabase = dbutils.widgets.get("deltadatabase").toString
val deltadatabase_path = dbutils.widgets.get("deltadatabase_path").toString
val harmonizeddb = dbutils.widgets.get("harmonizeddb").toString
val job_run_log = dbutils.widgets.get("job_run_log").toString
val job_run_log_path = dbutils.widgets.get("job_run_log_path").toString
val checkpointLocation = dbutils.widgets.get("checkpointLocation").toString
val kafkaBootStrapServers = dbutils.widgets.get("kafkaBootStrapServers").toString
val truststoreLocation = dbutils.widgets.get("truststoreLocation").toString
val keystoreLocation = dbutils.widgets.get("keystoreLocation").toString
val topic = dbutils.widgets.get("topic").toString
val secret_scope = dbutils.widgets.get("secret_scope").toString
val secret_truststorePassword = dbutils.widgets.get("secret_truststorePassword").toString
val secret_keystorePassword = dbutils.widgets.get("secret_keystorePassword").toString
val secret_keyPassword = dbutils.widgets.get("secret_keyPassword").toString
val aws_accountid = dbutils.widgets.get("account_id").toString
val sns_arn = dbutils.widgets.get("sns_arn").toString
val subtraction_factor =  dbutils.widgets.get("subtraction_factor").toInt
val trip_detail_path = dbutils.widgets.get("trip_detail_path").toString

val date_to_run = ZonedDateTime.now(ZoneId.of("UTC")).minusDays(subtraction_factor)
val formatter = DateTimeFormatter.ofPattern("yyyyMMdd")
val daily_mileage_batch_nb = formatter format date_to_run
val trip_event_path = dbutils.widgets.get("trip_event_path").toString

val formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd")
val date_of_batch = formatter1 format date_to_run

spark.sql(s"set sns_arn = '${sns_arn}'")
spark.sql(s"set aws_accountid = '${aws_accountid}'")

// COMMAND ----------

val jobId=dbutils.notebook.getContext.tags.getOrElse("jobId","")
val runId=dbutils.notebook.getContext.tags.getOrElse("runId","")
val clusterId=dbutils.notebook.getContext.tags.getOrElse("clusterId","")

val truststorePassword     = dbutils.secrets.get(scope = secret_scope, key = secret_truststorePassword)
val keystorePassword       = dbutils.secrets.get(scope = secret_scope, key = secret_keystorePassword)
val keyPassword            = dbutils.secrets.get(scope = secret_scope, key = secret_keyPassword)

// COMMAND ----------

val df_td = spark.read.parquet(trip_detail_path)
df_td.createOrReplaceTempView("DM_smartmiles_trip_detail")


// COMMAND ----------

val trip_event_batch = trip_event_path+"batch_nb="+daily_mileage_batch_nb+"*"


val df_staging_te = spark.read.json(trip_event_batch)

val df4 = df_staging_te.select(col("vehicle").alias("veh"),col("telemetryEvents"),col("tripSummaryId")).withColumn("data1",explode($"telemetryEvents")).drop("telemetryEvents")

df4.createOrReplaceTempView("non_trip_events")

// COMMAND ----------

spark.sql(s"DROP TABLE IF EXISTS $deltadatabase.smartmiles_wk_program_details;")

// COMMAND ----------

spark.sql(s"DROP TABLE IF EXISTS $deltadatabase.smartmiles_program_details_Export;")

// COMMAND ----------

val res = spark.sql(s"""
(
select s5.VIN_NB as enrld_vin_nb
, s5.src_sys_cd as src_sys_cd
, cast(s5.mile_ct as decimal(18,5)) as mile_ct
, cast(s5.total_mile_ct as decimal(18,5)) total_mile_ct
, cast(s5.mileage_dt as date) as mileage_dt
, 'MILEAGE_UPDATE' as event_type
, NULL as event_ts
, from_unixtime(unix_timestamp(CURRENT_TIMESTAMP)) as process_ts
, CURRENT_DATE as LOAD_DT
,CURRENT_TIMESTAMP as Etl_Last_Updt_dts
,date_trunc('hour',CURRENT_TIMESTAMP) as LOAD_HR_TS

from
(
select 
  s4.VIN_NB
, CASE WHEN td2.source_cd = 'IMS' THEN 'IMS_SM_5X' ELSE td2.source_cd END as src_sys_cd
, s4.PRGRM_TERM_BEG_DT
, s4.PRGRM_TERM_END_DT
, s4.mileage_dt
, s4.mile_ct
, SUM(cast(td2.mile_cn as decimal(18,5))) as total_mile_ct

from

(
select distinct
  s3.VIN_NB as VIN_NB
,SUBSTR(td1.period_start_ts,0,10) as mileage_dt
, s3.PRGRM_TERM_BEG_DT
, s3.PRGRM_TERM_END_DT
,sum(td1.mile_cn) as mile_ct
from
(
Select distinct 
  s2.VIN_NB
, s2.PRGRM_TERM_BEG_DT as PRGRM_TERM_BEG_DT
, s2.PRGRM_TERM_END_DT as PRGRM_TERM_END_DT
, SUBSTR(td.period_start_ts, 0,10) as mileage_dt

from
(
select pe1.VIN_NB,PRGRM_TERM_BEG_DT,PRGRM_TERM_END_DT 
from ${harmonizeddb}.program_enrollment pe1
join

(select max(EVNT_SYS_TS) as max_time
,pe.VIN_NB
from ${harmonizeddb}.program_enrollment pe
where PRGRM_STTS_CD = 'Active'
and DATA_CLCTN_STTS = 'Active'
GROUP BY VIN_NB)pe2 
on pe1.VIN_NB = pe2.VIN_NB
AND pe1.EVNT_SYS_TS = max_time
)s2


JOIN  DM_smartmiles_trip_detail td 
ON td.Enrolled_Vin_Nb = s2.VIN_NB
and SUBSTR(td.period_start_ts,0,10) >= s2.PRGRM_TERM_BEG_DT
and SUBSTR(td.period_start_ts,0,10) <= s2.PRGRM_TERM_END_DT

WHERE batch_nb LIKE '$daily_mileage_batch_nb%'
and mile_cn is not null 
and mile_cn <> 0
GROUP BY
  s2.VIN_NB
, s2.PRGRM_TERM_BEG_DT
, s2.PRGRM_TERM_END_DT
, SUBSTR(td.period_start_ts, 0,10)
) s3

JOIN  DM_smartmiles_trip_detail td1 
ON td1.Enrolled_Vin_Nb = s3.VIN_NB
and SUBSTR(td1.period_start_ts,0,10) >= s3.PRGRM_TERM_BEG_DT
and SUBSTR(td1.period_start_ts,0,10) <= s3.PRGRM_TERM_END_DT
and SUBSTR(td1.period_start_ts,0,10) = s3.mileage_dt

GROUP BY 
  s3.VIN_NB
, s3.mileage_dt
, s3.PRGRM_TERM_BEG_DT
, s3.PRGRM_TERM_END_DT
,SUBSTR(td1.period_start_ts,0,10))s4

JOIN DM_smartmiles_trip_detail td2 
ON td2.Enrolled_Vin_Nb = s4.VIN_NB
and SUBSTR(td2.period_start_ts,0,10) >= s4.PRGRM_TERM_BEG_DT
and SUBSTR(td2.period_start_ts,0,10) <= s4.PRGRM_TERM_END_DT 

GROUP BY
  s4.VIN_NB
, CASE WHEN td2.source_cd = 'IMS' THEN 'IMS_SM_5X' ELSE td2.source_cd END
, s4.PRGRM_TERM_BEG_DT
, s4.PRGRM_TERM_END_DT
, s4.mileage_dt
, s4.mile_ct

)s5

ORDER BY enrld_vin_nb,mileage_dt
)

UNION

(
Select 
 ss2.VIN_NB as enrld_vin_nb
,'IMS_SM_5X' as src_sys_cd
,NULL as mile_ct
,NULL as total_mile_ct
,NULL as mileage_dt
,nte.data1.telemetryEventType as event_type
,from_unixtime(unix_timestamp(cast(nte.data1.utcDateTime as timestamp))) as event_ts
,from_unixtime(unix_timestamp(CURRENT_TIMESTAMP)) as process_ts
,CURRENT_DATE as LOAD_DT
,CURRENT_TIMESTAMP as Etl_Last_Updt_dts
,date_trunc('hour',CURRENT_TIMESTAMP) as LOAD_HR_TS

from
(
select ppe1.VIN_NB,PRGRM_TERM_BEG_DT,PRGRM_TERM_END_DT 
from ${harmonizeddb}.program_enrollment ppe1
join

(select max(EVNT_SYS_TS) as max_time
,ppe.VIN_NB
from ${harmonizeddb}.program_enrollment ppe
where PRGRM_STTS_CD = 'Active'
and DATA_CLCTN_STTS = 'Active'
GROUP BY VIN_NB)ppe2 
on ppe1.VIN_NB = ppe2.VIN_NB
AND ppe1.EVNT_SYS_TS = max_time
)ss2

JOIN non_trip_events nte
on nte.veh.EnrolledVin = ss2.VIN_NB
and nte.data1.utcDateTime >= ss2.PRGRM_TERM_BEG_DT
and nte.data1.utcDateTime <= ss2.PRGRM_TERM_END_DT

WHERE
nte.data1.telemetryEventType IN ('HEARTBEAT','DISCONNECT_EVENT','CONNECT_EVENT') 
AND nte.tripSummaryId is null  
ORDER BY enrld_vin_nb)
""")


res.write.format("delta").mode("overwrite").saveAsTable(s"$deltadatabase.smartmiles_wk_program_details")


// COMMAND ----------

spark.sql(s"""CREATE TABLE IF NOT EXISTS ${deltadatabase}.smartmiles_program_details_Export(
enrld_vin_nb string, 
event_type string,
mile_ct decimal(18,5), 
total_mile_ct decimal(18,5),
mileage_dt date,
event_ts string,
src_sys_cd string,
process_ts string,
LOAD_DT date);""")


// COMMAND ----------

spark.sql(s"""INSERT OVERWRITE TABLE ${deltadatabase}.smartmiles_program_details_Export
SELECT
enrld_vin_nb, 
event_type,
mile_ct, 
total_mile_ct,
mileage_dt,
event_ts,
src_sys_cd,
process_ts,
LOAD_DT
FROM ${deltadatabase}.smartmiles_wk_program_details where ((mileage_dt not between '2020-12-14' and '2021-01-08') and (mileage_dt not between '2022-04-24' and '2022-04-27') and (mileage_dt not between '2022-06-25' and '2022-06-27') and event_type = 'MILEAGE_UPDATE') or event_type IN('HEARTBEAT','CONNECT_EVENT','DISCONNECT_EVENT')
""")

// COMMAND ----------

val df_res = spark.sql(s"""
SELECT
enrld_vin_nb, 
event_type,
mile_ct, 
total_mile_ct,
mileage_dt,
event_ts,
src_sys_cd,
process_ts as Etl_Row_Eff_dts,
Etl_Last_Updt_dts,
LOAD_HR_TS,
LOAD_DT
FROM ${deltadatabase}.smartmiles_wk_program_details;""")

df_res.write.format("delta").mode("append").partitionBy("LOAD_DT").saveAsTable(s"$deltadatabase.smartmiles_program_details")


// COMMAND ----------

val finalDF = spark.sql(s"""select enrld_vin_nb, event_type,mile_ct,total_mile_ct,mileage_dt,event_ts,src_sys_cd,process_ts from ${deltadatabase}.smartmiles_program_details_Export""")



val finalDF1 = finalDF.withColumn("key",col("enrld_vin_nb")) .withColumn("program_details",expr("struct(enrld_vin_nb,event_type,mile_ct,total_mile_ct,mileage_dt,event_ts,src_sys_cd,process_ts)")).withColumn("value",expr("to_json(struct(program_details))")).selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")


finalDF1.write.format("kafka").option("kafka.bootstrap.servers", kafkaBootStrapServers).option("kafka.security.protocol","SSL").option("kafka.ssl.truststore.location",truststoreLocation).option("kafka.ssl.truststore.password",truststorePassword).option("kafka.ssl.keystore.location",keystoreLocation).option("kafka.ssl.keystore.password",keystorePassword).option("kafka.ssl.key.password", keyPassword).option("topic",topic).save()
