// Databricks notebook source
// DBTITLE 1,Import libraries
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import java.util.Date
import java.util.Properties
import scala.sys.process._
import java.sql.Timestamp
import java.time.LocalDate

// COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.dropdown("environment", "dev", Seq("dev", "test","prod"), "environment")
val environment=dbutils.widgets.get("environment").toString.toLowerCase

println("environment is "+environment)

// COMMAND ----------

// DBTITLE 1,Set Job level properties
val jobName = s"${environment}_IoTSmartMilesIMSRealtimeScoring_job"
val notebookPath= s"/Repos/cheenh1@nationwide.com/pcds-iot-${environment}/Curation/SmartMiles/dev/realtime_scoring/_iot_sm_ims_MFtoPCDS_dailyScoring"

val spark_version ="7.6.x-scala2.12"
val node_type_id ="i3.xlarge"
val driver_node_type_id ="i3.xlarge"
val num_workers="3"

var sns_arn                        = ""
var deltadatabase                  = ""
var deltadatabase_path             = ""
var job_run_log                    = ""
var job_run_log_path               = ""
var part_json_s3_file_loc          = s"" 
var scoring_file_path              = ""
var scoring_table                  = ""
var checkpointLocation             = s""
var maxFilesPerTrigger             = ""
var includeExistingFiles           = ""
var kafkaBootStrapServers          = ""
var truststoreLocation             = ""
var keystoreLocation               = ""
var schemaRegistryURL              = ""
var topic                          = ""
var starting_Offsets               = ""
var secret_scope                   = ""
var secret_truststorePassword      = ""
var secret_keystorePassword        = ""
var secret_keyPassword             = ""
var account_id                     = ""
var databricks_account_id          = ""
var databricks_instance_profile    = ""
var maxRetries                     = ""
var retry_interval                 = ""
var cron_job_expression            = ""
var schedule_timezone_id           = ""
var schedule_pause_status          = ""
var email_list_onFailure           = ""

if(environment.equals("dev")) {
  
    sns_arn                        = ""
    deltadatabase                  = "dhf_iot_curated_dev"
    deltadatabase_path             = "s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/"
    job_run_log                    = s"${deltadatabase}.job_run_log"
    job_run_log_path               = s"s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/job_run_log"

    part_json_s3_file_loc          = s"s3://pcds-databricks-common-786994105833/iot/kiran/realtimeScoring-kafka-MF-to-PCDS/"  
    scoring_file_path              = s"s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/realtime_scoring_to_pcds"
    scoring_table                  = s"${deltadatabase}.realtime_scoring_to_pcds"
    checkpointLocation             = s"s3a://pcds-databricks-common-786994105833/iot/raw/dev/smartMiles/IMS/checkpoints/mf-consume-checkpoint/"
    kafkaBootStrapServers          = "event-streaming-dev-kb.aws.e1.nwie.net:9092"
    truststoreLocation             = "/dbfs/FileStore/iottelematics/smsr/iot_dev_smsr_scoring_from_mf_consumer.jks"
    keystoreLocation               = "/dbfs/FileStore/iottelematics/smsr/iot_dev_smsr_scoring_from_mf_consumer.jks"
    topic                          = "business.artificial-intelligence.telematics.model.sm.sr.output.v1"
    secret_scope                   = "IoTTelematicsSmSrScoringFromMF_dev"
    secret_truststorePassword      = "iot_dev_smsr_scoring_from_mf_consumer"
    secret_keystorePassword        = "iot_dev_smsr_scoring_from_mf_consumer"
    secret_keyPassword             = "iot_dev_smsr_scoring_from_mf_consumer"    
    starting_Offsets               = "earliest"
    maxFilesPerTrigger             = "100"
    includeExistingFiles           = "false"
    account_id                     = "786994105833"
    databricks_account_id          = "741794010583"
    databricks_instance_profile    = "pcds-iot-telematics-devdw01-trustingrole"
    maxRetries                     = "0"
    retry_interval                 = "300000"
    cron_job_expression            = s""
    schedule_timezone_id           = s"America/New_York"
    schedule_pause_status          = "PAUSED"
    email_list_onFailure           = s"cheenh1@nationwide.com"
}
else if (environment.equals("test")){  
    sns_arn                        = ""
    deltadatabase                  = "dhf_iot_curated_dev"
    deltadatabase_path             = "s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/"
    job_run_log                    = s"${deltadatabase}.job_run_log"
    job_run_log_path               = s"s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/job_run_log"

    part_json_s3_file_loc          = s"s3://pcds-databricks-common-786994105833/iot/kiran/realtimeScoring-kafka-MF-to-PCDS/"  
    scoring_file_path              = s"s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/realtime_scoring_to_pcds"
    scoring_table                  = s"${deltadatabase}.realtime_scoring_to_pcds"
    checkpointLocation             = s"s3a://pcds-databricks-common-786994105833/iot/raw/dev/smartMiles/IMS/checkpoints/mf-consume-checkpoint/"
    kafkaBootStrapServers          = "event-streaming-dev-kb.aws.e1.nwie.net:9092"
    truststoreLocation             = "/dbfs/FileStore/iottelematics/smsr/iot_dev_smsr_scoring_from_mf_consumer.jks"
    keystoreLocation               = "/dbfs/FileStore/iottelematics/smsr/iot_dev_smsr_scoring_from_mf_consumer.jks"
    topic                          = "business.artificial-intelligence.telematics.model.sm.sr.output.v1"
    secret_scope                   = "IoTTelematicsSmSrScoringFromMF_dev"
    secret_truststorePassword      = "iot_dev_smsr_scoring_from_mf_consumer"
    secret_keystorePassword        = "iot_dev_smsr_scoring_from_mf_consumer"
    secret_keyPassword             = "iot_dev_smsr_scoring_from_mf_consumer"    
    starting_Offsets               = "earliest"
    maxFilesPerTrigger             = "100"
    includeExistingFiles           = "false"
    account_id                     = "786994105833"
    databricks_account_id          = "741794010583"
    databricks_instance_profile    = "pcds-iot-telematics-devdw01-trustingrole"
    maxRetries                     = "0"
    retry_interval                 = "300000"
    cron_job_expression            = s""
    schedule_timezone_id           = s"America/New_York"
    schedule_pause_status          = "PAUSED"
    email_list_onFailure           = s"cheenh1@nationwide.com"
}
else if (environment.equals("prod")){  
  
    sns_arn                        = ""
    deltadatabase                  = "dhf_iot_curated_dev"
    deltadatabase_path             = "s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/"
    job_run_log                    = s"${deltadatabase}.job_run_log"
    job_run_log_path               = s"s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/job_run_log"

    part_json_s3_file_loc          = s"s3://pcds-databricks-common-786994105833/iot/kiran/realtimeScoring-kafka-MF-to-PCDS/"  
    scoring_file_path              = s"s3://pcds-databricks-common-786994105833/iot/delta/curated/dhf_iot_curated_dev/realtime_scoring_to_pcds"
    scoring_table                  = s"${deltadatabase}.realtime_scoring_to_pcds"
    checkpointLocation             = s"s3a://pcds-databricks-common-786994105833/iot/raw/dev/smartMiles/IMS/checkpoints/mf-consume-checkpoint/"
    kafkaBootStrapServers          = "event-streaming-dev-kb.aws.e1.nwie.net:9092"
    truststoreLocation             = "/dbfs/FileStore/iottelematics/smsr/iot_dev_smsr_scoring_from_mf_consumer.jks"
    keystoreLocation               = "/dbfs/FileStore/iottelematics/smsr/iot_dev_smsr_scoring_from_mf_consumer.jks"
    topic                          = "business.artificial-intelligence.telematics.model.sm.sr.output.v1"
    secret_scope                   = "IoTTelematicsSmSrScoringFromMF_dev"
    secret_truststorePassword      = "iot_dev_smsr_scoring_from_mf_consumer"
    secret_keystorePassword        = "iot_dev_smsr_scoring_from_mf_consumer"
    secret_keyPassword             = "iot_dev_smsr_scoring_from_mf_consumer"    
    starting_Offsets               = "earliest"
    maxFilesPerTrigger             = "100"
    includeExistingFiles           = "false"
    account_id                     = "786994105833"
    databricks_account_id          = "741794010583"
    databricks_instance_profile    = "pcds-iot-telematics-devdw01-trustingrole"
    maxRetries                     = "0"
    retry_interval                 = "300000"
    cron_job_expression            = s""
    schedule_timezone_id           = s"America/New_York"
    schedule_pause_status          = "PAUSED"
    email_list_onFailure           = s"cheenh1@nationwide.com"
}

// COMMAND ----------

val crt_db_ddl=s"""
create database if not exists ${deltadatabase}
location "${deltadatabase_path}"
"""

val crt_tbl_ddl=s"""
create table if not exists ${job_run_log} (
job_id Long,
run_id Long,
cluster_id String,
job_type string,
created timestamp
)
using delta
location "${job_run_log_path}"
"""

spark.sql(crt_db_ddl)
spark.sql(crt_tbl_ddl)

// COMMAND ----------

// DBTITLE 1,Initialization global variable
val token              = dbutils.secrets.get(scope = "iot", key = "JOB_TOKEN")
val workspaceID        = dbutils.notebook.getContext.tags.getOrElse("orgId","none")
val dbhost             = dbutils.notebook.getContext.apiUrl.get
var jobExists: Boolean = false
var jobid: Long        = 17
val clusterId          = dbutils.notebook.getContext.tags.getOrElse("clusterId","none")

// COMMAND ----------

// DBTITLE 1,Define case class
case class JobCreationLogClass(job_id: Long,run_id: Long, cluster_id: String, job_type: String )

// COMMAND ----------

// DBTITLE 1,Method to validate jobid
def validateJobId(jobid: Long)  = {   
  
    val resp=Seq("curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/get?job_id=$jobid" ).!!    
    if(resp.contains("INVALID_PARAMETER_VALUE")) {
      val msg=s"""Invalid job ID in job_run_log table. Please correct/delete the job ID in job_run_log table and resubmit"""
      println(msg)     
      throw new Exception(msg)
    }
    else {
      println(s"Job id is valid")
      jobExists= true
    }
  
}

// COMMAND ----------

// DBTITLE 1,Method to check job status 
def checkIfRunningOrPendingStatus(jobid: Long): Boolean = { 
    val runningStateArray=spark.read.json(Seq(Seq(
                                "curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/runs/list?job_id=$jobid" ).!!).toDS)      
                                .select(explode($"runs"))
                                .select("col.state.life_cycle_state")
                                .filter("life_cycle_state ='RUNNING' OR life_cycle_state ='PENDING' ")
                                .distinct
                                .collect()

    if(runningStateArray.size >=1) {
      println(s"Job associated is already in either RUNNING or PENDING status")    
      return true
    }  
    else {
      println(s"The job is NOT in RUNNING or PENDING state. Run-now will be invoked")  
      return false
    }
}

// COMMAND ----------

// DBTITLE 1,Create job and run
def createJobAndRun() = {        
     val qry = s""" SELECT job_id FROM ${job_run_log} where job_type="realtime_scoring_to_pcds" ORDER BY cast(created as timestamp) desc limit 1 """
     val jobidArray = spark.sql(qry).as[Long].collect 
  
     if(jobidArray.size == 1){
          println(s"Job ID exists")
          jobid=jobidArray(0)
          validateJobId(jobid)
      } else {
             jobExists=false
             jobid=1
             println(s"Job ID does not exist. New job will be created")
     }
  
     val runningOrPendingStatus=if(jobExists) checkIfRunningOrPendingStatus(jobid) else false
 
     try{

            if(jobExists && !runningOrPendingStatus) { 
                println("Im here1")
                val jsonForExistingJobid = s"""
                    {
                       "job_id": ${jobid}
                    }
                  """

             val runid=spark.read.json(sc.parallelize(Seq( Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForExistingJobid",s"$dbhost/api/2.0/jobs/run-now" ).!! ))).select("run_id").as[Long].collect.head         
              
             println(s"runid is ${runid} for jobid ${jobid}")
              
              
             val logDF=Seq(JobCreationLogClass(jobid,runid,clusterId,"realtime_scoring_to_pcds")).toDF.withColumn("created", current_timestamp())            
             logDF.coalesce(1).write.option("path", job_run_log_path).format("delta").mode("append").saveAsTable(job_run_log)              
              

            } else if(!jobExists){
                  println("Im here2")
                  
                  val currentDate = LocalDate.now().toString
                  println(s"currentDate is ${currentDate}")
 

                  val jsonForNewJobApi = s"""
                  {
                  "name": "${jobName}",
                  "new_cluster": {
                          "spark_version": "${spark_version}",
                          "node_type_id": "${node_type_id}",
                          "driver_node_type_id": "${driver_node_type_id}",
                          "num_workers": ${num_workers},
                          "spark_conf": {  
                                  "spark.hadoop.fs.s3a.credentialsType" : "AssumeRole",
                                  "spark.hadoop.fs.s3.impl" : "com.databricks.s3a.S3AFileSystem",
                                  "spark.hadoop.fs.s3a.acl.default" : "BucketOwnerFullControl",
                                  "spark.hadoop.fs.s3n.impl" : "com.databricks.s3a.S3AFileSystem",
                                  "spark.hadoop.fs.s3a.stsAssumeRole.arn" : "arn:aws:iam::${account_id}:role/pcds-databricks-common-access",
                                  "spark.databricks.io.cache.enabled" : "true",
                                  "spark.hadoop.fs.s3a.canned.acl" : "BucketOwnerFullControl",
                                  "spark.hadoop.fs.s3a.fast.upload.default" : "true",
                                  "spark.hadoop.fs.s3a.impl" : "com.databricks.s3a.S3AFileSystem"
                          },
                          "aws_attributes": {
                                  "first_on_demand": 1,
                                  "availability": "SPOT_WITH_FALLBACK",
                                  "zone_id": "us-east-1a",
                                  "instance_profile_arn": "arn:aws:iam::${account_id}:instance-profile/${databricks_instance_profile}",
                                  "spot_bid_price_percent": 100,
                                  "ebs_volume_type": "GENERAL_PURPOSE_SSD",
                                  "ebs_volume_count": 3,
                                  "ebs_volume_size": 100                 
                          },

                          "init_scripts": [],
                          "custom_tags": {
                                   "APRMID" : "6327",
                                   "ResourceOwner" : "iotsid@nationwide.com",
                                   "Created" : "${currentDate}",
                                   "Patch" : "False",
                                   "PowerOnInstanceAt" : "False",
                                   "ShutDownInstanceAt" : "False",
                                   "DisbursementCode" : "023866001",
                                   "SecurityException" : "n/a",
                                   "ResourceName" : "DHF Job Cluster",
                                   "DataClassification" : "public",
                                   "Project" : "PCDS IoT Delta Raw Ingestion",
                                   "Alert" : "False",
                                   "Team" : "NWLine-Smart.Squad@nationwide.com"
                          },
                          "cluster_log_conf": {
                             "dbfs": {
                                  "destination": "dbfs:/cluster-logs"
                            }
                          },                          
                          "spark_env_vars": {
                                  "AWS_STS_REGIONAL_ENDPOINTS": "\\\"regional\\\""
                          }
                   },

                   "notebook_task": {
                          "base_parameters": {
                                            "sns_arn": "${sns_arn}",
                                            "deltadatabase": "${deltadatabase}",
                                            "deltadatabase_path": "${deltadatabase_path}",
                                            "job_run_log": "${job_run_log}",
                                            "job_run_log_path": "${job_run_log_path}",
                                            "part_json_s3_file_loc": "${part_json_s3_file_loc}",
                                            "scoring_file_path": "${scoring_file_path}",
                                            "scoring_table": "${scoring_table}",
                                            "checkpointLocation": "${checkpointLocation}",
                                            "kafkaBootStrapServers": "${kafkaBootStrapServers}",
                                            "truststoreLocation": "${truststoreLocation}",
                                            "keystoreLocation": "${keystoreLocation}",
                                            "topic": "${topic}",
                                            "secret_scope": "${secret_scope}",
                                            "secret_truststorePassword": "${secret_truststorePassword}",
                                            "secret_keystorePassword": "${secret_keystorePassword}",
                                            "secret_keyPassword": "${secret_keyPassword}",
                                            "starting_Offsets": "${starting_Offsets}",  
                                            "maxFilesPerTrigger": "${maxFilesPerTrigger}",
                                            "includeExistingFiles": "${includeExistingFiles}",
                                            "account_id": "${account_id}"
                                            },                                            
                          "notebook_path": "${notebookPath}"
                   }, 
                   
                   "libraries": [],
                   "email_notifications": {
                          "on_start": [],
                          "on_success": [],
                          "on_failure": ["${email_list_onFailure}"]
                   },
                   "schedule": {
                          "quartz_cron_expression": "${cron_job_expression}",
                          "timezone_id": "${schedule_timezone_id}",
                          "pause_status": "${schedule_pause_status}"
                   },
                   "max_retries": ${maxRetries},
                   "min_retry_interval_millis": ${retry_interval}

                  } """
              
                  println(s"jsonForNewJobApi is ${jsonForNewJobApi}")
              
                  val newJobId=spark.read.json(Seq(Seq(
                              "curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewJobApi",s"$dbhost/api/2.0/jobs/create" ).!!).toDS)                   
                                 .select('job_id).as[Long].collect.head  
              
              
                  println(s"JobId ${newJobId} created")

                  val jsonForRunNow = s"""
                                        {
                                           "job_id": ${newJobId}
                                        }
                                        """
              
              
                  val jsonForPermissionApi = s"""
                                        {  
                                           "access_control_list": [
                                                                                
                                              {
                                                  "group_name":"PCDS_Admin",
                                                  "permission_level":"CAN_MANAGE"
                                              },
                                              {
                                                  "group_name":"PCDS_Arch",
                                                  "permission_level":"CAN_VIEW"
                                              },
                                              {
                                                  "group_name":"PCDS_Dev",
                                                  "permission_level":"CAN_VIEW"
                                              },
                                              {
                                                  "group_name":"pcds-iot-smartsquad-dev",
                                                  "permission_level":"CAN_MANAGE"
                                              },
                                              {
                                                  "user_name":"cheenh1@nationwide.com",
                                                  "permission_level":"CAN_MANAGE"
                                              }
                                           ]
                                        }
                                        """

                  Seq("curl", "-X","PATCH","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForPermissionApi",s"$dbhost/api/2.0/permissions/jobs/$newJobId" ).!!                   
              
                  val runid=spark.read.json(sc.parallelize(Seq(Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForRunNow",s"$dbhost/api/2.0/jobs/run-now" ).!! ))).select("run_id").as[Long].collect.head
              
                  println(s"runid is ${runid} for jobid ${newJobId}")

                  val logDF=Seq(JobCreationLogClass(newJobId,runid,clusterId,"realtime_scoring_to_pcds")).toDF.withColumn("created", current_timestamp())            
                  logDF.coalesce(1).write.option("path", job_run_log_path).format("delta").mode("append").saveAsTable(job_run_log)  
            }

     } catch {
            case e: Throwable => 
            println(s"Error in invoking job api : " + e)        
            throw e
     }
  
  
}

// COMMAND ----------

// DBTITLE 1,main method to invoke submit job
def masterMain() = {   

 
             try {
                   createJobAndRun()
             } catch {      
                   case e : Throwable => {
                                    e.printStackTrace
                                    val msg="Error while creating job"
                                    println(msg+e)  
                                    throw e
                   }
            }  
}

// COMMAND ----------

// DBTITLE 1,Call main method
masterMain()
