// Databricks notebook source
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import java.util.Date
import java.util.Properties
import scala.sys.process._
import java.sql.Timestamp
import java.time.LocalDate

// COMMAND ----------

val browserHostName = dbutils.notebook.getContext.tags.getOrElse("browserHostName","none")
var environment =""

if(browserHostName.contains("-dev-"))
{
  environment="dev"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-test-"))
{
  environment="test"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-prod-"))
{
  environment="prod"
  println("environment is set to : " + environment)
}

// COMMAND ----------

val account_id= environment match {
  case "dev"  => "786994105833"
  case "test"  => "168341759447"
  case "prod"  => "785562577411"
}


// COMMAND ----------


val jobName = s"${environment}_IoT_DQI_DRV_Daily_FileWatch"
val notebookPath= s"/Repos/iotsid@nationwide.com/pcds-iot-databricks/DQIChecks/drv_daily_file_watch"

val spark_version ="10.4.x-scala2.12"
val node_type_id ="i3.xlarge"
val driver_node_type_id ="i3.xlarge"
val num_workers="3"

val  drv_file_audit_table_name      = s"drv_daily_file_watch"
val  s3_path                        = s"s3://nw-internal-driven-${account_id}-us-east-1/workspace/"
val  s3_bucket                      = s"nw-internal-driven-${account_id}-us-east-1"
val  deltadatabase                  = s"dhf_iot_dqicheck_${environment}"
val  deltadatabase_path             = s"s3://pc-iot-raw-${account_id}/drv/tables/dhf_iot_dqicheck_${environment}"
val  sns_arn                        = s"arn:aws:sns:us-east-1:${account_id}:pcds-iot-databricks-emailgroup"
val  job_run_log                    = s"${deltadatabase}.job_run_log"
val  job_run_log_path               = s"${deltadatabase_path}/job_run_log"
val  databricks_instance_profile    = "pcds-iot-telematics-devdw01-trustingrole"
val  maxRetries                     = "0"
val  retry_interval                 = "300000"
val  cron_job_expression            = s"10 0 11 * * ?"
val  schedule_timezone_id           = s"America/New_York"
val  schedule_pause_status          = "PAUSED"
val  email_list_onFailure           = s"NWLine-Smart.Squad@nationwide.com"
val  dev_group_name                 = "pcds-iot-smartsquad-dev"
val  dev_group_permission           = "CAN_MANAGE"
val  dev_prod_group_name            = "pcds-iot-smartsquad-prod-support"
val  dev_prod_group_permission      = "CAN_MANAGE"
val  test_group_name                = "pcds-iot-smartsquad-test"
val  test_group_permission          = "CAN_VIEW"
val  pcdm_group_name                = "pcds-iot-pcdm-dev"
val  pcdm_group_permission          = "CAN_MANAGE"
val  runsupport_group_name          = "pcds-iot-iota-prod-support"
val  runsupport_group_permission    = "CAN_VIEW"
val  analyst_group_name             = "pcds-iot-smartsquad-analyst"
val  analyst_group_permission       = "CAN_VIEW"

// COMMAND ----------


val crt_db_ddl=s"""
create database if not exists ${deltadatabase}
location "${deltadatabase_path}"
"""

val crt_tbl_ddl=s"""
create table if not exists ${job_run_log} (
job_id Long,
run_id Long,
cluster_id String,
job_type string,
created timestamp
)
using delta
location "${job_run_log_path}"
"""

spark.sql(crt_db_ddl)
spark.sql(crt_tbl_ddl)

// COMMAND ----------


val token              = dbutils.secrets.get(scope = "iot", key = "JOB_TOKEN")
val workspaceID        = dbutils.notebook.getContext.tags.getOrElse("orgId","none")
val dbhost             = dbutils.notebook.getContext.apiUrl.get
var jobExists: Boolean = false
var jobid: Long        = 0
val clusterId          = dbutils.notebook.getContext.tags.getOrElse("clusterId","none")


// COMMAND ----------


case class JobCreationLogClass(job_id: Long,run_id: Long, cluster_id: String, job_type: String )

// COMMAND ----------


def validateJobId(jobid: Long)  = {

  val resp=Seq("curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/get?job_id=$jobid" ).!!
  if(resp.contains("INVALID_PARAMETER_VALUE")) {
    val msg=s"""Invalid job ID in job_run_log table. Please correct/delete the job ID in job_run_log table and resubmit"""
    println(msg)
    throw new Exception(msg)
  }
  else {
    println(s"Job id is valid")
    jobExists= true
  }

}

// COMMAND ----------


def checkIfRunningOrPendingStatus(jobid: Long): Boolean = {
  val runningStateArray=spark.read.json(Seq(Seq(
    "curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/runs/list?job_id=$jobid" ).!!).toDS)
    .select(explode($"runs"))
    .select("col.state.life_cycle_state")
    .filter("life_cycle_state ='RUNNING' OR life_cycle_state ='PENDING' ")
    .distinct
    .collect()

  if(runningStateArray.size >=1) {
    println(s"Job associated is already in either RUNNING or PENDING status")
    return true
  }
  else {
    println(s"The job is NOT in RUNNING or PENDING state. Run-now will be invoked")
    return false
  }
}

// COMMAND ----------


def createJobAndRun() = {
  val qry = s""" SELECT job_id FROM ${job_run_log} where job_type="drv_daily_file_watch" ORDER BY cast(created as timestamp) desc limit 1 """
  val jobidArray = spark.sql(qry).as[Long].collect

  if(jobidArray.size == 1){
    println(s"Job ID exists")
    jobid=jobidArray(0)
    validateJobId(jobid)
  } else {
    jobExists=false
    jobid=0
    println(s"Job ID does not exist. New job will be created")
  }

  val runningOrPendingStatus=if(jobExists) checkIfRunningOrPendingStatus(jobid) else false

  try{

    if(jobExists && !runningOrPendingStatus) {
      println("Im here1")
      val jsonForExistingJobid = s"""
                    {
                       "job_id": ${jobid}
                    }
                  """

      val runid=spark.read.json(sc.parallelize(Seq( Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForExistingJobid",s"$dbhost/api/2.0/jobs/run-now" ).!! ))).select("run_id").as[Long].collect.head

      println(s"runid is ${runid} for jobid ${jobid}")


      val logDF=Seq(JobCreationLogClass(jobid,runid,clusterId,"drv_daily_file_watch")).toDF.withColumn("created", current_timestamp())
      logDF.coalesce(1).write.option("path", job_run_log_path).format("delta").mode("append").saveAsTable(job_run_log)


    } else if(!jobExists){
      println("Im here2")

      val currentDate = LocalDate.now().toString
      println(s"currentDate is ${currentDate}")

      val jsonForNewJobApi = s"""
                  {
                  "name": "${jobName}",
                  "new_cluster": {
                          "spark_version": "${spark_version}",
                          "node_type_id": "${node_type_id}",
                          "driver_node_type_id": "${driver_node_type_id}",
                          "num_workers": ${num_workers},
                          "spark_conf": {
                                  "spark.hadoop.fs.s3a.credentialsType" : "AssumeRole",
                                  "spark.hadoop.fs.s3.impl" : "com.databricks.s3a.S3AFileSystem",
                                  "spark.hadoop.fs.s3a.acl.default" : "BucketOwnerFullControl",
                                  "spark.hadoop.fs.s3n.impl" : "com.databricks.s3a.S3AFileSystem",
                                  "spark.hadoop.fs.s3a.stsAssumeRole.arn" : "arn:aws:iam::${account_id}:role/pcds-databricks-common-access",
                                  "spark.databricks.io.cache.enabled" : "true",
                                  "spark.hadoop.fs.s3a.canned.acl" : "BucketOwnerFullControl",
                                  "spark.hadoop.fs.s3a.fast.upload.default" : "true",
                                  "spark.hadoop.fs.s3a.impl" : "com.databricks.s3a.S3AFileSystem"
                          },
                          "aws_attributes": {
                                  "first_on_demand": 1,
                                  "availability": "SPOT_WITH_FALLBACK",
                                  "zone_id": "us-east-1a",
                                  "instance_profile_arn": "arn:aws:iam::${account_id}:instance-profile/${databricks_instance_profile}",
                                  "spot_bid_price_percent": 100,
                                  "ebs_volume_type": "GENERAL_PURPOSE_SSD",
                                  "ebs_volume_count": 3,
                                  "ebs_volume_size": 100
                          },

                          "init_scripts": [],
                          "custom_tags": {
                                   "APRMID" : "6327",
                                   "ResourceOwner" : "iotsid@nationwide.com",
                                   "Created" : "${currentDate}",
                                   "Patch" : "False",
                                   "PowerOnInstanceAt" : "False",
                                   "ShutDownInstanceAt" : "False",
                                   "DisbursementCode" : "023866001",
                                   "SecurityException" : "n/a",
                                   "ResourceName" : "IOT Job Cluster",
                                   "DataClassification" : "public",
                                   "Project" : "NWLine-Smart.Squad@nationwide.com",
                                   "Alert" : "False",
                                   "Team" : "NWLine-Smart.Squad@nationwide.com"
                          },
                          "cluster_log_conf": {
                             "dbfs": {
                                  "destination": "dbfs:/cluster-logs"
                            }
                          },
                          "spark_env_vars": {
                                  "AWS_STS_REGIONAL_ENDPOINTS": "\\\"regional\\\""
                          }
                   },

                   "notebook_task": {
                          "base_parameters": { 
                                            "deltadatabase": "${deltadatabase}",
                                            "deltadatabase_path": "${deltadatabase_path}",
                                            "s3_path": "${s3_path}",
                                            "s3_bucket": "${s3_bucket}",
                                            "drv_file_audit_table_name": "${drv_file_audit_table_name}",
                                            "sns_arn": "${sns_arn}",
                                            "job_run_log": "${job_run_log}",
                                            "job_run_log_path": "${job_run_log_path}",
                                            "account_id": "${account_id}",
                                            "databricks_instance_profile": "${databricks_instance_profile}",
                                            "environment": "${environment}"
                                            },
                          "notebook_path": "${notebookPath}"
                   },

                   "libraries": [],
                   "email_notifications": {
                          "on_start": [],
                          "on_success": [],
                          "on_failure": ["${email_list_onFailure}"]
                   },
                   "schedule": {
                          "quartz_cron_expression": "${cron_job_expression}",
                          "timezone_id": "${schedule_timezone_id}",
                          "pause_status": "${schedule_pause_status}"
                   },
                   "max_retries": ${maxRetries},
                   "min_retry_interval_millis": ${retry_interval}

                  } """

      println(s"jsonForNewJobApi is ${jsonForNewJobApi}")

      val newJobId=spark.read.json(Seq(Seq(
        "curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewJobApi",s"$dbhost/api/2.0/jobs/create" ).!!).toDS)
        .select('job_id).as[Long].collect.head

      //val curlResponse = Seq(
      //  "curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewJobApi",s"$dbhost/api/2.0/jobs/create"
      //).!!
      //println( s"curl response: $curlResponse")

      //val newJobId=spark.read.json(Seq( curlResponse).toDS)
      //  .select('job_id).as[Long].collect.head

      println(s"JobId ${newJobId} created")

      val jsonForRunNow = s"""
                                        {
                                           "job_id": ${newJobId}
                                        }
                                        """


      val jsonForPermissionApi = s"""
                                        {
                                           "access_control_list": [

                                              {
                                                  "group_name":"${dev_group_name}",
												                          "permission_level":"${dev_group_permission}"
                                              },
                                              {
                                                  "group_name":"${dev_prod_group_name}",
                                                  "permission_level":"${dev_prod_group_permission}"
                                              },
                                              {
                                                  "group_name":"${test_group_name}",
                                                  "permission_level":"${test_group_permission}"
                                              },
											                        {
                                                  "group_name":"${pcdm_group_name}",
                                                  "permission_level":"${pcdm_group_permission}"
                                              },
                                              {
                                                  "group_name":"${runsupport_group_name}",
                                                  "permission_level":"${runsupport_group_permission}"
                                              },
                                              {
                                                  "group_name":"${analyst_group_name}",
                                                  "permission_level":"${analyst_group_permission}"
                                              }
                                           ]
                                        }
                                        """

      Seq("curl", "-X","PATCH","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForPermissionApi",s"$dbhost/api/2.0/permissions/jobs/$newJobId" ).!!

      val runid=spark.read.json(sc.parallelize(Seq(Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForRunNow",s"$dbhost/api/2.0/jobs/run-now" ).!! ))).select("run_id").as[Long].collect.head

      println(s"runid is ${runid} for jobid ${newJobId}")

      val logDF=Seq(JobCreationLogClass(newJobId,runid,clusterId,"drv_daily_file_watch")).toDF.withColumn("created", current_timestamp())
      logDF.coalesce(1).write.option("path", job_run_log_path).format("delta").mode("append").saveAsTable(job_run_log)
    }

  } catch {
    case e: Throwable =>
      println(s"Error in invoking job api : " + e)
      throw e
  }


}

// COMMAND ----------


def masterMain() = {


  try {
    createJobAndRun()
  } catch {
    case e : Throwable => {
      e.printStackTrace
      val msg="Error while creating job"
      println(msg+e)
      throw e
    }
  }
}

// COMMAND ----------


masterMain()
