// Databricks notebook source
// DBTITLE 1,Import libraries
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import java.util.Date
import java.util.Properties
import scala.sys.process._
import java.sql.Timestamp
import java.time.LocalDate

// COMMAND ----------

val browserHostName = dbutils.notebook.getContext.tags.getOrElse("browserHostName","none")
var environment =""

if(browserHostName.contains("-dev-"))
{
  environment="dev"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-test-"))
{
  environment="test"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-prod-"))
{
  environment="prod"
  println("environment is set to : " + environment)
}

// COMMAND ----------


val account_id= environment match {
  case "dev"  => "786994105833"
  case "test"  => "168341759447"
  case "prod"  => "785562577411"
}


// COMMAND ----------

// DBTITLE 1,Set Environment
val jobName = s"${environment}_IoT_DQI_CurationDailyAudit_job"
val notebookPath= s"/Repos/iotsid@nationwide.com/pcds-iot-${environment}/DQIChecks/curation_auditCheckDaily"

val spark_version ="10.4.x-scala2.12"
val node_type_id ="i3.xlarge"
val driver_node_type_id ="i3.xlarge"
val num_workers="3"


var deltadatabase                  = ""
var deltadatabase_path             = ""
var rawdeltadatabase               = ""
var harmonizedeltadatabase         = ""
var curationdeltadatabase          = ""
var daily_audit_table_name         = ""
var daily_audit_log_table_name     = ""
var outbound_scoring_table_name    = ""
var inbound_scoring_table_name     = ""
var sns_arn                        = ""
var job_run_log                    = ""
var job_run_log_path               = ""
var databricks_instance_profile    = ""
var maxRetries                     = ""
var retry_interval                 = ""
var cron_job_expression            = ""
var schedule_timezone_id           = ""
var schedule_pause_status          = ""
var email_list_onFailure           = ""
var dev_group_name                 = ""
var dev_group_permission           = ""
var dev_prod_group_name            = ""
var dev_prod_group_permission      = ""
var test_group_name                = ""
var test_group_permission          = ""
var pcdm_group_name                = ""
var pcdm_group_permission          = ""
var runsupport_group_name          = ""
var runsupport_group_permission    = ""
var analyst_group_name             = ""
var analyst_group_permission       = ""
var Common_group_name              = ""
var commmon_group_permission       = ""
var pcds_admin_group_name          = ""
var pcds_admin_group_permission    = ""
var pcds_arch_group_name           = ""
var pcds_arch_group_permission     = ""
var variance                       = "30"

if(environment.equals("dev")) {

  deltadatabase                  = "dhf_iot_dqichecks_dev"
  deltadatabase_path             = s"s3://pcds-databricks-common-${account_id}/iot/delta/dqichecks/dhf_iot_dqichecks_dev"
  rawdeltadatabase               = "dhf_iot_ims_raw_dev"
  harmonizedeltadatabase         = "dhf_iot_harmonized_dev"
  curationdeltadatabase          = "dhf_iot_curated_dev"
  daily_audit_table_name        = "curated_daiy_audit_errors"
  daily_audit_log_table_name    = "curated_daiy_audit_logs"
  outbound_scoring_table_name    = "outbound_score_elements"
  inbound_scoring_table_name     = "inbound_score_elements"

  sns_arn                        = s"arn:aws:sns:us-east-1:${account_id}:dw-cmt-pl-iot-telematics-emailgroup"
  job_run_log                    = s"${deltadatabase}.job_run_log"
  job_run_log_path               = s"${deltadatabase_path}/job_run_log"
  databricks_instance_profile    = "pcds-iot-telematics-devdw01-trustingrole"

  maxRetries                     = "0"
  retry_interval                 = "300000"
  cron_job_expression            = s"10 0 11 * * ?"
  schedule_timezone_id           = s"America/New_York"
  schedule_pause_status          = "PAUSED"
  email_list_onFailure           = s"NWLine-Smart.Squad@nationwide.com"
  dev_group_name                 = "pcds-iot-smartsquad-dev"
  dev_group_permission           = "CAN_MANAGE"
  dev_prod_group_name            = "pcds-iot-smartsquad-prod-support"
  dev_prod_group_permission      = "CAN_MANAGE"
  test_group_name                = "pcds-iot-smartsquad-test"
  test_group_permission          = "CAN_VIEW"
  pcdm_group_name                = "pcds-iot-pcdm-dev"
  pcdm_group_permission          = "CAN_MANAGE"
  runsupport_group_name          = "pcds-iot-iota-prod-support"
  runsupport_group_permission    = "CAN_VIEW"
  analyst_group_name             = "pcds-iot-smartsquad-analyst"
  analyst_group_permission       = "CAN_VIEW"
  //Common_group_name              = "PCDS_Dev"
  //commmon_group_permission       = "CAN_VIEW"
  //pcds_admin_group_name          = "PCDS_Admin"
  //pcds_admin_group_permission    = "CAN_VIEW"
  //pcds_arch_group_name           = "PCDS_Arch"
  //pcds_arch_group_permission     = "CAN_VIEW"
}
else if (environment.equals("test")){

  deltadatabase                  = "dhf_iot_dqichecks_test"
  deltadatabase_path             = s"s3://pcds-databricks-common-${account_id}/iot/delta/dqichecks/dhf_iot_dqichecks_test"
  rawdeltadatabase               = "dhf_iot_ims_raw_test"
  harmonizedeltadatabase         = "dhf_iot_harmonized_test"
  curationdeltadatabase          = "dhf_iot_curated_test"
  daily_audit_table_name         = "curated_daiy_audit_errors"
  daily_audit_log_table_name     = "curated_daiy_audit_logs"
  outbound_scoring_table_name    = "outbound_score_elements"
  inbound_scoring_table_name     = "inbound_score_elements"

  sns_arn                        = s"arn:aws:sns:us-east-1:${account_id}:dw-cmt-pl-iot-telematics-emailgroup"
  job_run_log                    = s"${deltadatabase}.job_run_log"
  job_run_log_path               = s"${deltadatabase_path}/job_run_log"
  databricks_instance_profile    = "pcds-iot-telematics-testdw01-trustingrole"

  maxRetries                     = "0"
  retry_interval                 = "300000"
  cron_job_expression            = s"10 0 11 * * ?"
  schedule_timezone_id           = s"America/New_York"
  schedule_pause_status          = "PAUSED"
  email_list_onFailure           = s"NWLine-Smart.Squad@nationwide.com"
  dev_group_name                 = "pcds-iot-smartsquad-dev"
  dev_group_permission           = "CAN_MANAGE"
  dev_prod_group_name			       = "pcds-iot-smartsquad-prod-support"
  dev_prod_group_permission      = "CAN_MANAGE"
  test_group_name                = "pcds-iot-smartsquad-test"
  test_group_permission          = "CAN_MANAGE"
  pcdm_group_name                = "pcds-iot-pcdm-dev"
  pcdm_group_permission          = "CAN_MANAGE"
  runsupport_group_name          = "pcds-iot-iota-prod-support"
  runsupport_group_permission    = "CAN_VIEW"
  analyst_group_name	           = "pcds-iot-smartsquad-analyst"
  analyst_group_permission       = "CAN_VIEW"
  //Common_group_name              = "PCDS_Test"
  //commmon_group_permission       = "CAN_VIEW"
  //pcds_admin_group_name          = "PCDS_Admin"
  //pcds_admin_group_permission    = "CAN_VIEW"
  //pcds_arch_group_name           = "PCDS_Arch"
  //pcds_arch_group_permission     = "CAN_VIEW"
}
else if (environment.equals("prod")){


  deltadatabase                  = "dhf_iot_dqichecks_prod"
  deltadatabase_path             = s"s3://pcds-databricks-common-${account_id}/iot/delta/dqichecks/dhf_iot_dqichecks_prod"
  rawdeltadatabase               = "dhf_iot_ims_raw_prod"
  harmonizedeltadatabase         = "dhf_iot_harmonized_prod"
  curationdeltadatabase          = "dhf_iot_curated_prod"
  daily_audit_table_name         = "curated_daiy_audit_errors"
  daily_audit_log_table_name     = "curated_daiy_audit_logs"
  outbound_scoring_table_name    = "outbound_score_elements"
  inbound_scoring_table_name     = "inbound_score_elements"

  sns_arn                        = s"arn:aws:sns:us-east-1:${account_id}:dw-cmt-pl-iot-telematics-emailgroup"
  job_run_log                    = s"${deltadatabase}.job_run_log"
  job_run_log_path               = s"${deltadatabase_path}/job_run_log"
  databricks_instance_profile    = "pcds-iot-telematics-proddw01-trustingrole"

  maxRetries                     = "3"
  retry_interval                 = "300000"
  cron_job_expression            = s"10 0 11 * * ?"
  schedule_timezone_id           = s"America/New_York"
  schedule_pause_status          = "UNPAUSED"
  email_list_onFailure           = s"NWLine-Smart.Squad@nationwide.com,NWLine-IoTA@nationwide.com"
  dev_group_name                 = "pcds-iot-smartsquad-dev"
  dev_group_permission           = "CAN_VIEW"
  dev_prod_group_name            = "pcds-iot-smartsquad-prod-support"
  dev_prod_group_permission      = "CAN_MANAGE"
  test_group_name                = "pcds-iot-smartsquad-test"
  test_group_permission          = "CAN_VIEW"
  pcdm_group_name                = "pcds-iot-pcdm-dev"
  pcdm_group_permission          = "CAN_VIEW"
  runsupport_group_name          = "pcds-iot-iota-prod-support"
  runsupport_group_permission    = "CAN_MANAGE"
  analyst_group_name             = "pcds-iot-smartsquad-analyst"
  analyst_group_permission       = "CAN_VIEW"
  //Common_group_name              = "PCDS_Prod"
  //commmon_group_permission       = "CAN_VIEW"
  //pcds_admin_group_name          = "PCDS_Admin"
  //pcds_admin_group_permission    = "CAN_VIEW"
  //pcds_arch_group_name           = "PCDS_Arch"
  //pcds_arch_group_permission     = "CAN_VIEW"
}

// COMMAND ----------

val crt_db_ddl=s"""
create database if not exists ${deltadatabase}
location "${deltadatabase_path}"
"""

val crt_tbl_ddl=s"""
create table if not exists ${job_run_log} (
job_id Long,
run_id Long,
cluster_id String,
job_type string,
created timestamp
)
using delta
location "${job_run_log_path}"
"""

spark.sql(crt_db_ddl)
spark.sql(crt_tbl_ddl)

// COMMAND ----------

// DBTITLE 1,Initialization global variable
val token              = dbutils.secrets.get(scope = "iot", key = "JOB_TOKEN")
val workspaceID        = dbutils.notebook.getContext.tags.getOrElse("orgId","none")
val dbhost             = dbutils.notebook.getContext.apiUrl.get
var jobExists: Boolean = false
var jobid: Long        = 0
val clusterId          = dbutils.notebook.getContext.tags.getOrElse("clusterId","none")


// COMMAND ----------

// DBTITLE 1,Define case class
case class JobCreationLogClass(job_id: Long,run_id: Long, cluster_id: String, job_type: String )

// COMMAND ----------

// DBTITLE 1,Method to validate jobid
def validateJobId(jobid: Long)  = {

  val resp=Seq("curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/get?job_id=$jobid" ).!!
  if(resp.contains("INVALID_PARAMETER_VALUE")) {
    val msg=s"""Invalid job ID in job_run_log table. Please correct/delete the job ID in job_run_log table and resubmit"""
    println(msg)
    throw new Exception(msg)
  }
  else {
    println(s"Job id is valid")
    jobExists= true
  }

}

// COMMAND ----------

// DBTITLE 1,Method to check job status
def checkIfRunningOrPendingStatus(jobid: Long): Boolean = {
  val runningStateArray=spark.read.json(Seq(Seq(
    "curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/runs/list?job_id=$jobid" ).!!).toDS)
    .select(explode($"runs"))
    .select("col.state.life_cycle_state")
    .filter("life_cycle_state ='RUNNING' OR life_cycle_state ='PENDING' ")
    .distinct
    .collect()

  if(runningStateArray.size >=1) {
    println(s"Job associated is already in either RUNNING or PENDING status")
    return true
  }
  else {
    println(s"The job is NOT in RUNNING or PENDING state. Run-now will be invoked")
    return false
  }
}

// COMMAND ----------

// DBTITLE 1,Create job and run
def createJobAndRun() = {
  val qry = s""" SELECT job_id FROM ${job_run_log} where job_type="iot_curation_daily_audit" ORDER BY cast(created as timestamp) desc limit 1 """
  val jobidArray = spark.sql(qry).as[Long].collect

  if(jobidArray.size == 1){
    println(s"Job ID exists")
    jobid=jobidArray(0)
    validateJobId(jobid)
  } else {
    jobExists=false
    jobid=0
    println(s"Job ID does not exist. New job will be created")
  }

  val runningOrPendingStatus=if(jobExists) checkIfRunningOrPendingStatus(jobid) else false

  try{

    if(jobExists && !runningOrPendingStatus) {
      println("Im here1")
      val jsonForExistingJobid = s"""
                    {
                       "job_id": ${jobid}
                    }
                  """

      val runid=spark.read.json(sc.parallelize(Seq( Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForExistingJobid",s"$dbhost/api/2.0/jobs/run-now" ).!! ))).select("run_id").as[Long].collect.head

      println(s"runid is ${runid} for jobid ${jobid}")


      val logDF=Seq(JobCreationLogClass(jobid,runid,clusterId,"iot_curation_daily_audit")).toDF.withColumn("created", current_timestamp())
      logDF.coalesce(1).write.option("path", job_run_log_path).format("delta").mode("append").saveAsTable(job_run_log)


    } else if(!jobExists){
      println("Im here2")

      val currentDate = LocalDate.now().toString
      println(s"currentDate is ${currentDate}")

      val jsonForNewJobApi = s"""
                  {
                  "name": "${jobName}",
                  "new_cluster": {
                          "spark_version": "${spark_version}",
                          "node_type_id": "${node_type_id}",
                          "driver_node_type_id": "${driver_node_type_id}",
                          "num_workers": ${num_workers},
                          "spark_conf": {
                                  "spark.hadoop.fs.s3a.credentialsType" : "AssumeRole",
                                  "spark.hadoop.fs.s3.impl" : "com.databricks.s3a.S3AFileSystem",
                                  "spark.hadoop.fs.s3a.acl.default" : "BucketOwnerFullControl",
                                  "spark.hadoop.fs.s3n.impl" : "com.databricks.s3a.S3AFileSystem",
                                  "spark.hadoop.fs.s3a.stsAssumeRole.arn" : "arn:aws:iam::${account_id}:role/pcds-databricks-common-access",
                                  "spark.databricks.io.cache.enabled" : "true",
                                  "spark.hadoop.fs.s3a.canned.acl" : "BucketOwnerFullControl",
                                  "spark.hadoop.fs.s3a.fast.upload.default" : "true",
                                  "spark.hadoop.fs.s3a.impl" : "com.databricks.s3a.S3AFileSystem"
                          },
                          "aws_attributes": {
                                  "first_on_demand": 1,
                                  "availability": "SPOT_WITH_FALLBACK",
                                  "zone_id": "us-east-1a",
                                  "instance_profile_arn": "arn:aws:iam::${account_id}:instance-profile/${databricks_instance_profile}",
                                  "spot_bid_price_percent": 100,
                                  "ebs_volume_type": "GENERAL_PURPOSE_SSD",
                                  "ebs_volume_count": 3,
                                  "ebs_volume_size": 100
                          },

                          "init_scripts": [],
                          "custom_tags": {
                                   "APRMID" : "6327",
                                   "ResourceOwner" : "iotsid@nationwide.com",
                                   "Created" : "${currentDate}",
                                   "Patch" : "False",
                                   "PowerOnInstanceAt" : "False",
                                   "ShutDownInstanceAt" : "False",
                                   "DisbursementCode" : "023866001",
                                   "SecurityException" : "n/a",
                                   "ResourceName" : "IOT Job Cluster",
                                   "DataClassification" : "public",
                                   "Project" : "NWLine-Smart.Squad@nationwide.com",
                                   "Alert" : "False",
                                   "Team" : "NWLine-Smart.Squad@nationwide.com"
                          },
                          "cluster_log_conf": {
                             "dbfs": {
                                  "destination": "dbfs:/cluster-logs"
                            }
                          },
                          "spark_env_vars": {
                                  "AWS_STS_REGIONAL_ENDPOINTS": "\\\"regional\\\""
                          }
                   },

                   "notebook_task": {
                          "base_parameters": {
                                            "deltadatabase": "${deltadatabase}",
                                            "deltadatabase_path": "${deltadatabase_path}",
                                            "rawdeltadatabase": "${rawdeltadatabase}",
                                            "harmonizedeltadatabase": "${harmonizedeltadatabase}",
                                            "curationdeltadatabase": "${curationdeltadatabase}",
                                            "daily_audit_table_name": "${daily_audit_table_name}",
                                            "daily_audit_log_table_name": "${daily_audit_log_table_name}",
                                            "outbound_scoring_table_name": "${outbound_scoring_table_name}",
                                            "inbound_scoring_table_name":"${inbound_scoring_table_name}",
                                            "sns_arn": "${sns_arn}",
                                            "job_run_log": "${job_run_log}",
                                            "job_run_log_path": "${job_run_log_path}",
                                            "account_id": "${account_id}",
                                            "databricks_instance_profile": "${databricks_instance_profile}",
                                            "environment": "${environment}",
                                            "variance": "${variance}"
                                            },
                          "notebook_path": "${notebookPath}"
                   },

                   "libraries": [],
                   "email_notifications": {
                          "on_start": [],
                          "on_success": [],
                          "on_failure": ["${email_list_onFailure}"]
                   },
                   "schedule": {
                          "quartz_cron_expression": "${cron_job_expression}",
                          "timezone_id": "${schedule_timezone_id}",
                          "pause_status": "${schedule_pause_status}"
                   },
                   "max_retries": ${maxRetries},
                   "min_retry_interval_millis": ${retry_interval}

                  } """

      println(s"jsonForNewJobApi is ${jsonForNewJobApi}")

      val newJobId=spark.read.json(Seq(Seq(
         "curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewJobApi",s"$dbhost/api/2.0/jobs/create" ).!!).toDS)
         .select('job_id).as[Long].collect.head

      //val curlResponse = Seq(
      //  "curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewJobApi",s"$dbhost/api/2.0/jobs/create"
      //).!!
      //println( s"curl response: $curlResponse")

      //val newJobId=spark.read.json(Seq( curlResponse).toDS)
      //  .select('job_id).as[Long].collect.head

      println(s"JobId ${newJobId} created")

      val jsonForRunNow = s"""
                                        {
                                           "job_id": ${newJobId}
                                        }
                                        """


      val jsonForPermissionApi = s"""
                                        {
                                           "access_control_list": [

                                              {
                                                  "group_name":"${dev_group_name}",
												                          "permission_level":"${dev_group_permission}"
                                              },
                                              {
                                                  "group_name":"${dev_prod_group_name}",
                                                  "permission_level":"${dev_prod_group_permission}"
                                              },
                                              {
                                                  "group_name":"${test_group_name}",
                                                  "permission_level":"${test_group_permission}"
                                              },
											                        {
                                                  "group_name":"${pcdm_group_name}",
                                                  "permission_level":"${pcdm_group_permission}"
                                              },
                                              {
                                                  "group_name":"${runsupport_group_name}",
                                                  "permission_level":"${runsupport_group_permission}"
                                              },
                                              {
                                                  "group_name":"${analyst_group_name}",
                                                  "permission_level":"${analyst_group_permission}"
                                              }
                                           ]
                                        }
                                        """

      Seq("curl", "-X","PATCH","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForPermissionApi",s"$dbhost/api/2.0/permissions/jobs/$newJobId" ).!!

      val runid=spark.read.json(sc.parallelize(Seq(Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForRunNow",s"$dbhost/api/2.0/jobs/run-now" ).!! ))).select("run_id").as[Long].collect.head

      println(s"runid is ${runid} for jobid ${newJobId}")

      val logDF=Seq(JobCreationLogClass(newJobId,runid,clusterId,"iot_curation_daily_audit")).toDF.withColumn("created", current_timestamp())
      logDF.coalesce(1).write.option("path", job_run_log_path).format("delta").mode("append").saveAsTable(job_run_log)
    }

  } catch {
    case e: Throwable =>
      println(s"Error in invoking job api : " + e)
      throw e
  }


}

// COMMAND ----------

// DBTITLE 1,main method to invoke submit job
def masterMain() = {


  try {
    createJobAndRun()
  } catch {
    case e : Throwable => {
      e.printStackTrace
      val msg="Error while creating job"
      println(msg+e)
      throw e
    }
  }
}

// COMMAND ----------

// DBTITLE 1,Call main method
masterMain()
