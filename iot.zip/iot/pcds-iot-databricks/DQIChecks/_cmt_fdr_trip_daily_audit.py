# Databricks notebook source
# DBTITLE 1,Import libraries
import json
import boto3
import time
import re
import dateutil
from datetime import datetime
import csv
from subprocess import call
from datetime import datetime, timedelta
from pyspark.sql.types import StructType,StructField, TimestampType, StringType, DateType, IntegerType, ArrayType
from pyspark.sql.functions import current_date, lit, size, col

# COMMAND ----------

# DBTITLE 1,Set Environment variables
deltadatabase = str(dbutils.widgets.get("deltadatabase"))
deltadatabase_path = str(dbutils.widgets.get("deltadatabase_path"))
rawdeltadatabase = str(dbutils.widgets.get("rawdeltadatabase"))
rawscoredatabase = str(dbutils.widgets.get("rawscoredatabase"))
harmonizedeltadatabase = str(dbutils.widgets.get("harmonizedeltadatabase"))
curationdeltadatabase = str(dbutils.widgets.get("curationdeltadatabase"))
rawTripSummaryRt_table = str(dbutils.widgets.get("rawTripSummaryRt_table"))
outbound_score_table = str(dbutils.widgets.get("outbound_score_table"))
harmonizedCmtScoreTable = str(dbutils.widgets.get("harmonizedCmtScoreTable"))
fdr_inbound_table = str(dbutils.widgets.get("fdr_inbound_table"))
nm2_inbound_table = str(dbutils.widgets.get("nm2_inbound_table"))
error_table = str(dbutils.widgets.get("error_table"))
checkpoint_table = str(dbutils.widgets.get("checkpoint_table"))
sns_arn = str(dbutils.widgets.get("sns_arn"))
job_run_log = str(dbutils.widgets.get("job_run_log"))
job_run_log_path = str(dbutils.widgets.get("job_run_log_path"))
account_id = str(dbutils.widgets.get("account_id"))
databricks_instance_profile = str(dbutils.widgets.get("databricks_instance_profile"))
env = str(dbutils.widgets.get("environment"))

now = datetime.now()
load_dt = (now.date() - timedelta(days=1)).strftime('%Y-%m-%d')
#load_dt = '2023-03-15'
print(load_dt)
cur_date = now.date()
print(cur_date)
prev_date = now.date() - timedelta(days=2)
print(prev_date)


# COMMAND ----------


spark.sql(f"""CREATE TABLE IF NOT EXISTS {deltadatabase}.{checkpoint_table} (
TRNSCTN_TP_CD STRING,
TRIP_SMRY_KEY ARRAY<STRING>,
RECORD_COUNT LONG,
SRC_SYS_CD STRING,
LOAD_DT DATE,
PREV_MAX_TS TIMESTAMP,
DB_LOAD_TS TIMESTAMP)
USING delta
OPTIONS (
  `mergeSchema` 'true')
LOCATION 's3://pcds-databricks-common-{account_id}/iot/delta/dqichecks/{deltadatabase}/{checkpoint_table}'
TBLPROPERTIES (
  'mergeSchema' = 'true')""")

spark.sql(f"""CREATE TABLE IF NOT EXISTS {deltadatabase}.{error_table} (
auditCheck STRING,
errorOutput_ds ARRAY<STRING>,
description STRING,
trip_load_dt DATE,
db_load_dt DATE,
db_load_ts TIMESTAMP)
USING delta
OPTIONS (
  `mergeSchema` 'true')
LOCATION 's3://pcds-databricks-common-{account_id}/iot/delta/dqichecks/{deltadatabase}/{error_table}'
TBLPROPERTIES (
  'mergeSchema' = 'true')""")

# COMMAND ----------

sns_client = boto3.client('sns',region_name='us-east-1')
def publish_sns_message(sns_client, topic_arn, msg, sub):
    sns_client.publish(
        TopicArn = topic_arn,
        Message = msg,
        Subject = sub
    )

# COMMAND ----------

def tripSmryInboundOutboundCheck(load_dt):

    rawRealtimeTripsDF = spark.sql(f"select count(distinct driveid)  from {rawdeltadatabase}.{rawTripSummaryRt_table} where load_dt = '{load_dt}'" )
    outboundScoreTripsDF = spark.sql(f"select count(distinct (get_json_object(trip_smry_json_tt, '$.driveid'))) as trip_smry_key from {rawdeltadatabase}.{outbound_score_table}  where load_dt = '{load_dt}' and get_json_object(trip_smry_json_tt, '$.driveid') is not null" )
    print("Fetching record count from outbound_mobile_score_elements for last 24 hrs...")
    outboundCheckpointDF = spark.sql(f"select load_dt,collect_list(regexp_extract(trnsctn_id,'(.*)_(.*)_(.*)',1)) as trip_smry_key,count(*) record_count,trnsctn_tp_cd, src_sys_cd,  (select max(db_load_time)  from {rawdeltadatabase}.{outbound_score_table} where src_sys_cd like '%CMT_%') as prev_max_ts, current_timestamp() as db_load_ts from  {rawdeltadatabase}.{outbound_score_table} where src_sys_cd like '%CMT_%' and db_load_time >= (select max(db_load_time) - INTERVAL 24 HOURS   from {rawdeltadatabase}.{outbound_score_table} where src_sys_cd like '%CMT_%') and db_load_time > (select coalesce(max(prev_max_ts), '2023-02-01') from {deltadatabase}.{checkpoint_table}) and trnsctn_tp_cd in ('Trip','Trip Label Update')  group by load_dt,trnsctn_tp_cd,src_sys_cd" )
    if outboundCheckpointDF.count() == 0:
        msg = f"CMT OUTBOUND TRIPS count Validation check failed.\n\nNo new trips were sent to MF for scoring"
        sub = f'{env}-CMT OUTBOUND TRIPS count Validation check failure'
        publish_sns_message(sns_client, sns_arn, msg, sub)
    else:
        print("Loading Checkoint table...")
        outboundCheckpointDF.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{checkpoint_table}')
    if rawRealtimeTripsDF.count() != outboundScoreTripsDF.count():
        if rawRealtimeTripsDF.count() < outboundScoreTripsDF.count() :
            print("Less TRIP_SMRY_KEY count for trip_summary_realtime table. Fetching the missing trips")
            missingTripSmryKeyDF = spark.sql(f"select 'tripSummary_rt_count_check' as auditCheck, collect_list(ob.trip_smry_key) as errorOutput_ds, 'Trips present in outbound_mobile_score_elements but missing in trip_summary_realtime' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct (get_json_object(trip_smry_json_tt, '$.driveid')) as trip_smry_key,prgrm_tp_cd, prgrm_cd, src_sys_cd from {rawdeltadatabase}.{outbound_score_table} where get_json_object(trip_smry_json_tt, '$.driveid') is not null and load_dt = '{load_dt}' and prgrm_stts_cd = 'Active') ob left join (select distinct driveid from {rawdeltadatabase}.{rawTripSummaryRt_table} ) td on ob.trip_smry_key = td.driveid  where  td.driveid is null" )
            countDF = missingTripSmryKeyDF.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
            missingTrips = countDF.head()[0]
            if missingTrips > 0:
                print("Loading Error table...")
                missingTripSmryKeyDF.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
                msg = f"CMT TRIP_SUMMARY_REALTIME TRIP_SMRY_KEY count Validation check failed.\n\nLess TRIP_SMRY_KEY count compared to outbound_mobile_score_elements for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'tripSummary_rt_count_check'"
                sub = f'{env}-CMT TRIP_SUMMARY_REALTIME TRIP_SMRY_KEY count Validation check failure: {load_dt}'
                publish_sns_message(sns_client, sns_arn, msg, sub)
            #else :
            #    msg = f'CMT TRIP_SUMMARY_REALTIME TRIP_SMRY_KEY count Validation check successful.\n\nTRIP_SMRY_KEY counts are matching for load_dt:{load_dt}'
            #    sub = f'{env}-CMT TRIP_SUMMARY_REALTIME TRIP_SMRY_KEY count Validation succeeded: {load_dt}'
            #    publish_sns_message(sns_client, sns_arn, msg, sub)
        else:
            print("Less TRIP_SMRY_KEY count for outbound_mobile_score_elements table. Fetching the missing trips")
            missingTripSmryKeyDF = spark.sql(f"select 'outbound_score_count_check' as auditCheck,collect_list(td.driveid) as errorOutout_ds, 'Trips present in trip_summary_realtime but missing in outbound_mobile_score_elements' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct (get_json_object(trip_smry_json_tt, '$.driveid')) as trip_smry_key,prgrm_tp_cd, prgrm_cd, src_sys_cd from {rawdeltadatabase}.{outbound_score_table} where get_json_object(trip_smry_json_tt, '$.driveid') is not null ) ob right join (select distinct driveid from {rawdeltadatabase}.{rawTripSummaryRt_table} where db_load_date = '{load_dt}') td on ob.trip_smry_key = td.driveid  where  ob.trip_smry_key is null" )
            countDF = missingTripSmryKeyDF.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
            missingTrips = countDF.head()[0]
            if missingTrips > 0:
                print("Loading Error table...")
                missingTripSmryKeyDF.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
                msg = f"CMT OUTBOUND_MOBILE_SCORE_ELEMENTS TRIP_SMRY_KEY count Validation check failed.\n\nLess TRIP_SMRY_KEY count compared to trip_summary_realtime for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'outbound_score_count_check'"
                sub = f'{env}-CMT OUTBOUND_MOBILE_SCORE_ELEMENTS TRIP_SMRY_KEY count Validation check failure: {load_dt}'
                publish_sns_message(sns_client, sns_arn, msg, sub)
            #else :
            #    msg = f'CMT OUTBOUND_MOBILE_SCORE_ELEMENTS TRIP_SMRY_KEY count Validation check successful.\n\nTRIP_SMRY_KEY counts are matching for load_dt: {load_dt}'
            #    sub = f'{env}-CMT OUTBOUND_MOBILE_SCORE_ELEMENTS TRIP_SMRY_KEY count Validation check succeeded: {load_dt}'
            #    publish_sns_message(sns_client, sns_arn, msg, sub)

    #else:
    #  msg = f'CMT TRIP_SMRY_KEY count Validation check successful for load_dt: {load_dt}'
    #  sub = f'{env}-CMT TRIP_SMRY_KEY count Validation check succeeded: {load_dt}'
    #  publish_sns_message(sns_client, sns_arn, msg, sub)

# COMMAND ----------

def fdrInboundOutboundCheck(load_dt):
    print(" Checking Trips present in outbound_mobile_score_elements but missing in inbound fdr_trip_driver_score...")
    missingTripSmryKeyDF1 = spark.sql(f"select 'fdr_inbound_score_check' as auditCheck, collect_list(ob.trip_smry_key) as errorOutput_ds, 'Trips present in outbound_mobile_score_elements but missing in inbound fdr_trip_driver_score' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct (get_json_object(trip_smry_json_tt, '$.driveid')) as trip_smry_key,prgrm_tp_cd, prgrm_cd, src_sys_cd from {rawdeltadatabase}.{outbound_score_table} where get_json_object(trip_smry_json_tt, '$.driveid') is not null and load_dt = '{load_dt}' and prgrm_stts_cd = 'Active') ob left join (select distinct driveid from {rawscoredatabase}.{fdr_inbound_table}) td on ob.trip_smry_key = td.driveid  where  td.driveid is null" )
    countDF1 = missingTripSmryKeyDF1.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
    missingTrips1 = countDF1.head()[0]
    if missingTrips1 > 0:
        print("Loading Error table...")
        missingTripSmryKeyDF1.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
        msg = f"CMT fdr_trip_driver_score TRIP_SMRY_KEY Validation check failed for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'fdr_inbound_score_check'"
        sub = f'{env}-CMT FDR Inbound Scoring Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_arn, msg, sub)
    #else :
    #    msg = f'CMT fdr_trip_driver_score TRIP_SMRY_KEY Validation check successful for load_dt: {load_dt}'
    #    sub = f'{env}-CMT FDR Inbound Scoring Validation check succeeded: {load_dt}'
    #    publish_sns_message(sns_client, sns_arn, msg, sub)

    print(" Checking Trips present in inbound fdr_trip_driver_score but missing in outbound_mobile_score_elements...")
    missingTripSmryKeyDF2 = spark.sql(f"select 'fdr_outbound_score_check' as auditCheck,collect_list(td.driveid) as errorOutput_ds, 'Trips present in inbound fdr_trip_driver_score but missing in outbound_mobile_score_elements' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct (get_json_object(trip_smry_json_tt, '$.driveid')) as trip_smry_key,prgrm_tp_cd, prgrm_cd, src_sys_cd from {rawdeltadatabase}.{outbound_score_table} where get_json_object(trip_smry_json_tt, '$.driveid') is not null ) ob right join (select distinct driveid from {rawscoredatabase}.{fdr_inbound_table} where load_date = '{load_dt}') td on ob.trip_smry_key = td.driveid  where  ob.trip_smry_key is null" )
    countDF2 = missingTripSmryKeyDF2.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
    missingTrips2 = countDF2.head()[0]
    if missingTrips2 > 0:
        print("Loading Error table...")
        missingTripSmryKeyDF2.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
        msg = f"CMT outbound_mobile_score_elements TRIP_SMRY_KEY Validation check failed for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'fdr_outbound_score_check'"
        sub = f'{env}-CMT FDR Outbound Scoring Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_arn, msg, sub)
    #else :
    #    msg = f'CMT outbound_mobile_score_elements TRIP_SMRY_KEY Validation check successful for load_dt: {load_dt}'
    #    sub = f'{env}-CMT FDR Outbound Scoring Validation check succeeded: {load_dt}'
    #    publish_sns_message(sns_client, sns_arn, msg, sub)

# COMMAND ----------

def nm2InboundOutboundCheck(load_dt):
    print(" Checking Trips present in outbound_mobile_score_elements but missing in inbound nm2_trip_driver_score...")
    missingTripSmryKeyDF3 = spark.sql(f"select 'nm2_inbound_score_check' as auditCheck, collect_list(ob.trip_smry_key) as errorOutput_ds, 'Trips present in outbound_mobile_score_elements but missing in inbound nm2_trip_driver_score' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct (get_json_object(trip_smry_json_tt, '$.driveid')) as trip_smry_key,prgrm_tp_cd, prgrm_cd, src_sys_cd from {rawdeltadatabase}.{outbound_score_table} where get_json_object(trip_smry_json_tt, '$.driveid') is not null and load_dt = '{load_dt}' and prgrm_stts_cd = 'Active') ob left join (select distinct driveid from {rawscoredatabase}.{nm2_inbound_table}) td on ob.trip_smry_key = td.driveid  where  td.driveid is null" )
    countDF3 = missingTripSmryKeyDF3.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
    missingTrips3 = countDF3.head()[0]
    if missingTrips3 > 0:
        print("Loading Error table...")
        missingTripSmryKeyDF3.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
        msg = f"CMT nm2_trip_driver_score TRIP_SMRY_KEY Validation check failed for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'nm2_inbound_score_check'"
        sub = f'{env}-CMT NM2 Inbound Scoring Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_arn, msg, sub)
    #else :
    #    msg = f'CMT nm2_trip_driver_score TRIP_SMRY_KEY Validation check successful for load_dt: {load_dt}'
    #    sub = f'{env}-CMT NM2 Inbound Scoring Validation check succeeded: {load_dt}'
    #    publish_sns_message(sns_client, sns_arn, msg, sub)

    print(" Checking Trips present in inbound nm2_trip_driver_score but missing in outbound_mobile_score_elements...")
    missingTripSmryKeyDF4 = spark.sql(f"select 'nm2_outbound_score_check' as auditCheck,collect_list(td.driveid) as errorOutput_ds, 'Trips present in inbound nm2_trip_driver_score but missing in outbound_mobile_score_elements' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct (get_json_object(trip_smry_json_tt, '$.driveid')) as trip_smry_key,prgrm_tp_cd, prgrm_cd, src_sys_cd from {rawdeltadatabase}.{outbound_score_table} where get_json_object(trip_smry_json_tt, '$.driveid') is not null ) ob right join (select distinct driveid from {rawscoredatabase}.{nm2_inbound_table} where load_date = '{load_dt}') td on ob.trip_smry_key = td.driveid  where  ob.trip_smry_key is null" )
    countDF4 = missingTripSmryKeyDF4.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
    missingTrips4 = countDF4.head()[0]
    if missingTrips4 > 0:
        print("Loading Error table...")
        missingTripSmryKeyDF4.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
        msg = f"CMT outbound_mobile_score_elements TRIP_SMRY_KEY Validation check failed for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'nm2_outbound_score_check'"
        sub = f'{env}-CMT NM2 Outbound Scoring Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_arn, msg, sub)
    #else :
    #    msg = f'CMT outbound_mobile_score_elements TRIP_SMRY_KEY Validation check successful for load_dt: {load_dt}'
    #    sub = f'{env}-CMT NM2 Outbound Scoring Validation check succeeded: {load_dt}'
    #    publish_sns_message(sns_client, sns_arn, msg, sub)

# COMMAND ----------

def tripDriverScoreCheck(load_dt):
    print(" Checking Trips present in raw fdr_trip_driver_score but missing in harmonized trip_driver_score...")
    missingTripSmryKeyDF3 = spark.sql(f"select 'fdr_harmonized_score_check' as auditCheck,collect_list(td.driveid) as errorOutput_ds, 'Trips present in raw fdr_trip_driver_score but missing in harmonized trip_driver_score' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct trip_smry_key from {harmonizedeltadatabase}.{harmonizedCmtScoreTable} ) ob right join (select distinct driveid from {rawscoredatabase}.{fdr_inbound_table} where load_date = '{load_dt}') td on ob.trip_smry_key = td.driveid  where ob.trip_smry_key is null" )
    countDF3 = missingTripSmryKeyDF3.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
    missingTrips3 = countDF3.head()[0]
    if missingTrips3 > 0:
        print("Loading Error table...")
        missingTripSmryKeyDF3.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
        msg = f"CMT Harmonized fdr_trip_driver_score TRIP_SMRY_KEY Validation check failed for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'fdr_harmonized_score_check'"
        sub = f'{env}-CMT Harmonized fdr_trip_driver_score TRIP_SMRY_KEY Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_arn, msg, sub)
    #else :
    #    msg = f'CMT Harmonized fdr_trip_driver_score TRIP_SMRY_KEY Validation check successful for load_dt: {load_dt}'
    #    sub = f'{env}-CMT Harmonized fdr_trip_driver_score TRIP_SMRY_KEY Validation check succeeded: {load_dt}'
    #    publish_sns_message(sns_client, sns_arn, msg, sub)

    print(" Checking Trips present in raw nm2_trip_driver_score but missing in harmonized trip_driver_score...")
    missingTripSmryKeyDF4 = spark.sql(f"select 'nm2_harmonized_score_check' as auditCheck,collect_list(td.driveid) as errorOutput_ds, 'Trips present in raw nm2_trip_driver_score but missing in harmonized trip_driver_score' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from (select distinct trip_smry_key from {harmonizedeltadatabase}.{harmonizedCmtScoreTable}) ob right join (select distinct driveid from {rawscoredatabase}.{nm2_inbound_table} where load_date = '{load_dt}') td on ob.trip_smry_key = td.driveid  where ob.trip_smry_key is null" )
    countDF4 = missingTripSmryKeyDF4.withColumn("trip_cnt",size(col("errorOutput_ds"))).select("trip_cnt")
    missingTrips4 = countDF4.head()[0]
    if missingTrips4 > 0:
        print("Loading Error table...")
        missingTripSmryKeyDF4.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
        msg = f"CMT Harmonized nm2_trip_driver_score TRIP_SMRY_KEY Validation check failed for load_dt: {load_dt}\n\nExecute below query to check missing TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'nm2_harmonized_score_check'"
        sub = f'{env}-CCMT Harmonized nm2_trip_driver_score TRIP_SMRY_KEY Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_arn, msg, sub)
    #else :
    #    msg = f'CMT Harmonized nm2_trip_driver_score TRIP_SMRY_KEY Validation check successful for load_dt: {load_dt}'
    #    sub = f'{env}-CMT Harmonized nm2_trip_driver_score TRIP_SMRY_KEY Validation check succeeded: {load_dt}'
    #    publish_sns_message(sns_client, sns_arn, msg, sub)

# COMMAND ----------

def orphanLabelUpdatesCheck(load_dt):
    print(" Checking Trips Label Updates in outbound_mobile_score_elements having no enrollment...")
    orphanLabelDF = spark.sql(f"select 'orphan_trip_labels_check' as auditCheck, collect_list(trip_smry_key) as errorOutput_ds, 'Trips Label Updates having no enrollment in outbound score table' as description,cast('{load_dt}' as DATE) as trip_load_dt, current_date() as db_load_dt, current_timestamp() as db_load_ts from {rawdeltadatabase}.{outbound_score_table} where  prgrm_cd is null or prgrm_tp_cd is null and trnsctn_tp_cd = 'Trip Label Update' and load_dt = '{load_dt}'")
    countDF5 = orphanLabelDF.withColumn("label_cnt",size(col("errorOutput_ds"))).select("label_cnt")
    labelCount = countDF5.head()[0]
    if labelCount > 0:
        print("Loading Error table...")
        orphanLabelDF.write.format('delta').mode('append').saveAsTable(f'{deltadatabase}.{error_table}')
        msg = f"CMT Orphan Trip Label Updates Validation check failed for load_dt: {load_dt}\n\nExecute below query to check  TRIP_SMRY_KEY:\nselect * from {deltadatabase}.{error_table} where trip_load_dt = '{load_dt}' and auditCheck = 'orphan_trip_labels_check'"
        sub = f'{env}-CMT Orphan Trip Label Updates Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_arn, msg, sub)

# COMMAND ----------

def rewardScoreCheck(load_dt):
  ds=spark.sql(f"select distinct a.dataCollectionId  from dhf_iot_cmt_raw_{env}.rewards a inner join dhf_iot_raw_{env}.program_enrollment b on a.dataCollectionId=b.dataCollectionId and a.rewards_policyNumber=b.policyNumber and a.driverFinalScore!=b.program_score and a.db_load_date= '{load_dt}'")

  dcid=[row['dataCollectionId'] for row in ds.collect()]
  
  if dcid:
    print("scores not matching")
    msg = f"FDR rewards driver_score is not matching with raw enrollment program_score for load_dt: {load_dt}\ndataCollectionId={dcid}\n\nThanks,\nIOT Team"
    sub = f'{env}-FDR Rewards Validation check failure: {load_dt}'
    publish_sns_message(sns_client, sns_arn, msg, sub)


# COMMAND ----------

tripSmryInboundOutboundCheck(load_dt)
fdrInboundOutboundCheck(load_dt)
nm2InboundOutboundCheck(load_dt)
tripDriverScoreCheck(load_dt)
orphanLabelUpdatesCheck(load_dt)
rewardScoreCheck(load_dt)
