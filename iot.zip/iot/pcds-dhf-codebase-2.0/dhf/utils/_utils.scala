// Databricks notebook source
import java.util.Properties
import java.sql.Timestamp
import java.time.LocalDateTime

//added for phase4
import java.util.Date
import scala.sys.process._
import org.json._

//added for email alerts
import javax.mail.Session
import javax.mail.Message
import javax.mail.MessagingException
import javax.mail.internet.AddressException
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.mail.internet.MimeUtility

// COMMAND ----------

val token = dbutils.notebook.getContext().apiToken.get
val workspaceID=dbutils.notebook.getContext.tags.getOrElse("orgId","none")
val dbhost = dbutils.notebook.getContext.apiUrl.get

// COMMAND ----------

//val scope_name = "dhf_dev"
val scope_name = s"dhf_${environment}"

val token    = dbutils.secrets.get(scope = scope_name, key = "JOBTOKEN")

val hostName = dbutils.secrets.get(scope = scope_name, key = "PGHOST")
val pgPort   = dbutils.secrets.get(scope = scope_name, key = "PGPORT")
val dbName   = dbutils.secrets.get(scope =scope_name, key = "PGDATABASE")
//val dbName   = "dhf2_config"
val user     = dbutils.secrets.get(scope = scope_name, key = "PGUSER")
val password = dbutils.secrets.get(scope = scope_name, key = "PGPASSWORD")

var currentSchema = ""
if(environment == "dev"){
currentSchema = "dhfconfigdevl"
}else if(environment == "test"){
currentSchema = "dhfconfigtest"
}else if(environment == "prod"){
currentSchema = "dhfconfigprod"
}

val driverClass = "org.postgresql.Driver"   
val jdbcUrlForConfigDB = s"jdbc:postgresql://${hostName}:${pgPort}/${dbName}"

val sqlConnectionProperties = new Properties()
sqlConnectionProperties.setProperty("user", user)
sqlConnectionProperties.setProperty("password", password)
sqlConnectionProperties.setProperty("currentSchema", currentSchema)
sqlConnectionProperties.setProperty("Driver", driverClass)
sqlConnectionProperties

// COMMAND ----------

case class TaskGroup (
                    job_group_id:Long,               // changes for UI-0323
                    id:Long,
                    name:String,
                    run_type:String,
                    job_type: String,
                    active: String,   
                    user_properties: String,
                    created: Timestamp,
                    source_db: String,
                  source_table : String,
                  target_db: String,
                  target_table : String,
                    merge_keys:String,
                    is_custom_notebook: Boolean,
                    max_bytes_per_trigger: String, //for merge stream from changelog,
                    inline_optimize_enabled: Boolean,
                    z_order_cols :String,
                    optimize_start_hour:java.lang.Long,
                    optimize_end_hour:java.lang.Long,
                    retention_hrs_vacuum:java.lang.Long,
                    min_threshold: Long,
                    max_threshold: Long,
                    merge_type: String,
                    is_hash_Column: Boolean,
                    is_surrogate_key: Boolean,
                    order_by_column: String,
                    pre_harmonization_query: String,
                    curation_handler_path: String,
                    email_list: String
     
                   )

case class Task (id:Long,
                  task_group_id:Long,
                  name: String,
                  read_table_from_date: String,
                  max_bytes_per_trigger: String,

                  source_db: String,
                  source_table : String,
                  target_db: String,
                  target_table : String,

                  sql_query : String,
                  active : String,
                  created :Timestamp 
                )


				


case class DataTransportDefinition (
                id: Long,
                name: String,
                handler_name: String,
                handler_path: String,
                version:String,
                version_features: String,
                property_values: String,
                description: String,                
                created: Timestamp
              )

case class Group(
                    id:Long,
                    name:String, 
                    run_type:String, 
                    job_type: String,
                    handler_path:String,
                    is_custom_notebook: Boolean,
                    active: String,
                    cluster_config: String
                   )

//Phase 3 class
case class WarehouseTask (
                    id:Long,
                    name:String,
                    //group_id:Long,
                    job_group_id: Long,
                    //data_domain:String,   
                    data_domain_id: Long,
                    source_db: String,
                    source_table:String,
                    active: Boolean,
                    created: Timestamp,
                    sf_schema:String,
                    sf_warehouse:String,  
                    sf_database: String,
                    sf_table:String,
                    sf_key:String,
                    min_threshold: Long,
                    max_threshold: Long,
                    sfmerge_type_1: Boolean, //added for SCD type1
                    sftype_1_order_by_column: String, //added for SCD type1
                    max_bytes_per_trigger: String,
                    email_list: String,
                    read_table_from_date: String
                     )

/*case class WarehouseConfig (
                    secret_scope:String,
                    secret_sf_user:String,
                    secret_sf_password:String,
                    sfURL:String,   
                    environment: String,
                    domain_id:Long
                   ) */

// COMMAND ----------

def getTaskGroup(taskGroupId: Long) : TaskGroup = {  

  
    val pushdown_query = s""" (select 
                                *
                              from
                                task_group_new                               
                              where 
                                id =${taskGroupId} and
                                 active ) t 
                             """    //and upper(job_type)=\'${job_type}\' 
  
  println("pushdown_query "+pushdown_query)
  val taskGroupList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[TaskGroup].collect.toList  
//  val taskGroupList = spark.sql(pushdown_query).as[TaskGroup].collect.toList
  println("taskGroupList is :::: "+ taskGroupList)
    if(taskGroupList!=null && taskGroupList.size>1) {
       throw new Exception("There should NOT be more than one entry for a task group in task_group table for a specific job_type. Please correct and resubmit the job")
    }  
    taskGroupList.head
} 

// COMMAND ----------

def getTask(taskGroupId:Int, job_type: String) : List[Task] = {    
  
  val whereCond =  s""" WHERE task_group_id=${taskGroupId} and  active """ // upper(job_type)=\'${job_type}\' and
  
    val pushdown_query = s""" (select *
                            from 
                              task_new 
                              
                            ${whereCond}  ) t
                            """   
  
  
    spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[Task].collect.toList 
    //spark.sql(pushdown_query).as[Task].collect.toList
   
}

// COMMAND ----------

def getGroup(groupId: Long) : Group = {  

  
    val pushdown_query = s""" (select 
                               *
                              from
                                job_group_new                               
                              where 
                                id =${groupId} ) t
                             """    
  println("pushdown_query issss2 "+pushdown_query)
  val groupIdList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[Group].collect.toList
  //val groupIdList = spark.sql(pushdown_query).as[Group].collect.toList
  println("GroupIdList is :::: "+ groupIdList)
    if(groupIdList!=null && groupIdList.size>1) {
       throw new Exception("There should NOT be more than one entry for a group_id in group_id table for a specific run_type. Please correct and resubmit the job")
    }  
    groupIdList.head
} 

// COMMAND ----------

def getConfig(domain_source_id: Long) : String = {  
    
    val pushdown_query = s""" (select  
                                  property_values
                              from
                                  domain_source                              
                              where 
                                  id =${domain_source_id} ) t
                            """
   
    val configList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[String].collect.toList   
    println("configList is: "+configList)
    
    if(configList.isEmpty ) {
       throw new Exception(s"no configuration found for domain_source_id ${domain_source_id} in domain_source table. Please correct and resubmit the job")
    }  
    if(configList!=null && configList.size>1) {
       throw new Exception(s"There should NOT be more than one entry for a domain_source_id ${domain_source_id} in domain_source table. Please correct and resubmit the job")
    }  
    configList.head
}

// COMMAND ----------

def getPropertyValue(propertyName:String, yamlString:String) : String = {
  
    val keyValueArray = yamlString.split(" ")
    keyValueArray.foreach( keyValue =>{
      if(keyValue.contains(propertyName)) {
        val value=keyValue.split("#")(1).toString.trim
        return value              
      }            
    })  
    return ""
}

// COMMAND ----------

// DBTITLE 1,Phase 3
//Phase 3

/*def getWarehouseConfig(env: String) : WarehouseConfig = {  

    val pushdown_query = s""" (select 
                                *
                              from
                                ${dbName}.dhf_delta_warehouse_config                              
                              where 
                                environment =\'${env}\'
                                )
                             """    
  println("pushdown_query issss2 "+pushdown_query)
 // val taskGroupList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[TaskGroup].collect.toList 
  val warehouseConfigList = spark.sql(pushdown_query).as[WarehouseConfig].collect.toList
  println("warehouseConfigList is :::: "+ warehouseConfigList)
    //if(taskGroupList!=null && taskGroupList.size>1) {
    //   throw new Exception("There should NOT be more than one entry for a task group in task_group table for a specific job_type. Please //correct and resubmit the job")
   //}  
    warehouseConfigList.head
} */


// COMMAND ----------

def getWarehouseTaskList(groupId: Long) : List[WarehouseTask] = {  

  
    val pushdown_query = s""" ( select 
                                     whtg.* , min_threshold,max_threshold
                                      from
                                      warehouse_sync_new whtg inner join job_threshold_config_new tc on whtg.id=tc.pipeline_stage_param
                                      where
                                      job_group_id =${groupId} and tc.pipeline_stage=\'WAREHOUSE_SYNC\' and
                                      active ) t
                             """    
  println("pushdown_query issss2 "+pushdown_query)
  val warehouseGroupList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[WarehouseTask].collect.toList 
  //val warehouseGroupList = spark.sql(pushdown_query).as[WarehouseTask].collect.toList
  println("warehouseGroupList is :::: "+ warehouseGroupList)
    //if(taskGroupList!=null && taskGroupList.size>1) {
    //   throw new Exception("There should NOT be more than one entry for a task group in task_group table for a specific job_type. Please //correct and resubmit the job")
   //}  
    warehouseGroupList
} 



// COMMAND ----------

def getTaskGroupList(groupId: Long) : List[TaskGroup] = {  

  
    val pushdown_query = s""" (select 
                                tg.*,min_threshold,max_threshold
                              from
                                task_group_new tg inner join job_threshold_config_new tc on tg.id=tc.pipeline_stage_param                                
                              where 
                                job_group_id =${groupId} and tc.pipeline_stage=\'HARMONIZATION\' and
                                active ) t
                             """    
  println("pushdown_query issss2 "+pushdown_query)
  val taskGroupList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[TaskGroup].collect.toList 
  //val taskGroupList = spark.sql(pushdown_query).as[TaskGroup].collect.toList
  println("taskGroupList is :::: "+ taskGroupList)
    //if(taskGroupList!=null && taskGroupList.size>1) {
    //   throw new Exception("There should NOT be more than one entry for a task group in task_group table for a specific job_type. Please //correct and resubmit the job")
   //}  
    taskGroupList
} 

// COMMAND ----------

def getCurationTaskGroupList(groupId: Long) : List[TaskGroup] = {  

  
    val pushdown_query = s""" (select 
                                tg.*,min_threshold,max_threshold
                              from
                                task_group_new tg inner join job_threshold_config_new tc on tg.id=tc.pipeline_stage_param                                
                              where 
                                job_group_id =${groupId} and tc.pipeline_stage=\'DATA_CURATION\' and
                                active ) t
                             """    
  println("pushdown_query issss2 "+pushdown_query)
  val taskGroupList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[TaskGroup].collect.toList 
  //val taskGroupList = spark.sql(pushdown_query).as[TaskGroup].collect.toList
  println("taskGroupList is :::: "+ taskGroupList)
    //if(taskGroupList!=null && taskGroupList.size>1) {
    //   throw new Exception("There should NOT be more than one entry for a task group in task_group table for a specific job_type. Please //correct and resubmit the job")
   //}  
    taskGroupList
} 

// COMMAND ----------

// DBTITLE 1,Operational Metrics
val jobId=dbutils.notebook.getContext.tags.getOrElse("jobId","none")
val runId=dbutils.notebook.getContext.tags.getOrElse("runId","none")
val clusterId=dbutils.notebook.getContext.tags.getOrElse("clusterId","none")
val job_name=dbutils.notebook.getContext.tags.getOrElse("jobName","Test").toString

case class MetricCCPerBatch(group_id: String, job_id: String, job_type: String, run_type: String, run_id: String,  batch_id: Long, batch_size: Long, batch_duration_min : String, batch_start_time : String, task_group_id: Long, task_id: Long, source_table:String, target_table : String, clusterId : String)

def persistLog(jobMetrics: MetricCCPerBatch, logTable: String)  = {   
      Seq(jobMetrics)
        .toDS  
        .coalesce(1)
        .withColumn("db_load_date",'batch_start_time.cast("date"))
        .write
        .format("delta")
        .mode("append")
        .partitionBy("db_load_date")
        .saveAsTable(s"${logTable}") 
}

// spark.sql("CREATE DATABASE IF NOT EXISTS dhf_logs_dev;")

// COMMAND ----------

//Phase 3 metrics

case class WarehousePerBatch(group_id: String, job_id: String, job_type: String, run_type: String, run_id: String, batch_id: Long, batch_size: Long, batch_duration_min : String, batch_start_time : String, task_id: Long, source_table: String, target_table : String, clusterId : String)

def warehousePersistLog(jobMetrics: WarehousePerBatch, logTable: String)  = {   
      Seq(jobMetrics)
        .toDS  
        .coalesce(1)
        .withColumn("db_load_date",'batch_start_time.cast("date"))
        .write
        .format("delta")
        .mode("append")
        .partitionBy("db_load_date")
        .saveAsTable(s"${logTable}") 
}

// COMMAND ----------

// DBTITLE 1,Phase 4 Alerting and Monitoring
//Splunk

def pushToSplunk(event : String) ={
try{
val jsonForSplunk = new JSONObject(event)
 val splunkToken = dbutils.secrets.get(scope = scope_name, key = "splunk_token")
 val splunkEndPoint= dbutils.secrets.get(scope = scope_name, key = "splunk_endpoint")
//val workspaceID=dbutils.notebook.getContext.tags.getOrElse("orgId","none")
val api_out=spark.read.json(Seq(Seq("curl", "-k","-X","POST","-H",s"Authorization: Splunk $splunkToken","-H",s"X-Databricks-Org-Id: ${workspaceID}","-H","Content-Type: application/json","-d", s"$jsonForSplunk",s"$splunkEndPoint" ).!!).toDS)
//println(api_out)
//val status = api_out.select("text").as[String].collect.head
//println("Status -" +status)
}catch{
case e: Throwable => println("Post to Splunk Failed" + e)
}
}

// COMMAND ----------


def sendToSplunk(groupId: String,jobId: String, jobName: String,jobType: String,runType: String,runId: String,batchId: Long,
batchSize: Long, start: String,totalTimeBatchMin: String,taskGroupId: Long,taskId: Long,source: String,harmonizedTable: String,clusterId: String, status: String) ={
val sourcetype= "DHFjobauditing_json"
val jsonForSplunkApi = s"""
                     {
                      "index": "pc-dhf",
                      "host": "datacollector4-d757dfc4d-fpn5k",
                      "source": "test-streamsets-data-collector",
                      "sourcetype": "${sourcetype}",
                      "event": { "group_id": "${groupId}",
                                 "job_id": "${jobId}",
                                 "job_name": "${job_name}",
                                 "job_type": "${jobType}",
                                 "run_type": "${runType}",
                                 "run_id": "${runId}",
                                 "batch_id": "${batchId}",
                                 "batch_size": "${batchSize}",
                                 "total_batch_time": "${totalTimeBatchMin}",
                                 "start_time": "${start}",
                                 "task_group_id": "${taskGroupId}",
                                 "task_id": "${taskId}",
                                 "source_table": "${source}",
                                 "target_table": "${harmonizedTable}",
                                 "cluster_id": "${clusterId}",
                                 "status":"${status}"
                                 
                               }
                    } """
  
//call splunk function and pass the json
println(s"Sending ${status} Log info to splunk for ${jobType}, batchid ${batchId},taskid ${taskId},taskgroup ${taskGroupId} ")
pushToSplunk(jsonForSplunkApi)
}



// COMMAND ----------

//SNOW TICKET PAYLOAD new one

def generatePayload(customerEventIdentifier: String, message:String, eventDetail: String) = {
  
  val date_time=new java.util.Date()
    println(date_time)
 
     val jsonForNewSnow = s"""{
        "ticketSeverity": "P4",
        "ticketGroup": "DW-RAPID-RESPONSE",
        "event": {
              "customerEventIdentifier": "${customerEventIdentifier}",
              "severity": "minor",
              "eventManager": "dhf-ops-process",
              "eventCategory": "dhf-job-abend",
              "configurationItem": "8475",
              "message": "${message}",
              "eventDetail": "${eventDetail}"
                  }
              }"""

jsonForNewSnow  
}

// COMMAND ----------

val incidentLogTable = s"dhf_logs_${environment}.dhf_delta_incident_log"

case class SnowIncident(incident_number: String, job_type: String, job_id: String, run_id:String, group_id: String, task_group: String, task_id: String, created_date: String, incident_message: String)

def incidentPersistLog(jobMetrics: SnowIncident, incidentlogTable: String)  = {   
      Seq(jobMetrics)
        .toDS  
        .coalesce(1)
        .withColumn("db_load_date",'created_date.cast("date"))
        .write
        .format("delta")
        .mode("append")
        .partitionBy("db_load_date")
        .saveAsTable(s"${incidentlogTable}") 
}

// COMMAND ----------

//SNOW TICKET FUNCTION New one

def createSnow(JobId: String, JobType: String, task_group: String, RunId: String, taskiD: Long, groupId: Long, job_name: String, customerEventIdentifier: String, message:String, eventDetail: String, counter: Long):String = {
  var Ticket_Number = ""
  var counter_inc = counter
  try
  {
      val jsonForNewSnow = generatePayload(customerEventIdentifier, message, eventDetail)
  
      	val clientId = dbutils.secrets.get(scope = scope_name, key = "snow_clientid")
	val snowEndPoint=dbutils.secrets.get(scope = scope_name, key = "snow_endpoint")
      val api_out=spark.read.json(Seq(Seq("curl","-k","-X","POST","-H",s"client_id: ${clientId}","-H","Content-Type: application/json","-H",s"X-NW-Message-ID: XXXX12347","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewSnow",s"$snowEndPoint").!!).toDS)
      //println(api_out.show(false))
         
           Ticket_Number = api_out.select("entry.TicketNum").as[String].collect.head
          
      if (!Ticket_Number.contains("INC")){
          println(s"Ticket not created in ${counter_inc} attempt. Sleeping for 90 sec")
          Thread.sleep(90000)
          counter_inc = counter_inc + 1
          if(counter_inc <= 5){
              //Calling snow fucntion to create ticket
              Ticket_Number = createSnow(JobId, JobType, task_group, RunId, taskiD, groupId, job_name, customerEventIdentifier, message, eventDetail, counter_inc)
             }
          else{
            println("Ticket Number is not generated. As it exceeds time")
             }
          }
       else{
            println(s"Ticket Number ${Ticket_Number}: generated successfully for taskid ${taskiD} failure")
         
        //Logging the Incident details in the Incident Log table
         incidentPersistLog(SnowIncident(Ticket_Number, JobType, jobId.toString, RunId, groupId.toString, task_group.toString, taskiD.toString, LocalDateTime.now().toString, eventDetail), incidentLogTable)
           }
    }catch {
         case e:Exception => {   
                  val failMsg = "API FAILED "
                  val description = failMsg+":"+e
                  println("SNOW ticket creation failed, TicketNum field is not available in JSON: " + description) 
                  Ticket_Number = "No ticket generated"
                }
         }
  //incidentPersistLog(SnowIncident(Ticket_Number, JobType, jobId.toString, runId, groupId.toString, task_group, taskiD.toString, LocalDateTime.now().toString, description), incidentLogTable) 
  
Ticket_Number
}


// COMMAND ----------

//function to check time for inline optimization
def isOptimizeTableTime(runTypeUpper: String, triggerOnce: String, optimizeStartHour: Integer, optimizeEndHour: Integer): Boolean = {
  val currentEDTTimeInHour = spark.sql("select hour(from_utc_timestamp(current_timestamp, 'EST'))").collect()(0)(0).toString.toInt

    !runTypeUpper.equals(triggerOnce)        &&
    currentEDTTimeInHour >= optimizeStartHour &&
    currentEDTTimeInHour < optimizeEndHour
}

// COMMAND ----------

//inline Optimization

def optimizeDeltaTable(taskGroup: TaskGroup) = {
  val silverDB= taskGroup.target_db
  val deltaTable = taskGroup.target_table
  val pkCols = taskGroup.z_order_cols
  val optimizeStartHour= taskGroup.optimize_start_hour.toString.toInt
  val optimizeEndHour = taskGroup.optimize_end_hour.toString.toInt
  val runTypeUpper = taskGroup.run_type
  val retention_hrs_vacuum = taskGroup.retention_hrs_vacuum
  val triggerOnce="AVAILABLE_NOW" 
  val isOptimizeTime = isOptimizeTableTime(runTypeUpper, triggerOnce, optimizeStartHour, optimizeEndHour)
  if(isOptimizeTime){	
  val zorderColumns = pkCols.split(",").map(_.trim.toUpperCase).mkString(",")
  val sql = s"""optimize ${silverDB}.${deltaTable} ZORDER BY ${zorderColumns} """
  var currentTimeStart = System.currentTimeMillis
  var startTime = new java.util.Date(currentTimeStart)
  println(s"${LocalDateTime.now()}: Optimize job is starting with QUERY: $sql")
  try {
    spark.sql(sql)
  } catch {     
    case e: Throwable => println("Optimize Failed" + e)
  }
  var currentTimeEnd = System.currentTimeMillis
  var endTime = new java.util.Date(currentTimeEnd)
  var totalTime = (endTime.getTime - startTime.getTime) / (1000.0 * 60)
  println(s"${LocalDateTime.now()}: Optimize completed for ${silverDB}.${deltaTable}. Took ${totalTime} mins")
   if(retention_hrs_vacuum != null){   
      println(s"${LocalDateTime.now()}: Vacuum job is starting")
      currentTimeStart = System.currentTimeMillis   
       startTime = new java.util.Date(currentTimeStart)
  try {
         spark.sql(s"VACUUM ${silverDB}.${deltaTable} RETAIN ${retention_hrs_vacuum} HOURS") 
    
  } catch {
    case e: Throwable => println("Vacuum Failed" + e)    
    }
      currentTimeEnd = System.currentTimeMillis 
      endTime = new java.util.Date(currentTimeEnd)
      totalTime = (endTime.getTime - startTime.getTime) / (1000.0 * 60)
  println(s"${LocalDateTime.now()}: Vacuum completed for ${silverDB}.${deltaTable}. Took ${totalTime} mins")
   }else{
     println("Vacuum cannot will not be performed since retention period is empty")
     
   }
  }else{
    println("Current Time is not b/w start and end hour of optimization.Skipping optimization & vacuum")
    
  }
  
}

// COMMAND ----------

// DBTITLE 1,Send Email Using SMTP
//sending email alerts


def sendEmail(toEmails: String , fromEmail: String, subject: String, body: String): Unit = {
    
    val props = new Properties
    props.setProperty("mail.transport.protocol", "smtp");
    val mail_smtp_host= dbutils.secrets.get(scope = scope_name, key = "mail_smtp_host")
    val mail_smtp_port= dbutils.secrets.get(scope = scope_name, key = "mail_smtp_port")
    props.setProperty("mail.smtp.host", s"$mail_smtp_host");
    props.put("mail.smtp.port", s"$mail_smtp_port");
    props.setProperty("mail.smtp.auth", "false");
    println("email--" +toEmails)
    val session = Session.getInstance(props)
    //var tolist= toEmails
    try {
      if(toEmails !=null){
      val messageBody = body
      val message = new MimeMessage(session)
      
        var toEmailList= toEmails.split(",").toList
      message.setFrom(new InternetAddress(fromEmail))
      for (toEmail <- toEmailList) {
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail))
      }
      message.setSubject(subject)
      message.setHeader("Content-Type", "text/plain;")
      message.setContent(messageBody, "text/html")
      val transport = session.getTransport("smtp")
      
      transport.connect()
      transport.sendMessage(message, message.getAllRecipients)
      }else{
        println("Email list is empty.No email will be sent.")
      }
    } catch {
      case exception: Exception =>
        println("Mail delivery failed. " + exception)
    }
}

// COMMAND ----------

// DBTITLE 1,HTML E-Mail formatting
def format_email(errorMsg: String, changeTicket: String, jobUrl: String, jobId: String, jobName: String,message: String): String = {
    val error_msg = errorMsg
    val change_ticket = changeTicket
    val Job_Url = jobUrl
    val Job_Id = jobId
    val Job_Name = jobName

    val html_body = s"""<!DOCTYPE html>
    <html>
    <head>
    </head>
    <style>
        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        </style>
    <body><p> Good Day! </p>
    <p>${message}, find the details below: </p> 
    <table style="width:90%">
      <tr>
        <th>Items</th>
        <th>Details</th>

      </tr>
      <tr>
        <td>Job-Name</td>
        <td>${Job_Name}</td>

      </tr>
      <tr>
        <td>Job Id</td>
        <td><a href="${Job_Url}">${Job_Id}</td>

      </tr>

      <tr>
        <td>Error Message</td>
        <td>${error_msg}</td>

      </tr>

      <tr>
        <td>Snow Ticket</td>
        <td><a href="">${change_ticket}</td>

      </tr>
    </table>
    <p>NOTE : PLEASE DO NOT REPLY. This email is generated by an automated system.For any issues or concern related to Framework, connect to DHF Team</p>
    <p>DHF Team</p>
    <table1 style="width:100%">
    

    </body>
    </html>"""
  html_body
}


// COMMAND ----------

def errorHandler(errorType: String,job_name: String,groupId: Long,jobId: String,jobType: String,runId: String,batchId: Long,maxThreshold: Long,minThreshold: Long,totalBatchTimeInMins: String,taskGroupId: Long,taskId: Long,errorMessage: String,to: String) {
   var customerEventIdentifier=""
   var message=""
   var eventDetail=""
   var ticketNum="No Ticket Generated"
   var html_body=""
   var from="dhfsid@nationwide.com"
   var sub=""
   var body=""
   var jobUrl = s"https://nationwide-pcds-${environment}-virginia.cloud.databricks.com/?o=${workspaceID}#job/${jobId}"
    
   if (errorType=="minThreshold"){
      if(jobType == "WAREHOUSE_SYNC"){
          message = s"Mininum Threshold Breached: JobId: ${jobId}, Taskid: ${taskId}, Batchid: ${batchId}"
          eventDetail = s"The Groupid: ${groupId}, Taskid: ${taskId}, RunId: ${runId}, Batchid: ${batchId} has breached the min threshold: ${minThreshold}. The total batch time: ${totalBatchTimeInMins}"
      } else {
          message = s"Mininum Threshold Breached: JobId: ${jobId}, TaskgroupId: ${taskGroupId}, Batchid: ${batchId}"
          eventDetail = s"The Groupid: ${groupId}, TaskgroupId: ${taskGroupId}, RunId: ${runId}, Batchid: ${batchId} has breached the min threshold: ${minThreshold}. The total batch time: ${totalBatchTimeInMins}"
     }
     html_body= format_email(eventDetail, "No Ticket Generated", jobUrl, jobId, job_name,message)
     
   }else if( errorType=="maxThreshold"){
            if(jobType == "WAREHOUSE_SYNC"){
                customerEventIdentifier = s"DHF JOB ${job_name} GROUP ID ${groupId} taskId ${taskId} has breached the max threshold."
                message = s"Maximun Threshold Breached: JobId: ${jobId}, taskId: ${taskId}, Batchid: ${batchId}."
                eventDetail = s"Batchid ${batchId} has breached the maxthreshold limit of ${maxThreshold} mins in merge stream handler .Total time the batch took to complete is ${totalBatchTimeInMins} mins"
            } else {
                customerEventIdentifier = s"DHF JOB ${job_name} GROUP ID ${groupId} TaskGroupId ${taskGroupId} has breached the max threshold."
                message = s"Maximun Threshold Breached: JobId: ${jobId}, TaskgroupId: ${taskGroupId}, Batchid: ${batchId}."
                eventDetail = s"Batchid ${batchId} has breached the maxthreshold limit of ${maxThreshold} mins in merge stream handler .Total time the batch took to complete is ${totalBatchTimeInMins} mins"
             }
         //ticketNum = createSnow(jobId, jobType, taskGroupId.toString, runId, taskId, groupId,  job_name,customerEventIdentifier,message,eventDetail,1)
         html_body= format_email(eventDetail, ticketNum, jobUrl, jobId, job_name,message)
     
   }else if (errorType=="exception"){
     if(jobType == "WAREHOUSE_SYNC"){
            customerEventIdentifier = s"DHF JOB ${job_name} GROUP ID ${groupId} taskId ${taskId} has Failed."
            message = s"Job Abend: ${jobId}, RunId: ${runId} ,GROUP ID ${groupId} Taskid: ${taskId} has failed."
            eventDetail =s"DHF JobId: ${jobId}, RunId: ${runId} The JobName: ${job_name}, Groupid: ${groupId}, taskId ${taskId} ,has has failed."
          }
          else {
            customerEventIdentifier = s"DHF JOB ${job_name} GROUP ID ${groupId} TaskGroupId ${taskGroupId} has Failed."
            message = s"Job Abend: ${jobId}, RunId: ${runId} ,TaskGroupId: ${taskGroupId} Taskid: ${taskId} has failed."
            eventDetail =s"DHF JobId: ${jobId}, RunId: ${runId} The JobName: ${job_name}, Groupid: ${groupId}, TaskGroupId: ${taskGroupId} ,has has failed."
          }
           //ticketNum = createSnow(jobId,jobType, taskGroupId.toString, runId, taskId, groupId, job_name,customerEventIdentifier,message,eventDetail + errorMessage,1)
           html_body= format_email(errorMessage, ticketNum, jobUrl, jobId, job_name,message)
   }
  
  sub = environment+":"+message
  body = html_body
  sendEmail(to,from,sub,body)
    }

// COMMAND ----------

def getUserPropertyValue(propertyName:String, yamlString:String) : String = {
    val keyValueArray = yamlString.split("#")
    keyValueArray.foreach( keyValue =>{
      if(keyValue.contains(propertyName)) {
        val value=keyValue.split(":")(1).toString.trim
        return value              
      }            
    })  
    return ""
}
