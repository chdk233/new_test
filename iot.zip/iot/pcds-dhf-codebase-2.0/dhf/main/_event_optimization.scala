// Databricks notebook source
// DBTITLE 1,importing libraries
import sqlContext.implicits._ 
import org.apache.spark.sql.functions._
import io.delta.tables._ 
import org.apache.spark.sql.expressions.Window
import java.time.LocalDateTime
import org.apache.spark.sql.types._
import java.util.Date
import scala.concurrent.{Await, Future} 
import scala.collection.parallel.ForkJoinTaskSupport
import java.util.concurrent.ForkJoinPool

import java.util.concurrent.Executors
import scala.concurrent._
import java.time.{ZonedDateTime, ZoneId}
import java.time.format.DateTimeFormatter

final val numberOfWorkers = sc.statusTracker.getExecutorInfos.length - 1
final val coresPerWorker = sc.parallelize("1", 1).map(_ => java.lang.Runtime.getRuntime.availableProcessors).collect()(0)
final val totalWorkerCores = numberOfWorkers * coresPerWorker

// COMMAND ----------

spark.conf.set("spark.databricks.delta.optimize.zorder.checkStatsCollection.enabled",false);  // to insure the optimization works if the z-ordering column is beyond 32nd column number.
//spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled",false)
val parallelthreads= totalWorkerCores //number of tables getting optimized in parallel
println("Total Worker Cores - " +totalWorkerCores)
println("Number Of Parallel thread - " +parallelthreads)
//val database="dhf2_phase1_test"
//val jobStatusLog="dhf_delta_optimize_job_status_log"
//val configTable="dhf_delta_optimize_config"

// COMMAND ----------

// DBTITLE 1,Get arguments from widgets
dbutils.widgets.removeAll()
dbutils.widgets.text("jobName", "Test", "Job_Name") 
dbutils.widgets.text("groupId", "1", "Group_Id")
dbutils.widgets.text("jobLogTable","","Job_Log_Table")
//dbutils.widgets.text("configTable","","Config_Table")
dbutils.widgets.text("jobStatusLog","","Job_Status_Log")
dbutils.widgets.text("environment", "dev", "environment")
val jobName=dbutils.widgets.get("jobName").toString.toUpperCase
val groupId=dbutils.widgets.get("groupId").toString.toInt
val jobLogTable=dbutils.widgets.get("jobLogTable").toString
//val configTable=dbutils.widgets.get("configTable").toString
val jobStatusLog=dbutils.widgets.get("jobStatusLog").toString
val environment = dbutils.widgets.get("environment").toString

println("JobName in notebook is : "+jobName)
println("groupId in notebook is : "+groupId)
println("Log table in notebook is : "+jobLogTable)
//println("configTable in notebook is : "+configTable)
println("jobStatusLog in notebook is : "+jobStatusLog)
println("environment in notebook is : " + environment)


// COMMAND ----------

// MAGIC %run ../utils/_utils

// COMMAND ----------

// DBTITLE 1,Log Properties
val jobId=dbutils.notebook.getContext.tags.getOrElse("jobId","0").toLong
val runId=dbutils.notebook.getContext.tags.getOrElse("runId","0").toLong


case class JobLogPerTable(job_id: Long, group_id: Long, job_name: String,run_id: Long, process_name : String, tablename : String, start_time: String, end_time: String, status:String, error_msg: String)

def persistLog(jobMetrics: JobLogPerTable, logTable: String)  = {   
      Seq(jobMetrics)
        .toDS  
        .coalesce(1)
        .write
        .format("delta")
        .mode("append")
        .saveAsTable(s"${logTable}") 
}

// COMMAND ----------

// DBTITLE 1,Table object
case class TableGroup( data_domain:String,
                      database_name:String, 
                      table_name:String,
                      job_group_id:Long,
                      partition_col:String,   
                      z_orderby_column:String,  
                      active:Boolean,     
                      size_of_table:String,     
                      retain_hours_vacuum:Integer)

// COMMAND ----------

// DBTITLE 1,get table list method
def getTableList(groupId: Integer): List[TableGroup]= {
  
  //val sqlquery = s""" (Select *
  //                     FROM ${configTable} WHERE active='Y' and groupId= ${groupId}) """
  //spark.sql(sqlquery).as[TableGroup].collect.toList
  val pushdown_query = s"""( SELECT *  FROM delta_optimize_config_new where active and job_group_id=${groupId}  ) t """
  spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[TableGroup].collect.toList
}

// COMMAND ----------

// DBTITLE 1,defining optimize method
def doOptimize(table_name:String,zorder_column:String,partition_col:String,groupId: Integer): Unit ={

  val optimize_table = table_name
  val zOrderColumn = zorder_column.split(",").map(_.trim.toUpperCase).mkString(",")
  var partitionCol = new Array[String](0)
  if(partition_col.trim().size >0)
  partitionCol = partition_col.split(",").map(_.trim)
  println(s"${LocalDateTime.now()}: Optimize job is starting")
  var currentTimeStart = System.currentTimeMillis  
  var startTime = new java.util.Date(currentTimeStart)
    var yesterday = ZonedDateTime.now(ZoneId.of("UTC")).minusDays(1)
  var formatter = DateTimeFormatter.ofPattern("yyyyMMdd")
  var partitiondate = formatter format yesterday
  var zOrderPredicate = ""
try { 
      if (!(zOrderColumn == null || zOrderColumn.isEmpty)) {
       zOrderPredicate = s"ZORDER BY ${zOrderColumn}"
      
      }
 
	   if(partitionCol.size==1){ // single partition in yyyymmdd format
          var optimizeresult=spark.sql(s"OPTIMIZE ${optimize_table} where ${partition_col} = ${partitiondate} ${zOrderPredicate}")
        }else if(partitionCol.size==2){ // two partition in yyyy and mm format
          var year = yesterday.getYear
          var month = yesterday.getMonthValue
          var optimizeresult=spark.sql(s"OPTIMIZE ${optimize_table} where ${partitionCol(0)} = ${year} and ${partitionCol(1)} = ${month} ${zOrderPredicate}")
        }else if(partitionCol.size==3){ //three partition in yyyy ,mm and dd format
          var year = yesterday.getYear
          var month = yesterday.getMonthValue
          var day = yesterday.getDayOfMonth
          var optimizeresult=spark.sql(s"OPTIMIZE ${optimize_table} where ${partitionCol(0)} = ${year} and ${partitionCol(1)} = ${month} and ${partitionCol(2)} = ${day} ${zOrderPredicate}")
        } else {
          var optimizeresult= spark.sql(s"OPTIMIZE ${optimize_table} ${zOrderPredicate} ")
       }
    var currentTimeEnd = System.currentTimeMillis  
  var endTime = new java.util.Date(currentTimeEnd)
    
  persistLog(JobLogPerTable(jobId,groupId.toLong, jobName, runId,"Optimization/zordering",table_name,startTime.toString,endTime.toString,"Completed","NA"), jobLogTable)
  println(s"${LocalDateTime.now()}: Optimize completed for ${optimize_table}.")
   }catch {
    case e: Throwable => println("Optimize Failed" + e)
    persistLog(JobLogPerTable(jobId, groupId.toLong,jobName, runId,"Optimization/zordering",table_name,startTime.toString,startTime.toString,"Failed","otimization Failed"+e), jobLogTable)
    
  }
  
}

// COMMAND ----------

// DBTITLE 1,Define Vacuum Method
def doVaccum(table_name: String,retain_hrs: Integer,groupId:Integer): Unit ={

  var vaccum_table = table_name
  println(s"${LocalDateTime.now()}: Vacuum job is starting")
  
  var currentTimeStart = System.currentTimeMillis   
  var startTime = new java.util.Date(currentTimeStart)
  try {
         spark.sql(s"VACUUM ${vaccum_table} RETAIN ${retain_hrs} HOURS") 
     var currentTimeEnd = System.currentTimeMillis 
     var endTime = new java.util.Date(currentTimeEnd)
 persistLog(JobLogPerTable(jobId,groupId.toLong, jobName, runId,"Vacuum",table_name,startTime.toString,endTime.toString,"Completed","NA"), jobLogTable)
  println(s"${LocalDateTime.now()}: Vacuum completed for ${vaccum_table}.")
  } catch {
    case e: Throwable => println("Performing Vacuum Failed" + e)
    persistLog(JobLogPerTable(jobId,groupId.toLong, jobName, runId,"Vacuum",table_name,startTime.toString,startTime.toString,"Failed","VACUUM Failed -"+e), jobLogTable)
    
    }
 
}

// COMMAND ----------

// DBTITLE 1,defining Main Method

def startOptimizeMain(jobname:String, groupId:Integer):Unit ={   //table convert to string, remove job id 
  
  var currentTimeStart = System.currentTimeMillis   
  var startTime = (new java.util.Date(currentTimeStart)).toString
 // spark.sql(s"insert into ${jobStatusLog} values(${jobId},${groupId},'${jobName}',${runId},'${startTime}','NA','Running')")
  val optimizeconfigtableList= getTableList(groupId).par
  val taskSupport = new ForkJoinTaskSupport(new ForkJoinPool(parallelthreads))
  optimizeconfigtableList.tasksupport = taskSupport
  optimizeconfigtableList.foreach( config =>{
    
    var table_name = config.database_name +"." + config.table_name
    var zorderby_col= config.z_orderby_column
    var retention_hrs_vacuum = config.retain_hours_vacuum 
    var partition_col= config.partition_col
  
      
    doOptimize(table_name,zorderby_col,partition_col,groupId)
   if(retention_hrs_vacuum != null){   
     doVaccum(table_name,retention_hrs_vacuum,groupId) 
   }else{
     println("Vacuum cannot will not be performed since retention period is empty")
   }
  })
  
   var currentTimeEnd = System.currentTimeMillis   //6: 25
  var endTime = (new java.util.Date(currentTimeEnd)).toString
  spark.sql(s"update ${jobStatusLog} set status='Completed',end_time='${endTime}' where job_id=${jobId} and group_id=${groupId} and run_id=${runId}")
  println("optimization job completed :Start_time - " +startTime+ " :End_time - " +endTime)
}

// COMMAND ----------

// DBTITLE 1,Call Main Method
//Calling the main function
startOptimizeMain(jobName,groupId)

