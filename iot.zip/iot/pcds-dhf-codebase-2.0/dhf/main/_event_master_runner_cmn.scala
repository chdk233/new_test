// Databricks notebook source
// MAGIC %md
// MAGIC ####Arguments : 
// MAGIC 
// MAGIC ######1. task_group_id  -> Pass comma separated task_group_id. If nothing is passed, all task groups Id will be consideed and jobs will be submitted for each of them if they are not running already
// MAGIC ######2. job_type  
// MAGIC ###### ----->select appropriate job_type that you want to submit
// MAGIC ###### ----->if ALL is selected, it will submit job for all pipelines        

// COMMAND ----------

// DBTITLE 1,Import libraries
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.types._

import org.apache.spark.sql.functions._
import java.util.Date
import java.util.Properties
import scala.sys.process._
import java.sql.Timestamp
import java.time.LocalDate
import scala.collection.mutable.ListBuffer




// COMMAND ----------

dbutils.widgets.removeAll()
//dbutils.widgets.text( "group_id", "", "Group_id")
dbutils.widgets.dropdown("job_type", "ALL", Seq("harmonization","data_curation","warehouse_sync","ALL"), "job_type")
// dbutils.widgets.dropdown("environment", "dev", Seq("dev", "test","prod"), "environment")
dbutils.widgets.text( "group_id", "", "group_id")


//val groupid=dbutils.widgets.get("group_id").toString
val job_type=dbutils.widgets.get("job_type").toString.toUpperCase
// val environment=dbutils.widgets.get("environment").toString
val group_id=dbutils.widgets.get("group_id").toString.trim()

// COMMAND ----------

// DBTITLE 1,Defining environment variable
val browserHostName = dbutils.notebook.getContext.tags.getOrElse("browserHostName","none")
var environment =""

if(browserHostName.contains("-dev-"))
{
environment="dev"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-test-"))
{
environment="test"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-prod-"))
{
environment="prod"
  println("environment is set to : " + environment)
}

// COMMAND ----------

// DBTITLE 1,Run utils notebook
// MAGIC %run ../utils/_utils

// COMMAND ----------

// DBTITLE 1,Set Job level properties
//var metricsLogTable = s"${dbName}.harmonize_metrics"

var metricsLogTable = ""
if(job_type == "HARMONIZATION"){
  metricsLogTable = s"dhf_logs_${environment}.harmonize_metrics"
}else if(job_type == "DATA_CURATION"){
  metricsLogTable = s"dhf_logs_${environment}.curation_metrics"
}else if(job_type == "WAREHOUSE_SYNC"){
  metricsLogTable = s"dhf_logs_${environment}.warehouse_sync_metrics"
}
/*
if(job_type == "HARMONIZATION"){
  metricsLogTable = s"dhf2_config.harmonize_metrics"
}else if(job_type == "DATA_CURATION"){
  metricsLogTable = s"dhf2_config.curation_metrics"
}else if(job_type == "WAREHOUSE_SYNC"){
  metricsLogTable = s"dhf2_config.warehouse_sync_metrics"
}
*/
val cdcJobCreationLogTable    = s"dhf_logs_${environment}.e2h_job_creation_log"
//val cdcJobCreationLogTable    = s"dhf2_config.e2h_job_creation_log"
val checkpoint_dir            = s"dbfs:/user/hive/warehouse/dhf_${environment}/checkpoint_dir"
//val readtablefromdate         ="" 
//val dbNamedelta                    ="dhf2_phase2_test_${environment}"


// COMMAND ----------

// DBTITLE 1,Initialization global variable
var jobExists: Boolean = false
var jobid: Long = 0
val baseFilePath = s"/Repos/dhfsid@nationwide.com/pcds-dhf-${environment}-2.0/dhf/main/"
val substr = s"main/"
var currentNotebook = dbutils.notebook.getContext.notebookPath.getOrElse("_event_master_runner_cmn") //.split("/").toList
//println(currentNotebook.replace("_event_master_runner","harmonization_2.0"))
var notebookPath =""
if(job_type == "HARMONIZATION"){
val currentPath = currentNotebook.replace("_event_master_runner_cmn","harmonization/harmonization_2.0")
val appendPath = currentPath.substring(currentPath.indexOf(substr) + substr.length())
notebookPath = if(s"${environment}" == "dev") currentPath else baseFilePath + appendPath
//notebookPath=currentNotebook.replace("_event_master_runner_cmn","harmonization/harmonization_2.0")
}else if(job_type == "DATA_CURATION"){
val currentPath = currentNotebook.replace("_event_master_runner_cmn","curation_2.0")
val appendPath = currentPath.substring(currentPath.indexOf(substr) + substr.length())
notebookPath = if(s"${environment}" == "dev") currentPath else baseFilePath + appendPath
}
//currentNotebook.foreach(x => if(x!= currentNotebook.last && x!="") notebookPath= notebookPath+"/"+x)
//notebookPath=notebookPath+"/harmonization_2.0"
val clusterId=dbutils.notebook.getContext.tags.getOrElse("clusterId","none")
var assumeRole = ""
var iamRole = ""
var passed_jobs_list = new ListBuffer[String]()
var failed_jobs_list = new ListBuffer[String]()


if(environment == "dev"){
  iamRole = "arn:aws:iam::786994105833:instance-profile/pcds-hrmonzpoc-devdw01-trustingrole"  
  assumeRole = "arn:aws:iam::786994105833:role/pcds-databricks-common-access"
}else if(environment == "test"){
  iamRole = "arn:aws:iam::168341759447:instance-profile/pcds-hrmonzpoc-testdw01-trustingrole"
  assumeRole = "arn:aws:iam::168341759447:role/pcds-databricks-common-access"  
}else if(environment == "prod"){
  iamRole = "arn:aws:iam::785562577411:instance-profile/pcds-hrmonzpoc-proddw01-trustingrole"
  assumeRole = "arn:aws:iam::785562577411:role/pcds-databricks-common-access" 
} 


// COMMAND ----------

// DBTITLE 1,Define case class
case class JobCreationLogClass(job_name: String,job_id: Long,run_id: Long, cluster_id: String, group_id: Long, job_type: String,run_type: String )
case class groupIdListCC(id: Long,job_type: String, run_type: String)

// COMMAND ----------

// DBTITLE 1,Method to validate jobid
def validateJobId(jobid: Long,group_id: Long)  = {   
    println(s"In validateJobId function")
    val resp=Seq("curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/get?job_id=$jobid" ).!!    
    if(resp.contains("INVALID_PARAMETER_VALUE")) {
      val msg=s"""Invalid job ID in job_creation_log table for group_id: ${group_id}. Please correct/delete the job ID in job_creation_log table and resubmit"""
      println(msg)     
      throw new Exception(msg)
    }
    else {
      println(s"Job id is valid for group_id: ${group_id}")
      jobExists= true
    }
  
}

// COMMAND ----------

// DBTITLE 1,Method to check job status 
def checkIfRunningOrPendingStatus(jobid: Long,group_id: Long): Boolean = { 
    println(s"In checkIfRunningOrPendingStatus function")
    val runningStateArray=spark.read.json(Seq(Seq(
                                "curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/runs/list?job_id=$jobid" ).!!).toDS)      
                                .select(explode($"runs"))
                                .select("col.state.life_cycle_state")
                                .filter("life_cycle_state ='RUNNING' OR life_cycle_state ='PENDING' ")
                                .distinct
                                .collect()

    if(runningStateArray.size >=1) {
      println(s"group_id: ${group_id} :: Job associated is already in either RUNNING or PENDING status")    
      return true
    }  
    else {
      println(s"group_id: ${group_id} :: The job is NOT in RUNNING or PENDING state. Run-now will be invoked")  
      return false
    }
}

// COMMAND ----------

// DBTITLE 1,Create job and run
def createJobAndRun(run_type: String, group_id: Long, jobName: String) = {        
     val pushdown_query_for_job = s""" SELECT job_id FROM ${cdcJobCreationLogTable} WHERE group_id=${group_id} limit 1 """
     val jobidArray = spark.sql(pushdown_query_for_job).as[Long].collect 
  
     if(jobidArray.size == 1){
          println(s"Job ID exists for group_id ${group_id}")
          jobid=jobidArray(0)
          validateJobId(jobid,group_id)
      } else {
             jobExists=false
             jobid=0
             println(s"group_id: ${group_id} :: Job ID does not exist. New job will be created")
     }
  
     val runningOrPendingStatus=if(jobExists) checkIfRunningOrPendingStatus(jobid,group_id) else false
 
     try{

            if(jobExists && !runningOrPendingStatus) { 
                println("Im here1")
                val jsonForExistingJobid = s"""
                    {
                       "job_id": ${jobid}
                    }
                  """

             val runid=spark.read.json(Seq( Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForExistingJobid",s"$dbhost/api/2.0/jobs/run-now" ).!! ).toDS).select("run_id").as[Long].collect.head         
              
             println(s"runid is ${runid} for jobid ${jobid}: group_id ${group_id} : jobName: ${jobName}")
              
              
             val logDF=Seq(JobCreationLogClass(jobName,jobid,runid,clusterId, group_id,job_type,run_type )).toDF.withColumn("created", current_timestamp())            
             logDF.coalesce(1).write.format("delta").mode("append").saveAsTable(s"${cdcJobCreationLogTable}")              
              

            } else if(!jobExists){
                  println("Im here2")
                  //println(s"Im here2 job_type ${job_type}")

                  val groupIdObj: Group = getGroup(group_id)
                  println("getGroupId function call completed")
                  val numWorkers          = getPropertyValue("numWorkers", groupIdObj.cluster_config)  //2
                  val sparkVersion        = getPropertyValue("sparkVersion", groupIdObj.cluster_config)  //"7.2.x-scala2.12"
                  
                   if(job_type == "WAREHOUSE_SYNC"){
                      val appendPath = groupIdObj.handler_path.substring(groupIdObj.handler_path.indexOf(substr) + substr.length())
                        notebookPath = if(s"${environment}" == "dev") groupIdObj.handler_path else baseFilePath + appendPath
                    //notebookPath = groupIdObj.handler_path
                    }
                   //val run_type            = run_type
                  //val notebookPath= groupIdObj.handler_path // TBD: extend this to other job_types where the notebook path will be standard.
                  //var notebookPath=""
                  //if(run_type=="ROUND_THE_CLOCK"){
                    // notebookPath= "/Repos/dhfsid@nationwide.com/pcds-dhf-${environment}-2.0/dhf/main/harmonization/harmonization_2.0"
                       //notebookPath= "/Repos/singho1@nationwide.com/dhf_2.0_dev_om/dhf/main/harmonization/harmonization_2.0"
                   // }
                   // else{
                     //  notebookPath= "/Repos/dhfsid@nationwide.com/pcds-dhf-${environment}/dhf/main/harmonization_batch_2.0"
                     //  notebookPath= "/Repos/singho1@nationwide.com/pcds-dhf-codebase-pg-nb/dhf/main/phase2/harmonization_batch_2.0"
                    //}
                 
                  
                  println(s"numWorkers is ${numWorkers}")
                  println(s"sparkVersion is ${sparkVersion}")
                  println(s"run_type is ${run_type}")
                  println(s"notebookPath is ${notebookPath}")
                  //println(s"maxBytesPerTrigger is ${maxBytesPerTrigger}")
              
              
                  val currentDate = LocalDate.now().toString
                  println(s"currentDate is ${currentDate}")
 

                  val jsonForNewJobApi = s"""
                  {
                  "name": "${jobName}",
                  "new_cluster": {
                          "spark_version": "${sparkVersion}",
                          "node_type_id": "i3.xlarge",
                          "driver_node_type_id": "i3.xlarge",
                          "num_workers": ${numWorkers},
                          "aws_attributes": {
                                  "first_on_demand": 1,
                                  "availability": "SPOT_WITH_FALLBACK",
                                  "zone_id": "auto",
                                  "instance_profile_arn": "${iamRole}",
                                  "spot_bid_price_percent": 100,
                                  "ebs_volume_type": "GENERAL_PURPOSE_SSD",
                                  "ebs_volume_count": 3,
                                  "ebs_volume_size": 100                 
                          },

                          "init_scripts": [],
                          "custom_tags": {
                                   "APRMID" : "8475",
                                   "ResourceOwner" : "dhfsid@nationwide.com",
                                   "Created" : "${currentDate}",
                                   "Patch" : "False", 
                                   "PowerOnInstanceAt" : "False",
                                   "ShutDownInstanceAt" : "False",
                                   "DisbursementCode" : "303500001",
                                   "SecurityException" : "n/a",
                                   "ResourceName" : "DHF Job Cluster",
                                   "DataClassification" : "public",
                                   "Project" : "Data Harmonization Framework",
                                   "Alert" : "False",
                                   "Team" : "PnC Data Platform"
                          },
                          "cluster_log_conf": {
                             "dbfs": {
                                  "destination": "dbfs:/cluster-logs"
                            }
                          },                          
                          "spark_env_vars": {
                                  "AWS_STS_REGIONAL_ENDPOINTS": "\\\"regional\\\""
                          }
                   },

                   "notebook_task": {
                          "base_parameters": {
                                            "groupId": "${group_id}",
                                            "environment": "${environment}",                                            
                                            "metricsLogTable": "${metricsLogTable}", 
                                            "checkpoint_dir": "${checkpoint_dir}"                                
                                            },
                          "notebook_path": "${notebookPath}"
                   }, 
                   
                   "email_notifications": {
                          "on_start": [],
                          "on_success": [],
                          "on_failure": []
                   },          
                   "max_retries": 1

                  } """
              
                  println(s"jsonForNewJobApi is ${jsonForNewJobApi}")    
              
                  val api_out = Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewJobApi",s"$dbhost/api/2.0/jobs/create" ).!!
              
                  print(s"Jobs API Output: ")
                  print(api_out)
              
                  if (!api_out.contains("error_code")){
                      val newJobId=spark.read.json(Seq(api_out).toDS).select('job_id).as[Long].collect.head  
              
                      println(s"JobId ${newJobId} created for group_id ${group_id} : jobName: ${jobName}")

                      val jsonForRunNow = s"""
                                            {
                                               "job_id": ${newJobId}
                                            }
                                            """


                      val jsonForPermissionApi = s"""
                                            {  
                                               "access_control_list": [
                                                  {
                                                      "group_name":"PCDS_Admin",
                                                      "permission_level":"CAN_MANAGE"
                                                  },
                                                  {
                                                      "group_name":"PCDS_Arch",
                                                      "permission_level":"CAN_VIEW"
                                                  },
                                                  {
                                                      "group_name":"PCDS_${environment}",
                                                      "permission_level":"CAN_MANAGE"
                                                  }
                                               ]
                                            }
                                            """

                      Seq("curl", "-X","PATCH","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForPermissionApi",s"$dbhost/api/2.0/permissions/jobs/$newJobId" ).!!                   

                      val runid=spark.read.json(Seq(Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForRunNow",s"$dbhost/api/2.0/jobs/run-now" ).!!).toDS).select("run_id").as[Long].collect.head 

                      println(s"runid is ${runid} for jobid ${newJobId} : group_id ${group_id} : jobName: ${jobName}")

                      val logDF=Seq(JobCreationLogClass(jobName,newJobId,runid,clusterId, group_id,job_type,run_type )).toDF.withColumn("created", current_timestamp())            
                      logDF.coalesce(1).write.format("delta").mode("append").saveAsTable(s"${cdcJobCreationLogTable}") 
                      passed_jobs_list += s"group_id: ${group_id},  job_response: ${api_out}"
                  } else{
                    val msg=s"""Error while creating job for group_id : ${group_id}"""
                    println(msg + api_out)  
                    failed_jobs_list +=  s"group_id: ${group_id},  job_response: ${api_out}"
                  }                                    
                
            }

     } catch {
            case e: Throwable => 
            println(s"Error in invoking job api for group_id ${group_id} : " + e)        
            throw e
     }
  
  
}

// COMMAND ----------

// DBTITLE 1,Collect task groups
def getGroupIdsToCreateJobs(groupId: String) : List[groupIdListCC] = {  
   
     val whereCond =  s""" WHERE active """ +
                    (if(!groupId.isEmpty) s" and id IN (${groupId}) " else "")
    
    val pushdown_query = s""" (SELECT distinct id , upper(job_type) as job_type,upper(run_type) as run_type FROM job_group_new ${whereCond}) t"""  
    println("pushdown_query is "+pushdown_query)
    //val groupIdList = spark.sql(pushdown_query).as[groupIdListCC].collect.toList 
    val groupIdList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[groupIdListCC].collect.toList
    groupIdList   
}

// COMMAND ----------

// DBTITLE 1,main method to invoke submit job
def masterMain(environment: String) = {   

  val groupIdList = getGroupIdsToCreateJobs(group_id)  
  println(s"groupIdList is ${groupIdList}")
  if(groupIdList.size >=1 ) {
      groupIdList.foreach( groupid => {          
             try {
                     var jobName=""
                     if(job_type == "HARMONIZATION"){
                        jobName = s"${environment}_DHF_HARMONIZATION_${groupid.run_type}_GROUPID_${groupid.id}".toUpperCase
                        }else if(job_type == "DATA_CURATION"){
                        jobName = s"${environment}_DHF_DATA_CURATION_${groupid.run_type}_GROUPID_${groupid.id}".toUpperCase
                        }else if(job_type == "WAREHOUSE_SYNC"){
                        jobName = s"${environment}_DHF_WAREHOUSESYNC_${groupid.run_type}_GROUPID_${groupid.id}".toUpperCase
                        }
                   createJobAndRun(groupid.run_type,groupid.id, jobName )
             } catch {      
                   case e : Throwable => {
                                    e.printStackTrace
                                    val msg=s"""Error while creating job for group_id : ${groupid.id}"""
                                    println(msg+e)  
                                    throw e
                   }
            }  
      })
  }
  else println(s"There is no group id available in config table")
}

// COMMAND ----------

// DBTITLE 1,Call main method
masterMain(environment)

// COMMAND ----------

display( passed_jobs_list.toDF())

// COMMAND ----------

display( failed_jobs_list.toDF())
