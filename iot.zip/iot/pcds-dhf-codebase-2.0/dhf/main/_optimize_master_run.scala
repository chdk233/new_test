// Databricks notebook source
// DBTITLE 1,Import libraries
import spark.implicits._
import org.apache.spark.sql._
import org.apache.spark.sql.types._

import org.apache.spark.sql.functions._
import java.util.Date
import java.util.Properties
import scala.sys.process._
import java.sql.Timestamp
import java.time.LocalDate
import scala.collection.mutable.ListBuffer

// COMMAND ----------

dbutils.widgets.removeAll()
// dbutils.widgets.dropdown("environment", "dev", Seq("dev", "test","prod"), "environment")
dbutils.widgets.text( "group_id", "", "group_id")

// val environment=dbutils.widgets.get("environment").toString
val groupId=dbutils.widgets.get("group_id").toString.trim()

// COMMAND ----------

// DBTITLE 1,Defining evironment Variable
val browserHostName = dbutils.notebook.getContext.tags.getOrElse("browserHostName","none")
var environment =""

if(browserHostName.contains("-dev-"))
{
environment="dev"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-test-"))
{
environment="test"
  println("environment is set to : " + environment)
}else if(browserHostName.contains("-prod-"))
{
environment="prod"
  println("environment is set to : " + environment)
}

// COMMAND ----------

// DBTITLE 1,Run utils notebook
// MAGIC %run ../utils/_utils

// COMMAND ----------

// DBTITLE 1,Initialization global variable
var jobExists: Boolean = false
var jobid: Long = 0
//val currentNotebook = dbutils.notebook.getContext.notebookPath.getOrElse("_optimize_master").split("/").last
var currentNotebook = dbutils.notebook.getContext.notebookPath.getOrElse("_optimize_master_run") //.split("/").toList
//println(currentNotebook.replace("_event_master_runner","harmonization_2.0"))
var notebookPath =currentNotebook.replace("_optimize_master_run","_event_optimization")
val clusterId=dbutils.notebook.getContext.tags.getOrElse("clusterId","none")
var assumeRole = ""
var iamRole = ""
var passed_jobs_list = new ListBuffer[String]()
var failed_jobs_list = new ListBuffer[String]()
//val optimizeConfigTable = s"${dbName}.dhf_delta_optimize_config"
val jobLogTable = s"dhf_logs_${environment}.dhf_delta_optimize_metrics_log"
val jobStatusLog= s"dhf_logs_${environment}.dhf_delta_optimize_job_creation_log"
//val dbName = "dhf2_phase1_test"

//val maxBytesPerTrigger        = "1g"
//val maxOffsetsPerTrigger      = "1000000"


if(environment == "dev"){
  iamRole = "arn:aws:iam::786994105833:instance-profile/pcds-hrmonzpoc-devdw01-trustingrole"  
  assumeRole = "arn:aws:iam::786994105833:role/pcds-databricks-common-access"
}else if(environment == "test"){
  iamRole = "arn:aws:iam::168341759447:instance-profile/pcds-hrmonzpoc-testdw01-trustingrole"
  assumeRole = "arn:aws:iam::168341759447:role/pcds-databricks-common-access" 
}else if(environment == "prod"){
  iamRole = "arn:aws:iam::785562577411:instance-profile/pcds-hrmonzpoc-proddw01-trustingrole"
  assumeRole = "arn:aws:iam::785562577411:role/pcds-databricks-common-access" 
} 

// COMMAND ----------

case class JobCreationLogTable(job_id: Long, group_id: Long, job_name: String,run_id: Long, start_time: String ,end_time : String,status: String)

def persistLog(jobMetrics: JobCreationLogTable, logTable: String)  = {   
      Seq(jobMetrics)
        .toDS  
        .coalesce(1)
        .write
        .format("delta")
        .mode("append")
        .saveAsTable(s"${logTable}") 
}

// COMMAND ----------

def validateJobId(jobid: Long,groupId: Long)  = {  
    println(s"In validateJobId function")
    val resp=Seq("curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/get?job_id=$jobid" ).!!   
    if(resp.contains("INVALID_PARAMETER_VALUE")) {
      val msg=s"""Invalid job ID in dhf_delta_optimize_job_log table for groupId: ${groupId}. Please correct/delete the job ID in job_creation_log table and resubmit"""
      println(msg)    
      throw new Exception(msg)
    }
    else {
      println(s"Job id is valid for groupId: ${groupId}")
      jobExists= true
    }
 
}

// COMMAND ----------

def checkIfRunningOrPendingStatus(jobid: Long,groupId: Long): Boolean = { 
    println(s"In checkIfRunningOrPendingStatus function")
    val runningStateArray=spark.read.json(Seq(Seq(
                                "curl", "-X","GET","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}",s"$dbhost/api/2.0/jobs/runs/list?job_id=$jobid" ).!!).toDS)      
                                .select(explode($"runs"))
                                .select("col.state.life_cycle_state")
                                .filter("life_cycle_state ='RUNNING' OR life_cycle_state ='PENDING' ")
                                .distinct
                                .collect()

    if(runningStateArray.size >=1) {
      println(s"group_id: ${groupId} :: Job associated is already in either RUNNING or PENDING status")    
      return true
    }  
    else {
      println(s"group_id: ${groupId} :: The job is NOT in RUNNING or PENDING state. Run-now will be invoked")  
      return false
    }
}

// COMMAND ----------

// DBTITLE 1,fetch table list from config tables
def fetchOptimizeConfigGroupId(): List[Long] = {   
    println(s"In fetchOptimizeConfigTables function")
      val whereCond =  s""" WHERE active and job_type=\'DELTA_OPTIMIZATION\' """ +
                    (if(!groupId.isEmpty) s" and Id IN (${groupId}) " else "")
  
     val pushdown_query = s"""( SELECT distinct(Id)  FROM job_group_new ${whereCond} ) t """
 
     //val tableGrpIdList = spark.sql(pushdown_query_for_grpId).as[Integer].collect.toList
    val taskGroupList = spark.read.jdbc(url=jdbcUrlForConfigDB, table=pushdown_query, properties=sqlConnectionProperties).as[Long].collect.toList 
                               
     
  taskGroupList
  
}

// COMMAND ----------

// DBTITLE 1,empty check method
def  isEmptyList(tableGroupIdList: List[Long]) ={
  if(tableGroupIdList.isEmpty ) {
    println("table group Id list is empty: ")
        false
    }  
    else{
          true
        }
}

// COMMAND ----------

// DBTITLE 1,Create job and run
def createJobAndRun(groupId: Long, jobName: String) = {        
          
  //val numWorkers          ="2" 
  //val sparkVersion        ="7.2.x-scala2.12"
  //val notebookPath=  s"/Repos/dhfsid@nationwide.com/pcds-dhf-${environment}-2.0/dhf/main/_event_optimization"
  //val notebookPath = s"/Repos/singho1@nationwide.com/dhf_2.0_dev_om/dhf/main/_event_optimization"
  val groupIdObj: Group = getGroup(groupId)
  println("getGroupId function call completed")
  val numWorkers          = getPropertyValue("numWorkers", groupIdObj.cluster_config)  //2
  val sparkVersion        = getPropertyValue("sparkVersion", groupIdObj.cluster_config) 

  println(s"numWorkers is ${numWorkers}")
  println(s"sparkVersion is ${sparkVersion}")
  println(s"notebookPath is ${notebookPath}")
  //println(s"maxBytesPerTrigger is ${maxBytesPerTrigger}")             
  val currentDate = LocalDate.now().toString
  println(s"currentDate is ${currentDate}")
 
  val pushdown_query_for_job = s""" SELECT job_id FROM  ${jobStatusLog} WHERE group_id=${groupId} limit 1 """
  
     val jobidArray = spark.sql(pushdown_query_for_job).as[Long].collect 
  
     if(jobidArray.size == 1){
          println(s"Job ID exists for group Id ${groupId}")
          jobid=jobidArray(0)
          validateJobId(jobid,groupId)
      } else {
             jobExists=false
             jobid=0
             println(s"GroupId: ${groupId} :: Job ID does not exist. New job will be created")
     }
  
  val runningOrPendingStatus=if(jobExists) checkIfRunningOrPendingStatus(jobid,groupId) else false
  try{
        if(jobExists && !runningOrPendingStatus) {
                val jsonForExistingJobid = s"""
                    {
                       "job_id": ${jobid}
                    }
                  """

             val runid=spark.read.json(Seq( Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForExistingJobid",s"$dbhost/api/2.0/jobs/run-now" ).!! ).toDS).select("run_id").as[Long].collect.head  
          var currentTimeStart = System.currentTimeMillis   //6: 25
          var startTime = (new java.util.Date(currentTimeStart)).toString
           val logDF=Seq(JobCreationLogTable(jobid,groupId,jobName,runid,startTime,"","Running")).toDF
                      logDF.coalesce(1).write.format("delta").mode("append").saveAsTable(jobStatusLog)
              
             println(s"runid is ${runid} for jobid ${jobid}: GroupId ${groupId} : jobName: ${jobName}")
      
    } else if(!jobExists){
           println(s"Creating new job -- ${jobName} ")
                  val jsonForNewJobApi = s"""
                  {
                  "name": "${jobName}",
                  "new_cluster": {
                          "spark_version": "${sparkVersion}",
                          "node_type_id": "i3.xlarge",
                          "driver_node_type_id": "i3.xlarge",
                          "num_workers": ${numWorkers},
                          "aws_attributes": {
                                  "first_on_demand": 1,
                                  "availability": "SPOT_WITH_FALLBACK",
                                  "zone_id": "auto",
                                  "instance_profile_arn": "${iamRole}",
                                  "spot_bid_price_percent": 100,
                                  "ebs_volume_type": "GENERAL_PURPOSE_SSD",
                                  "ebs_volume_count": 3,
                                  "ebs_volume_size": 100                 
                          },

                          "init_scripts": [],
                          "custom_tags": {
                                   "APRMID" : "8475",
                                   "ResourceOwner" : "dhfsid@nationwide.com",
                                   "Created" : "${currentDate}",
                                   "Patch" : "False", 
                                   "PowerOnInstanceAt" : "False",
                                   "ShutDownInstanceAt" : "False",
                                   "DisbursementCode" : "303500001",
                                   "SecurityException" : "n/a",
                                   "ResourceName" : "DHF Job Optimization Cluster",
                                   "DataClassification" : "public",
                                   "Project" : "Data Harmonization Framework",
                                   "Alert" : "False",
                                   "Team" : "PnC Data Platform"
                          },
                          "cluster_log_conf": {
                             "dbfs": {
                                  "destination": "dbfs:/cluster-logs"
                            }
                          },                          
                          "spark_env_vars": {
                                  "AWS_STS_REGIONAL_ENDPOINTS": "\\\"regional\\\""
                          }
                   },

                   "notebook_task": {
                          "base_parameters": {
                                            "groupId": "${groupId}",
                                            "jobName": "${jobName}",
                                            "environment": "${environment}",                                            
                                            "jobLogTable": "${jobLogTable}",
                                            "jobStatusLog": "${jobStatusLog}",
                                            "environment": "${environment}"
                                            },
                          "notebook_path": "${notebookPath}"
                   },
                   "email_notifications": {
                          "on_start": [],
                          "on_success": [],
                          "on_failure": []
                   },          
                   "max_retries": 1

                  } """
              
                  println(s"jsonForNewJobApi is ${jsonForNewJobApi}")    
              
                  val api_out = Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForNewJobApi",s"$dbhost/api/2.0/jobs/create" ).!!
              
                  print(s"Jobs API Output: ")
                  print(api_out)
              
                  if (!api_out.contains("error_code")){
                      val newJobId=spark.read.json(Seq(api_out).toDS).select('job_id).as[Long].collect.head  
              
                      println(s"JobId ${newJobId} created for  jobName: ${jobName}")

                      val jsonForRunNow = s"""
                                            {
                                               "job_id": ${newJobId}
                                            }
                                            """


                      val jsonForPermissionApi = s"""
                                            {  
                                               "access_control_list": [
                                                   {
                                                      "group_name":"PCDS_Admin",
                                                      "permission_level":"CAN_MANAGE"
                                                  },
                                                  {
                                                      "group_name":"PCDS_Arch",
                                                      "permission_level":"CAN_VIEW"
                                                  },
                                                  {
                                                      "group_name":"PCDS_${environment}",
                                                      "permission_level":"CAN_MANAGE"
                                                  }
                                               ]
                                            }
                                            """

                      Seq("curl", "-X","PATCH","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForPermissionApi",s"$dbhost/api/2.0/permissions/jobs/$newJobId" ).!!                   

                      val runid=spark.read.json(Seq(Seq("curl", "-X","POST","-H",s"Authorization: Bearer $token","-H",s"X-Databricks-Org-Id: ${workspaceID}","-d", s"$jsonForRunNow",s"$dbhost/api/2.0/jobs/run-now" ).!!).toDS).select("run_id").as[Long].collect.head 
                    
                     var currentTimeStart = System.currentTimeMillis   //6: 25
                     var startTime = (new java.util.Date(currentTimeStart)).toString
                    val logDF=Seq(JobCreationLogTable(newJobId,groupId,jobName,runid,startTime,"","Running")).toDF
                      logDF.coalesce(1).write.format("delta").mode("append").saveAsTable(jobStatusLog)

                      println(s"runid is ${runid} for jobid ${newJobId} : jobName: ${jobName}")
                    
                       passed_jobs_list += s"jobName: ${jobName},  job_response: ${api_out}"

                  } else{
                    val msg=s"""Error while creating job for jobName: ${jobName}"""
                    println(msg + api_out)  
                    failed_jobs_list +=  s"jobName: ${jobName},  job_response: ${api_out}"
                  }
        }

     } catch {
            case e: Throwable => 
            println(s"Error in invoking job api for jobName - ${jobName}: " + e)        
            throw e
     }
  
  
}

// COMMAND ----------

// DBTITLE 1,main method to invoke submit job
def masterMain(environment: String) = {   
   
  val currentdate= LocalDate.now().toString
  val tableGroupIdList = fetchOptimizeConfigGroupId()
  if(isEmptyList(tableGroupIdList)){
  tableGroupIdList.foreach(groupId => {
    
      try {
            createJobAndRun(groupId,s"${environment}_DHF_OPTIMIZATION_GroupId_${groupId}".toUpperCase) //dev_DHF_OPTIMIZATION_3_200_2021-10-8 
             } catch {      
                   case e : Throwable => {
                                    e.printStackTrace
                                    val msg=s"""Error while creating job }"""
                                    println(msg+e)  
                                    throw e
                   }
              }
    
    })
  }
   else println(s"There is NO active groupID for Optimization")
  
}

// COMMAND ----------

masterMain(environment)

// COMMAND ----------

display( passed_jobs_list.toDF())

// COMMAND ----------

display( failed_jobs_list.toDF())
