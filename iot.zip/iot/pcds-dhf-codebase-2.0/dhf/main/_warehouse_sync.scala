// Databricks notebook source
// DBTITLE 1,Import libraries
import spark.implicits._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import java.time.LocalDateTime
import org.apache.spark.sql.streaming.Trigger
import net.snowflake.spark.snowflake.Utils
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit
import org.apache.spark.sql.expressions.Window

// COMMAND ----------

// DBTITLE 1,Set spark conf
spark.conf.set("spark.sql.streaming.stopActiveRunOnRestart", true)

// COMMAND ----------

// DBTITLE 1,Get arguments from widgets
dbutils.widgets.removeAll()
dbutils.widgets.text( "groupId", "1", "GroupID")
//dbutils.widgets.text( "job_type", "EVENT_GENERATION", "job_type")
dbutils.widgets.text( "environment", "dev", "environment") 
dbutils.widgets.text( "metricsLogTable", "", "metricsLogTable")
//dbutils.widgets.text( "incidentLogTable", "", "incidentLogTable")
//dbutils.widgets.text( "maxBytesPerTrigger", "", "maxBytesPerTrigger")
//dbutils.widgets.text( "maxOffsetsPerTrigger", "", "maxOffsetsPerTrigger")
dbutils.widgets.text( "checkpoint_dir", "", "checkpoint_dir")
//dbutils.widgets.text( "readtablefromdate", "", "readtablefromdate")

val groupId=dbutils.widgets.get("groupId").toString.toInt
//val job_type=dbutils.widgets.get("job_type").toString.toUpperCase
val environment=dbutils.widgets.get("environment").toString 
val metricsLogTable=dbutils.widgets.get("metricsLogTable").toString
//val incidentLogTable=dbutils.widgets.get("incidentLogTable").toString
//val maxBytesPerTrigger=dbutils.widgets.get("maxBytesPerTrigger").toString
//val maxOffsetsPerTrigger=dbutils.widgets.get("maxOffsetsPerTrigger").toString
val checkpoint_dir=dbutils.widgets.get("checkpoint_dir").toString
//val readtablefromdate=dbutils.widgets.get("readtablefromdate").toString

println("GroupId in notebook is : "+groupId)
//println("job_type in notebook is : "+job_type)
println("environment in notebook is : "+environment) 
println("metricsLogTable in notebook is : "+metricsLogTable)
//println("incidentLogTable in notebook is : "+incidentLogTable)
//println("maxBytesPerTrigger in notebook is : "+maxBytesPerTrigger)
//println("maxOffsetsPerTrigger in notebook is : "+maxOffsetsPerTrigger)
println("checkpoint_dir in notebook is : "+checkpoint_dir)
//println("readtablefromdate in notebook is : "+readtablefromdate)
val readtablefromdate=""

// COMMAND ----------

// DBTITLE 1,Run utils notebook
// MAGIC %run ../utils/_utils

// COMMAND ----------

//Need to pass the runType to the main function startWarehouseSyncStreamingMain
val warehouseGroup = getGroup(groupId)
var runType        = warehouseGroup.run_type
var job_type       = warehouseGroup.job_type

// COMMAND ----------

// DBTITLE 1,Handle microbatch
class DeltaHandlerClass( 
                      sf_sync_key : String,
                      sf_vwarehouse_warehouse_sync: String,
                      sf_database_warehouse_sync : String,
                      sf_schemaname_warehouse_sync:String,
                      sf_tablename_warehouse_sync : String,
                      sourceDB: String,
                      source: String,
                      target: String,
                      sfUser : String,
                      sfPassword: String,
                      sfURL: String,
                      taskId: Long,
                      job_type: String,
                      job_name: String,
                      run_type: String,
                      minThreshold: Long,
                      maxThreshold: Long,
                      sfType1Merge: Boolean, //added for SCD type1
                      sfType1OrderCol: String, //added for SCD type1
                      maxBytesPerTrigger: String,
                      email_list: String
                    ) extends Serializable {  
  
    val options = Map(
                  "sfURL"         -> sfURL,
                  "sfUser"        -> sfUser,
                  "sfPassword"    -> sfPassword,
                  "sfDatabase"    -> sf_database_warehouse_sync,
                  "sfSchema"      -> sf_schemaname_warehouse_sync,
                  "sfWarehouse"   -> sf_vwarehouse_warehouse_sync
                  )
  
   
    def handleMicroBatch(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long) = {  
      
      try{
                val start = LocalDateTime.now()            
                      
                 //related to threshold
                val min_Threshold = minThreshold
                val max_Threshold = maxThreshold
                //related to threshold
        
                val batchSize = microBatchDF.count
                println(s"batchSize : ${batchSize} for ${sf_tablename_warehouse_sync}, batchId ${batchId}")
        
                print("microBatchDF...in microbatch handler: \n")
                microBatchDF.show(false)
        
                if(batchSize>=1) {    
                  
                         val sf_key = if (microBatchDF.schema.fieldNames.toList.map(_.toLowerCase).contains("surrogatekey")) "surrogatekey" else sf_sync_key  
                        if (sf_key.trim().isEmpty()) {
                            val failMsf = s"Error: No snowflake sync key is specified. Either your harmonized table should have a column called 'surrogatekey', or you should provide a 'sf_sync_key' from configuration. Exiting microbatch handler for  ${sf_tablename_warehouse_sync}, batchId ${batchId}" 
                          throw new Exception(failMsf)
                        } else {
                            var finalDF = microBatchDF
                            if (sfType1Merge) {
                                if(if(sfType1OrderCol==null) true else {if(sfType1OrderCol.length==0) true else false}){
                                  val w = Window.partitionBy(sf_key.split(",").map(colName => col(colName)): _*).orderBy($"_commit_version".desc)
                                  finalDF = microBatchDF.filter('_change_type === "insert" || '_change_type === "update_postimage")
                                            .withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
                                            .drop("_change_type").drop("_commit_version").drop("_commit_timestamp")
                                }  else {
                                  val w = Window.partitionBy(sf_key.split(",").map(colName => col(colName)): _*).orderBy(col(sfType1OrderCol.trim()).desc)
                                  finalDF = microBatchDF 
                                            .withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
                                           
                                }
                            }
                            finalDF.show(false)
                            val allCols = finalDF.schema.fieldNames.toList.map(_.toLowerCase)
                          
                            val targetAlias = "tgt"
                            val updatesAlias = "stg"
                            // added lines to form join conditions from sf_key
                            val sfCols= sf_key.split(",") 
                            val join_sf_key=sfCols.map(x => {
                                targetAlias+"."+x.trim()+  "=" + updatesAlias+"."+x.trim()    
                                } ).mkString(" AND ")
                            
                            println(s"Column used for Snowflake Sync Merge is: ${sf_key}")
                            
                            val updateCols=allCols.map(x => {
                              targetAlias+"."+x+ "=" + updatesAlias+"."+x    
                            } ).mkString(",")
                            val insertValues=allCols.map(x => { 
                              updatesAlias+"."+x    
                            } ).mkString(",")

                            finalDF.write
                                  .format("snowflake")
                                  .options(options).option("dbtable", s"stg_${sf_tablename_warehouse_sync}")
                                  .mode("overwrite")
                                  .save()
                            // modified the ON condition
                            val mergeQuery=s"""
                                              MERGE INTO ${sf_tablename_warehouse_sync} tgt
                                              USING stg_${sf_tablename_warehouse_sync} stg
                                              ON ${join_sf_key}
                                              WHEN MATCHED THEN UPDATE SET ${updateCols}               
                                              WHEN NOT MATCHED THEN INSERT (${allCols.mkString(",")}) VALUES (${insertValues}) 
                                            """

                            println("mergeQuery:" + mergeQuery)
                            Utils.runQuery(options,mergeQuery)                  
                            println("merge completed")                           
                        }
                } else println(s"NO DATA in microbatch for  ${sf_tablename_warehouse_sync}, batchId ${batchId}") 
        
                val totalTimeBatchMin  = ChronoUnit.MINUTES.between(start, LocalDateTime.now()) 
                
                println(s"Total batch time for ${sf_tablename_warehouse_sync}, batchId ${batchId} is: ${totalTimeBatchMin} min")
                
                  warehousePersistLog(WarehousePerBatch(groupId.toString, jobId.toString, job_type, run_type, runId, batchId, batchSize, totalTimeBatchMin.toString, start.toString, taskId, source, target, clusterId), metricsLogTable) 
                  
                  //post log info to splunk
                  sendToSplunk(groupId.toString, jobId, job_name, "WAREHOUSE_SYNC", run_type, runId, batchId, batchSize, start.toString, totalTimeBatchMin.toString, 0, taskId, source, target, clusterId, "Success")
              
                  // check batch timing and send an email if it breaches min threshold and create a ticket if it breaches max threshold
                  if(totalTimeBatchMin > min_Threshold){
                       if(totalTimeBatchMin > max_Threshold){
                          println("Max Threshold Breached. Generating snow ticket and Sending Email..")
                          errorHandler("maxThreshold",job_name,groupId,jobId,job_type,runId,batchId,max_Threshold,min_Threshold,totalTimeBatchMin.toString,0,taskId,"NA", email_list)
                          
                       }
                       else{
                           println("Min Threshold hold breached. sending email...") //email notebook
                          errorHandler("minThreshold",job_name,groupId,jobId,job_type,runId,batchId,max_Threshold,min_Threshold,totalTimeBatchMin.toString,0,taskId,"NA", email_list)
                           
                       }
                  }                  
        
      } catch {
                case e:Exception => {
                  
                  println(s"MERGE FAILED for Warehouse table: ${target}, batchId ${batchId}" + e)
                  
                  //post log info to splunk for failed batches
                  sendToSplunk(groupId.toString, jobId, job_name, "WAREHOUSE_SYNC", run_type, runId, batchId, 0, LocalDateTime.now().toString, "0", 0, taskId, source, target, clusterId, "Failed")
                  errorHandler("exception",job_name,groupId,jobId,job_type,runId, batchId,0,0,"0",0,taskId,e.toString.replace("\n", " "), email_list)
                
                  //incidentPersistLog(SnowIncident(ticketNum, "Warehouse_sync", jobId.toString, runId, taskGroupId.toString, "NA", taskId.toString, LocalDateTime.now().toString, description), incidentLogTable) 
                  //throw new Exception(description)
                }  
      }
      
    }
}

// COMMAND ----------

// DBTITLE 1,Define streaming main method

def startWarehouseSyncStreamingMain( groupId: Int, runType: String, job_type: String,environment: String)  = {

      //val taskGroup                = getTaskGroup(taskGroupId,job_type)
      //val run_type                 = taskGroup.run_type
      //val property_values          = getConfig(taskGroup.domain_source_id)
      //val secret_scope             = getPropertyValue("secret_scope", property_values)
      //val secret_sf_user           = getPropertyValue("secret_sf_user", property_values)
      //val secret_sf_password       = getPropertyValue("secret_sf_password", property_values)//
      //val sfURL                    = getPropertyValue("sf_url", property_values)
  
      //Un comment to test warehouse from delta config table
      /*val warehouseConfig           = getWarehouseConfig(environment)
      var secret_scope              = warehouseConfig.secret_scope  
      var secret_sf_user            = warehouseConfig.secret_sf_user 
      var secret_sf_password        = warehouseConfig.secret_sf_password 
      var sfURL                     = warehouseConfig.sfURL 
      val sfUser                    = dbutils.secrets.get(scope = secret_scope, key = secret_sf_user)
      val sfPassword                = dbutils.secrets.get(scope = secret_scope, key = secret_sf_password)
      */ 
      
      val warehouseTaskList       = getWarehouseTaskList(groupId) 
  
      if(warehouseTaskList.isEmpty ) {
        throw new Exception(s"No GroupID found for the given group_id ${groupId}. Please check the warehouse task config table")       
      }

      warehouseTaskList.foreach(warehouse => {   
            println(s"warehouse is **${warehouse}**")
            val property_values = getConfig(warehouse.data_domain_id) //(warehouseTaskList.domain_source_id)
            val secret_scope = getPropertyValue("secret_scope", property_values)
            val secret_sf_user = getPropertyValue("secret_sf_user", property_values)
            val secret_sf_password = getPropertyValue("secret_sf_password", property_values)
            val sfURL = getPropertyValue("sf_url", property_values)
            val sfUser = dbutils.secrets.get(scope = secret_scope, key = secret_sf_user)
            val sfPassword = dbutils.secrets.get(scope = secret_scope, key = secret_sf_password)
            //val job_type       = taskGroup.job_type
            //val job_type       =  "WAREHOUSESYNC"
            //val taskGroupId    = warehouse.group_id.toInt  
            //val taskGroupId     = groupId
            //val taskId         = taskConfig.id 
            val taskId          =  warehouse.id
            val source           = warehouse.source_table
            val target           = warehouse.sf_table
            val minThreshold     = warehouse.min_threshold
            val maxThreshold     = warehouse.max_threshold
             
  
            val sf_sync_key                  = if (warehouse.sf_key != null) warehouse.sf_key.replaceAll("\\s", "") else ""   
            val sf_vwarehouse_warehouse_sync = warehouse.sf_warehouse.replaceAll("\\s", "")
            val sf_database_warehouse_sync   = warehouse.sf_database.replaceAll("\\s", "")
            val sf_schemaname_warehouse_sync = warehouse.sf_schema.replaceAll("\\s", "")
            val sf_tablename_warehouse_sync  = warehouse.sf_table.replaceAll("\\s", "")
            val sourceDB                     = warehouse.source_db.replaceAll("\\s", "") 
            //val job_name                     = taskConfig.name 
             //val job_name                     = "DEV_DHF_WAREHOUSE"
             val sfType1Merge = warehouse.sfmerge_type_1
             val sfType1OrderCol =  warehouse.sftype_1_order_by_column //"date"  // taskConfig.sfType1OrderColumn warehouse.ordercolumn
             val maxBytesPerTrigger = warehouse.max_bytes_per_trigger
             val emaillist = warehouse.email_list
        
                  println(s"sfURL is **${sfURL}**")
                  println(s"sfUser is **${sfUser}**")
                  println(s"sf_sync_key is **${sf_sync_key}**")
                  println(s"sf_vwarehouse_warehouse_sync is **${sf_vwarehouse_warehouse_sync}**")
                  println(s"sf_database_warehouse_sync is **${sf_database_warehouse_sync}**")
                  println(s"sf_schemaname_warehouse_sync is **${sf_schemaname_warehouse_sync}**")
                  println(s"sf_tablename_warehouse_sync is **${sf_tablename_warehouse_sync}**")
                  println(s"sfType1Merge is **${sfType1Merge}**")
                  println(s"sfType1OrderCol is **${sfType1OrderCol}**")
        
                  println("sourceDB is "+ sourceDB)

                  val checkPoint               = checkpoint_dir + "/" + environment + "/warehousesync/" + taskId + "/" + source + "/cp001"
                  println("checkPoint is "+ checkPoint)
        
                  val deltaHandler = new DeltaHandlerClass(  
                                            sf_sync_key,
                                            sf_vwarehouse_warehouse_sync,
                                            sf_database_warehouse_sync,
                                            sf_schemaname_warehouse_sync,
                                            sf_tablename_warehouse_sync,
                                            sourceDB,                                            
                                            source,
                                            target,
                                            sfUser,
                                            sfPassword,
                                            sfURL,
                                            taskId,
                                            job_type,
                                            job_name,
                                            runType,
                                            minThreshold,
                                            maxThreshold,
                                            sfType1Merge,
                                            sfType1OrderCol,
                                            maxBytesPerTrigger,
                                            emaillist
                                            )
                
               var readStream = spark
                                    .readStream
                                    .option("ignoreChanges", "true")
                  //if (!runType.equals("AVAILABLE_NOW")) {
                          readStream = readStream.option("maxBytesPerTrigger", maxBytesPerTrigger)
                 // }
                  if (sfType1Merge && (if(sfType1OrderCol==null) true else {if(sfType1OrderCol.length==0) true else false})) {
                          readStream = readStream.option("readChangeFeed", "true")
                  }
                  var streamingDF = readStream
                    .format("delta")
                    .table(s"${sourceDB}.${source}")
                  if (!(readtablefromdate == null || readtablefromdate.isEmpty)) {
                          println("in empty readtablefromdate")
                          streamingDF = streamingDF.filter('updatetime >= readtablefromdate)
                  }

                  var streamQuery = streamingDF
                    .writeStream
                    .foreachBatch(deltaHandler.handleMicroBatch _)
                    .option("checkpointLocation", checkPoint)
                    .option("queryName", source+"_"+taskId)
                  if (runType.equals("AVAILABLE_NOW")) {
                          streamQuery = streamQuery
                            .option("maxBytesPerTrigger", maxBytesPerTrigger)
                            .trigger(Trigger.AvailableNow)
                  }
                  streamQuery.start()

      
      }) 
}

// COMMAND ----------

// DBTITLE 1,Call streaming main method
startWarehouseSyncStreamingMain(groupId,runType,job_type,environment)
