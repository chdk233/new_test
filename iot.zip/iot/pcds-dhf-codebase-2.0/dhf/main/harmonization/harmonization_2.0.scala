// Databricks notebook source
// MAGIC %md
// MAGIC - Runs all tables for one Group ID
// MAGIC - Al l tables writing to one Harmonize Table go into same TaskGroup
// MAGIC - Task Group Level configurations:
// MAGIC -  job_type: HARMONIZATION - no separat EVENT_GENERATION or EVENT_HARMONIZATION
// MAGIC -  run_type: ROUND_THE_CLOCK / AVAILABLE_NOW   -- This notebook ONLY runs ROUND_THE_CLOCK TaskGroups
// MAGIC -  isNotebook: True/False

// COMMAND ----------

// DBTITLE 1,Import libraries
import spark.implicits._
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import java.time.LocalDateTime
import org.apache.spark.sql.streaming.Trigger
import java.time.temporal.ChronoUnit
import io.delta.tables._
import org.apache.spark.sql.expressions.Window

import scala.collection.mutable.ListBuffer

// COMMAND ----------

// DBTITLE 1,Set spark conf
spark.conf.set("spark.sql.streaming.stopActiveRunOnRestart", true)
spark.conf.set("spark.sql.broadcastTimeout", 600)

// COMMAND ----------

// DBTITLE 1,Get arguments from widgets
dbutils.widgets.removeAll()
dbutils.widgets.text("groupId", "1", "GroupID")
dbutils.widgets.text("environment", "dev", "environment")
dbutils.widgets.text("metricsLogTable", "", "metricsLogTable")
dbutils.widgets.text("checkpoint_dir", "", "checkpoint_dir")

val groupId = dbutils.widgets.get("groupId").toString.toInt
val environment = dbutils.widgets.get("environment").toString
val metricsLogTable = dbutils.widgets.get("metricsLogTable").toString
val checkpoint_dir = dbutils.widgets.get("checkpoint_dir").toString

println("groupId in notebook is : " + groupId)
println("environment in notebook is : " + environment)
println("metricsLogTable in notebook is : " + metricsLogTable)
println("checkpoint_dir in notebook is : " + checkpoint_dir)

// COMMAND ----------

// DBTITLE 1,Run utils notebook
// MAGIC %run ../../utils/_utils

// COMMAND ----------

// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

class HarmonizeHandlerClass(harmonizedTable: String,
                            key: String,
                            taskGroupId: Long,
                            jobType: String,
                            runType: String,
                            taskGroup: TaskGroup,
                            changelogTable:String
                           ) extends Serializable {

        def handleMicroBatch(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long) = {

                try {
                        val start = LocalDateTime.now()
 println(s"In delta handler f4")
                        val batchSize = microBatchDF.count
                        println(s"In delta handler for harmonizedTable: ${harmonizedTable}, batchSize: ${batchSize}, batchId:${batchId}")
                  
                       val minThreshold = taskGroup.min_threshold
                       val maxThreshold = taskGroup.max_threshold

                        if (batchSize > 0) {
                                
                                // microBatchDF.createOrReplaceGlobalTempView("V")
                               // exclusion/ pre-Harmonization Logic

                                var exclusionDF = microBatchDF
                                val ispreHarmQuery = taskGroup.pre_harmonization_query
                                if(!(if(ispreHarmQuery==null) true else {if(ispreHarmQuery.length==0) true else false}))
                                {
                                  exclusionDF = pre_harm_exclusion(exclusionDF, ispreHarmQuery, taskGroup.source_db, environment)
                                  exclusionDF = removeAdditionalCols_clt(exclusionDF, harmonizedTable)
                                }
                                exclusionDF.createOrReplaceGlobalTempView("V")
                                // Add Hash
                                val hashDF = addHashColumn_clt_old("V")

                                // Dedup
                                val Type1 = taskGroup.merge_type.toLowerCase() //  from config
                                val ishashColumn = taskGroup.is_hash_Column  //  from config
                                val is_surrogatekey= taskGroup.is_surrogate_key
                                if (Type1=="type1") {
                                  
                                        var dedupDF = hashDF
                                        var orderby = taskGroup.order_by_column //"PLCY_KEY"   // TODO: from config
                                  
                                        if(if(orderby==null) true else {if(orderby.length==0) true else false}){
                                             val w = Window.partitionBy(key.split(",").map(colName => col(colName)): _*).orderBy($"_commit_version".desc)
                                             dedupDF = hashDF.filter('_change_type === "insert" || '_change_type === "update_postimage")
                                                      .withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
                                                      .drop("_change_type").drop("_commit_version")
                                             dedupDF = removeDuplicatesMicrobatch_clt(hashDF, key, "_commit_timestamp")
                                             dedupDF.drop("_commit_timestamp")
                                             
                                        }  else {
                                    
                                             val w = Window.partitionBy(key.split(",").map(colName => col(colName)): _*).orderBy(col(orderby.trim()).desc)
                                             dedupDF = hashDF.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
                                             dedupDF = removeDuplicatesMicrobatch_clt(hashDF, key, orderby)
                                        }
                                        
                                        val noHashDF = if (!ishashColumn) dedupDF.drop("row_hashed") else dedupDF
                                        // mergeType1(noHashDF,harmonizedTable) TODO: add function
                                        if(is_surrogatekey){
                                        // Add SurrogateKey
                                
                                            val surrogateKeyDF = addSurrogateKey_clt_type1(noHashDF, harmonizedTable, orderby)

                                            type1_defaultMerge(surrogateKeyDF, harmonizedTable, key)
                                        } else{
                                            type1_defaultMerge(noHashDF, harmonizedTable, key)
                                        }
                                } else {
                                  
                                        val dedupDF = removeDuplicates_clt_old(hashDF, harmonizedTable, key)
                                  
                                        // Add Audit Columns
                                        val auditDF = addAuditColumns_clt(dedupDF, key)

                                        // Add SurrogateKey
                                        val surrogateKeyDF = addSurrogateKey_clt(auditDF, harmonizedTable)

                                        //Merge Type2
                                        defaultMerge_clt(surrogateKeyDF, harmonizedTable)
                                }
                        
                        val totalBatchTimeInMins= ChronoUnit.MINUTES.between(start, LocalDateTime.now())
                     
                        persistLog(MetricCCPerBatch(groupId.toString, jobId, jobType + "-Merge", runType, runId, batchId, batchSize, ChronoUnit.MINUTES.between(start, LocalDateTime.now()).toString, start.toString, taskGroupId, 0, "", harmonizedTable, clusterId), metricsLogTable)
                          
                         //post log info to splunk
                  sendToSplunk(groupId.toString, jobId, job_name, jobType + "-Merge", runType, runId, batchId, batchSize,start.toString, totalBatchTimeInMins.toString,  taskGroupId, 0, changelogTable, harmonizedTable, clusterId,"Success")
                  
                  
                   /** run inline optimize if it is the right period **/ 
                  println("run inline optimize if it is the right period")
                  if(taskGroup.inline_optimize_enabled)
                        optimizeDeltaTable(taskGroup)
                          
                    // check batch timing and send an email if it breaches min threshold and create a ticket if it breaches max threshold
                     if(totalBatchTimeInMins > minThreshold){
                         if(totalBatchTimeInMins > maxThreshold){
                         println("Max Threshold Breached.Generating snow ticket and Sending Email..")
                  errorHandler("maxThreshold",job_name,groupId,jobId,jobType,runId,batchId,maxThreshold,minThreshold,
                                                                       totalBatchTimeInMins.toString,taskGroupId,0,"NA",taskGroup.email_list) 
                    }
                    else{
                        println("Min Threshold hold breached. sending email...") //email notebook
                  errorHandler("minThreshold",job_name,groupId,jobId,jobType,runId, batchId,maxThreshold,minThreshold,totalBatchTimeInMins.toString,taskGroupId,0,"NA",taskGroup.email_list) 
                    }
                 }else{
                       println(s"batchId ${batchId} for harmonization completed withing threshold limit.Total batch time - " +totalBatchTimeInMins)
                     } 
            } 

                } catch {
                        case e: Exception => {
                                println(s"MERGE FAILED for Harmonize table: ${harmonizedTable}, batchId ${batchId}" + e)
                                //post log info to splunk
                                sendToSplunk(groupId.toString, jobId, job_name, jobType + "-Merge", runType, runId, batchId, 0,LocalDateTime.now().toString, "0",  taskGroupId, 0, changelogTable, harmonizedTable, clusterId,"Failed")
                          
                          //create snow ticket and send email
                          errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroupId,0,e.toString.replace("\n", " "),taskGroup.email_list)
                           //throw new Exception(s"MERGE FAILED for Harmonize table: ${harmonizedTable}, batchId ${batchId}, FAILING the entire job " + e)
                        }
                }
        }
}

// COMMAND ----------

def startHarmonizeMergeStream(taskGroup: TaskGroup) = {
        val target_table = taskGroup.target_db + "." + taskGroup.target_table
        val maxBytesPerTrigger = taskGroup.max_bytes_per_trigger
        val Type1_evntharm = taskGroup.merge_type.toLowerCase() // TODO: from config
        val orderby_evntharm = taskGroup.order_by_column 
        var changelogTable=target_table + "_chlg"
        var changelogPrefix=""
        if(!(taskGroup.user_properties ==null || taskGroup.user_properties.isEmpty)){
                changelogPrefix    = getUserPropertyValue("changelogPrefix", taskGroup.user_properties)
                
                 if(!(changelogPrefix ==null || changelogPrefix.isEmpty)){
                 changelogTable=target_table +"_"+changelogPrefix+"_chlg"
                }
          }
        val checkPoint = checkpoint_dir + "/" + environment + "/eventharmonization/" + taskGroup.id + "/" + changelogTable + "/cp001"
  
        println("checkPoint is " + checkPoint)
       try {
        var readStream = spark
                        .readStream
                        .option("ignoreChanges", "true")
                  
                        //if (Type1_evntharm=="type1" && (if(orderby_evntharm==null) true else {if(orderby_evntharm.length==0) true else false})) {
                        //  readStream = readStream.option("readChangeFeed", "true")
                        //}
        val streamingDF = readStream
          .option("maxBytesPerTrigger", maxBytesPerTrigger) //will be only inserts into changelog table
          .format("delta")
          .table(changelogTable)

        val harmonizeHandler = new HarmonizeHandlerClass(
                target_table,
                taskGroup.merge_keys,
                taskGroup.id,
                taskGroup.job_type,
                taskGroup.run_type,
                taskGroup,
                changelogTable
        )
       
        var streamQuery = streamingDF
          .writeStream
          .foreachBatch(harmonizeHandler.handleMicroBatch _)
          .option("checkpointLocation", checkPoint)
           .option("queryName", "harmonize " + target_table+"_"+taskGroup.id)
        if (taskGroup.run_type.equals("AVAILABLE_NOW")) {
                streamQuery = streamQuery
                  .option("maxBytesPerTrigger", maxBytesPerTrigger)
                  .trigger(Trigger.AvailableNow)
        }
        streamQuery.start()
       }catch{
          case e: Exception => {
                                println(s"Merge Stream failed for Harmonize table: ${taskGroup.target_table}_chlg" + e)
                                //post log info to splunk
                                sendToSplunk(groupId.toString, jobId, job_name, taskGroup.job_type + "-Merge", taskGroup.run_type, runId, -1, 0,LocalDateTime.now().toString, "0",  taskGroup.id, 0,  changelogTable,  taskGroup.target_table, clusterId,"Failed")
                          
                          //create snow ticket and send email
                          errorHandler("exception", job_name,groupId,jobId,taskGroup.job_type,runId, -1,0,0,"0",taskGroup.id,0,e.toString.replace("\n", " "),taskGroup.email_list)
                           //throw new Exception(s"Merge Stream failed for Harmonize table: ${taskGroup.target_table}_chlg" + e)
                        }
         
       }
}

// COMMAND ----------

def startMergeStreamsForBatch(taskGroupList: List[TaskGroup]) = {
print(s"\n in start merge")
        var canExitLoop = false
        var startedTaskGroupList = new ListBuffer[Int]() //creating empty task list to avoid running the merge stream again after its completions 
        while (!canExitLoop) {
                canExitLoop = true
                taskGroupList.foreach(taskGroup => {
                        val activeStreamList = spark.streams.active.toList.map(_.name)
                        val taskGroupStreamList = getTask(taskGroup.id.toInt, taskGroup.job_type).map(_.source_table+"_"+taskGroup.id.toInt).toSet.toList // task stream names
                        print("\n activeStreamList: " + activeStreamList + "\n taskGroupStreamList: " + taskGroupStreamList)
                        if (taskGroupStreamList.exists(activeStreamList.contains)) { // if query streams are still active for all Task Groups
                                canExitLoop = false
                        } else {
                                print(s"\n Starting Merge Stream for Task Group: ${taskGroup.id}, Harmonize Table: ${taskGroup.target_db + "." + taskGroup.target_table} \n")
                                if (!startedTaskGroupList.contains(taskGroup.id.toInt)){
                                    
                                    startHarmonizeMergeStream(taskGroup)
                                    
                                    startedTaskGroupList += taskGroup.id.toInt //appending taskgroup after MergeStream to avoid running the merge stream again
                                    print(s"\n Appending TASK GROUP to the toCheckTaskGroupList --- ${startedTaskGroupList}")
                                    } else {
                                         println(s"Merge stream either running or completed for this Task Group: ${taskGroup.id}")
                                      }
                        }

                        if (!canExitLoop) {
                                print("\n Waiting in Merge Stream Loop . . . \n")
//                                 Thread.sleep(2 * 60 * 1000)
                        }
                })
        }
}

// COMMAND ----------

class DeltaHandlerClass(task: Task,
                  harmonizedTable: String,
                  jobType: String,
                  runType: String,
                  email_list: String,
                  changelogTable: String
                 ) extends Serializable {

      def handleMicroBatch(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long) = {

          try {
                  val start = LocalDateTime.now()
                  println(s"Entering EG handler...")
                  
                  //microBatchDF.withColumn("batchid", lit(batchId)).write.format("delta").mode("append").option("mergeSchema","true").saveAsTable(s"events_child_${taskGroupId}_${child}") //uncomment this block if you want to enable tracking table
                  val batchSize = microBatchDF.count
                  if ( batchSize>= 1) {

                      microBatchDF.createOrReplaceGlobalTempView(s"${task.source_table}")
                      val queryDF = microBatchDF.sparkSession.sql(task.sql_query.replace("{sourceDB}", task.source_db))
                      
                      queryDF.write.mode("append").format("delta").saveAsTable(changelogTable)
                    
                    val totalBatchTimeInMins= ChronoUnit.MINUTES.between(start, LocalDateTime.now())
                     
                      persistLog(MetricCCPerBatch(groupId.toString, jobId, jobType, runType, runId, batchId, batchSize, ChronoUnit.MINUTES.between(start, LocalDateTime.now()).toString, start.toString, task.task_group_id, task.id, task.source_table, harmonizedTable, clusterId), metricsLogTable)
                    
                    //Send log info to splunk
                    sendToSplunk(groupId.toString, jobId, job_name, jobType, runType, runId, batchId, batchSize,  start.toString,totalBatchTimeInMins.toString, task.task_group_id, task.id, task.source_table, changelogTable , clusterId,"Success")

                  } else println(s"NO DATA in microbatch for source table ${task.source_table}, batchId ${batchId}")

          } catch {
                  case e: Exception => {
                          println(s"APPEND FAILED for raw table: ${task.source_table}, batchId ${batchId}, FAILING the entire job " + e)
                          //Send log info to splunk
                          sendToSplunk(groupId.toString, jobId, job_name, jobType, runType, runId, batchId, 0,  LocalDateTime.now().toString,"0", task.task_group_id, task.id, task.source_table, changelogTable, clusterId,"Failed")
                          
                          //create snow ticket and send email
                          errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",task.task_group_id,task.id,e.toString.replace("\n", " "),email_list)
                         // throw new Exception(s"APPEND FAILED for raw table: ${task.source_table}, batchId ${batchId}, FAILING the entire job " + e)
                  }
          }
  }
}

// COMMAND ----------

def startGenerationStreamingMain() = {

        val group = getGroup(groupId)
        val taskGroupList = getTaskGroupList(groupId)

        taskGroupList.foreach(taskGroup => {
                // TODO - use a separate shceduler pool
                // spark.sparkContext.setLocalProperty("spark.scheduler.pool", "pool1")

                val taskGroupId = taskGroup.id.toInt //TODO
                val target_table = taskGroup.target_db + "." + taskGroup.target_table
                val taskList = getTask(taskGroupId, group.job_type)
                val Type1_evntgen = taskGroup.merge_type.toLowerCase() // TODO: from config
                val orderby_evntgen = taskGroup.order_by_column 
                val maxBytesPerTrigger = taskGroup.max_bytes_per_trigger
                var changelogTable=target_table + "_chlg"
                var changelogPrefix=""
               if(!(taskGroup.user_properties ==null || taskGroup.user_properties.isEmpty)){
                  changelogPrefix    = getUserPropertyValue("changelogPrefix", taskGroup.user_properties)
                 
                  if(!(changelogPrefix ==null || changelogPrefix.isEmpty)){
                     changelogTable=target_table +"_"+changelogPrefix +"_chlg"
                  }
               }
                  

                if (taskList.isEmpty) {
                        throw new Exception(s"No task found for the given task_group_id ${taskGroupId}. Please check the task config table")
                }

                taskList.foreach(task => {
                        val checkPoint = checkpoint_dir + "/" + environment + "/eventgeneration/" + taskGroupId + "/" + task.source_table + "/cp001"
                        println("checkPoint is " + checkPoint)

                        val deltaHandler = new DeltaHandlerClass(
                                task,
                                target_table,
                                group.job_type,
                                group.run_type,
                                taskGroup.email_list,
                                changelogTable
                               
                        )
                        try{
                        var readStream = spark
                                    .readStream
                                    .option("ignoreChanges", "true")
                  
                        if (Type1_evntgen=="type1" && (if(orderby_evntgen==null) true else {if(orderby_evntgen.length==0) true else false})) {
                          readStream = readStream.option("readChangeFeed", "true")
                        }
                        var streamingDF = readStream
                          .option("maxBytesPerTrigger", maxBytesPerTrigger)
                          .format("delta")
                          .table(s"${task.source_db}.${task.source_table}")
                          
                        if (!(task.read_table_from_date == null || task.read_table_from_date.isEmpty)) {
                                println("in empty readtablefromdate")
                                streamingDF = streamingDF.filter('updatetime >= task.read_table_from_date)
                        }

                        //                         var streamQuery = streamingDF
                        //                           .writeStream
                        //                           .foreachBatch(deltaHandler.handleMicroBatch _)
                        //                           //                           .option("checkpointLocation", checkPoint)
                        //                           .option("queryName", task.source_table)
                        //                         streamQuery.start()

                        var streamQuery = streamingDF
                          .writeStream
                          .foreachBatch(deltaHandler.handleMicroBatch _)
                          .option("checkpointLocation", checkPoint)
                          .option("queryName", task.source_table+"_"+taskGroupId)
                        if (taskGroup.run_type.equals("AVAILABLE_NOW")) {
                                streamQuery = streamQuery
                                  .option("maxBytesPerTrigger", maxBytesPerTrigger)
                                  .trigger(Trigger.AvailableNow)
                        }
                        streamQuery.start()
                        }catch{
                          case e: Exception => {
                            
                          println(s"Stream FAILED for raw table: ${task.source_table}" + e)
                          //Send log info to splunk
                          sendToSplunk(groupId.toString, jobId, job_name, group.job_type, group.run_type, runId, -1, 0,  LocalDateTime.now().toString,"0", task.task_group_id, task.id, task.source_table, taskGroup.target_table+"chlg", clusterId,"Failed")
                          
                          //create snow ticket and send email
                          errorHandler("exception", job_name,groupId,jobId,group.job_type,runId, -1,0,0,"0",task.task_group_id,task.id,e.toString.replace("\n", " "),taskGroup.email_list)
                          //throw new Exception(s"Stream FAILED for raw table: ${task.source_table}" + e)
                  }
                        }


                })

                if (taskGroup.run_type.equals("ROUND_THE_CLOCK") && !taskGroup.is_custom_notebook) { // && runType.equals("ROUND_THE_CLOCK"))  // this notebook only runs round_the_clock
                        startHarmonizeMergeStream(taskGroup) //, group.run_type, group.job_type)
                }
        })


        if (group.is_custom_notebook) {
                val baseFilePath = s"/Repos/dhfsid@nationwide.com/pcds-dhf-${environment}-2.0/dhf/main/"
                val substr = s"main/"
                val appendPath = group.handler_path.substring(group.handler_path.indexOf(substr) + substr.length())
                //val environment1 = s"test"
                val notebookHandlerPath = if(s"${environment}" == "dev") group.handler_path else baseFilePath + appendPath
                println(s"NotebookPath is ${notebookHandlerPath}")
                dbutils.notebook.run(notebookHandlerPath, 0, Map("groupId" -> groupId.toString,"environment" -> environment,"checkpoint_dir" -> checkpoint_dir))
                //dbutils.notebook.run(group.handler_path, 0, Map("groupId" -> groupId.toString,"environment" -> environment,"checkpoint_dir" -> checkpoint_dir))
        } else if (group.run_type.equals("AVAILABLE_NOW")) {
                startMergeStreamsForBatch(taskGroupList)
        }
}

// COMMAND ----------

startGenerationStreamingMain()
