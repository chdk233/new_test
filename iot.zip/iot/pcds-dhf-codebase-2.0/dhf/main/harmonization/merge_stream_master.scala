// Databricks notebook source
// DBTITLE 1,Import libraries
import spark.implicits._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.Date
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.expressions.Window
import java.time.temporal.ChronoUnit



//import org.apache.kafka.clients.consumer.{KafkaConsumer, OffsetAndMetadata}
//import org.apache.kafka.common.TopicPartition
import com.fasterxml.jackson.databind.{DeserializationFeature, ObjectMapper}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import org.apache.spark.sql.streaming.StreamingQueryListener
import org.apache.spark.sql.streaming.StreamingQueryListener._
import scala.collection.mutable.Map
import scala.collection.mutable.ListBuffer

// COMMAND ----------

// DBTITLE 1,Set spark conf
spark.conf.set("spark.sql.streaming.stopActiveRunOnRestart", true)
spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInWrite","CORRECTED")

// COMMAND ----------

// DBTITLE 1,Run utils notebook
// MAGIC %run ../../utils/_utils

// COMMAND ----------

class HarmonizeHandlerClass(taskGroup: TaskGroup, groupId:Long, runType: String, jobType: String,changelogTable: String)  extends Serializable {
   
                          
      def handleMicroBatch(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long) = {   
        
        try{
                val start = LocalDateTime.now()  
                val metricsLogTable = "dhf2_config.harmonize_metrics" // TODO
                val minThreshold = taskGroup.min_threshold
                val maxThreshold = taskGroup.max_threshold
          
                print("in delta handler \n")
                
                val batchSize = microBatchDF.count
                println(s"batchSize ${batchSize}, target ${taskGroup.target_table}")
                
                doHarmonize(microBatchDF, batchId, taskGroup.source_db, taskGroup.target_db, taskGroup.target_table)
          
                val totalBatchTimeInMins = ChronoUnit.MINUTES.between(start, LocalDateTime.now())
                println(s"Total batch time for   target: ${taskGroup.target_table}, batchId ${batchId} is: ${totalBatchTimeInMins} min")  
          
                persistLog(MetricCCPerBatch(groupId.toString, jobId, jobType + "-Merge-Notebook", runType, runId, batchId, batchSize, ChronoUnit.MINUTES.between(start, LocalDateTime.now()).toString, start.toString, taskGroup.id, 0, "", taskGroup.target_table, clusterId), metricsLogTable)
          
                 //post log info to splunk
                  sendToSplunk(groupId.toString, jobId, job_name, jobType + "-Merge-Notebook", runType, runId, batchId, batchSize, totalBatchTimeInMins.toString, start.toString, taskGroup.id, 0, changelogTable, taskGroup.target_table, clusterId,"Success")
                  
                  
                   /** run inline optimize if it is the right period **/ 
                  println("run inline optimize if it is the right period")
                  if(taskGroup.inline_optimize_enabled)
                        optimizeDeltaTable(taskGroup)
                          
                    // check batch timing and send an email if it breaches min threshold and create a ticket if it breaches max threshold
                     if(totalBatchTimeInMins > minThreshold){
                         if(totalBatchTimeInMins > maxThreshold){
                            println("Max Threshold Breached.Generating snow ticket and Sending Email..") //call snow functio
                            errorHandler("maxThreshold",job_name,groupId,jobId,jobType,runId,batchId,maxThreshold,minThreshold,
                                                                       totalBatchTimeInMins.toString,taskGroup.id,0,"NA",taskGroup.email_list)
                    }
                    else{
                        println("Min Threshold hold breached. sending email...") //email notebook
                      errorHandler("minThreshold",job_name,groupId,jobId,jobType,runId, batchId,maxThreshold,minThreshold,totalBatchTimeInMins.toString,taskGroup.id,0,"NA",taskGroup.email_list)
                    }
                 }else{
                       println(s"batchId ${batchId} for harmonization completed withing threshold limit.Total batch time - " +totalBatchTimeInMins)
                     } 
          
        } catch {
                case e:Exception => {
                  println(s"MERGE FAILED for  target: ${taskGroup.target_table} for batchId ${batchId}" + e)
                  //post log info to splunk                
                  sendToSplunk(groupId.toString, jobId, job_name, jobType + "-Merge-Notebook", runType, runId, batchId, 0, "0", LocalDateTime.now().toString, taskGroup.id, 0, changelogTable, taskGroup.target_table, clusterId,"Failed")
          
                 // throw new Exception(description)
                   errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroup.id,0,e.toString.replace("\n", " "),taskGroup.email_list)
                }  
        }
      }
}

// COMMAND ----------

def startHarmonizeMergeStream(taskGroup: TaskGroup) = {
        print("\n entering startMergeStreams \n")

        val target_table = taskGroup.target_db + "." + taskGroup.target_table
        val maxBytesPerTrigger = taskGroup.max_bytes_per_trigger
        val runType = taskGroup.run_type
        var changelogTable=target_table + "_chlg"
        var changelogPrefix=""
        if(!(taskGroup.user_properties ==null || taskGroup.user_properties.isEmpty)){
                changelogPrefix    = getUserPropertyValue("changelogPrefix", taskGroup.user_properties)
                
                 if(!(changelogPrefix ==null || changelogPrefix.isEmpty)){
                 changelogTable=target_table +"_"+changelogPrefix+"_chlg"
                }
          }
       val checkPoint = checkpoint_dir + "/" + environment + "/eventharmonization/" + taskGroup.id + "/" + changelogTable + "/cp001"
  
        println("checkPoint is " + checkPoint)
        try{
        val streamingDF = spark.readStream
          .option("ignoreChanges", "true")
          .format("delta")
          .option("maxBytesPerTrigger", maxBytesPerTrigger)
          .table(changelogTable)

        val harmonizeHandler = new HarmonizeHandlerClass(taskGroup, taskGroup.job_group_id, runType, taskGroup.job_type,changelogTable)


        val triggerMode = if (runType.equals("AVAILABLE_NOW")) {
                Trigger.AvailableNow
        } else {
                Trigger.ProcessingTime("0 seconds")
        }

          
         var streamQuery= streamingDF.writeStream
          .foreachBatch(harmonizeHandler.handleMicroBatch _)
          .option("checkpointLocation",checkPoint)
          .trigger(triggerMode)
          .option("queryName", "harmonize " + target_table+"_"+taskGroup.id)
          if (taskGroup.run_type.equals("AVAILABLE_NOW")) {
                streamQuery = streamQuery
                  .option("maxBytesPerTrigger", maxBytesPerTrigger)
        }
          streamQuery.start()
          
        }catch{
           case e: Exception => {
                                println(s"Merge Stream failed for Harmonize table: ${taskGroup.target_table}_chlg" + e)
                                //post log info to splunk
                                sendToSplunk(taskGroup.job_group_id.toString, jobId, job_name, taskGroup.job_type + "-Merge", taskGroup.run_type, runId, -1, 0,LocalDateTime.now().toString, "0",  taskGroup.id, 0,  taskGroup.target_table+"_chlg",  taskGroup.target_table, clusterId,"Failed")
                          
                          //create snow ticket and send email
                          errorHandler("exception", job_name,taskGroup.job_group_id,jobId,taskGroup.job_type,runId, -1,0,0,"0",taskGroup.id,0,e.toString.replace("\n", " "),taskGroup.email_list)
                           //throw new Exception(s"Merge Stream failed for Harmonize table: ${taskGroup.target_table}_chlg" + e)
                        }
        }

}

// COMMAND ----------

def startHarmonizerStreamingMain(groupId: Long) = { //target_table: String, mergeKeys: String, taskGroupId: Long) = {
        print("\n entering startHarmonizerStreamingMain \n")

        val group = getGroup(groupId)
        val taskGroupList = getTaskGroupList(groupId)

        print("\n .........runType: " + group.run_type + "taskGroupIds: " + taskGroupList.map(_.id) + "\n")

        if (group.run_type == "ROUND_THE_CLOCK") { // Start Merge Streams Right Away
                taskGroupList.foreach(taskGroup => {
                        startHarmonizeMergeStream(taskGroup)
                })
        } else if (group.run_type == "AVAILABLE_NOW") { // Start Merge Stream only after Query Streams complete for the Task Group
                var canExitLoop = false
                var startedTaskGroupList = new ListBuffer[Int]()
                while (!canExitLoop) {
                        canExitLoop = true
                        taskGroupList.foreach(taskGroup => {
                                val activeStreamList = spark.streams.active.toList.map(_.name)
                                val taskGroupStreamList = getTask(taskGroup.id.toInt, taskGroup.job_type).map(_.source_table+"_"+taskGroup.id.toInt).toSet.toList // task stream names
                                print("\n activeStreamList: " + activeStreamList + "\n taskGroupStreamList: " + taskGroupStreamList)
                                if (taskGroupStreamList.exists(activeStreamList.contains)) { // if query streams are still active for all Task Groups
                                        canExitLoop = false
                                } else {
                                        print(s"\n Starting Merge Stream for Task Group: ${taskGroup.id}, Harmonize Table: ${taskGroup.target_db + "." + taskGroup.target_table} \n")
                                        if (!startedTaskGroupList.contains(taskGroup.id.toInt)){
                                             
                                             startHarmonizeMergeStream(taskGroup)
                                             
                                             startedTaskGroupList += taskGroup.id.toInt //appending taskgroup after MergeStream to avoid running the merge stream again
                                             print(s"\n Appending TASK GROUP to the toCheckTaskGroupList --- ${startedTaskGroupList}")
                                             } else {
                                                    println(s"Merge stream either running or completed for this Task Group: ${taskGroup.id}")
                                               }
                                }

                                if (!canExitLoop) {
                                        print("\n Waiting in Merge Stream Loop . . . \n")
                                        //                                 Thread.sleep(2 * 60 * 1000)
                                }
                        })
                }
        }
}
