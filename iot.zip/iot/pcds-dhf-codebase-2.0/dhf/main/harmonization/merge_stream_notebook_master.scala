// Databricks notebook source
import sqlContext.implicits._ 
import org.apache.spark.sql.functions._
import io.delta.tables._ 
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.DataFrame
import java.time.LocalDateTime

// COMMAND ----------

// DBTITLE 0,Get arguments from widgets
dbutils.widgets.removeAll() 
dbutils.widgets.text( "groupId", "", "groupId")
dbutils.widgets.text("environment", "dev", "environment")
dbutils.widgets.text("checkpoint_dir", "", "checkpoint_dir")

val groupId=dbutils.widgets.get("groupId").toLong
val environment = dbutils.widgets.get("environment").toString
val checkpoint_dir = dbutils.widgets.get("checkpoint_dir").toString

println("environment in notebook is : " + environment)
println("checkpoint_dir in notebook is : " + checkpoint_dir)

// COMMAND ----------

// DBTITLE 1,Step1: Register your child notebook
// MAGIC %run ../harmonization_child/claims_child

// COMMAND ----------

// DBTITLE 1,Step 2: Register your Merge Function
def doHarmonize(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
  //Claims Merge
  if (harmonizedDB == "pg_hrm" && target == "cc_claim_ph3"){
        merge_cc_claim_ph2(microBatchDF, batchId, rawDB, harmonizedDB, target)
  }
  
  
//   XYZ Merge
//   else if (harmonizedDB == "pg_hrm" && target == "abcd"){
//        merge_abcd(microBatchDF, batchId, rawDB, harmonizedDB, target)
//   }   
  
}

// COMMAND ----------

// DBTITLE 1,Harmonize Master Notebook - path can change relative to your child notebook location
// MAGIC %run ./merge_stream_master

// COMMAND ----------

startHarmonizerStreamingMain(groupId) 
