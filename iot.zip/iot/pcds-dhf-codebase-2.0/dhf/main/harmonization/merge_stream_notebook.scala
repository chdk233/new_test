// Databricks notebook source
import sqlContext.implicits._ 
import org.apache.spark.sql.functions._
import io.delta.tables._ 
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.DataFrame
import java.time.LocalDateTime

// COMMAND ----------

// DBTITLE 0,Get arguments from widgets
dbutils.widgets.removeAll() 
dbutils.widgets.text( "groupId", "", "groupId")
dbutils.widgets.text("environment", "dev", "environment")
dbutils.widgets.text("checkpoint_dir", "", "checkpoint_dir")



val groupId=dbutils.widgets.get("groupId").toLong
val environment = dbutils.widgets.get("environment").toString
val checkpoint_dir = dbutils.widgets.get("checkpoint_dir").toString

println("environment in notebook is : " + environment)
println("checkpoint_dir in notebook is : " + checkpoint_dir)


// COMMAND ----------

// DBTITLE 1,Step1: Register your child notebook
// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_bldg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_line_mod

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_line_loc

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_geo_bceg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_geo_info

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_pol_party

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_loc

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_party

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_party_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_pol_line

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_occ_cl

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_named_insured

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_policy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_pers_prop

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_bus_incm

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_addl_intrst

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_form

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/cop_ds_line_bldg_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/gl_pol_line_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/pcio/gl_policy_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv_pak/pak_ds_acct_party_rls_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv_pak/pak_ds_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv_pak/pak_ds_cust_acct_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv_pak/pak_ds_party_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv_pak/pak_ds_party_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv_pak/pak_ds_party_entity_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_addl_intrst_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_bldg_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_bop_classification_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_flood_info_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_form_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_geo_bceg_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_geo_info_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_line_bldg_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_line_loc_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_line_mod_child1

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_line_mod_child2

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_line_mod_child3

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_loc_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_manuscript_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_named_insured_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_nonfiled_scr_rslt_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_party_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_pol_line_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_pol_party_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/bp_ds_policy_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_form_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_loc_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_nonfiled_scr_rslt_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_party_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_pol_line_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_pol_party_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_policy_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_addl_intrst_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_drvr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_gar_srvc_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_line_mod_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_mc_filing_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_mod_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/ca_ds_veh_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_ca_ds_audit_info

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_ca_ds_manuscript

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_ca_ds_named_insured

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_addl_intrst_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_bldg_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_loc_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_named_insured_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_pol_line_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_geo_bceg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_line_loc

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_manuscript

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_party_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_pol_party

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_policy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_form_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_geo_info_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_jurs_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_nonfield_scr_rslt_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_pers_prop_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_bus_incm

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_covg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_line_bldg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_line_mod_1

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_line_mod_2

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_manuscript

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_occ_cl

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cp_ds_spcl_cl

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_ds_fact_prem_tran_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cp_ds_fact_staging_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_addl_intrst

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_bldg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_flood_info

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_form

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_geo_info

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_jurs

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_line_bldg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_line_loc

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_loc

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_manuscript

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_named_insured

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_nonfiled_scr_rslt

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_party_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_pol_line

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_pol_party

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_policy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_spoil_dfncy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_covg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_crime_dfncy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_line_mod_1

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cop_ds_line_mod_2

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cop_ds_fact_prem_tran_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cop_ds_fact_staging_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/gl_ds_policy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_addl_intrst

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_crm_ds_covg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_form

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_geo_info

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_jurs

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_loc

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_manu_script

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_named_insured

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_non_filed_scr_rslt

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_pol_line

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_pol_party

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_policy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_line_mod_1

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/crm_ds_line_mod_2

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_cu_ds_covg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_form

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_fcltv_reins

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_geo_info

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_manu_script

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_named_insured

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_line_mod_1

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_line_mod_2

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/cu_ds_umbr_ul_pol

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_addl_intrst

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_covg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_form

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_geo_info

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_jurs

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_loc_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_party_addr_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_named_insured

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_pol_line_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_pol_party_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_policy_child

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_line_mod_1

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/im_ds_line_mod_2

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_wc_ds_addr

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_wc_ds_covg

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_wc_ds_line_pol_party

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_wc_ds_prtcptng_plan

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/wc_ds_jurs

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_wc_ds_rtg_prd_start

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/wc_ds_line_cl_cd

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_wc_ds_named_insured

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/wc_ds_pol_line

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/wc_ds_nonfiled_scr_rslt

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/wc_ds_policy

// COMMAND ----------

// MAGIC %run ../harmonization_child/legacy/hv/hv_wc_ds_geo_info

// COMMAND ----------

// DBTITLE 1,Step 2: Register your Merge Function
def doHarmonize(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
  //Claims Merge
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_bldg" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_bldg(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_line_mod(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_addr(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_loc" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_line_loc(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_bceg" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_geo_bceg(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_geo_info(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_party" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_pol_party(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_loc" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_loc(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_party(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_addr" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_party_addr(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_pol_line(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_occ_cl" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_occ_cl(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_named_insured(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_policy(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pers_prop" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_pers_prop(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_bus_incm" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_bus_incm(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addl_intrst" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_policy(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_pers_prop(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_bldg" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_cop_ds_bus_incm(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "DS_POL_LINE" && microBatchDF.filter("LOB_CD='GL'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_gl_ds_pol_line(microBatchDF.filter("LOB_CD='GL'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "DS_POLICY" && microBatchDF.filter("LOB_CD='GL'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='PCIO'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_pcio_gl_ds_policy(microBatchDF.filter("LOB_CD='GL'").filter("SOURCE_SYSTEM='PCIO'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_acct_party_rls" && microBatchDF.filter("LOB_CD='PAK'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_pak_ds_acct_party_rls(microBatchDF.filter("LOB_CD='PAK'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='PAK'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_pak_ds_addr(microBatchDF.filter("LOB_CD='PAK'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_cust_acct" && microBatchDF.filter("LOB_CD='PAK'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_pak_ds_cust_acct(microBatchDF.filter("LOB_CD='PAK'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_addr" && microBatchDF.filter("LOB_CD='PAK'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_pak_ds_party_addr(microBatchDF.filter("LOB_CD='PAK'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party" && microBatchDF.filter("LOB_CD='PAK'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_pak_ds_party(microBatchDF.filter("LOB_CD='PAK'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_entity" && microBatchDF.filter("LOB_CD='PAK'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_pak_ds_party_entity(microBatchDF.filter("LOB_CD='PAK'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addl_intrst" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_addl_intrst(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_addr(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_bldg" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_bldg(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_bop_classification" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_bop_classification(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_flood_info" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_flood_info(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_form(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_bceg" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_geo_bceg(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_geo_info(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_bldg" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_line_bldg(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_loc" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_line_loc(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_line_mod1(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_line_mod2(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_line_mod3(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_loc" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_loc(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_manuscript"&& microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_manuscript(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_named_insured(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_non_filed_scr_rslt" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_nonfiled_scr_rslt(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_addr" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_party_addr(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_pol_line(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_party" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_pol_party(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='BP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_bp_ds_policy(microBatchDF.filter("LOB_CD='BP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_addr(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_form(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_loc" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_loc(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_non_filed_scr_rslt" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_nonfiled_scr_rslt(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_addr" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_party_addr(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_pol_line(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_party" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_pol_party(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_policy(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addl_intrst" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_addl_intrst(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_drvr" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_drvr(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_gar_srvc" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_gar_srvc(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_line_mod(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_mc_filing" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_mc_filing(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_mod" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_mod(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_veh" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_veh(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_audit_info" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_audit_info(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_manuscript" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_manuscript(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='CA'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_ca_ds_named_insured(microBatchDF.filter("LOB_CD='CA'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addl_intrst" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_addl_intrst(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_bldg" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_bldg(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_loc" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_loc(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_named_insured(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_pol_line(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_addr(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_bceg" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_geo_bceg(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_loc" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_line_loc(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_manuscript" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_manuscript(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_addr" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_party_addr(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_party" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_pol_party(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy"&& microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_policy(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_form(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_geo_info(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_jurs" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_jurs(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_non_filed_scr_rslt" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_nonfiled_scr_rslt(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pers_prop" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_pers_prop(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_bus_incm" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_bus_incm(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_covg" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_covg(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_bldg" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_line_bldg(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod_1" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_line_mod_1(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod_2" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_line_mod_2(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_manuscript" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_manuscript(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_occ_cl" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_occ_cl(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_spcl_cl" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_spcl_cl(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_fact_prem_tran_legacy" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_fact_prem_tran(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "cp_fact_staging" && microBatchDF.filter("LOB_CD='CP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cp_ds_fact_staging(microBatchDF.filter("LOB_CD='CP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addl_intrst" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_addl_intrst(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_addr(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_bldg" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_bldg(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_flood_info" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_flood_info(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_form(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_geo_info(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_jurs" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_jurs(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_bldg" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_line_bldg(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_loc" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_line_loc(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_loc" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_loc(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_manuscript"&& microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_manuscript(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_named_insured(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_non_filed_scr_rslt" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_nonfiled_scr_rslt(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_addr" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_party_addr(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_pol_line(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_party" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_pol_party(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_policy(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_spoil_dfncy" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_spoil_dfncy(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_covg" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_covg(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_crime_dfncy" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_crime_dfncy(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_line_mod_1(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_line_mod_2(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_fact_prem_tran_legacy" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_fact_prem_tran(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "cop_fact_staging" && microBatchDF.filter("LOB_CD='COP'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cop_ds_fact_staging(microBatchDF.filter("LOB_CD='COP'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='GL'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_gl_ds_policy(microBatchDF.filter("LOB_CD='GL'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addl_intrst" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_addl_intrst(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_addr(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_form(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_geo_info(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_jurs" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_jurs(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_loc" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_loc(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_manuscript"&& microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_manuscript(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_named_insured(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_non_filed_scr_rslt" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_nonfiled_scr_rslt(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_pol_line(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_party" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_pol_party(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_policy(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_covg" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_covg(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_line_mod_1(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='CRM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_crm_ds_line_mod_2(microBatchDF.filter("LOB_CD='CRM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
    if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_addr(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_form(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "DS_FCLTV_REINS" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_fcltv_reins(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_geo_info(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_manuscript"&& microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_manuscript(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_named_insured(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_covg" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_covg(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_line_mod_1(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_line_mod_2(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "DS_UMBR_UL_POL" && microBatchDF.filter("LOB_CD='CU'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_cu_ds_umbr_ul_pol(microBatchDF.filter("LOB_CD='CU'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addl_intrst" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_addl_intrst(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_addr(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_form" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_form(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_geo_info(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_jurs" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_jurs(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_loc" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_loc(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_party_addr"&& microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_party_addr(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_named_insured(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_pol_line(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_party" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_pol_party(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_policy(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_covg" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_covg(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_line_mod_1(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_mod" && microBatchDF.filter("LOB_CD='IM'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_im_ds_line_mod_2(microBatchDF.filter("LOB_CD='IM'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
    if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_addr" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_addr(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_pol_party" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_line_pol_party(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_prtcptng_plan" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_prtcptng_plan(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_jurs" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_jurs(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_rtg_prd_start" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_rtg_prd_start(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_line_cl_cd"&& microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_line_cl_cd(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_named_insured" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_named_insured(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_pol_line" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_pol_line(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_nonfiled_scr_rslt" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_nonfiled_scr_rslt(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_policy" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_policy(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_covg" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_covg(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  if (harmonizedDB == "pcds_agreement_harmonized" && target == "ds_geo_info" && microBatchDF.filter("LOB_CD='WC'").count()>0 && microBatchDF.filter("SOURCE_SYSTEM='HV'").count()>0){
        print("Entering into Query .."+harmonizedDB+"."+target)
        merge_hv_wc_ds_geo_info(microBatchDF.filter("LOB_CD='WC'").filter("SOURCE_SYSTEM='HV'"), batchId, rawDB, harmonizedDB, target)
  }
  
//   XYZ Merge
//   else if (harmonizedDB == "pg_hrm" && target == "abcd"){
//        merge_abcd(microBatchDF, batchId, rawDB, harmonizedDB, target)
//   }   
  
}

// COMMAND ----------

// DBTITLE 1,Harmonize Master Notebook - path can change relative to your child notebook location
// MAGIC %run ./merge_stream_master

// COMMAND ----------

startHarmonizerStreamingMain(groupId) 
