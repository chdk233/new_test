// Databricks notebook source
import sqlContext.implicits._ 
import org.apache.spark.sql.functions._
import io.delta.tables._

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.DataFrame
import org.apache.spark.storage.StorageLevel._

// COMMAND ----------

// DBTITLE 1,Library Functions used in Agreement Domain
  // Agreement Related functions
// ------------------------

def removeTestAgency_clt (df: DataFrame, rawDB: String, environment: String): DataFrame = {

if(environment.toUpperCase() == "PROD")
{ df.createOrReplaceGlobalTempView("Harmz_Query")
  
var Exclusion = f"""select * from global_temp.Harmz_Query where NOT EXISTS (select '1' from ( SELECT DISTINCT polper.publicID FROM $rawDB.PC_PolicyPeriod polper INNER JOIN $rawDB.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID INNER JOIN $rawDB.pc_group grp ON prodcode.branchID = grp.id WHERE grp.Agencynum_ext IN ( select Distinct Agencynum_ext from $rawDB.pc_group where trim(int(substr(pc_group.Agencynum_ext,4))) >= 29800 and trim(int(substr(pc_group.Agencynum_ext,4))) <= 29999 OR Agencynum_ext = '00019999') OR polper.PolicyNumber IN ('ACP BP013200000000','ACP BP013200000761')) temp  where temp.PUBLICID=POLPER_PUBLICID)  
"""
var FinalDF = spark.sql(Exclusion)
  return FinalDF }
  else 
  {
  return df
  }
}

def addSurrogateID_clt(df:DataFrame, target:String ) = {   
  
    val maxSK = spark.table(s"${target}").count 
    val surrogateID= s"${target}".substring(target.indexOf(".")+4)+"_ID"
    val w  = Window.orderBy($"ETL_ROW_EFF_DTS")
    var df1 = df.withColumn(surrogateID, row_number.over(w) + maxSK)    
    df1.createOrReplaceGlobalTempView("surrogateKeyData")
    var df2 = spark.sql(s""" select *,XXHASH64(${surrogateID},PARTITION_VAL) as ${surrogateID}_New from global_temp.surrogateKeyData """ )
    df2.drop(s"${surrogateID}").withColumnRenamed(s"${surrogateID}_New",s"${surrogateID}")

}

def addSurrogateID_gt(df: DataFrame, target: String, datevalue: String) = {   
    val maxSK = spark.table(s"${target}").count
    val surrogateID= s"${target}".substring(target.indexOf(".")+4)+"_ID"
    val w  = Window.orderBy(datevalue)
    var df1 = df.withColumn(surrogateID, row_number.over(w) + maxSK)    
    df1.createOrReplaceGlobalTempView("surrogateKeyData")
    var df2 = spark.sql(s""" select *,XXHASH64(${surrogateID},PARTITION_VAL) as ${surrogateID}_New from global_temp.surrogateKeyData """ )
    df2.drop(s"${surrogateID}").withColumnRenamed(s"${surrogateID}_New",s"${surrogateID}")
}

def getSurrogateIDCol_clt(target:String) : String = {   
    val surrogateID= s"${target}".substring(target.indexOf(".")+4)+"_ID"
     return surrogateID
}

def getSurrogateIDReturnCol_clt(df:DataFrame, target:String, surrogate: String) : String = {   
    val maxSK = spark.table(s"${target}").count
    val surrogateID= surrogate
     return surrogateID
}

def addSurrogateID(df:DataFrame, target:String, surrogate: String) = {

    val maxSK = spark.table(s"${target}").count
    val surrogateID= surrogate
    val w = Window.orderBy($"ETL_ROW_EFF_DTS")
    var df1 = df.withColumn(surrogateID, row_number.over(w) + maxSK)
    df1.createOrReplaceGlobalTempView("surrogateKeyData")
    var df2 = spark.sql(s""" select *,XXHASH64(${surrogateID},PARTITION_VAL) as ${surrogateID}_New from global_temp.surrogateKeyData """ )
    df2.drop(s"${surrogateID}").withColumnRenamed(s"${surrogateID}_New",s"${surrogateID}")
}

def addHashColumnXXHash_clt(viewname: String) = {
  var allCols = spark.sql(s"select * from global_temp.${viewname}").schema.fieldNames.toList
  println("allCols: "+ allCols)
  val hash_exclude_cols = List("_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","MD5_HASH","surrogatekey") ++ List("ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS")
  println("hash_exclude_cols: "+ hash_exclude_cols)
  val hash_cols = allCols.map(_.toLowerCase) diff hash_exclude_cols.map(_.toLowerCase)
  println("hash_cols: "+ hash_cols)  
  val cols=hash_cols.mkString(",")
  val qry=s""" select *,XXHASH64(${cols}) as MD5_HASH from global_temp.${viewname} """ 
  println("hash_query: "+ qry) 
  spark.sql(qry)  
}


def removeDuplicatesMultistream_clt(df: DataFrame, target: String, targetKey: String, partitionKey: String, partitionValue: String) = {

    print("in removeduplicates function2 \n")

    val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
    val firsRowDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
    print(firsRowDF.schema.fieldNames.toList)

    val targetDF = spark.sql(s"select * from ${target} where ${partitionKey} == '${partitionValue}' and ETL_CURR_ROW_FL = 'Y'")//DeltaTable.forName(spark, target).toDF
    val join_keys = targetKey.split(",").toSeq
    val joinExprs = join_keys.map{case (c1) => firsRowDF(c1) === s"targetDF.${c1}"}.reduce(_ && _)
  
    val keyCol1 =join_keys(0)
    val keyCol2 =join_keys(1)

    val latestInTargetDF = targetDF.as("tgtDF").join(firsRowDF.as("srcDF"),  $"srcDF.${keyCol1}" === $"tgtDF.${keyCol1}" && $"srcDF.${keyCol2}" === $"tgtDF.${keyCol2}" ).filter($"tgtDF.ETL_CURR_ROW_FL" === 'Y').select($"tgtDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*)
  
//     val latestInTargetDF = firsRowDF.join(targetDF.as("targetDF"), joinExprs && s"targetDF.${partitionKey}" == partitionValue, "right").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select($"targetDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*)
//     val latestInTargetDF = targetDF.as("targetDF").join(firsRowDF, joinExprs && s"targetDF.${partitionKey}" == partitionValue, "leftsemi").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select(firsRowDF.schema.fieldNames.toList.map(col): _*)
    print("\n latestInTargetDF cols")
    print(latestInTargetDF.schema.fieldNames.toList)
  
    val outOfSeqDF = latestInTargetDF.as("tgtDF").join(df.as("srcDF"),  $"srcDF.${keyCol1}" === $"tgtDF.${keyCol1}" && $"srcDF.${keyCol2}" === $"tgtDF.${keyCol2}" ,"right").filter($"srcDF.ETL_ROW_EFF_DTS" > $"tgtDF.ETL_ROW_EFF_DTS" && $"tgtDF.${keyCol1}".isNotNull || $"tgtDF.${keyCol1}".isNull).select($"srcDF.*").select(df.schema.fieldNames.toList.map(col): _*)
   
    //add target latest rows to microbatch
    val df2 = outOfSeqDF.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
    df2.show(3,false)

    // remove consecutive duplicates, choose first
    val w3 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col("ETL_ROW_EFF_DTS").asc,col("isTarget").desc)
    val df3 = df2.withColumn("dupe",  $"MD5_HASH" === lag($"MD5_HASH", 1).over(w3)).where($"dupe" === false || $"dupe".isNull ).drop("dupe")

    // If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
    val w2 =  Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*)
    val df4 = df3.withColumn("count",  count($"*").over(w2)).where($"count" =!= 1 || ($"isTarget" =!= 1  && $"count" === 1)).drop("count").drop("isTarget")

    df4.show(3,false)
    df4

}

//This function to remove duplictes based on Key column combination in a micrbatch based on the specified order by clause
def removeDuplicatesMicrobatch_clt(df: DataFrame, partitionKeys: String, orderbyCols: String) = {
  print("in removeduplicates microbatch function \n")
  val w = Window.partitionBy(partitionKeys.split(",").map(colName => col(colName)): _*).orderBy( orderbyCols.split(",").map(colName => col(colName).desc): _*)
  val firsRowDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
  firsRowDF
}

//This function to remove duplictes based on Key column combination based on the specified order by clause
def removeDuplicates(df: DataFrame, partitionKeys: String, orderbyCols: String, order: String) = {
  print("in removeduplicates function \n")
  if (order == "desc") {
  val w = Window.partitionBy(partitionKeys.split(",").map(colName => col(colName)): _*).orderBy( orderbyCols.split(",").map(colName => col(colName).desc): _*)
  val firsRowDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
  firsRowDF
  }
  else
  {
  val w = Window.partitionBy(partitionKeys.split(",").map(colName => col(colName)): _*).orderBy( orderbyCols.split(",").map(colName => col(colName)): _*)
  val firsRowDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")
  }
}

def addAuditColumns_clt(df: DataFrame, targetKey: String) = {
       
    val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
    val auditDF = df.withColumn("ETL_ROW_EXP_DTS", lead($"ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999-12-31", "Y").otherwise("N"))    
  auditDF
  

  
}


// This function is same as above function, but uses SQL suntax to do the window function instead of scala. Needs to be tested for composite key before being used.
// def addAuditColumns_clt(viewname: String, targetKey: String) = {       
//     val auditDF = spark.sql(s"""SELECT *,
//             LEAD(ETL_ROW_EFF_DTS,1,"9999") OVER (PARTITION BY $targetKey ORDER BY ETL_ROW_EFF_DTS ASC) as ETL_ROW_EXP_DTS, 'N' as ETL_CURR_ROW_FL  , current_timestamp() as ETL_ADD_DTS, current_timestamp() as ETL_LAST_UPDATE_DTS
//             FROM global_temp.${viewname}""").withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999", "Y").otherwise("N"))        
//   auditDF
// }

def defaultMergeMultistream_clt (df: DataFrame, target: String, partition_col: String, partition_val: String) = {
  
    DeltaTable.forName(spark, target)
    .as("events")
    .merge(
      df.as("updates"),
      s"events.MD5_HASH = updates.MD5_HASH AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.${partition_col} = '${partition_val}'")  
    .whenMatched
    .updateExpr( 
        Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EXP_DTS",
            "ETL_CURR_ROW_FL" -> "'N'",
            "ETL_LAST_UPDATE_DTS" -> "current_timestamp()"
           )
      )
    .whenNotMatched
    .insertAll()
    .execute()   
}

//def removeLogicalDelete_clt (df: DataFrame): DataFrame = {
//df.createOrReplaceGlobalTempView("Harmz_Query")

//var LogicalDelete = """select * from global_temp.Harmz_Query where (COALESCE(SRC_EFFECTIVEDATE, POLPER_PERIODSTART ) <> //COALESCE(SRC_EXPIRATIONDATE, POLPER_PERIODEND) OR NOT EXISTS (SELECT 1 FROM global_temp.Harmz_Query TBL2 WHERE SRC_BRANCHID = TBL2.SRC_BRANCHID AND   SRC_FIXEDID  = TBL2.SRC_FIXEDID AND (COALESCE(TBL2.SRC_EFFECTIVEDATE, POLPER_PERIODSTART) <>COALESCE(TBL2.SRC_EXPIRATIONDATE, POLPER_PERIODEND))))""" 
 // var LDdf = spark.sql(LogicalDelete) 
  //return LDdf 
//}

def removeLogicalDelete_clt (df: DataFrame): DataFrame = {
  
        df.createOrReplaceGlobalTempView("Harmz_Query")
        var LogicalDelete = """SELECT * FROM GLOBAL_TEMP.HARMZ_QUERY WHERE SRC_PUBLICID NOT IN (SELECT SRC_PUBLICID FROM (SELECT T1.SRC_PUBLICID, T1.SRC_FIXEDID,CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED ,CASE WHEN MAX( CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) <> trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END ) OVER ( PARTITION BY T1.SRC_BRANCHID, T1.SRC_FIXEDID ) = 0
        THEN 1 ELSE 0 END AS BRANCH_PRUNED ,RANK() OVER ( PARTITION BY T1.SRC_FIXEDID, T1.SRC_BRANCHID, trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) ORDER BY T1.SRC_UPDATETIME DESC, T1.SRC_CREATETIME DESC, T1.SRC_PUBLICID DESC ) AS JUST_ONE_PRUNE FROM (select distinct SRC_FIXEDID, SRC_BRANCHID, SRC_EFFECTIVEDATE, POLPER_PERIODSTART,SRC_EXPIRATIONDATE,POLPER_PERIODEND,SRC_PUBLICID,SRC_UPDATETIME,SRC_CREATETIME FROM GLOBAL_TEMP.HARMZ_QUERY) T1)
        WHERE IS_DELETED = 1 AND NOT (BRANCH_PRUNED = 1 AND JUST_ONE_PRUNE = 1))"""
        var LDdf = spark.sql(LogicalDelete)
        return LDdf
}

def removeLogicalDelete_gt (df: DataFrame): DataFrame = {
  
  df.createOrReplaceGlobalTempView("Harmz_Query")
        var LogicalDeleteCost = """SELECT * FROM GLOBAL_TEMP.HARMZ_QUERY WHERE SRC_COST_PUBLICID NOT IN (SELECT SRC_COST_PUBLICID FROM (SELECT T1.SRC_COST_PUBLICID, T1.SRC_COST_FIXEDID, 
CASE WHEN TRIM(COALESCE(T1.SRC_COST_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = TRIM(COALESCE(T1.SRC_COST_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED  
FROM GLOBAL_TEMP.HARMZ_QUERY T1 WHERE POL_KEY LIKE '%QT%' ) WHERE IS_DELETED = 1)"""
    
  df.createOrReplaceGlobalTempView("LogicalDeleteCost")
        var LogicalDeleteTran = """SELECT * FROM GLOBAL_TEMP.LogicalDeleteCost WHERE SRC_TRAN_PUBLICID NOT IN (SELECT SRC_TRAN_PUBLICID FROM (SELECT T1.SRC_TRAN_PUBLICID, T1.SRC_TRAN_FIXEDID, 
CASE WHEN TRIM(COALESCE(T1.SRC_TRAN_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = TRIM(COALESCE(T1.SRC_TRAN_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED  
FROM GLOBAL_TEMP.LogicalDeleteCost T1 WHERE POL_KEY NOT LIKE '%QT%' ) WHERE IS_DELETED = 1)"""
        
        var LDdf = spark.sql(LogicalDeleteTran)
        return LDdf
}

def orphanRecords_Clt (df: DataFrame,harmonized_table:String,partition_col:String,partition_val:String,key_column:String): Unit = {

df.createOrReplaceGlobalTempView("stage_table")
var update_bound_query1 = s"""MERGE INTO $harmonized_table TGT USING 
(SELECT $partition_col,pol_key,key_column,END_EFF_DT, LATEST_BY_POLICY as exp_dts FROM (SELECT $partition_col,pol_key, END_EFF_DT, $key_column as key_column,ETL_ROW_EFF_DTS,
MAX(etl_row_eff_dts) OVER ( PARTITION BY pol_key, $key_column, END_EFF_DT ) AS LATEST_BY_GRAIN, 
MAX(etl_row_eff_dts) OVER ( PARTITION BY pol_key ) AS LATEST_BY_POLICY 
FROM global_temp.stage_table 
WHERE POL_KEY NOT LIKE '%QT%' AND $partition_col='${partition_val}') 
WHERE LATEST_BY_GRAIN < LATEST_BY_POLICY GROUP BY $partition_col,pol_key, key_column ,exp_dts, END_EFF_DT) UPDT 
ON TGT.pol_key = UPDT.pol_key and 
TGT.$key_column = UPDT.key_column 
AND TGT.END_EFF_DT = UPDT.END_EFF_DT 
AND TGT.etl_curr_row_fl = 'Y'  
AND TGT.END_EFF_DT <> TGT.END_EXP_DT
AND TGT.$partition_col='${partition_val}'
AND UPDT.$partition_col='${partition_val}'
WHEN MATCHED THEN UPDATE SET TGT.etl_row_exp_dts = UPDT.exp_dts, TGT.etl_curr_row_fl = 'N',TGT.ETL_LAST_UPDATE_DTS = TO_TIMESTAMP(CURRENT_TIMESTAMP());"""

var update_nonbound_query1 = s"""MERGE INTO $harmonized_table TGT USING 
(SELECT $partition_col,POL_KEY,key_column,UPDT_ROW_EXP_DTS,ETL_ROW_EFF_DTS FROM 
(SELECT $partition_col,POL_KEY,UPDT_ROW_EXP_DTS,key_column,ETL_ROW_EFF_DTS,ROW_NUMBER() OVER ( PARTITION BY POL_KEY,key_column,ETL_ROW_EFF_DTS ORDER BY UPDT_ROW_EXP_DTS DESC ) AS TIE_BREAKER 
FROM ( SELECT $partition_col,POL_KEY,key_column,ETL_ROW_EFF_DTS,ETL_ROW_EXP_DTS,COALESCE(LAG(ETL_ROW_EFF_DTS) OVER ( PARTITION BY POL_KEY,key_column ORDER BY ETL_ROW_EFF_DTS DESC), ETL_ROW_EXP_DTS) UPDT_ROW_EXP_DTS
FROM (SELECT DISTINCT TABLE1.$partition_col,TABLE1.POL_KEY,TABLE1.$key_column as key_column,TABLE1.ETL_ROW_EFF_DTS,TABLE1.ETL_ROW_EXP_DTS,TABLE1.END_EFF_DT,TABLE1.END_EXP_DT 
FROM $harmonized_table TABLE1 INNER JOIN $harmonized_table TABLE2 ON TABLE1.POL_KEY = TABLE2.POL_KEY 
AND TABLE1.$key_column = TABLE2.$key_column AND TABLE1.END_EFF_DT < TABLE2.END_EXP_DT AND TABLE1.END_EXP_DT > TABLE2.END_EFF_DT AND TABLE1.END_EFF_DT <> TABLE2.END_EXP_DT AND (TABLE1.END_EFF_DT <> TABLE2.END_EFF_DT OR TABLE1.END_EXP_DT <> TABLE2.END_EXP_DT) AND TABLE1.ETL_ROW_EFF_DTS < TABLE2.ETL_ROW_EXP_DTS AND TABLE1.ETL_ROW_EXP_DTS > TABLE2.ETL_ROW_EFF_DTS and TABLE1.POL_KEY LIKE '%QT%' and TABLE1.$partition_col=TABLE2.$partition_col AND TABLE1.$partition_col='${partition_val}'AND TABLE2.$partition_col='${partition_val}') TMP ) WHERE ETL_ROW_EXP_DTS <> UPDT_ROW_EXP_DTS ) TMP2 
WHERE TIE_BREAKER = 1) UPDT ON (TGT.POL_KEY = UPDT.POL_KEY AND TGT.$key_column = UPDT.key_column AND TGT.ETL_ROW_EFF_DTS = UPDT.ETL_ROW_EFF_DTS AND TGT.$partition_col='${partition_val}' AND UPDT.$partition_col='${partition_val}') 
WHEN MATCHED THEN UPDATE SET TGT.ETL_ROW_EXP_DTS = UPDT.UPDT_ROW_EXP_DTS,TGT.ETL_CURR_ROW_FL = 'N';"""

spark.sql(update_bound_query1) 
spark.sql(update_nonbound_query1) 

}


   
//function to remove additional columns present in Harmonize query
def removeAdditionalCols_clt (df: DataFrame, target : String) : DataFrame= {
  print("in AdditionalColstoRemove function \n")
  val dfCols = df.schema.fieldNames.toList
  val targetCols = DeltaTable.forName(spark, target).toDF.schema.fieldNames.toList
  val AdditionalColsToRemove = dfCols.map(_.toLowerCase) diff targetCols.map(_.toLowerCase)
  print("Additional Columns list: \n")
  print(AdditionalColsToRemove)
  var queryDF =df.drop(AdditionalColsToRemove : _*)
  return queryDF
}

def removeDuplicatesMicrobatchByHash_clt(df: DataFrame, targetKey: String ) = {

    print("in removeDuplicatesMicrobatch By Hash \n")

  // remove consecutive duplicates, choose first
    val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col("ETL_ROW_EFF_DTS").asc)
    val df1 = df.withColumn("dupe",  $"MD5_HASH" === lag($"MD5_HASH", 1).over(w)).where($"dupe" === false || $"dupe".isNull ).drop("dupe")

    df1.show(3,false)
    df1

}

def scdMerge_clt(queryDF: DataFrame, harmonized_table: String, key: String, partitionKey: String, partitionValue: String, surrogateId : String): DataFrame = {
  
val join_keys = key.split(",").toSeq
val keyCol1 =join_keys(0)
val keyCol2 =join_keys(1)  
val keyCol3 =join_keys(2) 
  

//Target Dataframe with Matching records
val targetDF  =  queryDF.as("events").join(DeltaTable.forName(spark, harmonized_table).toDF.as("updates"),$"events.${keyCol1}" ===  $"updates.${keyCol1}" && $"events.${keyCol2}" === $"updates.${keyCol2}" && $"events.${keyCol3}" === $"updates.${keyCol3}"  && $"updates.${partitionKey}" === s"${partitionValue}" ).select($"updates.*")
  
  
// DataFrame for Type1 records with same MD5_HASH value from Source Microbtach Dataframe
val SrcTgtDF = queryDF.as("events").join(targetDF.as("updates"),$"events.${keyCol1}" ===  $"updates.${keyCol1}" && $"events.${keyCol2}" === $"updates.${keyCol2}" && $"events.${keyCol3}" === $"updates.${keyCol3}" && $"updates.${partitionKey}" === s"${partitionValue}" && $"events.MD5_HASH" === $"updates.MD5_HASH").select($"events.*")

// DataFrame for Type1 records with different MD5_HASH value & Non-Type1 from Source Microbtach Dataframe
val queryDF1 = queryDF.except(SrcTgtDF)

// DataFrame with SrcMD5Hash <> TgtMD5Hash , Replaced Src with Tgt columns (ETL_ROW_EXP_DTS & ETL_ADD_DTS) to comply with databricks merge statement 
  
val SrcTgtDF1 = queryDF1.as("events").join(targetDF.as("updates"),$"events.${keyCol1}" ===  $"updates.${keyCol1}" && $"events.${keyCol2}" === $"updates.${keyCol2}" && $"events.${keyCol3}" === $"updates.${keyCol3}" && $"updates.${partitionKey}" === s"${partitionValue}" && $"events.MD5_HASH" != $"updates.MD5_HASH").select($"events.*",$"updates.ETL_ROW_EXP_DTS" as ("Tgt_Exp"),$"updates.ETL_ADD_DTS" as ("Tgt_Ead"),$"updates.${surrogateId}" as ("Tgt_ID")
,$"updates.ETL_CURR_ROW_FL" as ("Tgt_Curr_Row_Fl"))

val SrcTgtDF2 = SrcTgtDF1.withColumnRenamed("Tgt_Ead","ETL_ADD_DTS").withColumnRenamed("Tgt_Exp","ETL_ROW_EXP_DTS").withColumnRenamed("Tgt_ID",s"${surrogateId}").withColumnRenamed("Tgt_Curr_Row_Fl","ETL_CURR_ROW_FL").withColumn("ETL_LAST_UPDATE_DTS", current_timestamp())

// Merging Source DF with Tgt if any updates on existing data 

DeltaTable.forName(spark, harmonized_table)
                .as("t")
    .merge(
      SrcTgtDF2.as("s"),
      s"t.${keyCol1} = s.${keyCol1} AND t.${keyCol2} = s.${keyCol2} AND t.${keyCol3} = s.${keyCol3} AND t.${partitionKey} = '${partitionValue}' AND t.MD5_HASH != s.MD5_HASH") 
    .whenMatched
    .updateAll() 
    .execute()
 
// Reverting back to actual Dataframe by dropping additional columns
  
val ReturnDF =  SrcTgtDF1.drop("Tgt_Exp","Tgt_Ead","Tgt_ID","Tgt_Curr_Row_Fl")

// Returning the left over Dataframe which will be used for further processing/Functions. This is Non Type1 Dataframe  
val FinalDF = queryDF1.except(ReturnDF)
                
                return FinalDF
}

// this logic is created for IM Fact
def scdType1Merge_clt(queryDF: DataFrame, curated_table: String, key: String ,partitionKey: String, partitionValue: String, surrogateId : String ) = {
  
  // New records for insert flow
val SrcTgtDF1 = queryDF.as("events").join(DeltaTable.forName(spark, curated_table).toDF.as("updates"),$"events.${key}" ===  $"updates.${key}" && $"updates.${partitionKey}" === s"${partitionValue}","left" ).select($"events.*",$"events.ETL_ADD_DTS" as ("Src_Ead"),$"events.${surrogateId}" as ("Src_ID"), $"updates.${surrogateId}" as ("Tgt_ID")).filter(col("Tgt_ID").isNull)

//Existing data set for update flow
val SrcTgtDF2 = queryDF.as("events").join(DeltaTable.forName(spark, curated_table).toDF.as("updates"),$"events.${key}" ===  $"updates.${key}" && $"updates.${partitionKey}" === s"${partitionValue}").select($"events.*",$"updates.ETL_ADD_DTS" as ("Tgt_Ead"),$"updates.${surrogateId}" as ("Tgt_ID"))

 val SrcTgtDF3 = SrcTgtDF2.drop("ETL_ADD_DTS",s"${surrogateId}").withColumnRenamed("Tgt_Ead","ETL_ADD_DTS").withColumnRenamed("Tgt_ID",s"${surrogateId}")
 val SrcTgtDF4 = SrcTgtDF1.drop("ETL_ADD_DTS",s"${surrogateId}","Tgt_ID").withColumnRenamed("Src_Ead","ETL_ADD_DTS").withColumnRenamed("Src_ID",s"${surrogateId}")
  SrcTgtDF1.show(3,false)
  SrcTgtDF2.show(3,false)
  SrcTgtDF3.show(3,false)
  SrcTgtDF4.show(3,false)

  
// Union of above 2 Dataframes
val queryDF1 = SrcTgtDF4.union(SrcTgtDF3)

DeltaTable.forName(spark, curated_table).as("t")
    .merge(
      queryDF1.as("s"),
      s"t.$key = s.$key AND t.${partitionKey} = '${partitionValue}'") 
    .whenNotMatched
    .insertAll()
    .whenMatched
    .updateAll() 
    .execute()  
}

// this logic is to create harmonize stage table - truncate and load 
def createHarmonizeStage_clt(harmonized_table_stg: String, viewname: String) = {

    println("Stage Table build ssssssstart: " + harmonized_table_stg)
    var cols = spark.table(harmonized_table_stg).schema.fieldNames.toList.mkString(",")
    spark.sql(s"delete from ${harmonized_table_stg}")
    val query = s"insert into ${harmonized_table_stg} ($cols) select $cols from global_temp.${viewname}"
    println("Stage Insert query: " + query)
    spark.sql(query)
    val qryDF2= spark.sql(s"select * from ${harmonized_table_stg} ")

    qryDF2.show(3,false)
    qryDF2
}

// COMMAND ----------

// DBTITLE 1,Library Functions used in Agreement Domain - DHF 1.0
// Non CLT Projects, NM, Betterview

def addSurrogateKey_clt(df:DataFrame, target:String ) = {   
      val maxSK = spark.table(s"${target}").count 
    val w  = Window.orderBy($"ETL_ROW_EFF_DTS")
    df.withColumn("surrogatekey", row_number.over(w) + maxSK)  
  
}

def removeDuplicates_clt(df: DataFrame, target: String, targetKey: String) = {
    print("in removeduplicates function2 \n")
 
    val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
    val firsRowDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")   
    print(firsRowDF.schema.fieldNames.toList) 
   
    val latestInTargetDF = firsRowDF.join(DeltaTable.forName(spark, target).toDF.as("targetDF"), targetKey.split(",").toSeq, "right").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select($"targetDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*)  
    print("\n latestInTargetDF cols")
    print(latestInTargetDF.schema.fieldNames.toList)  
 
    //add target latest rows to microbatch
    val df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
    df2.show(3,false)
    // remove consecutive duplicates, choose first 
    val w3 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col("ETL_ROW_EFF_DTS").asc,col("isTarget").desc)
    val df3 = df2.withColumn("dupe",  $"row_hashed" === lag($"row_hashed", 1).over(w3))
            .where($"dupe" === false || $"dupe".isNull ).drop("dupe") 
  
    // If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
    val w2 =  Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*)
    val df4 = df3.withColumn("count",  count($"*").over(w2)).where($"count" =!= 1 || ($"isTarget" =!= 1  && $"count" === 1)).drop("count").drop("isTarget")
  
    df4.show(3,false)
    df4    
}

def defaultMerge_clt (df: DataFrame, target: String) = {
  
    DeltaTable.forName(spark, target)
    .as("events")
    .merge(
      df.as("updates"),
      "events.row_hashed = updates.row_hashed AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS") 
    .whenMatched
    .updateExpr( 
        Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EXP_DTS",
            "ETL_CURR_ROW_FL" -> "'N'",
            "ETL_LAST_UPDATE_DTS" -> "current_timestamp()"
           )
      )
    .whenNotMatched
    .insertAll()
    .execute()   
}

def addHashColumn_clt(viewname: String) = {
  var allCols = spark.sql(s"select * from global_temp.${viewname}").schema.fieldNames.toList
  println("allCols: "+ allCols)
  val hash_exclude_cols = List("_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey") ++ List("ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS")
  println("hash_exclude_cols: "+ hash_exclude_cols)
  val hash_cols = allCols.map(_.toLowerCase) diff hash_exclude_cols.map(_.toLowerCase)
  println("hash_cols: "+ hash_cols)  
  val cols=hash_cols.mkString(",")
  val qry=s""" select *,hash(${cols}) as row_hashed from global_temp.${viewname} """ 
  println("hash_query: "+ qry) 
  spark.sql(qry)  
}

// COMMAND ----------

// DBTITLE 1,Function - Common -  DHF 1.0 release

// Function - DHF 1.0 release - June 25th
// ---------------------------------------


def getSurrogateKey(viewname:String, target:String ) = {  
   val maxSK = spark.table(s"${target}").count 
   val qry=s"""select row_number() over(order by NULL) + ${maxSK} as surrogatekey,* from global_temp.${viewname} """ 
   spark.sql(qry)    
}

def getHash(viewname: String, hash_cols: List[String]) = {
  val cols=hash_cols.mkString(",")
  val qry=s""" select *,hash(${cols}) as row_hashed from global_temp.${viewname} """  
  spark.sql(qry)  
}

def addHashAndSurrogateCols(viewname: String, target: String) = {
  val surrogateKeyDF=getSurrogateKey(viewname, target)
  surrogateKeyDF.createOrReplaceGlobalTempView(viewname)
  
  var allCols = surrogateKeyDF.schema.fieldNames.toList
  println("allCols: "+ allCols)
  val hash_exclude_cols = List("_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey") ++ List("ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS")
  println("hash_exclude_cols: "+ hash_exclude_cols)
  val hash_cols = allCols.map(_.toLowerCase) diff hash_exclude_cols.map(_.toLowerCase)
  println("hash_cols: "+ hash_cols)
  val hashedDF=getHash(viewname, hash_cols)  
  
  hashedDF
}

def addAuditColumns(viewname: String, targetKey: String) = {
       
    val auditDF = spark.sql(s"""SELECT *,
            LEAD(ETL_ROW_EFF_DTS,1,"9999") OVER (PARTITION BY $targetKey ORDER BY ETL_ROW_EFF_DTS ASC) as ETL_ROW_EXP_DTS, 'N' as ETL_CURR_ROW_FL, current_timestamp() as ETL_ADD_DTS, current_timestamp() as ETL_LAST_UPDATE_DTS  
            FROM global_temp.${viewname}""").withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999", "Y").otherwise("N"))     
   
  auditDF
}

def defaultMerge(auditDF:DataFrame, target: String,  targetKey: String) = { 
  
//     //remove duplicates comparing to Target   
//     val dedupedAuditDF = auditDF.as("df1").join(DeltaTable.forName(spark, target).toDF.as("targetDF"), $"df1.row_hashed" === $"targetDF.row_hashed", "left").withColumn("isDupe", when($"targetDF.ETL_CURR_ROW_FL" === 'Y', "YES").otherwise("NO")).filter($"isDupe" === "NO").select("df1.*")
  
    val dedupedAuditDF = auditDF
  
    //Get earliest record from microbatch for a key. This is used to expire target row.
    val w = Window.partitionBy(col(targetKey)).orderBy($"ETL_ROW_EFF_DTS".desc)
    val dedupDF = dedupedAuditDF.withColumn("rownum", row_number.over(w))
     .where($"rownum" === 1).drop("rownum")  
    println("dedupDF - updates:")
    dedupDF.show(3,false)
    
    // Expire old record in Target
    DeltaTable.forName(spark, target)
      .as("events")
      .merge(
        dedupDF.as("updates"),
        s"events.$targetKey = updates.$targetKey AND events.row_hashed != updates.row_hashed")
      .whenMatched("events.ETL_CURR_ROW_FL = 'Y'")
      .updateExpr( 
        Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EFF_DTS",
            "ETL_CURR_ROW_FL" -> "'N'",
            "ETL_LAST_UPDATE_DTS" -> "current_timestamp()")
      )
      .execute() 
  
    // Write new records to Target
    DeltaTable.forName(spark, target)
    .as("events2")
    .merge(
      dedupedAuditDF.as("updates2"),
      "events2.row_hashed = updates2.row_hashed") 
    .whenNotMatched
    .insertAll()
    .execute() 
}

def defaultMerge_new(auditDF:DataFrame, target: String,  targetKey: String) = { 
  
    //remove duplicates comparing to Target   
     val dupesDF = auditDF.as("df1").join(DeltaTable.forName(spark, target).toDF.as("targetDF"), $"df1.row_hashed" === $"targetDF.row_hashed" && $"targetDF.ETL_CURR_ROW_FL" === 'Y').select("df1.*")   
     val dedupedAuditDF = auditDF.except(dupesDF)
     println("dedupedAuditDF - updates:")
     dedupedAuditDF.show(3,false) 
  
    //Get earliest record from microbatch for a key. This is used to expire target row.
    val w = Window.partitionBy(col(targetKey)).orderBy($"ETL_ROW_EFF_DTS".desc)
    val dedupDF = dedupedAuditDF.withColumn("rownum", row_number.over(w))
     .where($"rownum" === 1).drop("rownum")  
    println("dedupDF - updates:")
    dedupDF.show(3,false)
    
    // Expire old record in Target
    DeltaTable.forName(spark, target)
      .as("events")
      .merge(
        dedupDF.as("updates"),
        s"events.$targetKey = updates.$targetKey ")
      .whenMatched("events.ETL_CURR_ROW_FL = 'Y' AND events.row_hashed != updates.row_hashed")
      .updateExpr( 
        Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EFF_DTS",
            "ETL_CURR_ROW_FL" -> "'N'",
            "ETL_LAST_UPDATE_DTS" -> "current_timestamp()"
           )
      )
      .execute()  
  
      dedupedAuditDF.write.format("delta").mode("append").saveAsTable(target)
}

// COMMAND ----------

// DBTITLE 1,Library Functions used in Claims Domain - Claimless
def defaultMerge_claims(auditDF:DataFrame, target: String,  targetKey: String, hashCol: String) = { 
  
    //remove duplicates comparing to Target   
     val dupesDF = auditDF.as("df1").join(DeltaTable.forName(spark, target).toDF.as("targetDF"), $"df1.$hashCol" === $"targetDF.$hashCol" && $"targetDF.ETL_CURR_ROW_FL" === 'Y').select("df1.*")   
     val dedupedAuditDF = auditDF.except(dupesDF)
     println("dedupedAuditDF - updates:")
     dedupedAuditDF.show(3,false) 
  
    //Get earliest record from microbatch for a key. This is used to expire target row.
    val w = Window.partitionBy(col(targetKey)).orderBy($"ETL_ROW_EFF_DTS".desc)
    val dedupDF = dedupedAuditDF.withColumn("rownum", row_number.over(w))
     .where($"rownum" === 1).drop("rownum")  
    println("dedupDF - updates:")
    dedupDF.show(3,false)
    
    // Expire old record in Target
    DeltaTable.forName(spark, target)
      .as("events")
      .merge(
        dedupDF.as("updates"),
        s"events.$targetKey = updates.$targetKey ")
      .whenMatched(s"events.ETL_CURR_ROW_FL = 'Y' AND events.$hashCol != updates.$hashCol")
      .updateExpr( 
        Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EFF_DTS",
            "ETL_CURR_ROW_FL" -> "'N'",
            "ETL_LAST_UPDATE_DTS" -> "current_timestamp()"
           )
      )
      .execute()  
      
      // Insert all updates and new records
      dedupedAuditDF.write.format("delta").mode("append").saveAsTable(target)
}

def scd1Merge_claims(auditDF:DataFrame, target: String,  targetKey: String, hashCol: String) = { 
  val targetCols = DeltaTable.forName(spark, target).toDF.schema.fieldNames.toList
  
  var updateColMap = targetCols.filter(col => if(col != targetKey) true else false)
                        .map(col => if(col != "ETL_LAST_UPDATE_DTS")(col, s"updates.$col") else (col, "current_timestamp")).toMap
  
  DeltaTable.forName(spark, target)
      .as("events")
      .merge(
        auditDF.as("updates"),
        s"events.$targetKey = updates.$targetKey ")
      .whenMatched()
      .updateExpr(updateColMap)
      .whenNotMatched()
      .insertAll()
      .execute()
  
//   dedupedAuditDF.write.format("delta").mode("append").saveAsTable(target)
}

def removeDuplicates_claims(df: DataFrame, target: String, targetKey: String, hashCol:String, scdType:Int=2) = {
    print("in removeduplicates function2 \n")
   
    var windowOrder = "ETL_ROW_EFF_DTS"
    if (scdType == 1){
      windowOrder = "ETL_PROC_DTS"
    }
    
    var df2 = df
    if (scdType == 2){
      val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(windowOrder)
      val firsRowDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")   
      print(firsRowDF.schema.fieldNames.toList) 

      val latestInTargetDF = firsRowDF.join(DeltaTable.forName(spark, target).toDF.as("targetDF"), targetKey.split(",").toSeq, "right").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select($"targetDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*)  
      print("\n latestInTargetDF cols")
      print(latestInTargetDF.schema.fieldNames.toList)  

      //add target latest rows to microbatch
      val df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
      df2.show(3,false)
    }else{
      df2 = df.withColumn("isTarget", lit(1))
    }
    
    // remove consecutive duplicates, choose first 
    val w3 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col(windowOrder).asc,col("isTarget").desc)
    val df3 = df2.withColumn("dupe",  $"$hashCol" === lag($"$hashCol", 1).over(w3))
            .where($"dupe" === false || $"dupe".isNull ).drop("dupe") 
  
    // If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
    val w2 =  Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*)
    val df4 = df3.withColumn("count",  count($"*").over(w2)).where($"count" =!= 1 || ($"isTarget" =!= 1  && $"count" === 1)).drop("count").drop("isTarget")
  
    df4.show(3,false)
    df4    
}

def addHashColumn_claims(viewname: String) = { 
  var allCols = spark.sql(s"select * from global_temp.${viewname}").schema.fieldNames.toList
  println("allCols: "+ allCols)
  val hash_exclude_cols = List("_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey") ++ List("ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS")
  println("hash_exclude_cols: "+ hash_exclude_cols)
  val hash_cols = allCols.map(_.toLowerCase) diff hash_exclude_cols.map(_.toLowerCase)
  println("hash_cols: "+ hash_cols)  
  val cols=hash_cols.map("coalesce(" + _ +", \" \")").mkString(",")
  val qry=s""" select *,sha2(concat(${cols}), 256) as row_hashed from global_temp.${viewname}"""  
  spark.sql(qry)
}

// COMMAND ----------

// DBTITLE 1,Library Functions used in Claims Domain - Claims HV
// Claims-HV functions
def addAuditColumns_claims_HV(df4: DataFrame, targetKey: String) = { ////////////////df to df4
val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
val auditDF = df4.withColumn("ETL_ROW_EXP_DTS", lead($"ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999-12-31", "Y").otherwise("N")) ////////////////df to df4
auditDF
}

// This function is same as above function, but uses SQL suntax to do the window function instead of scala. Needs to be tested for composite key before being used.
// def addAuditColumns_clt(viewname: String, targetKey: String) = {
// val auditDF = spark.sql(s"""SELECT *,
// LEAD(ETL_ROW_EFF_DTS,1,"9999") OVER (PARTITION BY $targetKey ORDER BY ETL_ROW_EFF_DTS ASC) as ETL_ROW_EXP_DTS, 'N' as ETL_CURR_ROW_FL , current_timestamp() as ETL_ADD_DTS, current_timestamp() as ETL_LAST_UPDATE_DTS
// FROM global_temp.${viewname}""").withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999", "Y").otherwise("N"))
// auditDF
// }// Claim Related functions
// ------------------------

//Updated Method to avoid duplicate ID generation
def addSurrogateKey_claims_HV(auditDF:DataFrame, target:String, target_surrogateid:String) = {   
    val max_id_df = spark.sql(s"Select max(${target_surrogateid}) as max_id from ${target}").collect
    val maxSK = max_id_df(0).getAs[Long]("max_id") 
    var w  = Window.orderBy($"ETL_ROW_EFF_DTS")
    val surrDF = auditDF.withColumn({target_surrogateid}, row_number.over(w) + maxSK)
    surrDF
}

//Added new method to avoid Hash Collision
def addHashColumn_claims_HV(viewname: String, harmonized_table_surrogateid: String) = {
var allCols = spark.sql(s"select * from global_temp.${viewname}").schema.fieldNames.toList
println("allCols: "+ allCols)
val hash_exclude_cols = List("_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey","MD5_HASH",{harmonized_table_surrogateid}) ++ List("ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS")
println("hash_exclude_cols: "+ hash_exclude_cols)
val hash_cols = allCols.map(_.toLowerCase) diff hash_exclude_cols.map(_.toLowerCase)
println("hash_cols: "+ hash_cols)
val cols=hash_cols.mkString(",")
val qry=s""" select *,XXHASH64(${cols}) as MD5_HASH from global_temp.${viewname} """
val hashDF = spark.sql(qry)
hashDF //added
}


def removeDuplicatesMultistream_claims_HV(hashDF: DataFrame, target: String, targetKey: String, partitionKey: String, partitionValue: String) = { //////////////df to hashDF
print("in removeduplicates function2 \n")
  
val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
val firsRowDF = hashDF.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum") //////////////df to hashDF
print(firsRowDF.schema.fieldNames.toList)
  
val targetDF = spark.sql(s"select * from ${target} where ${partitionKey} == '${partitionValue}'")//DeltaTable.forName(spark, target).toDF
val join_keys = targetKey.split(",").toSeq
val joinExprs = join_keys.map{case (c1) => firsRowDF(c1) === s"targetDF.${c1}"}.reduce(_ && _)
  
val keyCol1 =join_keys(0)
val keyCol2 =join_keys(1)
  
//val latestInTargetDF = firsRowDF.join(DeltaTable.forName(spark, target).toDF.as("targetDF"), targetKey.split(",").toSeq, "right").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select($"targetDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*)
val latestInTargetDF = targetDF.as("tgtDF").join(firsRowDF.as("srcDF"),  $"srcDF.${keyCol1}" === $"tgtDF.${keyCol1}" && $"srcDF.${keyCol2}" === $"tgtDF.${keyCol2}" ).filter($"tgtDF.ETL_CURR_ROW_FL" === 'Y').select($"tgtDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*) 
  
print("\n latestInTargetDF cols")
print(latestInTargetDF.schema.fieldNames.toList)
  
//add target latest rows to microbatch
val df2 = hashDF.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1))) //////////////df to hashDF
  
// remove consecutive duplicates, choose first
val w3 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col("ETL_ROW_EFF_DTS").asc,col("isTarget").desc)
val df3 = df2.withColumn("dupe", $"MD5_HASH" === lag($"MD5_HASH", 1).over(w3))
.where($"dupe" === false || $"dupe".isNull ).drop("dupe")
  
// If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
val w2 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*)
val df4 = df3.withColumn("count", count($"*").over(w2)).where($"count" =!= 1 || ($"isTarget" =!= 1 && $"count" === 1)).drop("count").drop("isTarget")
df4
}


def defaultMergeMultistream_claims_HV (surrDF: DataFrame, target: String, partition_col: String, partition_val: String) = { ///////////////df to surrDF
DeltaTable.forName(spark, target)
.as("events")
.merge(
surrDF.as("updates"), //////////////////////df to surrDF
s"events.MD5_HASH = updates.MD5_HASH AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.${partition_col} = '${partition_val}'")
.whenMatched
.updateExpr(
Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EXP_DTS",
"ETL_CURR_ROW_FL" -> "'N'",
"ETL_LAST_UPDATE_DTS" -> "current_timestamp()"
)
)
.whenNotMatched
.insertAll()
.execute()
}


//Loss_Tran Specific Methods

def addAuditColumns_claims_HV_LossTran(df4: DataFrame, targetKey: String) = { 
//Generates current_timestamp as a value for ETL_ADD_DTS & ETL_LAST_UPDATE_DTS fields
val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_PROC_DTS")
val auditDF = df4
  .withColumn("ETL_ADD_DTS", current_timestamp())
  .withColumn("ETL_LAST_UPDATE_DTS", current_timestamp())
auditDF
}

def addSurrogateKey_claims_HV_LossTran(auditDF:DataFrame, target:String, target_surrogateid:String) = { 
//Generates sequential number as a value for LOSS_TRAN_ID field
val max_id_df = spark.sql(s"Select max(${target_surrogateid}) as max_id from ${target}").collect
val maxSK = max_id_df(0).getAs[Long]("max_id")
val w = Window.orderBy($"ETL_PROC_DTS")
val surrDF = auditDF.withColumn({target_surrogateid}, row_number.over(w) + maxSK) 
surrDF
}

def defaultMergeMultistream_claims_HV_LossTran(surrDF: DataFrame, target: String, partition_col: String, partition_val: String) = { 
//Checks if LOSS_TRNSC_KEY value already exists in harmonized table, if not inserts the records
DeltaTable.forName(spark, target)
.as("events")
.merge(
surrDF.as("updates"), 
s"events.LOSS_TRNSC_KEY = updates.LOSS_TRNSC_KEY AND events.${partition_col} = '${partition_val}'")
.whenNotMatched
.insertAll()
.execute()
}

// COMMAND ----------

// DBTITLE 1,CDC and ORPHAN Functions
//added function for the CDC Out of Sync

def mergeOutOfSync (df: DataFrame, target: String) = {
  
    DeltaTable.forName(spark, target).as("events")
    .merge(
      df.as("updates"),
      "events.MD5_HASH = updates.MD5_HASH AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS") 
    .whenMatched
    .updateExpr( 
        Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EXP_DTS",
            "ETL_CURR_ROW_FL" -> "updates.ETL_CURR_ROW_FL",
            "ETL_LAST_UPDATE_DTS" -> "current_timestamp()"
           )
      )
    .whenNotMatched
    .insertAll()
    .execute()   
}

//This function to capture the missing records and doing date chaining

def addAuditColumnsOutOfSync(df: DataFrame, target: String, targetKey: String) = {
      
  val firsRowDF = df
     println(firsRowDF.schema.fieldNames.toList)
  val tgtDF = DeltaTable.forName(spark, target).toDF
    tgtDF.createOrReplaceGlobalTempView("temptarget")
  
 println("selecting the common records between source and target: ")
   val SrcTargetDF = tgtDF.as("targetDF").join(df.as("srcDF"), targetKey.split(",").toSeq, "leftsemi").select(firsRowDF.schema.fieldNames.toList.map(col): _*)
   SrcTargetDF.show(3, false)
  
  //doing the union of source and target
  println("Union of source and target")
   val unionAllTempdf = df.withColumn("isTarget", lit(0)).union(SrcTargetDF.withColumn("isTarget", lit(1)))
     val unionTempdf = unionAllTempdf.drop("isTarget")
     unionTempdf.show(3, false)
  
   println("Drop Duplicates in unionTempdf: ")
    val nonDupUnionDf = unionTempdf.dropDuplicates("MD5_HASH","ETL_ROW_EFF_DTS") 
    nonDupUnionDf.show(3, false)
   
    val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
    val auditDF = nonDupUnionDf.withColumn("ETL_ROW_EXP_DTS", lead($"ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999-12-31", "Y").otherwise("N"))
  
  println("After adding Audit date columns")
  auditDF.show(2,false)
  auditDF
}

//to find and take the Orphan record
def getOrphanFromTable(target: String, targetKey: String) = {
   val tgtDF = DeltaTable.forName(spark, target).toDF
   val targetKeyCol = targetKey.split(",").toList
  
   val activeDF = tgtDF.filter(tgtDF("etl_curr_row_fl") === 'Y').select(targetKeyCol.map(c => col(c)): _*)
   val uniqueDF = tgtDF.select(targetKeyCol.map(c => col(c)): _*).distinct
   val tgtOrphanDF = uniqueDF.join(activeDF, targetKey.split(",").toSeq, "leftanti").withColumn("ETL_CURR_ROW_FL", lit("Y") ) 
     
  tgtOrphanDF.show(3,false)
  tgtOrphanDF
}

//Removing the entire Orphan rows before merging with Target

def removeFullOrphanKey(auditDf: DataFrame, orphanDf: DataFrame, targetKey: String) = {
  val nonOrphanDF = auditDf.join(orphanDf, targetKey.split(",").toSeq, "leftanti")
  nonOrphanDF.show(3,false)
  nonOrphanDF
}

//Removing only the Orphan rows updated as 'Y' before merging with Target

def removeOrphanKey(auditDf: DataFrame, orphanDf: DataFrame, targetKey: String) = { 
  var targetKeyWithFL = targetKey + ",ETL_CURR_ROW_FL"
  val nonOrphanDF = auditDf.join(orphanDf, targetKeyWithFL.split(",").toSeq , "leftanti")
  nonOrphanDF.show(3,false)
  nonOrphanDF
}


// COMMAND ----------

//CHeck and remove the functions if its duplicated

def addHashColumn_clt_old(viewname: String) = {
  var allCols = spark.sql(s"select * from global_temp.${viewname}").schema.fieldNames.toList
  println("allCols: "+ allCols)
  val hash_exclude_cols = List("_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey") ++ List("ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS")
  println("hash_exclude_cols: "+ hash_exclude_cols)
  val hash_cols = allCols.map(_.toLowerCase) diff hash_exclude_cols.map(_.toLowerCase)
  println("hash_cols: "+ hash_cols)  
  val cols=hash_cols.mkString(",")
  val qry=s""" select *,hash(${cols}) as row_hashed from global_temp.${viewname} """  
  spark.sql(qry)  
}

def removeDuplicates_clt_old(df: DataFrame, target: String, targetKey: String) = {
    print("in removeduplicates function2 \n")
 
    val w = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
    val firsRowDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")   
    print(firsRowDF.schema.fieldNames.toList) 
   
    val latestInTargetDF = firsRowDF.join(DeltaTable.forName(spark, target).toDF.as("targetDF"), targetKey.split(",").toSeq, "right").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select($"targetDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*)  
    print("\n latestInTargetDF cols")
    print(latestInTargetDF.schema.fieldNames.toList)  
 
    //add target latest rows to microbatch
    val df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
    df2.show()
    // remove consecutive duplicates, choose first 
    val w3 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col("ETL_ROW_EFF_DTS").asc,col("isTarget").desc,col("row_hashed").asc)
    val df3 = df2.withColumn("dupe",  $"row_hashed" === lag($"row_hashed", 1).over(w3))
            .where($"dupe" === false || $"dupe".isNull ).drop("dupe") 
  
    // If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
    val w2 =  Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*)
    val df4 = df3.withColumn("count",  count($"*").over(w2)).where($"count" =!= 1 || ($"isTarget" =!= 1  && $"count" === 1)).drop("count").drop("isTarget")
  
    df4.show()
    df4    
}

// COMMAND ----------

// Type-1 

//default Default Merge Function 

def type1_defaultMerge (df: DataFrame, target: String, merge_key: String) = {
    val match_condition = merge_key.split(",").map(x => {s"events.${x.trim()}=updates.${x.trim()}"}).mkString(" AND ")
    DeltaTable.forName(spark, target)
    .as("events")
    .merge(
      df.as("updates"),
      s"${match_condition}")
     .whenMatched
     .updateAll()
    .whenNotMatched
    .insertAll()
    .execute()  
}

//Add surrogate key
def addSurrogateKey_clt_type1(df:DataFrame, target:String, orderby:String) = {   
      val maxSK = spark.table(s"${target}").count 
    val w  = Window.orderBy(s"${orderby}")
    df.withColumn("surrogatekey", row_number.over(w) + maxSK)  
  
}

// COMMAND ----------

//pre-harminization/exclusion function

def pre_harm_exclusion(microBatchDF: DataFrame, pre_harm_logic_query:String, rawDB:String, environment: String) : DataFrame = {
      
  if(environment.toUpperCase() == "PROD")
  {
    println("Executing exclusion logic")
    microBatchDF.createOrReplaceGlobalTempView("Harmz_Query")
    var FinalDF = spark.sql(pre_harm_logic_query)
    return FinalDF
  }
   else
  {
    return microBatchDF
  }
}
