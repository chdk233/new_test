# Databricks notebook source
print("calling the python child notebook 2")

# COMMAND ----------

dbutils.widgets.removeAll() 

# COMMAND ----------


dbutils.widgets.text( "microBatchViewName", "microBatchView", "Microbatch_Global_TempView_Name")
dbutils.widgets.text( "harmonizedDB", "", "Harmonized DB")
dbutils.widgets.text( "merge_keys", "", "Merge_Keys")
dbutils.widgets.text( "batchId", "0", "Batch ID")
dbutils.widgets.text( "curatedDB", "", "Curation DB")
dbutils.widgets.text( "target", "", "Target table name") 
#dbutils.widgets.text( "sourcetable", "", "Source table name")



# COMMAND ----------

microBatchViewName = dbutils.widgets.get("microBatchViewName")
harmonizedDB = dbutils.widgets.get("harmonizedDB")
batchId = dbutils.widgets.get("batchId")
merge_keys = dbutils.widgets.get("merge_keys")
curatedDB = dbutils.widgets.get("curatedDB")
target = dbutils.widgets.get("target")
#sourcetable = dbutils.widgets.get("sourcetable")

print("Micro Batch View Name --", microBatchViewName)
print("Harmonised DB ---",  harmonizedDB)
print("batch ID ---", batchId)
print("Merge Keys ---", merge_keys)
print("Curated DB ---", curatedDB)
print("Target ---", target)
#print("sourcetable ---", sourcetable)

# COMMAND ----------

"""
try:
  display(spark.sql(f"select * from global_temp.{microBatchViewName}"))
  df = spark.sql(f"select * from global_temp.{microBatchViewName}")
  df.write.mode("append").format("delta").saveAsTable(f"{target}")
except Exception as e:
  print("Python childbook failed")
  raise e
"""

# COMMAND ----------

  display(spark.sql(f"select * from global_temp.{microBatchViewName}"))
  df = spark.sql(f"select * from global_temp.{microBatchViewName}")
  df.write.mode("append").format("delta").saveAsTable(f"{target}")

# COMMAND ----------

dbutils.notebook.exit("sucess")
