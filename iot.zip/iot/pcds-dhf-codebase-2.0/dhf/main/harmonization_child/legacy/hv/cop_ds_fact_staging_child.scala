// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_fact_staging(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select 
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(BOPCOV.nstanum IS NULL, '999', BOPCOV.nstanum)||'-'||IF(BOPCOV.nlocnum is null, '999', BOPCOV.nlocnum)||'-'||IF(BOPCOV.nBLDnum is null, '999', BOPCOV.nBLDnum)||'-'||IF(BLDEXT3.Element is null, '999', BLDEXT3.Element)||'-'||IF(BLDEXT4.Element is null, '999', BLDEXT4.Element)||'-'||BOPCOV.nCOVnum||'-'||BOPCOV.nSEQnum||'-'||BOPCOV.noccnum||'-'||IF(BOPCOV.LCOVCDE is null, 'NULL', BOPCOV.LCOVCDE)||'-9999-COV' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-COP' AS PARTITION_VAL,
'COP' as  LOB_CD,
'COPBUILDING' as CVRBL_TYPE_CD,
ifnull(rtrim(BOPCOV.LCOVCDE), ' ')  as COVG_CD,
ifnull(rtrim(BOPCOV.LCOVDES), 'Not Defined') as COVG_TEXT,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
cast(BOPCOV.NPRM as double) as PREM_AMT,
cast(BOPCOV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'NOKEY' as manuscript,
0 as NO_LOC,
0 as NO_BLD,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(BOPBLD.nstanum IS NULL, '999', BOPBLD.nstanum)||'-'||IF(POLLOC.nlocnum is null, '999', IF(cast(POLLOC.nlocnum as double) > 0, POLLOC.nlocnum,IF(BOPBLD.NLOCNUM is NULL, '999', BOPBLD.NLOCNUM)))||'-'||IF(BOPBLD.nBLDnum is null, '999', BOPBLD.nBLDnum)||'-'||IF(BLDEXT3.Element is null, '999', BLDEXT3.Element)||'-'||IF(BLDEXT4.Element is null, '999', BLDEXT4.Element)||'-'||BOPCOV.nCOVnum||'-'||BOPCOV.nSEQnum||'-'||IF(BOPCOV.LCOVCDE is null, 'NULL', BOPCOV.LCOVCDE)||'-9999-COV', 'NOKEY') AS TEMP_KEY
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'COP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT1
on ppol.PolicyID = POLEXT1.PolicyID 
and ppol.nexpnum = POLEXT1.nexpnum 
and POLEXT1.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVMFL.*
   from
   {rawDB}.BOPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVMFL.PolicyID
                   and 	mb.NEXPNUM=BOPCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) BOPCOV
on ppol.PolicyID = BOPCOV.PolicyID 
and ppol.nexpnum  = BOPCOV.nexpnum
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLLOC  
on ppol.PolicyID = POLLOC.PolicyID 
and ppol.nexpnum  = POLLOC.nexpnum 
and case when POLLOC.nlocnum >0 then  POLLOC.nlocnum else BOPCOV.nlocnum end = BOPCOV.nlocnum
and case when POLLOC.nbldnum >0 then  POLLOC.nbldnum else BOPCOV.nbldnum end = BOPCOV.nbldnum
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NSTANUM,NPOLPED,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID 
              ) ) WHERE rn = 1  )  BOPBLD
on ppol.PolicyID = BOPBLD.PolicyID 
and ppol.nexpnum  = BOPBLD.nexpnum 
and BOPCOV.nstanum = BOPBLD.nstanum
and BOPCOV.nlocnum = BOPBLD.nlocnum
and BOPCOV.NBLDNUM = BOPBLD.NBLDNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) BLDEXT3
on BLDEXT3.PolicyID = ppol.PolicyID
and BLDEXT3.nexpnum = ppol.nexpnum
and BLDEXT3.NSTANUM = BOPBLD.NSTANUM
and BLDEXT3.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT3.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT3.StringValue <> '0' and trim(BLDEXT3.StringValue) <> ''
and BLDEXT3.Name like 'OccCde%'
and BLDEXT3.Element = 0
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) BLDEXT4
on BLDEXT4.PolicyID = ppol.PolicyID
and BLDEXT4.nexpnum = ppol.nexpnum
and BLDEXT4.NSTANUM = BOPBLD.NSTANUM
and BLDEXT4.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT4.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT4.StringValue <> '0' and trim(BLDEXT4.StringValue) <> ''
and BLDEXT4.Name like 'PctOcc%'
and BLDEXT4.Element= 0
where BOPCOV.ncovnum is not null

UNION ALL

Select 
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-9999-9999-9999-9999-9999-'||IF(BOPRCV.nCOVnum is null, '9999', BOPRCV.nCOVnum)||'-9999-9999-'||IF(BOPRCV.LCOVCDE is null, 'NULL', BOPRCV.LCOVCDE)||'-9999-RCV' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-COP' AS PARTITION_VAL,
'COP' as  LOB_CD,
'COPLINE' as CVRBL_TYPE_CD,
ifnull(rtrim(BOPRCV.LCOVCDE), ' ')  as COVG_CD,
ifnull(rtrim(BOPRCV.LCOVDES), 'Not Defined') as COVG_TEXT,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
cast(BOPRCV.NPRM as double) as PREM_AMT,
cast(BOPRCV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'NOKEY' as manuscript,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' as TEMP_KEY
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'COP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT1
on ppol.PolicyID = POLEXT1.PolicyID 
and ppol.nexpnum = POLEXT1.nexpnum 
and POLEXT1.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NCOVNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPRCVMFL.*
   from
   {rawDB}.BOPRCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCVMFL.PolicyID
                   and 	mb.NEXPNUM=BOPRCVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) BOPRCV
on ppol.PolicyID = BOPRCV.PolicyID 
and ppol.nexpnum  = BOPRCV.nexpnum  
and BOPRCV.nstanum = 0

UNION ALL

Select 
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(SPCCOV.nstanum IS NULL, '999', SPCCOV.nstanum)||'-'||IF(SPCCOV.nlocnum is null, '999', SPCCOV.nlocnum)||'-'||IF(SPCCOV.nBLDnum is null, '999', SPCCOV.nBLDnum)||'-'||IF(BLDEXT3.Element is null, '999', BLDEXT3.Element)||'-'||IF(BLDEXT4.Element is null, '999', BLDEXT4.Element)||'-9999-'||SPCCOV.nSEQnum||'-9999-'||SPCCOV.LCOVTYPCDE||'-'||SPCCOV.LSUBCOVCDE||'-SPC' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-COP' AS PARTITION_VAL,
'COP' as  LOB_CD,
'COPBUILDING' as CVRBL_TYPE_CD,
ifnull(rtrim(SPCCOV.LCOVTYPCDE), ' ')  as COVG_CD,
ifnull(rtrim(SPCCOV.LCOVTYPDES), 'Not Defined') as COVG_TEXT,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
cast(SPCCOV.NPRM as double) as PREM_AMT,
cast(SPCCOV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(SPCCOV.nstanum IS NULL, '999', SPCCOV.nstanum)||'-'||IF(SPCCOV.nlocnum is null, '999', SPCCOV.nlocnum)||'-'||IF(SPCCOV.nBLDnum is null, '999', SPCCOV.nBLDnum)||'-'||IF(SPCCOV.nSEQnum is null, '999', SPCCOV.nSEQnum)||'-'||IF(SPCCOV.LSUBCOVCDE is null, 'NULL', SPCCOV.LSUBCOVCDE), 'NOKEY') AS manuscript,
ifnull(cast(rtrim(SPCCOV.NLOCNUM) as double), 0) as NO_LOC,
ifnull(cast(rtrim(SPCCOV.NBLDNUM) as double), 0) as NO_BLD,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(BOPBLD.nstanum IS NULL, '999', BOPBLD.nstanum)||'-'||IF(BOPBLD.nlocnum is null, '999', BOPBLD.nlocnum)||'-'||IF(BOPBLD.nBLDnum is null, '999', BOPBLD.nBLDnum)||'-'||IF(BLDEXT3.Element is null, '999', BLDEXT3.Element)||'-'||IF(BLDEXT4.Element is null, '999', BLDEXT4.Element)||'-9999-'||SPCCOV.nSEQnum||'-9999-'||SPCCOV.LCOVTYPCDE||'-'||SPCCOV.LSUBCOVCDE||'-SPC', 'NOKEY') AS TEMP_KEY
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'COP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT1
on ppol.PolicyID = POLEXT1.PolicyID 
and ppol.nexpnum = POLEXT1.nexpnum 
and POLEXT1.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOV
on ppol.policyid = SPCCOV.policyid
and ppol.nexpnum = SPCCOV.nexpnum
and SPCCOV.llob = 'COP'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NSTANUM,NPOLPED,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID 
              ) ) WHERE rn = 1  )  BOPBLD
on ppol.PolicyID = BOPBLD.PolicyID 
and ppol.nexpnum  = BOPBLD.nexpnum 
and SPCCOV.nstanum = BOPBLD.nstanum
and SPCCOV.nlocnum = BOPBLD.nlocnum
and SPCCOV.NBLDNUM = BOPBLD.NBLDNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) BLDEXT3
on BLDEXT3.PolicyID = ppol.PolicyID
and BLDEXT3.nexpnum = ppol.nexpnum
and BLDEXT3.NSTANUM = BOPBLD.NSTANUM
and BLDEXT3.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT3.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT3.StringValue <> '0' and trim(BLDEXT3.StringValue) <> ''
and BLDEXT3.Name like 'OccCde%'
and BLDEXT3.Element = 0
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) BLDEXT4
on BLDEXT4.PolicyID = ppol.PolicyID
and BLDEXT4.nexpnum = ppol.nexpnum
and BLDEXT4.NSTANUM = BOPBLD.NSTANUM
and BLDEXT4.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT4.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT4.StringValue <> '0' and trim(BLDEXT4.StringValue) <> ''
and BLDEXT4.Name like 'PctOcc%'
and BLDEXT4.Element = 0
where SPCCOV.LCOVTYPCDE IS NOT NULL

UNION ALL

Select 
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(tax.nstanum IS NULL, '999', tax.nstanum)||'-9999-9999-9999-9999-9999-9999-'||IF(tax.LKEY1 IS NOT NULL and trim(tax.LKEY1) <> '', tax.LKEY1, '999')||'-'||IF(tax.LKEY2 IS NOT NULL and trim(tax.LKEY2) <> '', tax.LKEY2, '999')||'-'||IF(tax.LKEY3 IS NOT NULL and trim(tax.LKEY3) <> '', tax.LKEY3, '999')||'-SURCHARGE' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-COP' AS PARTITION_VAL,
'COP' as  LOB_CD,
' ' as CVRBL_TYPE_CD,
' ' as COVG_CD,
'Not Defined' as COVG_TEXT,
ifnull(rtrim(tax.LDES), ' ') as COVG_TERM_CD,
ifnull(rtrim(tax.ldes), 'Not Defined') as COVG_TERM_TEXT,
cast(tax.NPRM as double) as PREM_AMT,
cast(tax.Nprmann as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'NOKEY' AS manuscript,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' AS TEMP_KEY
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'COP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT1
on ppol.PolicyID = POLEXT1.PolicyID 
and ppol.nexpnum = POLEXT1.nexpnum 
and POLEXT1.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,LKEY1,LKEY2,LKEY3 ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  poltx2mfl.*
   from
   {rawDB}.poltx2mfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = poltx2mfl.PolicyID
                   and 	mb.NEXPNUM=poltx2mfl.NEXPNUM 
              ) ) WHERE rn = 1  ) tax
on ppol.policyid = tax.policyid
and ppol.nexpnum = tax.nexpnum
"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_fact_staging")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","FACT_STAGE_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("FACT_STAGE_KEY","END_EFF_DT"),harmonized_table,"FACT_STAGE_ID","HV-COP") 
}