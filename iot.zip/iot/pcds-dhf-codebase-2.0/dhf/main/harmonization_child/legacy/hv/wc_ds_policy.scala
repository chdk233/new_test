// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_wc_ds_policy(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

Select  
 concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,concat('DPIM-',case when POLAGT.LAGTNUM is NULL then ('NULL') else POLAGT.LAGTNUM end) AS AGCY_KEY
,'WC' as PROD_CD
,ppol.LCMP as POL_CO_TEXT
,concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM), '-PNI') as PRIM_NAMED_INSURED_KEY
,POLEXT2.StringValue as SIC_CD
,POLEXT9.StringValue as AUDIT_PLAN_CD 
,POLEXT4.StringValue as CMML_MKT_SGMNT_CD 
,POLEXT10.StringValue as INDUSTRY_CD
,Substring(POLEXT10.StringValue,1,2) as INDUSTRY_GRP_CD   
,POLEXT11.StringValue as COMM_CONTRIBUTION_FCTR 
,POLEXT8.StringValue as POL_PRINT_METHOD
,POLEXT5.StringValue as GL_CLASS_CD 
,v3x.LBUSDES as BUS_CL_DESC
,ppol.NTOTPRMANN as TOTAL_PREM_RPT_AMT
, case when rtrim(v3x.LPOLSTS) = 'Cancel' then v3x.LSECTCTTYP end as RFND_CALC_METHD_CD
, case when rtrim(v3x.LPOLSTS) = 'Cancel' then v3x.LTCTDES end as RFND_CALC_METHD_TEXT
,'AQS' as POL_ORIGIN_CD
,POLEXT13.DoubleValue as EXP_PASS_PREM_AMT 
,concat(concat('HV-PAK','-'),namex.Stringvalue) as ACCT_KEY 
,ppol.LPOLNUM as POL_NO
,ppol.NEFFDAT as POL_EFF_DT
,ppol.NEXPDAT as POL_EXP_DT
,POLEXT1.StringValue as ORIG_EFF_DT 
,case when rtrim(v3x.LPOLSTS) in ( 'New Business') then 'Y' else 'N' end as NEW_BUS_FL
,ppol.LBUSTYP as ENTITY_TYPE_CD
,ppol.LPRISTACDE as PRIM_STATE_CD
,ppol.LPRISTANAM as PRIM_STATE_TEXT 
,v3x.LPOLSTS as POL_PERIOD_STATUS_TEXT
,case when rtrim(v3x.LPOLSTS) in ('Renewal', 'Quote', 'New Business') then 'Active' else 'Cancel' end as LAST_STATUS_CD
,'ETL_LAST_UPDATE_DTS' as LAST_STATUS_PROC_DTS
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end as LAST_STATUS_EFF_DT
,'Y' as BOUND_FL
,concat(rtrim(v3x.LPOLSTS) ,case when rtrim(v3x.LPOLSTS) = 'Cancel' and length(POLEXT3.StringValue)>1 then 
concat(' - ', POLEXT3.StringValue) end) as LAST_STATUS_REASON_CD
,case when rtrim(v3x.LPOLSTS) = 'Cancel' then v3x.LTCTDES end as CANCEL_SRCE_CD 
,POLEXT12.StringValue as ASE_ZONE
,'Y' as MONOLINE_FL,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV-WC' AS PARTITION_VAL,
'WC' AS LOB_CD

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'WC%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'WC%' 
and ppol.neffyrs > 2017
and w.act_wstid = 11 
and w.actstored <> 2
 
 and w.actLastActivity > '2017-12-31 23:59:59.999'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
 
 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT1 --with (nolock) 
on ppol.PolicyID = POLEXT1.PolicyID 
and  POLEXT1.Name like 'EffDat%' 


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT2 --with (nolock) 
on ppol.PolicyID = POLEXT2.PolicyID 
and  ppol.nexpnum = POLEXT2.nexpnum 
and  POLEXT2.Name like 'SICCde%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch   mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT3 --with (nolock) 
on ppol.PolicyID = POLEXT3.PolicyID 
and ppol.nexpnum = POLEXT3.nexpnum 
and  POLEXT3.Name like 'CanRsn%'
                   

left outer Join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT4 --with (nolock) 
on ppol.PolicyID = POLEXT4.PolicyID 
and  ppol.nexpnum = POLEXT4.nexpnum 
and  POLEXT4.Name like 'LobMktSeg%' 


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT5 --with (nolock) 
on ppol.PolicyID = POLEXT5.PolicyID
and ppol.nexpnum = POLEXT5.nexpnum 
and  POLEXT5.Name like 'GLCCde%' 
    

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT7 --with (nolock) 
on ppol.PolicyID = POLEXT7.PolicyID
and ppol.nexpnum = POLEXT7.nexpnum 
and  POLEXT7.Name like 'PolicyNumber%'  


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT8 --with (nolock) 
on ppol.PolicyID = POLEXT8.PolicyID 
and  ppol.nexpnum = POLEXT8.nexpnum 
and  POLEXT8.Name like 'AdditionalPrintOption%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT9

on ppol.PolicyID = POLEXT9.PolicyID
and ppol.nexpnum = POLEXT9.nexpnum 
and  POLEXT9.Name like 'AudTyp%' 


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch   mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT10 --with (nolock) 
on ppol.PolicyID = POLEXT10.PolicyID
and ppol.nexpnum = POLEXT10.nexpnum
and  POLEXT10.Name like 'NaiCde%'  
     

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch   mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT11 --with (nolock) 
on ppol.PolicyID = POLEXT11.PolicyID
and ppol.nexpnum = POLEXT11.nexpnum 
and  POLEXT11.Name like 'NegComExp%'  


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT12 --with (nolock) 
on ppol.PolicyID = POLEXT12.PolicyID
and  ppol.nexpnum = POLEXT12.nexpnum 
and  POLEXT12.Name like 'AcctZone%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT13 --with (nolock) 
on ppol.PolicyID = POLEXT13.PolicyID
and  ppol.nexpnum = POLEXT13.nexpnum 
and  POLEXT13.Name like 'PolPrm%' 

left outer join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLNAMEXTMFL.*
   from
   {rawDB}.POLNAMEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLNAMEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) namex 
on ppol.policyid = namex.policyid 
and namex.NEXPNUM = 0
and namex.Name = 'InsAct' 

left outer Join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  v3x --with (nolock)
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM 

 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
  {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch   mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
                   and 	mb.NEXPNUM=POLAGTMFL. NEXPNUM 
           
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  POLAGT --with (nolock)
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM 



"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_policy")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","POL_ID")
    mergeAndWrite(hashDF,List("POL_KEY","END_EFF_DT"), harmonized_table, "POL_ID","HV-WC")
}