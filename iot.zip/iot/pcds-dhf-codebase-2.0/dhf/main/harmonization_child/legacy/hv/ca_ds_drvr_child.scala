// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_drvr(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
select 
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(POLDVR.SequenceNumber is NULL, '999', POLDVR.SequenceNumber)||'-'||if(CAUSTA.NSTANUM is NULL, '999', CAUSTA.NSTANUM)||'-'||if(CAUCCVPRI.NSEQNUM is NULL, '999', CAUCCVPRI.NSEQNUM)||'-'||if(CAUCCVPRI.NTYPNUM is NULL, '999', CAUCCVPRI.NTYPNUM)||'-'||if(CAUCCVPRIEXT1.Element is NULL, '999', CAUCCVPRIEXT1.Element) AS DRVR_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT, 
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as LOB_CD,
cast(POLDVR.NDVRNUM as double) AS DRVR_NO,
ifnull(rtrim(POLDVR.LNAMFST), ' ') AS FIRST_NAME,
ifnull(rtrim(POLDVR.LNAMLST), ' ') AS LAST_NAME,
to_date(POLDVR.NBTHDAT, 'MM/dd/yyyy') AS BIRTH_DT,
ifnull(rtrim(POLDVR.LGDR), 'Not Defined') AS GENDER_TEXT,
ifnull(rtrim(POLDVR.LMTLSTS), ' ') AS MARITAL_STATUS_CD,
to_date(POLDVR.NHIRDAT, 'MM/dd/yyyy') AS HIRE_DT,
ifnull(rtrim(POLDVR.LDVRLICNUM), ' ') AS LIC_NO,
ifnull(rtrim(POLDVR.LSTALIC), ' ') AS LIC_JURS_CD,
cast(POLDVR.NYRSLIC as double) AS LIC_YR_NO,
ifnull(rtrim(POLDVR.NYRSXPR), ' ') AS DRVR_EXPER_CD,
ifnull(rtrim(POLDVR.LEXCDVR), 'U') AS EXCL_DRVR_FL,
if((CAUCCVPRIEXT1.StringValue is NULL or trim(CAUCCVPRIEXT1.StringValue) = ''), 'N', 'Y') AS DRIVE_OTHER_CAR_FL, 
ifnull(rtrim(POLDVR.XNAMSFX), ' ') AS DRVR_SUFFIX_CD,
ifnull(if(trim(CAUCCV.LDES) = 'BROADENED PIP', 'Y', 'N'), 'U') AS BROAD_PIP_FL, 
IF(trim(POLDVREXT1.StringValue) = 'Yes', 'Y', IF(trim(POLDVREXT1.StringValue) = 'No', 'N', trim(POLDVREXT1.StringValue))) AS MVR_DRIVR_CLEAR_IN
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,SequenceNumber ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLDVRMFL.*
   from
   {rawDB}.POLDVRMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLDVRMFL.PolicyID 
            
--               where POLDVRMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLDVR  
on ppol.policyid = POLDVR.policyid 
and ppol.NEXPNUM = POLDVR.NEXPNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,SequenceNumber,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLDVREXTMFL.*
   from
   {rawDB}.POLDVREXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLDVREXTMFL.PolicyID 
            
--               where POLDVREXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLDVREXT1  
on ppol.policyid = POLDVREXT1.policyid 
and ppol.NEXPNUM = POLDVREXT1.NEXPNUM  
and POLDVR.SequenceNumber= POLDVREXT1.SequenceNumber
and trim(POLDVREXT1.NAME) = 'MvrDvrClearInd'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.policyid = CAUPOL.policyid 
and ppol.NEXPNUM = CAUPOL.NEXPNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA  
on ppol.policyid = CAUSTA.policyid 
and ppol.NEXPNUM = CAUSTA.NEXPNUM
and CAUSTA.NPOLPED=CAUPOL.NPOLPED
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVPRIMFL.*
   from
   {rawDB}.CAUCCVPRIMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVPRIMFL.PolicyID 
            
--               where CAUCCVPRIMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUCCVPRI  
on ppol.policyid = CAUCCVPRI.policyid 
and ppol.NEXPNUM = CAUCCVPRI.NEXPNUM  
and CAUSTA.NSTANUM= CAUCCVPRI.NSTANUM
and CAUSTA.NPOLPED= CAUCCVPRI.NPOLPED
and trim(CAUCCVPRI.LDES) IN ('DRIVE OTHER CAR','BROADENED PIP') 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVMFL.*
   from
   {rawDB}.CAUCCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVMFL.PolicyID 
            
--               where CAUCCVMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUCCV  
on ppol.policyid = CAUCCV.policyid 
and ppol.NEXPNUM = CAUCCV.NEXPNUM  
and CAUCCVPRI.NSTANUM= CAUCCV.NSTANUM
and CAUCCVPRI.NTYPNUM= CAUCCV.NTYPNUM
and CAUCCVPRI.NPOLPED= CAUCCV.NPOLPED
and CAUCCVPRI.NSEQNUM= CAUCCV.NSEQNUM
and trim(CAUCCV.LDES) = 'BROADENED PIP'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVPRIEXTMFL.*
   from
   {rawDB}.CAUCCVPRIEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVPRIEXTMFL.PolicyID 
            
--               where CAUCCVPRIEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUCCVPRIEXT1  
on ppol.policyid = CAUCCVPRIEXT1.policyid 
and ppol.NEXPNUM = CAUCCVPRIEXT1.NEXPNUM  
and CAUCCVPRI.NSTANUM= CAUCCVPRIEXT1.NSTANUM
and CAUCCVPRI.NTYPNUM= CAUCCVPRIEXT1.NTYPNUM
and CAUCCVPRI.NPOLPED= CAUCCVPRIEXT1.NPOLPED
and CAUCCVPRI.NSEQNUM= CAUCCVPRIEXT1.NSEQNUM
and trim(CAUCCVPRIEXT1.Name) = 'DVRLink'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_drvr")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","DRVR_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("DRVR_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"DRVR_ID","HV-CA") 
    //     queryDF.show(3,false)
}