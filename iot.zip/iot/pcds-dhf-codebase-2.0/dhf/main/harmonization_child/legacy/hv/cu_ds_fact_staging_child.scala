// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cu_ds_fact_staging(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(BOPSTA.nstanum is null, '999', BOPSTA.nstanum)||'-'||IF(BOPCOV.nCOVnum is null, '999', BOPCOV.nCOVnum)||'-'||IF(BOPCOV.nSEQnum is null, '999', BOPCOV.nSEQnum)||'-'||IF(BOPCOV.LCOVCDE is null, 'NULL', BOPCOV.LCOVCDE)||'-'||if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC))||'-'||if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC))||'-COV' AS FACT_STAGE_KEY,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(bopcov.NSTANUM is null, '999', bopcov.NSTANUM)||'-'||IF(bopcov.NCOVNUM is null, '999', bopcov.NCOVNUM)||'-'||IF(BOPCOV.nSEQnum is null, '999', BOPCOV.nSEQnum), 'NOKEY') AS UL_POL_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CU' AS PARTITION_VAL,
'CU' as  LOB_CD,
'CULINE' as CVRBL_TYPE_CD,
ifnull(rtrim(BOPCOV.LCOVCDE), ' ') as COVG_CD,
ifnull(rtrim(BOPCOV.LCOVDES), 'Not Defined') as COVG_TEXT,
cast(BOPCOV.NPRM as double) as PREM_AMT,
cast(BOPCOV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT7.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'COV' AS TEMP_KEY,
'NOKEY' AS LINE_MANUSCRIPT_KEY,
ifnull(rtrim(BOPCOV.NSTANUM), ' ') as JURS_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'CMB%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CMB%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT7
on ppol.PolicyID = POLEXT7.PolicyID 
and ppol.nexpnum = POLEXT7.nexpnum 
and POLEXT7.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAMFL.NEXPNUM
--               where BOPSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTA 
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum  = BOPSTA.nexpnum 
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVMFL.*
   from
   {rawDB}.BOPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPCOV
on ppol.PolicyID = BOPCOV.PolicyID 
and ppol.nexpnum  = BOPCOV.nexpnum  
and BOPSTA.nstanum = BOPCOV.nstanum

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(SPCCOV.nstanum is null, '999', SPCCOV.nstanum)||'-'||IF(SPCCOV.nSEQnum is null, '999', SPCCOV.nSEQnum)||'-'||IF(SPCCOV.LCOVTYPCDE is null, 'NULL', SPCCOV.LCOVTYPCDE)||'-'||IF(SPCCOV.LSUBCOVCDE is null, 'NULL', SPCCOV.LSUBCOVCDE)||'-'||if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC))||'-'||if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC))||'-SPC' AS FACT_STAGE_KEY,
'NOKEY' AS UL_POL_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CU' AS PARTITION_VAL,
'CU' as  LOB_CD,
'CULINE' as CVRBL_TYPE_CD,
ifnull(rtrim(SPCCOV.LCOVTYPCDE), ' ') as COVG_CD,
ifnull(rtrim(SPCCOV.LCOVTYPDES), 'Not Defined') as COVG_TEXT,
cast(SPCCOV.NPRM as double) as PREM_AMT,
cast(SPCCOV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT7.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'Manuscript' AS TEMP_KEY,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(SPCCOV.nstanum is null, '999', SPCCOV.nstanum)||'-'||IF(SPCCOV.NLOCNUM is null, '999', SPCCOV.NLOCNUM)||'-'||IF(SPCCOV.NBLDNUM is null, '999', SPCCOV.NBLDNUM)||'-'||IF(SPCCOV.NSEQNUM is null, '999', SPCCOV.NSEQNUM)||'-'||IF(SPCCOV.LSUBCOVCDE is null, 'NULL', SPCCOV.LSUBCOVCDE), 'NOKEY') AS LINE_MANUSCRIPT_KEY,
ifnull(rtrim(SPCCOV.nstanum), ' ') as JURS_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'CMB%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CMB%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT7
on ppol.PolicyID = POLEXT7.PolicyID 
and ppol.nexpnum = POLEXT7.nexpnum 
and POLEXT7.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOV
on ppol.policyid = SPCCOV.policyid
and ppol.nexpnum = SPCCOV.nexpnum
 and  trim(llob) in  ('UMB','RRT') 
and SPCCOV.LCOVTYPCDE IS NOT NULL

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(tax.nstanum is null, '999', tax.nstanum)||'-'||if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC))||'-'||if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC))||'-SURCHARGE' AS FACT_STAGE_KEY,
'NOKEY' AS UL_POL_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CU' AS PARTITION_VAL,
'CU' as  LOB_CD,
' ' as CVRBL_TYPE_CD,
ifnull(rtrim(tax.LDES), ' ') as COVG_CD,
ifnull(rtrim(tax.ldes), 'Not Defined') as COVG_TEXT,
cast(tax.NPRM as double) as PREM_AMT,
cast(tax.Nprmann as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT7.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'Surcharge' AS TEMP_KEY,
'NOKEY' AS LINE_MANUSCRIPT_KEY,
ifnull(rtrim(tax.nstanum), ' ') as JURS_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'CMB%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CMB%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT7
on ppol.PolicyID = POLEXT7.PolicyID 
and ppol.nexpnum = POLEXT7.nexpnum 
and POLEXT7.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,LKEY1,LKEY2,LKEY3 ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  poltx2mfl.*
   from
   {rawDB}.poltx2mfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = poltx2mfl.PolicyID
                   and 	mb.NEXPNUM=poltx2mfl.NEXPNUM 
              ) ) WHERE rn = 1  ) tax
on ppol.policyid = tax.policyid
and ppol.nexpnum = tax.nexpnum
"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cu_ds_fact_staging")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","FACT_STAGE_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("FACT_STAGE_KEY","END_EFF_DT"),harmonized_table,"FACT_STAGE_ID","HV-CU") 
}