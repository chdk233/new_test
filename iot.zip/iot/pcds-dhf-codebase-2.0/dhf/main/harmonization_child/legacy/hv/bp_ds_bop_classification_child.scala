// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_bp_ds_bop_classification(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
 SELECT
'HV-'||POLEXT1.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT1.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPLOC.NLOCNUM is NULL, '999', LPAD(CAST(BOPLOC.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0'))||'-'||if(BLDEXT2.ELEMENT is NULL, '999', LPAD(CAST(BLDEXT2.ELEMENT AS STRING), 3, '0'))||'-'||if(bopcls.NOCCNUM is NULL, '999', LPAD(CAST(bopcls.NOCCNUM AS STRING), 3, '0')) AS BOP_CLASS_KEY,
'HV-'||POLEXT1.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPLOC.NLOCNUM is NULL, '999', LPAD(CAST(BOPLOC.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0')) AS CVRBL_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
ifnull(rtrim(BOPCLS.LCLSCDE), ' ') AS CLASS_CD,
ifnull(rtrim(BOPCLS.LPRIDES)||rtrim(BOPCLS.LSECDES), ' ') AS BP_CLASS_TYPE_DESC,
ifnull(rtrim(BOPCLS.LLIACLSGRP), ' ') AS CL_GROUP,
if(rtrim(BLDEXT1.StringValue)='' or BLDEXT1.StringValue is null, 'U', rtrim(BLDEXT1.StringValue)) AS FRANCHISED_FL,
ifnull(rtrim(BLDEXT2.StringValue), ' ') AS MSB_ESTMT_BNDL_CD,
if(rtrim(BOPBLD.LOCCTYP)='' or BOPBLD.LOCCTYP is null, 'Not Defined', rtrim(BOPBLD.LOCCTYP)) AS OCCPNCY_TYPE_TEXT,
if(rtrim(BOPPOL1.StringValue)='' or BOPPOL1.StringValue is null, 'U', rtrim(BOPPOL1.StringValue)) AS OWNED_CONDO_UNIT_FL,
ifnull(rtrim(ppol.LPMADES), ' ')  AS PROG_TYPE_CD,
'BP' AS LOB_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT1 
on ppol.PolicyID = POLEXT1.PolicyID 
and POLEXT1.nexpnum = 0   
and  POLEXT1.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NPOLPED,LPGMTYP ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID
              and mb.nexpnum = BOPPOLEXTMFL.nexpnum )) WHERE rn = 1  ) BOPPOL1  
on ppol.PolicyID = BOPPOL1.PolicyID 
and ppol.nexpnum = BOPPOL1.nexpnum  
and BOPPOL1.Name like 'CdoOwn%' and trim(BOPPOL1.stringvalue) != ''
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCMFL.*
   from
   {rawDB}.BOPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCMFL.PolicyID
              and mb.nexpnum = BOPLOCMFL.nexpnum )) WHERE rn = 1  ) BOPLOC  
on ppol.PolicyID = BOPLOC.PolicyID 
and ppol.nexpnum = BOPLOC.nexpnum
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID
              and mb.nexpnum = BOPBLDMFL.nexpnum)
  ) WHERE rn = 1  ) BOPBLD  
on  ppol.policyid = BOPBLD.policyid 
and ppol.NEXPNUM = BOPBLD.NEXPNUM 
and BOPLOC.NLOCNUM = BOPBLD.NLOCNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum)
  ) WHERE rn = 1  ) BLDEXT1  
on ppol.PolicyID = BLDEXT1.PolicyID 
and ppol.nexpnum = BLDEXT1.nexpnum 
and BOPBLD.NLOCNUM = BLDEXT1.NLOCNUM
and BOPBLD.NBLDNUM = BLDEXT1.NBLDNUM
and BLDEXT1.Name like 'FrnCrd%' and trim(BLDEXT1.stringvalue) != ''
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum)
  ) WHERE rn = 1  ) BLDEXT2  
on ppol.PolicyID = BLDEXT2.PolicyID 
and ppol.nexpnum = BLDEXT2.nexpnum
and BOPBLD.NLOCNUM = BLDEXT2.NLOCNUM
and BOPBLD.NBLDNUM = BLDEXT2.NBLDNUM
and BLDEXT2.Name like 'OccCde%' and trim(BLDEXT2.stringvalue) != ''
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCLSMFL.*
   from
   {rawDB}.BOPCLSMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCLSMFL.PolicyID
              and mb.nexpnum = BOPCLSMFL.nexpnum)
  ) WHERE rn = 1  ) BOPCLS 
on ppol.policyid = BOPCLS.policyid 
and ppol.NEXPNUM = BOPCLS.NEXPNUM
and BOPBLD.nstanum = BOPCLS.nstanum
and BOPBLD.NLOCNUM = BOPCLS.NLOCNUM
and BOPBLD.nbldnum = BOPCLS.nbldnum
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_bp_ds_bop_classification")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","BOP_CLASS_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("BOP_CLASS_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"BOP_CLASS_ID","HV-BP") 
    //     queryDF.show(3,false)
}