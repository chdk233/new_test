// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_geo_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select 

concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY -- will show duplicates

--BA LOC_KEY
 ,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when CAUSTA.NSTANUM is NULL then ( 999  ) else CAUSTA.NSTANUM  end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)
      WHEN POLLOC.NLOCNUM =0 THEN 
	       CASE WHEN CAUGARLOC.NLOCNUM IS NOT NULL THEN CAUGARLOC.NLOCNUM  else 
		   case when spccov.nlocnum is not null then spccov.nlocnum else  
		   POLLOC.NLOCNUM end end  else   POLLOC.NLOCNUM   end),'-') 
,case when POLLOC.NBLDNUM is NULL  then (999) 
      WHEN POLLOC.NBLDNUM =0 THEN 
	       CASE WHEN SPCCOV.NBLDNUM IS NOT NULL THEN SPCCOV.NBLDNUM else 
		   POLLOC.NBLDNUM END else POLLOC.NBLDNUM end)   as LOC_KEY 


--BA GEO_INFO_KEY
 ,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when CAUSTA.NSTANUM is NULL then ( 999  ) else CAUSTA.NSTANUM  end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)
      WHEN POLLOC.NLOCNUM =0 THEN 
	       CASE WHEN CAUGARLOC.NLOCNUM IS NOT NULL THEN CAUGARLOC.NLOCNUM  else 
		   case when spccov.nlocnum is not null then spccov.nlocnum else  
		   POLLOC.NLOCNUM end end  else   POLLOC.NLOCNUM   end),'-') 
,case when POLLOC.NBLDNUM is NULL  then (999) 
      WHEN POLLOC.NBLDNUM =0 THEN 
	       CASE WHEN SPCCOV.NBLDNUM IS NOT NULL THEN SPCCOV.NBLDNUM else 
		   POLLOC.NBLDNUM END else POLLOC.NBLDNUM end)   as GEO_INFO_KEY

,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM


,POLLOCEXT1.StringValue as COASTAL_IND

,substring(POLLOC.LCNT,0,case when charindex('-',POLLOC.LCNT)=0 then length(POLLOC.LCNT)+1 else charindex('-',POLLOC.LCNT) -1 end)  AS COUNTY_NAME
,substring(POLLOC.LCNT,case when charindex('-',POLLOC.LCNT)=0 then length(POLLOC.LCNT)+1 else charindex('-',POLLOC.LCNT)+1 end ,length(POLLOC.LCNT)+1) as COUNTY_CD

,POLSTA.StringValue as MUNICIPALITY_CD
,'CA' AS LOB_CD
,'HV-CA' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs like '%2020%'
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity like '%2020%' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  )POLEXT6 
on ppol.PolicyID = POLEXT6.PolicyID
and POLEXT6.nexpnum = 0
and POLEXT6.Name like 'PolicyPrefix%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
              and mb.NEXPNUM = CAUPOLMFL.NEXPNUM)) WHERE rn = 1  ) CAUPOL 
on ppol.policyid = CAUPOL.policyid 
and ppol.NEXPNUM = CAUPOL.NEXPNUM  

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
              and mb.NEXPNUM = CAUSTAMFL.NEXPNUM)) WHERE rn = 1  ) CAUSTA 
on ppol.policyid = CAUSTA.policyid 
and ppol.NEXPNUM = CAUSTA.NEXPNUM
and CAUSTA.NPOLPED=CAUPOL.NPOLPED

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              and mb.NEXPNUM = POLLocationMFL.NEXPNUM)) WHERE rn = 1  )  POLLOC 
on ppol.policyid = POLLOC.policyid
and ppol.NEXPNUM = POLLOC.NEXPNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
              and mb.NEXPNUM = POLLocationEXTMFL.NEXPNUM)) WHERE rn = 1  )  POLLOCEXT1 
on ppol.PolicyID = POLLOCEXT1.PolicyID
and ppol.NEXPNUM = POLLOCEXT1.NEXPNUM
and POLLOC.NLOCNUM = POLLOCEXT1.NLOCNUM
and POLLOC.NSTANUM = POLLOCEXT1.NSTANUM
and POLLOC.NBLDNUM = POLLOCEXT1.NBLDNUM
and POLLOCEXT1.Name like 'CosInd%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
              and mb.NEXPNUM = POLStatMFL.NEXPNUM)) WHERE rn = 1  )POLSTA 
on ppol.PolicyID = POLSTA.PolicyID
and ppol.nexpnum = POLSTA.nexpnum
and POLSTA.NSTANUM = POLLOC.NSTANUM
and   POLSTA.NLOCNUM = 
CASE WHEN POLSTA.NLOCNUM <>0 THEN  POLLOC.NLOCNUM 
     ELSE   POLSTA.NLOCNUM END
and POLSTA.Name like 'TwnCde%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  CAUGARLOCMFL.*
   from
   {rawDB}.CAUGARLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARLOCMFL.PolicyID 
              and mb.NEXPNUM = CAUGARLOCMFL.NEXPNUM)) WHERE rn = 1  ) CAUGARLOC  
on trim(ppol.PolicyID) = trim(CAUGARLOC.PolicyID) 
and trim(ppol.nexpnum) = trim(CAUGARLOC.nexpnum)
and trim(CAUGARLOC.NLOCNUM) <>0
and trim(CAUGARLOC.NSTANUM) = trim(CAUSTA.NSTANUM)
and trim(CAUGARLOC.NLOCNUM) = CASE WHEN trim(POLLOC.NLOCNUM) <>0 THEN trim(POLLOC.NLOCNUM) ELSE trim(CAUGARLOC.NLOCNUM) END

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID 
              and mb.NEXPNUM = SPCCOVMFL.NEXPNUM)) WHERE rn = 1  ) SPCCOV  
on trim(ppol.PolicyID) = trim(SPCCOV.PolicyID) 
and trim(ppol.nexpnum) = trim(SPCCOV.nexpnum)
and trim(SPCCOV.NLOCNUM) <>0
and trim(SPCCOV.NBLDNUM) <>0
and trim(SPCCOV.NSTANUM) = trim(CAUSTA.NSTANUM)
and trim(SPCCOV.NLOCNUM) = CASE WHEN trim(POLLOC.NLOCNUM) <>0 THEN trim(POLLOC.NLOCNUM) ELSE trim(SPCCOV.NLOCNUM) END
and trim(SPCCOV.NBLDNUM) = CASE WHEN trim(POLLOC.NBLDNUM)<>0 THEN trim(POLLOC.NBLDNUM) ELSE trim(SPCCOV.NBLDNUM) END
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_geo_info")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","GEO_INFO_ID")
  
    mergeAndWrite(hashDF,List("GEO_INFO_KEY","END_EFF_DT"), harmonized_table,"GEO_INFO_ID","HV-CA")
 
}