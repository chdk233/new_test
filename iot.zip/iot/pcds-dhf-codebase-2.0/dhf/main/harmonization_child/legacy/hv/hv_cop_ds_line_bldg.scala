// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_line_bldg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when BOPBLD.NSTANUM is NULL then ( 999 ) else BOPBLD.NSTANUM end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-') 
,case when BOPBLD.NBLDNUM is NULL then (999) else BOPBLD.NBLDNUM end),'-') 
,case when BLDEXT3.Element IS NULL then (999) else BLDEXT3.Element end),'-')
,case when BLDEXT4.Element IS NULL then (999) else BLDEXT4.Element end)
as LINE_BLDG_KEY
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when BOPBLD.NSTANUM is NULL then ( 999 ) else BOPBLD.NSTANUM end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-') 
,case when BOPBLD.NBLDNUM is NULL then (999) else BOPBLD.NBLDNUM end),'-')
,case when BLDEXT3.Element IS NULL then (999) else BLDEXT3.Element end),'-')
,case when BLDEXT4.Element IS NULL then (999) else BLDEXT4.Element end)
 as BLDG_KEY


,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999  ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM  when BOPBLD.NSTANUM is NULL then ( 999  ) else  BOPBLD.NSTANUM  end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-')
,case when POLLOC.NBLDNUM is NULL  then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM when BOPBLD.NBLDNUM is NULL then ( 999  ) else BOPBLD.NBLDNUM  end)
as LINE_LOCATION_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999  ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM  when BOPBLD.NSTANUM is NULL then ( 999  ) else  BOPBLD.NSTANUM  end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-') 
,case when POLLOC.NBLDNUM is NULL  then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM when BOPBLD.NBLDNUM is NULL then ( 999  ) else BOPBLD.NBLDNUM  end)
   as LOC_KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY
,case when year(ppol.NEFFDATREC) = 1899 then DATE(ppol.NEFFDAT) else DATE(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then DATE(ppol.NEXPDAT) else DATE(ppol.NEXPDATREC) end  as END_EXP_DT
,BLDEXT1.StringValue as BLDG_COND_TEXT
, BLDEXT2.StringValue as BLDG_SF_NO
,BOPBLD.NBLDNUM as BP_BLDG_NO
,BOPBLD.NCONCDE as CONSTR_CD
, BLDEXT10.StringValue as CONSTR_QLTY_LEVEL_TEXT
, BOPBLD.LCON as CONSTR_TYPE
,BOPBLD.NYRSBIL as CONSTR_YR_NO
,'COPBuilding' as CVRBL_TYPE_CD
,BOPBLD.LETQCLS as EQ_BUILD_CONSTR_DTL_CD
,BOPBLD.LETQCLS as EQ_CONSTR_CL
, BOPBLD.NETQCONCDE as EQ_GRADE_CD
, BOPLOCEXT1.Stringvalue as HAZARD_GRADE
, Case when BOPCOV.LMSCDES6 ='YES' then 'Y' when BOPCOV.LMSCDES6 ='NO' then 'N' end  as INCL_IN_BLNKT_FL
, BLDEXT5.DoubleValue as ITV_ACT_CASH_VAL_AMT
, BLDEXT6.DoubleValue as ITV_REPL_COST_VAL_AMT
, BLDEXT7.DoubleValue as ITV_VAL_AMT
,BOPCOVEXT.StringValue as MINE_SUBSD_TYPE
,BLDEXT8.DoubleValue as NUM_OF_RES_UNITS
,BLDEXT4.StringValue as PERCENT_OF_OCC
,'HV' as SOURCE_SYSTEM
,Case when BOPBLD.LSPK ='YES' then 'Y' when BOPBLD.LSPK ='NO' then 'N' end as SPRINKLER_RED_FL
,BLDEXT9.DoubleValue as STORIES_NO
,BLDEXT11.StringValue as VALUATION_ID
,Case when BOPPOLEXT.BooleanValue = 1 then 'Insured Request Exemption' else ' ' end as VALUATION_LAW
,'HV-COP' as PARTITION_VAL
,'COP' as LOB_CD
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid


 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
)) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              and mb.nexpnum = POLLocationMFL.nexpnum
)) WHERE rn = 1  )  POLLOC
on POLLOC.PolicyID = ppol.PolicyID
and POLLOC.nexpnum = ppol.nexpnum



left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM, NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID 
              and mb.nexpnum = BOPBLDMFL.nexpnum
)) WHERE rn = 1  )  BOPBLD
on BOPBLD.policyid = ppol.policyid
and BOPBLD.NEXPNUM = ppol.NEXPNUM
and BOPBLD.NLOCNUM = POLLOC.NLOCNUM
and case when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else BOPBLD.NBLDNUM end  = BOPBLD.NBLDNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCMFL.*
   from
   {rawDB}.BOPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCMFL.PolicyID 
              and mb.nexpnum = BOPLOCMFL.nexpnum
)) WHERE rn = 1  ) BOPLOC
on BOPLOC.PolicyID = ppol.PolicyID
and BOPLOC.nexpnum = ppol.nexpnum
and BOPLOC.NSTANUM = BOPBLD.NSTANUM
and BOPLOC.NLOCNUM = BOPBLD.NLOCNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCEXTMFL.*
   from
   {rawDB}.BOPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCEXTMFL.PolicyID 
              and mb.nexpnum = BOPLOCEXTMFL.nexpnum
              and BOPLOCEXTMFL.Name like 'EtqHazGra%'
)) WHERE rn = 1  )  BOPLOCEXT1
on BOPLOCEXT1.PolicyID = ppol.PolicyID
and BOPLOCEXT1.nexpnum = ppol.nexpnum
and BOPLOCEXT1.NSTANUM = BOPBLD.NSTANUM
and BOPLOCEXT1.NLOCNUM = BOPBLD.NLOCNUM
and BOPLOCEXT1.Name like 'EtqHazGra%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'CndBld%'
)) WHERE rn = 1  ) BLDEXT1
on BLDEXT1.PolicyID = ppol.PolicyID
and BLDEXT1.nexpnum = ppol.nexpnum
and BLDEXT1.NSTANUM = BOPBLD.NSTANUM
and BLDEXT1.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT1.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT1.Name like 'CndBld%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'SqrFtg%'
)) WHERE rn = 1  ) BLDEXT2
on BLDEXT2.PolicyID = ppol.PolicyID
and BLDEXT2.nexpnum = ppol.nexpnum
and BLDEXT2.NSTANUM = BOPBLD.NSTANUM
and BLDEXT2.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT2.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT2.Name like 'SqrFtg%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name,NCRTNUM, Element,NBLDNUM,NLOCNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              
)) WHERE rn = 1  ) BLDEXT3
on BLDEXT3.PolicyID = ppol.PolicyID
and BLDEXT3.nexpnum = ppol.nexpnum
and BLDEXT3.NSTANUM = BOPBLD.NSTANUM
and BLDEXT3.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT3.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT3.StringValue <> '0' and trim(BLDEXT3.StringValue) <> ''
and BLDEXT3.Name like 'OccCde%'



left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name,NCRTNUM, Element,NBLDNUM,NLOCNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
           
)) WHERE rn = 1  ) BLDEXT4
on BLDEXT4.PolicyID = ppol.PolicyID
and BLDEXT4.nexpnum = ppol.nexpnum
and BLDEXT4.NSTANUM = BOPBLD.NSTANUM
and BLDEXT4.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT4.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT4.StringValue <> '0' and trim(BLDEXT4.StringValue) <> ''
and BLDEXT4.Name like 'PctOcc%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'ItvAcv%'
)) WHERE rn = 1  )BLDEXT5
on BLDEXT5.PolicyID = ppol.PolicyID
and BLDEXT5.nexpnum = ppol.nexpnum
and BLDEXT5.NSTANUM = BOPBLD.NSTANUM
and BLDEXT5.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT5.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT5.Name like 'ItvAcv%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'ItvRp%'
)) WHERE rn = 1  )  BLDEXT6
on BLDEXT6.PolicyID = ppol.PolicyID
and BLDEXT6.nexpnum = ppol.nexpnum
and BLDEXT6.NSTANUM = BOPBLD.NSTANUM
and BLDEXT6.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT6.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT6.Name like 'ItvRp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'ItvVal%'
)) WHERE rn = 1  )  BLDEXT7
on BLDEXT7.PolicyID = ppol.PolicyID
and BLDEXT7.nexpnum = ppol.nexpnum
and BLDEXT7.NSTANUM = BOPBLD.NSTANUM
and BLDEXT7.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT7.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT7.Name like 'ItvVal%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'NumUnts%'
)) WHERE rn = 1  ) BLDEXT8
on BLDEXT8.PolicyID = ppol.PolicyID
and BLDEXT8.nexpnum = ppol.nexpnum
and BLDEXT8.NSTANUM = BOPBLD.NSTANUM
and BLDEXT8.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT8.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT8.Name like 'NumUnts%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'NumSty%'
)) WHERE rn = 1  )  BLDEXT9
on BLDEXT9.PolicyID = ppol.PolicyID
and BLDEXT9.nexpnum = ppol.nexpnum
and BLDEXT9.NSTANUM = BOPBLD.NSTANUM
and BLDEXT9.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT9.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT9.Name like 'NumSty%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'ConQlv%'
)) WHERE rn = 1  ) BLDEXT10
on BLDEXT10.PolicyID = ppol.PolicyID
and BLDEXT10.nexpnum = ppol.nexpnum
and BLDEXT10.NSTANUM = BOPBLD.NSTANUM
and BLDEXT10.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT10.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT10.Name like 'ConQlv%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.nexpnum = BOPBLDEXTMFL.nexpnum
              and BOPBLDEXTMFL.Name like 'BldID%'
)) WHERE rn = 1  )  BLDEXT11
on BLDEXT11.PolicyID = ppol.PolicyID
and BLDEXT11.nexpnum = ppol.nexpnum
and BLDEXT11.NSTANUM = BOPBLD.NSTANUM
and BLDEXT11.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT11.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT11.Name like 'BldID%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.nexpnum = BOPPOLEXTMFL.nexpnum
              and BOPPOLEXTMFL.Name like 'SCLaw%'
)) WHERE rn = 1  )	 BOPPOLEXT
on BOPPOLEXT.PolicyID = ppol.PolicyID
and BOPPOLEXT.nexpnum = ppol.nexpnum
and BOPPOLEXT.Name like 'SCLaw%'



left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,LPGMTYP,NOCCNUM,NCOVNUM, NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVMFL.*
   from
   {rawDB}.BOPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVMFL.PolicyID 
              and mb.nexpnum = BOPCOVMFL.nexpnum
              and BOPCOVMFL.NCOVNUM = 10
)) WHERE rn = 1  )  BOPCOV
on BOPCOV.PolicyID = ppol.PolicyID
and BOPCOV.nexpnum = ppol.nexpnum
and BOPCOV.NSTANUM = BOPBLD.NSTANUM
and BOPCOV.NLOCNUM = BOPBLD.NLOCNUM
and BOPCOV.NBLDNUM = BOPBLD.NBLDNUM
and BOPCOV.NCOVNUM = 10


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,LPGMTYP, NOCCNUM, NCOVNUM, NSEQNUM, NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVEXTMFL.*
   from
   {rawDB}.BOPCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVEXTMFL.PolicyID 
              and mb.nexpnum = BOPCOVEXTMFL.nexpnum
              and BOPCOVEXTMFL.NCOVNUM = 10 and BOPCOVEXTMFL.name like 'MSBBld%'
)) WHERE rn = 1  )  BOPCOVEXT
on BOPCOVEXT.PolicyID = ppol.PolicyID
and BOPCOVEXT.nexpnum = ppol.nexpnum
and BOPCOVEXT.NSTANUM = BOPBLD.NSTANUM
and BOPCOVEXT.NLOCNUM = BOPBLD.NLOCNUM
and BOPCOVEXT.NBLDNUM = BOPBLD.NBLDNUM
and BOPCOVEXT.NCOVNUM = 10 and BOPCOVEXT.name like 'MSBBld%'


"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_line_bldg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_BLDG_ID")
  
    mergeAndWrite(hashDF,List("LINE_BLDG_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table,"LINE_BLDG_ID","HV-COP")
 
}