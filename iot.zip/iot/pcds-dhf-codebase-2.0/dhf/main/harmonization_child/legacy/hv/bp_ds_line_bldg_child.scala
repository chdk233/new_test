// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_bp_ds_line_bldg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
SELECT distinct
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBLD.NSTANUM is NULL, '999', LPAD(CAST(BOPBLD.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NLOCNUM is NULL, '999', LPAD(CAST(BOPBLD.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0')) AS LOC_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBLD.NSTANUM is NULL, '999', LPAD(CAST(BOPBLD.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NLOCNUM is NULL, '999', LPAD(CAST(BOPBLD.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0'))||'-'||if(BLDEXT3.ELEMENT is null, '999', LPAD(CAST(BLDEXT3.ELEMENT AS STRING), 3, '0')) AS BLDG_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBLD.NSTANUM is NULL, '999', LPAD(CAST(BOPBLD.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NLOCNUM is NULL, '999', LPAD(CAST(BOPBLD.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0')) AS LINE_LOCATION_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBLD.NSTANUM is NULL, '999', LPAD(CAST(BOPBLD.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NLOCNUM is NULL, '999', LPAD(CAST(BOPBLD.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0'))||'-'||if(BLDEXT3.ELEMENT is null, '999', LPAD(CAST(BLDEXT3.ELEMENT AS STRING), 3, '0')) AS LINE_BLDG_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
'BPBuilding' as CVRBL_TYPE_CD,
ifnull(rtrim(BLDEXT1.StringValue), 'Not Defined') as BLDG_COND_TEXT,
if(rtrim(BOPBLD.LSPK) = '' OR BOPBLD.LSPK is null, 'U', rtrim(BOPBLD.LSPK)) AS AUTOMATIC_SPRINKLER_SYS_FL,
ifnull(rtrim(BOPBLD.LGRA), ' ') AS BCEG_CD,
ifnull(rtrim(BOPBLD.LOCCTYP), ' ') AS OCCP_TYPE,
ifnull(rtrim(BOPBLD.NBLDNUM), ' ') AS BLDG_UNIT_NO,
if(rtrim(BOPBLD.NBLDNUM) = '' OR cast(rtrim(BOPBLD.NBLDNUM) as double) is null, 0, cast(rtrim(BOPBLD.NBLDNUM) as double)) AS BP_BLDG_NO,
if(rtrim(BLDEXT2.stringvalue) = '' OR BLDEXT2.stringvalue is null, 'U',rtrim(BLDEXT2.stringvalue)) AS CNTRL_FIRE_STATION_FL,
ifnull(rtrim(BLDEXT5.StringValue), 'Not Defined') as CONSTR_QLTY_LEVEL_TEXT,
cast(rtrim(BOPBLD.NYRSBIL) as double) AS CONSTR_YR_NO,
ifnull(CAST(BLDEXT6.DoubleValue AS DOUBLE), CAST(0 AS DOUBLE)) AS ITV_ACT_CASH_VAL_AMT,
ifnull(CAST(BLDEXT7.DoubleValue AS DOUBLE), CAST(0 AS DOUBLE)) AS ITV_REPL_COST_VAL_AMT,
ifnull(CAST(BLDEXT8.DoubleValue AS DOUBLE), CAST(0 AS DOUBLE)) AS ITV_VAL_AMT,
ifnull(cast(cast(rtrim(BLDEXT9.DoubleValue) as double) as string), ' ') AS STORIES_NO,
'BP' AS LOB_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where BOP_DEC.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where BOP_DEC.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NSTANUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCMFL.*
   from
   {rawDB}.BOPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPLOC
on ppol.PolicyID = BOPLOC.PolicyID 
and ppol.nexpnum = BOPLOC.nexpnum

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NSTANUM,NPOLPED,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPBLD
on  ppol.policyid = BOPBLD.policyid 
and ppol.NEXPNUM = BOPBLD.NEXPNUM
and BOPLOC.NSTANUM = BOPBLD.NSTANUM
and BOPLOC.NLOCNUM = BOPBLD.NLOCNUM 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT1
on BLDEXT1.PolicyID = ppol.PolicyID
and BLDEXT1.nexpnum = ppol.nexpnum
and BLDEXT1.NSTANUM = BOPBLD.NSTANUM
and BLDEXT1.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT1.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT1.Name like 'CndBld%'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT2
on BLDEXT2.PolicyID = ppol.PolicyID
and BLDEXT2.nexpnum = ppol.nexpnum
and BLDEXT2.NSTANUM = BOPBLD.NSTANUM
and BLDEXT2.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT2.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT2.Name like 'CenAlm%'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT3
on BLDEXT3.PolicyID = ppol.PolicyID
and BLDEXT3.nexpnum = ppol.nexpnum
and BLDEXT3.NSTANUM = BOPBLD.NSTANUM
and BLDEXT3.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT3.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT3.StringValue <> '0' and trim(BLDEXT3.StringValue) <> ''
and BLDEXT3.Name like 'PctOcc%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT5
on BLDEXT5.PolicyID = ppol.PolicyID
and BLDEXT5.nexpnum = ppol.nexpnum
and BLDEXT5.NSTANUM = BOPBLD.NSTANUM
and BLDEXT5.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT5.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT5.Name like 'ConQlv%'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT6
on BLDEXT6.PolicyID = ppol.PolicyID
and BLDEXT6.nexpnum = ppol.nexpnum
and BLDEXT6.NSTANUM = BOPBLD.NSTANUM
and BLDEXT6.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT6.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT6.Name like 'ItvAcv%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT7
on BLDEXT7.PolicyID = ppol.PolicyID
and BLDEXT7.nexpnum = ppol.nexpnum
and BLDEXT7.NSTANUM = BOPBLD.NSTANUM
and BLDEXT7.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT7.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT7.Name like 'ItvRp%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT8
on BLDEXT8.PolicyID = ppol.PolicyID
and BLDEXT8.nexpnum = ppol.nexpnum
and BLDEXT8.NSTANUM = BOPBLD.NSTANUM
and BLDEXT8.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT8.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT8.Name like 'ItvVal%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BLDEXT9
on BLDEXT9.PolicyID = ppol.PolicyID
and BLDEXT9.nexpnum = ppol.nexpnum
and BLDEXT9.NSTANUM = BOPBLD.NSTANUM
and BLDEXT9.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT9.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT9.Name like 'NumSty%'
"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_bp_ds_line_bldg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_BLDG_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("LINE_BLDG_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"LINE_BLDG_ID","HV-BP") 
}