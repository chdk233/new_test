// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_loc(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
 Select 
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999  ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM  when BOPBLD.NSTANUM is NULL then ( 999  ) else  BOPBLD.NSTANUM  end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-') 
,case when POLLOC.NBLDNUM is NULL  then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM when BOPBLD.NBLDNUM is NULL then ( 999  ) else BOPBLD.NBLDNUM  end)
  as LOC_KEY 
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when POLLOC.NSTANUM is NULL then ( 999  ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM  when BOPBLD.NSTANUM is NULL then ( 999  ) else  BOPBLD.NSTANUM  end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-') 
,case when POLLOC.NBLDNUM is NULL  then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM when BOPBLD.NBLDNUM is NULL then ( 999  ) else BOPBLD.NBLDNUM  end),'-') 
,0),--WILL HAVE ONLY ONE ADDRESS --no seq number
'-LOC') as ADDR_KEY
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
, POLLOC.NLOCNUM as LOC_NO
, POLLOC.LADD1 as STREET_1_NAME
, POLLOC.LADD2 as STREET_2_NAME
, POLLOC.AddressLine3 as STREET_3_NAME
, 'US' as CNTRY_CD
, POLLOC.LSTA as REGION_CD
, POLLOC.LCTY as CITY_NAME
, concat(rtrim (POLLOC.LZIP), rtrim (POLLOC.LZIPEXT)) as POSTAL_CD
, POLLOC.LCNT as COUNTY_NAME
,'HV-COP' as PARTITION_VAL
,'COP' as LOB_CD
,ppol.insert_timestamp as ETL_ROW_EFF_DTS


from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid


 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,nstanum,nlocnum,nbldnum  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
            and mb.nexpnum = POLLocationMFL.nexpnum  


              )
  ) WHERE rn = 1  )          
   POLLOC  
on ppol.PolicyID = POLLOC.PolicyID 
and ppol.nexpnum = POLLOC.nexpnum 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,NCRTNUM  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDMFL.NEXPNUM
              )) WHERE rn = 1  )  BOPBLD
on BOPBLD.policyid = ppol.policyid
and BOPBLD.NEXPNUM = ppol.NEXPNUM
and BOPBLD.NLOCNUM =POLLOC.NLOCNUM
and case when POLLOC.NBLDNUM >0 then POLLOC.NBLDNUM else BOPBLD.NBLDNUM end = BOPBLD.NBLDNUM

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LOC_ID")
  
    mergeAndWrite(hashDF,List("LOC_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table,"LOC_ID","HV-COP")
 
}