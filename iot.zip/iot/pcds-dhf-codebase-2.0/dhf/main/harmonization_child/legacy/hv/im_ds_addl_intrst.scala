// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_ds_im_addl_intrst(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

Select 

--CIM ADDL_INTRST_KEY
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when INMLink.NSTANUM is null then (999) else INMLink.NSTANUM end),'-')
,case when INMLink.NLOCNUM is null then (999) else INMLink.NLOCNUM end),'-')
,case when INMLink.NBLDNUM is null then (999) else INMLink.NBLDNUM end),'-')
,case when INMLink.LCOVTYPCDE is null then ('NULL') else INMLink.LCOVTYPCDE end),'-')
,case when INMLink.LSUBCOVCDE is null then ('NULL') else INMLink.LSUBCOVCDE end),'-')
,case when INMLink.nseqnum is null then (999) else INMLink.nseqnum end ) ,'-')
,case when INMLink.ndesnum is null then (999) else INMLink.ndesnum end ) ,'-')
,case when INMLink.type is null then ('NULL') else INMLink.type end ) ,'-')
,case when polAddlin.SequenceNumber is null then (999) else polAddlin.SequenceNumber end )

as ADDL_INTRST_KEY

,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates

,concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') ,case when polAddlin.SequenceNumber is null then (999) else polAddlin.SequenceNumber end) as POL_PARTY_KEY
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,'IM Coverable' as CVRBL_TYPE_CD
,INMLink.type as ADDL_INTRST_TYPE_CD
,'IM' as LOB_CD
,polAddlin.LNAM3 AS CONTRACT_NO
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV-IM' AS PARTITION_VAL

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select distinct polAddlin1.policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,SequenceNumber ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAddInterestMFL.*
   from
   {rawDB}.POLAddInterestMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLAddInterestMFL.PolicyID
                  and mb.nexpnum = POLAddInterestMFL.nexpnum 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   polAddlin1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMLinkMFL.*
   from
   {rawDB}.INMLinkMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = INMLinkMFL.policyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  INMLink1 --
on polAddlin1.SequenceNumber=INMLink1.SequenceNumber
--where ppol.PolicyID = polAddlin1.PolicyID 
-- and ppol.nexpnum = polAddlin1.nexpnum  --Removed to pull ALL NEXPNUM
and polAddlin1.SequenceNumber IS NOT NULL
and INMLink1.type IS NOT NULL   
and INMLink1.SequenceNumber IS NOT NULL
group by  polAddlin1.SequenceNumber,INMLink1.type,INMLink1.SequenceNumber,polAddlin1.policyid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CIM%' 
and ppol.neffyrs > 2019
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 



left outer Join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,SequenceNumber ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAddInterestMFL.*
   from
   {rawDB}.POLAddInterestMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLAddInterestMFL.PolicyID
                  and mb.nexpnum = POLAddInterestMFL.nexpnum 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) polAddlin  
 on ppol.PolicyID = polAddlin.PolicyID 
 and ppol.nexpnum = polAddlin.nexpnum  
 and polAddlin.SequenceNumber IS NOT NULL

left outer join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMLinkMFL.*
   from
   {rawDB}.INMLinkMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = INMLinkMFL.policyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMLink  
on ppol.PolicyID = INMLink.PolicyID 
and ppol.nexpnum = INMLink.nexpnum  
and polAddlin.SequenceNumber=INMLink.SequenceNumber
and INMLink.SequenceNumber IS NOT NULL

"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batchaddlintrst")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","ADDL_INTRST_ID")
    mergeAndWrite(hashDF,List("ADDL_INTRST_KEY","END_EFF_DT"), harmonized_table, "ADDL_INTRST_ID","HV-IM")
}