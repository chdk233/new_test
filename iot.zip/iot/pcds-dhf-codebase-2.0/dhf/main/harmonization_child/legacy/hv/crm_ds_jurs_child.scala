// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_crm_ds_jurs(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(KRMSTAV02.NSTANUM is null, '999', KRMSTAV02.NSTANUM)||'-'||IF(KRMCLSV02.LCLSCDE is null, 'NULL', KRMCLSV02.LCLSCDE)||'-'||IF(KRMCLSV02.LPRIDES is null, 'NULL', KRMCLSV02.LPRIDES) AS JURS_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(KRMSTAV02.NSTANUM is null, '999', KRMSTAV02.NSTANUM)||'-'||IF(KRMCLSV02.LCLSCDE is null, 'NULL', KRMCLSV02.LCLSCDE)||'-'||IF(KRMCLSV02.LPRIDES is null, 'NULL', KRMCLSV02.LPRIDES) AS LINE_CL_CD_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CRM' AS PARTITION_VAL,
'CRM' as  LOB_CD,
'CRJurisdiction' as CVRBL_TYPE_CD,
ifnull(rtrim(KRMSTAV02.NSTANUM), ' ') as JURS_CD,
ifnull(rtrim(KRMSTAV02.LSTANAM), 'Not Defined') as JURS_TEXT
,KRMSTAEXTV026.DoubleValue as ELGBL_MANL_PREM_AM
,KRMSTAEXTV027.DoubleValue as TOT_MANL_PREM_AM
,KRMSTAEXTV028.DoubleValue as ELGBL_WRTN_PREM_AM
,KRMSTAEXTV029.DoubleValue as TOT_WRTN_PREM_AM

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
             )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
 )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'CR%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
)
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CR%' 
and ppol.neffyrs > 2019
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
  )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  KRMSTAV02MFL.*
   from
   {rawDB}.KRMSTAV02MFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = KRMSTAV02MFL.PolicyID 
 )
  ) WHERE rn = 1  ) KRMSTAV02  
on ppol.PolicyID = KRMSTAV02.PolicyID 
and ppol.nexpnum = KRMSTAV02.nexpnum 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCLSNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  KRMCLSV02MFL.*
   from
   {rawDB}.KRMCLSV02MFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = KRMCLSV02MFL.PolicyID 
        
              )
  ) WHERE rn = 1  ) KRMCLSV02  
on ppol.policyid = KRMCLSV02.policyid 
and ppol.NEXPNUM = KRMCLSV02.NEXPNUM 
and KRMSTAV02.NSTANUM = KRMCLSV02.NSTANUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  KRMSTAEXTV02MFL.*
   from
   {rawDB}.KRMSTAEXTV02MFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = KRMSTAEXTV02MFL.PolicyID 
            and mb.NEXPNUM = KRMSTAEXTV02MFL.NEXPNUM )
  ) WHERE rn = 1  )  KRMSTAEXTV026  
on ppol.PolicyID = KRMSTAEXTV026.PolicyID 
and KRMSTAEXTV026.NEXPNUM = ppol.NEXPNUM  
and KRMSTAV02.NSTANUM = KRMSTAEXTV026.NSTANUM
and  KRMSTAEXTV026.Name like 'RMFSubjectManPrm%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  KRMSTAEXTV02MFL.*
   from
   {rawDB}.KRMSTAEXTV02MFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = KRMSTAEXTV02MFL.PolicyID 
            and mb.NEXPNUM = KRMSTAEXTV02MFL.NEXPNUM )
  ) WHERE rn = 1  )  KRMSTAEXTV027  
on ppol.PolicyID = KRMSTAEXTV027.PolicyID 
and KRMSTAEXTV027.NEXPNUM = ppol.NEXPNUM  
and KRMSTAV02.NSTANUM = KRMSTAEXTV027.NSTANUM
and  KRMSTAEXTV027.Name like 'TotMnlPrm%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  KRMSTAEXTV02MFL.*
   from
   {rawDB}.KRMSTAEXTV02MFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = KRMSTAEXTV02MFL.PolicyID 
            and mb.NEXPNUM = KRMSTAEXTV02MFL.NEXPNUM )
  ) WHERE rn = 1  )KRMSTAEXTV028  
on ppol.PolicyID = KRMSTAEXTV028.PolicyID 
and KRMSTAEXTV028.NEXPNUM = ppol.NEXPNUM  
and KRMSTAV02.NSTANUM = KRMSTAEXTV028.NSTANUM
and  KRMSTAEXTV028.Name like 'RMFSubjectWrtPrm%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  KRMSTAEXTV02MFL.*
   from
   {rawDB}.KRMSTAEXTV02MFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = KRMSTAEXTV02MFL.PolicyID 
            and mb.NEXPNUM = KRMSTAEXTV02MFL.NEXPNUM )
  ) WHERE rn = 1  )KRMSTAEXTV029  
on ppol.PolicyID = KRMSTAEXTV029.PolicyID 
and KRMSTAEXTV029.NEXPNUM = ppol.NEXPNUM  
and KRMSTAV02.NSTANUM = KRMSTAEXTV029.NSTANUM
and  KRMSTAEXTV029.Name like 'TotWrtPrm%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_crm_ds_jurs")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","JURS_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("JURS_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"JURS_ID","HV-CRM") 
    //     queryDF.show(3,false)
}