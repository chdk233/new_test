// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_ds_im_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select  distinct

concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'), INMCOV.LCOVTYPCDE),'-'), rtrim(INMCOV.LCOVTYPDES)) ,'-') ,rtrim(INMCOV.LSUBCOVCDE)),'-'),case when rtrim(INMCOV.LSUBCOVDES) = '' then 'Addl Coverage Description' else rtrim(INMCOV.LSUBCOVDES) end) as COVG_KEY
,NULL as COVG_ID 
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,NULL as ETL_ROW_EXP_DTS   
,NULL as ETL_CURR_ROW_FL
--,NULL as ETL_ADD_DTS 
,NULL as ETL_LAST_UPDATE_DTS 
,NULL as MD5_HASH 
,'IM' AS LOB_CD
,'HV' as SOURCE_SYSTEM
,'HV-IM' AS PARTITION_VAL
,INMCOV.LSUBCOVCDE as COVG_PART_CD
,INMCOV.LSUBCOVDES as COVG_PART_TEXT
,INMCOV.LCOVTYPCDE as COVG_CD
,INMCOV.LCOVTYPDES as COVG_TEXT
 



from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CIM%'
and ppol1.neffyrs like '%2020%' 
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CIM%' 
and ppol.neffyrs like '%2020%'
and w.act_wstid = 11 
and w.actstored <> 2
 and w.actLastActivity like '%2020%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NCRTNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAMFL.*
   from
   {rawDB}.INMSTAMFL 
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTA 
on ppol.PolicyID = INMSTA.PolicyID 
and ppol.nexpnum  = INMSTA.nexpnum 
 


inner Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NCRTNUM,NSTANUM ,LSUBCOVCDE,LCOVTYPCDE,NSEQNUM,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMCOVMFL.*
   from
   {rawDB}.INMCOVMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = INMCOVMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMCOV  
on ppol.PolicyID = INMCOV.PolicyID 
and ppol.nexpnum  = INMCOV.nexpnum  
and INMSTA.nstanum = INMCOV.nstanum



"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","COVG_ID")
    mergeAndWrite(hashDF,List("COVG_KEY","ETL_ROW_EFF_DTS"), harmonized_table, "COVG_ID","HV-IM")
}