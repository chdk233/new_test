// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_crime_dfncy(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
 Select 
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
 as CRIME_DFNCY_KEY  -- will show duplicates
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY 
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'COP' as LOB_CD
,'HV' as SOURCE_SYSTEM
,BOPDFP.Dfp as EFD_DATA_CONTROL
,BOPDFP2.Dfp as EFD_ELCTN_TRANS
,BOPRCV1.NANNPRM as EFD_PREM
,BOPRCF1.NFAC as EFD_RATE
,BOPDFP3.Dfp as EFD_EFDE
,BOPDFP4.Dfp as EFD_XTRNL_EXPSR
,BOPDFP5.Dfp as EFD_IC_COV_PRPTY
,BOPDFP6.Dfp as EFD_IC_MNY
,BOPDFP7.Dfp as EFD_IC_SECURITY
,BOPDFP8.Dfp as EFD_LRGE_LOSS_EXPSR
,BOPDFP9.Dfp as EFD_LOWR_DED
,BOPDFP10.Dfp as EFD_MGMT_SUPERVSN
,BOPDFP11.Dfp as EFD_OFF_PRMS_EXPSR
,BOPDFP12.Dfp as EFD_PRVT_PROT
,BOPDFP13.Dfp as EFD_SPEC_INCM_INS_ARGMT
,BOPDFP14.Dfp as EFD_SPEC_OCCPCY_HZRD
,BOPDfpCoverage.DfpFactor as EFD_DFNCY_POINT_CHRG
,BOPDfpCoverage.DfpCharacteristicTot as EFD_TOT_DFNCY_PTS
--Money and Securities
,BOPDFP15.Dfp as MS_DATA_CONTROL
,BOPDFP16.Dfp as MS_ELCTN_TRANS
,BOPRCV2.NANNPRM as MS_AT_PREM
,BOPRCF2.NFAC as MS_AT_RATE
,BOPDFP17.Dfp as MS_EFDE
,BOPDFP18.Dfp as MS_XTRNL_EXPSR
,BOPDFP19.Dfp as MS_IC_COV_PRPTY
,BOPDFP20.Dfp as MS_IC_MNY
,BOPDFP21.Dfp as MS_IC_SECURITY
,BOPDFP22.Dfp as MS_LRGE_LOSS_EXPSR
,BOPDFP23.Dfp as MS_LOWR_DED
,BOPDFP24.Dfp as MS_MGMT_SUPERVSN
,BOPDfpCoverage2.DfpFactor as MS_DFNCY_POINT_CHRG
,BOPDFP25.Dfp as MS_OFF_PRMS_EXPSR
,BOPDFP26.Dfp as MS_PRVT_PROT
,BOPDFP27.Dfp as MS_SPEC_INCM_INS_ARGMT
,BOPDFP28.Dfp as MS_SPEC_OCCPCY_HZRD
,BOPDfpCoverage2.DfpCharacteristicTot as MS_TOT_DFNCY_PTS
,POLATTA1.AttachmentText as DATA_CONTROL_NOTE
,POLATTA2.AttachmentText as ELCTN_TRANS_NOTE
,POLATTA3.AttachmentText as EFDE_NOTE
,POLATTA4.AttachmentText as XTRNL_EXPSR_NOTE
,POLATTA5.AttachmentText as IC_COV_PRPTY_NOTE
,POLATTA6.AttachmentText as IC_MNY_NOTE
,POLATTA7.AttachmentText as IC_SECURITY_NOTE
,POLATTA8.AttachmentText as LRGE_LOSS_EXPSR_NOTE
,POLATTA9.AttachmentText as LOWR_DED_NOTE
,POLATTA10.AttachmentText as MGMT_SUPERVSN_NOTE
,POLATTA11.AttachmentText as OFF_PRMS_EXPSR_NOTE
,POLATTA12.AttachmentText as PRVT_PROT_NOTE
,POLATTA13.AttachmentText as SPEC_OCCPCY_HZRD_NOTE
,POLATTA14.AttachmentText as SPEC_INCM_INS_ARGMT
,POLATTA15.AttachmentText as UW_NOTE
,'HV-COP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  polpolmfl.*
   from {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  polpolmfl.*
   from {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM(SELECT  WRKACTIVITY.*
   from {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  )POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  ) BOPDFP  
on ppol.PolicyID = BOPDFP.PolicyID 
and ppol.nexpnum = BOPDFP.nexpnum
and BOPDFP.CoverageName ='Efd'
and BOPDFP.CharacteristicName like 'DtaPrc%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP2  
on ppol.PolicyID = BOPDFP2.PolicyID 
and ppol.nexpnum = BOPDFP2.nexpnum
and BOPDFP2.CoverageName ='Efd'
and BOPDFP2.CharacteristicName like 'EleTct%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP3  
on ppol.PolicyID = BOPDFP3.PolicyID 
and ppol.nexpnum = BOPDFP3.nexpnum
and BOPDFP3.CoverageName ='Efd'
and BOPDFP3.CharacteristicName like 'EfdExp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP4  
on ppol.PolicyID = BOPDFP4.PolicyID 
and ppol.nexpnum = BOPDFP4.nexpnum
and BOPDFP4.CoverageName ='Efd'
and BOPDFP4.CharacteristicName like 'ExtXps%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP5  
on ppol.PolicyID = BOPDFP5.PolicyID 
and ppol.nexpnum = BOPDFP5.nexpnum
and BOPDFP5.CoverageName ='Efd'
and BOPDFP5.CharacteristicName like 'InnPrp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP6  
on ppol.PolicyID = BOPDFP6.PolicyID 
and ppol.nexpnum = BOPDFP6.nexpnum
and BOPDFP6.CoverageName ='Efd'
and BOPDFP6.CharacteristicName like 'InnMny%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP7  
on ppol.PolicyID = BOPDFP7.PolicyID 
and ppol.nexpnum = BOPDFP7.nexpnum
and BOPDFP7.CoverageName ='Efd'
and BOPDFP7.CharacteristicName like 'InnScr%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP8  
on ppol.PolicyID = BOPDFP8.PolicyID 
and ppol.nexpnum = BOPDFP8.nexpnum
and BOPDFP8.CoverageName ='Efd'
and BOPDFP8.CharacteristicName like 'LrgLos%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP9  
on ppol.PolicyID = BOPDFP9.PolicyID 
and ppol.nexpnum = BOPDFP9.nexpnum
and BOPDFP9.CoverageName ='Efd'
and BOPDFP9.CharacteristicName like 'LowDed%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP10  
on ppol.PolicyID = BOPDFP10.PolicyID 
and ppol.nexpnum = BOPDFP10.nexpnum
and BOPDFP10.CoverageName ='Efd'
and BOPDFP10.CharacteristicName like 'MgeSpr%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP11  
on ppol.PolicyID = BOPDFP11.PolicyID 
and ppol.nexpnum = BOPDFP11.nexpnum
and BOPDFP11.CoverageName ='Efd'
and BOPDFP11.CharacteristicName like 'OffPms%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP12  
on ppol.PolicyID = BOPDFP12.PolicyID 
and ppol.nexpnum = BOPDFP12.nexpnum
and BOPDFP12.CoverageName ='Efd'
and BOPDFP12.CharacteristicName like 'PvtPtn%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP13  
on ppol.PolicyID = BOPDFP13.PolicyID 
and ppol.nexpnum = BOPDFP13.nexpnum
and BOPDFP13.CoverageName ='Efd'
and BOPDFP13.CharacteristicName like'ArnSpe%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP14  
on ppol.PolicyID = BOPDFP14.PolicyID 
and ppol.nexpnum = BOPDFP14.nexpnum
and BOPDFP14.CoverageName ='Efd'
and BOPDFP14.CharacteristicName like'SpcHaz%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCoverageMFL.*
   from {rawDB}.BOPDfpCoverageMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCoverageMFL.PolicyID
              and mb.nexpnum = BOPDfpCoverageMFL.nexpnum)) WHERE rn = 1  )  BOPDfpCoverage  
on ppol.PolicyID = BOPDfpCoverage.PolicyID 
and ppol.nexpnum = BOPDfpCoverage.nexpnum
and BOPDfpCoverage.CoverageName ='Efd'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NCOVNUM ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  BOPRCVMFL.*
   from {rawDB}.BOPRCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCVMFL.PolicyID
              and mb.nexpnum = BOPRCVMFL.nexpnum)) WHERE rn = 1  ) BOPRCV1   
on ppol.PolicyID = BOPRCV1.PolicyID 
and ppol.nexpnum = BOPRCV1.nexpnum
and BOPRCV1.NCOVNUM =80

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NCOVNUM,NFACNUM ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  BOPRCFMFL.*
   from {rawDB}.BOPRCFMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCFMFL.PolicyID
              and mb.nexpnum = BOPRCFMFL.nexpnum)) WHERE rn = 1  )  BOPRCF1   
on ppol.PolicyID = BOPRCF1.PolicyID 
and ppol.nexpnum = BOPRCF1.nexpnum
and BOPRCF1.NCOVNUM =80
 and BOPRCF1.LMATCDE like 'DFPVAL%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP15  
on ppol.PolicyID = BOPDFP15.PolicyID 
and ppol.nexpnum = BOPDFP15.nexpnum
and BOPDFP15.CoverageName ='Mns'
and BOPDFP15.CharacteristicName like 'DtaPrc%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP16  
on ppol.PolicyID = BOPDFP16.PolicyID 
and ppol.nexpnum = BOPDFP16.nexpnum
and BOPDFP16.CoverageName ='Mns'
and BOPDFP16.CharacteristicName like 'EleTct%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  ) BOPDFP17  
on ppol.PolicyID = BOPDFP17.PolicyID 
and ppol.nexpnum = BOPDFP17.nexpnum
and BOPDFP17.CoverageName ='Mns'
and BOPDFP17.CharacteristicName like 'EfdExp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  ) BOPDFP18  
on ppol.PolicyID = BOPDFP18.PolicyID 
and ppol.nexpnum = BOPDFP18.nexpnum
and BOPDFP18.CoverageName ='Mns'
and BOPDFP18.CharacteristicName like 'ExtXps%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP19  
on ppol.PolicyID = BOPDFP19.PolicyID 
and ppol.nexpnum = BOPDFP19.nexpnum
and BOPDFP19.CoverageName ='Mns'
and BOPDFP19.CharacteristicName like 'InnPrp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP20  
on ppol.PolicyID = BOPDFP20.PolicyID 
and ppol.nexpnum = BOPDFP20.nexpnum
and BOPDFP20.CoverageName ='Mns'
and BOPDFP20.CharacteristicName like 'InnMny%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  ) BOPDFP21  
on ppol.PolicyID = BOPDFP21.PolicyID 
and ppol.nexpnum = BOPDFP21.nexpnum
and BOPDFP21.CoverageName ='Mns'
and BOPDFP21.CharacteristicName like 'InnScr%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  ) BOPDFP22  
on ppol.PolicyID = BOPDFP22.PolicyID 
and ppol.nexpnum = BOPDFP22.nexpnum
and BOPDFP22.CoverageName ='Mns'
and BOPDFP22.CharacteristicName like 'LrgLos%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP23  
on ppol.PolicyID = BOPDFP23.PolicyID 
and ppol.nexpnum = BOPDFP23.nexpnum
and BOPDFP23.CoverageName ='Mns'
and BOPDFP23.CharacteristicName like 'LowDed%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCoverageMFL.*
   from {rawDB}.BOPDfpCoverageMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCoverageMFL.PolicyID
              and mb.nexpnum = BOPDfpCoverageMFL.nexpnum)) WHERE rn = 1  )  BOPDfpCoverage2  
on ppol.PolicyID = BOPDfpCoverage2.PolicyID 
and ppol.nexpnum = BOPDfpCoverage2.nexpnum
and BOPDfpCoverage2.CoverageName ='Mns'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP24  
on ppol.PolicyID = BOPDFP24.PolicyID 
and ppol.nexpnum = BOPDFP24.nexpnum
and BOPDFP24.CoverageName ='Mns'
and BOPDFP24.CharacteristicName like 'MgeSpr%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP25  
on ppol.PolicyID = BOPDFP25.PolicyID 
and ppol.nexpnum = BOPDFP25.nexpnum
and BOPDFP25.CoverageName ='Mns'
and BOPDFP24.CharacteristicName like 'OffPms%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP26  
on ppol.PolicyID = BOPDFP26.PolicyID 
and ppol.nexpnum = BOPDFP26.nexpnum
and BOPDFP26.CoverageName ='Mns'
and BOPDFP26.CharacteristicName like 'PvtPtn%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  ) BOPDFP27  
on ppol.PolicyID = BOPDFP27.PolicyID 
and ppol.nexpnum = BOPDFP27.nexpnum
and BOPDFP27.CoverageName ='Mns'
and BOPDFP27.CharacteristicName like 'ArnSpe%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPDfpCharcMFL.*
   from {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum)) WHERE rn = 1  )BOPDFP28  
on ppol.PolicyID = BOPDFP28.PolicyID 
and ppol.nexpnum = BOPDFP28.nexpnum
and BOPDFP28.CoverageName ='Mns'
and BOPDFP28.CharacteristicName like 'SpcHaz%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NCOVNUM ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  BOPRCVMFL.*
   from {rawDB}.BOPRCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCVMFL.PolicyID
              and mb.nexpnum = BOPRCVMFL.nexpnum)) WHERE rn = 1  ) BOPRCV2   
on ppol.PolicyID = BOPRCV2.PolicyID 
and ppol.nexpnum = BOPRCV2.nexpnum
and BOPRCV2.NCOVNUM =90

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NCOVNUM,NFACNUM ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  BOPRCFMFL.*
   from {rawDB}.BOPRCFMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCFMFL.PolicyID
              and mb.nexpnum = BOPRCFMFL.nexpnum)) WHERE rn = 1  )  BOPRCF2   
on ppol.PolicyID = BOPRCF2.PolicyID 
and ppol.nexpnum = BOPRCF2.nexpnum
and BOPRCF2.NCOVNUM =90
 and BOPRCF2.LMATCDE like 'DFPVAL%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )  POLATTA1  
on ppol.PolicyID = POLATTA1.PolicyID 
and ppol.nexpnum = POLATTA1.nexpnum
and POLATTA1.AQSObjectName ='BOPDfpCharc_Mns_Dfp_DtaPrc'
and ppol.nexpyrsrec = POLATTA1.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )  POLATTA2  
on ppol.PolicyID = POLATTA2.PolicyID 
and ppol.nexpnum = POLATTA2.nexpnum
and POLATTA2.AQSObjectName ='BOPDfpCharc_Mns_Dfp_EleTct'
and ppol.nexpyrsrec = POLATTA2.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )  POLATTA3  
on ppol.PolicyID = POLATTA3.PolicyID 
and ppol.nexpnum = POLATTA3.nexpnum
and POLATTA3.AQSObjectName ='BOPDfpCharc_Mns_Dfp_EfdExp'
and ppol.nexpyrsrec = POLATTA3.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )  POLATTA4  
on ppol.PolicyID = POLATTA4.PolicyID 
and ppol.nexpnum = POLATTA4.nexpnum
and POLATTA4.AQSObjectName ='BOPDfpCharc_Mns_Dfp_ExtXps'
and ppol.nexpyrsrec = POLATTA4.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )  POLATTA5  
on ppol.PolicyID = POLATTA5.PolicyID 
and ppol.nexpnum = POLATTA5.nexpnum
and POLATTA5.AQSObjectName ='BOPDfpCharc_Mns_Dfp_InnPrp'
and ppol.nexpyrsrec = POLATTA5.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  ) POLATTA6  
on ppol.PolicyID = POLATTA6.PolicyID 
and ppol.nexpnum = POLATTA6.nexpnum
and POLATTA6.AQSObjectName ='BOPDfpCharc_Mns_Dfp_InnMny'
and ppol.nexpyrsrec = POLATTA6.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  ) POLATTA7  
on ppol.PolicyID = POLATTA7.PolicyID 
and ppol.nexpnum = POLATTA7.nexpnum
and POLATTA7.AQSObjectName ='BOPDfpCharc_Mns_Dfp_InnScr'
and ppol.nexpyrsrec = POLATTA7.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )POLATTA8  
on ppol.PolicyID = POLATTA8.PolicyID 
and ppol.nexpnum = POLATTA8.nexpnum
and POLATTA8.AQSObjectName ='BOPDfpCharc_Mns_Dfp_LrgLos'
and ppol.nexpyrsrec = POLATTA8.nexpyrsrec

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  ) POLATTA9  
on ppol.PolicyID = POLATTA9.PolicyID 
and ppol.nexpnum = POLATTA9.nexpnum
and POLATTA9.AQSObjectName ='BOPDfpCharc_Mns_Dfp_LowDed'
and ppol.nexpyrsrec = POLATTA9.nexpyrsrec 

left outer  join(Select max (POLATTAmax3.Datecreated) as Datecreated, POLATTAmax3.AQSObjectName as AQSObjectName,ppolmax3.PolicyID  as policyid, ppolmax3.nexpnum as nexpnum
from  ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )  POLATTAmax3 
inner Join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  polpolmfl.*
   from {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppolmax3 
on ppolmax3.PolicyID = POLATTAmax3.PolicyID 
and ppolmax3.nexpnum = POLATTAmax3.nexpnum
and POLATTAmax3.AQSObjectName ='BOPDfpCharc_Mns_Dfp_LowDed'
and ppolmax3.nexpyrsrec = POLATTAmax3.nexpyrsrec 
group by POLATTAmax3.AQSObjectName,ppolmax3.PolicyID,ppolmax3.nexpnum
)POLATTAmax3
on POLATTA9.AQSObjectName = POLATTAmax3.AQSObjectName
 and POLATTA9.PolicyID = POLATTAmax3.PolicyID 
and POLATTA9.nexpnum = POLATTAmax3.nexpnum

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  ) POLATTA10  
on ppol.PolicyID = POLATTA10.PolicyID 
and ppol.nexpnum = POLATTA10.nexpnum
and POLATTA10.AQSObjectName ='BOPDfpCharc_Mns_Dfp_MgeSpr'
and ppol.nexpyrsrec = POLATTA10.nexpyrsrec 

left outer  join (select max (POLATTAmax1.Datecreated) as POLATTAmax1, POLATTAmax1.AQSObjectName as AQSObjectName,ppolmax1.PolicyID as policyid,ppolmax1.nexpnum as nexpnum from ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )POLATTAmax1
inner Join( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  polpolmfl.*
   from {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppolmax1 
on ppolmax1.PolicyID = POLATTAmax1.PolicyID
and ppolmax1.nexpnum = POLATTAmax1.nexpnum
and POLATTAmax1.AQSObjectName ='BOPDfpCharc_Mns_Dfp_MgeSpr'
and ppolmax1.nexpyrsrec = POLATTAmax1.nexpyrsrec
group by POLATTAmax1.AQSObjectName,ppolmax1.PolicyID,ppolmax1.nexpnum
)POLATTAmax1
on POLATTA10.AQSObjectName = POLATTAmax1.AQSObjectName
and POLATTA10.PolicyID = POLATTAmax1.PolicyID 
and POLATTA10.nexpnum = POLATTAmax1.nexpnum

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  ) POLATTA11  
on ppol.PolicyID = POLATTA11.PolicyID 
and ppol.nexpnum = POLATTA11.nexpnum
and POLATTA10.AQSObjectName ='BOPDfpCharc_Mns_Dfp_OffPms'
and ppol.nexpyrsrec = POLATTA11.nexpyrsrec 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )POLATTA12  
on ppol.PolicyID = POLATTA12.PolicyID 
and ppol.nexpnum = POLATTA12.nexpnum
and POLATTA12.AQSObjectName ='BOPDfpCharc_Mns_Dfp_PvtPtn'
and ppol.nexpyrsrec = POLATTA12.nexpyrsrec 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )POLATTA13  
on ppol.PolicyID = POLATTA13.PolicyID 
and ppol.nexpnum = POLATTA13.nexpnum
and POLATTA13.AQSObjectName ='BOPDfpCharc_Mns_Dfp_SpcHaz'
and ppol.nexpyrsrec = POLATTA13.nexpyrsrec 

left outer  join (select max (POLATTAmax2.Datecreated) as POLATTAmax2, POLATTAmax2.AQSObjectName as AQSObjectName,ppolmax2.PolicyID as policyid,ppolmax2.nexpnum as nexpnum from ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  ) POLATTAmax2
inner Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  polpolmfl.*
   from {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  )ppolmax2 
on ppolmax2.PolicyID = POLATTAmax2.PolicyID AND
 ppolmax2.nexpnum = POLATTAmax2.nexpnum
and POLATTAmax2.AQSObjectName ='BOPDfpCharc_Mns_Dfp_SpcHaz'
and ppolmax2.nexpyrsrec = POLATTAmax2.nexpyrsrec
group by POLATTAmax2.AQSObjectName,ppolmax2.PolicyID,ppolmax2.nexpnum
)POLATTAmax2
on POLATTA13.AQSObjectName = POLATTAmax2.AQSObjectName 
and POLATTA13.PolicyID = POLATTAmax2.PolicyID 
and POLATTA13.nexpnum = POLATTAmax2.nexpnum 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )POLATTA14  
on ppol.PolicyID = POLATTA14.PolicyID 
and ppol.nexpnum = POLATTA14.nexpnum
and POLATTA14.AQSObjectName ='BOPDfpCharc_Mns_Dfp_ArnSpe'
and ppol.nexpyrsrec = POLATTA14.nexpyrsrec 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over(partition BY PolicyID,NEXPNUM,PolicyRowID ORDER BY NEXPDATREC DESC ) AS rn
   FROM(SELECT  PolicyAttachmentsMFL.*
   from {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum)) WHERE rn = 1  )POLATTA15  
on ppol.PolicyID = POLATTA15.PolicyID 
and ppol.nexpnum = POLATTA15.nexpnum
and POLATTA15.AQSObjectName ='BOPPOLEXT_KrmUwxNot_DoubleValue'
 and ppol.nexpyrsrec = POLATTA14.nexpyrsrec 
 

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_crime_dfncy")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","CRIME_DFNCY_ID")
  
    mergeAndWrite(hashDF,List("CRIME_DFNCY_KEY","END_EFF_DT"), harmonized_table,"CRIME_DFNCY_ID","HV-COP")
 
}