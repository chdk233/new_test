// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_bp_ds_line_mod3(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select --distinct
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0')) AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0'))||'-BOPEXPER' AS MOD_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPSTA.NSTANUM is NULL, '999', LPAD(cast(BOPSTA.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0'))||'-BOPLIAEXPER' AS LINE_MOD_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
'BP' AS LOB_CD,
'BOPLIAEXPER' as LINE_MOD_CD,
ifnull(rtrim(BOPSTA.LSTACDE), ' ') as JURS_CD,
ifnull(rtrim(BOPSTA.LSTANAM), 'Not Defined') as JURS_TEXT,
ifnull(rtrim(BOPSTA.NIRM1), ' ') as MOD_VAL,
ifnull(cast(BOPSTAEXT2.DoubleValue as double), 0) as SGSTD_MIN_FCTR,
ifnull(cast(BOPSTAEXT3.DoubleValue as double), 0) as SGSTD_MAX_FCTR,
ifnull(cast(BOPSTAEXT4.DoubleValue as double), 0) as SGSTD_FCTR
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAMFL.NEXPNUM
--               where BOPSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTA 
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,nbktnum ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBKTPOLMFL.*
   from
   {rawDB}.BOPBKTPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBKTPOLMFL.PolicyID 
             and mb.NEXPNUM = BOPBKTPOLMFL.NEXPNUM
--               where BOPBKTPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPBKT  
on ppol.policyid = BOPBKT.policyid 
and ppol.NEXPNUM = BOPBKT.NEXPNUM
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT2  
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and BOPSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'AgtLiaMinDef%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT3 
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and BOPSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'AgtLiaMaxDef%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT4 
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and BOPSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'

union

Select --distinct
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0')) AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0'))||'-BOPDEREG' AS MOD_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPSTA.NSTANUM is NULL, '999', LPAD(cast(BOPSTA.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0'))||'-BOPLIADEREG' AS LINE_MOD_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
'BP' AS LOB_CD,
'BOPLIADEREG' as LINE_MOD_CD,
ifnull(rtrim(BOPSTA.LSTACDE), ' ') as JURS_CD,
ifnull(rtrim(BOPSTA.LSTANAM), 'Not Defined') as JURS_TEXT,
ifnull(rtrim(BOPSTA.NIRM6), ' ') as MOD_VAL,
ifnull(cast(BOPSTAEXT2.DoubleValue as double), 0) as SGSTD_MIN_FCTR,
ifnull(cast(BOPSTAEXT3.DoubleValue as double), 0) as SGSTD_MAX_FCTR,
ifnull(cast(BOPSTAEXT4.DoubleValue as double), 0) as SGSTD_FCTR
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAMFL.NEXPNUM
--               where BOPSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTA 
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,nbktnum ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBKTPOLMFL.*
   from
   {rawDB}.BOPBKTPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBKTPOLMFL.PolicyID 
             and mb.NEXPNUM = BOPBKTPOLMFL.NEXPNUM
--               where BOPBKTPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPBKT  
on ppol.policyid = BOPBKT.policyid 
and ppol.NEXPNUM = BOPBKT.NEXPNUM
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT2  
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and BOPSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'AgtLiaMinDef%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT3 
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and BOPSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'AgtLiaMaxDef%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT4 
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and BOPSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'

union

Select --distinct
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0')) AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0'))||'-BOPCAPPING' AS MOD_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPSTA.NSTANUM is NULL, '999', LPAD(cast(BOPSTA.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPBKT.NBKTNUM is NULL, '999', LPAD(cast(BOPBKT.NBKTNUM AS STRING), 3, '0'))||'-BOPLIACAPPING' AS LINE_MOD_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
'BP' AS LOB_CD,
'BOPLIACAPPING' as LINE_MOD_CD,
ifnull(rtrim(BOPSTA.LSTACDE), ' ') as JURS_CD,
ifnull(rtrim(BOPSTA.LSTANAM), 'Not Defined') as JURS_TEXT,
ifnull(rtrim(BOPSTA.NIRM7), ' ') as MOD_VAL,
ifnull(cast(BOPSTAEXT2.DoubleValue as double), 0) as SGSTD_MIN_FCTR,
ifnull(cast(BOPSTAEXT3.DoubleValue as double), 0) as SGSTD_MAX_FCTR,
ifnull(cast(BOPSTAEXT4.DoubleValue as double), 0) as SGSTD_FCTR
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAMFL.NEXPNUM
--               where BOPSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTA 
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,nbktnum ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBKTPOLMFL.*
   from
   {rawDB}.BOPBKTPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBKTPOLMFL.PolicyID 
             and mb.NEXPNUM = BOPBKTPOLMFL.NEXPNUM
--               where BOPBKTPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPBKT  
on ppol.policyid = BOPBKT.policyid 
and ppol.NEXPNUM = BOPBKT.NEXPNUM
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT2  
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and BOPSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'AgtLiaMinDef%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT3 
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and BOPSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'AgtLiaMaxDef%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM
--               where BOPSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT4 
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and BOPSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_bp_ds_line_mod3")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_MOD_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("LINE_MOD_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"LINE_MOD_ID","HV-BP") 
    //     queryDF.show(3,false)
}