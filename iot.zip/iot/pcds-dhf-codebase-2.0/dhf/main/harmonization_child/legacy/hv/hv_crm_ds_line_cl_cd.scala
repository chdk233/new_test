// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_crm_ds_line_cl_cd(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select 
--DS_LINE_CL_CD CR
    concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when KRMSTAV02.NSTANUM is NULL then ( 999  ) else KRMSTAV02.NSTANUM end)
,'-'),case when KRMCLSV02.LCLSCDE is NULL then ( 'NULL'  ) else KRMCLSV02.LCLSCDE end)
,'-'),case when KRMCLSV02.LPRIDES is NULL then ( 'NULL'  ) else KRMCLSV02.LPRIDES end)
as LINE_CL_CD_KEY 
,case when year(ppol.NEFFDATREC) = 1899 then DATE(ppol.NEFFDAT) else DATE(ppol.NEFFDATREC) end  as EFF_DT 
,case when year(ppol.NEXPDATREC) = 1899 then DATE(ppol.NEXPDAT) else DATE(ppol.NEXPDATREC) end  as EXP_DT
,'HV' as SOURCE_SYSTEM
,KRMSTAV02.NSTANUM as JURS_CD
,KRMSTAV02.LSTANAM as JURS_TEXT
, KRMCLSV02.LPMA as CL_TYPE_CD 
, KRMCLSV02.LPMADES as CL_TYPE_TEXT  
,KRMCLSV02.LCLSCDE as CL_CD 
, case when KRMCLSV02.LCLSCDE IS NOT NULL and trim(KRMCLSV02.LSECDES)<>'' then concat(concat(KRMCLSV02.LPRIDES,'-'), KRMCLSV02.LSECDES) when  KRMCLSV02.LCLSCDE IS NOT NULL and trim(KRMCLSV02.LSECDES) =''
then KRMCLSV02.LPRIDES else space(1) end as CLASS_DESC 
,ppol.insert_timestamp AS ETL_ROW_EFF_DTS
,'CRM' AS LOB_CD,
'HV-CRM' AS PARTITION_VAL

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CR%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  KRMSTAV02MFL.*
   from
   {rawDB}.KRMSTAV02MFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = KRMSTAV02MFL.PolicyID
              and mb.nexpnum = KRMSTAV02MFL.nexpnum )) WHERE rn = 1  ) KRMSTAV02  
on ppol.PolicyID = KRMSTAV02.PolicyID 
and ppol.nexpnum = KRMSTAV02.nexpnum 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCLSNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  KRMCLSV02MFL.*
   from
   {rawDB}.KRMCLSV02MFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = KRMCLSV02MFL.PolicyID
              and mb.nexpnum = KRMCLSV02MFL.nexpnum )) WHERE rn = 1  ) KRMCLSV02 
on ppol.policyid = KRMCLSV02.policyid 
and ppol.NEXPNUM = KRMCLSV02.NEXPNUM 
and KRMSTAV02.NSTANUM = KRMCLSV02.NSTANUM

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_crm_ds_line_cl_cd")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_CL_CD_ID")
  
    mergeAndWrite(hashDF,List("LINE_CL_CD_KEY","ETL_ROW_EFF_DTS"), harmonized_table,"LINE_CL_CD_ID","HV-CRM")
 
}