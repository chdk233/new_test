// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_pers_prop(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select --distinct
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates


, concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY 

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end )
,'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end),'-')
,case when PRPOCC.NOCCNUM is NULL  then (999)  else PRPOCC.NOCCNUM end)
,'-'),case when PRPBLDEXT4.Element is NULL  then (999)  else PRPBLDEXT4.Element end)
as OCC_CL_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end )
,'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
as LINE_LOC_KEY 

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end )
,'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
,'-'),case when PRPBLDEXT4.Element IS NULL then (999) else PRPBLDEXT4.Element end)

as BLDG_KEY  

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end )
,'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end),'-')
,case when PRPOCC.NOCCNUM is NULL  then (999)  else PRPOCC.NOCCNUM end)
,'-'),case when PRPBLDEXT4.Element is NULL  then (999)  else PRPBLDEXT4.Element end)
as PERS_PROP_KEY


,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'CPPersonalProperty' as CVRBL_TYPE_CD
,PRPBLD.NCTSGP2RAT as BASE_GRP_II_SPCF_LOSS_RATE
,IF(ISNULL(PRPBLD.NETQCONCDE),' ',PRPBLD.NETQCONCDE) as EQ_GRADE
,IF(ISNULL(PRPBLDEXT1.StringValue),' ',PRPBLDEXT1.StringValue) as EQ_SPRNKL_LEAK_ONLY
,'CP' as LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as etl_row_eff_dts

from global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid


 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,nstanum,nlocnum,nbldnum  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
            and mb.nexpnum = POLLocationMFL.nexpnum  
              )
  ) WHERE rn = 1  )          
   POLLOC
on ppol.PolicyID = POLLOC.PolicyID 
and ppol.nexpnum = POLLOC.nexpnum 
 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLOCMFL.*
   from
   {rawDB}.PRPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) PRPLOC 
on ppol.PolicyID = PRPLOC.PolicyID
and ppol.nexpnum = PRPLOC.nexpnum
and POLLOC.NLOCNUM = PRPLOC.NLOCNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBLDMFL.*
   from
   {rawDB}.PRPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDMFL.PolicyID 
            
              )
  ) WHERE rn = 1  )  PRPBLD  
on  ppol.policyid = PRPBLD.policyid 
and ppol.NEXPNUM = PRPBLD.NEXPNUM
and POLLOC.NLOCNUM = PRPBLD.NLOCNUM
and PRPLOC.NSTANUM = PRPBLD.NSTANUM
and case when POLLOC.NBLDNUM >0 then POLLOC.NBLDNUm else PRPBLD.NBLDNUM end = PRPBLD.NBLDNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPOCCMFL.*
   from
   {rawDB}.PRPOCCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPOCCMFL.PolicyID 
)
  ) WHERE rn = 1  ) PRPOCC  
on  ppol.policyid = PRPOCC.policyid 
and ppol.NEXPNUM = PRPOCC.NEXPNUM 
and PRPLOC.NSTANUM = PRPOCC.NSTANUM
and PRPLOC.NLOCNUM = PRPOCC.NLOCNUM
and PRPBLD.NBLDNUM = PRPOCC.NBLDNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) PRPBLDEXT1  
on ppol.PolicyID = PRPBLDEXT1.PolicyID 
and PRPBLDEXT1.nexpnum = ppol.NEXPNUM   
and PRPBLD.NLOCNUM = PRPBLDEXT1.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT1.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT1.NSTANUM
and  PRPBLDEXT1.Name like 'EqsRsk%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  )  PRPBLDEXT4  
on ppol.PolicyID = PRPBLDEXT4.PolicyID 
and PRPBLDEXT4.nexpnum = ppol.NEXPNUM  
and PRPBLD.NLOCNUM = PRPBLDEXT4.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT4.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT4.NSTANUM
and  PRPBLDEXT4.Name like 'PctOcc%'
and  PRPBLDEXT4.StringValue <> '0' and PRPBLDEXT4.StringValue <> space(0)

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cp_ds_pers_prop")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
   queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","PERS_PROP_ID")
  
    mergeAndWrite(hashDF,List("PERS_PROP_KEY","END_EFF_DT"),harmonized_table,"PERS_PROP_ID","HV-CP")
}