// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_bldg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when BOPBLD.NSTANUM is NULL then ( 999 ) else BOPBLD.NSTANUM end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-') 
,case when BOPBLD.NBLDNUM is NULL then (999) else BOPBLD.NBLDNUM end),'-')
,case when BLDEXT3.Element IS NULL then (999) else BLDEXT3.Element end),'-')
,case when BLDEXT4.Element IS NULL then (999) else BLDEXT4.Element end)
 as BLDG_KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY
,case when year(ppol.NEFFDATREC) = 1899 then DATE(ppol.NEFFDAT) else DATE(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then DATE(ppol.NEXPDAT) else DATE(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999  ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM  when BOPBLD.NSTANUM is NULL then ( 999  ) else  BOPBLD.NSTANUM  end),'-')
,case when POLLOC.NLOCNUM is NULL then (999)  when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM when BOPBLD.NLOCNUM is NULL then ( 999  ) else BOPBLD.NLOCNUM  end),'-') 
,case when POLLOC.NBLDNUM is NULL  then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM when BOPBLD.NBLDNUM is NULL then ( 999  ) else BOPBLD.NBLDNUM  end)
   as LOC_KEY 
,BOPBLD.NYRSBIL as BUILD_YR
, BOPBLD.NBLDNUM as BLDG_NO
,'Building' as BLDG_TYPE_TEXT
,BOPBLD.LISOCON as CONSTR_TYPE_CD
, BOPBLD.LCON as CONSTR_TYPE_TEXT
, BLDEXT1.DoubleValue as STORIES_NO
,BLDEXT2.DoubleValue as UNITS_NO
,BLDEXT3.StringValue as PCT_OCCUPIED_CD
,BLDEXT4.DoubleValue as PCT_OCCUPIED_TEXT
,BLDEXT5.StringValue as ROOF_TYPE_TEXT
,BLDEXT6.StringValue as TOT_AREA_SF_NO
,'HV-COP' as PARTITION_VAL
,'COP' as LOB_CD
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid


 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              and mb.NEXPNUM = POLLocationMFL.NEXPNUM
              )) WHERE rn = 1  )  POLLOC
on POLLOC.PolicyID = ppol.PolicyID
and POLLOC.nexpnum = ppol.nexpnum

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDMFL.NEXPNUM
              )) WHERE rn = 1  )  BOPBLD
on BOPBLD.policyid = ppol.policyid
and BOPBLD.NEXPNUM = ppol.NEXPNUM
and BOPBLD.NLOCNUM = POLLOC.NLOCNUM
and case when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else BOPBLD.NBLDNUM end  = BOPBLD.NBLDNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCMFL.*
   from
   {rawDB}.BOPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCMFL.PolicyID 
              and mb.NEXPNUM = BOPLOCMFL.NEXPNUM
              )) WHERE rn = 1  )  BOPLOC
on BOPLOC.PolicyID = ppol.PolicyID
and BOPLOC.nexpnum = ppol.nexpnum
and BOPLOC.NSTANUM = BOPBLD.NSTANUM
and BOPLOC.NLOCNUM = BOPBLD.NLOCNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDEXTMFL.NEXPNUM
              and BOPBLDEXTMFL.Name like 'NumSty%'
              )) WHERE rn = 1  )  BLDEXT1
on BLDEXT1.PolicyID = ppol.PolicyID
and BLDEXT1.nexpnum = ppol.nexpnum
and BLDEXT1.NSTANUM = BOPBLD.NSTANUM
and BLDEXT1.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT1.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT1.Name like 'NumSty%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDEXTMFL.NEXPNUM
              and BOPBLDEXTMFL.Name like 'NumUnts%'
              )) WHERE rn = 1  ) BLDEXT2
on BLDEXT2.PolicyID = ppol.PolicyID
and BLDEXT2.nexpnum = ppol.nexpnum
and BLDEXT2.NSTANUM = BOPBLD.NSTANUM
and BLDEXT2.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT2.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT2.Name like 'NumUnts%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDEXTMFL.NEXPNUM
              and BOPBLDEXTMFL.StringValue <> '0' and trim(BOPBLDEXTMFL.StringValue) <> ''
              and BOPBLDEXTMFL.Name like 'OccCde%'
              )) WHERE rn = 1  ) BLDEXT3
on BLDEXT3.PolicyID = ppol.PolicyID
and BLDEXT3.nexpnum = ppol.nexpnum
and BLDEXT3.NSTANUM = BOPBLD.NSTANUM
and BLDEXT3.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT3.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT3.StringValue <> '0' and trim(BLDEXT3.StringValue) <> ''
and BLDEXT3.Name like 'OccCde%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDEXTMFL.NEXPNUM
              and BOPBLDEXTMFL.StringValue <> '0' and trim(BOPBLDEXTMFL.StringValue) <> ''
              and BOPBLDEXTMFL.Name like 'PctOcc%'
              )) WHERE rn = 1  ) BLDEXT4
on BLDEXT4.PolicyID = ppol.PolicyID
and BLDEXT4.nexpnum = ppol.nexpnum
and BLDEXT4.NSTANUM = BOPBLD.NSTANUM
and BLDEXT4.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT4.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT4.StringValue <> '0' and trim(BLDEXT4.StringValue) <> ''
and BLDEXT4.Name like 'PctOcc%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDEXTMFL.NEXPNUM
              and BOPBLDEXTMFL.Name like 'TypRoof%'
              )) WHERE rn = 1  ) BLDEXT5
on BLDEXT5.PolicyID = ppol.PolicyID
and BLDEXT5.nexpnum = ppol.nexpnum
and BLDEXT5.NSTANUM = BOPBLD.NSTANUM
and BLDEXT5.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT5.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT5.Name like 'TypRoof%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPBLDEXTMFL.NEXPNUM
              and BOPBLDEXTMFL.StringValue <> '0' and trim(BOPBLDEXTMFL.StringValue) <> ''
              and BOPBLDEXTMFL.Name like 'SqrFtg%'
              )) WHERE rn = 1  ) BLDEXT6
on BLDEXT6.PolicyID = ppol.PolicyID
and BLDEXT6.nexpnum = ppol.nexpnum
and BLDEXT6.NSTANUM = BOPBLD.NSTANUM
and BLDEXT6.NLOCNUM = BOPBLD.NLOCNUM
and BLDEXT6.NBLDNUM = BOPBLD.NBLDNUM
and BLDEXT6.StringValue <> '0' and trim(BLDEXT6.StringValue) <> ''
and BLDEXT6.Name like 'SqrFtg%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_bldg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","BLDG_ID")
  
    mergeAndWrite(hashDF,List("BLDG_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table,"BLDG_ID","HV-COP")
 
}