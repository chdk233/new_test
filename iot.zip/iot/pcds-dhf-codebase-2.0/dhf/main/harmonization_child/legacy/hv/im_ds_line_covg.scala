// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_im_ds_line_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
    
SELECT distinct

SUBSTRING(fact.FACT_PREM_TRANS_KEY,1 ,length(fact.FACT_PREM_TRANS_KEY)-22) AS LINE_COVG_KEY 
--,NULL as LINE_COVG_ID 	 	 
,fact.POL_KEY as POL_KEY 
,fact.POL_KEY as POL_LINE_KEY 
,fact.COVG_KEY as COVG_KEY 

,fact.END_EFF_DT as END_EFF_DT
,fact.END_EXP_DT as END_EXP_DT 
,fact.END_EFF_DT as ETL_ROW_EFF_DTS 
,fact.END_EXP_DT as ETL_ROW_EXP_DTS 
--,NULL as ETL_CURR_ROW_FL 
--,NULL as ETL_ADD_DTS 
--,NULL as ETL_LAST_UPDATE_DTS
--,NULL as MD5_HASH 
,'IM' as LOB_CD 
,'HV' as SOURCE_SYSTEM 
,'HV-IM' as PARTITION_VAL
,fact.CVRBL_TYPE_CD  as CVRBL_TYPE_CD 
  
  from  global_temp.ds_fact_prem_tran_micro_batch micro_fact
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY FACT_PREM_TRANS_KEY,END_EXP_DT,END_EFF_DT ORDER BY END_EXP_DT  DESC ) AS rn
   FROM
   (SELECT  ds_fact_prem_tran.*
   from
   {rawDB}.ds_fact_prem_tran 
   inner join global_temp.ds_fact_prem_tran_micro_batch  mb
              on mb.POL_KEY = ds_fact_prem_tran.POL_KEY
              and mb.END_EFF_DT = ds_fact_prem_tran.END_EFF_DT
              and mb.END_EXP_DT = ds_fact_prem_tran.END_EXP_DT 
              )
  ) WHERE rn = 1 ) FACT  
  on micro_fact.POL_KEY = fact.POL_KEY
              and micro_fact.END_EFF_DT = fact.END_EFF_DT
              and micro_fact.END_EXP_DT = fact.END_EXP_DT
      WHERE fact.PARTITION_VAL = 'HV-IM' and fact.FACT_PREM_TRANS_KEY NOT LIKE '%SURCHARGE%' AND fact.FACT_PREM_TRANS_KEY NOT LIKE '%BAL_MIN%'
    

"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"ds_fact_prem_tran_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_im_line_covg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_COVG_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("LINE_COVG_KEY","END_EFF_DT"),harmonized_table,"LINE_COVG_ID","HV-IM") 
}