// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_wc_ds_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select distinct
 concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(WORCOV.LmatCDE)),'-'), WORCOV.Ldes)  as COVG_KEY
,'WC' as LOB_CD 
,'HV' as SOURCE_SYSTEM 
,'HV-WC' as PARTITION_VAL 
,WORCOV.LmatCDE as COVG_CD
,WORCOV.LDES as COVG_TEXT
,to_timestamp('1900-01-01 00:00:00.000000') as ETL_ROW_EFF_DTS
 
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'WC%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  ) POLEXT6   
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSEGNUM, LJURMAT, NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  WORSTAMFL.*
   from
   {rawDB}.WORSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = WORSTAMFL.PolicyID 
              and mb.NEXPNUM = WORSTAMFL.NEXPNUM 
              )
  ) WHERE rn = 1  ) WORSTA 
on ppol.PolicyID = WORSTA.PolicyID 
and ppol.nexpnum  = WORSTA.nexpnum 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSEGNUM,LJURMAT,NSTANUM,NCOVNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  WORCOVMFL.*
   from
   {rawDB}.WORCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = WORCOVMFL.PolicyID 
              and mb.NEXPNUM = WORCOVMFL.NEXPNUM 
              )
  ) WHERE rn = 1  ) WORCOV  
on ppol.PolicyID = WORCOV.PolicyID 
and ppol.nexpnum  = WORCOV.nexpnum  
and WORSTA.nstanum = WORCOV.nstanum

Where  WORCOV.Ldes IS Not NULL
and WORCOV.LmatCDE IS Not NULL
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_wc_ds_covg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","COVG_ID")
  
    mergeAndWrite(hashDF,List("COVG_KEY","ETL_ROW_EFF_DTS"), harmonized_table,"COVG_ID","HV-WC")
 
}