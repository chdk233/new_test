// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_ds_cu_ul_covg_term(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select
concat('HV-',POLEXT6.StringValue,'-',rtrim(PPOL.lpolnum),'-',PPOL.NEFFYRS,'-',ppol.NEXPNUM,'-',
case when bpcov1.NSTANUM is NULL then 999 else bpcov1.NSTANUM end,'-',
case when bpcov1.NCOVNUM is null then 999 else bpcov1.NCOVNUM end,'-',
CASE WHEN bpcov1.NSEQNUM is null then 999 else bpcov1.NSEQNUM END,
IFNULL('-'||lcovcde||'-'||SYMBOL,'')) AS CU_UL_COVG_TERM_KEY,
--LINE_COVG_KEY,
concat('HV-',POLEXT6.StringValue,'-',rtrim(PPOL.lpolnum),'-',PPOL.NEFFYRS,'-',ppol.NEXPNUM,'-',
case when bpcov1.NSTANUM is NULL then 999 else bpcov1.NSTANUM end,'-',
case when bpcov1.NCOVNUM is null then 999 else bpcov1.NCOVNUM end,'-',
CASE WHEN bpcov1.NSEQNUM is null then 999 else bpcov1.NSEQNUM END) AS CU_UL_POL_KEY,
case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT,
case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT,
'HV' AS SOURCE_SYSTEM,
'CUmbr' as CVRBL_TYPE_CD,
LCOVDES AS COVG_CD,
SYMBOL AS COVG_TERM_CD,
REPLACE(REPLACE(SCREEN,'_AMT',''),'_LMT','') AS COVG_TERM_TEXT,
IF(SCREEN LIKE '%_LMT%',VALUE,NULL) AS TERM_VAL_CD,
IF(SCREEN LIKE '%_AMT%',VALUE,NULL) AS TERM_VAL_AMT,
--'CU' AS LOB_CD,
'HV-CU' AS PARTITION_VAL,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CMB%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CMB%'   
and ppol.neffyrs > 2019
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'


left Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'  
 
 left Join
 
 (
SELECT bpcov.*,
STACK(86,
        IF(TRIM(lcovcde)='GN1','Underlying GL Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='GN1','Prems/OP Table 1 Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        IF(TRIM(lcovcde)='GN1','Prems/OP Table 2 Premium_AMT','NA'),LMSCMAT5,replace(cast(NMSCRAT5 as string),'.0',''),
        IF(TRIM(lcovcde)='GN1','Prems/OP Table 3 Premium_AMT','NA'),LMSCMAT6,replace(cast(NMSCRAT6 as string),'.0',''),
        IF(TRIM(lcovcde)='GN1','Prems/OP Table A Premium_AMT','NA'),LMSCMAT7,replace(cast(NMSCRAT7 as string),'.0',''),
        IF(TRIM(lcovcde)='GN1','Prems/OP Table B Premium_AMT','NA'),LMSCMAT8,replace(cast(NMSCRAT8 as string),'.0',''),
        IF(TRIM(lcovcde)='GN1','Prems/OP Table C Premium_AMT','NA'),LMSCMAT9,replace(cast(NMSCRAT9 as string),'.0',''),
        
        IF(TRIM(lcovcde)='BP1','Underlying Businessowners Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='BP1','Underlying Businessowners Premium - Other Than Garage Classes_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        IF(TRIM(lcovcde)='BP1','Underlying Businessowners Premium - Garage Classes_AMT','NA'),LMSCMAT5,replace(cast(NMSCRAT5 as string),'.0',''),
        
        IF(TRIM(lcovcde)='AUP','Underlying Commercial Auto Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='AUP','Light Vehicle Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        IF(TRIM(lcovcde)='AUP','Medium Vehicle Premium_AMT','NA'),LMSCMAT5,replace(cast(NMSCRAT5 as string),'.0',''),
        IF(TRIM(lcovcde)='AUP','Heavy Vehicle Premium_AMT','NA'),LMSCMAT6,replace(cast(NMSCRAT6 as string),'.0',''),
        IF(TRIM(lcovcde)='AUP','X-Heavy Premium_AMT','NA'),LMSCMAT7,replace(cast(NMSCRAT7 as string),'.0',''),
        IF(TRIM(lcovcde)='AUP','Zone Rated Premium_AMT','NA'),LMSCMAT8,replace(cast(NMSCRAT8 as string),'.0',''),
        IF(TRIM(lcovcde)='AUP','All Other Risk Premium_AMT','NA'),LMSCMAT9,replace(cast(NMSCRAT9 as string),'.0',''),
        If(TRIM(lcovcde)='AUP' and bpext.Name like '%HirNonOwn%','Hired or Non-owned Autos only?_LMT','NA'),bpext.Name,bpext.stringvalue,
        If(TRIM(lcovcde)='AUP' and bpext1.Name like '%UndAutUmxLmt%','Is Underlying Auto UM Limit $$1,000,000?_LMT','NA'),bpext1.Name,bpext1.stringvalue,
        
        
        IF(TRIM(lcovcde)='ELI','Underlying Employers Liability Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        
        IF(TRIM(lcovcde)='GLU','Underlying Garage Liability Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='GLU','Underlying Garage Liability Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        
        IF(TRIM(lcovcde)='GCU','Underlying BOP Garage Class Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='GCU','Underlying BOP Garage Class Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        
        IF(TRIM(lcovcde)='EPL','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='EPL','Underlying Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        
        IF(TRIM(lcovcde)='LQL','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='LQL','Underlying Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        IF(TRIM(lcovcde)='LQL','Percent of Underlying Premium_LMT','NA'),LMSCMAT5,LMSCDES5,
        
        IF(TRIM(lcovcde)='ACU','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='ACU','Rate per Auto_LMT','NA'),LMSCMAT4,LMSCDES4,
        IF(TRIM(lcovcde)='ACU','Number of Autos_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),
        
        IF(TRIM(lcovcde)='BBP','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='BBP','Number of Barbers & Beauticians_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),

        IF(TRIM(lcovcde)='BCP','Underlying Policy Premium_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),
        
        IF(TRIM(lcovcde)='CPF','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='CPF','Number of Cemeteries_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),
        
        IF(TRIM(lcovcde)='CDO','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='CDO','Number of Officers_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),
        
        IF(TRIM(lcovcde)='DDO','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='DDO','Underlying Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        IF(TRIM(lcovcde)='DDO','Number of Directors_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),
        IF(TRIM(lcovcde)='DDO' AND BPEXT2.NAME LIKE '%AnnAgtLmt%','D & O Annual Aggregate Limit_LMT','NA'),BPEXT2.NAME,BPEXT2.STRINGVALUE,
        IF(TRIM(lcovcde)='DDO' AND BPEXT3.NAME LIKE '%PedLgtDat%','Pending or Prior Litigation Date_LMT','NA'),BPEXT3.NAME,BPEXT3.STRINGVALUE,
        IF(TRIM(lcovcde)='DDO' AND BPEXT4.NAME LIKE '%RctDat%','Retroactive Date_LMT','NA'),BPEXT4.NAME,BPEXT4.STRINGVALUE,
        IF(TRIM(lcovcde)='DDO' AND BPEXT5.NAME LIKE '%RetLmt%','Retained Limit_LMT','NA'),BPEXT5.NAME,BPEXT5.STRINGVALUE,
        
        
        
        IF(TRIM(lcovcde)='DPL','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='DPL','Number of Pharmacists_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),
        
        IF(TRIM(lcovcde)='HSL','Underlying Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='HSL','Underlying Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        IF(TRIM(lcovcde)='HSL','Percent of Underlying Premium_LMT','NA'),LMSCMAT5,LMSCDES5,
        
        --sandeep
        
        IF(TRIM(lcovcde)='MPL','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='MPL','Underlying  Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),

        IF(TRIM(lcovcde)='OPL','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='OPL','Underlying  Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        
        IF(TRIM(lcovcde)='MPO','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='MPO','Underlying  Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),

        IF(TRIM(lcovcde)='PMP','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='PMP','Number of Pastors or Ministers_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),

        IF(TRIM(lcovcde)='PEO','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='PEO','Underlying  Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),

        IF(TRIM(lcovcde)='VPL','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='VPL','Number of Veterinarians_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),

        IF(TRIM(lcovcde)='UMF','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='UMF','Number of Autos_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),

        IF(TRIM(lcovcde)='REO','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='REO','Number of Licensed Agents_LMT','NA'),'NXPS',replace(cast(NXPS as string),'.0',''),

        IF(TRIM(lcovcde)='PPL','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='PPL','Underlying  Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),

        IF(TRIM(lcovcde)='WCL','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='WCL','Underlying  Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),

        IF(TRIM(lcovcde)='IEO','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='IEO','Underlying  Policy Premium_AMT','NA'),LMSCMAT4,replace(cast(NMSCRAT4 as string),'.0',''),
        IF(TRIM(lcovcde)='IEO',' Percent of Underlying Premium_LMT','NA'),LMSCMAT5,LMSCDES5,
        
        
        IF(TRIM(lcovcde)='HSA','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='HSA' AND trim(LMSCDES2)<>'N/A','Sublimited Limit_AMT','NA'),LMSCMAT2,LMSCDES2,
        IF(TRIM(lcovcde)='HSA','Human Services Abuse or Molestation Premium_AMT','NA'),LMSCMAT6,replace(cast(NMSCRAT6 as string),'.0',''),
        IF(TRIM(lcovcde)='HSA','Apply Sublimited limits Indicator_LMT','NA'),LMSCMAT4,LMSCDES4,
        
        IF(TRIM(lcovcde)='HSP','Underlying  Policy Limit_LMT','NA'),LMSCMAT1,LMSCDES1,
        IF(TRIM(lcovcde)='HSP' AND LCOVDES LIKE '%HUMAN%SERVICES%PROF%SERVICES%EXCLUSION%' AND trim(LMSCDES2)<>'N/A','Sublimited Limit_AMT','NA'),LMSCMAT2,LMSCDES2,
        IF(TRIM(lcovcde)='HSP' AND LCOVDES LIKE '%HUMAN%SERVICES%PROF%SERVICES%EXCLUSION%','Apply Sublimited limits Indicator_LMT','NA'),LMSCMAT4,LMSCDES4,
        IF(TRIM(lcovcde)='HSP','Human Services Professional Services Premium_AMT','NA'),LMSCMAT6,replace(cast(NMSCRAT6 as string),'.0',''),
        
        
        IF(TRIM(lcovcde)='HSP' AND LCOVDES LIKE  'HUMAN%SERVICES%PROFESSIONAL%SERVICES%' AND LMSCMAT2 LIKE '%AGGLMT%','Human Services Professional Liability Aggregate Limit_LMT','NA'),LMSCMAT2,LMSCDES2,
        IF(TRIM(lcovcde)='HSP' AND LCOVDES LIKE  'HUMAN%SERVICES%PROFESSIONAL%SERVICES%' AND LMSCMAT2 LIKE '%SUBLMT%' AND trim(LMSCDES2)<>'N/A' ,'Sublimitted Limit_AMT','NA'),LMSCMAT2,LMSCDES2,
        IF(TRIM(lcovcde)='HSP' AND LCOVDES LIKE  'HUMAN%SERVICES%PROFESSIONAL%SERVICES%' AND LMSCMAT4 LIKE '%PRFOCC%','Human Services Professional Liability Occurrence Limit_LMT','NA'),LMSCMAT4,LMSCDES4,
        IF(TRIM(lcovcde)='HSP' AND LCOVDES LIKE  'HUMAN%SERVICES%PROFESSIONAL%SERVICES%' AND LMSCMAT4 LIKE '%APYSUB%','Apply Sublimited limits Indicator_LMT','NA'),LMSCMAT4,LMSCDES4
       
        
        ) AS (SCREEN,SYMBOL,VALUE) 
 
 from 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NPOLPED,NCOVNUM,NLOCNUM,NBLDNUM,NOCCNUM,NCRTNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVMFL.* 
   from
   {rawDB}.BOPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) bpcov   

 
left Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCOVNUM,NLOCNUM,NBLDNUM,NOCCNUM,NCRTNUM,NSEQNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVEXTMFL.*
   from
   {rawDB}.BOPCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BPEXT 
 ON
 BPCOV.POLICYID=BPEXT.POLICYID AND
 BPCOV.NEXPNUM=BPEXT.NEXPNUM AND
 BPCOV.NSTANUM=BPEXT.NSTANUM AND
 BPCOV.NCOVNUM=BPEXT.NCOVNUM AND
 BPCOV.NSEQNUM=BPEXT.NSEQNUM AND 
 BPCOV.LPGMTYP=BPEXT.LPGMTYP AND
 bpcov.lcovcde like '%AUP%' 
 and bpext.Name like '%HirNonOwn%' and trim(bpext.stringvalue)<>''

left Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCOVNUM,NLOCNUM,NBLDNUM,NOCCNUM,NCRTNUM,NSEQNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVEXTMFL.*
   from
   {rawDB}.BOPCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BPEXT1 
 ON
 BPCOV.POLICYID=BPEXT1.POLICYID AND
 BPCOV.NEXPNUM=BPEXT1.NEXPNUM AND
 BPCOV.NSTANUM=BPEXT1.NSTANUM AND
 BPCOV.NCOVNUM=BPEXT1.NCOVNUM AND
 BPCOV.NSEQNUM=BPEXT1.NSEQNUM AND 
 BPCOV.LPGMTYP=BPEXT1.LPGMTYP AND
 bpcov.lcovcde like '%AUP%' 
 and bpext1.Name like '%UndAutUmxLmt%' and trim(bpext1.stringvalue)<>''

left Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCOVNUM,NLOCNUM,NBLDNUM,NOCCNUM,NCRTNUM,NSEQNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVEXTMFL.*
   from
   {rawDB}.BOPCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BPEXT2
ON
BPCOV.POLICYID=BPEXT2.POLICYID AND
 BPCOV.NEXPNUM=BPEXT2.NEXPNUM AND
 BPCOV.NSTANUM=BPEXT2.NSTANUM AND
 BPCOV.NCOVNUM=BPEXT2.NCOVNUM AND
 BPCOV.NSEQNUM=BPEXT2.NSEQNUM AND 
 BPCOV.LPGMTYP=BPEXT2.LPGMTYP AND
 bpcov.lcovcde like '%DDO%'
 AND BPEXT2.NAME LIKE '%AnnAgtLmt%' AND trim(bpext2.stringvalue)<>''
 
 left Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCOVNUM,NLOCNUM,NBLDNUM,NOCCNUM,NCRTNUM,NSEQNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVEXTMFL.*
   from
   {rawDB}.BOPCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BPEXT3
ON
BPCOV.POLICYID=BPEXT3.POLICYID AND
 BPCOV.NEXPNUM=BPEXT3.NEXPNUM AND
 BPCOV.NSTANUM=BPEXT3.NSTANUM AND
 BPCOV.NCOVNUM=BPEXT3.NCOVNUM AND
 BPCOV.NSEQNUM=BPEXT3.NSEQNUM AND 
 BPCOV.LPGMTYP=BPEXT3.LPGMTYP AND
 bpcov.lcovcde like '%DDO%'
 AND BPEXT3.NAME LIKE '%PedLgtDat%' AND trim(BPEXT3.stringvalue)<>''
 
 left Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCOVNUM,NLOCNUM,NBLDNUM,NOCCNUM,NCRTNUM,NSEQNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVEXTMFL.*
   from
   {rawDB}.BOPCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BPEXT4
ON
BPCOV.POLICYID=BPEXT4.POLICYID AND
 BPCOV.NEXPNUM=BPEXT4.NEXPNUM AND
 BPCOV.NSTANUM=BPEXT4.NSTANUM AND
 BPCOV.NCOVNUM=BPEXT4.NCOVNUM AND
 BPCOV.NSEQNUM=BPEXT4.NSEQNUM AND 
 BPCOV.LPGMTYP=BPEXT4.LPGMTYP AND
 bpcov.lcovcde like '%DDO%'
 AND BPEXT4.NAME LIKE '%RctDat%' AND trim(BPEXT4.stringvalue)<>''
 
 left Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCOVNUM,NLOCNUM,NBLDNUM,NOCCNUM,NCRTNUM,NSEQNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPCOVEXTMFL.*
   from
   {rawDB}.BOPCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BPEXT5
ON
BPCOV.POLICYID=BPEXT5.POLICYID AND
 BPCOV.NEXPNUM=BPEXT5.NEXPNUM AND
 BPCOV.NSTANUM=BPEXT5.NSTANUM AND
 BPCOV.NCOVNUM=BPEXT5.NCOVNUM AND
 BPCOV.NSEQNUM=BPEXT5.NSEQNUM AND 
 BPCOV.LPGMTYP=BPEXT5.LPGMTYP AND
 bpcov.lcovcde like '%DDO%'
 AND BPEXT5.NAME LIKE '%RetLmt%' AND trim(BPEXT5.stringvalue)<>''
 
 ) bpcov1
ON
ppol.PolicyID=bpcov1.PolicyID and
ppol.NEXPNUM = bpcov1.NEXPNUM
and SCREEN != 'NA'  AND TRIM(SYMBOL)!=''
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batchaddlintrst")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    //val hashDF = addHashColumn_clt("V","CU_UL_COVG_TERM_ID")
    mergeAndWrite(queryDF,List("CU_UL_COVG_TERM_KEY","END_EFF_DT"), harmonized_table, "CU_UL_COVG_TERM_ID","HV-CU")
}