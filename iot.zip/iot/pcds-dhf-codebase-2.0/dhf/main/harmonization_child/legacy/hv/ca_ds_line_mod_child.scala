// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_line_mod(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(CAUSTA.NSTANUM is NULL, '999', CAUSTA.NSTANUM)||'-'||if(CAUSTADSC.NCOVTYP is NULL, '999', CAUSTADSC.NCOVTYP)||'-'||if(CAUSTADSC.NDSCTYP is NULL, '999', CAUSTADSC.NDSCTYP) AS LINE_MOD_KEY,
CASE 
WHEN NCOVTYP =1 THEN
      CASE 
      WHEN CAUSTADSC.NDSCTYP is NULL THEN 'NOKEY'
      WHEN NDSCTYP=1 THEN 'HV-BA-LIA-EXPER'
	  WHEN NDSCTYP=2 THEN 'HV-BA-LIA-SCHED'
	  WHEN NDSCTYP=3 THEN 'HV-BA-LIA-TIP'
	  WHEN NDSCTYP=4 THEN 'HV-BA-LIA-DEREG'
	  WHEN NDSCTYP=5 THEN 'HV-BA-LIA-CAPPING'
	  WHEN NDSCTYP=6 THEN 'HV-BA-LIA-N/A'
      ELSE 'NOKEY'
	  END
WHEN NCOVTYP =8 THEN
	 CASE 
     WHEN CAUSTADSC.NDSCTYP is NULL THEN 'NOKEY'
	 WHEN NDSCTYP=1 THEN 'HV-BA-PHY-EXPER'
	 WHEN NDSCTYP=2 THEN 'HV-BA-PHY-SCHED'
	 WHEN NDSCTYP=3 THEN 'HV-BA-PHY-TIP'
	 WHEN NDSCTYP=4 THEN 'HV-BA-PHY-DEREG'
	 WHEN NDSCTYP=5 THEN 'HV-BA-PHY-CAPPING'
	 WHEN NDSCTYP=6 THEN 'HV-BA-PHY-N/A'
	 ELSE 'NOKEY'
     END
ELSE 'NOKEY'
END AS MOD_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
'CA' as LOB_CD,
CASE 
WHEN NCOVTYP =1 THEN 
     CASE 
     WHEN CAUSTADSC.NDSCTYP=1 THEN 'LIA-EXPER'
     WHEN CAUSTADSC.NDSCTYP=2 THEN 'LIA-SCHED'
	 WHEN CAUSTADSC.NDSCTYP=3 THEN 'LIA-TIP'
	 WHEN CAUSTADSC.NDSCTYP=4 THEN 'LIA-DEREG'
	 WHEN CAUSTADSC.NDSCTYP=5 THEN 'LIA-CAPPING'
	 WHEN CAUSTADSC.NDSCTYP=6 THEN 'LIA-N/A'
	 ELSE 'NF'
	 END
WHEN NCOVTYP =8 THEN
	 CASE WHEN CAUSTADSC.NDSCTYP=1 THEN 'PHY-EXPER'
     WHEN CAUSTADSC.NDSCTYP=2 THEN 'PHY-SCHED'
	 WHEN CAUSTADSC.NDSCTYP=3 THEN 'PHY-TIP'
	 WHEN CAUSTADSC.NDSCTYP=4 THEN 'PHY-DEREG'
	 WHEN CAUSTADSC.NDSCTYP=5 THEN 'PHY-CAPPING'
	 WHEN CAUSTADSC.NDSCTYP=6 THEN 'PHY-N/A'
	 ELSE 'NF'
	 END
ELSE ' '
END AS LINE_MOD_CD,
ifnull(rtrim(CAUSTA.LSTANUM), ' ') AS JURS_CD,
ifnull(rtrim(CAUSTA.LSTANAM), 'Not Defined') AS JURS_TEXT,
ifnull(rtrim(CAUSTADSC.NIRMAUT), ' ') AS MOD_VAL,
CASE 
WHEN CAUSTADSC.NCOVTYP= 1 and CAUSTAEXT1.DoubleValue is  not null THEN cast(CAUSTAEXT1.DoubleValue as double)
WHEN CAUSTADSC.NCOVTYP=8 and CAUSTAEXT3.DoubleValue is  not null THEN cast(CAUSTAEXT3.DoubleValue as double)
ELSE 0
END AS SGSTD_MIN_FCTR,
CASE 
WHEN CAUSTADSC.NCOVTYP= 1 and CAUSTAEXT2.DoubleValue is  not null THEN cast(CAUSTAEXT2.DoubleValue as double)
WHEN CAUSTADSC.NCOVTYP=8 and CAUSTAEXT4.DoubleValue is  not null THEN cast(CAUSTAEXT4.DoubleValue as double)
ELSE 0
END AS SGSTD_MAX_FCTR,
CASE 
WHEN CAUSTADSC.NCOVTYP= 1 and CAUSTAEXT5.DoubleValue is  not null THEN cast(CAUSTAEXT5.DoubleValue as double)
WHEN CAUSTADSC.NCOVTYP=8 and CAUSTAEXT6.DoubleValue is  not null THEN cast(CAUSTAEXT6.DoubleValue as double)
ELSE 0
END AS SGSTD_FCTR
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.policyid = CAUPOL.policyid 
and ppol.NEXPNUM = CAUPOL.NEXPNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA  
on ppol.policyid = CAUSTA.policyid 
and ppol.NEXPNUM = CAUSTA.NEXPNUM
and CAUSTA.NPOLPED=CAUPOL.NPOLPED
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NCOVTYP,NDSCTYP ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTADSCMFL.*
   from
   {rawDB}.CAUSTADSCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTADSCMFL.PolicyID 
            
--               where CAUSTADSCMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTADSC  
on ppol.policyid = CAUSTADSC.policyid 
and ppol.NEXPNUM = CAUSTADSC.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTADSC.NSTANUM
and CAUSTA.NPOLPED= CAUSTADSC.NPOLPED
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT1
on ppol.policyid = CAUSTAEXT1.policyid 
and ppol.NEXPNUM = CAUSTAEXT1.NEXPNUM
and CAUSTA.NSTANUM= CAUSTAEXT1.NSTANUM
and CAUSTA.NPOLPED=CAUSTAEXT1.NPOLPED
and trim(CAUSTAEXT1.Name) = 'LiaMinDef'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT2
on ppol.policyid = CAUSTAEXT2.policyid 
and ppol.NEXPNUM = CAUSTAEXT2.NEXPNUM
and CAUSTA.NSTANUM= CAUSTAEXT2.NSTANUM
and CAUSTA.NPOLPED=CAUSTAEXT2.NPOLPED
and trim(CAUSTAEXT2.Name) = 'LiaMaxDef'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT3
on ppol.policyid = CAUSTAEXT3.policyid 
and ppol.NEXPNUM = CAUSTAEXT3.NEXPNUM
and CAUSTA.NSTANUM= CAUSTAEXT3.NSTANUM
and CAUSTA.NPOLPED=CAUSTAEXT3.NPOLPED
and trim(CAUSTAEXT3.Name) = 'PrpMinDef'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT4
on ppol.policyid = CAUSTAEXT4.policyid 
and ppol.NEXPNUM = CAUSTAEXT4.NEXPNUM
and CAUSTA.NSTANUM= CAUSTAEXT4.NSTANUM
and CAUSTA.NPOLPED=CAUSTAEXT4.NPOLPED
and trim(CAUSTAEXT4.Name) = 'PrpMaxDef'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT5
on ppol.policyid = CAUSTAEXT5.policyid 
and ppol.NEXPNUM = CAUSTAEXT5.NEXPNUM
and CAUSTA.NSTANUM= CAUSTAEXT5.NSTANUM
and CAUSTA.NPOLPED=CAUSTAEXT5.NPOLPED
and trim(CAUSTAEXT5.Name) = 'LiaDefFac'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT6
on ppol.policyid = CAUSTAEXT6.policyid 
and ppol.NEXPNUM = CAUSTAEXT6.NEXPNUM
and CAUSTA.NSTANUM= CAUSTAEXT6.NSTANUM
and CAUSTA.NPOLPED=CAUSTAEXT6.NPOLPED
and trim(CAUSTAEXT6.Name) = 'PrpDefFac'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_line_mod")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_MOD_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("LINE_MOD_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"LINE_MOD_ID","HV-CA") 
    //     queryDF.show(3,false)
}