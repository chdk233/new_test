// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_jurs(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
select 

concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) 
as POL_KEY

, concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY 


,concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when PRPSTA.NSTANUM is NULL then ( 999  ) else PRPSTA.NSTANUM end)

as JURS_KEY

,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,'CPJurisdiction' as CVRBL_TYPE_CD
,PRPSTA.NSTANUM as JURS_CD
,PRPSTA.LSTANAM as JURS_TEXT
,PRPSTAEXT6.DoubleValue as ELGBL_MANL_PREM_AM
,PRPSTAEXT7.DoubleValue as TOT_MANL_PREM_AM
,PRPSTAEXT8.DoubleValue as ELGBL_WRTN_PREM_AM
,PRPSTAEXT9.DoubleValue as TOT_WRTN_PREM_AM
,'CP' as LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum ,ppol1.NEXPDAT,ppol1.NEFFDAT,w.act_wstid ) ppol1
on ppol1.policyid=ppol.policyid

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPSTAMFL.*
   from
   {rawDB}.PRPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSTAMFL.PolicyID 
              and  mb.nexpnum = PRPSTAMFL.nexpnum)
  ) WHERE rn = 1  ) PRPSTA 
on ppol.PolicyID = PRPSTA.PolicyID 
and ppol.nexpnum = PRPSTA.nexpnum 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPSTAEXTMFL.*
   from
   {rawDB}.PRPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSTAEXTMFL.PolicyID 
              and  mb.nexpnum = PRPSTAEXTMFL.nexpnum)
  ) WHERE rn = 1  ) PRPSTAEXT6  
on ppol.PolicyID = PRPSTAEXT6.PolicyID 
and PRPSTAEXT6.NEXPNUM = ppol.NEXPNUM  
and PRPSTA.NSTANUM = PRPSTAEXT6.NSTANUM
and  PRPSTAEXT6.Name like 'RMFSubjectManPrm%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPSTAEXTMFL.*
   from
   {rawDB}.PRPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSTAEXTMFL.PolicyID 
              and  mb.nexpnum = PRPSTAEXTMFL.nexpnum)
  ) WHERE rn = 1  )PRPSTAEXT7  
on ppol.PolicyID = PRPSTAEXT7.PolicyID 
and PRPSTAEXT7.NEXPNUM = ppol.NEXPNUM  
and PRPSTA.NSTANUM = PRPSTAEXT7.NSTANUM
and  PRPSTAEXT7.Name like 'TotMnlPrm%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPSTAEXTMFL.*
   from
   {rawDB}.PRPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSTAEXTMFL.PolicyID 
              and  mb.nexpnum = PRPSTAEXTMFL.nexpnum)
  ) WHERE rn = 1  )PRPSTAEXT8  
on ppol.PolicyID = PRPSTAEXT8.PolicyID 
and PRPSTAEXT8.NEXPNUM = ppol.NEXPNUM  
and PRPSTA.NSTANUM = PRPSTAEXT8.NSTANUM
and  PRPSTAEXT8.Name like 'RMFSubjectWrtPrm%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPSTAEXTMFL.*
   from
   {rawDB}.PRPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSTAEXTMFL.PolicyID 
              and  mb.nexpnum = PRPSTAEXTMFL.nexpnum)
  ) WHERE rn = 1  )PRPSTAEXT9  
on ppol.PolicyID = PRPSTAEXT9.PolicyID 
and PRPSTAEXT9.NEXPNUM = ppol.NEXPNUM  
and PRPSTA.NSTANUM = PRPSTAEXT9.NSTANUM
and  PRPSTAEXT9.Name like 'TotWrtPrm%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cp_jurs")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
   queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","JURS_ID")
  
    mergeAndWrite(hashDF,List("JURS_KEY","END_EFF_DT"),harmonized_table,"JURS_ID","HV-CP")
}