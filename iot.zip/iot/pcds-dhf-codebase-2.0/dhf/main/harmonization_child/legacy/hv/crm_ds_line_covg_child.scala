// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_crm_ds_line_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 


SELECT
fact.FACT_PREM_TRANS_KEY AS LINE_COVG_KEY
,fact.POL_KEY as POL_KEY
,fact.POL_LINE_KEY as POL_LINE_KEY
,fact.COVG_KEY as COVG_KEY
,fact.END_EFF_DT as END_EFF_DT
,fact.END_EXP_DT as END_EXP_DT
,TO_TIMESTAMP(fact.END_EFF_DT) as ETL_ROW_EFF_DTS
,'CRM' as LOB_CD
,'HV' as SOURCE_SYSTEM
,'HV-CRM' as PARTITION_VAL
,fact.CVRBL_TYPE_CD as CVRBL_TYPE_CD

from global_temp.ds_fact_prem_tran_micro_batch micro_fact
INNER JOIN ( SELECT distinct * FROM
( SELECT *, row_number() over ( partition BY FACT_PREM_TRANS_KEY,END_EFF_DT ORDER BY END_EXP_DT DESC ) AS rn
FROM
(SELECT ds_fact_prem_tran.*
from
{rawDB}.ds_fact_prem_tran
inner join global_temp.ds_fact_prem_tran_micro_batch mb
on mb.POL_KEY = ds_fact_prem_tran.POL_KEY
and mb.END_EFF_DT = ds_fact_prem_tran.END_EFF_DT
and mb.END_EXP_DT = ds_fact_prem_tran.END_EXP_DT
)
) WHERE rn = 1 )
fact
on 
micro_fact.POL_KEY = fact.POL_KEY
and micro_fact.END_EFF_DT = fact.END_EFF_DT
and micro_fact.END_EXP_DT = fact.END_EXP_DT
where fact.partition_val = 'HV-CRM' and fact.fact_prem_trans_key not like '%SURCHARGE%' and fact.fact_prem_trans_key not like '%BAL_MIN%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"ds_fact_prem_tran_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.ds_fact_prem_tran_micro_batch_hv_crm_ds_line_covg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_COVG_ID")
  
    mergeAndWrite(hashDF,List("LINE_COVG_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table,"LINE_COVG_ID","HV-CRM")
 
}