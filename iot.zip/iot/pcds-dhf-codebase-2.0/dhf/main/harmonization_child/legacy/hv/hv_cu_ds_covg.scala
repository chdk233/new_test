// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cu_ds_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
select  distinct
concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(BOPCOV.LCOVCDE)),'-'),rtrim(BOPCOV.LCOVDES)) as COVG_KEY
,'CU' as LOB_CD 
,'HV' as SOURCE_SYSTEM 
,'HV-CU' as PARTITION_VAL 
 ,rtrim(BOPCOV.LCOVCDE) as COVG_CD
 ,rtrim(BOPCOV.LCOVDES) as COVG_TEXT
 ,to_timestamp('1900-01-01 00:00:00.000000') as ETL_ROW_EFF_DTS
 
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CMB%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer Join( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,LPGMTYP,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID
              and mb.nexpnum  = BOPSTAMFL.nexpnum )) WHERE rn = 1  )  BOPSTA  
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum  = BOPSTA.nexpnum 


inner Join( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,LPGMTYP,NPOLPED,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  BOPCOVMFL.*
   from
   {rawDB}.BOPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPCOVMFL.PolicyID
              and mb.nexpnum  = BOPCOVMFL.nexpnum )) WHERE rn = 1  )BOPCOV  
on ppol.PolicyID = BOPCOV.PolicyID 
and ppol.nexpnum  = BOPCOV.nexpnum  
and BOPSTA.nstanum = BOPCOV.nstanum

Union ALL

Select distinct
concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(SPCCOV.LCOVTYPCDE)),'-'),rtrim(SPCCOV.LCOVTYPDES)) as COVG_KEY
,'CU' as LOB_CD 
,'HV' as SOURCE_SYSTEM 
,'HV-CU' as PARTITION_VAL 
 ,rtrim(SPCCOV.LCOVTYPCDE) as COVG_CD
, rtrim(SPCCOV.LCOVTYPDES) as COVG_TEXT
,to_timestamp('1900-01-01 00:00:00.000000') as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CMB%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID 
              and mb.nexpnum = SPCCOVMFL.nexpnum )
  ) WHERE rn = 1  ) SPCCOV  
on ppol.policyid = SPCCOV.policyid
and ppol.nexpnum = SPCCOV.nexpnum 
and SPCCOV.LCOVTYPCDE IS NOT NULL

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cu_ds_covg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","COVG_ID")
  
    mergeAndWrite(hashDF,List("COVG_KEY","ETL_ROW_EFF_DTS"), harmonized_table,"COVG_ID","HV-CU")
 
}