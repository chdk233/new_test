// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_crm_ds_fact_prem_tran(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT
fact.FACT_STAGE_KEY||'-'||fact.END_EFF_DT AS FACT_PREM_TRANS_KEY,
'CRM' as LOB_CD,
'HV' as SOURCE_SYSTEM,
'HV-CRM' as PARTITION_VAL,
ifnull(POL.AGCY_KEY, 'NOKEY') as AGCY_KEY,
'NOKEY' as AGNT_KEY,
POL.POL_KEY as POL_KEY,
ifnull(polline.POL_LINE_KEY, 'NOKEY') as POL_LINE_KEY,
ifnull(fact.covg, 'NOKEY') as COVG_KEY,
case 
when  fact.temp_key = 'NOKEY' then 'NOKEY' 
when substring(reverse(fact.temp_key),1,3) = 'CPS' then substring(fact.FACT_STAGE_KEY,1 ,locate_pos(fact.temp_key, '-', 8 )-1)
when substring(reverse(fact.temp_key),1,3) = 'VOC' then substring(fact.FACT_STAGE_KEY,1 ,locate_pos(fact.temp_key, '-', 8 )-1)
else 'NOKEY'
end  as LOC_KEY,
case 
when fact.manuscript_temp like 'MNR-E%' then fact.MANUSCRIPT 
else 'NOKEY' 
end as LINE_MANUSCRIPT_KEY,
ifnull(POL.PRIM_NAMED_INSURED_KEY, 'NOKEY') as NAMED_INSURED_KEY,
ifnull(to_timestamp(fact.TRANS_PROC_DTS,'MM/dd/yyyy'), to_timestamp('12/31/9999','MM/dd/yyyy')) as TRANS_PROC_DTS,
ifnull(fact.END_EFF_DT, CAST('1900-01-01' as DATE)) as TRANS_EFF_DT,
ifnull(fact.END_EXP_DT, CAST('9999-12-31' as DATE)) as TRANS_EXP_DT,
ifnull(fact.TRANS_CD, ' ') as TRANS_CD,
Case when fact.COVG_TERM_TEXT != 'Not Defined' and fact.TERM_VAL_AMT is not null then fact.TERM_VAL_AMT else 0 end as ACT_AMT,
ifnull(fact.TERM_VAL_AMT, 0) as TRANS_AMT,
ifnull(fact.TRANS_ALLOC_CD, ' ') as TRANS_ALLOC_CD,
Case when fact.FACT_STAGE_KEY not like '%SURCHARGE%' and fact.TERM_VAL_AMT is not null then fact.TERM_VAL_AMT else 0 end as WRITTEN_PREM_AMT,
case when fact.FACT_STAGE_KEY  like '%SURCHARGE%' and fact.TERM_VAL_AMT is not null then fact.TERM_VAL_AMT else 0 end as SRCHG_AMT,
Case when fact.FACT_STAGE_KEY not like '%SURCHARGE%' and fact.TEMP_ANNUAL_PREM_AMT is not null then fact.TEMP_ANNUAL_PREM_AMT else 0 end as ANNUAL_PREM_AMT,
ifnull(fact.END_EFF_DT, CAST('1900-01-01' as DATE)) as END_EFF_DT,
ifnull(fact.END_EXP_DT, CAST('1900-12-31' as DATE)) as END_EXP_DT
from  global_temp.ds_policy_micro_batch micro_pol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY POL_KEY,ETL_ROW_EFF_DTS,END_EFF_DT ORDER BY END_EXP_DT   DESC ) AS rn
   FROM
   (SELECT  ds_policy.*
   from
   {rawDB}.ds_policy
   inner join global_temp.ds_policy_micro_batch mb
              on   mb.POL_KEY = ds_policy.POL_KEY 
            and mb.END_EFF_DT = ds_policy.END_EFF_DT
            and mb.END_EXP_DT = ds_policy.END_EXP_DT
              )
  ) WHERE rn = 1  )          
   pol 
ON micro_pol.POL_KEY = pol.POL_KEY 
   and micro_pol.END_EFF_DT = pol.END_EFF_DT
   and micro_pol.END_EXP_DT = pol.END_EXP_DT
   and pol.POL_key like 'HV-CR%'
   and pol.END_EFF_DT > to_date('2009-12-31','yyyy-mm-dd')
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY POL_LINE_KEY,ETL_ROW_EFF_DTS,END_EFF_DT ORDER BY END_EXP_DT   DESC ) AS rn
   FROM
   (SELECT  ds_pol_line.*
   from
   {rawDB}.ds_pol_line
   inner join global_temp.ds_policy_micro_batch mb
              on   mb.POL_KEY = ds_pol_line.POL_KEY 
            and mb.END_EFF_DT = ds_pol_line.END_EFF_DT
            and mb.END_EXP_DT = ds_pol_line.END_EXP_DT
              )
  ) WHERE rn = 1  )  polline
ON POL.pol_key = polline.POL_KEY
and POL.END_EFF_DT = polline.END_EFF_DT
and POL.END_EXP_DT = polline.END_EXP_DT
and polline.POL_key like 'HV-CR%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY FACT_STAGE_KEY,ETL_ROW_EFF_DTS,END_EFF_DT ORDER BY END_EXP_DT   DESC ) AS rn
   FROM
   (SELECT  ds_fact_staging.*
   from
   {rawDB}.ds_fact_staging
   inner join global_temp.ds_policy_micro_batch mb
              on   mb.POL_KEY = ds_fact_staging.POL_KEY 
            and mb.END_EFF_DT = ds_fact_staging.END_EFF_DT
            and mb.END_EXP_DT = ds_fact_staging.END_EXP_DT
              )
  ) WHERE rn = 1  )  fact
on pol.pol_key = fact.pol_key 
and  pol.END_EFF_DT =  fact.END_EFF_DT
and  pol.END_EXP_DT =  fact.END_EXP_DT
and fact.POL_key like 'HV-CR%'
where fact.FACT_STAGE_KEY is NOT NULL
"""
 
     microBatchDF.createOrReplaceGlobalTempView(s"ds_policy_micro_batch")
  println("microBatchDFcount :"+microBatchDF.count)
  microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.ds_policy_micro_batch_hv_crm_ds_fact_prem_tran")
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB) 
  harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
  println("harmz_query after rawDB replace: \n"+ harmz_query)
   
 
  val harmonized_table = s"${harmonizedDB}.${target}"
  val queryDF=microBatchDF.sparkSession.sql(harmz_query)
  println("Harmonized query execution completed..")
  println("QueryDFCount :"+queryDF.count)
  
  //test
    val w = Window.partitionBy($"FACT_PREM_TRANS_KEY").orderBy($"FACT_PREM_TRANS_KEY")
  var auditDF = queryDF.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")  

  val maxSK = spark.table(s"${harmonized_table}").count
  val w1  = Window.orderBy($"FACT_PREM_TRANS_KEY")

  auditDF = auditDF.withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ID", row_number.over(w1) + maxSK)
  
  auditDF= auditDF.withColumn(s"FACT_PREM_TRANS_ID", expr("CAST(ID AS INTEGER)")).drop("ID")
  
  println("auditDF:")
  println("auditDFCount :"+auditDF.count)
 //auditDF.write.format("delta").mode("append").saveAsTable(harmonized_table)
  
  DeltaTable.forName(spark, harmonized_table)
  .as("events")
  .merge(
    auditDF.as("updates"),
    s"events.FACT_PREM_TRANS_KEY = updates.FACT_PREM_TRANS_KEY AND events.SOURCE_SYSTEM = 'HV'")  
  
  .whenNotMatched
  .insertAll()
  .execute()
 }