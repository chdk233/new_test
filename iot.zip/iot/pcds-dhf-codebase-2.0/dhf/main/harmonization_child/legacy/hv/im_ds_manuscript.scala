// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_ds_im_manuscript(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

Select  
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when INMCOV.NSTANUM is null then (999) else INMCOV.NSTANUM end),'-')
,case when INMCOV.NLOCNUM is null then (999) else INMCOV.NLOCNUM end),'-')
,case when INMCOV.NBLDNUM is null then (999) else INMCOV.NBLDNUM end),'-')
,case when INMCOV.NSEQNUM is null then (999) else INMCOV.NSEQNUM end),'-')
,case when INMCOV.LCOVTYPCDE is null then ('NULL') else INMCOV.LCOVTYPCDE end),'-')
,case when INMCOV.LSUBCOVCDE is null then ('NULL') else INMCOV.LSUBCOVCDE end)

as MANUSCRIPT_KEY  
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,INMCOVEXT1.StringValue AS MANUSCRIPT_CVRG_DESC
,'HV' as SOURCE_SYSTEM
 ,Case 
when INMCOVEXT2.StringValue like 'CIM%' or INMCOVEXT2.StringValue like  'IM%' or INMCOVEXT2.StringValue like  'MIL%'  
or INMCOVEXT2.StringValue like  'CO-10%'or INMCOVEXT2.StringValue like  'CM%' or INMCOVEXT2.StringValue like 'ST%'
then Substring (INMCOVEXT2.StringValue,1,CHARINDEX(' ', INMCOVEXT2.StringValue))
else INMCOVEXT2.StringValue end as MANUSCRIPT_NO
,INMCOV.LSUBCOVCDE as MANUSCRIPT_TYPE_CD

,INMCOVEXT1.StringValue as MANUSCRIPT_TYPE_TEXT
,INMCOVEXT2.StringValue AS MANUSCRIPT_TTL
,INMCOV.NANNPRM AS MANUSCRIPT_PREM_AMT
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,'IM' AS LOB_CD
,'HV-IM' AS PARTITION_VAL

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CIM%'
and ppol1.neffyrs like '%2020%' 
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CIM%' 
and ppol.neffyrs like '%2020%'
and w.act_wstid = 11 
and w.actstored <> 2
 and w.actLastActivity like '%2020%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NCRTNUM,NSTANUM ,LSUBCOVCDE,LCOVTYPCDE,NSEQNUM,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMCOVMFL.*
   from
   {rawDB}.INMCOVMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = INMCOVMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMCOV  
on ppol.PolicyID = INMCOV.PolicyID 
and ppol.nexpnum = INMCOV.nexpnum   
and INMCOV.LCOVTYPCDE IN ('MNR') -- Building records only for Manuscript Endorsements and Exclusions
and INMCOV.LSUBCOVCDE IN ('END','EXC')

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMCOVEXTMFL.*
   from
   {rawDB}.INMCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = INMCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMCOVEXT1  
on ppol.PolicyID = INMCOVEXT1.PolicyID 
and ppol.nexpnum = INMCOVEXT1.nexpnum   
and  INMCOV.NSTANUM = INMCOVEXT1.NSTANUM
and  INMCOV.NLOCNUM = INMCOVEXT1.NLOCNUM
and  INMCOV.NBLDNUM = INMCOVEXT1.NBLDNUM
and  INMCOV.NSEQNUM = INMCOVEXT1.NSEQNUM
and INMCOV.LCOVTYPCDE =INMCOVEXT1.LCOVTYPCDE
and INMCOV.LSUBCOVCDE =INMCOVEXT1.LSUBCOVCDE
and INMCOVEXT1.Name like '%Txt%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMCOVEXTMFL.*
   from
   {rawDB}.INMCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = INMCOVEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMCOVEXT2 
on ppol.PolicyID = INMCOVEXT2.PolicyID 
and ppol.nexpnum = INMCOVEXT2.nexpnum   
and  INMCOV.NSTANUM = INMCOVEXT2.NSTANUM
and  INMCOV.NLOCNUM = INMCOVEXT2.NLOCNUM
and  INMCOV.NBLDNUM = INMCOVEXT2.NBLDNUM
and  INMCOV.NSEQNUM = INMCOVEXT2.NSEQNUM
and INMCOV.LCOVTYPCDE =INMCOVEXT2.LCOVTYPCDE
and INMCOV.LSUBCOVCDE =INMCOVEXT2.LSUBCOVCDE
and INMCOVEXT2.Name like '%Ttl%'

"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","MANUSCRIPT_ID")
    mergeAndWrite(hashDF,List("MANUSCRIPT_KEY","END_EFF_DT"), harmonized_table, "MANUSCRIPT_ID","HV-IM")
}