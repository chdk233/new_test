// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cu_ds_fact_prem_tran(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT
fact.FACT_STAGE_KEY AS FACT_PREM_TRANS_KEY,
'CU' as LOB_CD,
'HV' as SOURCE_SYSTEM,
'HV-CU' as PARTITION_VAL,
ifnull(POL.AGCY_KEY, 'NOKEY') as AGCY_KEY,
fact.POL_KEY as POL_KEY,
ifnull(fact.POL_LINE_KEY, 'NOKEY') as POL_LINE_KEY,
case 
when fact.temp_key ='COV'  and  (trim(fact.COVG_CD) not  IN ('GN1', 'UMF', 'BP1', 'AUP', 'ELI', 'GLU', 'GCU', 'ACU', 'BBP', 'BCP', 'CPF', 'CDO', 'DDO', 'DPL', 'EPL', 'HSL', 'HSE', 'HSP', 'HSA', 'IEO', 'LQL', 'MPL', 'OPL', 'MPO', 'PMP', 'PEO', 'VPL', 'REO', 'PPL', 'WCL', '') ) then 'HV-CMB-'||trim(fact.COVG_CD)||'-'||trim(fact.COVG_TEXT) 
else 'NOKEY' 
end  as COVG_KEY,
case 
when fact.temp_key ='COV'  and  (trim(fact.COVG_CD)  IN ('GN1', 'UMF', 'BP1', 'AUP', 'ELI', 'GLU', 'GCU', 'ACU', 'BBP', 'BCP', 'CPF', 'CDO', 'DDO', 'DPL', 'EPL', 'HSL', 'HSE', 'HSP', 'HSA', 'IEO', 'LQL', 'MPL', 'OPL', 'MPO', 'PMP', 'PEO', 'VPL', 'REO', 'PPL', 'WCL') ) then fact.UL_POL_KEY 
else 'NOKEY' 
end  as UL_POL_KEY,
case 
when fact.temp_key ='COV'  and  (trim(fact.COVG_CD)  IN ('GN1', 'UMF', 'BP1', 'AUP', 'ELI', 'GLU', 'GCU', 'ACU', 'BBP', 'BCP', 'CPF', 'CDO', 'DDO', 'DPL', 'EPL', 'HSL', 'HSE', 'HSP', 'HSA', 'IEO', 'LQL', 'MPL', 'OPL', 'MPO', 'PMP', 'PEO', 'VPL', 'REO', 'PPL', 'WCL') ) then 'HV-CMB-'||trim(fact.COVG_CD)||'-'||trim(fact.COVG_TEXT) 
else 'NOKEY' 
end  as UL_COVG_KEY,
case 
when fact.temp_key ='COV'  and  trim(fact.COVG_CD) like '%FR%' then fact.UL_POL_KEY 
else 'NOKEY' 
end  as FCLTV_REINS_KEY,
ifnull(rtrim(fact.LINE_MANUSCRIPT_KEY), 'NOKEY') as LINE_MANUSCRIPT_KEY,
ifnull(POL.PRIM_NAMED_INSURED_KEY, 'NOKEY') as NAMED_INSURED_KEY,
ifnull(to_timestamp(fact.TRANS_PROC_DTS,'MM/dd/yyyy'), to_timestamp('12/31/9999','MM/dd/yyyy')) as TRANS_PROC_DTS,
ifnull(fact.END_EFF_DT, CAST('1900-01-01' as DATE)) as TRANS_EFF_DT,
ifnull(fact.END_EXP_DT, CAST('9999-12-31' as DATE)) as TRANS_EXP_DT,
ifnull(fact.TRANS_CD, ' ') as TRANS_CD,
ifnull(fact.CVRBL_TYPE_CD, ' ') as CVRBL_TYPE_CD,
Case when fact.temp_key != 'Surcharge' and fact.PREM_AMT is not null then fact.PREM_AMT else 0 end as ACT_AMT,
ifnull(fact.PREM_AMT, 0) as TRANS_AMT,
ifnull(fact.TRANS_ALLOC_CD, ' ') as TRANS_ALLOC_CD,
Case when fact.temp_key != 'Surcharge' and fact.PREM_AMT is not null then fact.PREM_AMT else 0 end as WRITTEN_PREM_AMT,
case when fact.temp_key = 'Surcharge' and fact.PREM_AMT is not null then fact.PREM_AMT else 0 end as SRCHG_AMT,
Case when fact.temp_key != 'Surcharge' and fact.TEMP_ANNUAL_PREM_AMT is not null then fact.TEMP_ANNUAL_PREM_AMT else 0 end as ANNUAL_PREM_AMT,
ifnull(fact.END_EFF_DT, CAST('1900-01-01' as DATE)) as END_EFF_DT,
ifnull(fact.END_EXP_DT, CAST('1900-12-31' as DATE)) as END_EXP_DT
from  global_temp.ds_cu_fact_staging_micro_batch micro_fact
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY FACT_STAGE_KEY,ETL_ROW_EFF_DTS,END_EFF_DT ORDER BY END_EXP_DT   DESC ) AS rn
   FROM
   (SELECT  ds_cu_fact_staging.*
   from
   {rawDB}.ds_cu_fact_staging
   inner join global_temp.ds_cu_fact_staging_micro_batch mb
              on   mb.POL_KEY = ds_cu_fact_staging.POL_KEY 
            and mb.END_EFF_DT = ds_cu_fact_staging.END_EFF_DT
            and mb.END_EXP_DT = ds_cu_fact_staging.END_EXP_DT
              )
  ) WHERE rn = 1  )          
   fact 
ON micro_fact.POL_KEY = fact.POL_KEY 
   and micro_fact.END_EFF_DT = fact.END_EFF_DT
   and micro_fact.END_EXP_DT = fact.END_EXP_DT 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY POL_KEY,ETL_ROW_EFF_DTS,END_EFF_DT ORDER BY END_EXP_DT   DESC ) AS rn
   FROM
   (SELECT  ds_policy.*
   from
   {rawDB}.ds_policy
   inner join global_temp.ds_cu_fact_staging_micro_batch mb
              on   mb.POL_KEY = ds_policy.POL_KEY 
            and mb.END_EFF_DT = ds_policy.END_EFF_DT
            and mb.END_EXP_DT = ds_policy.END_EXP_DT
              )
  ) WHERE rn = 1  )  pol
on pol.pol_key = fact.pol_key 
and  pol.END_EFF_DT =  fact.END_EFF_DT
and  pol.END_EXP_DT =  fact.END_EXP_DT
and fact.pol_key like 'HV-CMB%'
and pol.pol_key like 'HV-CMB%'
"""
 
     microBatchDF.createOrReplaceGlobalTempView(s"ds_cu_fact_staging_micro_batch")
  println("microBatchDFcount :"+microBatchDF.count)
  microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.ds_cu_fact_staging_micro_batch_hv_cu_ds_fact_prem_tran")
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB) 
  harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
  println("harmz_query after rawDB replace: \n"+ harmz_query)
   
 
  val harmonized_table = s"${harmonizedDB}.${target}"
  val queryDF=microBatchDF.sparkSession.sql(harmz_query)
  println("Harmonized query execution completed..")
  println("QueryDFCount :"+queryDF.count)
  
  //test
    val w = Window.partitionBy($"FACT_PREM_TRANS_KEY").orderBy($"FACT_PREM_TRANS_KEY")
  var auditDF = queryDF.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")  

  val maxSK = spark.table(s"${harmonized_table}").count
  val w1  = Window.orderBy($"FACT_PREM_TRANS_KEY")

  auditDF = auditDF.withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ID", row_number.over(w1) + maxSK)
  
  auditDF= auditDF.withColumn(s"FACT_PREM_TRANS_ID", expr("CAST(ID AS INTEGER)")).drop("ID")
  
  println("auditDF:")
  println("auditDFCount :"+auditDF.count)
 //auditDF.write.format("delta").mode("append").saveAsTable(harmonized_table)
  
  DeltaTable.forName(spark, harmonized_table)
  .as("events")
  .merge(
    auditDF.as("updates"),
    s"events.FACT_PREM_TRANS_KEY = updates.FACT_PREM_TRANS_KEY AND events.SOURCE_SYSTEM = 'HV'")  
  
  .whenNotMatched
  .insertAll()
  .execute()
 }