// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_jurs(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(CAUSTA.NSTANUM is null, '999', CAUSTA.NSTANUM) AS JURS_KEY,
'NOKEY' as LINE_CL_CD_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
ifnull(rtrim(CAUSTA.LSTACDE), ' ') as JURS_CD,
ifnull(rtrim(CAUSTA.LSTANAM), 'Not Defined') as JURS_TEXT,
CASE
WHEN CAUSTAEXT1.DoubleValue IS NOT NULL AND CAUSTAEXT2.DoubleValue IS NOT NULL THEN cast((CAUSTAEXT1.DoubleValue + CAUSTAEXT2.DoubleValue) as double)
WHEN CAUSTAEXT1.DoubleValue IS NOT NULL AND CAUSTAEXT2.DoubleValue IS NULL THEN cast(CAUSTAEXT1.DoubleValue as double)
WHEN CAUSTAEXT1.DoubleValue IS NULL AND CAUSTAEXT2.DoubleValue IS NOT NULL THEN cast(CAUSTAEXT2.DoubleValue as double)
ELSE 0
END AS ELGBL_MANL_PREM_AM,
CASE
WHEN CAUSTAEXT3.DoubleValue IS NOT NULL AND CAUSTAEXT4.DoubleValue IS NOT NULL THEN cast((CAUSTAEXT3.DoubleValue + CAUSTAEXT4.DoubleValue) as double)
WHEN CAUSTAEXT3.DoubleValue IS NOT NULL AND CAUSTAEXT4.DoubleValue IS NULL THEN cast(CAUSTAEXT3.DoubleValue as double)
WHEN CAUSTAEXT3.DoubleValue IS NULL AND CAUSTAEXT4.DoubleValue IS NOT NULL THEN cast(CAUSTAEXT4.DoubleValue as double)
ELSE 0
END AS TOT_MANL_PREM_AM,
CASE
WHEN CAUSTAEXT5.DoubleValue IS NOT NULL AND CAUSTAEXT6.DoubleValue IS NOT NULL THEN cast((CAUSTAEXT5.DoubleValue + CAUSTAEXT6.DoubleValue) as double)
WHEN CAUSTAEXT5.DoubleValue IS NOT NULL AND CAUSTAEXT6.DoubleValue IS NULL THEN cast(CAUSTAEXT5.DoubleValue as double)
WHEN CAUSTAEXT5.DoubleValue IS NULL AND CAUSTAEXT6.DoubleValue IS NOT NULL THEN cast(CAUSTAEXT6.DoubleValue as double)
ELSE 0
END AS ELGBL_WRTN_PREM_AM,
CASE
WHEN CAUSTAEXT7.DoubleValue IS NOT NULL AND CAUSTAEXT8.DoubleValue IS NOT NULL THEN cast((CAUSTAEXT7.DoubleValue + CAUSTAEXT8.DoubleValue) as double)
WHEN CAUSTAEXT7.DoubleValue IS NOT NULL AND CAUSTAEXT8.DoubleValue IS NULL THEN cast(CAUSTAEXT7.DoubleValue as double)
WHEN CAUSTAEXT7.DoubleValue IS NULL AND CAUSTAEXT8.DoubleValue IS NOT NULL THEN cast(CAUSTAEXT8.DoubleValue as double)
ELSE 0
END AS TOT_WRTN_PREM_AM
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs like '%2020%'
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs like '%2020%'
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity like '%2020%'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where CAUSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA  
on ppol.PolicyID = CAUSTA.PolicyID 
and ppol.nexpnum = CAUSTA.nexpnum 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT1  
on ppol.policyid = CAUSTAEXT1.policyid 
and ppol.NEXPNUM = CAUSTAEXT1.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT1.NSTANUM
and TRIM(CAUSTAEXT1.Name)= 'RMFSubjectLiaManPrm'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT2 
on ppol.policyid = CAUSTAEXT2.policyid 
and ppol.NEXPNUM = CAUSTAEXT2.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT2.NSTANUM
and TRIM(CAUSTAEXT2.Name)= 'RMFSubjectPhyManPrm'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT3
on ppol.policyid = CAUSTAEXT3.policyid 
and ppol.NEXPNUM = CAUSTAEXT3.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT3.NSTANUM
and TRIM(CAUSTAEXT3.Name)= 'TotLiaMnlPrm'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT4
on ppol.policyid = CAUSTAEXT4.policyid 
and ppol.NEXPNUM = CAUSTAEXT4.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT4.NSTANUM
and TRIM(CAUSTAEXT4.Name)= 'TotPhyMnlPrm'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT5
on ppol.policyid = CAUSTAEXT5.policyid 
and ppol.NEXPNUM = CAUSTAEXT5.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT5.NSTANUM
and TRIM(CAUSTAEXT5.Name)= 'TotLiaWrtPrm'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT6
on ppol.policyid = CAUSTAEXT6.policyid 
and ppol.NEXPNUM = CAUSTAEXT6.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT6.NSTANUM
and TRIM(CAUSTAEXT6.Name)= 'TotPhyWrtPrm'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT7
on ppol.policyid = CAUSTAEXT7.policyid 
and ppol.NEXPNUM = CAUSTAEXT7.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT7.NSTANUM
and TRIM(CAUSTAEXT7.Name)= 'RMFSubjectLiaWrtPrm'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAEXTMFL.*
   from
   {rawDB}.CAUSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAEXTMFL.PolicyID 
            
--               where CAUSTAEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTAEXT8
on ppol.policyid = CAUSTAEXT8.policyid 
and ppol.NEXPNUM = CAUSTAEXT8.NEXPNUM  
and CAUSTA.NSTANUM= CAUSTAEXT8.NSTANUM
and TRIM(CAUSTAEXT8.Name)= 'RMFSubjectPhyWrtPrm'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_jurs")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","JURS_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("JURS_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"JURS_ID","HV-CA") 
    //     queryDF.show(3,false)
}