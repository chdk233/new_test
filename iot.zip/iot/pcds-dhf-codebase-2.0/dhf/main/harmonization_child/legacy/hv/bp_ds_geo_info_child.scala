// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_bp_ds_geo_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
 select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(POLLOC.NSTANUM is NULL, '999', LPAD(CAST(POLLOC.NSTANUM AS STRING), 3, '0'))||'-'||if(POLLOC.NLOCNUM is NULL, '999', LPAD(CAST(POLLOC.NLOCNUM AS STRING), 3, '0'))||'-'||if(POLLOC.NBLDNUM is NULL, '999', LPAD(CAST(POLLOC.NBLDNUM AS STRING), 3, '0'))||'-GI' AS GEO_INFO_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(POLLOC.NSTANUM is NULL, '999', LPAD(CAST(POLLOC.NSTANUM AS STRING), 3, '0'))||'-'||if(POLLOC.NLOCNUM is NULL, '999', LPAD(CAST(POLLOC.NLOCNUM AS STRING), 3, '0'))||'-'||if(POLLOC.NBLDNUM is NULL, '999', LPAD(CAST(POLLOC.NBLDNUM AS STRING), 3, '0')) AS LOC_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
CASE
WHEN POLLOCEXT1.stringvalue is NULL THEN ' '
WHEN POLLOCEXT1.stringvalue like 'Not Coastal County, Beach or Seacoast%' THEN 'N'
ELSE 'Y'
END AS COASTAL_IND,
ifnull(rtrim(POLSTA1.stringvalue), ' ') AS COUNTY_CD,
ifnull(rtrim(POLLOC.LCNT), ' ') AS COUNTY_NAME,
ifnull(rtrim(POLSTA5.stringvalue), ' ') AS COUNTY_TAX_CD,
ifnull(rtrim(BOPLOC.LETQZNECDE), ' ') AS EQ_TERRITORY_ZONE_CD,
if(BOPLOCEXT1.StringValue is null OR trim(BOPLOCEXT1.StringValue) = '', 'Not Defined', rtrim(BOPLOCEXT1.StringValue)) AS FIRE_HYDRANT_DISTANCE_TEXT,
ifnull(rtrim(POLLOCEXT2.StringValue), ' ') AS FIRE_STATION_NAME,
ifnull(rtrim(BOPLOC.LTER), ' ') AS ISO_TERRITORY_CD,
ifnull(rtrim(BOPLOC.LPTNCLS), ' ') AS PROTECTION_CL_CD,
ifnull(rtrim(POLLOCEXT3.StringValue), ' ') AS TERRITORY_CD,
ifnull(rtrim(POLSTA3.stringvalue), ' ') AS TOWN_CD,
ifnull(rtrim(BOPLOC.LETQZNE), ' ') AS CMRCL_EQ_RATE_TERR_CD,
CASE
WHEN trim(BOPLOCEXT2.StringValue) = '5 TO 15' THEN cast(15 as double)
WHEN trim(BOPLOCEXT2.StringValue) = '5 OR LESS' THEN cast(5 as double)
WHEN trim(BOPLOCEXT2.StringValue) = 'GREATER THAN 5' THEN cast(15 as double)
WHEN trim(BOPLOCEXT2.StringValue) = 'NONE' OR trim(BOPLOCEXT2.StringValue) = '' OR BOPLOCEXT2.StringValue is null THEN cast(0 as double)
END AS FIRE_STATION_MILE_DIST_QTY,
ifnull(rtrim(POLSTA4.StringValue), ' ') as TOWN_NAME,
ifnull(rtrim(BOPLOCEXT.StringValue), ' ')  as FIRE_TERRITORY_CD,
'BP' AS LOB_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
            and mb.nexpnum = POLLocationMFL.nexpnum
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLLOC  
on ppol.PolicyID = POLLOC.PolicyID
and ppol.nexpnum = POLLOC.nexpnum
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,nstanum,nlocnum,NBLDNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            and mb.nexpnum = POLLocationEXTMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLLOCEXT1  
on ppol.PolicyID = POLLOCEXT1.PolicyID 
and ppol.nexpnum = POLLOCEXT1.NEXPNUM
and POLLOC.NSTANUM=POLLOCEXT1.NSTANUM
and POLLOC.NLOCNUM = POLLOCEXT1.NLOCNUM 
and POLLOC.NBLDNUM = POLLOCEXT1.NBLDNUM 
and POLLOCEXT1.Name like 'CosInd%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,nstanum,nlocnum,NBLDNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            and mb.nexpnum = POLLocationEXTMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLLOCEXT2
on ppol.PolicyID = POLLOCEXT2.PolicyID 
and ppol.nexpnum = POLLOCEXT2.NEXPNUM
and POLLOC.NSTANUM=POLLOCEXT2.NSTANUM
and POLLOC.NLOCNUM = POLLOCEXT2.NLOCNUM 
and POLLOC.NBLDNUM = POLLOCEXT2.NBLDNUM 
and POLLOCEXT2.Name like 'RespFireSta%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,nstanum,nlocnum,NBLDNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            and mb.nexpnum = POLLocationEXTMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLLOCEXT3
on ppol.PolicyID = POLLOCEXT3.PolicyID 
and ppol.nexpnum = POLLOCEXT3.NEXPNUM
and POLLOC.NSTANUM=POLLOCEXT3.NSTANUM
and POLLOC.NLOCNUM = POLLOCEXT3.NLOCNUM 
and POLLOC.NBLDNUM = POLLOCEXT3.NBLDNUM 
and POLLOCEXT3.Name like 'PrpTerCde%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NAME,nstanum,nlocnum,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
            and mb.nexpnum = POLStatMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLSTA1
on ppol.PolicyID = POLSTA1.PolicyID 
and ppol.nexpnum = POLSTA1.NEXPNUM
and POLLOC.NSTANUM=POLSTA1.NSTANUM
and POLLOC.NLOCNUM = POLSTA1.NLOCNUM
and  POLSTA1.Name like 'CntCde%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NAME,nstanum,nlocnum,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
            and mb.nexpnum = POLStatMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLSTA3
on ppol.PolicyID = POLSTA3.PolicyID 
and ppol.nexpnum = POLSTA3.NEXPNUM
and POLLOC.NSTANUM=POLSTA3.NSTANUM
and POLLOC.NLOCNUM = POLSTA3.NLOCNUM
and  POLSTA3.Name like 'TwnCde%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NAME,nstanum,nlocnum,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
            and mb.nexpnum = POLStatMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLSTA4
on ppol.PolicyID = POLSTA4.PolicyID 
and ppol.nexpnum = POLSTA4.NEXPNUM
and POLLOC.NSTANUM=POLSTA4.NSTANUM
and POLLOC.NLOCNUM = POLSTA4.NLOCNUM
and  POLSTA4.Name like 'TwnNam%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NAME,nstanum,nlocnum,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
            and mb.nexpnum = POLStatMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLSTA5
on ppol.PolicyID = POLSTA5.PolicyID 
and ppol.nexpnum = POLSTA5.NEXPNUM
and POLLOC.NSTANUM=POLSTA5.NSTANUM
and POLLOC.NLOCNUM = POLSTA5.NLOCNUM
and  POLSTA5.Name like 'TwnCde%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCMFL.*
   from
   {rawDB}.BOPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCMFL.PolicyID
              and mb.nexpnum = BOPLOCMFL.nexpnum )) WHERE rn = 1  ) BOPLOC  
on ppol.PolicyID = BOPLOC.PolicyID 
and ppol.nexpnum = BOPLOC.nexpnum 
and POLLOC.NLOCNUM = BOPLOC.NLOCNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,nexpnum,NLOCNUM,name  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCEXTMFL.*
   from
   {rawDB}.BOPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCEXTMFL.PolicyID 
            and mb.nexpnum = BOPLOCEXTMFL.nexpnum  
              )
  ) WHERE rn = 1  )          
   BOPLOCEXT
on ppol.PolicyID = BOPLOCEXT.PolicyID 
and ppol.nexpnum = BOPLOCEXT.nexpnum
and BOPLOC.NLOCNUM = BOPLOCEXT.NLOCNUM
and BOPLOCEXT.Name like 'FirTerCde%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,nexpnum,NLOCNUM,name  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCEXTMFL.*
   from
   {rawDB}.BOPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCEXTMFL.PolicyID 
            and mb.nexpnum = BOPLOCEXTMFL.nexpnum  
              )
  ) WHERE rn = 1  )          
   BOPLOCEXT1
on ppol.PolicyID = BOPLOCEXT1.PolicyID 
and ppol.nexpnum = BOPLOCEXT1.nexpnum
and BOPLOC.NLOCNUM = BOPLOCEXT1.NLOCNUM
and BOPLOCEXT1.Name like 'PrHydrant%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,nexpnum,NLOCNUM,name  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCEXTMFL.*
   from
   {rawDB}.BOPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCEXTMFL.PolicyID 
            and mb.nexpnum = BOPLOCEXTMFL.nexpnum  
              )
  ) WHERE rn = 1  )          
   BOPLOCEXT2
on ppol.PolicyID = BOPLOCEXT2.PolicyID 
and ppol.nexpnum = BOPLOCEXT2.nexpnum
and BOPLOC.NLOCNUM = BOPLOCEXT2.NLOCNUM
and BOPLOCEXT2.Name like 'PrFireDept%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_bp_ds_geo_info")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","GEO_INFO_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("GEO_INFO_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"GEO_INFO_ID","HV-BP") 
    //     queryDF.show(3,false)
}