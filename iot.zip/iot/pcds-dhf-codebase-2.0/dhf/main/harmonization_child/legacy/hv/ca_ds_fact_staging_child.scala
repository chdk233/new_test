// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_fact_staging(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(CAUSTA.nstanum is null, '999', CAUSTA.nstanum)||'-9999-9999-9999-'||IF(CAUCCV.nCOVnum is null, '999', CAUCCV.nCOVnum)||'-'||IF(CAUCCVPRI.NTYPNUM is null, '999', CAUCCVPRI.NTYPNUM)||'-'||IF(CAUCCVPRI.nSEQnum is null, '999', CAUCCVPRI.nSEQnum)||'-'||IF(CAUCCVPRI.LMATCDE is null, 'NULL', rtrim(CAUCCVPRI.LMATCDE))||'-'||IF(CAUCCV.LMATCDE is null, 'NULL', rtrim(CAUCCV.LMATCDE))||'-CAUCCV' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
'CALINE' as CVRBL_TYPE_CD,
ifnull(rtrim(CAUCCVPRI.LMATCDE), ' ') as COVG_CD,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
ifnull(rtrim(CAUCCVPRI.LDES), 'Not Defined') as COVG_TEXT,
CASE WHEN CAUCCVPRI.LMATCDE like '%NONSRV%' THEN (CASE WHEN (trim(CAUCCVPRI.LTERZIP) ='' OR CAUCCVPRI.LTERZIP ='NULL' or CAUCCVPRI.LTERZIP is null) THEN ' ' ELSE  CAUCCVPRI.LTERZIP END )ELSE ' ' END AS GARAGE_TER_ZIP,
CASE WHEN CAUCCVPRI.LMATCDE like '%NONSRV%' THEN (CASE WHEN (trim(CAUCCVPRI.LTERCDE) ='' OR CAUCCVPRI.LTERCDE  ='NULL' or CAUCCVPRI.LTERCDE is null) THEN ' ' ELSE  CAUCCVPRI.LTERCDE  END )  ELSE ' ' END AS GARAGE_TER_CDE,
CASE WHEN CAUCCVPRI.LMATCDE LIKE '%NONSRV%' THEN (CASE WHEN (trim(CAUCCVPRI.LTERCTY)  ='' OR CAUCCVPRI.LTERCTY   ='NULL' or CAUCCVPRI.LTERCTY is null) THEN ' ' ELSE CAUCCVPRI.LTERCTY  END )   ELSE ' ' END AS GARAGE_CTY,
cast(NPRM as double) as TERM_VAL_AMT,
ifnull(rtrim(CAUCCV.LMATCDE), ' ') as COVG_PART_CD,
ifnull(rtrim(CAUCCV.LDES), 'Not Defined') as COVG_PART_TEXT,
cast(NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
case when POLAGT.LAGTNUM is NULL then ' ' else POLAGT.LAGTNUM end AS LAGTNUM,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
0 as NO_STA,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' as MANUSCRIPT_TEMP
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn FROM  (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT6  on ppol.PolicyID = POLEXT6.PolicyID and POLEXT6.nexpnum = 0  and  POLEXT6.Name like 'PolicyPrefix%' left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn  FROM (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT1 on ppol.PolicyID = POLEXT1.PolicyID and ppol.nexpnum = POLEXT1.nexpnum and POLEXT1.Name like '%TctDat%' left outer join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  POLPOLV3XMFL.* from   {rawDB}.POLPOLV3XMFL  inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = POLPOLV3XMFL.PolicyID  and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM  ) ) WHERE rn = 1  ) v3x on ppol.policyid = v3x.policyid and ppol.NEXPNUM = v3x.NEXPNUM left outer Join ( SELECT * FROM  ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn  FROM   (SELECT  CAUPOLMFL.*   from   {rawDB}.CAUPOLMFL   inner join global_temp.polpolmfl_micro_batch mb              on   mb.PolicyID = CAUPOLMFL.PolicyID     ) ) WHERE rn = 1  ) CAUPOL on ppol.PolicyID = CAUPOL.PolicyID and ppol.nexpnum  = CAUPOL.nexpnum left outer Join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn   FROM   (SELECT  CAUSTAMFL.*   from   {rawDB}.CAUSTAMFL   inner join global_temp.polpolmfl_micro_batch mb            on   mb.PolicyID = CAUSTAMFL.PolicyID              )  ) WHERE rn = 1  ) CAUSTA on ppol.PolicyID = CAUSTA.PolicyID and ppol.nexpnum  = CAUSTA.nexpnum and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVPRIMFL.*
   from
   {rawDB}.CAUCCVPRIMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVPRIMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUCCVPRI
on ppol.PolicyID = CAUCCVPRI.PolicyID 
and ppol.nexpnum  = CAUCCVPRI.nexpnum 
and CAUSTA.nstanum = CAUCCVPRI.nstanum
and CAUSTA.NPOLPED= CAUCCVPRI.NPOLPED
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVMFL.*
   from
   {rawDB}.CAUCCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUCCV
on ppol.PolicyID = CAUCCV.PolicyID 
and ppol.nexpnum  = CAUCCV.nexpnum 
and CAUCCVPRI.nstanum = CAUCCV.nstanum
and CAUCCVPRI.NPOLPED = CAUCCV.NPOLPED
and CAUCCVPRI.NTYPNUM = CAUCCV.NTYPNUM
and CAUCCVPRI.NSEQNUM = CAUCCV.NSEQNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   POLAGT
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(CAUSTA.nstanum is null, '999', CAUSTA.nstanum)||'-'||IF(CAUVEH.NVEHNUM is null, '999', CAUVEH.NVEHNUM)||'-'||IF(CAUVEHCOV.nCOVnum is null, '999', CAUVEHCOV.nCOVnum)||'-9999-9999-'||IF(CAUVEHCOV.LMATCDE is null, 'NULL', rtrim(CAUVEHCOV.LMATCDE))||'-9999-VEHCOV' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
'CALINE' as CVRBL_TYPE_CD,
ifnull(rtrim(CAUVEHCOV.LMATCDE), ' ') as COVG_CD,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
ifnull(rtrim(CAUVEHCOV.LCOVDES), 'Not Defined') as COVG_TEXT,
CASE WHEN CAUVEH.LTERZIP IS NULL OR trim(CAUVEH.LTERZIP)= '' THEN ' ' ELSE CAUVEH.LTERZIP END AS GARAGE_TER_ZIP,
CASE WHEN CAUVEH.LTER IS NULL OR trim(CAUVEH.LTER)= '' THEN ' ' ELSE CAUVEH.LTER END AS GARAGE_TER_CDE,
CASE WHEN CAUVEH.LGARCTY IS NULL OR trim(CAUVEH.LGARCTY)= '' THEN ' ' ELSE CAUVEH.LGARCTY END AS GARAGE_CTY,
cast(NPRM as double) as TERM_VAL_AMT,
' ' as COVG_PART_CD,
'Not Defined' as COVG_PART_TEXT,
cast(NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
case when POLAGT.LAGTNUM is NULL then ' ' else POLAGT.LAGTNUM end AS LAGTNUM,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
0 as NO_STA,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' as MANUSCRIPT_TEMP
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn FROM  (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT6  on ppol.PolicyID = POLEXT6.PolicyID and POLEXT6.nexpnum = 0  and  POLEXT6.Name like 'PolicyPrefix%' left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn  FROM (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT1 on ppol.PolicyID = POLEXT1.PolicyID and ppol.nexpnum = POLEXT1.nexpnum and POLEXT1.Name like '%TctDat%' left outer join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  POLPOLV3XMFL.* from   {rawDB}.POLPOLV3XMFL  inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = POLPOLV3XMFL.PolicyID  and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM  ) ) WHERE rn = 1  ) v3x on ppol.policyid = v3x.policyid and ppol.NEXPNUM = v3x.NEXPNUM left outer Join ( SELECT * FROM  ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn  FROM   (SELECT  CAUPOLMFL.*   from   {rawDB}.CAUPOLMFL   inner join global_temp.polpolmfl_micro_batch mb              on   mb.PolicyID = CAUPOLMFL.PolicyID     ) ) WHERE rn = 1  ) CAUPOL on ppol.PolicyID = CAUPOL.PolicyID and ppol.nexpnum  = CAUPOL.nexpnum left outer Join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn   FROM   (SELECT  CAUSTAMFL.*   from   {rawDB}.CAUSTAMFL   inner join global_temp.polpolmfl_micro_batch mb            on   mb.PolicyID = CAUSTAMFL.PolicyID              )  ) WHERE rn = 1  ) CAUSTA on ppol.PolicyID = CAUSTA.PolicyID and ppol.nexpnum  = CAUSTA.nexpnum and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NVEHNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUVEHMFL.*
   from
   {rawDB}.CAUVEHMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUVEHMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUVEH
on ppol.policyid = CAUVEH.policyid 
and ppol.NEXPNUM = CAUVEH.NEXPNUM
and CAUSTA.NSTANUM=CAUVEH.NSTANUM
and CAUSTA.NPOLPED=CAUVEH.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NVEHNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUVEHCOVMFL.*
   from
   {rawDB}.CAUVEHCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUVEHCOVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUVEHCOV
on ppol.policyid = CAUVEHCOV.policyid 
and ppol.NEXPNUM = CAUVEHCOV.NEXPNUM
and CAUVEHCOV.NSTANUM=CAUSTA.NSTANUM
and CAUVEHCOV.NPOLPED=CAUPOL.NPOLPED
and CAUVEHCOV.NVEHNUM=CAUVEH.NVEHNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   POLAGT
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(CAUSTA.nstanum is null, '999', CAUSTA.nstanum)||'-'||IF(CAUGARLOC.NLOCNUM is null, '999', CAUGARLOC.NLOCNUM)||'-9999-9999-'||IF(CAUGARCOV.nCOVnum is null, '999', CAUGARCOV.nCOVnum)||'-'||IF(CAUGARCOVPRI.NTYPNUM is null, '999', CAUGARCOVPRI.NTYPNUM)||'-'||IF(CAUGARCOVPRI.NSEQNUM is null, '999', CAUGARCOVPRI.NSEQNUM)||'-'||IF(CAUGARCOVPRI.LMATCDE is null, 'NULL', rtrim(CAUGARCOVPRI.LMATCDE))||'-'||IF(CAUGARCOV.LMATCDE is null, 'NULL', rtrim(CAUGARCOV.LMATCDE))||'-GARCOV' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
'CALINE' as CVRBL_TYPE_CD,
ifnull(rtrim(CAUGARCOVPRI.LMATCDE), ' ') as COVG_CD,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
ifnull(rtrim(CAUGARCOVPRI.LCOVDES), 'Not Defined') as COVG_TEXT,
' ' AS GARAGE_TER_ZIP,
' ' AS GARAGE_TER_CDE,
' ' AS GARAGE_CTY,
cast(NPRM as double) as TERM_VAL_AMT,
ifnull(rtrim(CAUGARCOV.LMATCDE), ' ') as COVG_PART_CD,
ifnull(rtrim(CAUGARCOV.LCOVDES), 'Not Defined') as COVG_PART_TEXT,
cast(NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
case when POLAGT.LAGTNUM is NULL then ' ' else POLAGT.LAGTNUM end AS LAGTNUM,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
0 as NO_STA,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' as MANUSCRIPT_TEMP
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn FROM  (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT6  on ppol.PolicyID = POLEXT6.PolicyID and POLEXT6.nexpnum = 0  and  POLEXT6.Name like 'PolicyPrefix%' left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn  FROM (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT1 on ppol.PolicyID = POLEXT1.PolicyID and ppol.nexpnum = POLEXT1.nexpnum and POLEXT1.Name like '%TctDat%' left outer join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  POLPOLV3XMFL.* from   {rawDB}.POLPOLV3XMFL  inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = POLPOLV3XMFL.PolicyID  and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM  ) ) WHERE rn = 1  ) v3x on ppol.policyid = v3x.policyid and ppol.NEXPNUM = v3x.NEXPNUM left outer Join ( SELECT * FROM  ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn  FROM   (SELECT  CAUPOLMFL.*   from   {rawDB}.CAUPOLMFL   inner join global_temp.polpolmfl_micro_batch mb              on   mb.PolicyID = CAUPOLMFL.PolicyID     ) ) WHERE rn = 1  ) CAUPOL on ppol.PolicyID = CAUPOL.PolicyID and ppol.nexpnum  = CAUPOL.nexpnum left outer Join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn   FROM   (SELECT  CAUSTAMFL.*   from   {rawDB}.CAUSTAMFL   inner join global_temp.polpolmfl_micro_batch mb            on   mb.PolicyID = CAUSTAMFL.PolicyID              )  ) WHERE rn = 1  ) CAUSTA on ppol.PolicyID = CAUSTA.PolicyID and ppol.nexpnum  = CAUSTA.nexpnum and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARLOCMFL.*
   from
   {rawDB}.CAUGARLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARLOCMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARLOC
on ppol.policyid = CAUGARLOC.policyid 
and ppol.NEXPNUM = CAUGARLOC.NEXPNUM
and CAUSTA.NSTANUM=CAUGARLOC.NSTANUM
and CAUPOL.NPOLPED=CAUGARLOC.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARCOVPRIMFL.*
   from
   {rawDB}.CAUGARCOVPRIMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARCOVPRIMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARCOVPRI
on ppol.policyid = CAUGARCOVPRI .policyid 
and ppol.NEXPNUM = CAUGARCOVPRI .NEXPNUM
and CAUGARCOVPRI.NSTANUM=CAUSTA.NSTANUM
and CAUGARCOVPRI.NPOLPED=CAUPOL.NPOLPED
and CAUGARCOVPRI.NLOCNUM=CAUGARLOC.NLOCNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NTYPNUM,NSEQNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARCOVMFL.*
   from
   {rawDB}.CAUGARCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARCOVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARCOV
on ppol.policyid = CAUGARCOV .policyid 
and ppol.NEXPNUM = CAUGARCOV .NEXPNUM
and CAUSTA.NSTANUM=CAUGARCOV.NSTANUM
and CAUPOL.NPOLPED=CAUGARCOV.NPOLPED
and CAUGARLOC.NLOCNUM=CAUGARCOV.NLOCNUM
and CAUGARCOVPRI.NTYPNUM=CAUGARCOV.NTYPNUM
and CAUGARCOVPRI.NSEQNUM= CAUGARCOV.NSEQNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   POLAGT
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(CAUSTA.nstanum is null, '999', CAUSTA.nstanum)||'-9999-9999-9999-9999-'||IF(CAUGARCCV.NTYPNUM is null, '999', CAUGARCCV.NTYPNUM)||'-'||IF(CAUGARCCV.NSEQNUM is null, '999', CAUGARCCV.NSEQNUM)||'-'||IF(CAUGARCCV.LMATCDE is null, 'NULL', rtrim(CAUGARCCV.LMATCDE))||'-9999-GARCCV' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
'CALINE' as CVRBL_TYPE_CD,
ifnull(rtrim(CAUGARCCV.LMATCDE), ' ') as COVG_CD,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
ifnull(rtrim(CAUGARCCV.LDES), 'Not Defined') as COVG_TEXT,
' ' AS GARAGE_TER_ZIP,
' ' AS GARAGE_TER_CDE,
' ' AS GARAGE_CTY,
cast(NPRM as double) as TERM_VAL_AMT,
' ' as COVG_PART_CD,
'Not Defined' as COVG_PART_TEXT,
cast(NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
case when POLAGT.LAGTNUM is NULL then ' ' else POLAGT.LAGTNUM end AS LAGTNUM,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
0 as NO_STA,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' as MANUSCRIPT_TEMP
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn FROM  (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT6  on ppol.PolicyID = POLEXT6.PolicyID and POLEXT6.nexpnum = 0  and  POLEXT6.Name like 'PolicyPrefix%' left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn  FROM (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT1 on ppol.PolicyID = POLEXT1.PolicyID and ppol.nexpnum = POLEXT1.nexpnum and POLEXT1.Name like '%TctDat%' left outer join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  POLPOLV3XMFL.* from   {rawDB}.POLPOLV3XMFL  inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = POLPOLV3XMFL.PolicyID  and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM  ) ) WHERE rn = 1  ) v3x on ppol.policyid = v3x.policyid and ppol.NEXPNUM = v3x.NEXPNUM left outer Join ( SELECT * FROM  ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn  FROM   (SELECT  CAUPOLMFL.*   from   {rawDB}.CAUPOLMFL   inner join global_temp.polpolmfl_micro_batch mb              on   mb.PolicyID = CAUPOLMFL.PolicyID     ) ) WHERE rn = 1  ) CAUPOL on ppol.PolicyID = CAUPOL.PolicyID and ppol.nexpnum  = CAUPOL.nexpnum left outer Join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn   FROM   (SELECT  CAUSTAMFL.*   from   {rawDB}.CAUSTAMFL   inner join global_temp.polpolmfl_micro_batch mb            on   mb.PolicyID = CAUSTAMFL.PolicyID              )  ) WHERE rn = 1  ) CAUSTA on ppol.PolicyID = CAUSTA.PolicyID and ppol.nexpnum  = CAUSTA.nexpnum and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARCCVMFL.*
   from
   {rawDB}.CAUGARCCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARCCVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARCCV
on ppol.policyid = CAUGARCCV .policyid 
and ppol.NEXPNUM = CAUGARCCV .NEXPNUM
and CAUSTA.NSTANUM=CAUGARCCV.NSTANUM
and CAUPOL.NPOLPED=CAUGARCCV.NPOLPED
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   POLAGT
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(CAUSTA.nstanum is null, '999', CAUSTA.nstanum)||'-'||IF(SPCCOV.nlocnum is null, '999', SPCCOV.nlocnum)||'-'||IF(SPCCOV.NBLDNUM is null, '999', SPCCOV.NBLDNUM)||'-'||IF(SPCCOV.nSEQnum is null, '999', SPCCOV.nSEQnum)||'-'||IF(SPCCOV1.nSEQnum is null, '999', SPCCOV1.nSEQnum)||'-'||IF(SPCCOV.LCOVTYPCDE is null, 'NULL', SPCCOV.LCOVTYPCDE)||'-'||IF(SPCCOV.LSUBCOVCDE is null, 'NULL', SPCCOV.LSUBCOVCDE)||'-'||IF(SPCCOV1.LSUBCOVCDE is null, 'NULL', SPCCOV1.LSUBCOVCDE)||'-SPC' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
'CALINE' as CVRBL_TYPE_CD,
ifnull(rtrim(SPCCOV.LCOVTYPCDE), ' ') as COVG_CD,
' ' as COVG_TERM_CD,
'Not Defined' as COVG_TERM_TEXT,
ifnull(rtrim(SPCCOV.LCOVTYPDES), 'Not Defined') as COVG_TEXT,
CASE WHEN (SPCCOVEXT2.STRINGVALUE IS NULL OR trim(SPCCOVEXT2.STRINGVALUE) ='') THEN ' ' ELSE SPCCOVEXT2.STRINGVALUE END AS GARAGE_TER_ZIP,
CASE WHEN (SPCCOVEXT1.STRINGVALUE IS NULL OR trim(SPCCOVEXT1.STRINGVALUE) ='') THEN ' ' ELSE SPCCOVEXT1.STRINGVALUE END  AS GARAGE_TER_CDE,
CASE WHEN (SPCCOVEXT3.STRINGVALUE IS NULL OR trim(SPCCOVEXT3.STRINGVALUE) ='') THEN ' ' ELSE SPCCOVEXT3.STRINGVALUE END AS GARAGE_CTY,
cast(SPCCOV.NPRM as double) as TERM_VAL_AMT,
ifnull(rtrim(SPCCOV.LSUBCOVCDE), ' ') as COVG_PART_CD,
ifnull(rtrim(SPCCOV.LSUBCOVDES), 'Not Defined') as COVG_PART_TEXT,
cast(SPCCOV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
case when POLAGT.LAGTNUM is NULL then ' ' else POLAGT.LAGTNUM end AS LAGTNUM,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
ifnull(cast(SPCCOV.NSTANUM as double), 0) as NO_STA,
ifnull(cast(SPCCOV.NLOCNUM as double), 0) as NO_LOC,
ifnull(cast(SPCCOV.NBLDNUM as double), 0) as NO_BLD,
CASE WHEN SPCCOV.LSUBCOVCDE IN ('END','EXC') THEN concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when SPCCOV.NSTANUM is null then '999' else SPCCOV.NSTANUM end),'-')
,case when SPCCOV.NLOCNUM is null then '999' else SPCCOV.NLOCNUM end),'-')
,case when SPCCOV.NBLDNUM is null then '999' else SPCCOV.NBLDNUM end),'-')
,case when SPCCOV.NSEQNUM is null then '999' else SPCCOV.NSEQNUM end),'-')
,case when SPCCOV1.NSEQNUM is null then '999' else SPCCOV1.NSEQNUM end),'-')
,case when SPCCOV.LCOVTYPCDE is null then 'NULL' else SPCCOV.LCOVTYPCDE end),'-')
,case when SPCCOV.LSUBCOVCDE is null then 'NULL' ELSE SPCCOV.LSUBCOVCDE end),'-')
,CASE WHEN SPCCOV1.LSUBCOVCDE is null then 'NULL' ELSE SPCCOV1.LSUBCOVCDE end)
ELSE 'NOKEY' END as MANUSCRIPT_TEMP
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn FROM  (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT6  on ppol.PolicyID = POLEXT6.PolicyID and POLEXT6.nexpnum = 0  and  POLEXT6.Name like 'PolicyPrefix%' left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn  FROM (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT1 on ppol.PolicyID = POLEXT1.PolicyID and ppol.nexpnum = POLEXT1.nexpnum and POLEXT1.Name like '%TctDat%' left outer join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  POLPOLV3XMFL.* from   {rawDB}.POLPOLV3XMFL  inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = POLPOLV3XMFL.PolicyID  and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM  ) ) WHERE rn = 1  ) v3x on ppol.policyid = v3x.policyid and ppol.NEXPNUM = v3x.NEXPNUM left outer Join ( SELECT * FROM  ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn  FROM   (SELECT  CAUPOLMFL.*   from   {rawDB}.CAUPOLMFL   inner join global_temp.polpolmfl_micro_batch mb              on   mb.PolicyID = CAUPOLMFL.PolicyID     ) ) WHERE rn = 1  ) CAUPOL on ppol.PolicyID = CAUPOL.PolicyID and ppol.nexpnum  = CAUPOL.nexpnum left outer Join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn   FROM   (SELECT  CAUSTAMFL.*   from   {rawDB}.CAUSTAMFL   inner join global_temp.polpolmfl_micro_batch mb            on   mb.PolicyID = CAUSTAMFL.PolicyID              )  ) WHERE rn = 1  ) CAUSTA on ppol.PolicyID = CAUSTA.PolicyID and ppol.nexpnum  = CAUSTA.nexpnum and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOV
on ppol.policyid = SPCCOV.policyid
and ppol.nexpnum = SPCCOV.nexpnum
and SPCCOV.NSTANUM = CAUSTA.NSTANUM
and trim(SPCCOV.llob) = 'CAU'
and SPCCOV.LCOVTYPCDE IS NOT NULL
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   SPCCOVEXT1
ON SPCCOVEXT1.POLICYID = PPOL.POLICYID
and SPCCOVEXT1.NEXPNUM=ppol.NEXPNUM
and SPCCOVEXT1.NSTANUM= SPCCOV.NSTANUM
and SPCCOVEXT1.NLOCNUM= SPCCOV.NLOCNUM
and SPCCOVEXT1.NBLDNUM= SPCCOV.NBLDNUM
and trim(SPCCOVEXT1.LLOB) = trim(SPCCOV.LLOB)
and SPCCOVEXT1.LCOVTYPCDE= SPCCOV.LCOVTYPCDE
and SPCCOVEXT1.LSUBCOVCDE= SPCCOV.LSUBCOVCDE
and SPCCOVEXT1.NSEQNUM= SPCCOV.NSEQNUM
AND trim(SPCCOVEXT1.NAME) = 'TerCde'
AND upper(SPCCOV.LCOVTYPDES) LIKE '%CA-9937 - GARAGEKEEPERS%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   SPCCOVEXT2
ON SPCCOVEXT2.POLICYID = PPOL.POLICYID
and SPCCOVEXT2.NEXPNUM=ppol.NEXPNUM
and SPCCOVEXT2.NSTANUM= SPCCOV.NSTANUM
and SPCCOVEXT2.NLOCNUM= SPCCOV.NLOCNUM
and SPCCOVEXT2.NBLDNUM= SPCCOV.NBLDNUM
and trim(SPCCOVEXT2.LLOB) = trim(SPCCOV.LLOB)
and SPCCOVEXT2.LCOVTYPCDE= SPCCOV.LCOVTYPCDE
and SPCCOVEXT2.LSUBCOVCDE= SPCCOV.LSUBCOVCDE
and SPCCOVEXT2.NSEQNUM= SPCCOV.NSEQNUM
AND trim(SPCCOVEXT2.NAME) = 'TerZip'
AND upper(SPCCOV.LCOVTYPDES) LIKE '%CA-9937 - GARAGEKEEPERS%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   SPCCOVEXT3
ON SPCCOVEXT3.POLICYID = PPOL.POLICYID
and SPCCOVEXT3.NEXPNUM=ppol.NEXPNUM
and SPCCOVEXT3.NSTANUM= SPCCOV.NSTANUM
and SPCCOVEXT3.NLOCNUM= SPCCOV.NLOCNUM
and SPCCOVEXT3.NBLDNUM= SPCCOV.NBLDNUM
and trim(SPCCOVEXT3.LLOB) = trim(SPCCOV.LLOB)
and SPCCOVEXT3.LCOVTYPCDE= SPCCOV.LCOVTYPCDE
and SPCCOVEXT3.LSUBCOVCDE= SPCCOV.LSUBCOVCDE
and SPCCOVEXT3.NSEQNUM= SPCCOV.NSEQNUM
AND trim(SPCCOVEXT3.NAME) = 'TerCty'
AND upper(SPCCOV.LCOVTYPDES) LIKE '%CA-9937 - GARAGEKEEPERS%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOV1
on SPCCOV.PolicyID = SPCCOV1.PolicyID 
and SPCCOV.nexpnum = SPCCOV1.nexpnum  
and SPCCOV.NSTANUM= SPCCOV1.NSTANUM
and SPCCOV.NLOCNUM= SPCCOV1.NLOCNUM
and SPCCOV.NBLDNUM= SPCCOV1.NBLDNUM
and trim(SPCCOV1.LLOB) = 'CAU'
and trim(SPCCOV1.LSUBCOVCDE) IN( 'MNR' ,'FLT')
and upper(SPCCOV1.LCOVTYPDES) like '%MANUAL%'
and upper(SPCCOV.LCOVTYPDES) like '%MANUSCRIPT ENDORSEMENT%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   POLAGT
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(tax.nstanum is null, '999', tax.nstanum)||'-9999-9999-9999-9999-9999-9999-9999-'||IF(tax.NKEY1 is null or trim(tax.NKEY1) = '', '999', tax.NKEY1)||'-'||IF(tax.NKEY2 is null or trim(tax.NKEY2) = '', '999', tax.NKEY2)||'-'||IF(tax.NKEY3 is null or trim(tax.NKEY3) = '', '999', tax.NKEY3)||'-'||IF(tax.NKEY4 is null or trim(tax.NKEY4) = '', '999', tax.NKEY4)||'-'||IF(tax.NKEY5 is null or trim(tax.NKEY5) = '', '999', tax.NKEY5)||'-'||IF(tax.NKEY6 is null or trim(tax.NKEY6) = '', '999', tax.NKEY6)||'-SURCHARGE' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
' ' as CVRBL_TYPE_CD,
' ' as COVG_CD,
ifnull(rtrim(tax.LDES), ' ') as COVG_TERM_CD,
ifnull(rtrim(tax.ldes), 'Not Defined') as COVG_TERM_TEXT,
'Not Defined' as COVG_TEXT,
' '  AS GARAGE_TER_ZIP,
' '  AS GARAGE_TER_CDE,
' ' AS GARAGE_CTY,
cast(tax.NPRM as double) as TERM_VAL_AMT,
' ' as COVG_PART_CD,
'Not Defined' as COVG_PART_TEXT,
cast(tax.NPRMANN as double) as TEMP_ANNUAL_PREM_AMT,
case when POLAGT.LAGTNUM is NULL then ' ' else POLAGT.LAGTNUM end AS LAGTNUM,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
0 as NO_STA,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' as MANUSCRIPT_TEMP
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn FROM  (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT6  on ppol.PolicyID = POLEXT6.PolicyID and POLEXT6.nexpnum = 0  and  POLEXT6.Name like 'PolicyPrefix%' left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn  FROM (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT1 on ppol.PolicyID = POLEXT1.PolicyID and ppol.nexpnum = POLEXT1.nexpnum and POLEXT1.Name like '%TctDat%' left outer join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  POLPOLV3XMFL.* from   {rawDB}.POLPOLV3XMFL  inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = POLPOLV3XMFL.PolicyID  and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM  ) ) WHERE rn = 1  ) v3x on ppol.policyid = v3x.policyid and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LLOB,NSTANUM,NKEY1,NKEY2,NKEY3,NKEY4,NKEY5,NKEY6 ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLTAXMFL.*
   from
   {rawDB}.POLTAXMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLTAXMFL.PolicyID
                   and 	mb.NEXPNUM=POLTAXMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) tax
on ppol.policyid = tax.policyid
and ppol.nexpnum = tax.nexpnum
and trim(tax.LLOB) = 'CAU'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   POLAGT
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-9999-9999-9999-9999-9999-9999-9999-9999-'||IF(POLPRM.LMATCDE is null, 'NULL', POLPRM.LMATCDE)||'-BAL_MIN' AS FACT_STAGE_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CA' AS PARTITION_VAL,
'CA' as  LOB_CD,
' ' as CVRBL_TYPE_CD,
' ' as COVG_CD,
' ' as COVG_TERM_CD,
ifnull(rtrim(POLPRM.ldes), 'Not Defined') as COVG_TERM_TEXT,
'Not Defined' as COVG_TEXT,
' '  AS GARAGE_TER_ZIP,
' '  AS GARAGE_TER_CDE,
' ' AS GARAGE_CTY,
cast(POLPRM.NPRM as double) as TERM_VAL_AMT,
' ' as COVG_PART_CD,
'Not Defined' as COVG_PART_TEXT,
cast(POLPRM.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
case when POLAGT.LAGTNUM is NULL then ' ' else POLAGT.LAGTNUM end AS LAGTNUM,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
0 as NO_STA,
0 as NO_LOC,
0 as NO_BLD,
'NOKEY' as MANUSCRIPT_TEMP
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn FROM  (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT6  on ppol.PolicyID = POLEXT6.PolicyID and POLEXT6.nexpnum = 0  and  POLEXT6.Name like 'PolicyPrefix%' left outer Join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn  FROM (SELECT  POLPOLEXTMFL.* from {rawDB}.POLPOLEXTMFL inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = POLPOLEXTMFL.PolicyID ) ) WHERE rn = 1  ) POLEXT1 on ppol.PolicyID = POLEXT1.PolicyID and ppol.nexpnum = POLEXT1.nexpnum and POLEXT1.Name like '%TctDat%' left outer join ( SELECT * FROM   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  POLPOLV3XMFL.* from   {rawDB}.POLPOLV3XMFL  inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = POLPOLV3XMFL.PolicyID  and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM  ) ) WHERE rn = 1  ) v3x on ppol.policyid = v3x.policyid and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LLOB,LMATCDE,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPRMMFL.*
   from
   {rawDB}.POLPRMMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPRMMFL.PolicyID
                   and 	mb.NEXPNUM=POLPRMMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) POLPRM
on ppol.PolicyID = POLPRM.PolicyID 
and ppol.nexpnum  = POLPRM.nexpnum  
and upper(POLPRM.LDES) like '%BALANCE%' 
AND trim(POLPRM.LLOB) = 'CAU'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   POLAGT
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM
"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_fact_staging")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","FACT_STAGE_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("FACT_STAGE_KEY","END_EFF_DT"),harmonized_table,"FACT_STAGE_ID","HV-CA") 
}