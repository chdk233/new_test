// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
select  distinct
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',trim(POLEXT6.StringValue)),'-'),trim(PRPCOV.LCOVTYP)),'-'),trim(PRPCOV.LMATCDE)),'-'),trim(PRPCOV.LCOVDES)),'-') ,trim(PRPPRL.NPRLNUM)),'-'),TRIM(PRPPRL.LDES))
as COVG_KEY
,'CP' as LOB_CD 
,'HV' as SOURCE_SYSTEM 
,'HV-CP' as PARTITION_VAL
,concat(PRPCOV.LMATCDE,'-',PRPPRL.NPRLNUM) as COVG_PART_CD
,case when trim(PRPPRL.LDES) = '' then 'Not Defined' else PRPPRL.LDES end as COVG_PART_TEXT 
, PRPCOV.LCOVTYP as COVG_CD
, PRPCOV.LCOVDES as COVG_TEXT
,to_timestamp('1900-01-01 00:00:00.000000') as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

INNER Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPCOVMFL.*
   from
   {rawDB}.PRPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPCOVMFL.PolicyID 
              and mb.nexpnum = PRPCOVMFL.nexpnum )
  ) WHERE rn = 1  ) PRPCOV   
on ppol.policyid = PRPCOV.policyid
and ppol.nexpnum = PRPcov.nexpnum

inner Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM,NPRLNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPPRLMFL.*
   from
   {rawDB}.PRPPRLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPPRLMFL.PolicyID 
              and mb.nexpnum = PRPPRLMFL.nexpnum )
  ) WHERE rn = 1  )  PRPPRL 
on ppol.policyid =  PRPPRL.policyid 
and ppol.NEXPNUM =  PRPPRL.NEXPNUM
and PRPPRL.NSTANUM = PRPCOV.NSTANUM
and PRPPRL.NLOCNUM = PRPCOV.NLOCNUM
and PRPPRL.NBLDNUM = PRPCOV.NBLDNUM
and PRPPRL.NOCCNUM = PRPCOV.NOCCNUM
and PRPPRL.NCOVNUM = PRPCOV.NCOVNUM
and PRPPRL.NSUBCOVNUM = PRPCOV.NSUBCOVNUM


Union ALL

select  distinct
concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',trim(POLEXT6.StringValue)),'-'),trim(SPCCOV.LCOVTYPCDE)),'-'),trim(SPCCOV.LCOVTYPDES)),'-'),trim(SPCCOV.LSUBCOVCDE)),'-'),case when trim(SPCCOV.LSUBCOVDES) = '' then 'NULL' else trim(SPCCOV.LSUBCOVDES) end)
as COVG_KEY
,'CP' as LOB_CD 
,'HV' as SOURCE_SYSTEM 
,'HV-CP' as PARTITION_VAL 
 ,SPCCOV.LSUBCOVCDE as COVG_PART_CD
 ,case when trim(SPCCOV.LSUBCOVDES) = '' then 'Not Defined' else SPCCOV.LSUBCOVDES end as COVG_PART_TEXT 
 , SPCCOV.LCOVTYPCDE as COVG_CD
, SPCCOV.LCOVTYPDES as COVG_TEXT 
,to_timestamp('1900-01-01 00:00:00.000000') as ETL_ROW_EFF_DTS
 
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  )POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

inner join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID 
              and mb.nexpnum = SPCCOVMFL.nexpnum )
  ) WHERE rn = 1  )  SPCCOV  
on ppol.policyid = SPCCOV.policyid
and ppol.nexpnum = SPCCOV.nexpnum
and  llob = 'PRP' -- CP
and SPCCOV.LCOVTYPCDE IS NOT NULL

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cp_ds_covg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","COVG_ID")
  
    mergeAndWrite(hashDF,List("COVG_KEY","ETL_ROW_EFF_DTS"), harmonized_table,"COVG_ID","HV-CP")
 
}