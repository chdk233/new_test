// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_spoil_dfncy(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 


Select 
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
 as SPOIL_DFNCY_KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'COP' as LOB_CD
,'HV' as SOURCE_SYSTEM
,BOPDFP.Dfp as ADDL_LOSS_INCOME
,POLATTA1.AttachmentText as ADDL_LOSS_INCOME_NOTE
,BOPDFP2.Dfp as COV_OBJ_COND
,POLATTA2.AttachmentText as COV_OBJ_COND_NOTE
,BOPDFP3.Dfp as DED_AMT
,POLATTA3.AttachmentText as DED_AMT_NOTE
,BOPDFP4.Dfp as DISASTER_EXPSR
,POLATTA4.AttachmentText as DISASTER_EXPSR_NOTE
,BOPDFP7.Dfp as INC_EXPSR_COVG
,POLATTA7.AttachmentText as INC_EXPSR_COVG_NOTE
,BOPDFP8.Dfp as JURS_INSP
,POLATTA8.AttachmentText as JURS_INSP_NOTE
,BOPDFP9.Dfp as COV_OBJ_MAINT
,POLATTA9.AttachmentText as COV_OBJ_MAINT_NOTE
,BOPDFP10.Dfp as SPEC_INS_ARNGMT
,POLATTA10.AttachmentText as SPEC_INS_ARNGMT_NOTE
,BOPCV.NANNPRM as SPOIL_PREM
,BOPRCF.NFAC as SPOIL_RATE
,BOPDfpCoverage.DfpFactor as SPOIL_DFNCY_POINT_CHRG
,BOPDfpCoverage.DfpCharacteristicTot as TOT_DFNCY_PTS
,BOPDFP5.Dfp as COV_OBJ_TYPE
,POLATTA5.AttachmentText as COV_OBJ_TYPE_NOTE
,POLATTA6.AttachmentText as UW_NOTE
,'HV-COP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            

              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            

              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            

              )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
)) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  )    POLATTA1  
on ppol.PolicyID = POLATTA1.PolicyID 
and ppol.nexpnum = POLATTA1.nexpnum
and POLATTA1.AQSObjectName ='BOPDfpCharc_Spo_Dfp_LosInc'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  ) POLATTA2  
on ppol.PolicyID = POLATTA2.PolicyID 
and ppol.nexpnum = POLATTA2.nexpnum
and POLATTA2.AQSObjectName ='BOPDfpCharc_Spo_Dfp_CndObj'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  )  POLATTA3  
on ppol.PolicyID = POLATTA3.PolicyID 
and ppol.nexpnum = POLATTA3.nexpnum
and POLATTA3.AQSObjectName ='BOPDfpCharc_Spo_Dfp_DepAmt'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  ) POLATTA4  
on ppol.PolicyID = POLATTA4.PolicyID 
and ppol.nexpnum = POLATTA4.nexpnum
and POLATTA4.AQSObjectName ='BOPDfpCharc_Spo_Dfp_DisExp'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  )  POLATTA5  
on ppol.PolicyID = POLATTA5.PolicyID 
and ppol.nexpnum = POLATTA5.nexpnum
and POLATTA5.AQSObjectName ='BOPDfpCharc_Spo_Dfp_TypObj'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  )  POLATTA6  
on ppol.PolicyID = POLATTA6.PolicyID 
and ppol.nexpnum = POLATTA6.nexpnum
and POLATTA6.AQSObjectName ='BOPPOLEXT_SpoUwxNot_DoubleValue'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  )  POLATTA7  
on ppol.PolicyID = POLATTA7.PolicyID 
and ppol.nexpnum = POLATTA7.nexpnum
and ppol.nexpyrsrec = POLATTA7.nexpyrsrec
and POLATTA7.AQSObjectName ='BOPDfpCharc_Spo_Dfp_XpsEnh'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  )  POLATTA8  
on ppol.PolicyID = POLATTA8.PolicyID 
and ppol.nexpnum = POLATTA8.nexpnum
and POLATTA8.AQSObjectName ='BOPDfpCharc_Spo_Dfp_JurIsp'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  ) POLATTA9  
on ppol.PolicyID = POLATTA9.PolicyID 
and ppol.nexpnum = POLATTA9.nexpnum
and POLATTA9.AQSObjectName ='BOPDfpCharc_Spo_Dfp_MtnObj'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,PolicyRowID ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PolicyAttachmentsMFL.*
   from
   {rawDB}.PolicyAttachmentsMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolicyAttachmentsMFL.PolicyID
              and mb.nexpnum = PolicyAttachmentsMFL.nexpnum
)) WHERE rn = 1  )  POLATTA10  
on ppol.PolicyID = POLATTA10.PolicyID 
and ppol.nexpnum = POLATTA10.nexpnum
and POLATTA10.AQSObjectName ='BOPDfpCharc_Spo_Dfp_SpcArn'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  )  BOPDFP  
on ppol.PolicyID = BOPDFP.PolicyID 
and ppol.nexpnum = BOPDFP.nexpnum
and BOPDFP.CoverageName ='Spo'
and BOPDFP.CharacteristicName= 'LosInc'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP2  
on ppol.PolicyID = BOPDFP2.PolicyID 
and ppol.nexpnum = BOPDFP2.nexpnum
and BOPDFP2.CoverageName ='Spo'
and BOPDFP2.CharacteristicName= 'CndObj'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP3  
on ppol.PolicyID = BOPDFP3.PolicyID 
and ppol.nexpnum = BOPDFP3.nexpnum
and BOPDFP3.CoverageName ='Spo'
and BOPDFP3.CharacteristicName= 'DepAmt'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP4  
on ppol.PolicyID = BOPDFP4.PolicyID 
and ppol.nexpnum = BOPDFP4.nexpnum
and BOPDFP4.CoverageName ='Spo'
and BOPDFP4.CharacteristicName= 'DisExp'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP5   
on ppol.PolicyID = BOPDFP5.PolicyID 
and ppol.nexpnum = BOPDFP5.nexpnum
and BOPDFP5.CoverageName ='Spo'
and BOPDFP5.CharacteristicName= 'TypObj'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP7  
on ppol.PolicyID = BOPDFP7.PolicyID 
and ppol.nexpnum = BOPDFP7.nexpnum
and BOPDFP7.CoverageName ='Spo'
and BOPDFP7.CharacteristicName= 'XpsEnh'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP8  
on ppol.PolicyID = BOPDFP8.PolicyID 
and ppol.nexpnum = BOPDFP8.nexpnum
and BOPDFP8.CoverageName ='Spo'
and BOPDFP8.CharacteristicName= 'JurIsp'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP9  
on ppol.PolicyID = BOPDFP9.PolicyID 
and ppol.nexpnum = BOPDFP9.nexpnum
and BOPDFP9.CoverageName ='Spo'
and BOPDFP9.CharacteristicName= 'MtnObj'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName,CharacteristicName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCharcMFL.*
   from
   {rawDB}.BOPDfpCharcMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCharcMFL.PolicyID
              and mb.nexpnum = BOPDfpCharcMFL.nexpnum
)) WHERE rn = 1  ) BOPDFP10  
on ppol.PolicyID = BOPDFP10.PolicyID 
and ppol.nexpnum = BOPDFP10.nexpnum
and BOPDFP10.CoverageName ='Spo'
and BOPDFP10.CharacteristicName= 'SpcArn'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,CoverageName ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPDfpCoverageMFL.*
   from
   {rawDB}.BOPDfpCoverageMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPDfpCoverageMFL.PolicyID
              and mb.nexpnum = BOPDfpCoverageMFL.nexpnum
)) WHERE rn = 1  )   BOPDfpCoverage  
on ppol.PolicyID = BOPDfpCoverage.PolicyID 
and ppol.nexpnum = BOPDfpCoverage.nexpnum
and BOPDfpCoverage.CoverageName ='Spo'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPRCVMFL.*
   from
   {rawDB}.BOPRCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCVMFL.PolicyID
              and mb.nexpnum = BOPRCVMFL.nexpnum
)) WHERE rn = 1  )  BOPCV  
on ppol.PolicyID = BOPCV.PolicyID
and ppol.nexpnum = BOPCV.nexpnum
and BOPCV.LMSCMAT5 like 'REFLMT%' 
and BOPCV.LCOVCDE ='OPE'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NCOVNUM ,NFACNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPRCFMFL.*
   from
   {rawDB}.BOPRCFMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCFMFL.PolicyID
              and mb.nexpnum = BOPRCFMFL.nexpnum
)) WHERE rn = 1  )  BOPRCF  
on ppol.PolicyID = BOPRCF.PolicyID
and ppol.nexpnum = BOPRCF.nexpnum
and BOPRCF.NCOVNUM =50
and BOPRCF.LMATCDE like 'DFPVAL%'


"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_spoil_dfncy")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
   queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","SPOIL_DFNCY_ID")
  
    mergeAndWrite(hashDF,List("SPOIL_DFNCY_KEY","END_EFF_DT"),harmonized_table,"SPOIL_DFNCY_ID","HV-COP")
}