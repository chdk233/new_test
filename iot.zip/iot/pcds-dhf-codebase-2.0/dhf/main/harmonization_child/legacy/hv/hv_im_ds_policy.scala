// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_im_ds_policy(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select  
 --IM POL_KEY
   concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
   as POL_KEY  -- will show duplicates
 
 --IM END_EFF_DT
   ,case when year(ppol.NEFFDATREC) = 1899 then DATE(ppol.NEFFDAT) else DATE(ppol.NEFFDATREC) end  as END_EFF_DT
 
,case when year(ppol.NEXPDATREC) = 1899 then DATE(ppol.NEXPDAT) else DATE(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
 
 --IM AGCY_KEY
   ,concat('DPIM-',case when POLAGT.LAGTNUM is NULL then ('NULL') else POLAGT.LAGTNUM end) AS AGCY_KEY

--IM AGNT_KEY
,concat(concat(concat('DPIM-',CASE WHEN rtrim(POLAGT.LAGTNUM) IS NULL THEN ('NULL') else RTRIM(POLAGT.LAGTNUM) end), '-'),case  when RTRIM(POLAGT.LPCRNUM) =''   then ('NULL') when RTRIM(POLAGT.LPCRNUM) is NULL then ('NULL') else RTRIM(POLAGT.LPCRNUM) end ) AS AGNT_KEY
--,'IM' AS PROD_CD
  ,concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM), '-PNI-0') as PRIM_NAMED_INSURED_KEY
,ifnull(rtrim(POLEXT2.StringValue), ' ') AS SIC_CD,
ifnull(rtrim(POLEXT14.StringValue), ' ') AS AUDIT_PLAN_CD, 
ifnull(rtrim(POLEXT4.StringValue), ' ') AS CMML_MKT_SGMNT_CD,
ifnull(rtrim(POLEXT10.StringValue), ' ') AS INDUSTRY_CD,
ifnull(substr(rtrim(POLEXT10.StringValue), 1, 2), ' ') AS INDUSTRY_GRP_CD,
ifnull(CAST(POLEXT11.StringValue AS DOUBLE), 0) AS COMM_CONTRIBUTION_FCTR,
ifnull(rtrim(POLEXT8.StringValue), ' ') AS POL_PRINT_METHOD,
ifnull(rtrim(POLEXT5.StringValue), ' ') AS GL_CLASS_CD,
ifnull(rtrim(v3x.LBUSDES), ' ') AS BUS_CL_DESC,
ifnull(CAST(ppol.NTOTPRM AS DOUBLE), 0) AS TOTAL_PREM_RPT_AMT,
if(rtrim(v3x.LPOLSTS) = 'Cancel', if(rtrim(v3x.LSECTCTTYP) = '' OR v3x.LSECTCTTYP is null, ' ', rtrim(v3x.LSECTCTTYP)), ' ') AS RFND_CALC_METHD_CD,
if(rtrim(v3x.LPOLSTS) = 'Cancel', if(rtrim(v3x.LTCTDES) = '' OR v3x.LTCTDES is null, 'Not Defined', rtrim(v3x.LTCTDES)), 'Not Defined') AS RFND_CALC_METHD_TEXT,
'AQS' AS POL_ORIGIN_CD
  ,concat(concat('HV-PAK','-'),namex.Stringvalue) as ACCT_KEY 
,ifnull(rtrim(ppol.LPOLNUM), ' ') AS POL_NO,
ifnull(date(ppol.NEFFDAT), TO_DATE('1900-01-01','yyyy-mm-dd')) AS POL_EFF_DT,
ifnull(date(ppol.NEXPDAT), TO_DATE('1900-01-01','yyyy-mm-dd')) AS POL_EXP_DT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') AS ORIG_EFF_DT,
if(rtrim(v3x.LPOLSTS) = 'New Business', 'Y', 'N') AS NEW_BUS_FL,
ifnull(rtrim(ppol.LBUSTYP), ' ') AS ENTITY_TYPE_CD,
ifnull(rtrim(ppol.LPRISTACDE), ' ') AS PRIM_STATE_CD,
if(rtrim(ppol.LPRISTANAM) = '' OR ppol.LPRISTANAM is null, 'Not Defined', rtrim(ppol.LPRISTANAM)) AS PRIM_STATE_TEXT,
if(rtrim(v3x.LTCTDES) = '' OR v3x.LTCTDES is null, 'Not Defined', rtrim(v3x.LTCTDES)) AS POL_PERIOD_STATUS_TEXT,
if(rtrim(v3x.LPOLSTS) in ('Renewal', 'Quote', 'New Business'), 'Active', 'Cancel') AS LAST_STATUS_CD,
if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)) AS LAST_STATUS_EFF_DT,
'Y' AS BOUND_FL,
if(rtrim(v3x.LPOLSTS) = 'Cancel', rtrim(v3x.LPOLSTS)||'-'||rtrim(POLEXT3.StringValue), rtrim(v3x.LPOLSTS)) AS LAST_STATUS_REASON_CD,
if(rtrim(v3x.LPOLSTS) = 'Cancel', rtrim(v3x.LTCTDES), '') AS CANCEL_SRCE_CD,
ifnull(rtrim(POLEXT12.StringValue), '') AS ASE_ZONE,
IF(rtrim(ppol.LPOLTYP) = 'MONOLINE', 'Y', 'N') AS MONOLINE_FL,
if(trim(ppol.LCMP) = '' OR ppol.LCMP is null, 'Not Defined', rtrim(ppol.LCMP)) AS POL_CO_TEXT,
ifnull(cast(ppol.NTOTPRMANN as double), 0) as TOTAL_COST_RPT_AMT,
if(rtrim(V3X.LPRITCTTYP) = 'audit', 'YES', 'NO') AS TERM_AUDITED_IND,
if(rtrim(V3X.LPRITCTTYP) = 'audit', to_date(PPOL.NCHGDAT, 'MM/dd/yyyy'), TO_DATE('1900-01-01','yyyy-mm-dd')) AS POL_LAST_AUDITED_DT,
CAST(POLEXT13.DoubleValue as double) as EXP_PASS_PREM_AMT,
trim(v3x.LPRDCDE) AS PROD_CD,
trim(v3x.LPRDCDEDES) AS PROD_TEXT,
'IM' AS LOB_CD,
'HV-IM' AS PARTITION_VAL,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'CIM%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.neffyrs,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CIM%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLNAMEXTMFL.*
   from
   {rawDB}.POLNAMEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLNAMEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   namex
 
on ppol.policyid = namex.policyid 
and namex.NEXPNUM = 0
and namex.Name = 'InsAct' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT6
 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT1
 
on ppol.PolicyID = POLEXT1.PolicyID 
and  ppol.nexpnum = POLEXT1.nexpnum
and  POLEXT1.Name like 'EffDat%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT2
 
on ppol.PolicyID = POLEXT2.PolicyID 
and  ppol.nexpnum = POLEXT2.nexpnum
and  POLEXT2.Name like 'SICCde%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT3
 
on ppol.PolicyID = POLEXT3.PolicyID 
and  ppol.nexpnum = POLEXT3.nexpnum
and  POLEXT3.Name like 'CanRsn%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT4
 
on ppol.PolicyID = POLEXT4.PolicyID 
and  ppol.nexpnum = POLEXT4.nexpnum
and  POLEXT4.Name like 'LobMktSeg%' 


left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID  )
  ) WHERE rn = 1  )          
   POLEXT5
 
on ppol.PolicyID = POLEXT5.PolicyID 
and  ppol.nexpnum = POLEXT5.nexpnum
and  POLEXT5.Name like 'GLCCde%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT7
 
on ppol.PolicyID = POLEXT7.PolicyID 
and  ppol.nexpnum = POLEXT7.nexpnum 
and  POLEXT7.Name like 'PolicyNumber%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT8
 
on ppol.PolicyID = POLEXT8.PolicyID 
and  ppol.nexpnum = POLEXT8.nexpnum
and  POLEXT8.Name like 'AdditionalPrintOption%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT10
 
on ppol.PolicyID = POLEXT10.PolicyID 
and ppol.nexpnum = POLEXT10.nexpnum
and  POLEXT10.Name like 'NaiCde%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT11
 
on ppol.PolicyID = POLEXT11.PolicyID 
and ppol.nexpnum = POLEXT11.nexpnum
and  POLEXT11.Name like 'NegComExp%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT12
 
on ppol.PolicyID = POLEXT12.PolicyID 
and ppol.nexpnum = POLEXT12.nexpnum
and  POLEXT12.Name like 'AcctZone%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT13
 
on ppol.PolicyID = POLEXT13.PolicyID 
and ppol.nexpnum = POLEXT13.nexpnum
and  POLEXT13.Name like 'PolPrm%'
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )
  ) WHERE rn = 1  )          
   POLEXT14
 
on ppol.PolicyID = POLEXT14.PolicyID 
and ppol.nexpnum = POLEXT14.nexpnum
and  POLEXT14.Name like 'AudTyp%'


left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL. NEXPNUM )
  ) WHERE rn = 1  )          
   v3x
 
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAGTMFL.*
   from
   {rawDB}.POLAGTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAGTMFL.PolicyID 
                   )
  ) WHERE rn = 1  )          
   POLAGT
 
on ppol.policyid = POLAGT.policyid 
and ppol.NEXPNUM = POLAGT.NEXPNUM
"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_im_ds_policy")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","POLICY_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("POL_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"POLICY_ID","HV-IM") 
}