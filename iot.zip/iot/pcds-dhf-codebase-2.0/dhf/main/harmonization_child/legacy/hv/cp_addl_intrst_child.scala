// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_addl_intrst(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

Select 
--DS_ADDL_INTRST_CP

concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when PRPLink.nstanum is null then (999) else PRPLink.nstanum end),'-')
,case when PRPLink.nlocnum is null then (999) else PRPLink.nlocnum end),'-')
,case when PRPLink.nbldnum is null then (999) else PRPLink.nbldnum end),'-')
,case when PRPLink.noccnum is null then (999) else PRPLink.noccnum end),'-')
,case when PRPLink.ncovnum is null then (999) else PRPLink.ncovnum end),'-')
,case when PRPLink.nsubcovnum is null then (999) else PRPLink.nsubcovnum end),'-')
,case when PRPLink.SequenceNumber is null then (999) else PRPLink.SequenceNumber end ) ,'-')
,case when PRPLink.type is null then ('NULL') else PRPLink.type end ) ,'-')
,case when POLADDNIN.SequenceNumber is null then (999) else POLADDNIN.SequenceNumber end )
--,case when PRPLink.nseqnum is null then (999) else PRPLink.nseqnum end ) --- added for MPA/SPP uniqueness 
as ADDL_INTRST_KEY

,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates

,concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when POLADDNIN.SequenceNumber is NULL  then (999)  else POLADDNIN.SequenceNumber end)
as POL_PARTY_KEY
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
--,ppol.NEFFDAT as POL_EFF_DT
--,ppol.NEXPDAT as POL_EXP_DT
,'HV' as SOURCE_SYSTEM
,IF(ISNULL(PRPLink.type),'',PRPLink.type) as ADDL_INTRST_TYPE_CD
,IF(ISNULL(POLADDNIN.LNAM3),'',POLADDNIN.LNAM3) as CONTRACT_NO
,'CP' as LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS


from global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
GROUP BY  ppol1.lpolnum ,ppol1.NEXPDAT,ppol1.NEFFDAT,w.act_wstid ) ppol1
on ppol1.policyid=ppol.policyid


 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,nexpnum,SequenceNumber,Type,nbldnum,NodeKey  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLinkMFL.*
   from
   {rawDB}.PRPLinkMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLinkMFL.PolicyID 
            and mb.nexpnum = PRPLinkMFL.nexpnum  

--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   PRPLink


on ppol.PolicyID = PRPLink.PolicyID 
and ppol.nexpnum = PRPLink.nexpnum  

left outer Join 
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,nexpnum,SequenceNumber ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAddInterestMFL.*
   from
   {rawDB}.POLAddInterestMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAddInterestMFL.PolicyID 
            and mb.nexpnum = POLAddInterestMFL.nexpnum  

--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )   POLADDNIN 
on ppol.PolicyID = POLADDNIN.PolicyID 
and ppol.nexpnum = POLADDNIN.nexpnum 

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_CP_AI")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","ADDL_INTRST_ID")
  
     mergeAndWrite(hashDF,List("ADDL_INTRST_KEY","END_EFF_DT","END_EXP_DT"),harmonized_table,"ADDL_INTRST_ID","HV-CP")
 
}