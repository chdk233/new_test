// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_pol_line(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select 
 concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY
,case when year(ppol.NEFFDATREC) = 1899 then DATE(ppol.NEFFDAT) else DATE(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then DATE(ppol.NEXPDAT) else DATE(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,ppol.LPMATYP as PROG_CD
,ppol.LPMADES as PROG_TEXT
,BOPPOLEXT1.StringValue as BLDG_BPP_CAT
,BOPPOLEXT2.StringValue as BLDG_BPP_CL
,BOPPOLEXT3.StringValue as BLDG_BPP_GRP_NO
,BOPPOLEXT4.StringValue as BLDG_BPP_ISO_CL
,BOPPOLEXT5.StringValue as CRIME_CAT
,BOPPOLEXT6.StringValue as CRIME_CL_DESC 
,BOPPOLEXT7.StringValue as CRIME_GRP_NO
,BOPPOLEXT8.StringValue as SPOIL_CL
,BOPPOLEXT9.StringValue as SPOIL_GRP_NO
,BOPPRRCV.NMSCRAT5 as CRIME_RATABLE_EMPL
,'HV-COP' as PARTITION_VAL
,'COP' as LOB_CD
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid


 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'BldCgr%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT1 
on ppol.policyid = BOPPOLEXT1.policyid 
and ppol.NEXPNUM = BOPPOLEXT1.NEXPNUM
and BOPPOLEXT1.Name like 'BldCgr%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'BldCls%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT2 
on ppol.policyid = BOPPOLEXT2.policyid 
and ppol.NEXPNUM = BOPPOLEXT2.NEXPNUM
and BOPPOLEXT2.Name like 'BldCls%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'BldCopGrp%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT3 
on ppol.policyid = BOPPOLEXT3.policyid 
and ppol.NEXPNUM = BOPPOLEXT3.NEXPNUM
and BOPPOLEXT3.Name like 'BldCopGrp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'IsoClsCde%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT4 
on ppol.policyid = BOPPOLEXT4.policyid 
and ppol.NEXPNUM = BOPPOLEXT4.NEXPNUM
and BOPPOLEXT4.Name like 'IsoClsCde%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'KrmCgr%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT5 
on ppol.policyid = BOPPOLEXT5.policyid 
and ppol.NEXPNUM = BOPPOLEXT5.NEXPNUM
and BOPPOLEXT5.Name like 'KrmCgr%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'KrmCls%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT6 
on ppol.policyid = BOPPOLEXT6.policyid 
and ppol.NEXPNUM = BOPPOLEXT6.NEXPNUM
and BOPPOLEXT6.Name like 'KrmCls%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'KrmCopGrp%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT7 
on ppol.policyid = BOPPOLEXT7.policyid 
and ppol.NEXPNUM = BOPPOLEXT7.NEXPNUM
and BOPPOLEXT7.Name like 'KrmCopGrp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'SpoCls%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT8 
on ppol.policyid = BOPPOLEXT8.policyid 
and ppol.NEXPNUM = BOPPOLEXT8.NEXPNUM
and BOPPOLEXT8.Name like 'SpoCls%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPPOLEXTMFL.*
   from
   {rawDB}.BOPPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPPOLEXTMFL.PolicyID 
              and mb.NEXPNUM = BOPPOLEXTMFL.NEXPNUM
              and BOPPOLEXTMFL.Name like 'SpoCopGrp%'
              )
  ) WHERE rn = 1  ) BOPPOLEXT9 
on ppol.policyid = BOPPOLEXT9.policyid 
and ppol.NEXPNUM = BOPPOLEXT9.NEXPNUM
and BOPPOLEXT9.Name like 'SpoCopGrp%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,LPGMTYP,NPOLPED,NSTANUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPRCVMFL.*
   from
   {rawDB}.BOPRCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPRCVMFL.PolicyID 
              and mb.NEXPNUM = BOPRCVMFL.NEXPNUM
              and BOPRCVMFL.LMSCMAT5 like'RATEMP%' and BOPRCVMFL.NCOVNUM=80
              )
  ) WHERE rn = 1  )  BOPPRRCV 
on ppol.policyid = BOPPRRCV.policyid 
and ppol.NEXPNUM = BOPPRRCV.NEXPNUM
and BOPPRRCV.LMSCMAT5 like'RATEMP%' and BOPPRRCV.NCOVNUM=80
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_pol_line")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","POL_LINE_ID")
  
    mergeAndWrite(hashDF,List("POL_LINE_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table,"POL_LINE_ID","HV-COP")
 
}