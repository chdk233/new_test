// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_bp_ds_bldg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPLOC.NSTANUM is NULL, '999', LPAD(CAST(BOPLOC.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPLOC.NLOCNUM is NULL, '999', LPAD(CAST(BOPLOC.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0')) AS LOC_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPLOC.NSTANUM is NULL, '999', LPAD(CAST(BOPLOC.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPLOC.NLOCNUM is NULL, '999', LPAD(CAST(BOPLOC.NLOCNUM AS STRING), 3, '0'))||'-'||if(BOPBLD.NBLDNUM is NULL, '999', LPAD(CAST(BOPBLD.NBLDNUM AS STRING), 3, '0'))||'-'||if(BOPBLDEXT3.ELEMENT is null, '999', LPAD(CAST(BOPBLDEXT3.ELEMENT AS STRING), 3, '0')) AS BLDG_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
cast(BOPBLD.NYRSBIL as double) as BUILD_YR,
cast(BOPBLD.NBLDNUM as double) as BLDG_NO,
ifnull(trim(BOPBLD.LISOCON), ' ') as CONSTR_TYPE_CD,
ifnull(trim(BOPBLD.LCON), 'Not Defined') as CONSTR_TYPE_TEXT,
ifnull(trim(BOPBLD.LGRA), ' ') as EFFECTIVENESS_GRADE_CD,
ifnull(trim(BOPBLD.LGRATYP), 'Not Defined') as EFFECTIVENESS_GRADE_TEXT,
cast(BOPBLDEXT1.DoubleValue as double) as STORIES_NO,
cast(BOPBLDEXT2.DoubleValue as double) as UNITS_NO,
ifnull(trim(BOPBLDEXT3.StringValue), 'Not Defined') as PCT_OCCUPIED_TEXT,
cast(BOPBLDEXT4.DoubleValue as double) as TOT_AREA_SF_NO,
ifnull(trim(BOPBLDEXT5.StringValue), ' ') as BLDG_ELEVATION,
'BP' AS LOB_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where BOP_DEC.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where BOP_DEC.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NSTANUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCMFL.*
   from
   {rawDB}.BOPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPLOC
on ppol.PolicyID = BOPLOC.PolicyID 
and ppol.nexpnum = BOPLOC.nexpnum

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NSTANUM,NPOLPED,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDMFL.*
   from
   {rawDB}.BOPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPBLD
on  ppol.policyid = BOPBLD.policyid 
and ppol.NEXPNUM = BOPBLD.NEXPNUM
and BOPLOC.NSTANUM = BOPBLD.NSTANUM
and BOPLOC.NLOCNUM = BOPBLD.NLOCNUM 

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPBLDEXT1
on ppol.PolicyID = BOPBLDEXT1.PolicyID 
and ppol.nexpnum = BOPBLDEXT1.NEXPNUM
and BOPBLD.NSTANUM = BOPBLDEXT1.NSTANUM
and BOPBLD.NLOCNUM = BOPBLDEXT1.NLOCNUM
and BOPBLD.NBLDNUM = BOPBLDEXT1.NBLDNUM  
and BOPBLDEXT1.Name like 'NumSty%'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPBLDEXT2
on ppol.PolicyID = BOPBLDEXT2.PolicyID 
and ppol.nexpnum = BOPBLDEXT2.nexpnum 
and BOPBLD.NSTANUM = BOPBLDEXT2.NSTANUM
and BOPBLD.NLOCNUM = BOPBLDEXT2.NLOCNUM
and BOPBLD.NBLDNUM = BOPBLDEXT2.NBLDNUM  
and BOPBLDEXT2.Name like 'NumUnts%'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPBLDEXT3
on ppol.PolicyID = BOPBLDEXT3.PolicyID 
and ppol.nexpnum = BOPBLDEXT3.nexpnum 
and BOPBLD.NSTANUM = BOPBLDEXT3.NSTANUM
and BOPBLD.NLOCNUM = BOPBLDEXT3.NLOCNUM
and BOPBLD.NBLDNUM = BOPBLDEXT3.NBLDNUM   
and BOPBLDEXT3.StringValue <> '0' and trim(BOPBLDEXT3.StringValue) <> ''
and BOPBLDEXT3.Name like 'PctOcc%'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPBLDEXT4
on ppol.PolicyID = BOPBLDEXT4.PolicyID 
and ppol.nexpnum = BOPBLDEXT4.nexpnum
and BOPBLD.NSTANUM = BOPBLDEXT4.NSTANUM
and BOPBLD.NLOCNUM = BOPBLDEXT4.NLOCNUM
and BOPBLD.NBLDNUM = BOPBLDEXT4.NBLDNUM  
and BOPBLDEXT4.Name like 'SqrFtg%'

left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element,NBLDNUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPBLDEXTMFL.*
   from
   {rawDB}.BOPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPBLDEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   BOPBLDEXT5
on ppol.PolicyID = BOPBLDEXT5.PolicyID 
and ppol.nexpnum = BOPBLDEXT5.nexpnum
and BOPBLD.NSTANUM = BOPBLDEXT5.NSTANUM
and BOPBLD.NLOCNUM = BOPBLDEXT5.NLOCNUM
and BOPBLD.NBLDNUM = BOPBLDEXT5.NBLDNUM  
and BOPBLDEXT5.Name like 'BldElv%'
"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_bp_ds_bldg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","BLDG_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("BLDG_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"BLDG_ID","HV-BP") 
}