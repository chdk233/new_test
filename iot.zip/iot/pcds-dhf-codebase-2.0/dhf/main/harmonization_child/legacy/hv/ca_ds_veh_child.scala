// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_veh(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(CAUSTA.NSTANUM is NULL, '999', CAUSTA.NSTANUM)||'-'||if(CAUVEH.NVEHNUM is NULL, '999', CAUVEH.NVEHNUM) AS VEH_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(CAUSTA.NSTANUM is NULL, '999', CAUSTA.NSTANUM)||'-'||if(CAUVEH.NVEHNUM is NULL, '999', CAUVEH.NVEHNUM)||'-'||if(CAUVEH.LTER is NULL or trim(CAUVEH.LTER) = '', 'NULL', CAUVEH.LTER)||'-'||if(CAUVEH.LTERZIP is NULL or trim(CAUVEH.LTERZIP) = '', 'NULL', CAUVEH.LTERZIP)||'-'||if(CAUVEH.LGARCTY is NULL or trim(CAUVEH.LGARCTY) = '', 'NULL', CAUVEH.LGARCTY) AS GARAGE_LOC_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
'CA' as LOB_CD,
ifnull(rtrim(CAUVEH.LVEHTYP), ' ') AS CVRBL_TYPE_CD,
ifnull(rtrim(CAUVEH.LIDXNUM), ' ') AS VEH_ID_NO,
cast(CAUVEH.NVEHNUM as double) AS VEH_NO,
ifnull(rtrim(CAUVEH.LMDL), ' ') AS MODEL_NAME,
ifnull(rtrim(CAUVEH.LVEHDES), ' ') AS MODEL_DESC,
cast(CAUVEH.LMDLYRS as double) AS MODEL_YR,
ifnull(rtrim(CAUVEH.LMFR), ' ') AS MAKE_NAME,
ifnull(rtrim(CAUVEH.LANTTFT), 'Not Defined') AS ANTITHEFT_DEVICE_TEXT,
ifnull(rtrim(CAUVEHTRK.LUSE), ' ') AS BUS_USE_CL,
ifnull(rtrim(CAUVEH.LCLSCDE), ' ') AS CL_CD,
cast(CAUVEHPBL.NMNS*30 as double) AS  DAYS_SCHL_YR_CNT,
ifnull(rtrim(CAUVEHTRK.LZNEDSN), ' ') AS FAR_TERM_ZONE,
CASE WHEN CAUPOL.LFLEIND = 'FLEET' THEN 'Y' ELSE 'N' END AS FLEET_FL,
ifnull(rtrim(CAUVEHTRK.LZNEGAR), ' ') AS GARAGING_ZONE,
cast(CAUVEHTRK.NWGT as double) AS GROSS_VEH_WEIGHT,
ifnull(rtrim(CAUVEH.LPLTNUM), ' ') AS LIC_PLATE,
cast(CAUVEH.NCSTNEW as double) AS ORIG_COST_NEW_AMT,
ifnull(rtrim(CAUVEH.LPLTTYP), ' ') AS PLATE_TYPE_CD,
CONCAT (CASE WHEN CAUVEHPBL.LPBLTYP IS NOT NULL OR CAUVEHPBL.LPBLTYP <> '' THEN RTRIM(CAUVEHPBL.LPBLTYP) ELSE 'NULL' END  ,'-',CASE WHEN CAUVEHPBL.LPBLSUBTYP IS NOT NULL OR CAUVEHPBL.LPBLSUBTYP <> '' THEN RTRIM(CAUVEHPBL.LPBLSUBTYP) ELSE 'NULL' END ) AS PUB_TRNSP_TYPE,
ifnull(rtrim(CAUVEHPBL.LRAD), ' ') AS PUB_TRNSP_RADIUS_CL,
CASE WHEN trim(LVEHDES) = 'SCH & CH BUSES' AND NMNS < 12 THEN 'Y' ELSE 'N' END AS SCHL_BUS_PRORATION_FL,
ifnull(rtrim(CAUVEHPBL.LSES), ' ') AS SEATING_CPCTY,
ifnull(rtrim(CAUVEHTRK.LSUBIDS), ' ') AS SEC_CL_CD,
ifnull(rtrim(CAUVEHTRK.LWGT), ' ') AS SIZE_CL,
case when LSPCVEH IS NOT NULL AND trim(LSPCVEH) <> '' AND (LSPCVEH NOT LIKE '%MANUAL RATED%' AND LSPCVEH NOT LIKE '%MANUALLY RATED%'
AND LSPCVEH NOT LIKE '%MANUAL RATED%') THEN rtrim(CAUVEH.LVEHTYP) ELSE 'NULL' END AS SPCL_VEH_CL,
CONCAT (CASE WHEN CAUVEHTRK.LIDS IS NOT NULL OR trim(CAUVEHTRK.LIDS) <> '' THEN RTRIM(CAUVEHTRK.LIDS) ELSE 'NULL' END  ,'-',CASE WHEN CAUVEHTRK.LSUBIDS IS NOT NULL OR trim(CAUVEHTRK.LSUBIDS) <> '' THEN RTRIM(CAUVEHTRK.LSUBIDS) ELSE 'NULL' END ) AS TRUCK_SEC_CL,
ifnull(rtrim(CAUVEHTRK.LRAD), ' ')  AS TRUCK_RADIUS_CL,
ifnull(rtrim(CAUVEHTRK.LUSE), ' ') AS TRLR_HOW_USED,
ifnull(rtrim(CAUVEHTRK.LTRKTYP5), 'U') AS TRUCK_TRACTOR_FL,
cast(CAUVEH.NCDESEQNUM as double) AS VEH_SEQ_NO,
ifnull(rtrim(CAUVEH.LVEHDES), ' ') AS VEH_DESC_CD,
'NA' AS TELEMATICS_PARTICIPATION_FL
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.policyid = CAUPOL.policyid 
and ppol.NEXPNUM = CAUPOL.NEXPNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA  
on ppol.policyid = CAUSTA.policyid 
and ppol.NEXPNUM = CAUSTA.NEXPNUM
and CAUSTA.NPOLPED=CAUPOL.NPOLPED
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NVEHNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUVEHMFL.*
   from
   {rawDB}.CAUVEHMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUVEHMFL.PolicyID 
            
--               where CAUVEHMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUVEH  
on ppol.policyid = CAUVEH.policyid 
and ppol.NEXPNUM = CAUVEH.NEXPNUM
and CAUSTA.NSTANUM=CAUVEH.NSTANUM
and CAUSTA.NPOLPED=CAUVEH.NPOLPED
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NVEHNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUVEHTRKMFL.*
   from
   {rawDB}.CAUVEHTRKMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUVEHTRKMFL.PolicyID 
            
--               where CAUVEHTRKMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUVEHTRK  
on ppol.policyid = CAUVEHTRK.policyid 
and ppol.NEXPNUM = CAUVEHTRK.NEXPNUM
and CAUVEH.NSTANUM=CAUVEHTRK.NSTANUM
and CAUVEH.NVEHNUM=CAUVEHTRK.NVEHNUM
and CAUVEH.NPOLPED=CAUVEHTRK.NPOLPED
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NVEHNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUVEHPBLMFL.*
   from
   {rawDB}.CAUVEHPBLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUVEHPBLMFL.PolicyID 
            
--               where CAUVEHPBLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUVEHPBL  
on ppol.policyid = CAUVEHPBL.policyid 
and ppol.NEXPNUM = CAUVEHPBL.NEXPNUM
and CAUVEH.NSTANUM=CAUVEHPBL.NSTANUM
and CAUVEH.NVEHNUM=CAUVEHPBL.NVEHNUM
and CAUVEH.NPOLPED=CAUVEHPBL.NPOLPED
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_veh")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","VEH_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("VEH_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"VEH_ID","HV-CA") 
    //     queryDF.show(3,false)
}