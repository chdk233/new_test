// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_bp_ds_flood_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
 SELECT
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(BOPLOC.NSTANUM is NULL, '999', LPAD(CAST(BOPLOC.NSTANUM AS STRING), 3, '0'))||'-'||if(BOPLOC.NLOCNUM is NULL, '999', LPAD(CAST(BOPLOC.NLOCNUM AS STRING), 3, '0'))||'-'||if(POLLOC.NBLDNUM is NULL, '999', LPAD(CAST(POLLOC.NBLDNUM AS STRING), 3, '0')) AS FLOOD_INFO_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
'BP' AS LOB_CD,
'BOPLocation' AS CVRBL_TYPE_CD,
ifnull(CAST(POLLOCEXT.StringValue AS DOUBLE), 0) AS FLOOD_RISK_SCORE,
ifnull(rtrim(BOPLOCEXT1.StringValue), ' ') AS FLOOD_ZONE
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCMFL.*
   from
   {rawDB}.BOPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCMFL.PolicyID
              and mb.nexpnum = BOPLOCMFL.nexpnum )) WHERE rn = 1  ) BOPLOC  
on ppol.PolicyID = BOPLOC.PolicyID 
and ppol.nexpnum = BOPLOC.nexpnum
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,nexpnum,NLOCNUM,name  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLOCEXTMFL.*
   from
   {rawDB}.BOPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLOCEXTMFL.PolicyID 
            and mb.nexpnum = BOPLOCEXTMFL.nexpnum  
              )
  ) WHERE rn = 1  )          
   BOPLOCEXT1
on ppol.PolicyID = BOPLOCEXT1.PolicyID 
and ppol.nexpnum = BOPLOCEXT1.nexpnum  
and BOPLOC.NSTANUM = BOPLOCEXT1.NSTANUM 
and BOPLOC.NLOCNUM = BOPLOCEXT1.NLOCNUM  
and BOPLOCEXT1.Name like 'FodZon%'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
            and mb.nexpnum = POLLocationMFL.nexpnum
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLLOC  
on ppol.PolicyID = POLLOC.PolicyID
and ppol.nexpnum = POLLOC.nexpnum
and BOPLOC.NLOCNUM = POLLOC.NLOCNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,nstanum,nlocnum,NBLDNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            and mb.nexpnum = POLLocationEXTMFL.nexpnum
              )
  ) WHERE rn = 1  ) POLLOCEXT  
on ppol.PolicyID = POLLOCEXT.PolicyID
and ppol.nexpnum = POLLOCEXT.nexpnum
and POLLOC.NLOCNUM = POLLOCEXT.NLOCNUM
and POLLOC.NBLDNUM = POLLOCEXT.NBLDNUM
and POLLOCEXT.Name like 'FloodRiskScore%'

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_bp_ds_flood_info")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","FLOOD_INFO_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("FLOOD_INFO_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"FLOOD_INFO_ID","HV-BP") 
    //     queryDF.show(3,false)
}