// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_form(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

Select
--Form Key
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-'),DocBaseDoc.bdtNumber),'-'),DocBaseDoc.bdtEdition),'-'),DocBaseDoc.bdtid ) as FORM_KEY 
--POLICY KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY 
,case when year(ppol.NEFFDATREC) = 1899 then DATE(ppol.NEFFDAT) else DATE(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then DATE(ppol.NEXPDAT) else DATE(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,docType.typDisplay as FORM_PATTERN_CD
,DocBaseDoc.bdtNumber as FORM_NO
,DocBaseDoc.bdtDesc as FORM_DESC
,DocBaseDoc.bdtEdition as EDITION
,'COP' as LOB_CD
,'HV-COP' as PARTITION_VAL
,ppol.insert_timestamp as etl_row_eff_dts

from global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'

left outer join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,dat_bdtId,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAttachmentMFL.*
   from
   {rawDB}.POLAttachmentMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAttachmentMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) PolAttachment  
ON PolAttachment.PolicyID = ppol.PolicyId
AND PolAttachment.NEXPNUM=ppol.NEXPNUM

INNER JOIN  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY bdtid ORDER BY update_timestamp   DESC ) AS rn
   FROM
   (SELECT  DOCBASEDOCUMENT.*
   from
   {rawDB}.DOCBASEDOCUMENT
   inner join {rawDB}.POLAttachmentMFL PolAttachment
   on DOCBASEDOCUMENT.bdtid = PolAttachment.dat_bdtid
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolAttachment.PolicyID 
              AND PolAttachment.NEXPNUM=mb.NEXPNUM
              )
  ) WHERE rn = 1  ) DocBaseDoc 
ON DocBaseDoc.bdtid =PolAttachment.dat_bdtid  



INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY typId ORDER BY update_timestamp   DESC ) AS rn
   FROM
   (SELECT  docType.*
   from
   {rawDB}.docType
   inner join {rawDB}.DOCBASEDOCUMENT DocBaseDoc
   ON docType.typId =DocBaseDoc.bdt_typId
   inner join {rawDB}.POLAttachmentMFL PolAttachment
   on DocBaseDoc.bdtid = PolAttachment.dat_bdtid
   inner join global_temp.polpolmfl_micro_batch mb
    on   mb.PolicyID = PolAttachment.PolicyID 
    AND PolAttachment.NEXPNUM=mb.NEXPNUM
              )
  ) WHERE rn = 1  ) docType 
ON docType.typId =DocBaseDoc.bdt_typId

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_HV_COP_Form")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
   queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","FORM_ID")
  
    mergeAndWrite(hashDF,List("FORM_KEY","END_EFF_DT"),harmonized_table,"FORM_ID","HV-COP")
}