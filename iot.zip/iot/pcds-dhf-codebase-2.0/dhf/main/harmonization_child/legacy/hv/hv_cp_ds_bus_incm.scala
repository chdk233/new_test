// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_bus_incm(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select 
--Business Income Key CP
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat( concat(concat(concat(concat(concat(concat
 (concat(concat(concat(concat(concat(concat( concat(concat
 (concat(concat(concat(concat(concat(concat(concat
 ('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
 ,case when POLLOC.NSTANUM is NULL then ( 999 ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM else case when PRPLOC.NSTANUM is NULL then ( 999 ) else PRPLOC.NSTANUM end end),'-')
,case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end),'-')
  ,case when PRPOCC.NOCCNUM is NULL then (999) else PRPOCC.NOCCNUM end),'-')
  ,case when PRPCOV.NCOVNUM is NULL then (999) else PRPCOV.NCOVNUM end),'-')
  ,case when PRPCOV.NSUBCOVNUM is NULL then (999) else PRPCOV.NSUBCOVNUM end),'-')
  ,case when PRPPRL.NPRLNUM is NULL then (999) else PRPPRL.NPRLNUM end),'-')
  ,case when PRPTME.LTMEMAT is NULL then ('NULL') else rtrim(PRPTME.LTMEMAT) end ),'-')
 ,case when PRPSSC.NSEQNUM is NULL  then (999)  else PRPSSC.NSEQNUM end),'-')
  ,case when SPCCOV.LCOVTYPCDE is NULL then ('NULL') else SPCCOV.LCOVTYPCDE end),'-')
  ,case when SPCCOV.LSUBCOVCDE is NULL then ('NULL') else SPCCOV.LSUBCOVCDE end) ,'-')
  ,case when PRPBLDEXT3.Element is NULL  then (999)  else PRPBLDEXT3.Element end)

AS BI_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') ,
case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end )
,'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
,'-'),case when PRPBLDEXT3.Element is NULL  then (999)  else PRPBLDEXT3.Element end)
as LINE_BLDG_KEY  
 

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end )
,'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
,'-'),case when PRPBLDEXT3.Element IS NULL then (999) else PRPBLDEXT3.Element end)

as BLDG_KEY 
--POLICY KEY CP
  ,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY 
 
--POLICY LINE KEY CP
  ,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY

,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
 
 --SOURCE_SYSTEM
  ,'HV' as SOURCE_SYSTEM
 
 --CVRBL_TYP_CD
  ,'CPBusiness Income' AS CVRBL_TYPE_CD
,CASE WHEN TRIM(PRPCOV.LAGDAMTTYP)  = 'YES' THEN PRPCOV.NXPS  ELSE NULL END AS AGREED_VAL_LMT
,case when PRPCOV.NBKTNUM <>0 then PRPCOV.LFRM ELSE NULL END AS BLNKT_LOSS_CAUSE_VAL
,CASE WHEN PRPCOV.NBKTNUM<>0 AND PRPPRL.NPRLNUM<>3  THEN PRPCOV.NBKTNUM ELSE NULL END AS BLNKT_ID_NO
,PRPCOV.NCOVNUM AS BUS_INC_NO
,CASE WHEN TRIM(PRPCOV.NCOVNUM) IN (61,62,63,64,65) AND TRIM(PRPTME.LTMEMAT) ='TMEEEXIND' AND TRIM(LCHC)='YES' THEN 'Business Income With Extra Expense'
      WHEN TRIM(PRPCOV.NCOVNUM) IN (61,62,63,64,65) AND TRIM(PRPTME.LTMEMAT) ='TMEEEXIND' AND TRIM(LCHC) ='NO' THEN 'Business Income With Out Extra Expense'
	  WHEN TRIM(PRPCOV.NCOVNUM) IN (66,67) THEN 'Extra Expense Only' end as COVG_TYPE

,CASE WHEN PRPCOV.NBKTNUM <>0 AND TRIM(PRPCOV.NCOVNUM) IN (67,62,66,61,63,65,64,81,74) THEN 'Yes, Included in Blanket'
      WHEN PRPCOV.NBKTNUM =0 AND TRIM(PRPCOV.NCOVNUM) IN (67,62,66,61,63,65,64,81,74) THEN 'Yes, Not Included in Blanket'
	  WHEN TRIM(PRPCOV.NCOVNUM) NOT in (67,62,66,61,63,65,64,81,74) Then 'No Coverage' end as COVG_IND

,CASE WHEN TRIM(PRPPRL.LMATCDE)='EQS' AND TRIM(PRPPRL.LIND) = 'YES' THEN 'Y' ELSE 'N' END AS EQ_SL_ONLY_FL  


--EXT_PRD_APPL_FL CP 
,CASE WHEN (TRIM(PRPTME.LTMEMAT)= 'TMEEXTIDM'  AND TRIM(PRPTME.LCHC) <> 'NONE'  AND tRIM(PRPTME.LCHC) <> '' )  THEN 'Y' ELSE 'N' END AS  EXT_PRD_APPL_FL
--INC_IN_BLNKT_FL (Other than EQ) (Transformation Logic is available in the respective Data Mapping Sheet)
,CASE WHEN PRPPRL.NPRLNUM <>3 AND PRPCOV.NBKTNUM <>0 THEN 'Y' ELSE 'N' END AS INC_IN_BLNKT_FL

--FUNG_WET_DRY_ROT_BACT_INCRD_FL CP

,CASE WHEN TRIM(SPCCOV.LCOVTYPCDE) = 'FUN' and TRIM(SPCCOV.LSUBCOVCDE)= 'GCO' AND TRIM(SPCCOV.LSUBDES4) <> '' THEN  'Y' else 'N' End as FUNG_WET_DRY_ROT_BACT_INCRD_FL

--TYPE_RISK_DESC CP
  ,PRPCOV.LTMETYP2 AS TYPE_RISK_DESC
--RISK_EDU_INST_PCT CP
  ,CASE  When LCOVDES = 'Business Educational Institute' THEN PRPCOV.LTMETYP3  ELSE 'NA' END AS  RISK_EDU_INST_PCT

--RISK_MERC_PCT CP
  ,CASE WHEN PRPCOV.LTMETYP2 = 'MERC' THEN PRPCOV.LTMETYP3  ELSE 'NA' END AS RISK_MERC_PCT

--RISK_RENTAL_PCT CP
  ,CASE WHEN PRPCOV.LTMETYP2 = 'RENTAL' THEN PRPCOV.LTMETYP3  ELSE 'NA' END AS RISK_RENTAL_PCT

--RISK_MFG_PCT
  ,CASE WHEN PRPCOV.LTMETYP2 = 'MFG' THEN PRPCOV.LTMETYP3  ELSE 'NA' END AS RISK_MFG_PCT
  ,'CP' AS LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              and mb.nexpnum = POLLocationMFL.nexpnum)
  ) WHERE rn = 1  ) POLLOC  
on ppol.PolicyID = POLLOC.PolicyID 
and ppol.nexpnum = POLLOC.nexpnum  

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLOCMFL.*
   from
   {rawDB}.PRPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCMFL.PolicyID 
              and mb.nexpnum = PRPLOCMFL.nexpnum)
  ) WHERE rn = 1  ) PRPLOC  
on ppol.PolicyID = PRPLOC.PolicyID 
and ppol.nexpnum = PRPLOC.nexpnum 
and POLLOC.NLOCNUM = PRPLOC.NLOCNUM

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBLDMFL.*
   from
   {rawDB}.PRPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDMFL.PolicyID 
              and mb.nexpnum = PRPBLDMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLD  
on ppol.PolicyID = PRPBLD.PolicyID 
and ppol.nexpnum = PRPBLD.nexpnum 
and POLLOC.NLOCNUM = PRPBLD.NLOCNUM
and PRPLOC.NSTANUM = PRPBLD.NSTANUM
and case when POLLOC.NBLDNUM >0 then POLLOC.NBLDNUm else PRPBLD.NBLDNUM end = PRPBLD.NBLDNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPCOVMFL.*
   from
   {rawDB}.PRPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPCOVMFL.PolicyID 
              and mb.nexpnum = PRPCOVMFL.nexpnum )
  ) WHERE rn = 1  ) PRPCOV  
on ppol.PolicyID = PRPCOV.PolicyID 
and ppol.nexpnum = PRPCOV.nexpnum  
and PRPCOV.NSTANUM = PRPLOC.NSTANUM
and PRPCOV.NLOCNUM = PRPLOC.NLOCNUM
and PRPCOV.NBLDNUM = PRPBLD.NBLDNUM
 and TRIM(PRPCOV.NCOVNUM) in (67,62,66,61,63,65,64,81,74) 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPOCCMFL.*
   from
   {rawDB}.PRPOCCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPOCCMFL.PolicyID 
              and mb.nexpnum = PRPOCCMFL.nexpnum )
  ) WHERE rn = 1  )  PRPOCC 
on  ppol.policyid = PRPOCC.policyid 
and ppol.NEXPNUM = PRPOCC.NEXPNUM 
and PRPLOC.NSTANUM = PRPOCC.NSTANUM
and PRPLOC.NLOCNUM = PRPOCC.NLOCNUM
and PRPBLD.NBLDNUM = PRPOCC.NBLDNUM
and PRPCOV.NOCCNUM = PRPOCC.NOCCNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID 
              and mb.nexpnum = SPCCOVMFL.nexpnum )
  ) WHERE rn = 1  ) SPCCOV 
ON

SPCCOV.POLICYID = PPOL.POLICYID
and SPCCOV.NEXPNUM=ppol.NEXPNUM
and SPCCOV.NSTANUM = PRPLOC.NSTANUM---Validated that the State Number matches.
 --We need to Validate the non populated values
and TRIM(SPCCOV.LLOB) = 'PRP'
and TRIM(SPCCOV.LCOVTYPCDE) IN ('FUN')
and TRIM(SPCCOV.LSUBCOVCDE) IN ('GCO')

and SPCCOV.NLOCNUM = CASE
WHEN SPCCOV.NLOCNUM =PRPLOC.NLOCNUM 
THEN PRPLOC.NLOCNUM
ELSE
 SPCCOV.NLOCNUM
END 

and SPCCOV.NBLDNUM=  CASE
WHEN  SPCCOV.NBLDNUM = PRPBLD.NBLDNUM and  SPCCOV.NLOCNUM =PRPLOC.NLOCNUM 
THEN PRPBLD.NBLDNUM
ELSE SPCCOV.NBLDNUM
END 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPSSCMFL.*
   from
   {rawDB}.PRPSSCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSSCMFL.PolicyID 
              and mb.nexpnum = PRPSSCMFL.nexpnum )
  ) WHERE rn = 1  ) PRPSSC 
on  ppol.policyid = PRPSSC.policyid 
and ppol.NEXPNUM = PRPSSC.NEXPNUM 
and PRPLOC.NSTANUM = PRPSSC.NSTANUM
and PRPLOC.NLOCNUM = PRPSSC.NLOCNUM
and PRPBLD.NBLDNUM = PRPSSC.NBLDNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM,NPRLNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPPRLMFL.*
   from
   {rawDB}.PRPPRLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPPRLMFL.PolicyID 
              and mb.nexpnum = PRPPRLMFL.nexpnum )
  ) WHERE rn = 1  ) PRPPRL 
on ppol.policyid =  PRPPRL.policyid 
and ppol.NEXPNUM =  PRPPRL.NEXPNUM
and PRPPRL.NSTANUM = PRPLOC.NSTANUM
and PRPPRL.NLOCNUM = PRPLOC.NLOCNUM
and PRPPRL.NBLDNUM = PRPBLD.NBLDNUM
and PRPPRL.NOCCNUM = PRPCOV.NOCCNUM
and PRPPRL.NCOVNUM = PRPCOV.NCOVNUM
and PRPPRL.NSUBCOVNUM = PRPCOV.NSUBCOVNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPPOLMFL.*
   from
   {rawDB}.PRPPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPPOLMFL.PolicyID 
              and mb.nexpnum = PRPPOLMFL.nexpnum )
  ) WHERE rn = 1  ) PRPPOL 
on PRPPOL.policyid = ppol.policyid 
and PRPPOL.NEXPNUM = ppol.NEXPNUM 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPCLSMFL.*
   from
   {rawDB}.PRPCLSMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPCLSMFL.PolicyID 
              and mb.nexpnum = PRPCLSMFL.nexpnum )
  ) WHERE rn = 1  )  PRPCLS 
on PRPCLS.policyid = ppol.policyid 
and PRPCLS.NEXPNUM = ppol.NEXPNUM 
and PRPCLS.NSTANUM = PRPLOC.NSTANUM
and PRPCLS.NLOCNUM = PRPLOC.NLOCNUM
and PRPCLS.NBLDNUM = PRPBLD.NBLDNUM
and PRPCLS.NOCCNUM = PRPOCC.NOCCNUM
and TRIM(PRPCLS.LCSPCDE) NOT in ('1190','1200','0833','1185')

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM,LTMEMAT ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPTMEMFL.*
   from
   {rawDB}.PRPTMEMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPTMEMFL.PolicyID 
              and mb.nexpnum = PRPTMEMFL.nexpnum )
  ) WHERE rn = 1  )  PRPTME 
on PRPTME.PolicyID = ppol.PolicyID 
and PRPTME.NEXPNUM=ppol.NEXPNUM
and PRPTME.NSTANUM=PRPLOC.NSTANUM
and PRPTME.NLOCNUM = PRPLOC.NLOCNUM
and PRPTME.NBLDNUM = PRPBLD.NBLDNUM
and PRPTME.NOCCNUM =PRPOCC.NOCCNUM
and PRPTME.NCOVNUM =PRPCOV.NCOVNUM
and PRPTME.NSUBCOVNUM =PRPCOV.NSUBCOVNUM
and TRIM(PRPTME.LTMEMAT) IN ('TMEEEXIND', 'TMEDPNPRP','TMEEXTIDM')

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  )PRPBLDEXT3  
on ppol.PolicyID = PRPBLDEXT3.PolicyID 
and ppol.nexpnum = PRPBLDEXT3.nexpnum 
and PRPBLD.NSTANUM = PRPBLDEXT3.NSTANUM
and PRPBLD.NLOCNUM = PRPBLDEXT3.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT3.NBLDNUM   
and  PRPBLDEXT3.StringValue <> '0' and TRIM(PRPBLDEXT3.StringValue) <> ''
and  PRPBLDEXT3.Name like 'PctOcc%' 	
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cp_ds_bus_incm")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","BI_ID")
  
    mergeAndWrite(hashDF,List("BI_KEY","END_EFF_DT"), harmonized_table,"BI_ID","HV-CP")
 
}