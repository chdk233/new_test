// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
select  distinct
concat(concat(concat(concat(concat(concat(concat(concat(concat
('HV-',POLEXT6.StringValue),'-')
, CASE WHEN rtrim(CAUCCVPRI.LMATCDE) IS NOT NULL AND rtrim(CAUCCVPRI.LMATCDE) <> '' THEN rtrim(CAUCCVPRI.LMATCDE) ELSE 'NULL' END ) ,'-')
, CASE WHEN rtrim(CAUCCVPRI.LDES) IS NOT NULL AND rtrim(CAUCCVPRI.LDES) <> '' THEN rtrim(CAUCCVPRI.LDES) ELSE 'NULL' END ) ,'-')
,CASE WHEN rtrim(CAUCCV.LMATCDE) IS NOT NULL AND rtrim(CAUCCV.LMATCDE) <> '' THEN rtrim(CAUCCV.LMATCDE) ELSE 'NULL' END ) ,'-')
,CASE WHEN rtrim(CAUCCV.LDES) IS NOT NULL AND rtrim(CAUCCV.LDES) <> '' THEN rtrim(CAUCCV.LDES) ELSE 'NULL' END )
as COVG_KEY, 
'CA' as LOB_CD,
'HV' as SOURCE_SYSTEM, 
'HV-CA' as PARTITION_VAL,
to_timestamp('1900-01-01','yyyy-mm-dd') AS ETL_ROW_EFF_DTS,
ifnull(rtrim(CAUCCVPRI.LMATCDE), ' ') as COVG_CD, 
ifnull(rtrim(CAUCCVPRI.LDES), 'Not Defined') as COVG_TEXT,   
ifnull(rtrim(CAUCCV.LMATCDE), ' ') as COVG_PART_CD, 
ifnull(rtrim(CAUCCV.LDES), 'Not Defined') as COVG_PART_TEXT 
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where CAUPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.PolicyID = CAUPOL.PolicyID 
and ppol.nexpnum  = CAUPOL.nexpnum 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where CAUSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA
  on ppol.PolicyID = CAUSTA.PolicyID 
and ppol.nexpnum  = CAUSTA.nexpnum 
and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVPRIMFL.*
   from
   {rawDB}.CAUCCVPRIMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVPRIMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUCCVPRI
on ppol.PolicyID = CAUCCVPRI.PolicyID 
and ppol.nexpnum  = CAUCCVPRI.nexpnum 
and CAUSTA.nstanum = CAUCCVPRI.nstanum
and CAUSTA.NPOLPED= CAUCCVPRI.NPOLPED
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVMFL.*
   from
   {rawDB}.CAUCCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUCCV
on ppol.PolicyID = CAUCCV.PolicyID 
and ppol.nexpnum  = CAUCCV.nexpnum 
and CAUCCVPRI.nstanum = CAUCCV.nstanum
and CAUCCVPRI.NPOLPED = CAUCCV.NPOLPED
and CAUCCVPRI.NTYPNUM = CAUCCV.NTYPNUM
and CAUCCVPRI.NSEQNUM = CAUCCV.NSEQNUM

union all

select  distinct
concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'), rtrim(CAUVEHCOV.LMATCDE)),'-'), rtrim(CAUVEHCOV.LCOVDES))  as COVG_KEY,
'CA' as LOB_CD,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
to_timestamp('1900-01-01','yyyy-mm-dd') AS ETL_ROW_EFF_DTS,
ifnull(rtrim(CAUVEHCOV.LMATCDE), ' ') as COVG_CD,
ifnull(rtrim(CAUVEHCOV.LCOVDES), 'Not Defined') as COVG_TEXT, 
' ' as COVG_PART_CD,  
'Not Defined' as COVG_PART_TEXT  
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where CAUPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.PolicyID = CAUPOL.PolicyID 
and ppol.nexpnum  = CAUPOL.nexpnum 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where CAUSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA
  on ppol.PolicyID = CAUSTA.PolicyID 
and ppol.nexpnum  = CAUSTA.nexpnum 
and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NVEHNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUVEHMFL.*
   from
   {rawDB}.CAUVEHMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUVEHMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUVEH
on ppol.policyid = CAUVEH.policyid 
and ppol.NEXPNUM = CAUVEH.NEXPNUM
and CAUSTA.NSTANUM=CAUVEH.NSTANUM
and CAUSTA.NPOLPED=CAUVEH.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NVEHNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUVEHCOVMFL.*
   from
   {rawDB}.CAUVEHCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUVEHCOVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUVEHCOV
on ppol.policyid = CAUVEHCOV.policyid 
and ppol.NEXPNUM = CAUVEHCOV.NEXPNUM
and CAUVEHCOV.NSTANUM=CAUVEH.NSTANUM
and CAUVEHCOV.NPOLPED=CAUVEH.NPOLPED
and CAUVEHCOV.NVEHNUM=CAUVEH.NVEHNUM

union all

select   distinct
concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'), rtrim(CAUGARCOVPRI.LMATCDE)),'-'), rtrim(CAUGARCOVPRI.LCOVDES)),'-'), rtrim(CAUGARCOV.LMATCDE)),'-'), rtrim(CAUGARCOV.LCOVDES)) as COVG_KEY, 
'CA' as LOB_CD,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
to_timestamp('1900-01-01','yyyy-mm-dd') AS ETL_ROW_EFF_DTS,
ifnull(rtrim(CAUGARCOVPRI.LMATCDE), ' ') as COVG_CD,
ifnull(rtrim(CAUGARCOVPRI.LCOVDES), 'Not Defined') COVG_TEXT,
ifnull(rtrim(CAUGARCOV.LMATCDE), ' ') as COVG_PART_CD,
ifnull(rtrim(CAUGARCOV.LCOVDES), 'Not Defined') as COVG_PART_TEXT
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where CAUPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.PolicyID = CAUPOL.PolicyID 
and ppol.nexpnum  = CAUPOL.nexpnum 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where CAUSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA
  on ppol.PolicyID = CAUSTA.PolicyID 
and ppol.nexpnum  = CAUSTA.nexpnum 
and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARLOCMFL.*
   from
   {rawDB}.CAUGARLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARLOCMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARLOC
on ppol.policyid = CAUGARLOC.policyid 
and ppol.NEXPNUM = CAUGARLOC.NEXPNUM
and CAUSTA.NSTANUM=CAUGARLOC.NSTANUM
and CAUPOL.NPOLPED=CAUGARLOC.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARCOVPRIMFL.*
   from
   {rawDB}.CAUGARCOVPRIMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARCOVPRIMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARCOVPRI
on ppol.policyid = CAUGARCOVPRI .policyid 
and ppol.NEXPNUM = CAUGARCOVPRI .NEXPNUM
and CAUGARCOVPRI.NSTANUM=CAUSTA.NSTANUM
and CAUGARCOVPRI.NPOLPED=CAUPOL.NPOLPED
and CAUGARCOVPRI.NLOCNUM=CAUGARLOC.NLOCNUM
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NTYPNUM,NSEQNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARCOVMFL.*
   from
   {rawDB}.CAUGARCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARCOVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARCOV
on ppol.policyid = CAUGARCOV .policyid 
and ppol.NEXPNUM = CAUGARCOV .NEXPNUM
and CAUSTA.NSTANUM=CAUGARCOV.NSTANUM
and CAUPOL.NPOLPED=CAUGARCOV.NPOLPED
and CAUGARLOC.NLOCNUM=CAUGARCOV.NLOCNUM
and CAUGARCOVPRI.NTYPNUM=CAUGARCOV.NTYPNUM
and CAUGARCOVPRI.NSEQNUM= CAUGARCOV.NSEQNUM

union all

select  distinct
concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'), rtrim(CAUGARCCV.LMATCDE)),'-'), rtrim(CAUGARCCV.LDES))  as COVG_KEY,
'CA' as LOB_CD, 
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
to_timestamp('1900-01-01','yyyy-mm-dd') AS ETL_ROW_EFF_DTS,
ifnull(rtrim(CAUGARCCV.LMATCDE), ' ') as COVG_CD,
ifnull(rtrim(CAUGARCCV.LDES), 'Not Defined') as COVG_TEXT,
' ' as COVG_PART_CD,
'Not Defined' as COVG_PART_TEXT   
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where CAUPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.PolicyID = CAUPOL.PolicyID 
and ppol.nexpnum  = CAUPOL.nexpnum 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where CAUSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA
  on ppol.PolicyID = CAUSTA.PolicyID 
and ppol.nexpnum  = CAUSTA.nexpnum 
and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY  PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUGARCCVMFL.*
   from
   {rawDB}.CAUGARCCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUGARCCVMFL.PolicyID 
              )
  ) WHERE rn = 1  )          
   CAUGARCCV
on ppol.policyid = CAUGARCCV .policyid 
and ppol.NEXPNUM = CAUGARCCV .NEXPNUM
and CAUSTA.NSTANUM=CAUGARCCV.NSTANUM
and CAUPOL.NPOLPED=CAUGARCCV.NPOLPED

union all

select  distinct
concat(concat(concat(concat(concat(concat(concat(concat(concat
('HV-',POLEXT6.StringValue),'-'), rtrim(SPCCOV.LCOVTYPCDE)),'-')
,CASE WHEN  rtrim(SPCCOV.LCOVTYPDES) IS NOT NULL AND rtrim(SPCCOV.LCOVTYPDES)<> '' THEN rtrim(SPCCOV.LCOVTYPDES) ELSE 'NULL' END) ,'-') 
 ,CASE WHEN  rtrim(SPCCOV.LSUBCOVCDE) IS NOT NULL AND rtrim(SPCCOV.LSUBCOVCDE)<> '' THEN rtrim(SPCCOV.LSUBCOVCDE) ELSE 'NULL' END) ,'-') 
 ,CASE WHEN  rtrim(SPCCOV.LSUBCOVDES) IS NOT NULL AND rtrim(SPCCOV.LSUBCOVDES)<> '' THEN rtrim(SPCCOV.LSUBCOVDES) ELSE 'NULL' END) 
 as COVG_KEY,
'CA' as LOB_CD,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
to_timestamp('1900-01-01','yyyy-mm-dd') AS ETL_ROW_EFF_DTS,
ifnull(rtrim(SPCCOV.LCOVTYPCDE), ' ') as COVG_CD,
ifnull(rtrim(SPCCOV.LCOVTYPDES), 'Not Defined') as COVG_TEXT,
ifnull(rtrim(SPCCOV.LSUBCOVCDE), ' ') as COVG_PART_CD,
ifnull(rtrim(SPCCOV.LSUBCOVDES), 'Not Defined') as COVG_PART_TEXT 
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where CAUPOLMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.PolicyID = CAUPOL.PolicyID 
and ppol.nexpnum  = CAUPOL.nexpnum 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where CAUSTAMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA
  on ppol.PolicyID = CAUSTA.PolicyID 
and ppol.nexpnum  = CAUSTA.nexpnum 
and CAUPOL.NPOLPED  = CAUSTA.NPOLPED
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOV
on ppol.policyid = SPCCOV.policyid
and ppol.nexpnum = SPCCOV.nexpnum
and SPCCOV.NSTANUM = CAUSTA.NSTANUM
and llob = 'CAU'
and SPCCOV.LCOVTYPCDE IS NOT NULL
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_covg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","COVG_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("COVG_KEY","ETL_ROW_EFF_DTS"),harmonized_table,"COVG_ID","HV-CA") 
    //     queryDF.show(3,false)
}