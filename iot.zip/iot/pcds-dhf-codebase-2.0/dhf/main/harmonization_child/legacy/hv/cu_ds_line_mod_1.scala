// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_ds_cu_line_mod1(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
    
Select --distinct
--TIP modifier
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates

,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum))
,'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY

,'HV-CU-LIA-TIP' as MOD_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-') ,case when BOPSTA.NSTANUM is NULL then (999) else BOPSTA.NSTANUM end)
,'-') ,'LIA-TIP')
as LINE_MOD_KEY 

,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'LIA-TIP' as LINE_MOD_CD
,BOPSTA.LSTACDE as JURS_CD
,BOPSTA.LSTANAM as JURS_TEXT
,1 as MOD_VAL
,BOPSTAEXT2.DoubleValue as SGSTD_MIN_FCTR
,BOPSTAEXT3.DoubleValue as SGSTD_MAX_FCTR
,BOPSTAEXT4.DoubleValue as SGSTD_FCTR
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,'CU' AS LOB_CD
,'HV-CU' AS PARTITION_VAL

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CMB%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 

and ppol.lpolnum like 'CMB%' 
and ppol.neffyrs > 2019
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTA --with (nolock) 
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )BOPSTAEXT2 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and BOPSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'AgtLiaMinDef%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT3 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and BOPSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'AgtLiaMaxDef%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT4 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and BOPSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT6 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT6.PolicyID 
and  BOPSTAEXT6.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT6.NSTANUM
and   BOPSTAEXT6.Name like 'RMFSubjectLiaManPrm%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT7 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT7.PolicyID 
and  BOPSTAEXT7.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT7.NSTANUM
and   BOPSTAEXT7.Name like 'TotLiaMnlPrm%'

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )BOPSTAEXT8 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT8.PolicyID 
and  BOPSTAEXT8.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT8.NSTANUM
and   BOPSTAEXT8.Name like 'RMFSubjectLiaWrtPrm%'

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT9 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT9.PolicyID 
and  BOPSTAEXT9.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT9.NSTANUM
and   BOPSTAEXT9.Name like 'TotLiaWrtPrm%'

UNION--1

Select --distinct
--sched modifier
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates

,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum))
,'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY

,'HV-CU-LIA-SCHED' as MOD_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-') ,case when BOPSTA.NSTANUM is NULL then (999) else BOPSTA.NSTANUM end)
,'-') ,'LIA-SCHED')
as LINE_MOD_KEY 

,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'LIA-SCHED' as LINE_MOD_CD
,BOPSTA.LSTACDE as JURS_CD
,BOPSTA.LSTANAM as JURS_TEXT
,BOPSTA.NIRM2 as MOD_VAL
,BOPSTAEXT2.DoubleValue as SGSTD_MIN_FCTR
,BOPSTAEXT3.DoubleValue as SGSTD_MAX_FCTR
,BOPSTAEXT4.DoubleValue as SGSTD_FCTR
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,'CU' AS LOB_CD
,'HV-CU' AS PARTITION_VAL

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CMB%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 

and ppol.lpolnum like 'CMB%' 
and ppol.neffyrs > 2019
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTA --with (nolock) 
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )BOPSTAEXT2 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and BOPSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'AgtLiaMinDef%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT3 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and BOPSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'AgtLiaMaxDef%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT4 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and BOPSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT6 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT6.PolicyID 
and  BOPSTAEXT6.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT6.NSTANUM
and   BOPSTAEXT6.Name like 'RMFSubjectLiaManPrm%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT7 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT7.PolicyID 
and  BOPSTAEXT7.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT7.NSTANUM
and   BOPSTAEXT7.Name like 'TotLiaMnlPrm%'

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )BOPSTAEXT8 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT8.PolicyID 
and  BOPSTAEXT8.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT8.NSTANUM
and   BOPSTAEXT8.Name like 'RMFSubjectLiaWrtPrm%'

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT9 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT9.PolicyID 
and  BOPSTAEXT9.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT9.NSTANUM
and   BOPSTAEXT9.Name like 'TotLiaWrtPrm%'


UNION--2

Select --distinct
--EXPER modifier
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates

,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum))
,'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY

,'HV-CU-LIA-EXPER' as MOD_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-') ,case when BOPSTA.NSTANUM is NULL then (999) else BOPSTA.NSTANUM end)

,'-') ,'LIA-EXPER')
as LINE_MOD_KEY 

,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'LIA-EXPER' as LINE_MOD_CD
,BOPSTA.LSTACDE as JURS_CD
,BOPSTA.LSTANAM as JURS_TEXT
,1 as MOD_VAL
,BOPSTAEXT2.DoubleValue as SGSTD_MIN_FCTR
,BOPSTAEXT3.DoubleValue as SGSTD_MAX_FCTR
,BOPSTAEXT4.DoubleValue as SGSTD_FCTR
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,'CU' AS LOB_CD
,'HV-CU' AS PARTITION_VAL

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CMB%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 

and ppol.lpolnum like 'CMB%' 
and ppol.neffyrs > 2019
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTA --with (nolock) 
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )BOPSTAEXT2 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and BOPSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'AgtLiaMinDef%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT3 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and BOPSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'AgtLiaMaxDef%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT4 --with (nolock) 
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and BOPSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT6 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT6.PolicyID 
and  BOPSTAEXT6.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT6.NSTANUM
and   BOPSTAEXT6.Name like 'RMFSubjectLiaManPrm%'
  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT7 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT7.PolicyID 
and  BOPSTAEXT7.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT7.NSTANUM
and   BOPSTAEXT7.Name like 'TotLiaMnlPrm%'

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )BOPSTAEXT8 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT8.PolicyID 
and  BOPSTAEXT8.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT8.NSTANUM
and   BOPSTAEXT8.Name like 'RMFSubjectLiaWrtPrm%'

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAEXTMFL.*
   from
   {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) BOPSTAEXT9 --with (nolock) 
on ppol.PolicyID =  BOPSTAEXT9.PolicyID 
and  BOPSTAEXT9.NEXPNUM = ppol.NEXPNUM  
and   BOPSTA.NSTANUM =  BOPSTAEXT9.NSTANUM
and   BOPSTAEXT9.Name like 'TotLiaWrtPrm%'
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batchLINMOD")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_MOD_ID")
    mergeAndWrite(hashDF,List("LINE_MOD_KEY","END_EFF_DT"), harmonized_table, "LINE_MOD_ID","HV-CU")
}