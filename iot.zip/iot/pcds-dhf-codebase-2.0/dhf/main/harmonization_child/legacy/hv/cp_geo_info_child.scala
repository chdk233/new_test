// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_geo_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select -- distinct is used to elimiate duplicates with NEXPNUM > 0
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY -- will show duplicates

--CP LOC_KEY
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when POLLOC.NSTANUM is NULL then ( 999 ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM else case when PRPLOC.NSTANUM is NULL then ( 999 ) else PRPLOC.NSTANUM end end),'-')
,case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end) as LOC_KEY 


,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')

,case when POLLOC.NSTANUM is NULL then ( 999 ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM else case when PRPLOC.NSTANUM is NULL then ( 999 ) else PRPLOC.NSTANUM end end),'-')
,case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)

as GEO_INFO_KEY
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,IF(ISNULL(POLLOCEXT1.StringValue),' ',POLLOCEXT1.StringValue) as COASTAL_IND
,IF(ISNULL(LCNT),' ',IF(charindex('-',LCNT) =0 ,' ',substring(LCNT,charindex('-',LCNT)+1))) as COUNTY_CD -- split at '-' to get code (second part)
,IF(ISNULL(LCNT),' ',IF(charindex('-',LCNT) =0,substring(LCNT,1),substring(LCNT,1,charindex('-',LCNT)-1))) as COUNTY_NAME --split at '-' to get name (first part)
,IF(ISNULL(PRPLOC.LTERCDE),' ',PRPLOC.LTERCDE) as ISO_TERRITORY_CD
,IF(ISNULL(PRPLOC.LETQZNECDE),' ',PRPLOC.LETQZNECDE) as EQ_TERRITORY_ZONE_CD
,IF(ISNULL(PRPLOCEXT1.StringValue),' ',PRPLOCEXT1.StringValue) as FIRE_HYDRANT_DISTANCE_CD
,IF(ISNULL(POLLOCEXT2.StringValue),' ',POLLOCEXT2.StringValue) as FIRE_STATION_NAME
,IF(ISNULL(POLSTA.StringValue),' ',POLSTA.StringValue ) as MUNICIPALITY_CD
,IF(ISNULL(POLLOCEXT3.StringValue),' ',POLLOCEXT3.StringValue)  as TERRITORY_CD
,IF(ISNULL(POLLOCEXT4.StringValue),' ',POLLOCEXT4.StringValue)  as CMRCL_EQ_RATE_TERR_CD
,PRPLOCEXT2.DoubleValue as FIRE_STATION_MILE_DIST_QTY
,'CP' as LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as etl_row_eff_dts
from global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid
and ppol1.lpolnum like 'CP%'
and ppol1.neffyrs > 2009
and w.act_wstid = 11
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
GROUP BY ppol1.lpolnum ,ppol1.NEXPDAT,ppol1.NEFFDAT,w.act_wstid ) ppol1
on ppol1.policyid=ppol.policyid



 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 



left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
            
              )
  ) WHERE rn = 1  )  POLLOC 
on ppol.policyid = POLLOC.policyid
and ppol.NEXPNUM = POLLOC.NEXPNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLOCMFL.*
   from
   {rawDB}.PRPLOCMFL 
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) PRPLOC 
on ppol.PolicyID = PRPLOC.PolicyID
and ppol.nexpnum = PRPLOC.nexpnum
and POLLOC.NLOCNUM = PRPLOC.NLOCNUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBLDMFL.*
   from
   {rawDB}.PRPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDMFL.PolicyID 
            
              )
  ) WHERE rn = 1  )  PRPBLD
on ppol.PolicyID = PRPBLD.PolicyID 
and ppol.nexpnum = PRPBLD.nexpnum 
and POLLOC.NLOCNUM = PRPBLD.NLOCNUM
and PRPLOC.NSTANUM = PRPBLD.NSTANUM
and case when POLLOC.NBLDNUM >0 then POLLOC.NBLDNUm else PRPBLD.NBLDNUM end = PRPBLD.NBLDNUM 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLSTA 
on ppol.PolicyID = POLSTA.PolicyID
and ppol.nexpnum = POLSTA.nexpnum
and case when POLSTA.NLOCNUm >0 then POLSTA.NLOCNUM else PRPLOC.NLOCNUM end = PRPLOC.NLOCNUM
and case when POLSTA.NBLDNUm >0 then POLSTA.NBLDNum else PRPBLD.NBLDNUM end = PRPBLD.NBLDNUM
AND POLSTA.Name like 'TwnCde%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLOCEXTMFL.*
   from
   {rawDB}.PRPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) PRPLOCEXT1 
on ppol.PolicyID = PRPLOCEXT1.PolicyID
and ppol.NEXPNUM = PRPLOCEXT1.NEXPNUM
and PRPLOC.NLOCNUM = PRPLOCEXT1.NLOCNUM
and PRPLOC.NSTANUM = PRPLOCEXT1.NSTANUM
and PRPLOCEXT1.Name like 'PrHydrant%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLOCEXTMFL.*
   from
   {rawDB}.PRPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) PRPLOCEXT2 
on ppol.PolicyID = PRPLOCEXT2.PolicyID
and ppol.NEXPNUM = PRPLOCEXT2.NEXPNUM
and PRPLOC.NLOCNUM = PRPLOCEXT2.NLOCNUM
and PRPLOC.NSTANUM = PRPLOCEXT2.NSTANUM
and PRPLOCEXT2.Name like 'PrFireDept%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLLOCEXT1 
on ppol.PolicyID = POLLOCEXT1.PolicyID
and ppol.NEXPNUM = POLLOCEXT1.NEXPNUM
and POLLOC.NLOCNUM = POLLOCEXT1.NLOCNUM
and POLLOC.NSTANUM = POLLOCEXT1.NSTANUM
and POLLOC.NBLDNUM = POLLOCEXT1.NBLDNUM
and POLLOCEXT1.Name like 'CosInd%'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  )  POLLOCEXT2 
on ppol.PolicyID = POLLOCEXT2.PolicyID
and ppol.NEXPNUM = POLLOCEXT2.NEXPNUM
and POLLOC.NLOCNUM = POLLOCEXT2.NLOCNUM
and POLLOC.NSTANUM = POLLOCEXT2.NSTANUM
and POLLOC.NBLDNUM = POLLOCEXT2.NBLDNUM
and POLLOCEXT2.Name like 'RespFireSta%'



left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  )  POLLOCEXT3 
on ppol.PolicyID = POLLOCEXT3.PolicyID
and ppol.NEXPNUM = POLLOCEXT3.NEXPNUM
and POLLOC.NLOCNUM = POLLOCEXT3.NLOCNUM
and POLLOC.NSTANUM = POLLOCEXT3.NSTANUM
and POLLOC.NBLDNUM = POLLOCEXT3.NBLDNUM  
and POLLOCEXT3.Name like 'PrpTerCde%'



left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,NSTANUM,NLOCNUM,NBLDNUM,Name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  )  POLLOCEXT4 
on ppol.PolicyID = POLLOCEXT4.PolicyID
and ppol.NEXPNUM = POLLOCEXT4.NEXPNUM
and POLLOC.NLOCNUM = POLLOCEXT4.NLOCNUM
and POLLOC.NSTANUM = POLLOCEXT4.NSTANUM
and POLLOC.NBLDNUM = POLLOCEXT4.NBLDNUM
and POLLOCEXT4.Name like 'DefEQTerritory%'

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_HV_CP_GI")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
   queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","GEO_INFO_ID")
  
    mergeAndWrite(hashDF,List("GEO_INFO_KEY","END_EFF_DT"),harmonized_table,"GEO_INFO_ID","HV-CP")
}