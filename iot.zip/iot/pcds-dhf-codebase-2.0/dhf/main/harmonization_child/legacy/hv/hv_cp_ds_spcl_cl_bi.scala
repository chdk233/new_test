// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_spcl_cl_bi(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select 
--CP Special Class Business Income
concat(concat( concat(concat( concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat( concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999 ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM else case when PRPLOC.NSTANUM is NULL then ( 999 ) else PRPLOC.NSTANUM end end),'-')
,case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end),'-')
,case when PRPOCC.NOCCNUM is NULL then (999) else PRPOCC.NOCCNUM end),'-')
,case when PRPCOV.NCOVNUM is NULL then (999) else PRPCOV.NCOVNUM end),'-')
,case when PRPCOV.NSUBCOVNUM is NULL then (999) else PRPCOV.NSUBCOVNUM end),'-')
,case when PRPPRL.NPRLNUM is NULL then (999) else PRPPRL.NPRLNUM end),'-')
--,case when PRPBKT.NBKTNUM is NULL then (999)  else PRPBKT.NBKTNUM end) ,'-')
,case when PRPTME.LTMEMAT is NULL then ('999') else rtrim(PRPTME.LTMEMAT) end ),'-')
,case when T1.dat_bdtid is NULL then (9999)  else T1.dat_bdtid end) 
AS SPCL_CL_BI_KEY

--POLICY KEY CP
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY 
 ,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_LINE_KEY


, CASE WHEN (PRPCOV.NCOVNUM IS NULL ) 

THEN 'NOKEY' ELSE (
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
 ,case when POLLOC.NSTANUM is NULL then ( 999 ) when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM else case when PRPLOC.NSTANUM is NULL then ( 999 ) else PRPLOC.NSTANUM end end),'-')
 ,case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
 ,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end),'-')
 ,case when PRPOCC.NOCCNUM is NULL then (999) else PRPOCC.NOCCNUM end),'-')
 ,case when PRPCOV.NCOVNUM is NULL then (999) else PRPCOV.NCOVNUM end),'-')     
 ,case when PRPCOV.NSUBCOVNUM is NULL then (999) else PRPCOV.NSUBCOVNUM end),'-')      
 --,case when PRPBKT.NBKTNUM is NULL then (999)  else PRPBKT.NBKTNUM end)  ,'-')
 ,case when PRPPRL.NPRLNUM is NULL then (999)  else PRPPRL.NPRLNUM end) ,'-')
 ,case when T1.dat_bdtid is NULL then (999)  else T1.dat_bdtid end) )

END
  AS SPCL_CL_KEY
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT

  ,'HV' as SOURCE_SYSTEM
  ,'CPSpecialClassBusinessIncome' AS CVRBL_TYPE_CD 

,CASE WHEN TRIM(PRPCOV.LAGDAMTTYP)  = 'YES' THEN PRPCOV.NXPS  ELSE NULL END AS AGREED_VAL_LMT
,CASE WHEN TRIM(PRPCOV.NCOVNUM) IN (61,62,63,64,65) AND TRIM(PRPTME.LTMEMAT) ='TMEEEXIND' AND TRIM(LCHC) ='YES' THEN 'Business Income Extra Expense'
      WHEN TRIM(PRPCOV.NCOVNUM) IN (61,62,63,64,65) AND TRIM(PRPTME.LTMEMAT) ='TMEEEXIND' AND TRIM(LCHC) ='NO' THEN 'Business Income WITH OUT Extra Expense'
      WHEN TRIM(PRPCOV.NCOVNUM) IN (66,67) THEN 'Extra Expense Only' end as COVG_TYPE 
   

,CASE WHEN PRPCOV.NBKTNUM<>0 AND PRPPRL.NPRLNUM<>3  THEN PRPCOV.NBKTNUM ELSE NULL END AS BLNKT_ID_NO
 ,case when PRPCOV.NBKTNUM <>0 then PRPCOV.LFRM ELSE NULL END AS BLNKT_LOSS_CAUSE 
  
,CASE WHEN PRPPRL.NPRLNUM <>3 AND PRPCOV.NBKTNUM <>0 THEN 'Y' ELSE 'N' END AS INCL_BLNKT_FL 

,CASE WHEN (TRIM(PRPTME.LTMEMAT)= 'TMEEXTIDM'  AND TRIM(PRPTME.LCHC) <> 'NONE'  AND TRIM(PRPTME.LCHC) <> '' )  THEN 'YES' ELSE 'NO' END AS  EXT_PERIOD_APPL


--RISK_EDU_INST_PCT CP 
   
,CASE  When TRIM(LCOVDES) = 'Business Educational Institute' AND  TRIM(PRPCOV.LTMETYP3) NOT IN ('','NONE') THEN   CAST(REPLACE(LTMETYP3,'%','') AS int)   ELSE NULL END AS  RISK_EDU_INST_PCT
,CASE WHEN PRPCOV.LTMETYP2 LIKE '%MERC%' and TRIM(PRPCOV.NCOVNUM) IN (65,61,81)  AND TRIM(PRPCOV.LTMETYP3) NOT IN ('','NONE') THEN  CAST(REPLACE(LTMETYP3,'%','') AS int)  ELSE NULL END AS RISK_MERC_PCT
,CASE WHEN PRPCOV.LTMETYP2 LIKE '%RENTAL%'  and TRIM(PRPCOV.NCOVNUM) IN (65,61,81) AND TRIM(PRPCOV.LTMETYP3) NOT IN ('','NONE') THEN  CAST(REPLACE(LTMETYP3,'%','') AS int)  ELSE NULL END AS RISK_RENTAL_PCT
,CASE WHEN PRPCOV.LTMETYP2 LIKE '%MFG%'  and TRIM(PRPCOV.NCOVNUM) IN (65,61,81) AND TRIM(PRPCOV.LTMETYP3) NOT IN ('','NONE') THEN  CAST(REPLACE(LTMETYP3,'%','') AS int)  ELSE NULL END AS RISK_MFG_PCT
,CASE WHEN TRIM(PRPCOV.NCOVNUM) = 63 THEN  PRPCOV.LTMETYP3 ELSE 'NA' END  AS MTH_INDEM_LMT_VAL --Bsiness Income monthly
,CASE WHEN TRIM(PRPCOV.NCOVNUM) = 66 THEN  PRPCOV.LTMETYP3 ELSE 'NA' END  AS EXTRA_EXPNS_BSC_LMT_RNG -- Extra Expense
,CASE WHEN TRIM(PRPCOV.NCOVNUM) = 67 THEN  PRPCOV.LTMETYP3 ELSE 'NA' END  AS EXTRA_EXPNS_EXPND_LOSS_LMT_RNG --Extra Expense Expanded

--SPCL_CL_BI_NO CP
  ,PRPCOV.NCOVNUM AS SPCL_CL_BI_NO

--TYPE_RISK_DESC CP
  ,PRPCOV.LTMETYP2 AS RISK_TYPE_DESC 
  ,'CP' as LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  )POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0  
and  POLEXT6.Name like 'PolicyPrefix%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              and mb.nexpnum = POLLocationMFL.nexpnum)
  ) WHERE rn = 1  ) POLLOC  
on ppol.PolicyID = POLLOC.PolicyID 
and ppol.nexpnum = POLLOC.nexpnum  

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLOCMFL.*
   from
   {rawDB}.PRPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCMFL.PolicyID 
              and mb.nexpnum = PRPLOCMFL.nexpnum)
  ) WHERE rn = 1  ) PRPLOC  
on ppol.PolicyID = PRPLOC.PolicyID 
and ppol.nexpnum = PRPLOC.nexpnum 
and POLLOC.NLOCNUM = PRPLOC.NLOCNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBLDMFL.*
   from
   {rawDB}.PRPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDMFL.PolicyID 
              and mb.nexpnum = PRPBLDMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLD  
on ppol.PolicyID = PRPBLD.PolicyID 
and ppol.nexpnum = PRPBLD.nexpnum 
and POLLOC.NLOCNUM = PRPBLD.NLOCNUM
and PRPLOC.NSTANUM = PRPBLD.NSTANUM
and case when POLLOC.NBLDNUM >0 then POLLOC.NBLDNUm else PRPBLD.NBLDNUM end = PRPBLD.NBLDNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPOCCMFL.*
   from
   {rawDB}.PRPOCCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPOCCMFL.PolicyID 
              and mb.nexpnum = PRPOCCMFL.nexpnum )
  ) WHERE rn = 1  )PRPOCC 
on ppol.policyid = PRPOCC.policyid 
and ppol.NEXPNUM = PRPOCC.NEXPNUM 
and PRPLOC.NSTANUM = PRPOCC.NSTANUM
and PRPLOC.NLOCNUM = PRPOCC.NLOCNUM
and PRPOCC.NBLDNUm = PRPBLD.NBLDNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPCLSMFL.*
   from
   {rawDB}.PRPCLSMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPCLSMFL.PolicyID 
              and mb.nexpnum = PRPCLSMFL.nexpnum )
  ) WHERE rn = 1  ) PRPCLS 
on PRPCLS.policyid = ppol.policyid 
and PRPCLS.NEXPNUM = ppol.NEXPNUM 
and PRPCLS.NSTANUM = PRPLOC.NSTANUM
and PRPCLS.NLOCNUM = POLLOC.NLOCNUM
and PRPCLS.NBLDNUM = PRPBLD.NBLDNUM
and PRPCLS.NOCCNUM = PRPOCC.NOCCNUM
and TRIM(PRPCLS.LCSPCDE) in ('1190','1200','0833','1185') 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPCOVMFL.*
   from
   {rawDB}.PRPCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPCOVMFL.PolicyID 
              and mb.nexpnum = PRPCOVMFL.nexpnum )
  ) WHERE rn = 1  )PRPCOV 
on PRPCOV.PolicyID = ppol.PolicyID 
and PRPCOV.NEXPNUM=ppol.NEXPNUM
and PRPCOV.NSTANUM=PRPLOC.NSTANUM
and PRPCOV.NLOCNUM = POLLOC.NLOCNUM
and PRPCOV.NBLDNUM = PRPBLD.NBLDNUM
and PRPCOV.NOCCNUM =PRPOCC.NOCCNUM
and  TRIM(PRPCOV.NCOVNUM) in (67,62,66,61,63,65,64,81,74) 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM,NPRLNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPPRLMFL.*
   from
   {rawDB}.PRPPRLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPPRLMFL.PolicyID 
              and mb.nexpnum = PRPPRLMFL.nexpnum )
  ) WHERE rn = 1  )PRPPRL 
on ppol.policyid =  PRPPRL.policyid 
and ppol.NEXPNUM =  PRPPRL.NEXPNUM
and PRPPRL.NSTANUM = PRPLOC.NSTANUM
and PRPPRL.NLOCNUM = PRPLOC.NLOCNUM
and PRPPRL.NBLDNUM = PRPBLD.NBLDNUM
and PRPPRL.NOCCNUM = PRPOCC.NOCCNUM
and PRPPRL.NCOVNUM= PRPCOV.NCOVNUM
and PRPPRL.NSUBCOVNUM= PRPCOV.NSUBCOVNUM


LEFT  join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM,LTMEMAT ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPTMEMFL.*
   from
   {rawDB}.PRPTMEMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPTMEMFL.PolicyID 
              and mb.nexpnum = PRPTMEMFL.nexpnum )
  ) WHERE rn = 1  ) PRPTME 
on PRPTME.PolicyID = ppol.PolicyID 
and PRPTME.NEXPNUM=ppol.NEXPNUM
and PRPTME.NSTANUM=PRPLOC.NSTANUM
and PRPTME.NLOCNUM = POLLOC.NLOCNUM
and PRPTME.NBLDNUM = PRPBLD.NBLDNUM
and PRPTME.NOCCNUM =PRPOCC.NOCCNUM
and PRPTME.NCOVNUM =PRPCOV.NCOVNUM
and PRPTME.NSUBCOVNUM =PRPCOV.NSUBCOVNUM
and TRIM(PRPTME.LTMEMAT) IN ('TMEEXIND', 'TMEDPNPRP','TMEEXTIDM')
--TMEEXIND : This is for extra expense indicator
--TMEDPNPRP : This is for dependent properties
--TMEEXTIDM : This is for Extended income

left outer Join 
((SELECT DISTINCT POLICYID,NEXPNUM,dat_bdtid,dat_staId FROM 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,dat_bdtId,NCRTNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  POLAttachmentMFL.*
   from
   {rawDB}.POLAttachmentMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAttachmentMFL.PolicyID 
              and mb.nexpnum = POLAttachmentMFL.nexpnum )
  ) WHERE rn = 1  ) )PolAttachment 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY bdtid ORDER BY update_timestamp   DESC ) AS rn
   FROM
   (SELECT  DOCBASEDOCUMENT.*
   from
   {rawDB}.docBaseDocument
   inner join {rawDB}.POLAttachmentMFL PolAttachment
   on DOCBASEDOCUMENT.bdtid = PolAttachment.dat_bdtid
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PolAttachment.PolicyID 
              AND PolAttachment.NEXPNUM=mb.NEXPNUM
              )
  ) WHERE rn = 1  ) docBasedoc
ON docBasedoc.bdtId=  PolAttachment.dat_bdtid  AND  trim(bdtNumber) IN ('CP0017','CP0018','CP0010') ) AS T1
ON T1.PolicyId= PPOL.PolicyID
and T1.NEXPNUM=ppol.nexpnum and  T1.dat_staId = PRPLOC.NSTANUM 

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cp_ds_spcl_cl_bi")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","SPCL_CL_BI_ID")
  
    mergeAndWrite(hashDF,List("SPCL_CL_BI_KEY","END_EFF_DT"), harmonized_table,"SPCL_CL_BI_ID","HV-CP")
 
}