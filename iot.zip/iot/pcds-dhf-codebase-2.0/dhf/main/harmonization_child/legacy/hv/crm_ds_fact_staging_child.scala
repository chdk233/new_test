// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_crm_ds_fact_staging(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(KRMCOV.NSTANUM is null, '999', KRMCOV.NSTANUM)||'-9999-9999-9999-9999-9999-'||IF(KRMCOV.NSEQNUM is null, '999', KRMCOV.NSEQNUM)||'-'||IF(KRMCOV.NCLSNUM is null, '999', KRMCOV.NCLSNUM)||'-'||IF(KRMCOV.NCOVNUM is null, '999', KRMCOV.NCOVNUM)||'-'||IF(KRMCOV.NSECCOVNUM is null, '999', KRMCOV.NSECCOVNUM)||'-COV' AS FACT_STAGE_KEY,
'NOKEY' as MANUSCRIPT,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(KRMCOV.LCOVCDE)||'-'||rtrim(KRMCOV.LSECCOVCDE)||'-'||IF(trim(KRMCOV.LSECCOVDES) = '' or KRMCOV.LSECCOVDES is null, 'NULL', rtrim(KRMCOV.LSECCOVDES))||'-'||IF(trim(KRMCOV.LCOVDES) = '' or KRMCOV.LCOVDES is null, 'NULL', rtrim(KRMCOV.LCOVDES)), 'NOKEY') AS COVG,
'NOKEY' AS MANUSCRIPT_TEMP, 
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CRM' AS PARTITION_VAL,
'CRM' as  LOB_CD,
ifnull(rtrim(KRMCOV.LCOVCDE) , ' ') as COVG_TERM_CD,
ifnull(rtrim(KRMCOV.LCOVDES), 'Not Defined') as COVG_TERM_TEXT,
cast(KRMCOV.NPRM as double) as TERM_VAL_AMT,
ifnull(rtrim(KRMCOV.LSECCOVCDE) ,' ') as COVG_PART_CD,
ifnull(rtrim(KRMCOV.LSECCOVDES) ,'Not Defined') as COVG_PART_TEXT,
cast(KRMCOV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'NOKEY' AS TEMP_KEY
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'CR%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CR%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT1
on ppol.PolicyID = POLEXT1.PolicyID 
and ppol.nexpnum = POLEXT1.nexpnum 
and POLEXT1.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NCLSNUM,NCOVNUM,NSECCOVNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  KRMCOVV02MFL.*
   from
   {rawDB}.KRMCOVV02MFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = KRMCOVV02MFL.PolicyID 
              ) ) WHERE rn = 1  ) KRMCOV  
on ppol.PolicyID = KRMCOV.PolicyID 
and ppol.nexpnum = KRMCOV.nexpnum

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(SPCCOV.NSTANUM is null, '999', SPCCOV.NSTANUM)||'-'||IF(SPCCOV.NLOCNUM is null, '999', SPCCOV.NLOCNUM)||'-'||IF(SPCCOV.NBLDNUM is null, '999', SPCCOV.NBLDNUM)||'-'||IF(SPCCOV.LCOVTYPCDE is null, '999', SPCCOV.LCOVTYPCDE)||'-'||IF(trim(SPCCOV.LCOVTYPDES) = '' or SPCCOV.LCOVTYPDES is null, 'NULL', rtrim(SPCCOV.LCOVTYPDES))||'-'||IF(SPCCOV.LSUBCOVCDE is null, '999', SPCCOV.LSUBCOVCDE)||'-'||IF(SPCCOV.NSEQNUM is null, '999', SPCCOV.NSEQNUM)||'-9999-9999-9999-SPC' AS FACT_STAGE_KEY,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(SPCCOV.NSTANUM is null, '999', SPCCOV.NSTANUM)||'-'||IF(SPCCOV.NLOCNUM is null, '999', SPCCOV.NLOCNUM)||'-'||IF(SPCCOV.NBLDNUM is null, '999', SPCCOV.NBLDNUM)||'-'||IF(SPCCOV.NSEQNUM is null, '999', SPCCOV.NSEQNUM)||'-'||IF(SPCCOV.LSUBCOVCDE is null, 'NULL', SPCCOV.LSUBCOVCDE), 'NOKEY') as MANUSCRIPT,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(SPCCOV.LCOVTYPCDE)||'-'||IF(trim(SPCCOV.LCOVTYPDES) = '' or SPCCOV.LCOVTYPDES is null, 'NULL', rtrim(SPCCOV.LCOVTYPDES))||'-'||IF(trim(SPCCOV.LSUBCOVDES) = '' or SPCCOV.LSUBCOVDES is null, 'NULL', rtrim(SPCCOV.LSUBCOVDES)), 'NOKEY') AS COVG,
ifnull(SPCCOV.LCOVTYPCDE||'-'||SPCCOV.LSUBCOVCDE , 'NOKEY') AS MANUSCRIPT_TEMP, 
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CRM' AS PARTITION_VAL,
'CRM' as  LOB_CD,
ifnull(rtrim(SPCCOV.LCOVTYPCDE) , ' ') as COVG_TERM_CD,
ifnull(rtrim(SPCCOV.LCOVTYPDES), 'Not Defined') as COVG_TERM_TEXT,
cast(SPCCOV.NPRM as double) as TERM_VAL_AMT,
ifnull(rtrim(SPCCOV.LSUBCOVCDE) ,' ') as COVG_PART_CD,
ifnull(rtrim(SPCCOV.LSUBCOVDES) ,'Not Defined') as COVG_PART_TEXT,
cast(SPCCOV.NANNPRM as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
ifnull('HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(POLLOC.NSTANUM is null, '999', POLLOC.NSTANUM)||'-'||IF(POLLOC.NLOCNUM is null, '999', POLLOC.NLOCNUM)||'-'||IF(POLLOC.NBLDNUM is null, '999', POLLOC.NBLDNUM), 'NOKEY') AS TEMP_KEY
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'CR%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CR%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT1
on ppol.PolicyID = POLEXT1.PolicyID 
and ppol.nexpnum = POLEXT1.nexpnum 
and POLEXT1.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NCRTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOV
on ppol.policyid = SPCCOV.policyid 
and ppol.NEXPNUM = SPCCOV.NEXPNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLLOC  
on ppol.PolicyID = POLLOC.PolicyID 
and ppol.nexpnum = POLLOC.nexpnum
and POLLOC.NLOCNUM =SPCCOV.NLOCNUM
where SPCCOV.LCOVTYPCDE is NOT NULL

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||IF(POLTAX.NSTANUM is null, '999', POLTAX.NSTANUM)||'-9999-9999-'||IF(POLTAX.NKEY1 is null, '999', POLTAX.NKEY1)||'-'||IF(POLTAX.NKEY2 is null, '999', POLTAX.NKEY2)||'-'||IF(POLTAX.NKEY3 is null, '999', POLTAX.NKEY3)||'-'||IF(POLTAX.NKEY4 is null, '999', POLTAX.NKEY4)||'-'||IF(POLTAX.NKEY5 is null, '999', POLTAX.NKEY5)||'-'||IF(POLTAX.NKEY6 is null, '999', POLTAX.NKEY6)||'-9999-SURCHARGE' AS FACT_STAGE_KEY,
'NOKEY' as MANUSCRIPT,
'NOKEY' AS COVG,
'NOKEY' AS MANUSCRIPT_TEMP, 
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-CRM' AS PARTITION_VAL,
'CRM' as  LOB_CD,
' ' as COVG_TERM_CD,
ifnull(rtrim(POLTAX.LDES), 'Not Defined') as COVG_TERM_TEXT,
cast(POLTAX.NPRM as double) as TERM_VAL_AMT,
' ' as COVG_PART_CD,
'Not Defined' as COVG_PART_TEXT,
cast(POLTAX.NPRMANN as double) as TEMP_ANNUAL_PREM_AMT,
to_date(POLEXT1.stringvalue, 'MM/dd/yyyy') as TRANS_PROC_DTS,
ifnull(rtrim(v3x.LPOLSTS)||'-'||rtrim(v3x.LPRITCTTYP), ' ') as TRANS_CD,
ifnull(rtrim(v3x.LPRITCTTYP), ' ') as TRANS_ALLOC_CD,
'NOKEY' AS TEMP_KEY
from 
global_temp.polpolmfl_micro_batch micro_ppol INNER JOIN ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb  on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM)  ) WHERE rn = 1  ) ppol on micro_ppol.PolicyID = ppol.PolicyID and micro_ppol.NEXPNUM = ppol.NEXPNUM
inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn FROM (SELECT  polpolmfl.* from {rawDB}.polpolmfl inner join global_temp.polpolmfl_micro_batch mb on   mb.PolicyID = polpolmfl.PolicyID and mb.NEXPNUM = polpolmfl.NEXPNUM )) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
and ppol1.lpolnum like 'CR%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn FROM (SELECT  WRKACTIVITY.* from {rawDB}.WRKACTIVITY inner join global_temp.polpolmfl_micro_batch mb on   mb.policyid = WRKACTIVITY.actpolicyid )) WHERE rn = 1  ) w on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CR%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              ) ) WHERE rn = 1  ) POLEXT1
on ppol.PolicyID = POLEXT1.PolicyID 
and ppol.nexpnum = POLEXT1.nexpnum 
and POLEXT1.Name like '%TctDat%' 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLV3XMFL.*
   from
   {rawDB}.POLPOLV3XMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLV3XMFL.PolicyID
                   and 	mb.NEXPNUM=POLPOLV3XMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) v3x
on ppol.policyid = v3x.policyid 
and ppol.NEXPNUM = v3x.NEXPNUM
inner join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LLOB,NSTANUM,NKEY1,NKEY2,NKEY3,NKEY4,NKEY5,NKEY6 ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLTAXMFL.*
   from
   {rawDB}.POLTAXMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLTAXMFL.PolicyID
                   and 	mb.NEXPNUM=POLTAXMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) POLTAX
on ppol.policyid = POLTAX.policyid 
and ppol.NEXPNUM = POLTAX.NEXPNUM
"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_crm_ds_fact_staging")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","FACT_STAGE_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("FACT_STAGE_KEY","END_EFF_DT"),harmonized_table,"FACT_STAGE_ID","HV-CRM") 
}