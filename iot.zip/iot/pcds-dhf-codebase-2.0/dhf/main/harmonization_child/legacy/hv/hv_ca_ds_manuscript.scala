// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_manuscript(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select DISTINCT 

concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when CAUSTA.NSTANUM is null then (999) else CAUSTA.NSTANUM end),'-')
,case when SPCCOV.NLOCNUM is null then (999) else SPCCOV.NLOCNUM end),'-')
,case when SPCCOV.NBLDNUM is null then (999) else SPCCOV.NBLDNUM end),'-')
,case when SPCCOV.NSEQNUM is null then (999) else SPCCOV.NSEQNUM end),'-')
,case when SPCCOVEXT3.StringValue is NOT NULL THEN case when SPCCOV1.NSEQNUM is null then (999) else SPCCOV1.NSEQNUM END ELSE 9999 END ),'-')
,case when SPCCOV.LCOVTYPCDE is null then ('NULL') else SPCCOV.LCOVTYPCDE end),'-')
,case when SPCCOV.LSUBCOVCDE is null then 'NULL' ELSE SPCCOV.LSUBCOVCDE end),'-')
,case when SPCCOVEXT3.StringValue is NOT NULL THEN  CASE WHEN SPCCOV1.LSUBCOVCDE is null then 'NULL' ELSE SPCCOV1.LSUBCOVCDE end ELSE '9999' END )

as MANUSCRIPT_KEY 
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,SPCCOVEXT1.StringValue AS MANUSCRIPT_CVRG_DESC
,'HV' as SOURCE_SYSTEM

,Case 
when SPCCOVEXT2.StringValue like 'MCA%' or SPCCOVEXT2.StringValue like  'CA%' or SPCCOVEXT2.StringValue like  'IL%'  
or SPCCOVEXT2.StringValue like  'CO-10%'or SPCCOVEXT2.StringValue like  'MIL%' or SPCCOVEXT2.StringValue like 'ST%'
then Substring (SPCCOVEXT2.StringValue,1,CHARINDEX(' ', SPCCOVEXT2.StringValue))
else SPCCOVEXT2.StringValue end as MANUSCRIPT_NO

,SPCCOV.LSUBCOVCDE as MANUSCRIPT_TYPE_CD
,SPCCOV.LCOVTYPDES as MANUSCRIPT_TYPE_TEXT
,SPCCOVEXT2.StringValue AS MANUSCRIPT_TTL
,CASE WHEN (SPCCOVEXT3.StringValue IS NOT NULL AND SPCCOVEXT3.StringValue IN (LEFT(SPCCOVEXT2.STRINGVALUE,8), LEFT(SPCCOVEXT2.STRINGVALUE,7)))THEN  SPCCOV1.NANNPRM  ELSE NULL END AS MANUSCRIPT_PREM_AMT
,'CA' AS LOB_CD
,'HV-CA' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs like '%2020%'
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity like '%2020%' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID )) WHERE rn = 1  )POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'

left outer Join( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID
              and mb.nexpnum = CAUPOLMFL.nexpnum)) WHERE rn = 1  )  CAUPOL 
on ppol.policyid = CAUPOL.policyid 
and ppol.NEXPNUM = CAUPOL.NEXPNUM

left outer Join( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID
              and mb.nexpnum = CAUSTAMFL.nexpnum)) WHERE rn = 1  ) CAUSTA 
on ppol.policyid = CAUSTA.policyid 
and ppol.NEXPNUM = CAUSTA.NEXPNUM
and CAUSTA.NPOLPED=CAUPOL.NPOLPED

INNER Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
              and mb.nexpnum = SPCCOVMFL.nexpnum)) WHERE rn = 1  ) SPCCOV  
on ppol.PolicyID = SPCCOV.PolicyID 
and ppol.nexpnum = SPCCOV.nexpnum   
and SPCCOV.LLOB = 'CAU'
and SPCCOV.nstanum = CAUSTA.Nstanum
and (SPCCOV.LCOVTYPDES like '%MANUSCRIPT EXCLUSION%' or  SPCCOV.LCOVTYPDES like '%MANUSCRIPT ENDORSEMENT%') -- Building records only for Manuscript Endorsements and Exclusions

---Manuscript Text :We need this field only when Manuscript EXCLUSION/MANUSCRIPT ENDORSEMENT coverage is present
left outer Join
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,LLOB,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
              and mb.nexpnum = SPCCOVEXTMFL.nexpnum)) WHERE rn = 1  ) SPCCOVEXT1  
on ppol.PolicyID = SPCCOVEXT1.PolicyID 
and ppol.nexpnum = SPCCOVEXT1.nexpnum   
and  SPCCOV.NSTANUM = SPCCOVEXT1.NSTANUM
and  SPCCOV.NLOCNUM = SPCCOVEXT1.NLOCNUM
and  SPCCOV.NBLDNUM = SPCCOVEXT1.NBLDNUM
and  SPCCOV.NSEQNUM = SPCCOVEXT1.NSEQNUM
and SPCCOV.LCOVTYPCDE =SPCCOVEXT1.LCOVTYPCDE
and SPCCOV.LSUBCOVCDE =SPCCOVEXT1.LSUBCOVCDE
and SPCCOV.LLOB =SPCCOVEXT1.LLOB
and SPCCOV.NPOLPED =SPCCOVEXT1.NPOLPED
and SPCCOVEXT1.Name like '%Txt%'

---Manuscript Title :We need this field only when Manuscript Exclusion/MANUSCRIPT ENDORSEMENT coverage is present
left outer Join
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,LLOB,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
              and mb.nexpnum = SPCCOVEXTMFL.nexpnum)) WHERE rn = 1  )SPCCOVEXT2  
on ppol.PolicyID = SPCCOVEXT2.PolicyID 
and ppol.nexpnum = SPCCOVEXT2.nexpnum   
and  SPCCOV.NSTANUM = SPCCOVEXT2.NSTANUM
and  SPCCOV.NLOCNUM = SPCCOVEXT2.NLOCNUM
and  SPCCOV.NBLDNUM = SPCCOVEXT2.NBLDNUM
and  SPCCOV.NSEQNUM = SPCCOVEXT2.NSEQNUM
and SPCCOV.LCOVTYPCDE =SPCCOVEXT2.LCOVTYPCDE
and SPCCOV.LSUBCOVCDE =SPCCOVEXT2.LSUBCOVCDE
and SPCCOV.LLOB =SPCCOVEXT2.LLOB
and SPCCOV.NPOLPED =SPCCOVEXT2.NPOLPED
and SPCCOVEXT2.Name like '%Ttl%'

LEFT OUTER Join
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
              and mb.nexpnum = SPCCOVMFL.nexpnum)) WHERE rn = 1  ) SPCCOV1  ---Thi will Include the Manual Premium Coverage if available.
on SPCCOV.PolicyID = SPCCOV1.PolicyID 
and SPCCOV.nexpnum = SPCCOV1.nexpnum   
and SPCCOV1.LLOB = 'CAU'
and ( SPCCOV.NSTANUM = SPCCOV1.NSTANUM )
and  SPCCOV.NLOCNUM = SPCCOV1.NLOCNUM
and  (SPCCOV.NBLDNUM = SPCCOV1.NBLDNUM )
and SPCCOV.NPOLPED =SPCCOV1.NPOLPED
and  upper(SPCCOV1.LCOVTYPDES) like '%MANUAL%'
and SPCCOV.LCOVTYPDES like '%MANUSCRIPT ENDORSEMENT%'

left outer Join
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NLOCNUM,NBLDNUM,LLOB,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM(SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
              and mb.nexpnum = SPCCOVEXTMFL.nexpnum)) WHERE rn = 1  )SPCCOVEXT3  
on ppol.PolicyID = SPCCOVEXT3.PolicyID 
and ppol.nexpnum = SPCCOVEXT3.nexpnum   
and  SPCCOV1.NSTANUM = SPCCOVEXT3.NSTANUM
and  SPCCOV1.NLOCNUM = SPCCOVEXT3.NLOCNUM
and  SPCCOV1.NBLDNUM = SPCCOVEXT3.NBLDNUM
and  SPCCOV1.NSEQNUM = SPCCOVEXT3.NSEQNUM
and SPCCOV1.LCOVTYPCDE =SPCCOVEXT3.LCOVTYPCDE
and SPCCOV1.LSUBCOVCDE = SPCCOVEXT3.LSUBCOVCDE 
and SPCCOV1.LLOB =SPCCOVEXT3.LLOB
and SPCCOV1.NPOLPED =SPCCOVEXT3.NPOLPED
and SPCCOVEXT3.Name like '%FrmNum%'
and (SPCCOVEXT3.StringValue IS NOT NULL OR TRIM(SPCCOVEXT3.StringValue) <>'')
and SPCCOVEXT3.StringValue IN (LEFT(SPCCOVEXT2.STRINGVALUE,8), LEFT(SPCCOVEXT2.STRINGVALUE,7))
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_manuscript")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","MANUSCRIPT_ID")
  
    mergeAndWrite(hashDF,List("MANUSCRIPT_KEY","END_EFF_DT"), harmonized_table,"MANUSCRIPT_ID","HV-CA")
 
}