// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_gar_srvc(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(CAUSTA.NSTANUM is NULL, '999', CAUSTA.NSTANUM)||'-9999-'||if(CAUCCVPRI.NTYPNUM is NULL, '999', CAUCCVPRI.NTYPNUM)||'-'||if(CAUCCVPRI.NSEQNUM is NULL, '999', CAUCCVPRI.NSEQNUM) AS GAR_SRVC_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(CAUCCVPRI.NSTANUM is NULL, '999', CAUCCVPRI.NSTANUM)||'-9999-'||if(CAUCCVPRI.LTERCDE is NULL, 'NULL', CAUCCVPRI.LTERCDE)||'-'||if(CAUCCVPRI.LTERZIP is NULL, 'NULL', CAUCCVPRI.LTERZIP)||'-'||if(CAUCCVPRI.LTERCTY is NULL or trim(CAUCCVPRI.LTERCTY) = '', 'NULL', CAUCCVPRI.LTERCTY) AS GARAGE_SRVC_LOC_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
'CA' as LOB_CD,
'CALine' as CVRBL_TYPE_CD,
IF(trim(CAUCCV.LIND) = 'YES', 'Y', 'N') as EMP_AS_INS_FL,
cast(CAUCCVPRI.NXPS1 as double) as EMP_CNT_NO,
cast(CAUCCVPRI1.NXPS1 as double) as PARTNERS_CNT_NO
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.policyid = CAUPOL.policyid 
and ppol.NEXPNUM = CAUPOL.NEXPNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA  
on ppol.policyid = CAUSTA.policyid 
and ppol.NEXPNUM = CAUSTA.NEXPNUM
and CAUSTA.NPOLPED=CAUPOL.NPOLPED
inner Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVPRIMFL.*
   from
   {rawDB}.CAUCCVPRIMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVPRIMFL.PolicyID 
            
--               where CAUCCVPRIMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUCCVPRI  
on ppol.policyid = CAUCCVPRI.policyid 
and ppol.NEXPNUM = CAUCCVPRI.NEXPNUM  
and CAUSTA.NSTANUM= CAUCCVPRI.NSTANUM
and CAUSTA.NPOLPED= CAUCCVPRI.NPOLPED
and trim(CAUCCVPRI.LMATCDE) = 'NONSRV'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVPRIMFL.*
   from
   {rawDB}.CAUCCVPRIMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVPRIMFL.PolicyID 
            
--               where CAUCCVPRIMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUCCVPRI1
on ppol.policyid = CAUCCVPRI1.policyid 
and ppol.NEXPNUM = CAUCCVPRI1.NEXPNUM  
and CAUSTA.NSTANUM= CAUCCVPRI1.NSTANUM
and CAUSTA.NPOLPED= CAUCCVPRI1.NPOLPED
and trim(CAUCCVPRI1.LMATCDE) = 'NONSRV'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NTYPNUM,NSEQNUM,NCOVNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUCCVMFL.*
   from
   {rawDB}.CAUCCVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUCCVMFL.PolicyID 
            
--               where CAUCCVMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUCCV
on ppol.policyid = CAUCCV.policyid 
and ppol.NEXPNUM = CAUCCV.NEXPNUM  
and CAUCCVPRI.NSTANUM= CAUCCV.NSTANUM
and CAUCCVPRI.NPOLPED= CAUCCV.NPOLPED
and CAUCCVPRI.NTYPNUM= CAUCCV.NTYPNUM
and CAUCCVPRI.NSEQNUM= CAUCCV.NSEQNUM
AND trim(CAUCCV.LMATCDE) = 'NONSIE'

UNION ALL

Select
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_LINE_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(CAUSTA.NSTANUM is NULL, '999', CAUSTA.NSTANUM)||'-'||if(SPCCOV.NLOCNUM is NULL, '999', SPCCOV.NLOCNUM)||'-9999-'||if(SPCCOV.NSEQNUM is NULL, '999', SPCCOV.NSEQNUM) AS GAR_SRVC_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(SPCCOV.NSTANUM is NULL, '999', SPCCOV.NSTANUM)||'-'||if(SPCCOV.NLOCNUM is NULL, '999', SPCCOV.NLOCNUM)||'-'||if(SPCCOVEXT1.STRINGVALUE is NULL, 'NULL', SPCCOVEXT1.STRINGVALUE)||'-'||if(SPCCOVEXT2.STRINGVALUE is NULL, 'NULL', SPCCOVEXT2.STRINGVALUE)||'-'||if(SPCCOVEXT3.STRINGVALUE is NULL or trim(SPCCOVEXT3.STRINGVALUE) = '', 'NULL', SPCCOVEXT3.STRINGVALUE) AS GARAGE_SRVC_LOC_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
'CA' as LOB_CD,
'CALine' as CVRBL_TYPE_CD,
'U' as EMP_AS_INS_FL,
'9999' as EMP_CNT_NO,
'9999' as PARTNERS_CNT_NO 
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BA%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BA%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUPOLMFL.*
   from
   {rawDB}.CAUPOLMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUPOLMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUPOL  
on ppol.policyid = CAUPOL.policyid 
and ppol.NEXPNUM = CAUPOL.NEXPNUM
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  CAUSTAMFL.*
   from
   {rawDB}.CAUSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = CAUSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) CAUSTA  
on ppol.policyid = CAUSTA.policyid 
and ppol.NEXPNUM = CAUSTA.NEXPNUM
and CAUSTA.NPOLPED=CAUPOL.NPOLPED
inner Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOV
ON SPCCOV.POLICYID = PPOL.POLICYID
and SPCCOV.NEXPNUM=ppol.NEXPNUM
and SPCCOV.NSTANUM= CAUSTA.NSTANUM
and trim(SPCCOV.LLOB) = 'CAU'
and trim(SPCCOV.LCOVTYPDES)= 'CA-9937 - GARAGEKEEPERS'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVEXTMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOVEXT1
ON SPCCOVEXT1.POLICYID = PPOL.POLICYID
and SPCCOVEXT1.NEXPNUM=ppol.NEXPNUM
and SPCCOVEXT1.NSTANUM= SPCCOV.NSTANUM
and SPCCOVEXT1.NLOCNUM= SPCCOV.NLOCNUM
and SPCCOVEXT1.NBLDNUM= SPCCOV.NBLDNUM
and SPCCOVEXT1.LLOB =SPCCOV.LLOB
and SPCCOVEXT1.LCOVTYPCDE= SPCCOV.LCOVTYPCDE
and SPCCOVEXT1.LSUBCOVCDE= SPCCOV.LSUBCOVCDE
and SPCCOVEXT1.NSEQNUM= SPCCOV.NSEQNUM
AND trim(SPCCOVEXT1.NAME) = 'TerCde'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVEXTMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOVEXT2
ON SPCCOVEXT2.POLICYID = PPOL.POLICYID
and SPCCOVEXT2.NEXPNUM=ppol.NEXPNUM
and SPCCOVEXT2.NSTANUM= SPCCOV.NSTANUM
and SPCCOVEXT2.NLOCNUM= SPCCOV.NLOCNUM
and SPCCOVEXT2.NBLDNUM= SPCCOV.NBLDNUM
and SPCCOVEXT2.LLOB =SPCCOV.LLOB
and SPCCOVEXT2.LCOVTYPCDE= SPCCOV.LCOVTYPCDE
and SPCCOVEXT2.LSUBCOVCDE= SPCCOV.LSUBCOVCDE
and SPCCOVEXT2.NSEQNUM= SPCCOV.NSEQNUM
AND trim(SPCCOVEXT1.NAME) = 'TerZip'
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,LLOB,NLOCNUM,NBLDNUM,LCOVTYPCDE,LSUBCOVCDE,NSEQNUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVEXTMFL.NEXPNUM 
              ) ) WHERE rn = 1  ) SPCCOVEXT3
ON SPCCOVEXT3.POLICYID = PPOL.POLICYID
and SPCCOVEXT3.NEXPNUM=ppol.NEXPNUM
and SPCCOVEXT3.NSTANUM= SPCCOV.NSTANUM
and SPCCOVEXT3.NLOCNUM= SPCCOV.NLOCNUM
and SPCCOVEXT3.NBLDNUM= SPCCOV.NBLDNUM
and SPCCOVEXT3.LLOB =SPCCOV.LLOB
and SPCCOVEXT3.LCOVTYPCDE= SPCCOV.LCOVTYPCDE
and SPCCOVEXT3.LSUBCOVCDE= SPCCOV.LSUBCOVCDE
and SPCCOVEXT3.NSEQNUM= SPCCOV.NSEQNUM
AND trim(SPCCOVEXT1.NAME) = 'TerCty'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_ca_ds_gar_srvc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","GAR_SRVC_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("GAR_SRVC_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"GAR_SRVC_ID","HV-CA") 
    //     queryDF.show(3,false)
}