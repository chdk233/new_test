// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_line_mod_1(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select 
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
-- Line Mod Key
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when BOPSTA.NSTANUM is NULL then (999) else   BOPSTA.NSTANUM  end),'-') 
,'CAPPING') as LINE_MOD_KEY
,'HV-COP-CAPPING'  as MOD_KEY
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'CAPPING' as LINE_MOD_CD
, case when BOPSTA.NSTANUM is not NULL then '1.000'end  as MOD_VAL
,BOPSTA.LSTACDE as JURS_CD
,BOPSTA.LSTANAM as JURS_TEXT
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT2.DoubleValue is null then '1' else BOPSTAEXT2.DoubleValue end as SGSTD_MIN_FCTR
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT3.DoubleValue is null then '1' else BOPSTAEXT3.DoubleValue end as SGSTD_MAX_FCTR
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT4.DoubleValue is null then '1' else BOPSTAEXT4.DoubleValue end as SGSTD_FCTR
--Newly included fields in DB
,BOPSTAEXT5.DoubleValue as TOTAL_MANUAL_PREMIUM 
,BOPSTAEXT6.DoubleValue as TOTAL_WRITTEN_PREMIUM 
,BOPSTAEXT7.DoubleValue as ELIGIBLE_MANUAL_PREMIUM
,BOPSTAEXT8.DoubleValue AS ELIGIBLE_WRITTEN_PREMIUM
,'COP' as LOB_CD
,'HV-COP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'

left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAMFL.NEXPNUM

              )
  ) WHERE rn = 1  )BOPSTA  
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT2  
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT2.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'LiaMinDef%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT3  
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT3.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'LiaMaxDef%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT4  
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT4.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT5  
on ppol.PolicyID = BOPSTAEXT5.PolicyID 
and ppol.nexpnum = BOPSTAEXT5.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT5.NSTANUM
and BOPSTAEXT5.Name like 'TotLiaMnlPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT6  
on ppol.PolicyID = BOPSTAEXT6.PolicyID 
and ppol.nexpnum = BOPSTAEXT6.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT6.NSTANUM
and BOPSTAEXT6.Name like 'TotLiaWrtPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT7  
on ppol.PolicyID = BOPSTAEXT7.PolicyID 
and ppol.nexpnum = BOPSTAEXT7.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT7.NSTANUM
and BOPSTAEXT7.Name like 'RMFSubjectLiaManPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT8  
on ppol.policyid = BOPSTAEXT8.policyid 
and ppol.NEXPNUM = BOPSTAEXT8.NEXPNUM  
and BOPSTA.NSTANUM= BOPSTAEXT8.NSTANUM
and BOPSTAEXT8.Name like 'RMFSubjectLiaWrtPrm%'

Union All
--TIP
Select 
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
-- Line Mod Key
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when BOPSTA.NSTANUM is NULL then (999) else   BOPSTA.NSTANUM  end),'-') 
,'TIP') as LINE_MOD_KEY
,'HV-COP-TIP'  as MOD_KEY
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'TIP' as LINE_MOD_CD
, case when BOPSTA.NSTANUM is not NULL then '1.000'end  as MOD_VAL
,BOPSTA.LSTACDE as JURS_CD
,BOPSTA.LSTANAM as JURS_TEXT
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT2.DoubleValue is null then '1' else BOPSTAEXT2.DoubleValue end as SGSTD_MIN_FCTR
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT3.DoubleValue is null then '1' else BOPSTAEXT3.DoubleValue end as SGSTD_MAX_FCTR
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT4.DoubleValue is null then '1' else BOPSTAEXT4.DoubleValue end as SGSTD_FCTR
--Newly included fields in DB
,BOPSTAEXT5.DoubleValue as TOTAL_MANUAL_PREMIUM 
,BOPSTAEXT6.DoubleValue as TOTAL_WRITTEN_PREMIUM 
,BOPSTAEXT7.DoubleValue as ELIGIBLE_MANUAL_PREMIUM
,BOPSTAEXT8.DoubleValue AS ELIGIBLE_WRITTEN_PREMIUM
,'COP' as LOB_CD
,'HV-COP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'

left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAMFL.NEXPNUM

              )
  ) WHERE rn = 1  ) BOPSTA  
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT2  
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT2.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'LiaMinDef%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT3  
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT3.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'LiaMaxDef%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT4  
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT4.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT5  
on ppol.PolicyID = BOPSTAEXT5.PolicyID 
and ppol.nexpnum = BOPSTAEXT5.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT5.NSTANUM
and BOPSTAEXT5.Name like 'TotLiaMnlPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT6  
on ppol.PolicyID = BOPSTAEXT6.PolicyID 
and ppol.nexpnum = BOPSTAEXT6.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT6.NSTANUM
and BOPSTAEXT6.Name like 'TotLiaWrtPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT7  
on ppol.PolicyID = BOPSTAEXT7.PolicyID 
and ppol.nexpnum = BOPSTAEXT7.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT7.NSTANUM
and BOPSTAEXT7.Name like 'RMFSubjectLiaManPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT8  
on ppol.policyid = BOPSTAEXT8.policyid 
and ppol.NEXPNUM = BOPSTAEXT8.NEXPNUM  
and BOPSTA.NSTANUM= BOPSTAEXT8.NSTANUM
and BOPSTAEXT8.Name like 'RMFSubjectLiaWrtPrm%'

Union All
--DEREGULATION
Select 
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
-- Line Mod Key
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when BOPSTA.NSTANUM is NULL then (999) else   BOPSTA.NSTANUM  end),'-') 
,'DEREG') as LINE_MOD_KEY
,'HV-COP-DEREG'  as MOD_KEY
,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'DEREG' as LINE_MOD_CD
, case when BOPSTA.NSTANUM is not NULL then '1.000'end  as MOD_VAL
,BOPSTA.LSTACDE as JURS_CD
,BOPSTA.LSTANAM as JURS_TEXT
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT2.DoubleValue is null then '1' else BOPSTAEXT2.DoubleValue end as SGSTD_MIN_FCTR
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT3.DoubleValue is null then '1' else BOPSTAEXT3.DoubleValue end as SGSTD_MAX_FCTR
,Case when BOPSTA.LSTACDE is not null and BOPSTAEXT4.DoubleValue is null then '1' else BOPSTAEXT4.DoubleValue end as SGSTD_FCTR
--Newly included fields in DB
,BOPSTAEXT5.DoubleValue as TOTAL_MANUAL_PREMIUM 
,BOPSTAEXT6.DoubleValue as TOTAL_WRITTEN_PREMIUM 
,BOPSTAEXT7.DoubleValue as ELIGIBLE_MANUAL_PREMIUM
,BOPSTAEXT8.DoubleValue AS ELIGIBLE_WRITTEN_PREMIUM
,'COP' as LOB_CD
,'HV-COP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  )  w
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'

left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAMFL.NEXPNUM

              )
  ) WHERE rn = 1  ) BOPSTA  
on ppol.PolicyID = BOPSTA.PolicyID 
and ppol.nexpnum = BOPSTA.nexpnum 

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT2  
on ppol.PolicyID = BOPSTAEXT2.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT2.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT2.NSTANUM
and  BOPSTAEXT2.Name like 'LiaMinDef%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT3  
on ppol.PolicyID = BOPSTAEXT3.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT3.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT3.NSTANUM
and  BOPSTAEXT3.Name like 'LiaMaxDef%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT4  
on ppol.PolicyID = BOPSTAEXT4.PolicyID 
and ppol.NEXPNUM  = BOPSTAEXT4.NEXPNUM  
and BOPSTA.NSTANUM = BOPSTAEXT4.NSTANUM
and  BOPSTAEXT4.Name like 'LiaDefFac%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT5  
on ppol.PolicyID = BOPSTAEXT5.PolicyID 
and ppol.nexpnum = BOPSTAEXT5.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT5.NSTANUM
and BOPSTAEXT5.Name like 'TotLiaMnlPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT6  
on ppol.PolicyID = BOPSTAEXT6.PolicyID 
and ppol.nexpnum = BOPSTAEXT6.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT6.NSTANUM
and BOPSTAEXT6.Name like 'TotLiaWrtPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  ) BOPSTAEXT7  
on ppol.PolicyID = BOPSTAEXT7.PolicyID 
and ppol.nexpnum = BOPSTAEXT7.nexpnum
and BOPSTA.NSTANUM =BOPSTAEXT7.NSTANUM
and BOPSTAEXT7.Name like 'RMFSubjectLiaManPrm%'

left outer Join 
( SELECT * FROM ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,NSTANUM,NAME,ELEMENT ORDER BY NEXPDATREC   DESC ) AS rn FROM
   (SELECT  BOPSTAEXTMFL.*
   from {rawDB}.BOPSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAEXTMFL.PolicyID 
             and mb.NEXPNUM = BOPSTAEXTMFL.NEXPNUM )
  ) WHERE rn = 1  )BOPSTAEXT8  
on ppol.policyid = BOPSTAEXT8.policyid 
and ppol.NEXPNUM = BOPSTAEXT8.NEXPNUM  
and BOPSTA.NSTANUM= BOPSTAEXT8.NSTANUM
and BOPSTAEXT8.Name like 'RMFSubjectLiaWrtPrm%'

"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_line_mod_1")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_MOD_ID")
  
    mergeAndWrite(hashDF,List("LINE_MOD_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table,"LINE_MOD_ID","HV-COP")
 
}