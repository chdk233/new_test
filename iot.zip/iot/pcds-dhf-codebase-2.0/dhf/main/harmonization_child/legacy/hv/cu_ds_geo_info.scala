// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_ds_cu_geo_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

SELECT
concat('HV-',POLEXT6.StringValue,'-',rtrim(ppol.lpolnum),'-',ppol.NEFFYRS,'-',ppol.NEXPNUM,'-',
case when POLLOC.NSTANUM is NULL then 999 when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when BOPsta.NSTANUM is NULL then ( 999  ) else  BOPsta.NSTANUM  end,'-',
case when POLLOC.NLOCNUM is NULL then 999 else POLLOC.NLOCNUM end,'-',
case when POLLOC.NBLDNUM is NULL then 999 else POLLOC.NBLDNUM end) as GEO_INFO_KEY,
concat('HV-',POLEXT6.StringValue,'-',rtrim(lpolnum),'-',ppol.NEFFYRS,'-',ppol.NEXPNUM) AS POL_KEY,
concat('HV-',POLEXT6.StringValue,'-',rtrim(ppol.lpolnum),'-',ppol.NEFFYRS,'-',ppol.NEXPNUM,'-',
case when POLLOC.NSTANUM is NULL then 999 when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when BOPsta.NSTANUM is NULL then ( 999  ) else  BOPsta.NSTANUM  end,'-',
case when POLLOC.NLOCNUM is NULL then 999 else POLLOC.NLOCNUM end,'-',
case when POLLOC.NBLDNUM is NULL then 999 else POLLOC.NBLDNUM end)  as LOC_KEY,
case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT,
case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT,
'HV' AS SOURCE_SYSTEM,
POLLOCEXT1.stringvalue as COASTAL_IND,
POLSTA1.stringvalue as  COUNTY_CD,
substring(LCNT,0,case when charindex('-',LCNT)=0 then lenGTH(lcnt)+1 else charindex('-',LCNT)-1 end) as COUNTY_NAME,
POLSTA3.stringvalue as MUNICIPALITY_CD,
'CU' AS LOB_CD,
'HV-CU' AS PARTITION_VAL,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CMB%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CMB%'   
and neffyrs > 2019
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'  
 
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLLOC --with (nolock)
on ppol.PolicyID = POLLOC.PolicyID
and ppol.nexpnum = POLLOC.nexpnum
 
left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,LPGMTYP,NSTANUM,NPOLPED ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPSTAMFL.*
   from
   {rawDB}.BOPSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) bopsta --with (nolock)
on POLLOC.PolicyID = bopsta.PolicyID
and POLLOC.nexpnum = bopsta.nexpnum
and LPGMTYP like '%UMB%'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,PolicyRowID,NLOCNUM,name,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationEXTMFL.*
   from
   {rawDB}.POLLocationEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLLocationEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLLOCEXT1 --with (nolock) 
on POLLOC.PolicyID = POLLOCEXT1.PolicyID 
and POLLOC.nexpnum = POLLOCEXT1.NEXPNUM
and POLLOC.NSTANUM=POLLOCEXT1.NSTANUM
and POLLOC.NLOCNUM = POLLOCEXT1.NLOCNUM 
and POLLOC.NBLDNUM = POLLOCEXT1.NBLDNUM 
and  POLLOCEXT1.Name like 'CosInd%' 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,PolicyRowID,NLOCNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLSTA1 --with (nolock) 
on POLLOC.PolicyID = POLSTA1.PolicyID 
and POLLOC.nexpnum = POLSTA1.NEXPNUM
and POLLOC.NSTANUM=POLSTA1.NSTANUM
and POLLOC.NLOCNUM = POLSTA1.NLOCNUM
and  POLSTA1.Name like 'CntCde%' 

  
  
  left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,PolicyRowID,NLOCNUM,name ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLStatMFL.*
   from
   {rawDB}.POLStatMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLStatMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLSTA3 --with (nolock) 
on POLLOC.PolicyID = POLSTA3.PolicyID 
and POLLOC.nexpnum = POLSTA3.NEXPNUM
and POLLOC.NSTANUM=POLSTA3.NSTANUM
and POLLOC.NLOCNUM = POLSTA3.NLOCNUM
and  POLSTA3.Name like 'TwnCde%' 


"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batchaddlintrst")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","GEO_INFO_ID")
    mergeAndWrite(hashDF,List("GEO_INFO_KEY","END_EFF_DT"), harmonized_table, "GEO_INFO_ID","HV-CU")
}