// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_im_ds_line_mod1(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

Select 
--TIP modifier
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') 
,ppol.NEXPNUM)
as POL_LINE_KEY
,'HV-IM-TIP' as MOD_KEY
,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-') ,case when INMSTA.NSTANUM is NULL then (999) else INMSTA.NSTANUM end)
,'-') ,'TIP')
as LINE_MOD_KEY 
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,'HV' SOURCE_SYSTEM
,'TIP' as LINE_MOD_CD
,INMSTA.LSTACDE as JURS_CD
,INMSTA.LSTANAM as JURS_TEXT
,INMSTA.NIRM3 as MOD_VAL
,INMSTAEXT2.DoubleValue as SGSTD_MIN_FCTR
,INMSTAEXT3.DoubleValue as SGSTD_MAX_FCTR
,INMSTAEXT4.DoubleValue as SGSTD_FCTR
--newly added 4 field removed
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,'HV-IM' AS PARTITION_VAL
,'IM' AS LOB_CD

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CIM%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CIM%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NCRTNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAMFL.*
   from
   {rawDB}.INMSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTA 
on ppol.policyid = INMSTA.policyid 
and ppol.NEXPNUM = INMSTA.NEXPNUM

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT2  
on ppol.PolicyID = INMSTAEXT2.PolicyID 
and INMSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT2.NSTANUM
and  INMSTAEXT2.Name like 'AgtPrpPdxMin%'

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT3  
on ppol.PolicyID = INMSTAEXT3.PolicyID 
and INMSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT3.NSTANUM
and  INMSTAEXT3.Name like 'AgtPrpPdxMax%'

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT4  
on ppol.PolicyID = INMSTAEXT4.PolicyID 
and INMSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT4.NSTANUM
and  INMSTAEXT4.Name like 'PrpDefFac%'
  

union--1
Select 
--Schedule modifier
--IM POL_KEY
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates

--IM POL_LINE_KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') 
,ppol.NEXPNUM)
as POL_LINE_KEY

--IM  MOD_KEY
,'HV-IM-SCHED' as MOD_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-') ,case when INMSTA.NSTANUM is NULL then (999) else INMSTA.NSTANUM end)
,'-') ,'SCHED')
as LINE_MOD_KEY 

--IM END_EFF_DT
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT

--IM END_EXP_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT

--IM SOURCE_SYSTEM
,'HV' SOURCE_SYSTEM

--IM LINE_MOD_CD
,'SCHED' as LINE_MOD_CD

--IM JURS_CD
,INMSTA.LSTACDE as JURS_CD

--IM JURS_TEXT
,INMSTA.LSTANAM as JURS_TEXT

--IM MOD_VAL
,INMSTA.NIRM2 as MOD_VAL

--IM SGSTD_MIN_FCTR
,INMSTAEXT2.DoubleValue as SGSTD_MIN_FCTR

--IM SGSTD_MAX_FCTR
,INMSTAEXT3.DoubleValue as SGSTD_MAX_FCTR

--IM SGSTD_FCTR
,INMSTAEXT4.DoubleValue as SGSTD_FCTR
 
,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,'HV-IM' AS PARTITION_VAL
,'IM' AS LOB_CD

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CIM%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CIM%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'


left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NCRTNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAMFL.*
   from
   {rawDB}.INMSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTA 
on ppol.policyid = INMSTA.policyid 
and ppol.NEXPNUM = INMSTA.NEXPNUM

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT2  
on ppol.PolicyID = INMSTAEXT2.PolicyID 
and INMSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT2.NSTANUM
and  INMSTAEXT2.Name like 'AgtPrpPdxMin%'

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT3  
on ppol.PolicyID = INMSTAEXT3.PolicyID 
and INMSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT3.NSTANUM
and  INMSTAEXT3.Name like 'AgtPrpPdxMax%'

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT4  
on ppol.PolicyID = INMSTAEXT4.PolicyID 
and INMSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT4.NSTANUM
and  INMSTAEXT4.Name like 'PrpDefFac%'
  
 
union--2

Select 
--EXPER modifier
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY  -- will show duplicates

--IM POL_LINE_KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') 
,ppol.NEXPNUM)
as POL_LINE_KEY

--IM  MOD_KEY
,'HV-IM-EXPER' as MOD_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-') ,case when INMSTA.NSTANUM is NULL then (999) else INMSTA.NSTANUM end)
,'-') ,'EXPER')
as LINE_MOD_KEY 

--IM END_EFF_DT
,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT

--IM END_EXP_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT

--IM SOURCE_SYSTEM
,'HV' SOURCE_SYSTEM

--IM LINE_MOD_CD
,'EXPER' as LINE_MOD_CD

--IM JURS_CD
,INMSTA.LSTACDE as JURS_CD

--IM JURS_TEXT
,INMSTA.LSTANAM as JURS_TEXT

--IM MOD_VAL
,INMSTA.NIRM1 as MOD_VAL

--IM SGSTD_MIN_FCTR
,INMSTAEXT2.DoubleValue as SGSTD_MIN_FCTR

--IM SGSTD_MAX_FCTR
,INMSTAEXT3.DoubleValue as SGSTD_MAX_FCTR

--IM SGSTD_FCTR
,INMSTAEXT4.DoubleValue as SGSTD_FCTR

,ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
,'HV-IM' AS PARTITION_VAL
,'IM' AS LOB_CD

from  global_temp.polpolmfl_micro_batch  micro_ppol
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol 
ON
    micro_ppol.PolicyID = ppol.PolicyID 
    and micro_ppol.NEXPNUM = ppol.NEXPNUM
    
    

inner join
(select min(ppol1.policyid) as policyid 

from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
              )
  ) WHERE rn = 1  )          
   ppol1


inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w1
on ppol1.policyid = w1.actpolicyid
and ppol1.lpolnum like 'CIM%'
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2

group by  ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  w
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'CIM%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch  mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 --with (nolock) 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NCRTNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAMFL.*
   from
   {rawDB}.INMSTAMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTA 
on ppol.policyid = INMSTA.policyid 
and ppol.NEXPNUM = INMSTA.NEXPNUM

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT2  
on ppol.PolicyID = INMSTAEXT2.PolicyID 
and INMSTAEXT2.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT2.NSTANUM
and  INMSTAEXT2.Name like 'AgtPrpPdxMin%'

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT3  
on ppol.PolicyID = INMSTAEXT3.PolicyID 
and INMSTAEXT3.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT3.NSTANUM
and  INMSTAEXT3.Name like 'AgtPrpPdxMax%'

LEFT OUTER join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NAME ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  INMSTAEXTMFL.*
   from
   {rawDB}.INMSTAEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = INMSTAEXTMFL.PolicyID 
            
--               where BOP_LOCATION.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) INMSTAEXT4  
on ppol.PolicyID = INMSTAEXT4.PolicyID 
and INMSTAEXT4.NEXPNUM = ppol.NEXPNUM  
and INMSTA.NSTANUM = INMSTAEXT4.NSTANUM
and  INMSTAEXT4.Name like 'PrpDefFac%'
  
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_MOD_ID")
    mergeAndWrite(hashDF,List("LINE_MOD_KEY","END_EFF_DT"), harmonized_table, "LINE_MOD_ID","HV-IM")
}