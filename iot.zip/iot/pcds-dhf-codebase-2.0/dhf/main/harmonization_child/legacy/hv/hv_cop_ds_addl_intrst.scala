// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cop_ds_addl_intrst(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select 
concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when BOPLink.nstanum is null then (999) else BOPLink.nstanum end),'-')
,case when BOPLink.nlocnum is null then (999) else BOPLink.nlocnum end),'-')
,case when BOPLink.nbldnum is null then (999) else BOPLink.nbldnum end),'-')
,case when BOPLink.noccnum is null then (999) else BOPLink.noccnum end),'-')
,case when BOPLink.ncovnum is null then (999) else BOPLink.ncovnum end),'-')
,case when boplink.SequenceNumber is null then (999) else boplink.SequenceNumber end ) ,'-')
,case when boplink.type is null then ('NULL') else boplink.type end ) ,'-')
,case when polAddlin.SequenceNumber is null then (999) else polAddlin.SequenceNumber end ),'-')
,case when boplink.nseqnum is null then (999) else boplink.nseqnum end ) as ADDL_INTRST_KEY
,concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY
,concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') ,case when polAddlin.SequenceNumber is null then (999) else polAddlin.SequenceNumber end) as POL_PARTY_KEY
,case when year(ppol.NEFFDATREC) = 1899 then DATE(ppol.NEFFDAT) else DATE(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then DATE(ppol.NEXPDAT) else DATE(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,'COPBuilding' as CVRBL_TYPE_CD
,BOPLink.type as ADDL_INTRST_TYPE_CD
,polAddlin.LNAM3 as CONTRACT_NO
,'HV-COP' as PARTITION_VAL
,'COP' as LOB_CD
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'COP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid


 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,SequenceNumber,NCRTNUM  ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLAddInterestMFL.*
   from
   {rawDB}.POLAddInterestMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLAddInterestMFL.PolicyID 
             and mb.nexpnum = POLAddInterestMFL.nexpnum
              )
  ) WHERE rn = 1  ) polAddlin  
 on ppol.PolicyID = polAddlin.PolicyID 
 and ppol.nexpnum = polAddlin.nexpnum  

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY policyid,nexpnum,SequenceNumber,Type, lpgmtyp,npolped, nstanum,nlocnum,nbldnum, noccnum,ncovnum,nseqnum,ncrtnum ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  BOPLinkMFL.*
   from
   {rawDB}.BOPLinkMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = BOPLinkMFL.PolicyID 
             and mb.nexpnum = BOPLinkMFL.nexpnum
              )
  ) WHERE rn = 1  )  BOPLink  
on ppol.PolicyID = BOPLink.PolicyID 
and ppol.nexpnum = BOPLink.nexpnum  
and polAddlin.SequenceNumber=BOPLink.SequenceNumber
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cop_ds_addl_intrst")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","ADDL_INTRST_ID")
  
    mergeAndWrite(hashDF,List("ADDL_INTRST_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table,"ADDL_INTRST_ID","HV-COP")
 
}