// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_bp_ds_manuscript(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s"""
 Select 
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM AS POL_KEY,
'HV-'||POLEXT6.StringValue||'-'||rtrim(ppol.lpolnum)||'-'||ppol.NEFFYRS||'-'||ppol.NEXPNUM||'-'||if(SPCCOV.NSTANUM is NULL, '999', LPAD(CAST(SPCCOV.NSTANUM AS STRING), 3, '0'))||'-'||if(SPCCOV.NLOCNUM is NULL, '999', LPAD(CAST(SPCCOV.NLOCNUM AS STRING), 3, '0'))||'-'||if(SPCCOV.NBLDNUM is NULL, '999', LPAD(CAST(SPCCOV.NBLDNUM AS STRING), 3, '0'))||'-'||if(SPCCOV.NSEQNUM is NULL, '999', LPAD(CAST(SPCCOV.NSEQNUM AS STRING), 3, '0'))||'-'||if(SPCCOV.LSUBCOVCDE is NULL, 'NULL', rtrim(SPCCOV.LSUBCOVCDE)) AS MANUSCRIPT_KEY,
ifnull(if(year(ppol.NEFFDATREC) = 1899, date(ppol.NEFFDAT), date(ppol.NEFFDATREC)),TO_DATE('1900-01-01','yyyy-mm-dd')) AS END_EFF_DT,
ifnull(if(year(ppol.NEXPDATREC) = 1899, date(ppol.NEXPDAT), date(ppol.NEXPDATREC)),TO_DATE('9999-12-31','yyyy-mm-dd')) AS END_EXP_DT,
ifnull(ppol.insert_timestamp,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
'HV' AS SOURCE_SYSTEM,
'HV-BP' AS PARTITION_VAL,
SPCCOVEXT2.StringValue as MANUSCRIPT_CVRG_DESC,
SPCCOVEXT3.StringValue as MANUSCRIPT_ADDL_CVRG_DESC,
Case 
when SPCCOVEXT.StringValue like 'MBOP%' or SPCCOVEXT.StringValue like  'BOP%' or SPCCOVEXT.StringValue like  'IL%' or SPCCOVEXT.StringValue like  'CO-1000%'
then Substring (SPCCOVEXT.StringValue,1,CHARINDEX(' ', SPCCOVEXT.StringValue)) 
else SPCCOVEXT.StringValue 
end as MANUSCRIPT_NO,
SPCCOV.LSUBCOVCDE as MANUSCRIPT_TYPE_CD,
SPCCOV.LCOVTYPDES as MANUSCRIPT_TYPE_TEXT,
SPCCOVEXT.StringValue as MANUSCRIPT_TTL,
'BP' AS LOB_CD
from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
--               where polpolmfl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w1 
on ppol1.policyid = w1.actpolicyid 
 and ppol1.lpolnum like 'BOP%'   
and ppol1.neffyrs > 2009
and w1.act_wstid = 11 
and w1.actstored <> 2
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT,w1.act_wstid)ppol1
on ppol1.policyid=ppol.policyid

inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
--               where WRKACTIVITY.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) w 
on 
ppol.policyid = w.actpolicyid 
and ppol.lpolnum like 'BOP%' 
and ppol.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999'
 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
--               where POLPOLEXTMFL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) POLEXT6 
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM,LCOVTYPCDE,LSUBCOVCDE ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVMFL.*
   from
   {rawDB}.SPCCOVMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVMFL.NEXPNUM
              )
  ) WHERE rn = 1  ) SPCCOV
on ppol.PolicyID = SPCCOV.PolicyID 
and ppol.nexpnum = SPCCOV.nexpnum   
and rtrim(SPCCOV.LCOVTYPCDE) = 'MNR'
and rtrim(SPCCOV.LSUBCOVCDE) in ('END', 'EXC')
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,ELEMENT,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM,LCOVTYPCDE,LSUBCOVCDE ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVEXTMFL.NEXPNUM
              )
  ) WHERE rn = 1  ) SPCCOVEXT
on ppol.PolicyID = SPCCOVEXT.PolicyID 
and ppol.nexpnum = SPCCOVEXT.nexpnum   
and  SPCCOV.NSTANUM = SPCCOVEXT.NSTANUM
and  SPCCOV.NLOCNUM = SPCCOVEXT.NLOCNUM
and  SPCCOV.NBLDNUM = SPCCOVEXT.NBLDNUM
and  SPCCOV.NSEQNUM = SPCCOVEXT.NSEQNUM
and SPCCOV.LSUBCOVCDE =SPCCOVEXT.LSUBCOVCDE
and SPCCOVEXT.Name like '%Ttl%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,ELEMENT,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM,LCOVTYPCDE,LSUBCOVCDE ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVEXTMFL.NEXPNUM
              )
  ) WHERE rn = 1  ) SPCCOVEXT2
on ppol.PolicyID = SPCCOVEXT2.PolicyID 
and ppol.nexpnum = SPCCOVEXT2.nexpnum   
and  SPCCOV.NSTANUM = SPCCOVEXT2.NSTANUM
and  SPCCOV.NLOCNUM = SPCCOVEXT2.NLOCNUM
and  SPCCOV.NBLDNUM = SPCCOVEXT2.NBLDNUM
and  SPCCOV.NSEQNUM = SPCCOVEXT2.NSEQNUM
and SPCCOV.LSUBCOVCDE =SPCCOVEXT2.LSUBCOVCDE 
and SPCCOVEXT2.Name like '%Txt%'
left outer Join 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,ELEMENT,NPOLPED,LLOB,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM,LCOVTYPCDE,LSUBCOVCDE ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  SPCCOVEXTMFL.*
   from
   {rawDB}.SPCCOVEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = SPCCOVEXTMFL.PolicyID
                   and 	mb.NEXPNUM=SPCCOVEXTMFL.NEXPNUM
              )
  ) WHERE rn = 1  ) SPCCOVEXT3
on ppol.PolicyID = SPCCOVEXT3.PolicyID 
and ppol.nexpnum = SPCCOVEXT3.nexpnum   
and  SPCCOV.NSTANUM = SPCCOVEXT3.NSTANUM
and  SPCCOV.NLOCNUM = SPCCOVEXT3.NLOCNUM
and  SPCCOV.NBLDNUM = SPCCOVEXT3.NBLDNUM
and  SPCCOV.NSEQNUM = SPCCOVEXT3.NSEQNUM
and SPCCOV.LSUBCOVCDE =SPCCOVEXT3.LSUBCOVCDE 
and SPCCOVEXT3.Name like '%EndSpc%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_bp_ds_manuscript")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","MANUSCRIPT_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("MANUSCRIPT_KEY","ETL_ROW_EFF_DTS","END_EFF_DT"),harmonized_table,"MANUSCRIPT_ID","HV-BP") 
    //     queryDF.show(3,false)
}