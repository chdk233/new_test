// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_line_bldg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select 
concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) as POL_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-')
,case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end ),'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
as LOC_KEY 

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') 
,case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end ),'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
,'-'),case when PRPBLDEXT4.Element IS NULL then (999) else PRPBLDEXT4.Element end)

as BLDG_KEY  

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end ),'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
as LINE_LOCATION_KEY  

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM),'-') ,
case when POLLOC.NSTANUM is NULL then ( 999 ) 
when POLLOC.NSTANUM > 0 then POLLOC.NSTANUM 
when PRPLOC.NSTANUM is NULL then case when PRPBLD.NSTANUm is NULL then (999) else PRPBLD.NSTANUM end  else PRPLOC.NSTANUM end ),'-'),case when POLLOC.NLOCNUM is NULL then (999) when POLLOC.NLOCNUM > 0 then POLLOC.NLOCNUM else case when PRPLOC.NLOCNUM is NULL then (999) else PRPLOC.NLOCNUM end end),'-')
,case when POLLOC.NBLDNUM is NULL then (999) when POLLOC.NBLDNUM > 0 then POLLOC.NBLDNUM else case when PRPBLD.NBLDNUM is NULL then (999) else PRPBLD.NBLDNUM end end)
,'-'),case when PRPBLDEXT4.Element is NULL  then (999)  else PRPBLDEXT4.Element end)
as LINE_BLDG_KEY 

,case when year(ppol.NEFFDATREC) = 1899 then date(ppol.NEFFDAT) else date(ppol.NEFFDATREC) end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then date(ppol.NEXPDAT) else date(ppol.NEXPDATREC) end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,'CPBuilding' as CVRBL_TYPE_CD
,case when TRIM(PRPBLDEXT14.StringValue) = 'True' then PRPBLDEXT15.DoubleValue end as AGREED_VAL_LMT
,PRPBLD.LGP2SYM as BASE_GRP_II_SYMB
,PRPBLD.NCTSGP2RAT as BASE_GRP_II_SPCF_LOSS_RATE
,PRPBLD.LGRATYP as BCEG_CL
,PRPBLD.LGRA as BCEG_DESC
,PRPBLDEXT2.StringValue as BLDG_COND_TEXT
,PRPBLDEXT3.StringValue as BLDG_UNQ_ID
,PRPBLDEXT4.DoubleValue as BLDG_OCCP_PCT
,PRPBLD.LCON as CONSTR_TYPE
,PRPBLDEXT5.DoubleValue as BLDG_SF_NO
,PRPBLD.NBLDNUM as BLDG_UNIT_NO
,PRPBLDEXT6.StringValue as CONSTR_QLTY_LEVEL_TEXT
,PRPBLD.LISOCON as CONSTR_TYPE_USE
,PRPBLD.NYRSBIL as CONSTR_YR_NO
,PRPBLDEXT7.StringValue as EQ_BLDG_CONSTR_DTL -- UGP2CON
,PRPBLD.LETQCLS as EQ_CONSTR_CL
,PRPBLDEXT8.StringValue as GRD_CL_BASE_GRP_II --BldCSPClass
,to_timestamp(PRPBLDEXT16.StringValue,"MM/dd/yyyy") as LOSS_COST_EFF_DTS
,PRPLOCEXT1.StringValue as NAME_STORM_PCT_DED --NAMSTMDED
,concat(concat(PRPBLDEXT7.StringValue,' '),PRPBLD.LISOCON) as PREDOMN_CONSTR_TYPE
,case	when PRPBLDEXT11.BooleanValue  = 0 and TRIM(PRPBLD.LTYPRAT) = 'SPECIFIC' then 'SPECIFIC' 
		when  PRPBLDEXT11.BooleanValue  = 1 and TRIM(PRPBLD.LTYPRAT) = 'SPECIFIC' then 'Tentative'
		else 'Class' end
		as RATING_TYPE
,PRPBLD.LRCP as RCP_CD
,case	when PRPBLDEXT12.BooleanValue = 0 then 'Not Rated as Sprinklered'  -- logic from Snowflake Data
		when PRPBLDEXT12.BooleanValue = 1 and TRIM(PRPBLD.LSPK) = 'NO' then 'Rated as Sprinklered; >50% of Value Exposed to Sprinklers'
		when PRPBLDEXT12.BooleanValue = 1 and TRIM(PRPBLD.LSPK) = 'YES' then 'Rated as Sprinklered; <50% of Value Exposed to Sprinklers'
		end as SPRINKLER_SYS
,PRPBLDEXT9.StringValue as STORIES_NO
, case when TRIM(PRPSSC1.LIND) = 'YES' then 'Y' when TRIM(PRPSSC1.LIND) = 'NO' then 'N' end  as SUB_STD_COND_A_FL 
,case when TRIM(PRPSSC2.LIND) = 'YES' then 'Y' when TRIM(PRPSSC2.LIND) = 'NO' then 'N' end  as SUB_STD_COND_B_FL
,case when TRIM(PRPSSC3.LIND) = 'YES' then 'Y' when TRIM(PRPSSC3.LIND) = 'NO' then 'N' end   as SUB_STD_COND_C_FL
, case when TRIM(PRPSSC4.LIND) = 'YES' then 'Y' when TRIM(PRPSSC4.LIND) = 'NO' then 'N' end  as SUB_STD_COND_D_FL
, case when TRIM(PRPSSC5.LIND) = 'YES' then 'Y' when TRIM(PRPSSC5.LIND) = 'NO' then 'N' end   as SUB_STD_COND_E_FL
,case  when PRPBLDEXT10.DoubleValue <4 then 'Y' else 'N' end AS UNDER_FOUR_UNIT_FL
,PRPBLDEXT10.DoubleValue as UNITS_NO 
,PRPBLDEXT13.DoubleValue as OCCPNCY_RECERT_YR  -- mapping to this target field because a proper target field is not found for the data 
,PRPBLD.NBLDGP2RAT as BASE_GRP_I_TENT_LOSS_RATE  -- mapping to this target field because a proper target field is not found for the data 
,PRPBLDEXT17.STringValue as BLDG_ELVTN_DS
,'CP' as LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from 
global_temp.polpolmfl_micro_batch micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

Inner Join (select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   {rawDB}.polpolmfl
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM  )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
  {rawDB}.WRKACTIVITY
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.policyid = WRKACTIVITY.actpolicyid )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum,ppol1.NEFFDAT,ppol1.NEXPDAT)ppol1
on ppol1.policyid=ppol.policyid

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   {rawDB}.POLPOLEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
              )
  ) WHERE rn = 1  ) POLEXT6   
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLLocationMFL.*
   from
   {rawDB}.POLLocationMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = POLLocationMFL.PolicyID 
              and mb.nexpnum = POLLocationMFL.nexpnum)
  ) WHERE rn = 1  ) POLLOC  
on ppol.PolicyID = POLLOC.PolicyID 
and ppol.nexpnum = POLLOC.nexpnum  

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPLOCMFL.*
   from
   {rawDB}.PRPLOCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCMFL.PolicyID 
              and mb.nexpnum = PRPLOCMFL.nexpnum)
  ) WHERE rn = 1  )PRPLOC  
on ppol.PolicyID = PRPLOC.PolicyID 
and ppol.nexpnum = PRPLOC.nexpnum 
and POLLOC.NLOCNUM = PRPLOC.NLOCNUM

 left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBLDMFL.*
   from
   {rawDB}.PRPBLDMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDMFL.PolicyID 
              and mb.nexpnum = PRPBLDMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLD  
on ppol.PolicyID = PRPBLD.PolicyID 
and ppol.nexpnum = PRPBLD.nexpnum 
and POLLOC.NLOCNUM = PRPBLD.NLOCNUM
and PRPLOC.NSTANUM = PRPBLD.NSTANUM
and case when POLLOC.NBLDNUM >0 then POLLOC.NBLDNUm else PRPBLD.NBLDNUM end = PRPBLD.NBLDNUM

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPSSCMFL.*
   from
   {rawDB}.PRPSSCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSSCMFL.PolicyID 
              and mb.nexpnum = PRPSSCMFL.nexpnum )
  ) WHERE rn = 1  )PRPSSC1 
on  ppol.policyid = PRPSSC1.policyid 
and ppol.NEXPNUM = PRPSSC1.NEXPNUM 
and PRPLOC.NSTANUM = PRPSSC1.NSTANUM
and PRPLOC.NLOCNUM = PRPSSC1.NLOCNUM
and PRPBLD.NBLDNUM = PRPSSC1.NBLDNUM
and PRPSSC1.NSEQNUM = 1

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPSSCMFL.*
   from
   {rawDB}.PRPSSCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSSCMFL.PolicyID 
              and mb.nexpnum = PRPSSCMFL.nexpnum )
  ) WHERE rn = 1  )PRPSSC2 
on  ppol.policyid = PRPSSC2.policyid 
and ppol.NEXPNUM = PRPSSC2.NEXPNUM 
and PRPLOC.NSTANUM = PRPSSC2.NSTANUM
and PRPLOC.NLOCNUM = PRPSSC2.NLOCNUM
and PRPBLD.NBLDNUM = PRPSSC2.NBLDNUM
and PRPSSC2.NSEQNUM = 2

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPSSCMFL.*
   from
   {rawDB}.PRPSSCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSSCMFL.PolicyID 
              and mb.nexpnum = PRPSSCMFL.nexpnum )
  ) WHERE rn = 1  )PRPSSC3 
on  ppol.policyid = PRPSSC3.policyid 
and ppol.NEXPNUM = PRPSSC3.NEXPNUM 
and PRPLOC.NSTANUM = PRPSSC3.NSTANUM
and PRPLOC.NLOCNUM = PRPSSC3.NLOCNUM
and PRPBLD.NBLDNUM = PRPSSC3.NBLDNUM
and PRPSSC3.NSEQNUM = 3

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPSSCMFL.*
   from
   {rawDB}.PRPSSCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSSCMFL.PolicyID 
              and mb.nexpnum = PRPSSCMFL.nexpnum )
  ) WHERE rn = 1  )PRPSSC4 
on  ppol.policyid = PRPSSC4.policyid 
and ppol.NEXPNUM = PRPSSC4.NEXPNUM 
and PRPLOC.NSTANUM = PRPSSC4.NSTANUM
and PRPLOC.NLOCNUM = PRPSSC4.NLOCNUM
and PRPBLD.NBLDNUM = PRPSSC4.NBLDNUM
and PRPSSC4.NSEQNUM = 4

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NSEQNUM ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPSSCMFL.*
   from
   {rawDB}.PRPSSCMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPSSCMFL.PolicyID 
              and mb.nexpnum = PRPSSCMFL.nexpnum )
  ) WHERE rn = 1  )PRPSSC5 
on  ppol.policyid = PRPSSC5.policyid 
and ppol.NEXPNUM = PRPSSC5.NEXPNUM 
and PRPLOC.NSTANUM = PRPSSC5.NSTANUM
and PRPLOC.NLOCNUM = PRPSSC5.NLOCNUM
and PRPBLD.NBLDNUM = PRPSSC5.NBLDNUM
and PRPSSC5.NSEQNUM = 5

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPLOCEXTMFL.*
   from
   {rawDB}.PRPLOCEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPLOCEXTMFL.PolicyID 
              and mb.nexpnum = PRPLOCEXTMFL.nexpnum )
  ) WHERE rn = 1  )  PRPLOCEXT1  
on ppol.PolicyID = PRPLOCEXT1.PolicyID 
and PRPLOCEXT1.nexpnum = 0  
and PRPLOC.NLOCNUM = PRPLOCEXT1.NLOCNUM
and PRPLOC.NSTANUM = PRPLOCEXT1.NSTANUM
and  PRPLOCEXT1.Name like 'NAMSTMDED%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT2  
on ppol.PolicyID = PRPBLDEXT2.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT2.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT2.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT2.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT2.NSTANUM
and  PRPBLDEXT2.Name like 'CndBld%' 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT3  
on ppol.PolicyID = PRPBLDEXT3.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT3.NEXPNUM
and PRPBLD.NLOCNUM = PRPBLDEXT3.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT3.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT3.NSTANUM
and  PRPBLDEXT3.Name like 'BldID%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  )PRPBLDEXT4 
on ppol.PolicyID = PRPBLDEXT4.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT4.NEXPNUM
and PRPBLD.NLOCNUM = PRPBLDEXT4.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT4.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT4.NSTANUM
and  PRPBLDEXT4.Name like 'PctOcc%'
and  PRPBLDEXT4.StringValue <> '0' and TRIM(PRPBLDEXT4.StringValue) <> ''

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT5  
on ppol.PolicyID = PRPBLDEXT5.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT5.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT5.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT5.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT5.NSTANUM
and  PRPBLDEXT5.Name like 'SqrFtg%' 

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT6  
on ppol.PolicyID = PRPBLDEXT6.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT6.NEXPNUM
and PRPBLD.NLOCNUM = PRPBLDEXT6.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT6.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT6.NSTANUM
and  PRPBLDEXT6.Name like 'ConQlv%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT7  
on ppol.PolicyID = PRPBLDEXT7.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT7.NEXPNUM   
and PRPBLD.NLOCNUM = PRPBLDEXT7.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT7.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT7.NSTANUM
and  PRPBLDEXT7.Name like 'UGP2CON%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT8  
on ppol.PolicyID = PRPBLDEXT8.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT8.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT8.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT8.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT8.NSTANUM
and  PRPBLDEXT8.Name like 'BldCSPClass%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT9  
on ppol.PolicyID = PRPBLDEXT9.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT9.NEXPNUM   
and PRPBLD.NLOCNUM = PRPBLDEXT9.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT9.NBLDNUM
and PRPBLD.NSTANUM = PRPBLDEXT9.NSTANUM
and  PRPBLDEXT9.Name like 'NumSty%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT10  
on ppol.PolicyID = PRPBLDEXT10.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT10.NEXPNUM
and PRPBLD.NLOCNUM = PRPBLDEXT10.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT10.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT10.NSTANUM
and  PRPBLDEXT10.Name like 'NumUnts%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT11  
on ppol.PolicyID = PRPBLDEXT11.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT11.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT11.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT11.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT11.NSTANUM
and  PRPBLDEXT11.Name like 'Tentative%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT12  
on ppol.PolicyID = PRPBLDEXT12.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT12.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT12.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT12.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT12.NSTANUM
and  PRPBLDEXT12.Name like 'Spk%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT13  
on ppol.PolicyID = PRPBLDEXT13.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT13.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT13.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT13.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT13.NSTANUM
and  PRPBLDEXT13.Name like 'EffAge%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT14  
on ppol.PolicyID = PRPBLDEXT14.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT14.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT14.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT14.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT14.NSTANUM
and  PRPBLDEXT14.Name like 'AgdAmt%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT15  
on ppol.PolicyID = PRPBLDEXT15.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT15.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT15.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT15.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT15.NSTANUM
and  PRPBLDEXT15.Name like 'BldLmt%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT16  
on ppol.PolicyID = PRPBLDEXT16.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT16.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT16.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT16.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT16.NSTANUM
and  PRPBLDEXT16.Name like 'NPUBDAT%'

left outer Join 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,Name,Element ORDER BY NEXPDATREC DESC ) AS rn FROM
   (SELECT  PRPBLDEXTMFL.*
   from
   {rawDB}.PRPBLDEXTMFL
   inner join global_temp.polpolmfl_micro_batch mb
              on   mb.PolicyID = PRPBLDEXTMFL.PolicyID 
              and mb.nexpnum = PRPBLDEXTMFL.nexpnum )
  ) WHERE rn = 1  ) PRPBLDEXT17  
on ppol.PolicyID = PRPBLDEXT17.PolicyID 
and ppol.NEXPNUM = PRPBLDEXT17.NEXPNUM 
and PRPBLD.NLOCNUM = PRPBLDEXT17.NLOCNUM
and PRPBLD.NBLDNUM = PRPBLDEXT17.NBLDNUM 
and PRPBLD.NSTANUM = PRPBLDEXT17.NSTANUM
and  PRPBLDEXT17.Name like 'BldElev%'
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_hv_cp_ds_line_bldg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
  
  queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","LINE_BLDG_ID")
  
    mergeAndWrite(hashDF,List("LINE_BLDG_KEY","END_EFF_DT"), harmonized_table,"LINE_BLDG_ID","HV-CP")
 
}