// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_ca_ds_fact_prem_tran(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT
fact.FACT_STAGE_KEY||'-'||fact.END_EFF_DT||'-'||fact.END_EXP_DT AS FACT_PREM_TRANS_KEY,
'CA' as LOB_CD,
'HV' as SOURCE_SYSTEM,
'HV-CA' as PARTITION_VAL,
ifnull(POL.AGCY_KEY, 'NOKEY') as AGCY_KEY,
'NOKEY' as AGNT_KEY,
fact.POL_KEY as POL_KEY,
ifnull(fact.POL_LINE_KEY, 'NOKEY') as POL_LINE_KEY,
CASE 
WHEN fact.FACT_STAGE_KEY IS  NOT  NULL AND (fact.COVG_CD is NOT NULL or trim(fact.COVG_CD) != '')
THEN (CASE WHEN (substring(reverse(fact.FACT_STAGE_KEY),1,6) in ('VCCUAC','VOCCPS')) OR (substring(reverse(fact.FACT_STAGE_KEY),1,6) in ('VOCRAG'))  THEN  (concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-','BA'),'-'),
fact.COVG_CD),'-'),fact.COVG_TEXT),'-'),fact.COVG_PART_CD),'-'),fact.COVG_PART_TEXT))
WHEN (substring(reverse(fact.FACT_STAGE_KEY),1,6) in ('VOCHEV','VCCRAG')) THEN  
concat(concat(concat(concat(concat('HV-','BA'),'-'),
fact.COVG_CD),'-'),fact.COVG_TEXT)
ELSE 'NOKEY'END)
ELSE 'NOKEY' 
END AS COVG_KEY,
case when ( (fact.FACT_STAGE_KEY IS   NULL) or (fact.NO_STA =0 ) or (fact.NO_LOC =0 )or (fact.NO_BLD  = 0 ) ) then 'NOKEY'
when substring(reverse(fact.FACT_STAGE_KEY),1,3)  = 'CPS' then  substring(fact.FACT_STAGE_KEY,1 ,locate_pos( fact.FACT_STAGE_KEY, '-', 8 )-1)
when substring(reverse(fact.FACT_STAGE_KEY),1,6)  = 'VOCRAG' then  substring(fact.FACT_STAGE_KEY,1 ,locate_pos( fact.FACT_STAGE_KEY, '-', 8 )-1) else 'NOKEY' end  as LOC_KEY,
CASE when  fact.FACT_STAGE_KEY IS   NULL then 'NOKEY'
      WHEN substring(reverse(fact.FACT_STAGE_KEY),1,3) IN( 'CPS') AND upper(fact.COVG_TEXT) LIKE '%CA-9937 - GARAGEKEEPERS%' THEN 
          concat(concat(concat(concat(concat(concat(substring(fact.FACT_STAGE_KEY,1 ,locate_pos( fact.FACT_STAGE_KEY, '-', 7)-1),'-')
          ,fact.GARAGE_TER_CDE ),'-')
          ,fact.GARAGE_TER_ZIP),'-')
          ,fact.GARAGE_CTY)
      WHEN substring(reverse(fact.FACT_STAGE_KEY),1,3) IN( 'VCC') AND upper(FACT.COVG_PART_CD) LIKE '%NONSRV%' THEN 
          concat(concat(concat(concat(concat(concat(substring(fact.FACT_STAGE_KEY,1 ,locate_pos( fact.FACT_STAGE_KEY, '-', 7)-1),'-')
          ,fact.GARAGE_TER_CDE ),'-')
          ,fact.GARAGE_TER_ZIP),'-')
          ,fact.GARAGE_CTY)
     else 'NOKEY' 
END AS GARAGE_SRVC_LOC_KEY,
CASE when  fact.FACT_STAGE_KEY IS   NULL then 'NOKEY'
      WHEN substring(reverse(fact.FACT_STAGE_KEY),1,6) ='VOCHEV' THEN 
          concat(concat(concat(concat(concat(concat(substring(fact.FACT_STAGE_KEY,1 ,locate_pos( fact.FACT_STAGE_KEY, '-', 7)-1),'-')
          ,fact.GARAGE_TER_CDE ),'-')
          ,fact.GARAGE_TER_ZIP  ),'-')
          ,fact.GARAGE_CTY)
       else 'NOKEY' 
END AS VEH_GARAGE_LOC_KEY,
CASE when  fact.FACT_STAGE_KEY IS   NULL then 'NOKEY'
      WHEN substring(reverse(fact.FACT_STAGE_KEY),1,6) ='VOCHEV' THEN 
         concat(substring(fact.FACT_STAGE_KEY,1 ,locate_pos( fact.FACT_STAGE_KEY, '-', 7)-1))
      ELSE 'NOKEY'
      END AS VEH_KEY,
CASE when  fact.FACT_STAGE_KEY IS   NULL then 'NOKEY' 
      ELSE FACT.MANUSCRIPT_TEMP end AS  LINE_MANUSCRIPT_KEY,
Case when fact.FACT_STAGE_KEY not like '%SURCHARGE%'  AND fact.FACT_STAGE_KEY not like '%BAL_MIN%' THEN fact.FACT_STAGE_KEY ELSE 'NOKEY' END as LINE_COVG_KEY,
ifnull(POL.PRIM_NAMED_INSURED_KEY, 'NOKEY') as NAMED_INSURED_KEY,
ifnull(to_timestamp(fact.TRANS_PROC_DTS,'MM/dd/yyyy'), to_timestamp('12/31/9999','MM/dd/yyyy')) as TRANS_PROC_DTS,
ifnull(fact.END_EFF_DT, CAST('1900-01-01' as DATE)) as TRANS_EFF_DT,
ifnull(fact.END_EXP_DT, CAST('1900-12-31' as DATE)) as TRANS_EXP_DT,
ifnull(fact.TRANS_CD, ' ') as TRANS_CD,
ifnull(fact.CVRBL_TYPE_CD, ' ') as CVRBL_TYPE_CD,
Case when trim(fact.COVG_CD)  != '' and fact.TERM_VAL_AMT is not null then fact.TERM_VAL_AMT else 0 end as ACT_AMT,
ifnull(fact.TERM_VAL_AMT, 0) as TRANS_AMT,
ifnull(fact.TRANS_ALLOC_CD, ' ') as TRANS_ALLOC_CD,
Case when fact.FACT_STAGE_KEY not like '%SURCHARGE' and fact.TERM_VAL_AMT is not null then fact.TERM_VAL_AMT else 0 end as WRITTEN_PREM_AMT,
case when fact.FACT_STAGE_KEY  like '%SURCHARGE' and fact.TERM_VAL_AMT is not null then fact.TERM_VAL_AMT else 0 end as SRCHG_AMT,
Case when fact.FACT_STAGE_KEY not like '%SURCHARGE' and fact.TEMP_ANNUAL_PREM_AMT is not null then fact.TEMP_ANNUAL_PREM_AMT else 0 end as ANNUAL_PREM_AMT,
ifnull(fact.END_EFF_DT, CAST('1900-01-01' as DATE)) as END_EFF_DT,
ifnull(fact.END_EXP_DT, CAST('1900-12-31' as DATE)) as END_EXP_DT
from  global_temp.ds_fact_staging_micro_batch micro_fact
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY FACT_STAGE_KEY,ETL_ROW_EFF_DTS,END_EFF_DT ORDER BY END_EXP_DT   DESC ) AS rn
   FROM
   (SELECT  ds_fact_staging.*
   from
   {rawDB}.ds_fact_staging
   inner join global_temp.ds_fact_staging_micro_batch mb
              on   mb.POL_KEY = ds_fact_staging.POL_KEY 
            and mb.END_EFF_DT = ds_fact_staging.END_EFF_DT
            and mb.END_EXP_DT = ds_fact_staging.END_EXP_DT
              )
  ) WHERE rn = 1  )          
   fact 
ON micro_fact.POL_KEY = fact.POL_KEY 
   and micro_fact.END_EFF_DT = fact.END_EFF_DT
   and micro_fact.END_EXP_DT = fact.END_EXP_DT 
left outer join
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY POL_KEY,ETL_ROW_EFF_DTS,END_EFF_DT ORDER BY END_EXP_DT   DESC ) AS rn
   FROM
   (SELECT  ds_policy.*
   from
   {rawDB}.ds_policy
   inner join global_temp.ds_fact_staging_micro_batch mb
              on   mb.POL_KEY = ds_policy.POL_KEY 
            and mb.END_EFF_DT = ds_policy.END_EFF_DT
            and mb.END_EXP_DT = ds_policy.END_EXP_DT
              )
  ) WHERE rn = 1  )  pol
on pol.pol_key = fact.pol_key 
and  pol.END_EFF_DT =  fact.END_EFF_DT
and  pol.END_EXP_DT =  fact.END_EXP_DT
and fact.POL_key like 'HV-BA%'
and pol.POL_key like 'HV-BA%'
"""
 
    microBatchDF.createOrReplaceGlobalTempView(s"ds_fact_staging_micro_batch")
  println("microBatchDFcount :"+microBatchDF.count)
  microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.ds_fact_staging_micro_batch_hv_ca_ds_fact_prem_tran")
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB) 
  harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
  println("harmz_query after rawDB replace: \n"+ harmz_query)
   
 
  val harmonized_table = s"${harmonizedDB}.${target}"
  val queryDF=microBatchDF.sparkSession.sql(harmz_query)
  println("Harmonized query execution completed..")
  println("QueryDFCount :"+queryDF.count)
  
  //test
    val w = Window.partitionBy($"FACT_PREM_TRANS_KEY").orderBy($"FACT_PREM_TRANS_KEY")
  var auditDF = queryDF.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")  

  val maxSK = spark.table(s"${harmonized_table}").count
  val w1  = Window.orderBy($"FACT_PREM_TRANS_KEY")

  auditDF = auditDF.withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ID", row_number.over(w1) + maxSK)
  
  auditDF= auditDF.withColumn(s"FACT_PREM_TRANS_ID", expr("CAST(ID AS INTEGER)")).drop("ID")
  
  println("auditDF:")
  println("auditDFCount :"+auditDF.count)
 //auditDF.write.format("delta").mode("append").saveAsTable(harmonized_table)
  
  DeltaTable.forName(spark, harmonized_table)
  .as("events")
  .merge(
    auditDF.as("updates"),
    s"events.FACT_PREM_TRANS_KEY = updates.FACT_PREM_TRANS_KEY AND events.SOURCE_SYSTEM = 'HV'")  
  
  .whenNotMatched
  .insertAll()
  .execute()
 }