// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_cp_ds_jurs(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select 

concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) 
as POL_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum))
,'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM) ,'-') ,case when PRPBKT.NBKTNUM is NULL then ppol.NEXPNUM else PRPBKT.NBKTNUM end)
as POL_LINE_KEY

,concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat('HV-',POLEXT6.StringValue),'-'),rtrim(ppol.lpolnum)),'-'),ppol.NEFFYRS),'-') ,ppol.NEXPNUM)
,'-'),case when PRPSTA.NSTANUM is NULL then ( 999  ) else PRPSTA.NSTANUM end)
,'-') ,case when PRPPRL.NLOCNUM is NULL then (999) else PRPPRL.NLOCNUM end)
,'-') ,case when PRPPRL.NBLDNUM is NULL  then (999)  else PRPPRL.NBLDNUM end)
,'-'),case when PRPPRL.NOCCNUM is NULL  then (999)  else PRPPRL.NOCCNUM end)
,'-') ,case when PRPPRL.NCOVNUM is NULL  then (999)  else PRPPRL.NCOVNUM end)
,'-') ,case when PRPPRL.NSUBCOVNUM is NULL  then (999)  else PRPPRL.NSUBCOVNUM end)
,'-'),case when PRPPRL.NPRLNUM is NULL then (999) else PRPPRL.NPRLNUM end)
,'-'),case when PRPBKT.NBKTNUM is NULL then ppol.NEXPNUM else PRPBKT.NBKTNUM end)
as JURS_KEY


,case when year(ppol.NEFFDATREC) = 1899 then ppol.NEFFDAT else ppol.NEFFDATREC end  as END_EFF_DT
,case when year(ppol.NEXPDATREC) = 1899 then ppol.NEXPDAT else ppol.NEXPDATREC end  as END_EXP_DT
,'HV' as SOURCE_SYSTEM
,'CPJurisdiction' as CVRBL_TYPE_CD
,case when PRPSTA.NSTANUM is null then '' else PRPSTA.NSTANUM end  as JURS_CD
,case when PRPSTA.LSTANAM is null then 'Not Defined' else PRPSTA.LSTANAM end as JURS_TEXT
,case when PRPPRL.NPRLNUM = 6 then 'Y' else 'N' end as MINE_SUBS_COVG
,'CP' as LOB_CD
,'HV-CP' as PARTITION_VAL
,ppol.insert_timestamp as ETL_ROW_EFF_DTS

from dhf_aqs_raw_pt_e2.polpolmfl micro_ppol 
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   dhf_aqs_raw_pt_e2.polpolmfl
   inner join dhf_aqs_raw_pt_e2.polpolmfl mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol 
on micro_ppol.PolicyID = ppol.PolicyID 
and micro_ppol.NEXPNUM = ppol.NEXPNUM

inner join  
(select min(ppol1.policyid) as policyid from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID, NEXPNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  polpolmfl.*
   from
   dhf_aqs_raw_pt_e2.polpolmfl
   inner join dhf_aqs_raw_pt_e2.polpolmfl mb
              on   mb.PolicyID = polpolmfl.PolicyID 
            and mb.NEXPNUM = polpolmfl.NEXPNUM 
            
              )
  ) WHERE rn = 1  ) ppol1 
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY actPolicyID ORDER BY actLastActivity   DESC ) AS rn
   FROM
   (SELECT  WRKACTIVITY.*
   from
   dhf_aqs_raw_pt_e2.WRKACTIVITY
   inner join dhf_aqs_raw_pt_e2.polpolmfl mb
              on   mb.policyid = WRKACTIVITY.actpolicyid 
            
             )
  ) WHERE rn = 1  ) w 
on ppol1.policyid = w.actpolicyid 
 and ppol1.lpolnum like 'CP%'   
and ppol1.neffyrs > 2009
and w.act_wstid = 11 
and w.actstored <> 2
and w.actLastActivity > '2009-12-31 23:59:59.999' 
group by ppol1.lpolnum ,ppol1.NEXPDAT,ppol1.NEFFDAT,w.act_wstid ) ppol1
on ppol1.policyid=ppol.policyid

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,Name,Element ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  POLPOLEXTMFL.*
   from
   dhf_aqs_raw_pt_e2.POLPOLEXTMFL
   inner join dhf_aqs_raw_pt_e2.polpolmfl mb
              on   mb.PolicyID = POLPOLEXTMFL.PolicyID 
            
              )
  ) WHERE rn = 1  ) POLEXT6  
on ppol.PolicyID = POLEXT6.PolicyID 
and POLEXT6.nexpnum = 0   
and  POLEXT6.Name like 'PolicyPrefix%' 

 left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPSTAMFL.*
   from
   dhf_aqs_raw_pt_e2.PRPSTAMFL
   inner join dhf_aqs_raw_pt_e2.polpolmfl mb
              on   mb.PolicyID = PRPSTAMFL.PolicyID 
              and  mb.nexpnum = PRPSTAMFL.nexpnum
            
              )
  ) WHERE rn = 1  ) PRPSTA 
on ppol.PolicyID = PRPSTA.PolicyID 
and ppol.nexpnum = PRPSTA.nexpnum 

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NSTANUM,NLOCNUM,NBLDNUM,NOCCNUM,NCOVNUM,NSUBCOVNUM,NPRLNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPPRLMFL.*
   from
   dhf_aqs_raw_pt_e2.PRPPRLMFL
   inner join dhf_aqs_raw_pt_e2.polpolmfl mb
              on   mb.PolicyID = PRPPRLMFL.PolicyID 
              and  mb.nexpnum = PRPPRLMFL.nexpnum
            
              )
  ) WHERE rn = 1  ) PRPPRL 
on ppol.PolicyID = PRPPRL.PolicyID 
and ppol.nexpnum = PRPPRL.nexpnum
and PRPSTA.NSTANUM = PRPPRL.NSTANUM

left outer Join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PolicyID,NEXPNUM,NBKTNUM ORDER BY NEXPDATREC   DESC ) AS rn
   FROM
   (SELECT  PRPBKTPOLMFL.*
   from
   dhf_aqs_raw_pt_e2.PRPBKTPOLMFL
   inner join dhf_aqs_raw_pt_e2.polpolmfl mb
              on   mb.PolicyID = PRPBKTPOLMFL.PolicyID 
              and  mb.nexpnum = PRPBKTPOLMFL.nexpnum
            
              )
  ) WHERE rn = 1  ) PRPBKT
on ppol.policyid = PRPBKT.policyid 
and ppol.NEXPNUM = PRPBKT.NEXPNUM 
"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"polpolmfl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.polpolmfl_micro_batch_HV_CP_Jurs")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
   queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","JURS_ID")
  
    mergeAndWrite(hashDF,List("JURS_KEY","END_EFF_DT"),harmonized_table,"JURS_ID","HV-CP")
}
