// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_policy(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT 
'PCIO-COP-'||POLICY.CPE_MF_GN_PREFIX_A||POLICY.CPE_MF_GN_PREFIX_B||POLICY.CPE_MF_GN_POL_BRANCH||POLICY.CPE_MF_GN_POL_DEC||POLICY.CPE_MF_GN_POL_NUMBER AS POL_KEY,
'DPIM-'||LPAD(TRIM(POLICY.CPE_GN_AGENT_NUMBER),8,'0') as AGCY_KEY,
'DPIM-'||LPAD(TRIM(POLICY.CPE_GN_AGENT_NUMBER),8,'0')||'-'||LPAD(TRIM(POLICY.CPE_GN_AGENT_PROD_CODE),8,'0') AS AGNT_KEY,
to_date(POLICY.CPE_MF_GN_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(POLICY.CPE_MF_GN_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
--to_timestamp(POLICY.CPE_MF_GN_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
IF(TO_TIMESTAMP(CPE_GN_CYCLE_DATE_1,'yyyyDDD') IS NULL,TO_TIMESTAMP(policy.CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE_1,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
'COP' AS PROD_CD,
POLICY.CPE_GN_COMPANY_NUM AS POL_CO_CD,
IF(RANKINGI=1,
'PCIO-COP-'||POLICY.CPE_MF_IS_PREFIX_A||POLICY.CPE_MF_IS_PREFIX_B||POLICY.CPE_MF_IS_POL_BRANCH||POLICY.CPE_MF_IS_POL_DEC||POLICY.CPE_MF_IS_POL_NUMBER||'-'||POLICY.CPE_MF_IS_SEQ_NUM1,'NOKEY') AS PRIM_NAMED_INSURED_KEY,
PZE10100_C_BILL_PLAN AS PAY_PLAN_CD,
POLICY.CPE_GN_BILL_TYPE AS BILL_PLAN_CD,
POLICY.CPE_GN_STAND_INDUST_CODE as SIC_CD,
POLICY.CPE_GN_UNDERWRITER_ID AS UNDERWRITER_CD,
POLICY.CPE_MF_GN_POL_DEC AS DECLARATION_NUM,
PZE10200_C_MRKT_SEG_IND AS CMML_MKT_SGMNT_CD,
IF(trim(POLICY.CPE_GN_NEW_REN_IND)= 'R','Y','N') AS POL_TERM_RENEW_FL,
POLICY.CPE_GN_TRFR_PROC_CODE as AGNT_TFR_PROC_TYPE, 
POLICY.CPE_GN_AGENT_NGTD_COMM/1000 AS COMM_CONTRIBUTION_FCTR,
CAST(POLICY.CPE_GN_IRPM_CREDIT AS INT )/100 AS  IRPM_FCTR,
(100-CAST(POLICY.CPE_GN_LPDP_DISC AS INT))/100  AS LPDP_FCTR,
CAST(POLICY.CPE_GN_MLPDC_FACTOR AS INT)/100  AS MULTI_POL_DISC_FCTR, 
POLICY.CPE_GN_CSC_IND AS SRVC_PLUS_INDC, 
POLICY.CPE_GN_INSUREDS_BUSINESS AS BUS_CL_DESC,
POLICY.CPE_GN_REINSURANCE_IND AS REINS_TYPE_CD,
POLICY.CPE_GN_CANCEL_TYPE AS RFND_CALC_METHD_CD,
POLICY.CPE_GN_PR_POL_PFXA||POLICY.CPE_GN_PR_POL_PFXB||POLICY.CPE_GN_PR_POL_RGN_OFF||POLICY.CPE_GN_PR_POL_DEC||POLICY.CPE_GN_PR_POL_NUMBER as  PRIOR_POL_NUM,
POLICY.CPE_GN_PR_POL_PFXA||POLICY.CPE_GN_PR_POL_RGN_OFF||POLICY.CPE_GN_PR_POL_DEC||POLICY.CPE_GN_PR_POL_NUMBER AS PRIOR_ACCT_NUM,
'DPIM-'|| lpad(trim(POLICY.CPE_GN_SVC_AGENT_ORIG),8,'0') AS SRVCNG_AGCY_KEY,
'DPIM-'|| lpad(trim(POLICY.CPE_GN_SVC_AGENT_ORIG),8,'0') || '-' || lpad(trim(POLICY.CPE_GN_SVC_PRODUCER_ORIG ),8,'0') AS SRVCNG_AGNT_KEY,
cast(POLICY.CPE_GN_AGENT_COMMISSION as int) /1000 AS ICM_BASE_COMM_PCT,
cast(POLICY.CPE_GN_CSC_DEV as int)/1000 AS ICM_SRVC_PLUS_DEVTN_PCT,
to_timestamp(POLICY.CPE_GN_RATE_DATE,'yyDDD') AS RATE_DT,
PZE10100_Q_1Y_PR_LOSS_AF_PP AS ATFAULT_LOSS_PAST_1YR_NO,                   
PZE10100_Q_2Y_PR_LOSS_AF_PP AS ATFAULT_LOSS_PAST_2YR_NO,                   
PZE10100_Q_3Y_PR_LOSS_AF_PP AS ATFAULT_LOSS_PAST_3YR_NO,
PZE10100_Q_3Y_PRIOR_LOSS_PP AS LOSS_PAST_3YR_NO,  
'PCIO-PAK-'||POLICY.CPE_MF_GN_PREFIX_A||POLICY.CPE_MF_GN_POL_BRANCH||POLICY.CPE_MF_GN_POL_DEC||POLICY.CPE_MF_GN_POL_NUMBER AS  ACCT_KEY,
POLICY.CPE_MF_GN_PREFIX_A||POLICY.CPE_MF_GN_PREFIX_B||POLICY.CPE_MF_GN_POL_BRANCH||POLICY.CPE_MF_GN_POL_DEC||POLICY.CPE_MF_GN_POL_NUMBER AS  POL_NO,
TO_DATE(POLICY.CPE_GN_POL_EFF_DATE, 'yyDDD') as POL_EFF_DT,
TO_DATE(POLICY.CPE_GN_POL_EXP_DATE, 'yyDDD') as POL_EXP_DT,
TO_DATE(POLICY.CPE_GN_ORIG_EFF_DATE , 'yyDDD') as ORIG_EFF_DT,
TO_DATE(POLICY.CPE_GN_ORIG_EFF_DATE , 'yyDDD') as LEGACY_POL_ORIG_EFF_DT,
IF(trim (POLICY.CPE_GN_NEW_REN_IND) ='N','Y','N')  AS NEW_BUS_FL,
PZE10100_C_BUSINESS_ENTITY AS ENTITY_TYPE_CD, 
POLICY.CPE_GN_POLICY_STATE AS PRIM_STATE_CD,
POLICY.CPE_GN_STATUS_CODE AS POL_PERIOD_STATUS_CD,
case 
when trim(POLICY.CPE_GN_STATUS_CODE)='A' THEN 'ACTIVE'
when trim(POLICY.CPE_GN_STATUS_CODE)='D' THEN 'REINSTATED'
when trim(POLICY.CPE_GN_STATUS_CODE) in ('H','I') THEN 'RENEWED'
when trim(POLICY.CPE_GN_STATUS_CODE)='P' THEN 'PENDING CANCEL FROM  BILLING'
when trim(POLICY.CPE_GN_STATUS_CODE)='U' THEN 'EXPIRED'
when trim(POLICY.CPE_GN_STATUS_CODE) in ('X','V','W') THEN 'CANCELED'
when trim(POLICY.CPE_GN_STATUS_CODE) ='R' THEN 'CLT-Complete and ready for PC Migration'
when trim(POLICY.CPE_GN_STATUS_CODE) ='S' THEN 'CLT-Stage Integrity source system error (Error on MF)'
when trim(POLICY.CPE_GN_STATUS_CODE) ='L' THEN 'CLT-Renewal Quoted in PC (could be draft quote/quote or issued)'
when trim(POLICY.CPE_GN_STATUS_CODE) ='Z' THEN 'CLT-Expired convert'
ELSE 'Not Defined'
end as POL_PERIOD_STATUS_TEXT,
case 
when trim(POLICY.CPE_GN_STATUS_CODE) IN ('A','D','H','I') THEN 'ACTIVE'
WHEN trim(POLICY.CPE_GN_STATUS_CODE) in ('X','V','W','U') THEN 'CANCEL'
ELSE trim(POLICY.CPE_GN_STATUS_CODE)
END AS LAST_STATUS_CD,
POLICY.CPE_GN_IRPM_ELIG_PREM/100 AS  TOTAL_IRPM_ELIGBL_PREM_AMT,
PZE10200_C_CANCEL_DETAIL AS LAST_STATUS_REASON_CD,
POLICY.CPE_GN_CANCEL_REASON AS CANCEL_SRCE_CD,
PZE10200_F_MONOLINE as MONOLINE_FL,
'PCIO-COP' as partition_val

FROM
  global_temp.cop_gnrl_micro_batch micro_gnrl
  
  INNER JOIN
(select * from (SELECT *, gnrl.CPE_GN_CYCLE_DATE as CPE_GN_CYCLE_DATE_1,
rank() over
(partition by CPE_MF_GN_PREFIX_A,CPE_MF_GN_POL_BRANCH,CPE_MF_GN_POL_DEC,CPE_MF_GN_POL_NUMBER,CPE_MF_GN_PREFIX_B,CPE_MF_GN_POL_EXP_DATE,CPE_MF_GN_VER_DATE order by prefix.PHE00100_VERSION_DATE desc) as ranking 
FROM 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A, CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, cpe_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  COP_GNRL.*
   from
   {rawDB}.COP_GNRL
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = COP_GNRL.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = COP_GNRL.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = COP_GNRL.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = COP_GNRL.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = COP_GNRL.CPE_MF_GN_POL_NUMBER 
            and mb.cpe_MF_GN_VER_DATE = COP_GNRL.cpe_MF_GN_VER_DATE
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(COP_GNRL.CPE_GN_CYCLE_DATE is null, 'null', COP_GNRL.CPE_GN_CYCLE_DATE)
            
--               where CP_BLDG.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  gnrl
left JOIN
(select distinct * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PHE00100_PREFIX_A, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE,PZE10100_D_CYCLE_DATE  ORDER BY if(PZE10100_D_CYCLE_DATE is null,PHE00100_DATE_STAMP, PZE10100_D_CYCLE_DATE )   DESC ) AS rn
   FROM
   (SELECT  PAK_PREFIX.*
   from
   {rawDB}.PAK_PREFIX
   inner join global_temp.cop_gnrl_micro_batch mb 
              on   mb.CPE_MF_GN_PREFIX_A = PAK_PREFIX.PHE00100_PREFIX_A 
           -- and mb.CPE_MF_GN_PREFIX_B = PAK_PREFIX.CPE_MF_IT_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = PAK_PREFIX.PHE00100_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = PAK_PREFIX.PHE00100_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = PAK_PREFIX.PHE00100_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = PAK_PREFIX.PHE00100_VERSION_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(PAK_PREFIX.PZE10100_D_CYCLE_DATE is null, 'null', PAK_PREFIX.PZE10100_D_CYCLE_DATE)
--               where CP_GNRL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )) prefix
on
TRIM(CPE_MF_GN_PREFIX_A)=TRIM(PZE10200_X_PREFIX_A) AND
TRIM(CPE_MF_GN_PREFIX_B)=TRIM(PZE10200_X_PREFIX_B) AND
TRIM(CPE_MF_GN_POL_BRANCH)=TRIM(PZE10200_X_REGNL_OFFICE) AND
TRIM(CPE_MF_GN_POL_DEC)=TRIM(PZE10200_X_DECLARATION) AND
TRIM(CPE_MF_GN_POL_NUMBER)=TRIM(PZE10200_X_POLICY_NBR) AND
TO_DATE(CPE_MF_GN_VER_DATE,'yyyyDDD')>=to_date(PHE00100_VERSION_DATE,'yyyyMMdd') AND
TO_DATE(CPE_MF_GN_POL_EXP_DATE,'yyyyDDD')=to_date(PHE00100_POL_EXP_DATE,'yyyyDDD')
left join 
( SELECT * FROM
( SELECT *, row_number() over ( partition BY PHE00100_PREFIX_A, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE,PZE10100_D_CYCLE_DATE ORDER BY if(PZE10100_D_CYCLE_DATE is null,PHE00100_DATE_STAMP, PZE10100_D_CYCLE_DATE ) DESC ) AS rn
   FROM
   (SELECT  PAK_GNRL.*
   from
   {rawDB}.PAK_GNRL
   inner join global_temp.cop_gnrl_micro_batch mb
             on mb.CPE_MF_GN_PREFIX_A = PAK_GNRL.PHE00100_PREFIX_A
-- and mb.CPE_MF_GN_PREFIX_B = PAK_GNRL.PHE00100_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = PAK_GNRL.PHE00100_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = PAK_GNRL.PHE00100_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = PAK_GNRL.PHE00100_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = PAK_GNRL.PHE00100_VERSION_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(PAK_GNRL.PZE10100_D_CYCLE_DATE is null, 'null', PAK_GNRL.PZE10100_D_CYCLE_DATE)
)) WHERE rn = 1 ) gnrl
on 
trim(prefix.PHE00100_PREFIX_A) = trim(gnrl.PHE00100_PREFIX_A)
and prefix.PHE00100_POL_BRANCH = gnrl.PHE00100_POL_BRANCH
and prefix.PHE00100_POL_DEC = gnrl.PHE00100_POL_DEC
and prefix.PHE00100_POL_NUMBER = gnrl.PHE00100_POL_NUMBER
and prefix.PHE00100_POL_EXP_DATE = gnrl.PHE00100_POL_EXP_DATE
and prefix.PHE00100_VERSION_DATE = gnrl.PHE00100_VERSION_DATE
LEFT JOIN
(SELECT *,
row_number() over ( partition BY CPE_MF_IS_PREFIX_A, CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_VER_DATE order by CPE_MF_IS_PREFIX_A, CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_VER_DATE,CPE_MF_IS_SEQ_NUM1 ASC ) AS RANKINGI 
FROM  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IS_PREFIX_A,CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER,CPE_MF_IS_SEQ_NUM1, CPE_MF_IS_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_IS_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_insured.*
   from
   {rawDB}.cop_insured
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_insured.CPE_MF_IS_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_insured.CPE_MF_IS_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_insured.CPE_MF_IS_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_insured.CPE_MF_IS_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_insured.CPE_MF_IS_POL_NUMBER
            and mb.CPE_MF_GN_VER_DATE = cop_insured.CPE_MF_IS_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_insured.CPE_GN_CYCLE_DATE is null, 'null', cop_insured.CPE_GN_CYCLE_DATE)
            
--               where cp_insured.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) )
on
CPE_MF_GN_PREFIX_A=CPE_MF_IS_PREFIX_A and
CPE_MF_GN_PREFIX_B=CPE_MF_IS_PREFIX_B and
CPE_MF_GN_POL_BRANCH=CPE_MF_IS_POL_BRANCH and
CPE_MF_GN_POL_DEC=CPE_MF_IS_POL_DEC and
CPE_MF_GN_POL_NUMBER=CPE_MF_IS_POL_NUMBER and
CPE_MF_GN_VER_DATE=CPE_MF_IS_VER_DATE and
CPE_MF_GN_POL_EXP_DATE=CPE_MF_IS_POL_EXP_DATE
AND RANKINGI=1
))policy ON(
    trim(policy.CPE_MF_GN_PREFIX_A) = trim(micro_gnrl.CPE_MF_GN_PREFIX_A)
    and trim(policy.CPE_MF_GN_PREFIX_B) = trim(micro_gnrl.CPE_MF_GN_PREFIX_B)
    and trim(policy.CPE_MF_GN_POL_BRANCH) = trim(micro_gnrl.CPE_MF_GN_POL_BRANCH)
    and trim(policy.CPE_MF_GN_POL_DEC) = trim(micro_gnrl.CPE_MF_GN_POL_DEC)
    and trim(policy.CPE_MF_GN_POL_NUMBER) = trim(micro_gnrl.CPE_MF_GN_POL_NUMBER)
    and trim(policy.cpe_MF_GN_VER_DATE) = trim(micro_gnrl.cpe_MF_GN_VER_DATE)
    and if(CPE_GN_CYCLE_DATE_1 is null,'null',CPE_GN_CYCLE_DATE_1) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE)
    )
where ranking=1
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_party_micro_batch_gnrl")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("POL_KEY","END_EFF_DT"), harmonized_table, "POLICY_ID","PCIO-COP")
}
