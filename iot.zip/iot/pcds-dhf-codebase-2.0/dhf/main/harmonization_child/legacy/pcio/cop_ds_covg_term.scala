// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_covg_term(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)

  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select DISTINCT 		
'PCIO-COP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER||'-'||CPE_MF_IT_SEQ_NUM1||'-'||CPE_MF_IT_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-'||COVG_CD||'-'||replacE(NAME,'_AMT','')||'-'||trim(CPE_IT_COV_TYPE) AS  COVG_TERM_KEY,		
'PCIO-COP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER AS POL_KEY,		
'PCIO-COP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER AS POL_LINE_KEY,		
case		
when trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G','E','I','X','C','K','S') THEN 		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3		
else 'NOKEY'		
END AS CVRBL_KEY,		
CASE 		
WHEN trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G') THEN 		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-COPLINEBLDG-'||COVG_CD 		
WHEN trim(CPE_IT_COV_TYPE) in ('E','I','X') then  		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-COPBUSINESSINCOME-'||COVG_CD 		
WHEN trim(CPE_IT_COV_TYPE) in ('C','K','S') then 		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-COPPERSPROP-'||COVG_CD		
ELSE 'NOKEY'		
END AS  LINE_COVG_KEY,		
to_Date(CPE_MF_IT_VER_DATE,'yyyyDDD') as END_EFF_DT,		
to_date(CPE_MF_IT_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,		
--to_timestamp(CPE_MF_IT_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
--IF(gnrl.CPE_GN_CYCLE_DATE IS NULL,TO_TIMESTAMP(gnrl.CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
--IF(cydate IS NULL,TO_TIMESTAMP(CPE_MF_IT_DATE,'yyyyDDD'), TO_TIMESTAMP(cydate,'yyyyDDD')) as ETL_ROW_EFF_DTS,
IF(to_timestamp(cydate, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(CPE_MF_IT_DATE,'yyyyDDD'), TO_TIMESTAMP(cydate,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,		
CASE 		
WHEN trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G') THEN 'COPLINEBLDG'		
WHEN trim(CPE_IT_COV_TYPE) in ('E','I','X') then   'COPBUSINESSINCOME'		
WHEN trim(CPE_IT_COV_TYPE) in ('C','K','S') then   'COPPERSPROP'		
ELSE ' '		
END AS CVRBL_TYPE_CD, 		
COVG_CD AS COVG_CD,		
replacE(NAME,'_AMT','') AS COVG_TERM_CD,		
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,		
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT		
FROM		
		
(select *,itm.CPE_GN_CYCLE_DATE as cydate,STACK(142,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQ",CPE_LC_RATE_STATE,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQ",CPE_BL_EQ_TERR,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQ",CPE_BL_EQ_BLD_CLS,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQ",CPE_BL_EQ_SUSP_GRD,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQ",CPE_BL_EQ_RAT_GRD,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQ",CPE_BL_EQ_ZONE,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQ",CPE_IT_EQ_SPLK_IND,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-EQ",CPE_IT_COV_LIMIT,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQ",CPE_IT_COIN_PCT,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQ",CPE_IT_EQ_DEDUCT_PCT,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQ",CPE_IT_EQ_FLAT_DEDUCT,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQ",CPE_BL_EQ_MSN_VNR,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQ",CPE_BL_EQ_NUM_STR,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQ",CPE_IT_REPL_COST_IND,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQ",CPE_IT_ORD_LAW_IND,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQ",CPE_IT_ROOF_ACV,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQ",CPE_IT_BLDRSK_RENOV,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQ",CPE_BL_BCEG,    		
		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BI_ALS_IND","NA"),"I-EQ",CPE_IT_BI_ALS_IND,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('E','I','X'),"PAY_EXP_DAYS","NA"),"I-EQ",CPE_IT_PAY_EXP_DAYS,		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-EQ",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),		
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('E','I','X'),"EXT_PERIOD_DAYS","NA"),"I-EQ",CPE_IT_INFL_GUARD_PCT,         --12		
		
		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQSPKL",CPE_LC_RATE_STATE,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQSPKL",CPE_BL_EQ_TERR,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQSPKL",CPE_BL_EQ_BLD_CLS,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQSPKL",CPE_BL_EQ_SUSP_GRD,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQSPKL",CPE_BL_EQ_RAT_GRD,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQSPKL",CPE_BL_EQ_ZONE,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQSPKL",CPE_IT_EQ_SPLK_IND,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-EQSPKL",CPE_IT_COV_LIMIT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQSPKL",CPE_IT_COIN_PCT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQSPKL",CPE_IT_EQ_DEDUCT_PCT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQSPKL",CPE_IT_EQ_FLAT_DEDUCT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQSPKL",CPE_BL_EQ_MSN_VNR,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQSPKL",CPE_BL_EQ_NUM_STR,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQSPKL",CPE_IT_REPL_COST_IND,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQSPKL",CPE_IT_ORD_LAW_IND,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQSPKL",CPE_IT_ROOF_ACV,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQSPKL",CPE_IT_BLDRSK_RENOV,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQSPKL",CPE_BL_BCEG, 		
		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BI_ALS_IND","NA"),"I-EQSPKL",CPE_IT_BI_ALS_IND,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"PAY_EXP_DAYS","NA"),"I-EQSPKL",CPE_IT_PAY_EXP_DAYS,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-EQSPKL",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"EXT_PERIOD_DAYS","NA"),"I-EQSPKL",CPE_IT_INFL_GUARD_PCT,    --13 		
		
		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQSUBLMT",CPE_LC_RATE_STATE,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQSUBLMT",CPE_BL_EQ_TERR,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQSUBLMT",CPE_BL_EQ_BLD_CLS,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQSUBLMT",CPE_BL_EQ_SUSP_GRD,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQSUBLMT",CPE_BL_EQ_RAT_GRD,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQSUBLMT",CPE_BL_EQ_ZONE,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQSUBLMT",CPE_IT_EQ_SPLK_IND,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQSUBLMT",CPE_IT_COIN_PCT,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_LIMIT_AMT","NA"),"I-EQSUBLMT",CPE_IT_EQ_SUB_LIMIT,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_PERCENT","NA"),"I-EQSUBLMT",CPE_IT_EQ_SUB_PERCENT,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQSUBLMT",CPE_IT_EQ_DEDUCT_PCT,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQSUBLMT",CPE_IT_EQ_FLAT_DEDUCT,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQSUBLMT",CPE_BL_EQ_MSN_VNR,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQSUBLMT",CPE_BL_EQ_NUM_STR,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQSUBLMT",CPE_IT_REPL_COST_IND,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQSUBLMT",CPE_IT_ORD_LAW_IND,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQSUBLMT",CPE_IT_ROOF_ACV,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQSUBLMT",CPE_IT_BLDRSK_RENOV,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQSUBLMT",CPE_BL_BCEG,   		
		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BI_ALS_IND","NA"),"I-EQSUBLMT",CPE_IT_BI_ALS_IND,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"PAY_EXP_DAYS","NA"),"I-EQSUBLMT",CPE_IT_PAY_EXP_DAYS,		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-EQSUBLMT",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),		
IF(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"EXT_PERIOD_DAYS","NA"),"I-EQSUBLMT",CPE_IT_INFL_GUARD_PCT,                                 --14		
		
		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQSUBSP",CPE_LC_RATE_STATE,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQSUBSP",CPE_BL_EQ_TERR,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQSUBSP",CPE_BL_EQ_BLD_CLS,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQSUBSP",CPE_BL_EQ_SUSP_GRD,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQSUBSP",CPE_BL_EQ_RAT_GRD,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQSUBSP",CPE_BL_EQ_ZONE,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQSUBSP",CPE_IT_EQ_SPLK_IND,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQSUBSP",CPE_IT_COIN_PCT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_LIMIT_AMT","NA"),"I-EQSUBSP",CPE_IT_EQ_SUB_LIMIT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_PERCENT","NA"),"I-EQSUBSP",CPE_IT_EQ_SUB_PERCENT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQSUBSP",CPE_IT_EQ_DEDUCT_PCT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQSUBSP",CPE_IT_EQ_FLAT_DEDUCT,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQSUBSP",CPE_BL_EQ_MSN_VNR,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQSUBSP",CPE_BL_EQ_NUM_STR,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQSUBSP",CPE_IT_REPL_COST_IND,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQSUBSP",CPE_IT_ORD_LAW_IND,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQSUBSP",CPE_IT_ROOF_ACV,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQSUBSP",CPE_IT_BLDRSK_RENOV,		
if(CPE_IT_EQ_IND = 'Y' AND CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQSUBSP",CPE_BL_BCEG,               --15		
		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-CAPTHEFT",CPE_LC_RATE_STATE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"GROUP1_TERR","NA"),"I-CAPTHEFT",CPE_LC_GROUP1_TERR,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"PROT_CLASS","NA"),"I-CAPTHEFT",CPE_LC_PROT_CLASS,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-CAPTHEFT",CPE_BL_CONST_TYPE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CLASS_CODE","NA"),"I-CAPTHEFT",CPE_BL_CLASS_CODE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-CAPTHEFT",CPE_IT_COIN_PCT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-CAPTHEFT",CPE_IT_COV_LIMIT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K'),"YEAR_BUILT","NA"),"I-CAPTHEFT",CPE_BL_YEAR_BUILT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-CAPTHEFT",CPE_IT_REPL_COST_IND,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-CAPTHEFT",CPE_BL_ALL_OTHER_DED_AMOUNT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-CAPTHEFT",CPE_IT_INFL_GUARD_PCT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SPLK_IND","NA"),"I-CAPTHEFT",CPE_IT_SPLK_IND,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"VMM_IND","NA"),"I-CAPTHEFT",CPE_IT_VMM_IND,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-CAPTHEFT",CPE_IT_ROOF_ACV,   --IGRP1SV                            		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-CAPTHEFT",CPE_LC_RATE_STATE,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"OCCUP_GROUP_CD","NA"),"I-CAPTHEFT",CPE_BL_OCCUP_GROUP_CD,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-CAPTHEFT",CPE_IT_COIN_PCT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-CAPTHEFT",CPE_IT_COV_LIMIT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-CAPTHEFT",CPE_BL_YEAR_BUILT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-CAPTHEFT",CPE_IT_REPL_COST_IND,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-CAPTHEFT",CPE_IT_INFL_GUARD_PCT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-CAPTHEFT",CPE_BL_ALL_OTHER_DED_AMOUNT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"THEFT_DEDUCTIBLE_AMT","NA"),"I-CAPTHEFT",CPE_BL_THEFT_DEDUCTIBLE,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-CAPTHEFT",CPE_IT_ROOF_ACV,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SC_THEFT_IND","NA"),"I-CAPTHEFT",CPE_IT_SC_THEFT_IND,		
		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"SC_THEFT_IND","NA"),"I-CAPTHEFT",CPE_IT_SC_THEFT_IND,  ----26		
		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-CAPCOL",CPE_LC_RATE_STATE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"GROUP1_TERR","NA"),"I-CAPCOL",CPE_LC_GROUP1_TERR,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"PROT_CLASS","NA"),"I-CAPCOL",CPE_LC_PROT_CLASS,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-CAPCOL",CPE_BL_CONST_TYPE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CLASS_CODE","NA"),"I-CAPCOL",CPE_BL_CLASS_CODE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-CAPCOL",CPE_IT_COIN_PCT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-CAPCOL",CPE_IT_COV_LIMIT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K'),"YEAR_BUILT","NA"),"I-CAPCOL",CPE_BL_YEAR_BUILT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-CAPCOL",CPE_IT_REPL_COST_IND,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-CAPCOL",CPE_BL_ALL_OTHER_DED_AMOUNT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-CAPCOL",CPE_IT_INFL_GUARD_PCT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SPLK_IND","NA"),"I-CAPCOL",CPE_IT_SPLK_IND,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"VMM_IND","NA"),"I-CAPCOL",CPE_IT_VMM_IND,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and  trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-CAPCOL",CPE_IT_ROOF_ACV,   --IGRP1SV                            		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-CAPCOL",CPE_LC_RATE_STATE,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"OCCUP_GROUP_CD","NA"),"I-CAPCOL",CPE_BL_OCCUP_GROUP_CD,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-CAPCOL",CPE_IT_COIN_PCT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-CAPCOL",CPE_IT_COV_LIMIT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-CAPCOL",CPE_BL_YEAR_BUILT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-CAPCOL",CPE_IT_REPL_COST_IND,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-CAPCOL",CPE_IT_INFL_GUARD_PCT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-CAPCOL",CPE_BL_ALL_OTHER_DED_AMOUNT,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-CAPCOL",CPE_IT_ROOF_ACV,		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SC_THEFT_IND","NA"),"I-CAPCOL",CPE_IT_SC_THEFT_IND,		
		
If(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_IT_GROUP1_IND='Y' AND  CPE_IT_SC_THEFT_IND='Y' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"SC_THEFT_IND","NA"),"I-CAPCOL",CPE_IT_SC_THEFT_IND,                          --25		
		
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE<>'013' AND CPE_IT_ALE_WAIVED_IND<>'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-MINE",CPE_LC_RATE_STATE,		
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE<>'013' AND CPE_IT_ALE_WAIVED_IND<>'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"ILL_MINE_COV_LIMIT_AMT","NA"),"I-MINE",CPE_IT_ILL_MINE_COV_LIMIT, --23		
		
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE='013' AND CPE_IT_ALE_WAIVED_IND='N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-MINEALE",CPE_LC_RATE_STATE,		
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE='013' AND CPE_IT_ALE_WAIVED_IND='N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"ILL_MINE_COV_LIMIT_AMT","NA"),"I-MINEALE",CPE_IT_ILL_MINE_COV_LIMIT,		
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE='013' AND CPE_IT_ALE_WAIVED_IND='N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"ALE_WAIVED_IND","NA"),"I-MINEALE",CPE_IT_ALE_WAIVED_IND     --24		
) AS (NAME,COVG_CD,VALUE)
FROM

(select distinct * from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IT_PREFIX_A,CPE_MF_IT_POL_BRANCH,CPE_MF_IT_POL_DEC,CPE_MF_IT_POL_NUMBER,CPE_MF_IT_PREFIX_B,CPE_MF_IT_POL_EXP_DATE,CPE_MF_IT_VER_DATE,CPE_MF_IT_REC_TYPE,CPE_MF_IT_SEQ_NUM1,CPE_MF_IT_SEQ_NUM2,CPE_MF_IT_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_IT_DATE ,CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_item.*
   from
   {rawDB}.cop_item
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
    mb.CPE_MF_GN_PREFIX_A= cop_item.CPE_MF_IT_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_item.CPE_MF_IT_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_item.CPE_MF_IT_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_item.CPE_MF_IT_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_item.CPE_MF_IT_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_item.CPE_MF_IT_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_item.CPE_MF_IT_VER_DATE


            

              )
  ) WHERE rn = 1  ) ) itm

 inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A,CPE_MF_BL_POL_BRANCH,CPE_MF_BL_POL_DEC,CPE_MF_BL_POL_NUMBER,CPE_MF_BL_PREFIX_B,CPE_MF_BL_POL_EXP_DATE,CPE_MF_BL_VER_DATE,CPE_MF_BL_REC_TYPE,CPE_MF_BL_SEQ_NUM1,CPE_MF_BL_SEQ_NUM2,CPE_MF_BL_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_BL_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_gnrl_micro_batch mb
             on 
			 mb.CPE_MF_GN_PREFIX_A= cop_bldg.CPE_MF_BL_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_bldg.CPE_MF_BL_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_bldg.CPE_MF_BL_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_bldg.CPE_MF_BL_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_bldg.CPE_MF_BL_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_bldg.CPE_MF_BL_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_bldg.CPE_MF_BL_VER_DATE

              )
  ) WHERE rn = 1  )  
  bldg 		
on		
CPE_MF_BL_PREFIX_A=CPE_MF_IT_PREFIX_A and 		
CPE_MF_BL_PREFIX_B=CPE_MF_IT_PREFIX_B and		
CPE_MF_BL_POL_BRANCH=CPE_MF_IT_POL_BRANCH and		
CPE_MF_BL_POL_DEC=CPE_MF_IT_POL_DEC and		
CPE_MF_BL_POL_NUMBER=CPE_MF_IT_POL_NUMBER and		
CPE_MF_BL_SEQ_NUM1=CPE_MF_IT_SEQ_NUM1 AND		
CPE_MF_BL_SEQ_NUM2=CPE_MF_IT_SEQ_NUM2 and		
CPE_MF_BL_VER_DATE =CPE_MF_IT_VER_DATE AND		
CPE_MF_BL_POL_EXP_DATE=CPE_MF_IT_POL_EXP_DATE 

inner join		
(select distinct * from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A,CPE_MF_LC_POL_BRANCH,CPE_MF_LC_POL_DEC,CPE_MF_LC_POL_NUMBER,CPE_MF_LC_PREFIX_B,CPE_MF_LC_POL_EXP_DATE,CPE_MF_LC_VER_DATE,CPE_MF_LC_REC_TYPE,CPE_MF_LC_SEQ_NUM1,CPE_MF_LC_SEQ_NUM2,CPE_MF_LC_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
    mb.CPE_MF_GN_PREFIX_A= cop_location.CPE_MF_LC_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_location.CPE_MF_LC_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_location.CPE_MF_LC_VER_DATE

            

              )
  ) WHERE rn = 1  ) ) lctn		
on		
CPE_MF_BL_PREFIX_A=CPE_MF_LC_PREFIX_A and		
CPE_MF_BL_POL_BRANCH=CPE_MF_LC_POL_BRANCH and		
CPE_MF_BL_POL_DEC=CPE_MF_LC_POL_DEC and		
CPE_MF_BL_POL_NUMBER=CPE_MF_LC_POL_NUMBER and		
CPE_MF_BL_PREFIX_B=CPE_MF_LC_PREFIX_B and		
CPE_MF_BL_POL_EXP_DATE=CPE_MF_LC_POL_EXP_DATE and		
CPE_MF_BL_VER_DATE=CPE_MF_LC_VER_DATE and		
CPE_MF_BL_SEQ_NUM1=CPE_MF_LC_SEQ_NUM1 )where name!='NA' and  trim(value)!=''	
--) --4949312

-- SECOND UNION--HAR--
	
-- 
		
union all		
		
select  DISTINCT 		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1||'-'||COVG_CD||'-'||replacE(NAME,'_AMT','') AS COVG_TERM_KEY,		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER AS POL_KEY,		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER AS POL_LINE_KEY,		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1 AS CVRBL_KEY,		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1||'-COPLOCATION-'||COVG_CD AS LINE_COVG_KEY,		
to_date(CPE_MF_LC_VER_DATE,'yyyyDDD') AS END_EFF_DT,		
to_date(CPE_MF_LC_POL_EXP_DATE,'yyyyDDD') AS END_EXP_DT,		
--to_timestamp(CPE_MF_LC_DATE,'yyyyDDD') AS ETL_ROW_EFF_DTS,
--IF(DATE_1 IS NULL,TO_TIMESTAMP(CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(DATE_1,'yyyyDDD')) as ETL_ROW_EFF_DTS,
IF(to_timestamp(DATE_1, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(DATE_1,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,		
'COPLOCATION' AS CVRBL_TYPE_CD, 		
COVG_CD AS COVG_CD,		
replacE(NAME,'_AMT','') AS COVG_TERM_CD,		
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,		
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT		
from 		
(select *,DATE_1, STACK(25,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_SCORE","NA"),'L-FLOOD',CPE_LC_FLOOD_SCORE,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_FLASH_SCORE","NA"),'L-FLOOD',CPE_LC_FLOOD_FLASH_SCORE,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_BLDG_FL","NA"),'L-FLOOD',CPE_LC_FLOOD_BLDG,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_BPP_FL","NA"),'L-FLOOD',CPE_LC_FLOOD_BPP,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_BI_FL","NA"),'L-FLOOD',CPE_LC_FLOOD_BI,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_RISK_TYPE","NA"),'L-FLOOD',CPE_LC_FLOOD_RISK_TYPE,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_ZONE","NA"),'L-FLOOD',CPE_LC_FLOOD_ZONE,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_CONT_VALUES","NA"),'L-FLOOD',CPE_LC_FLOOD_CONT_VALUES,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_2X_AGG_LIMIT_FL","NA"),'L-FLOOD',CPE_LC_FLOOD_AGG_LIMIT,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_LIMIT_AMT","NA"),'L-FLOOD',CPE_LC_FLOOD_LIMIT,		
IF(CPE_LC_FLOOD_PREM>0 and (CPE_GN_POL_EFF_DATE<'15001' or CPE_GN_POL_EFF_DATE>'15151'),"FLOOD_DED_AMT","NA"),'L-FLOOD',CPE_LC_FLOOD_DED,		
		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_SCORE","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_SCORE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_FLASH_SCORE","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_FLASH_SCORE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_BLDG_FL","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_BLDG,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_BPP_FL","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_BPP,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_BI_FL","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_BI,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_BLANKET","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_BLANKET,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_RISK_TYPE","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_RISK_TYPE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_ZONE","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_ZONE,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_CONT_VALUES","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_CONT_VALUES,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_2X_AGG_LIMIT_FL","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_AGG_LIMIT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_LIMIT_AMT","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_LIMIT,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_DED_AMT","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_DED,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"FLOOD_MIN_DED_AMT","NA"),'L-CAPFLOOD',CPE_LC_FLOOD_MIN_DED,		
if(CPE_MF_LC_PREFIX_B  LIKE '%COP%' and CPE_LC_FLOOD_PREM>0 and CPE_GN_POL_EFF_DATE>='15001' AND CPE_GN_POL_EFF_DATE<='15151',"TOTAL_FLOOD_LMT_AMT","NA"),'L-CAPFLOOD',CPE_LC_TOTAL_FLOOD_LMT 		
) AS (NAME,COVG_CD,VALUE)
from 
( select gnrl.*,lctn.*,gnrl.CPE_GN_CYCLE_DATE as DATE_1 from (
(select distinct * from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A,CPE_MF_LC_POL_BRANCH,CPE_MF_LC_POL_DEC,CPE_MF_LC_POL_NUMBER,CPE_MF_LC_PREFIX_B,CPE_MF_LC_POL_EXP_DATE,CPE_MF_LC_VER_DATE,CPE_MF_LC_REC_TYPE,CPE_MF_LC_SEQ_NUM1,CPE_MF_LC_SEQ_NUM2,CPE_MF_LC_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
    mb.CPE_MF_GN_PREFIX_A= cop_location.CPE_MF_LC_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_location.CPE_MF_LC_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_location.CPE_MF_LC_VER_DATE


              )
  ) WHERE rn = 1  ) ) lctn		
inner join 		
(select distinct * from global_temp.cop_gnrl_micro_batch ) micro_gnrl
 inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,CPE_MF_GN_POL_BRANCH,CPE_MF_GN_POL_DEC,CPE_MF_GN_POL_NUMBER,CPE_MF_GN_PREFIX_B,CPE_MF_GN_POL_EXP_DATE,CPE_MF_GN_VER_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_GN_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_GNRL.*
   from
   {rawDB}.cop_GNRL
   inner join global_temp.cop_gnrl_micro_batch mb
   
  on  mb.CPE_MF_GN_PREFIX_A= cop_GNRL.CPE_MF_GN_PREFIX_A
and mb.CPE_MF_GN_POL_BRANCH=cop_GNRL.CPE_MF_GN_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_GNRL.CPE_MF_GN_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_GNRL.CPE_MF_GN_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_GNRL.CPE_MF_GN_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_GNRL.CPE_MF_GN_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_GNRL.CPE_MF_GN_VER_DATE
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1)    gnrl		
ON 		
gnrl.CPE_MF_GN_PREFIX_A=lctn.CPE_MF_LC_PREFIX_A and		
gnrl.CPE_MF_GN_POL_BRANCH=lctn.CPE_MF_LC_POL_BRANCH and		
gnrl.CPE_MF_GN_POL_DEC=lctn.CPE_MF_LC_POL_DEC and		
gnrl.CPE_MF_GN_POL_NUMBER=lctn.CPE_MF_LC_POL_NUMBER and		
gnrl.CPE_MF_GN_PREFIX_B=lctn.CPE_MF_LC_PREFIX_B and		
gnrl.CPE_MF_GN_POL_EXP_DATE=lctn.CPE_MF_LC_POL_EXP_DATE and		
gnrl.CPE_MF_GN_VER_DATE=lctn.CPE_MF_LC_VER_DATE 
))
 )		
WHERE NAME!='NA' and  trim(value)!=''	

--)---121977

union all
select DISTINCT 		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||COVG_CD||'-'||replacE(NAME,'_AMT','') COVG_TERM_KEY,		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER as POL_KEY,		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER as POL_LINE_KEY,		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2 AS CVRBL_KEY, --BLDG_KEY		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-' ||CPE_MF_BL_SEQ_NUM2||'-COPBLDG-'||COVG_CD AS LINE_COVG_KEY,		
to_date(CPE_MF_BL_VER_DATE,'yyyyDDD') as END_EFF_DT,		
TO_DATE(CPE_MF_BL_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,		
--to_timestamp(CPE_MF_BL_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,	
--IF(bdate IS NULL,TO_TIMESTAMP(CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(bdate,'yyyyDDD')) as ETL_ROW_EFF_DTS,
IF(to_timestamp(bdate, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(bdate,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,		
'COPBLDG' AS CVRBL_TYPE_CD, 		
COVG_CD AS COVG_CD,		
replacE(NAME,'_AMT','') AS COVG_TERM_CD,		
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,		
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT		
from		
(select *,bldg.CPE_GN_CYCLE_DATE as bdate,
stack(5,if(CPE_BL_LL_PREM >0,"LL_TYPE","NA"),"B-LEGLIAB",CPE_BL_LL_TYPE,		
        if(CPE_BL_LL_PREM >0,"LL_LIMIT_AMT","NA"),"B-LEGLIAB",CPE_BL_LL_LIMIT,		
        if(CPE_BL_LL_PREM >0,"LL_INC_FAC_IND","NA"),"B-LEGLIAB",CPE_BL_LL_INC_FAC_IND,		
        if(CPE_BL_LL_PREM >0,"ALL_OTHER_DED_AMOUNT_AMT","NA"),"B-LEGLIAB",CPE_BL_ALL_OTHER_DED_AMOUNT,		
        if(CPE_BL_LL_PREM >0,"RATE_STATE","NA"),"B-LEGLIAB",CPE_LC_RATE_STATE		
) AS (NAME,COVG_CD,VALUE)		
FROM 		
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A,CPE_MF_BL_POL_BRANCH,CPE_MF_BL_POL_DEC,CPE_MF_BL_POL_NUMBER,CPE_MF_BL_PREFIX_B,CPE_MF_BL_POL_EXP_DATE,CPE_MF_BL_VER_DATE,CPE_MF_BL_REC_TYPE,CPE_MF_BL_SEQ_NUM1,CPE_MF_BL_SEQ_NUM2,CPE_MF_BL_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_BL_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_gnrl_micro_batch mb
             on 
			 mb.CPE_MF_GN_PREFIX_A= cop_bldg.CPE_MF_BL_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_bldg.CPE_MF_BL_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_bldg.CPE_MF_BL_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_bldg.CPE_MF_BL_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_bldg.CPE_MF_BL_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_bldg.CPE_MF_BL_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_bldg.CPE_MF_BL_VER_DATE
-- 
              )
  ) WHERE rn = 1  )  
  bldg  		
inner join 		
(select distinct * from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A,CPE_MF_LC_POL_BRANCH,CPE_MF_LC_POL_DEC,CPE_MF_LC_POL_NUMBER,CPE_MF_LC_PREFIX_B,CPE_MF_LC_POL_EXP_DATE,CPE_MF_LC_VER_DATE,CPE_MF_LC_REC_TYPE,CPE_MF_LC_SEQ_NUM1,CPE_MF_LC_SEQ_NUM2,CPE_MF_LC_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
    mb.CPE_MF_GN_PREFIX_A= cop_location.CPE_MF_LC_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_location.CPE_MF_LC_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_location.CPE_MF_LC_VER_DATE

            )
  ) WHERE rn = 1  ) ) lctn				
on		
CPE_MF_BL_PREFIX_A=CPE_MF_LC_PREFIX_A and		
CPE_MF_BL_POL_BRANCH=CPE_MF_LC_POL_BRANCH and		
CPE_MF_BL_POL_DEC=CPE_MF_LC_POL_DEC and		
CPE_MF_BL_POL_NUMBER=CPE_MF_LC_POL_NUMBER and		
CPE_MF_BL_PREFIX_B=CPE_MF_LC_PREFIX_B and		
CPE_MF_BL_POL_EXP_DATE=CPE_MF_LC_POL_EXP_DATE and		
CPE_MF_BL_VER_DATE=CPE_MF_LC_VER_DATE and		
CPE_MF_BL_SEQ_NUM1=CPE_MF_LC_SEQ_NUM1 		
 )		
where name!='NA' and  trim(value)!=''	

union all 
--FOURTH UNION -- HAR --
--select count(*) from(
select distinct 		
'PCIO-COP-'||CPE_MF_GN_PREFIX_A||CPE_MF_GN_PREFIX_B||CPE_MF_GN_POL_BRANCH||CPE_MF_GN_POL_DEC||CPE_MF_GN_POL_NUMBER||'-'||replacE(NAME,'_AMT','') AS COVG_TERM_KEY,		
'PCIO-COP-'||CPE_MF_GN_PREFIX_A||CPE_MF_GN_PREFIX_B||CPE_MF_GN_POL_BRANCH||CPE_MF_GN_POL_DEC||CPE_MF_GN_POL_NUMBER AS POL_KEY,		
'PCIO-COP-'||CPE_MF_GN_PREFIX_A||CPE_MF_GN_PREFIX_B||CPE_MF_GN_POL_BRANCH||CPE_MF_GN_POL_DEC||CPE_MF_GN_POL_NUMBER AS POL_LINE_KEY,		
'PCIO-COP-'||CPE_MF_GN_PREFIX_A||CPE_MF_GN_PREFIX_B||CPE_MF_GN_POL_BRANCH||CPE_MF_GN_POL_DEC||CPE_MF_GN_POL_NUMBER AS CVRBL_KEY,		
'NOKEY' AS  LINE_COVG_KEY,		
to_date(CPE_MF_GN_VER_DATE,'yyyyDDD') as END_EFF_DT,		
TO_DATE(CPE_MF_GN_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,		
--TO_TIMESTAMP(CPE_MF_GN_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
--IF(CPE_GN_CYCLE_DATE IS NULL,TO_TIMESTAMP(CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
IF(to_timestamp(CPE_GN_CYCLE_DATE, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,		
'COPLINE' AS CVRBL_TYPE_CD, 		
' ' AS COVG_CD,		
replacE(NAME,'_AMT','') AS COVG_TERM_CD,		
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,		
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT		
 from 		
 (select *,		
 stack(59,"BLANKET_IND",CPE_GN_BLANKET_IND,		
         "BLANKET_BUILDING",CPE_GN_BLANKET_BUILDING,		
         "BLANKET_CONTENTS",CPE_GN_BLANKET_CONTENTS,		
         "BLANKET_BUS_INCOME",CPE_GN_BLANKET_BUS_INCOME,		
         "BLANKET_COINS_PERCENT",CPE_GN_BLANKET_CO_PERCENT,		
         "BLANKET_HIGH_WEIGHT",CPE_GN_BLANKET_HIGH_WEIGHT, 		
         "BLANKET_BLDG_CNTS",CPE_GN_BLANKET_BLDG_CNTS,		
         "BLANKET_OVERRIDE_VALUE",CPE_GN_BLANKET_OVERRIDE_VALUE,		
         "BLKT_TOT_BLDG_LIMIT_AMT",CPE_GN_BLKT_TOT_BLDG_LIMIT,		
         "BLKT_TOT_CONT_LIMIT_AMT",CPE_GN_BLKT_TOT_CONT_LIMIT,		
         "BLKT_TOT_BUS_INCM_LIMIT_AMT",CPE_GN_BLKT_TOT_TIME_LIMIT,		
         		
 "EQ_BLKT_LIMIT_AMT",CPE_GN_EQ_BLKT_LIMIT, 		
 "ACCT_RECEV_LIMIT_AMT",CPE_GN_ACCT_RECEV_LIMIT,		
 "AUTO_INCR_PCT",CPE_GN_AUTO_INCR_PCT,		
 "GRND_WATER_LIMIT_AMT",CPE_GN_GRND_WATER_LIMIT ,		
 "LIQD_STOR_TNK_LIMIT_AMT",CPE_GN_LIQD_STOR_TNK_LIMIT,		
 "BPP_OFF_LIMIT_AMT",CPE_GN_BPP_OFF_LIMIT,		
 "BPP_TMP_LIMIT_AMT",CPE_GN_BPP_TMP_LIMIT ,		
 "CONSQ_LOSS_LIMIT_AMT",CPE_GN_CONSQ_LOSS_LIMIT,		
 "DEBR_REML_LIMIT_AMT",CPE_GN_DEBR_REML_LIMIT ,		
 "ELECTR_DATA_LIMIT_AMT",CPE_GN_ELECTR_DATA_LIMIT,		
 "FINE_ARTS_LIMIT_AMT",CPE_GN_FINE_ARTS_LIMIT,		
 "FIRE_DEPT_LIMIT_AMT",CPE_GN_FIRE_DEPT_LIMIT,		
 "FIRE_EXTIR_LIMIT_AMT",CPE_GN_FIRE_EXTIR_LIMIT ,		
 "FUR_GARMT_LIMIT_AMT",CPE_GN_FUR_GARMT_LIMIT ,		
 "INSTALL_PROP_LIMIT_AMT",CPE_GN_INSTALL_PROP_LIMIT,		
 "INV_APPR_EXP_LIMIT_AMT",CPE_GN_INV_APPR_EXP_LIMIT,		
 "JEWEL_THEFT_LIMIT_AMT",CPE_GN_JEWEL_THEFT_LIMIT,		
 "FUG_WET_DRY_LIMIT_AMT",CPE_GN_FUG_WET_DRY_LIMIT ,		
 "ORD_LAW_DEMO_LIMIT_AMT",CPE_GN_ORD_LAW_DEMO_LIMIT ,		
 "ORD_LAW_INCR_LIMIT_AMT",CPE_GN_ORD_LAW_INCR_LIMIT ,		
 "PERS_EFFECT_LIMIT_AMT",CPE_GN_PERS_EFFECT_LIMIT,		
 "POLLUT_CLUP_LIMIT_AMT",CPE_GN_POLLUT_CLUP_LIMIT ,		
 "PROP_INTRAN_LIMIT_AMT",CPE_GN_PROP_INTRAN_LIMIT,		
 "REWARD_PAY_LIMIT_AMT",CPE_GN_REWARD_PAY_LIMIT ,		
 "STAMP_THEFT_LIMIT_AMT",CPE_GN_STAMP_THEFT_LIMIT,		
 "PAPER_RECORD_LIMIT_AMT",CPE_GN_PAPER_RECORD_LIMIT,		
 "EMP_THEFT_LIMIT_AMT",CPE_GN_EMP_THEFT_LIMIT ,		
  "FORGRY_ALT_LIMIT_AMT",CPE_GN_FORGRY_ALT_LIMIT,		
 "MONY_SECRT_IN_LIMIT_AMT",CPE_GN_MONY_SECRT_IN_LIMIT,		
 "MONY_SECRT_OU_LIMIT_AMT",CPE_GN_MONY_SECRT_OU_LIMIT,		
 "CTFT_MONY_ORD_LIMIT_AMT",CPE_GN_CTFT_MONY_ORD_LIMIT,		
 "FOOD_CONT_LOS_LIMIT_AMT",CPE_GN_FOOD_CONT_LOS_LIMIT ,		
 "FOOD_ADV_EXP_LIMIT_AMT",CPE_GN_FOOD_ADV_EXP_LIMIT,		
 "INTER_CMP_OPS_LIMIT_AMT",CPE_GN_INTER_CMP_OPS_LIMIT ,		
 "ACQD_SCHED_LIMIT_AMT",CPE_GN_ACQD_SCHED_LIMIT 	,	
 "TERR_BPP_IND",CPE_GN_TERR_BPP_IND,		
 "GRND_WATER_IND",CPE_GN_GRND_WATER_IND,		
 "FLSE_PRET_IND",CPE_GN_FLSE_PRET_IND,		
 "GREEN_UPG_IND",CPE_GN_GREEN_UPG_IND ,		
 "MFR_SELL_PRCE_IND",CPE_GN_MFR_SELL_PRCE_IND  ,		
 "PROP_ADDL_EXCL_IND",CPE_GN_PROP_ADDL_EXCL_IND,		
 "RAIL_STK_IND",CPE_GN_RAIL_STK_IND,		
 "SCHD_MOB_EQP_IND",CPE_GN_SCHD_MOB_EQP_IND,		
 "TRANS_BACK_HUL_IND",CPE_GN_TRANS_BACK_HUL_IND ,		
 "VECH_DAMAGE_IND",CPE_GN_VECH_DAMAGE_IND ,		
 "OPER_LEGAL_LIAB_IND",CPE_GN_OPER_LEGAL_LIAB_IND,		
 "ADP_GROUP_NUMBER",CPE_GN_ADP_GROUP_NUMBER ,		
 "EXTND_BI_DAY_LIMIT",CPE_GN_EXTND_BI_DAY_LIMIT		
          ) AS (NAME,VALUE)		
       FROM  --dhf_pcio_policy_2021hist.cop_gnrl
       ( select gnrl.* from (
       (select  * from global_temp.cop_gnrl_micro_batch ) micro_gnrl

 inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,CPE_MF_GN_POL_BRANCH,CPE_MF_GN_POL_DEC,CPE_MF_GN_POL_NUMBER,CPE_MF_GN_PREFIX_B,CPE_MF_GN_POL_EXP_DATE,CPE_MF_GN_VER_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_GN_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_GNRL.*
   from
   {rawDB}.cop_GNRL
   inner join global_temp.cop_gnrl_micro_batch mb
   
  on  mb.CPE_MF_GN_PREFIX_A= cop_GNRL.CPE_MF_GN_PREFIX_A
and mb.CPE_MF_GN_POL_BRANCH=cop_GNRL.CPE_MF_GN_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_GNRL.CPE_MF_GN_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_GNRL.CPE_MF_GN_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_GNRL.CPE_MF_GN_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_GNRL.CPE_MF_GN_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_GNRL.CPE_MF_GN_VER_DATE
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) gnrl	
   
  on  gnrl.CPE_MF_GN_PREFIX_A= micro_gnrl.CPE_MF_GN_PREFIX_A
and gnrl.CPE_MF_GN_POL_BRANCH=micro_gnrl.CPE_MF_GN_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC=micro_gnrl.CPE_MF_GN_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER =micro_gnrl.CPE_MF_GN_POL_NUMBER
and gnrl.CPE_MF_GN_PREFIX_B=micro_gnrl.CPE_MF_GN_PREFIX_B
and gnrl.CPE_MF_GN_POL_EXP_DATE=micro_gnrl.CPE_MF_GN_POL_EXP_DATE
and gnrl.CPE_MF_GN_VER_DATE=micro_gnrl.CPE_MF_GN_VER_DATE
  ))
          )where name!='NA' and  trim(value)!=''
  --)--101007
  
  union all 
  --FIFTH UNION --HAR
--select count(*) from (
select distinct 		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1||'-'||replacE(NAME,'_AMT','') AS COVG_TERM_KEY,		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER AS POL_KEY,		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER AS POL_LINE_KEY,		
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1 AS CVRBL_KEY,		
'NOKEY' AS  LINE_COVG_KEY,		
to_date(CPE_MF_LC_VER_DATE,'yyyyDDD') as END_EFF_DT,		
TO_DATE(CPE_MF_LC_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,		
--TO_TIMESTAMP(CPE_MF_LC_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
--IF(CPE_GN_CYCLE_DATE IS NULL,TO_TIMESTAMP(CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
IF(to_timestamp(CPE_GN_CYCLE_DATE, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,		
'COPLOCATION'  AS CVRBL_TYPE_CD, 		
' ' AS COVG_CD,		
replacE(NAME,'_AMT','') AS COVG_TERM_CD,		
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,		
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT		
 from 		
 (select *,		
 stack(1,"ADP_BLANKET_IND",CPE_LC_ADP_BLANKET_IND )		
    AS (NAME,VALUE) FROM  --dhf_pcio_policy_2021hist.cop_location
    (select distinct * from  
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A,CPE_MF_LC_POL_BRANCH,CPE_MF_LC_POL_DEC,CPE_MF_LC_POL_NUMBER,CPE_MF_LC_PREFIX_B,CPE_MF_LC_POL_EXP_DATE,CPE_MF_LC_VER_DATE,CPE_MF_LC_REC_TYPE,CPE_MF_LC_SEQ_NUM1,CPE_MF_LC_SEQ_NUM2,CPE_MF_LC_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE,CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
    mb.CPE_MF_GN_PREFIX_A= cop_location.CPE_MF_LC_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_location.CPE_MF_LC_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_location.CPE_MF_LC_VER_DATE

            

              )
  ) WHERE rn = 1  ) ) lctn		
    ) where trim(value)!=''	
 -- )--56967
 
 union all 
 --six union --HAR
--select count(*) from (
select DISTINCT 		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||replacE(NAME,'_AMT','') COVG_TERM_KEY,		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER as POL_KEY,		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER as POL_LINE_KEY,		
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2 AS CVRBL_KEY, --BLDG_KEY		
'NOKEY' AS LINE_COVG_KEY,		
to_date(CPE_MF_BL_VER_DATE,'yyyyDDD') as END_EFF_DT,		
TO_DATE(CPE_MF_BL_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,		
--to_timestamp(CPE_MF_BL_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,	
--IF(CPE_GN_CYCLE_DATE IS NULL,TO_TIMESTAMP(CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
IF(to_timestamp(CPE_GN_CYCLE_DATE, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,

'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,		
'COPBLDG' AS CVRBL_TYPE_CD, 		
' '  AS COVG_CD,		
replacE(NAME,'_AMT','') AS COVG_TERM_CD,		
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,		
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT		
from		
(select *,		
stack(1,"ADP_EQBLKT_IND",CPE_BL_ADP_EQBLKT_IND)		
 AS (NAME,VALUE) FROM -- dhf_pcio_policy_2021hist.cop_BLDG	
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A,CPE_MF_BL_POL_BRANCH,CPE_MF_BL_POL_DEC,CPE_MF_BL_POL_NUMBER,CPE_MF_BL_PREFIX_B,CPE_MF_BL_POL_EXP_DATE,CPE_MF_BL_VER_DATE,CPE_MF_BL_REC_TYPE,CPE_MF_BL_SEQ_NUM1,CPE_MF_BL_SEQ_NUM2,CPE_MF_BL_SEQ_NUM3 ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_BL_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_gnrl_micro_batch mb
             on 
			 mb.CPE_MF_GN_PREFIX_A= cop_bldg.CPE_MF_BL_PREFIX_A 
and mb.CPE_MF_GN_POL_BRANCH=cop_bldg.CPE_MF_BL_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC=cop_bldg.CPE_MF_BL_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER =cop_bldg.CPE_MF_BL_POL_NUMBER
and mb.CPE_MF_GN_PREFIX_B=cop_bldg.CPE_MF_BL_PREFIX_B
and mb.CPE_MF_GN_POL_EXP_DATE=cop_bldg.CPE_MF_BL_POL_EXP_DATE
and mb.CPE_MF_GN_VER_DATE=cop_bldg.CPE_MF_BL_VER_DATE

              )
  ) WHERE rn = 1  )  
  bldg 
    ) where trim(value)!='' 
   -- )--91720
  

  


"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"cop_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
     //queryDF.createOrReplaceGlobalTempView(s"V")
     // val hashDF = addHashColumn_clt("V","COVG_TERM_ID ")
    mergeAndWrite(queryDF,List("COVG_TERM_KEY","END_EFF_DT"), harmonized_table, "COVG_TERM_ID","PCIO-COP")
}
