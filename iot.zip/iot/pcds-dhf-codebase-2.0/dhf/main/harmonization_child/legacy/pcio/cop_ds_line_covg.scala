// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_line_covg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
select distinct
CASE 
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'P%' then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-COPLINE-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'L%' then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-COPLOCATION-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'B%' then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-COPBLDG-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
when fact.PHW930PP_X_COV_SHORT_NAME like 'I%' and trim(fact.PHW930PP_ITEM_TYPE) in ('B','D','F','H','J','P','G') then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')||'-COPLINEBLDG-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('E','I','X') then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')||'-COPBUSINESSINCOME-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('C','K','S') then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')||'-COPPERSPROP-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
ELSE 'NOKEY'
END AS LINE_COVG_KEY,
'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER as POL_KEY,
'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER as POL_LINE_KEY,
IFNULL('PCIO-COP-'||trim(fact.PHW930PP_X_COV_SHORT_NAME),'NOKEY') AS COVG_KEY,
CASE 
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'P%' then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'L%' then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'B%' then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')
when fact.PHW930PP_X_COV_SHORT_NAME like 'I%' and trim(fact.PHW930PP_ITEM_TYPE) in ('B','D','F','H','J','P','G') then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('E','I','X') then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('C','K','S') then 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')
ELSE 'NOKEY'
END AS CVRBL_KEY,
ifnull(to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy'),cast('1900-01-01' as date)) AS END_EFF_DT,
ifnull(to_date(fact.PHW930PP_D_EXPIRATION1,'MM/dd/yyyy'),cast('1900-01-01' as date)) AS END_EXP_DT,
if(fact.PHW930PP_D_CYCLE is null, to_timestamp(to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy'), 'yyyy-mm-dd'), to_timestamp(to_date(fact.PHW930PP_D_CYCLE,'MM/dd/yyyy'), 'yyyy-mm-dd')) as ETL_ROW_EFF_DTS,
'PCIO' AS SOURCE_SYSTEM,
'PCIO-COP' AS PARTITION_VAL,
Case 
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'P%' then   'COPLINE'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'L%' then   'COPLOCATION'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'B%' then 'COPBLDG'
when fact.PHW930PP_X_COV_SHORT_NAME like 'I%' and trim(fact.PHW930PP_ITEM_TYPE) in ('B','D','F','H','J','P','G') then 'COPLINEBLDG'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('E','I','X') then   'COPBUSINESSINCOME'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('C','K','S') then   'COPPERSPROP'
ELSE ' '
END as CVRBL_TYPE_CD,
'COP' AS LOB_CD
  from global_temp.pcio_mf_cop_prem_micro_batch micro_fact
  inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PHW930PP_PREFIX_A, PHW930PP_PREFIX_B, PHW930PP_POLICY_BRANCH, PHW930PP_POLICY_DEC, PHW930PP_POLICY_NUMBER, PHW930PP_D_TRANS_EFF, PHW930PP_SEQ_NUM1 ORDER BY to_date(PHW930PP_D_CYCLE,'MM/dd/yyyy')  DESC ) AS rn
   FROM
   (SELECT  pcio_preminc.*
   from
   {rawDB}.pcio_mf_cop_prem pcio_preminc
   inner join global_temp.pcio_mf_cop_prem_micro_batch mb
              on   mb.PHW930PP_PREFIX_A = pcio_preminc.PHW930PP_PREFIX_A 
              and  mb.PHW930PP_PREFIX_B = pcio_preminc.PHW930PP_PREFIX_B
              and  mb.PHW930PP_POLICY_BRANCH = pcio_preminc.PHW930PP_POLICY_BRANCH
              and  mb.PHW930PP_POLICY_DEC = pcio_preminc.PHW930PP_POLICY_DEC
              and  mb.PHW930PP_POLICY_NUMBER = pcio_preminc.PHW930PP_POLICY_NUMBER
              and  mb.PHW930PP_D_TRANS_EFF = pcio_preminc.PHW930PP_D_TRANS_EFF
              and  mb.PHW930PP_SEQ_NUM1 = pcio_preminc.PHW930PP_SEQ_NUM1
              )
  ) WHERE rn = 1  )          
   fact on   fact.PHW930PP_PREFIX_A = micro_fact.PHW930PP_PREFIX_A 
              and  fact.PHW930PP_PREFIX_B = micro_fact.PHW930PP_PREFIX_B
              and  fact.PHW930PP_POLICY_BRANCH = micro_fact.PHW930PP_POLICY_BRANCH
              and  fact.PHW930PP_POLICY_DEC = micro_fact.PHW930PP_POLICY_DEC
              and  fact.PHW930PP_POLICY_NUMBER = micro_fact.PHW930PP_POLICY_NUMBER
              and  fact.PHW930PP_D_TRANS_EFF = micro_fact.PHW930PP_D_TRANS_EFF
              and  fact.PHW930PP_SEQ_NUM1 = micro_fact.PHW930PP_SEQ_NUM1
              and  to_date(fact.PHW930PP_D_CYCLE,'MM/dd/yyyy') = to_date(micro_fact.PHW930PP_D_CYCLE,'MM/dd/yyyy')
   where trim(fact.PHW930PP_PREFIX_A) != '' and trim(PHW930PP_ACCT_DIST_IND) = 'P13' 
"""
 
    microBatchDF.createOrReplaceGlobalTempView(s"pcio_mf_cop_prem_micro_batch")
  println("microBatchDFcount :"+microBatchDF.count)
  microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_raw_hist.pcio_mf_cop_prem_micro_batch_cop_ds_line_covg")
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB) 
  harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
  println("harmz_query after rawDB replace: \n"+ harmz_query)
   
 
  val harmonized_table = s"${harmonizedDB}.${target}"
  val queryDF=microBatchDF.sparkSession.sql(harmz_query)
  println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("LINE_COVG_KEY","END_EFF_DT"), harmonized_table, "LINE_COVG_ID","PCIO-COP")
 }
