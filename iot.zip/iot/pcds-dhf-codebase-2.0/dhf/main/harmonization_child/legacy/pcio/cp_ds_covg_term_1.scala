// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cp_ds_covg_term(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)

  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select  distinct 
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER||'-'||COVG_CD||'-'||replacE(NAME,'_AMT','') AS COVG_TERM_KEY,
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER AS POL_KEY,
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER AS POL_LINE_KEY,
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER AS CVRBL_KEY,
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER||'-CPLINE-'||COVG_CD AS  LINE_COVG_KEY,
to_date(gnrl.CPE_MF_GN_VER_DATE,'yyyyDDD') as END_EFF_DT,
TO_DATE(gnrl.CPE_MF_GN_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
--TO_TIMESTAMP(gnrl.CPE_MF_GN_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
IF(TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(gnrl.CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'CP' AS LOB_CD,
'PCIO-CP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,
'CPLINE' AS CVRBL_TYPE_CD, 
COVG_CD AS COVG_CD,
replacE(NAME,'_AMT','') AS COVG_TERM_CD,
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT
from
global_temp.cp_gnrl_micro_batch micro_gnrl
inner join
(SELECT * FROM (SELECT *,STACK(5,if(CPE_GN_PROT_PLUS_CODE = "H","PROT_PLUS_CODE","NA"),"P-HSFORM",CPE_GN_PROT_PLUS_CODE,
                 if(CPE_GN_PROT_PLUS_CODE = "B","PROT_PLUS_CODE","NA"),"P-BASCPROT",CPE_GN_PROT_PLUS_CODE,
                 if(CPE_GN_PROT_PLUS_CODE=  "G","PROT_PLUS_CODE","NA"),"P-GOLDPROT",CPE_GN_PROT_PLUS_CODE,
                 if(CPE_GN_PROT_PLUS_CODE=  "P","PROT_PLUS_CODE","NA"),"P-PLATPROT",CPE_GN_PROT_PLUS_CODE,
                 if(CPE_GN_PROT_PLUS_CODE=  "D","PROT_PLUS_CODE","NA"),"P-DIAMPROT",CPE_GN_PROT_PLUS_CODE)
                 AS (NAME,COVG_CD,VALUE) FROM 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)    DESC ) AS rn
   FROM
   (SELECT  cp_gnrl.*
   from
   {rawDB}.cp_gnrl
   inner join global_temp.cp_gnrl_micro_batch mb
             on   mb.CPE_MF_GN_PREFIX_A = cp_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cp_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cp_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cp_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cp_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cp_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cp_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) GNRL 
  
  where CPE_MF_GN_PREFIX_B not like '%COP%')
where NAME!="NA" and  trim(value)!='')gnrl 
on  (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))--)group by  covg_term_key, end_eff_dt, etl_row_eff_dts having count(*)>1 --65727 
            
union all--1

--union1 -below

select DISTINCT 
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||COVG_CD||'-'||replacE(NAME,'_AMT','') COVG_TERM_KEY,
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER as POL_KEY,
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER as POL_LINE_KEY,
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2 AS CVRBL_KEY, --BLDG_KEY
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-' ||CPE_MF_BL_SEQ_NUM2||'-CPBLDG-'||COVG_CD AS LINE_COVG_KEY,
to_date(CPE_MF_BL_VER_DATE,'yyyyDDD') as END_EFF_DT,
TO_DATE(CPE_MF_BL_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
--to_timestamp(CPE_MF_BL_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
IF(TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'CP' AS LOB_CD,
'PCIO-CP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,
'CPBLDG' AS CVRBL_TYPE_CD, 
COVG_CD AS COVG_CD,
replacE(NAME,'_AMT','') AS COVG_TERM_CD,
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT

FROM 
global_temp.cp_gnrl_micro_batch micro_gnrl
inner join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)    DESC ) AS rn
   FROM
   (SELECT  cp_gnrl.*
   from
   {rawDB}.cp_gnrl
   inner join global_temp.cp_gnrl_micro_batch mb
             on   mb.CPE_MF_GN_PREFIX_A = cp_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cp_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cp_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cp_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cp_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cp_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cp_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) gnrl
  on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
  
  inner join
(select *,
stack(8,if(TRIM(CPE_BL_DISCHRG_PD_LMT)>0,"DISCHRG_PD_LMT_AMT","NA"),"B-PDDISCHG",CPE_BL_DISCHRG_PD_LMT,
        if(TRIM(CPE_BL_DISCHRG_PD_LMT)>0,"ALL_OTHER_DED_AMOUNT_AMT","NA"),"B-PDDISCHG",CPE_BL_ALL_OTHER_DED_AMOUNT,
        if(TRIM(CPE_BL_DISCHRG_PD_LMT)>0,"RATE_STATE","NA"),"B-PDDISCHG",CPE_LC_RATE_STATE,
        if(CPE_BL_LL_PREM >0,"LL_TYPE","NA"),"B-LEGLIAB",CPE_BL_LL_TYPE,
        if(CPE_BL_LL_PREM >0,"LL_LIMIT_AMT","NA"),"B-LEGLIAB",CPE_BL_LL_LIMIT,
        if(CPE_BL_LL_PREM >0,"LL_INC_FAC_IND","NA"),"B-LEGLIAB",CPE_BL_LL_INC_FAC_IND,
        if(CPE_BL_LL_PREM >0,"ALL_OTHER_DED_AMOUNT_AMT","NA"),"B-LEGLIAB",CPE_BL_ALL_OTHER_DED_AMOUNT,
        if(CPE_BL_LL_PREM >0,"RATE_STATE","NA"),"B-LEGLIAB",CPE_LC_RATE_STATE
) AS (NAME,COVG_CD,VALUE)
FROM 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A, CPE_MF_BL_PREFIX_B, CPE_MF_BL_POL_BRANCH, CPE_MF_BL_POL_DEC, CPE_MF_BL_POL_NUMBER, CPE_MF_BL_VER_DATE,  CPE_MF_BL_SEQ_NUM1, CPE_MF_BL_SEQ_NUM2,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_BL_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cp_bldg.*
   from
   {rawDB}.cp_bldg
   inner join global_temp.cp_gnrl_micro_batch mb
   
              on  
          mb.CPE_MF_GN_PREFIX_A = cp_bldg.CPE_MF_BL_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cp_bldg.CPE_MF_BL_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cp_bldg.CPE_MF_BL_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cp_bldg.CPE_MF_BL_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cp_bldg.CPE_MF_BL_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cp_bldg.CPE_MF_BL_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_bldg.CPE_GN_CYCLE_DATE is null, 'null', cp_bldg.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )

where CPE_MF_BL_PREFIX_B NOT LIKE '%COP%' )  bldg
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cp_location.*
   from
   {rawDB}.cp_location
   inner join global_temp.cp_gnrl_micro_batch mb
   
              on  
           mb.CPE_MF_GN_PREFIX_A = cp_location.CPE_MF_LC_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cp_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cp_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cp_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cp_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cp_location.CPE_MF_LC_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_location.CPE_GN_CYCLE_DATE is null, 'null', cp_location.CPE_GN_CYCLE_DATE)         

              )
  ) WHERE rn = 1  )  where CPE_MF_LC_PREFIX_B NOT LIKE '%COP%') loc
on
CPE_MF_BL_PREFIX_A=CPE_MF_LC_PREFIX_A and
CPE_MF_BL_POL_BRANCH=CPE_MF_LC_POL_BRANCH and
CPE_MF_BL_POL_DEC=CPE_MF_LC_POL_DEC and
CPE_MF_BL_POL_NUMBER=CPE_MF_LC_POL_NUMBER and
CPE_MF_BL_PREFIX_B=CPE_MF_LC_PREFIX_B and
CPE_MF_BL_POL_EXP_DATE=CPE_MF_LC_POL_EXP_DATE and
CPE_MF_BL_VER_DATE=CPE_MF_LC_VER_DATE and
CPE_MF_BL_SEQ_NUM1=CPE_MF_LC_SEQ_NUM1 
and if(BLDG.CPE_GN_CYCLE_DATE is null,'null',BLDG.CPE_GN_CYCLE_DATE) = if(LOC.CPE_GN_CYCLE_DATE is null, 'null', LOC.CPE_GN_CYCLE_DATE)
)
where name!='NA' and  trim(value)!=''


union all--2

select DISTINCT 
'PCIO-CP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER||'-'||CPE_MF_IT_SEQ_NUM1||'-'||CPE_MF_IT_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-'||COVG_CD||'-'||replacE(NAME,'_AMT','')||'-'||trim(CPE_IT_COV_TYPE) AS  COVG_TERM_KEY,
'PCIO-CP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER AS POL_KEY,
'PCIO-CP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER AS POL_LINE_KEY,

case
when trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G','E','I','X','C','K','S') THEN 
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3
else 'NOKEY'
END AS CVRBL_KEY,

CASE 
WHEN trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G') THEN 
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-CPLINEBLDG-'||COVG_CD 
WHEN trim(CPE_IT_COV_TYPE) in ('E','I','X') then  
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-CPBUSINESSINCOME-'||COVG_CD 
WHEN trim(CPE_IT_COV_TYPE) in ('C','K','S') then 
'PCIO-CP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1|| '-' ||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-CPPERSPROP-'||COVG_CD
ELSE 'NOKEY'
END AS  LINE_COVG_KEY,
to_Date(CPE_MF_IT_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(CPE_MF_IT_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
--to_timestamp(CPE_MF_IT_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
IF(to_timestamp(cycle, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(CPE_MF_IT_DATE,'yyyyDDD'), TO_TIMESTAMP(cycle,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'CP' AS LOB_CD,
'PCIO-CP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,
CASE 
WHEN trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G') THEN 'CPLINEBLDG'
WHEN trim(CPE_IT_COV_TYPE) in ('E','I','X') then   'CPBUSINESSINCOME'
WHEN trim(CPE_IT_COV_TYPE) in ('C','K','S') then   'CPPERSPROP'
ELSE ' '
END AS CVRBL_TYPE_CD, 
COVG_CD AS COVG_CD,
replacE(NAME,'_AMT','') AS COVG_TERM_CD,
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT
FROM 
global_temp.cp_gnrl_micro_batch micro_gnrl
inner join  
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)    DESC ) AS rn
   FROM
   (SELECT  cp_gnrl.*
   from
   {rawDB}.cp_gnrl
   inner join global_temp.cp_gnrl_micro_batch mb
             on   mb.CPE_MF_GN_PREFIX_A = cp_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cp_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cp_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cp_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cp_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cp_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cp_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) gnrl
  inner join

(SELECT *, item.CPE_GN_CYCLE_DATE as cycle,
STACK(225,

if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-GRP1SV",CPE_LC_RATE_STATE,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"GROUP1_TERR","NA"),"I-GRP1SV",CPE_LC_GROUP1_TERR,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"PROT_CLASS","NA"),"I-GRP1SV",CPE_LC_PROT_CLASS,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-GRP1SV",CPE_BL_CONST_TYPE,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CLASS_CODE","NA"),"I-GRP1SV",CPE_BL_CLASS_CODE,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-GRP1SV",CPE_IT_COIN_PCT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-GRP1SV",CPE_IT_COV_LIMIT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K'),"YEAR_BUILT","NA"),"I-GRP1SV",CPE_BL_YEAR_BUILT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-GRP1SV",CPE_IT_REPL_COST_IND,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-GRP1SV",CPE_BL_ALL_OTHER_DED_AMOUNT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-GRP1SV",CPE_IT_INFL_GUARD_PCT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SPLK_IND","NA"),"I-GRP1SV",CPE_IT_SPLK_IND,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"VMM_IND","NA"),"I-GRP1SV",CPE_IT_VMM_IND,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='Y' and  trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-GRP1SV",CPE_IT_ROOF_ACV,                               --3

if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-GRP1S",CPE_LC_RATE_STATE,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"GROUP1_TERR","NA"),"I-GRP1S",CPE_LC_GROUP1_TERR,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"PROT_CLASS","NA"),"I-GRP1S",CPE_LC_PROT_CLASS,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-GRP1S",CPE_BL_CONST_TYPE,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CLASS_CODE","NA"),"I-GRP1S",CPE_BL_CLASS_CODE,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-GRP1S",CPE_IT_COIN_PCT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-GRP1S",CPE_IT_COV_LIMIT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K'),"YEAR_BUILT","NA"),"I-GRP1S",CPE_BL_YEAR_BUILT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-GRP1S",CPE_IT_REPL_COST_IND,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-GRP1S",CPE_BL_ALL_OTHER_DED_AMOUNT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-GRP1S",CPE_IT_INFL_GUARD_PCT,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SPLK_IND","NA"),"I-GRP1S",CPE_IT_SPLK_IND,
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='Y' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-GRP1S",CPE_IT_ROOF_ACV,                               --4

IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-GRP1V",CPE_LC_RATE_STATE,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"GROUP1_TERR","NA"),"I-GRP1V",CPE_LC_GROUP1_TERR,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"PROT_CLASS","NA"),"I-GRP1V",CPE_LC_PROT_CLASS,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-GRP1V",CPE_BL_CONST_TYPE,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"CLASS_CODE","NA"),"I-GRP1V",CPE_BL_CLASS_CODE,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-GRP1V",CPE_IT_COIN_PCT,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-GRP1V",CPE_IT_COV_LIMIT,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K'),"YEAR_BUILT","NA"),"I-GRP1V",CPE_BL_YEAR_BUILT,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-GRP1V",CPE_IT_REPL_COST_IND,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-GRP1V",CPE_BL_ALL_OTHER_DED_AMOUNT,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-GRP1V",CPE_IT_INFL_GUARD_PCT,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-GRP1V",CPE_IT_ROOF_ACV,
IF(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='Y') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"VMM_IND","NA"),"I-GRP1V",CPE_IT_VMM_IND,                     --5

if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-GRP1",CPE_LC_RATE_STATE,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"GROUP1_TERR","NA"),"I-GRP1",CPE_LC_GROUP1_TERR,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"PROT_CLASS","NA"),"I-GRP1",CPE_LC_PROT_CLASS,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-GRP1",CPE_BL_CONST_TYPE,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"CLASS_CODE","NA"),"I-GRP1",CPE_BL_CLASS_CODE,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-GRP1",CPE_IT_COIN_PCT,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-GRP1",CPE_IT_COV_LIMIT,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-GRP1",CPE_BL_YEAR_BUILT,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-GRP1",CPE_IT_REPL_COST_IND,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-GRP1",CPE_BL_ALL_OTHER_DED_AMOUNT,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-GRP1",CPE_IT_INFL_GUARD_PCT,
if( TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-GRP1",CPE_IT_ROOF_ACV, 

if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-GRP1",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),
if(TRIM(CPE_IT_GROUP1_IND)='Y' and (TRIM(CPE_IT_SPLK_IND)='N' and TRIM(CPE_IT_VMM_IND)='N') and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"MON_LIMIT_CODE","NA"),"I-GRP1",substring(TRIM(CPE_IT_RPTG_FORM_TYPE),1,1),                     --6

if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-SPECFORM",CPE_LC_RATE_STATE,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"OCCUP_GROUP_CD","NA"),"I-SPECFORM",CPE_BL_OCCUP_GROUP_CD,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-SPECFORM",CPE_BL_CONST_TYPE,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-SPECFORM",CPE_IT_COIN_PCT,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-SPECFORM",CPE_IT_COV_LIMIT,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-SPECFORM",CPE_BL_YEAR_BUILT,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-SPECFORM",CPE_IT_REPL_COST_IND,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-SPECFORM",CPE_IT_INFL_GUARD_PCT,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-SPECFORM",CPE_BL_ALL_OTHER_DED_AMOUNT,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"THEFT_DEDUCTIBLE_AMT","NA"),"I-SPECFORM",CPE_BL_THEFT_DEDUCTIBLE,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-SPECFORM",CPE_IT_ROOF_ACV,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SC_THEFT_IND","NA"),"I-SPECFORM",CPE_IT_SC_THEFT_IND,     

if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in
('E','I','X'),"GROUP1_TERR","NA"),"I-SPECFORM",CPE_LC_GROUP1_TERR,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in
('E','I','X'),"CLASS_CODE","NA"),"I-SPECFORM",CPE_BL_CLASS_CODE,
if(Trim(CPE_IT_COL_IND)='Y' and trim(CPE_IT_COL_TYPE)=3 and Trim(CPE_IT_SC_THEFT_IND)='N' AND trim(CPE_IT_COV_TYPE) in
('E','I','X'),"BUS_INC_HR_DED","NA"),"I-SPECFORM",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),                   --7

if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-BRODFORM",CPE_LC_RATE_STATE,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"OCCUP_GROUP_CD","NA"),"I-BRODFORM",CPE_BL_OCCUP_GROUP_CD,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-BRODFORM",CPE_IT_COIN_PCT,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"CONST_TYPE","NA"),"I-BRODFORM",CPE_BL_CONST_TYPE,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-BRODFORM",CPE_IT_COV_LIMIT,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-BRODFORM",CPE_BL_YEAR_BUILT,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-BRODFORM",CPE_IT_REPL_COST_IND,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-BRODFORM",CPE_IT_INFL_GUARD_PCT,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-BRODFORM",CPE_BL_ALL_OTHER_DED_AMOUNT,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"THEFT_DEDUCTIBLE_AMT","NA"),"I-BRODFORM",CPE_BL_THEFT_DEDUCTIBLE,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-BRODFORM",CPE_IT_ROOF_ACV,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SC_THEFT_IND","NA"),"I-BRODFORM",CPE_IT_SC_THEFT_IND, 

if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"GROUP1_TERR","NA"),"I-BRODFORM",CPE_LC_GROUP1_TERR,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"CLASS_CODE","NA"),"I-BRODFORM",CPE_BL_CLASS_CODE,
if(Trim(CPE_IT_COL_IND)='Y' and  trim(CPE_IT_COL_TYPE)=2 and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-BRODFORM",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3), 



If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-GRP2WH",CPE_LC_RATE_STATE,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"GROUP2_TERR","NA"),"I-GRP2WH",CPE_LC_GROUP2_TERR,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"BG2_SYMBOL","NA"),"I-GRP2WH",CPE_BL_SYMBOL,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-GRP2WH",CPE_IT_COIN_PCT,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-GRP2WH",CPE_IT_COV_LIMIT,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-GRP2WH",CPE_BL_YEAR_BUILT,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-GRP2WH",CPE_IT_REPL_COST_IND,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"WIND_HAIL_DED_AMOUNT_AMT","NA"),"I-GRP2WH",CPE_BL_WIND_HAIL_DED_AMOUNT,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"WND_HAIL_DED_PCT","NA"),"I-GRP2WH",CPE_BL_WND_HAIL_DED_PCT,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"HURR_DED_PCT","NA"),"I-GRP2WH",CPE_BL_HURR_DED_PCT,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"BCEG","NA"),"I-GRP2WH",CPE_BL_BCEG,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"GP2_SYMBOL_MULTIPLIER","NA"),"I-GRP2WH",CPE_BL_SYMBOL_PFX,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-GRP2WH",CPE_IT_INFL_GUARD_PCT,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"W_AND_H_IND","NA"),"I-GRP2WH",CPE_IT_W_AND_H_IND,
If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-GRP2WH",CPE_IT_ROOF_ACV,   

If(TRIM(CPE_IT_GROUP2_IND)='Y' and CPE_IT_W_AND_H_IND='Y' AND trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-GRP2WH",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),



if(CPE_LC_ISO_RUL_EFF_IND='A' and  CPE_IT_FOOD_CONT_LMT>0 and   trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"FOOD_CONT_LMT_AMT","NA"),"I-FOODCONT",CPE_IT_FOOD_CONT_LMT,
if(CPE_LC_ISO_RUL_EFF_IND='A' and  CPE_IT_FOOD_CONT_LMT>0 and   trim(CPE_IT_COV_TYPE) in 
('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-FOODCONT",CPE_LC_RATE_STATE,  --12

if(CPE_LC_ISO_RUL_EFF_IND='A' and  CPE_IT_FOOD_ADV_LMT>0 and   trim(CPE_IT_COV_TYPE) in 
('B','C','S','K','E','I','X','P','D','F','H','J','G'),"FOOD_ADV_LMT_AMT","NA"),"I-FOODADV",CPE_IT_FOOD_ADV_LMT,
if(CPE_LC_ISO_RUL_EFF_IND='A' and  CPE_IT_FOOD_ADV_LMT>0 and   trim(CPE_IT_COV_TYPE) in 
('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-FOODADV",CPE_LC_RATE_STATE, --13

if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-GRP2",CPE_LC_RATE_STATE,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"GROUP2_TERR","NA"),"I-GRP2",CPE_LC_GROUP2_TERR,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"BG2_SYMBOL","NA"),"I-GRP2",CPE_BL_SYMBOL,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-GRP2",CPE_IT_COIN_PCT,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-GRP2",CPE_IT_COV_LIMIT,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-GRP2",CPE_BL_YEAR_BUILT,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-GRP2",CPE_IT_REPL_COST_IND,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-GRP2",CPE_BL_ALL_OTHER_DED_AMOUNT,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"HURR_DED_PCT","NA"),"I-GRP2",CPE_BL_HURR_DED_PCT,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"BCEG","NA"),"I-GRP2",CPE_BL_BCEG,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"GP2_SYMBOL_MULTIPLIER","NA"),"I-GRP2",CPE_BL_SYMBOL_PFX,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-GRP2",CPE_IT_INFL_GUARD_PCT,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"W_AND_H_IND","NA"),"I-GRP2",CPE_IT_W_AND_H_IND,
if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-GRP2",CPE_IT_ROOF_ACV, 

if(TRIM(CPE_IT_GROUP2_IND)='Y' and  CPE_IT_W_AND_H_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-GRP2",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),


If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-SPTHEFT",CPE_LC_RATE_STATE,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"OCCUP_GROUP_CD","NA"),"I-SPTHEFT",CPE_BL_OCCUP_GROUP_CD,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-SPTHEFT",CPE_IT_COIN_PCT,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-SPTHEFT",CPE_IT_COV_LIMIT,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X'),"YEAR_BUILT","NA"),"I-SPTHEFT",CPE_BL_YEAR_BUILT,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-SPTHEFT",CPE_IT_REPL_COST_IND,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"INFL_GUARD_PCT","NA"),"I-SPTHEFT",CPE_IT_INFL_GUARD_PCT,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"ALL_OTHER_DED_AMOUNT_AMT","NA"),"I-SPTHEFT",CPE_BL_ALL_OTHER_DED_AMOUNT,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"THEFT_DEDUCTIBLE_AMT","NA"),"I-SPTHEFT",CPE_BL_THEFT_DEDUCTIBLE,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-SPTHEFT",CPE_IT_ROOF_ACV,
If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"SC_THEFT_IND","NA"),"I-SPTHEFT",CPE_IT_SC_THEFT_IND,

If(CPE_MF_IT_PREFIX_B  not LIKE '%COP%' and CPE_IT_COL_IND='Y'  and CPE_IT_COL_TYPE=3 and   CPE_IT_SC_THEFT_IND='Y' 
and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"SC_THEFT_IND","NA"),"I-SPTHEFT",CPE_IT_SC_THEFT_IND,


IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQ",CPE_LC_RATE_STATE,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQ",CPE_BL_EQ_TERR,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQ",CPE_BL_EQ_BLD_CLS,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQ",CPE_BL_EQ_SUSP_GRD,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQ",CPE_BL_EQ_RAT_GRD,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQ",CPE_BL_EQ_ZONE,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQ",CPE_IT_EQ_SPLK_IND,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-EQ",CPE_IT_COV_LIMIT,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQ",CPE_IT_COIN_PCT,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQ",CPE_IT_EQ_DEDUCT_PCT,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQ",CPE_IT_EQ_FLAT_DEDUCT,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQ",CPE_BL_EQ_MSN_VNR,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQ",CPE_BL_EQ_NUM_STR,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQ",CPE_IT_REPL_COST_IND,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQ",CPE_IT_ORD_LAW_IND,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQ",CPE_IT_ROOF_ACV,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQ",CPE_IT_BLDRSK_RENOV,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQ",CPE_BL_BCEG,    

IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in 
('E','I','X'),"BI_ALS_IND","NA"),"I-EQ",CPE_IT_BI_ALS_IND,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in 
('E','I','X'),"PAY_EXP_DAYS","NA"),"I-EQ",CPE_IT_PAY_EXP_DAYS,
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in 
('E','I','X'),"BUS_INC_HR_DED","NA"),"I-EQ",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),
IF((CPE_IT_EQ_IND = 'Y') and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and CPE_IT_SPLK_IND = 'N' and  trim(CPE_IT_COV_TYPE) in 
('E','I','X'),"EXT_PERIOD_DAYS","NA"),"I-EQ",CPE_IT_INFL_GUARD_PCT,


if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQSPKL",CPE_LC_RATE_STATE,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQSPKL",CPE_BL_EQ_TERR,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQSPKL",CPE_BL_EQ_BLD_CLS,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQSPKL",CPE_BL_EQ_SUSP_GRD,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQSPKL",CPE_BL_EQ_RAT_GRD,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQSPKL",CPE_BL_EQ_ZONE,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQSPKL",CPE_IT_EQ_SPLK_IND,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"COV_LIMIT_AMT","NA"),"I-EQSPKL",CPE_IT_COV_LIMIT,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQSPKL",CPE_IT_COIN_PCT,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQSPKL",CPE_IT_EQ_DEDUCT_PCT,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQSPKL",CPE_IT_EQ_FLAT_DEDUCT,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQSPKL",CPE_BL_EQ_MSN_VNR,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQSPKL",CPE_BL_EQ_NUM_STR,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQSPKL",CPE_IT_REPL_COST_IND,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQSPKL",CPE_IT_ORD_LAW_IND,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQSPKL",CPE_IT_ROOF_ACV,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQSPKL",CPE_IT_BLDRSK_RENOV,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQSPKL",CPE_BL_BCEG, 

if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BI_ALS_IND","NA"),"I-EQSPKL",CPE_IT_BI_ALS_IND,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"PAY_EXP_DAYS","NA"),"I-EQSPKL",CPE_IT_PAY_EXP_DAYS,
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-EQSPKL",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),
if(CPE_IT_EQ_SPLK_IND='Y' and CPE_IT_EQ_SUB_LIMIT_IND = 'N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"EXT_PERIOD_DAYS","NA"),"I-EQSPKL",CPE_IT_INFL_GUARD_PCT,


IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQSUBLMT",CPE_LC_RATE_STATE,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQSUBLMT",CPE_BL_EQ_TERR,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQSUBLMT",CPE_BL_EQ_BLD_CLS,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQSUBLMT",CPE_BL_EQ_SUSP_GRD,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQSUBLMT",CPE_BL_EQ_RAT_GRD,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQSUBLMT",CPE_BL_EQ_ZONE,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQSUBLMT",CPE_IT_EQ_SPLK_IND,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQSUBLMT",CPE_IT_COIN_PCT,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_LIMIT_AMT","NA"),"I-EQSUBLMT",CPE_IT_EQ_SUB_LIMIT,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_PERCENT","NA"),"I-EQSUBLMT",CPE_IT_EQ_SUB_PERCENT,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQSUBLMT",CPE_IT_EQ_DEDUCT_PCT,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQSUBLMT",CPE_IT_EQ_FLAT_DEDUCT,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQSUBLMT",CPE_BL_EQ_MSN_VNR,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQSUBLMT",CPE_BL_EQ_NUM_STR,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQSUBLMT",CPE_IT_REPL_COST_IND,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQSUBLMT",CPE_IT_ORD_LAW_IND,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQSUBLMT",CPE_IT_ROOF_ACV,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQSUBLMT",CPE_IT_BLDRSK_RENOV,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQSUBLMT",CPE_BL_BCEG,   

IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BI_ALS_IND","NA"),"I-EQSUBLMT",CPE_IT_BI_ALS_IND,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"PAY_EXP_DAYS","NA"),"I-EQSUBLMT",CPE_IT_PAY_EXP_DAYS,
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-EQSUBLMT",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),
IF(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='N' and trim(CPE_IT_COV_TYPE) in ('E','I','X'),"EXT_PERIOD_DAYS","NA"),"I-EQSUBLMT",CPE_IT_INFL_GUARD_PCT,



if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-EQSUBSP",CPE_LC_RATE_STATE,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_TERR","NA"),"I-EQSUBSP",CPE_BL_EQ_TERR,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_BLD_CLS","NA"),"I-EQSUBSP",CPE_BL_EQ_BLD_CLS,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUSP_GRD","NA"),"I-EQSUBSP",CPE_BL_EQ_SUSP_GRD,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_RAT_GRD","NA"),"I-EQSUBSP",CPE_BL_EQ_RAT_GRD,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_ZONE","NA"),"I-EQSUBSP",CPE_BL_EQ_ZONE,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SPLK_IND","NA"),"I-EQSUBSP",CPE_IT_EQ_SPLK_IND,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"COIN_PCT","NA"),"I-EQSUBSP",CPE_IT_COIN_PCT,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_LIMIT_AMT","NA"),"I-EQSUBSP",CPE_IT_EQ_SUB_LIMIT,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_SUB_PERCENT","NA"),"I-EQSUBSP",CPE_IT_EQ_SUB_PERCENT,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_DEDUCT_PCT","NA"),"I-EQSUBSP",CPE_IT_EQ_DEDUCT_PCT,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_FLAT_DEDUCT_AMT","NA"),"I-EQSUBSP",CPE_IT_EQ_FLAT_DEDUCT,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_MSN_VNR_PCT","NA"),"I-EQSUBSP",CPE_BL_EQ_MSN_VNR,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"EQ_NUM_STR","NA"),"I-EQSUBSP",CPE_BL_EQ_NUM_STR,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','C','S','K','P','D','F','H','J','G'),"REPL_COST_IND","NA"),"I-EQSUBSP",CPE_IT_REPL_COST_IND,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ORD_LAW_IND","NA"),"I-EQSUBSP",CPE_IT_ORD_LAW_IND,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"ROOF_ACV","NA"),"I-EQSUBSP",CPE_IT_ROOF_ACV,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','P','D','F','H','J','G'),"BLDRSK_RENOV","NA"),"I-EQSUBSP",CPE_IT_BLDRSK_RENOV,
if(CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and CPE_IT_EQ_SPLK_IND='Y' and trim(CPE_IT_COV_TYPE) in ('B','E','I','X','C','S','K','P','D','F','H','J','G'),"BCEG","NA"),"I-EQSUBSP",CPE_BL_BCEG,                            --22

IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE<>'013' AND CPE_IT_ALE_WAIVED_IND<>'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-MINE",CPE_LC_RATE_STATE,
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE<>'013' AND CPE_IT_ALE_WAIVED_IND<>'N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"ILL_MINE_COV_LIMIT_AMT","NA"),"I-MINE",CPE_IT_ILL_MINE_COV_LIMIT, --25

IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE='013' AND CPE_IT_ALE_WAIVED_IND='N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"RATE_STATE","NA"),"I-MINEALE",CPE_LC_RATE_STATE,
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE='013' AND CPE_IT_ALE_WAIVED_IND='N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"ILL_MINE_COV_LIMIT_AMT","NA"),"I-MINEALE",CPE_IT_ILL_MINE_COV_LIMIT,
IF(CPE_IT_ILL_MINE_IND = 'Y' and CPE_LC_RATE_STATE='013' AND CPE_IT_ALE_WAIVED_IND='N' and  trim(CPE_IT_COV_TYPE) in ('B','C','S','K','E','I','X','P','D','F','H','J','G'),"ALE_WAIVED_IND","NA"),"I-MINEALE",CPE_IT_ALE_WAIVED_IND,          --26

IF(CPE_LC_ISO_RUL_EFF_IND='A' AND CPE_IT_DISCHRG_BI_LMT > 0 AND TRIM(CPE_IT_COV_TYPE) in ('E','I','X'),"DISCHRG_BI_LMT_AMT","NA"),"I-BIDISCHG",CPE_IT_DISCHRG_BI_LMT,
IF(CPE_LC_ISO_RUL_EFF_IND='A' AND CPE_IT_DISCHRG_BI_LMT > 0 AND TRIM(CPE_IT_COV_TYPE) in ('E','I','X'),"BUS_INC_HR_DED","NA"),"I-BIDISCHG",substring(TRIM(CPE_IT_PEAK_SEASON_EFF_DT),1,3),
IF(CPE_LC_ISO_RUL_EFF_IND='A' AND CPE_IT_DISCHRG_BI_LMT > 0 AND TRIM(CPE_IT_COV_TYPE) in ('E','I','X'),"RATE_STATE","NA"),"I-BIDISCHG",CPE_LC_RATE_STATE                                                                    --14

)
AS (NAME,COVG_CD,VALUE)
FROM 
(SELECT * FROM ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IT_PREFIX_A, CPE_MF_IT_PREFIX_B, CPE_MF_IT_POL_BRANCH, CPE_MF_IT_POL_DEC, CPE_MF_IT_POL_NUMBER, CPE_MF_IT_VER_DATE,  CPE_MF_IT_SEQ_NUM2, CPE_MF_IT_SEQ_NUM1, CPE_MF_IT_SEQ_NUM3, CPE_IT_COV_TYPE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_IT_DATE, CPE_GN_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  cp_item.*
   from
   {rawDB}.cp_item
   inner join global_temp.cp_gnrl_micro_batch mb
   
              on  
          mb.CPE_MF_GN_PREFIX_A = cp_item.CPE_MF_IT_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cp_item.CPE_MF_IT_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cp_item.CPE_MF_IT_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cp_item.CPE_MF_IT_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cp_item.CPE_MF_IT_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cp_item.CPE_MF_IT_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_item.CPE_GN_CYCLE_DATE is null, 'null', cp_item.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )   WHERE CPE_MF_IT_PREFIX_B NOT LIKE '%COP%') item
inner join
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A, CPE_MF_BL_PREFIX_B, CPE_MF_BL_POL_BRANCH, CPE_MF_BL_POL_DEC, CPE_MF_BL_POL_NUMBER, CPE_MF_BL_VER_DATE,  CPE_MF_BL_SEQ_NUM1, CPE_MF_BL_SEQ_NUM2,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_BL_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cp_bldg.*
   from
   {rawDB}.cp_bldg
   inner join global_temp.cp_gnrl_micro_batch mb
   
              on  
          mb.CPE_MF_GN_PREFIX_A = cp_bldg.CPE_MF_BL_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cp_bldg.CPE_MF_BL_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cp_bldg.CPE_MF_BL_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cp_bldg.CPE_MF_BL_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cp_bldg.CPE_MF_BL_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cp_bldg.CPE_MF_BL_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_bldg.CPE_GN_CYCLE_DATE is null, 'null', cp_bldg.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  ) where CPE_MF_BL_PREFIX_B NOT LIKE '%COP%') bldg
on
CPE_MF_BL_PREFIX_A=CPE_MF_IT_PREFIX_A and 
CPE_MF_BL_PREFIX_B=CPE_MF_IT_PREFIX_B and
CPE_MF_BL_POL_BRANCH=CPE_MF_IT_POL_BRANCH and
CPE_MF_BL_POL_DEC=CPE_MF_IT_POL_DEC and
CPE_MF_BL_POL_NUMBER=CPE_MF_IT_POL_NUMBER and
CPE_MF_BL_SEQ_NUM1=CPE_MF_IT_SEQ_NUM1 AND
CPE_MF_BL_SEQ_NUM2=CPE_MF_IT_SEQ_NUM2 and
CPE_MF_BL_VER_DATE =CPE_MF_IT_VER_DATE AND
CPE_MF_BL_POL_EXP_DATE=CPE_MF_IT_POL_EXP_DATE 
and if(BLDG.CPE_GN_CYCLE_DATE is null,'null',BLDG.CPE_GN_CYCLE_DATE) = if(ITEM.CPE_GN_CYCLE_DATE is null, 'null', ITEM.CPE_GN_CYCLE_DATE)  
inner join
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cp_location.*
   from
   {rawDB}.cp_location
   inner join global_temp.cp_gnrl_micro_batch mb
   
              on  
           mb.CPE_MF_GN_PREFIX_A = cp_location.CPE_MF_LC_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cp_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cp_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cp_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cp_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cp_location.CPE_MF_LC_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_location.CPE_GN_CYCLE_DATE is null, 'null', cp_location.CPE_GN_CYCLE_DATE)         

              )
  ) WHERE rn = 1  )  where CPE_MF_LC_PREFIX_B NOT LIKE '%COP%') loc
on
CPE_MF_BL_PREFIX_A=CPE_MF_LC_PREFIX_A and
CPE_MF_BL_POL_BRANCH=CPE_MF_LC_POL_BRANCH and
CPE_MF_BL_POL_DEC=CPE_MF_LC_POL_DEC and
CPE_MF_BL_POL_NUMBER=CPE_MF_LC_POL_NUMBER and
CPE_MF_BL_PREFIX_B=CPE_MF_LC_PREFIX_B and
CPE_MF_BL_POL_EXP_DATE=CPE_MF_LC_POL_EXP_DATE and
CPE_MF_BL_VER_DATE=CPE_MF_LC_VER_DATE and
CPE_MF_BL_SEQ_NUM1=CPE_MF_LC_SEQ_NUM1 )        item  
on TRIM(micro_gnrl.CPE_MF_GN_PREFIX_A)=TRIM(item.CPE_MF_IT_PREFIX_A) and
micro_gnrl.CPE_MF_GN_PREFIX_B=item.CPE_MF_IT_PREFIX_B and
micro_gnrl.CPE_MF_GN_POL_BRANCH=item.CPE_MF_IT_POL_BRANCH and
micro_gnrl.CPE_MF_GN_POL_DEC=item.CPE_MF_IT_POL_DEC and
micro_gnrl.CPE_MF_GN_POL_NUMBER=item.CPE_MF_IT_POL_NUMBER and
micro_gnrl.CPE_MF_GN_VER_DATE=item.CPE_MF_IT_VER_DATE 
--and micro_gnrl.CPE_MF_GN_POL_EXP_DATE=item.CPE_MF_IT_POL_EXP_DATE
and if(micro_gnrl.CPE_GN_CYCLE_DATE is null,'null',micro_gnrl.CPE_GN_CYCLE_DATE) = if(cycle is null, 'null', cycle)

where name!='NA' and  trim(value)!=''



"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"cp_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
     //queryDF.createOrReplaceGlobalTempView(s"V")
     // val hashDF = addHashColumn_clt("V","COVG_TERM_ID ")
    mergeAndWrite(queryDF,List("COVG_TERM_KEY","END_EFF_DT"), harmonized_table, "COVG_TERM_ID","PCIO-CP")
}

