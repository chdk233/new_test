// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_bus_incm(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

SELECT
--'PCIO-COP-'||ITEM.CPE_MF_IT_PREFIX_A||ITEM.CPE_MF_IT_PREFIX_B||ITEM.CPE_MF_IT_POL_BRANCH||ITEM.CPE_MF_IT_POL_DEC||ITEM.CPE_MF_IT_POL_NUMBER||'-'||CPE_BL_CLASS_CODE||'-'||ITEM.CPE_MF_IT_SEQ_NUM1||'-'||ITEM.CPE_MF_IT_SEQ_NUM2||'-'||ITEM.CPE_MF_IT_SEQ_NUM3||'-'||ITEM.CPE_IT_COV_TYPE AS BI_KEY,
'PCIO-COP-'||ITEM.CPE_MF_IT_PREFIX_A||ITEM.CPE_MF_IT_PREFIX_B||ITEM.CPE_MF_IT_POL_BRANCH||ITEM.CPE_MF_IT_POL_DEC||ITEM.CPE_MF_IT_POL_NUMBER||'-'||ITEM.CPE_MF_IT_SEQ_NUM1||'-'||ITEM.CPE_MF_IT_SEQ_NUM2||'-'||ITEM.CPE_MF_IT_SEQ_NUM3 AS BI_KEY, --changed_new
'PCIO-COP-'||ITEM.CPE_MF_IT_PREFIX_A||ITEM.CPE_MF_IT_PREFIX_B||ITEM.CPE_MF_IT_POL_BRANCH||ITEM.CPE_MF_IT_POL_DEC||ITEM.CPE_MF_IT_POL_NUMBER AS POL_KEY,
'PCIO-COP-'||ITEM.CPE_MF_IT_PREFIX_A||ITEM.CPE_MF_IT_PREFIX_B||ITEM.CPE_MF_IT_POL_BRANCH||ITEM.CPE_MF_IT_POL_DEC||ITEM.CPE_MF_IT_POL_NUMBER AS POL_LINE_KEY,
to_date(ITEM.CPE_MF_IT_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(ITEM.CPE_MF_IT_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
'PCIO' AS SOURCE_SYSTEM,
--'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_BL_CLASS_CODE||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2  as BLDG_KEY,
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2  as BLDG_KEY,--changed_new
'COPBUSINESSINCOME' as CVRBL_TYPE_CD,
CAST(ITEM.CPE_IT_AV_LIMIT AS INT) AS AGREED_VAL_LMT,
CAST(ITEM.CPE_MF_IT_SEQ_NUM3 AS INT) AS BUS_INC_NO,
ITEM.CPE_IT_COV_TYPE AS COVG_TYPE,
ITEM.CPE_IT_EQ_SPLK_IND AS EQ_SL_ONLY_FL,
IF (CPE_GN_BLANKET_BUS_INCOME = 'Y' OR  CPE_GN_BLANKET_EXTRA_EXP = 'Y', 'Y', 'N') as INC_IN_BLNKT_FL,
CAST(ITEM.CPE_MF_IT_SEQ_NUM3 AS INT) AS LEGACY_ITEM_NO,
CASE
when  ITEM.CPE_IT_TIME_ELEMENT_IND=1  then 'Mercantile and Non-manufacturing'
WHEN  ITEM.CPE_IT_TIME_ELEMENT_IND=2 then 'Manufacturing'
WHEN ITEM.CPE_IT_TIME_ELEMENT_IND=3 then 'Rental Properties'
else ' ' 
end as TYPE_RISK_DESC,
IF(TO_TIMESTAMP(ITEM.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(ITEM.CPE_MF_IT_DATE,'yyyyDDD'), TO_TIMESTAMP(ITEM.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' as PARTITION_VAL

from global_temp.cop_item_micro_batch micro_item 
inner join
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IT_PREFIX_A, CPE_MF_IT_PREFIX_B, CPE_MF_IT_POL_BRANCH, CPE_MF_IT_POL_DEC, CPE_MF_IT_POL_NUMBER, CPE_MF_IT_VER_DATE,  CPE_MF_IT_SEQ_NUM2, CPE_MF_IT_SEQ_NUM1, CPE_MF_IT_SEQ_NUM3, CPE_IT_COV_TYPE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_IT_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_item.*
   from
   {rawDB}.cop_item
   inner join global_temp.cop_item_micro_batch mb
              on   mb.CPE_MF_IT_PREFIX_A = cop_item.CPE_MF_IT_PREFIX_A 
            and mb.CPE_MF_IT_PREFIX_B = cop_item.CPE_MF_IT_PREFIX_B 
            and mb.CPE_MF_IT_POL_BRANCH = cop_item.CPE_MF_IT_POL_BRANCH 
            and mb.CPE_MF_IT_POL_DEC = cop_item.CPE_MF_IT_POL_DEC 
            and mb.CPE_MF_IT_POL_NUMBER = cop_item.CPE_MF_IT_POL_NUMBER 
            and mb.CPE_MF_IT_VER_DATE = cop_item.CPE_MF_IT_VER_DATE 
            and mb.CPE_MF_IT_SEQ_NUM2 = cop_item.CPE_MF_IT_SEQ_NUM2 
            and mb.CPE_MF_IT_SEQ_NUM1 = cop_item.CPE_MF_IT_SEQ_NUM1 
            and mb.CPE_MF_IT_SEQ_NUM3 = cop_item.CPE_MF_IT_SEQ_NUM3 
            and mb.CPE_IT_COV_TYPE = cop_item.CPE_IT_COV_TYPE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_item.CPE_GN_CYCLE_DATE is null, 'null', cop_item.CPE_GN_CYCLE_DATE)
--               where cop_item.PZE10100_D_CYCLE_DATE <= mb.PZE10100_D_CYCLE_DATE

              )
  ) WHERE rn = 1  )          
  
WHERE trim(CPE_IT_COV_TYPE) in ('E','I','X'))item

on   item.CPE_MF_IT_PREFIX_A = micro_item.CPE_MF_IT_PREFIX_A 
            and item.CPE_MF_IT_PREFIX_B = micro_item.CPE_MF_IT_PREFIX_B 
            and item.CPE_MF_IT_POL_BRANCH = micro_item.CPE_MF_IT_POL_BRANCH 
            and item.CPE_MF_IT_POL_DEC = micro_item.CPE_MF_IT_POL_DEC 
            and item.CPE_MF_IT_POL_NUMBER = micro_item.CPE_MF_IT_POL_NUMBER 
            and item.CPE_MF_IT_VER_DATE = micro_item.CPE_MF_IT_VER_DATE 
            and item.CPE_MF_IT_SEQ_NUM2 = micro_item.CPE_MF_IT_SEQ_NUM2 
            and item.CPE_MF_IT_SEQ_NUM1 = micro_item.CPE_MF_IT_SEQ_NUM1 
            and item.CPE_MF_IT_SEQ_NUM3 = micro_item.CPE_MF_IT_SEQ_NUM3 
            and item.CPE_IT_COV_TYPE = micro_item.CPE_IT_COV_TYPE 
            and if(item.CPE_GN_CYCLE_DATE is null,'null',item.CPE_GN_CYCLE_DATE) = if(micro_item.CPE_GN_CYCLE_DATE is null, 'null', micro_item.CPE_GN_CYCLE_DATE)
            
            inner join
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A, CPE_MF_BL_PREFIX_B, CPE_MF_BL_POL_BRANCH, CPE_MF_BL_POL_DEC, CPE_MF_BL_POL_NUMBER, CPE_MF_BL_VER_DATE,  CPE_MF_BL_SEQ_NUM1, CPE_MF_BL_SEQ_NUM2,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_BL_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_item_micro_batch mb
              on   mb.CPE_MF_IT_PREFIX_A = cop_bldg.CPE_MF_BL_PREFIX_A 
            and mb.CPE_MF_IT_PREFIX_B = cop_bldg.CPE_MF_BL_PREFIX_B 
            and mb.CPE_MF_IT_POL_BRANCH = cop_bldg.CPE_MF_BL_POL_BRANCH 
            and mb.CPE_MF_IT_POL_DEC = cop_bldg.CPE_MF_BL_POL_DEC 
            and mb.CPE_MF_IT_POL_NUMBER = cop_bldg.CPE_MF_BL_POL_NUMBER 
            and mb.CPE_MF_IT_VER_DATE = cop_bldg.CPE_MF_BL_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_bldg.CPE_GN_CYCLE_DATE is null, 'null', cop_bldg.CPE_GN_CYCLE_DATE)
            
 --               where cop_bldg.PZE10100_D_CYCLE_DATE <= mb.PZE10100_D_CYCLE_DATE  
            

              )
  ) WHERE rn = 1  ))  bldg on
item.CPE_MF_IT_PREFIX_A=bldg.CPE_MF_BL_PREFIX_A and
item.CPE_MF_IT_PREFIX_B=bldg.CPE_MF_BL_PREFIX_B and
item.CPE_MF_IT_POL_BRANCH=bldg.CPE_MF_BL_POL_BRANCH and
item.CPE_MF_IT_POL_DEC=bldg.CPE_MF_BL_POL_DEC and
item.CPE_MF_IT_POL_NUMBER=bldg.CPE_MF_BL_POL_NUMBER and
item.CPE_MF_IT_SEQ_NUM1=bldg.CPE_MF_BL_SEQ_NUM1 and
item.CPE_MF_IT_SEQ_NUM2=bldg.CPE_MF_BL_SEQ_NUM2 and
item.CPE_MF_IT_POL_EXP_DATE=bldg.CPE_MF_BL_POL_EXP_DATE and
item.CPE_MF_IT_VER_DATE =bldg.CPE_MF_BL_VER_DATE
and if(item.CPE_GN_CYCLE_DATE is null,'null',item.CPE_GN_CYCLE_DATE) = if(bldg.CPE_GN_CYCLE_DATE is null, 'null', bldg.CPE_GN_CYCLE_DATE)

LEFT join
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
   {rawDB}.cop_gnrl
   inner join global_temp.cop_item_micro_batch mb
              on   mb.CPE_MF_IT_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_IT_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_IT_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_IT_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_IT_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_IT_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
--               where cop_gnrl.PZE10100_D_CYCLE_DATE <= mb.PZE10100_D_CYCLE_DATE  
            

              )
  ) WHERE rn = 1  ))  gnrl on
gnrl.CPE_MF_GN_PREFIX_A=item.CPE_MF_IT_PREFIX_A and
gnrl.CPE_MF_GN_PREFIX_B=item.CPE_MF_IT_PREFIX_B and
gnrl.CPE_MF_GN_POL_BRANCH=item.CPE_MF_IT_POL_BRANCH and
gnrl.CPE_MF_GN_POL_DEC=item.CPE_MF_IT_POL_DEC and
gnrl.CPE_MF_GN_POL_NUMBER=item.CPE_MF_IT_POL_NUMBER and
gnrl.CPE_MF_GN_VER_DATE=item.CPE_MF_IT_VER_DATE and
gnrl.CPE_MF_GN_POL_EXP_DATE=item.CPE_MF_IT_POL_EXP_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(item.CPE_GN_CYCLE_DATE is null, 'null', item.CPE_GN_CYCLE_DATE)


"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_item_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_item_micro_batch_ds_bus_incm")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("BI_KEY","END_EFF_DT"), harmonized_table, "BI_ID","PCIO-COP")
}
