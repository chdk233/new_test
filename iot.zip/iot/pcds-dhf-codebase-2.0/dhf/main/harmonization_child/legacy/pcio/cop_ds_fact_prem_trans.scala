// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_fact_prem_tran(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
select 
fact.PHW930PP_ACCT_DIST_IND as PHW930PP_ACCT_DIST_IND,
'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)||'-'||SUBSTR(fact.PHW930PP_D_CYCLE,7,4)||'-'||SUBSTR(fact.PHW930PP_D_CYCLE,1,2)||'-'||SUBSTR(fact.PHW930PP_D_CYCLE,4,2)||'-'||SUBSTR(fact.PHW930PP_D_TRANS_EFF,7,4)||'-'||SUBSTR(fact.PHW930PP_D_TRANS_EFF,1,2)||'-'||SUBSTR(fact.PHW930PP_D_TRANS_EFF,4,2)||'-'||LPAD(cast(cast(fact.PHW930PP_AMEND_NUM as int) as string),3,'0')||'-'||fact.PHW930PP_SEQ_NUM1||'-'||LPAD(cast(cast(fact.PHW930PP_NIGHTLY_SEQ as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')||'-'||trim(fact.PHW930PP_C_LOAD) as FACT_PREM_TRANS_KEY,
ifnull('DPIM'||'-'||LPAD(TRIM(fact.PHW930PP_X_AGENCY_CODE),8,'0'),'NOKEY') as AGCY_KEY,
ifnull('DPIM'||'-'||LPAD(TRIM(fact.PHW930PP_X_AGENCY_CODE),8,'0') ||'-'|| LPAD(TRIM(fact.PHW930PP_X_PRODUCER_NBR),8,'0'),'NOKEY') as AGNT_KEY,
'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER as POL_KEY,
'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER as POL_LINE_KEY,
if(fact.PHW930PP_ACCT_DIST_IND ='P13', IFNULL('PCIO-COP-' || trim(fact.PHW930PP_X_COV_SHORT_NAME),'NOKEY'),'NOKEY') AS COVG_KEY,
if(fact.PHW930PP_ACCT_DIST_IND ='P13' AND fact.PHW930PP_ASSOC_SEQ_NUM1 != '00000' and (fact.PHW930PP_X_COV_SHORT_NAME like 'L%' or fact.PHW930PP_X_COV_SHORT_NAME like 'I%'),ifnull('PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0'),'NOKEY'),'NOKEY') as LOC_KEY,
CASE
When fact.PHW930PP_X_COV_SHORT_NAME LIKE 'P%' AND fact.PHW930PP_ACCT_DIST_IND ='P13' THEN 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-COPLINE-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
When fact.PHW930PP_X_COV_SHORT_NAME LIKE 'L%' AND fact.PHW930PP_ACCT_DIST_IND ='P13' THEN  'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-COPLOCATION-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
WHEN fact.PHW930PP_X_COV_SHORT_NAME LIKE 'B%' AND fact.PHW930PP_ACCT_DIST_IND ='P13' THEN 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-COPBLDG-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
WHEN fact.PHW930PP_X_COV_SHORT_NAME like 'I%' and trim(fact.PHW930PP_ITEM_TYPE) in ('B','D','F','H','J','P','G') AND fact.PHW930PP_ACCT_DIST_IND ='P13' THEN 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')||'-COPLINEBLDG-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
WHEN fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('E','I','X') AND fact.PHW930PP_ACCT_DIST_IND ='P13' THEN 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')||'-COPBUSINESSINCOME-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
WHEN fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('C','K','S') AND fact.PHW930PP_ACCT_DIST_IND ='P13' THEN 'PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0')||'-COPPERSPROP-'||trim(fact.PHW930PP_X_COV_SHORT_NAME)
ELSE 'NOKEY'
END AS LINE_COVG_KEY,
if(fact.PHW930PP_ACCT_DIST_IND ='P13' AND fact.PHW930PP_ASSOC_SEQ_NUM2 != '00000' and (fact.PHW930PP_X_COV_SHORT_NAME like 'B%' or fact.PHW930PP_X_COV_SHORT_NAME like 'I%'),ifnull('PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int)as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0'),'NOKEY'),'NOKEY') AS BLDG_KEY, 
if(fact.PHW930PP_ACCT_DIST_IND ='P13' AND fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('B','D','F','H','J','P','G'),ifnull('PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0'),'NOKEY'),'NOKEY') AS LINE_BLDG_KEY,
if(fact.PHW930PP_ACCT_DIST_IND ='P13' AND fact.PHW930PP_ASSOC_SEQ_NUM1 != '00000' and (fact.PHW930PP_X_COV_SHORT_NAME like 'L%' or fact.PHW930PP_X_COV_SHORT_NAME like 'I%'),ifnull('PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0'),'NOKEY'),'NOKEY') AS LINE_LOC_KEY,  
if(fact.PHW930PP_ACCT_DIST_IND ='P13' AND fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('E','I','X'),ifnull('PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0'), 'NOKEY'), 'NOKEY') as BI_KEY,  
if(fact.PHW930PP_ACCT_DIST_IND ='P13' AND fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('C','K','S'),ifnull('PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM3 as int) as string),3,'0'), 'NOKEY'), 'NOKEY') AS PP_KEY,  
if(fact.PHW930PP_ACCT_DIST_IND ='P13' AND fact.PHW930PP_ASSOC_SEQ_NUM2 != '00000',ifnull('PCIO-COP-'||fact.PHW930PP_PREFIX_A||fact.PHW930PP_PREFIX_B||fact.PHW930PP_POLICY_BRANCH||fact.PHW930PP_POLICY_DEC||fact.PHW930PP_POLICY_NUMBER||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM1 as int)as string),3,'0')||'-'||LPAD(cast(cast(fact.PHW930PP_ASSOC_SEQ_NUM2 as int) as string),3,'0'),'NOKEY'),'NOKEY') AS OCC_CL_KEY,
'NOKEY' AS JURS_KEY,
'PCIO' AS SOURCE_SYSTEM,
'PCIO-COP' AS PARTITION_VAL,
cast((substr(cast(to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy') as string),1,4)||substr(cast(to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy') as string),6,2)) as double) AS ACCTG_MO_ID,
ifnull(to_timestamp(fact.PHW930PP_D_CYCLE,'MM/dd/yyyy'),to_timestamp('9999-12-31 00:00:00.000000')) AS TRANS_PROC_DTS,
to_timestamp('9999-12-31 00:00:00.000000') AS ORIG_TRANS_PROC_DTS,
cast('1900-01-01' as date) AS ORIG_END_EFF_DT,
ifnull(to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy'),cast('1900-01-01' as date)) AS TRANS_EFF_DT,
ifnull(to_date(fact.PHW930PP_D_EXPIRATION1,'MM/dd/yyyy'),cast('1900-01-01' as date)) AS TRANS_EXP_DT,
ifnull(to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy'),cast('1900-01-01' as date)) AS END_EFF_DT,
ifnull(to_date(fact.PHW930PP_D_EXPIRATION1,'MM/dd/yyyy'),cast('1900-01-01' as date)) AS END_EXP_DT,
trim(fact.PHW930PP_C_TRANSACTION_TYPE) AS TRANS_CD,
' ' as TRANS_TYPE_CD, 
0 AS TRANS_SEQ,
Case 
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'P%' then   'COPLINE'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'L%' then   'COPLOCATION'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'B%' then 'COPBLDG'
when fact.PHW930PP_X_COV_SHORT_NAME like 'I%' and trim(fact.PHW930PP_ITEM_TYPE) in ('B','D','F','H','J','P','G') then 'COPLINEBLDG'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('E','I','X') then   'COPBUSINESSINCOME'
when fact.PHW930PP_X_COV_SHORT_NAME LIKE 'I%' AND trim(fact.PHW930PP_ITEM_TYPE) in ('C','K','S') then   'COPPERSPROP'
ELSE ' '
END as CVRBL_TYPE_CD,
ifnull(cast(fact.PHW930PP_M_TOTAL_LIMIT as double),0) AS PREM_BASIS_AMT,
ifnull(ABS(cast(fact.PHW930PP_M_PRORATED_PREM as double)),0) AS ACT_AMT,
ifnull(ABS(cast(fact.PHW930PP_M_FULL_TERM_PREM as double)),0) AS ACT_TERM_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',ifnull(cast(fact.PHW930PP_M_PRORATED_PREM as double),0),0) AS TRANS_AMT,
trim(fact.PHW930PP_C_TRANSACTION_TYPE) AS TRANS_ALLOC_CD,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',ifnull(cast(fact.PHW930PP_M_PRORATED_PREM as double),0), 0) AS WRITTEN_PREM_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',ifnull(cast(fact.PHW930PP_M_PRORATED_PREM as double),0), 0) AS INFORCE_PREM_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P16' OR fact.PHW930PP_ACCT_DIST_IND IS NULL,cast('0' as double),cast('0' as double)) AS TAX_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P16' OR fact.PHW930PP_ACCT_DIST_IND IS NULL,cast('0' as double),cast('0' as double)) AS FEE_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P16' OR fact.PHW930PP_ACCT_DIST_IND IS NULL,cast(fact.PHW930PP_M_PRORATED_PREM as double),0) AS SRCHG_AMT,
cast(fact.PHW930PP_P_CONTRIB_COMMSN as double) AS COMM_CONTRIBUTION_FCTR,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',cast(fact.PHW930PP_P_COMMISSION as double )*cast(fact.PHW930PP_M_PRORATED_PREM as double),null) as COMM_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',cast(fact.PHW930PP_P_COMMISSION as double),null) as COMM_PCT,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',cast(fact.PHW930PP_P_FINAL_COMMSN as double )*cast(fact.PHW930PP_M_PRORATED_PREM as double),null) as NET_COMM_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',cast(fact.PHW930PP_P_FINAL_COMMSN as double),null) as NET_COMM_PCT,
if(fact.PHW930PP_ACCT_DIST_IND ='P13',(cast(fact.PHW930PP_P_CSP_DEV_NUM as double)*cast(fact.PHW930PP_M_PRORATED_PREM as double)),null) as SRVC_PLUS_COMM_AMT,
cast('0' as double) as RATE_CAPPING_FCTR,
ifnull(if(fact.PHW930PP_ACCT_DIST_IND='P13',cast(fact.PHW930PP_M_FULL_TERM_PREM as double),0),0) as FULL_TERM_PREM_AMT,
if(fact.PHW930PP_ACCT_DIST_IND='P13',if((cast(SUBSTR(cast(fact.PHW930PP_D_TRANS_EFF as string),7,10) as int)%4=0 and cast(SUBSTR(cast(fact.PHW930PP_D_TRANS_EFF as string),1,2) as int) <= 2 and cast(SUBSTR(cast(fact.PHW930PP_D_TRANS_EFF as string),4,5) as int)<=29) OR (cast(SUBSTR(cast(fact.PHW930PP_D_EXPIRATION1 as string),7,10) as int)%4=0 and cast(SUBSTR(cast(fact.PHW930PP_D_EXPIRATION1 as string),1,2) as int)>2 and cast(SUBSTR(cast(fact.PHW930PP_D_EXPIRATION1 as string),4,5) as int)>29),ifnull(if(fact.PHW930PP_D_EXPIRATION1=fact.PHW930PP_D_TRANS_EFF,366*cast(fact.PHW930PP_M_FULL_TERM_PREM as double),(366*cast(fact.PHW930PP_M_FULL_TERM_PREM as double))/datediff(to_date(fact.PHW930PP_D_EXPIRATION1,'MM/dd/yyyy'),to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy'))),0),ifnull(if(fact.PHW930PP_D_EXPIRATION1=fact.PHW930PP_D_TRANS_EFF,365*cast(fact.PHW930PP_M_FULL_TERM_PREM as double),(365*cast(fact.PHW930PP_M_FULL_TERM_PREM as double))/datediff(to_date(fact.PHW930PP_D_EXPIRATION1,'MM/dd/yyyy'),to_date(fact.PHW930PP_D_TRANS_EFF,'MM/dd/yyyy'))),0)),0) AS ANNUAL_PREM_AMT,
if(fact.PHW930PP_ACCT_DIST_IND ='P16' OR fact.PHW930PP_ACCT_DIST_IND IS NULL,fact.PHW930PP_C_SURCHARGE_TYPE,' ') AS TFS_COST_TYPE_CD,
ifnull(trim(fact.PHW930PP_C_CLASS), ' ') AS LINE_CLASS_CD,
fact.PHW930PP_C_OOS_IND AS OOS_CD,
'COP' AS LOB_CD
  from global_temp.pcio_mf_cop_prem_micro_batch micro_fact
  inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY PHW930PP_PREFIX_A, PHW930PP_PREFIX_B, PHW930PP_POLICY_BRANCH, PHW930PP_POLICY_DEC, PHW930PP_POLICY_NUMBER, PHW930PP_D_TRANS_EFF, PHW930PP_SEQ_NUM1 ORDER BY to_date(PHW930PP_D_CYCLE,'MM/dd/yyyy')   DESC ) AS rn
   FROM
   (SELECT  pcio_preminc.*
   from
   {rawDB}.PCIO_MF_COP_PREM  pcio_preminc
   inner join global_temp.pcio_mf_cop_prem_micro_batch mb
              on   mb.PHW930PP_PREFIX_A = pcio_preminc.PHW930PP_PREFIX_A 
              and  mb.PHW930PP_PREFIX_B = pcio_preminc.PHW930PP_PREFIX_B
              and  mb.PHW930PP_POLICY_BRANCH = pcio_preminc.PHW930PP_POLICY_BRANCH
              and  mb.PHW930PP_POLICY_DEC = pcio_preminc.PHW930PP_POLICY_DEC
              and  mb.PHW930PP_POLICY_NUMBER = pcio_preminc.PHW930PP_POLICY_NUMBER
              and  mb.PHW930PP_D_TRANS_EFF = pcio_preminc.PHW930PP_D_TRANS_EFF
              and  mb.PHW930PP_SEQ_NUM1 = pcio_preminc.PHW930PP_SEQ_NUM1
              )
  ) WHERE rn = 1  )          
   fact on   fact.PHW930PP_PREFIX_A = micro_fact.PHW930PP_PREFIX_A 
              and  fact.PHW930PP_PREFIX_B = micro_fact.PHW930PP_PREFIX_B
              and  fact.PHW930PP_POLICY_BRANCH = micro_fact.PHW930PP_POLICY_BRANCH
              and  fact.PHW930PP_POLICY_DEC = micro_fact.PHW930PP_POLICY_DEC
              and  fact.PHW930PP_POLICY_NUMBER = micro_fact.PHW930PP_POLICY_NUMBER
              and  fact.PHW930PP_D_TRANS_EFF = micro_fact.PHW930PP_D_TRANS_EFF
              and  fact.PHW930PP_SEQ_NUM1 = micro_fact.PHW930PP_SEQ_NUM1
              and  to_date(fact.PHW930PP_D_CYCLE,'MM/dd/yyyy') = to_date(micro_fact.PHW930PP_D_CYCLE,'MM/dd/yyyy')
   where trim(fact.PHW930PP_PREFIX_A) != ''
"""
 
   microBatchDF.createOrReplaceGlobalTempView(s"pcio_mf_cop_prem_micro_batch")
  println("microBatchDFcount :"+microBatchDF.count)
  microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_raw_hist.pcio_mf_cop_prem_micro_batch_cop_ds_fact_prem_tran")
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB) 
  harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
  println("harmz_query after rawDB replace: \n"+ harmz_query)
   
 
  val harmonized_table = s"${harmonizedDB}.${target}"
  val queryDF=microBatchDF.sparkSession.sql(harmz_query)
  
  //test
    val w = Window.partitionBy($"FACT_PREM_TRANS_KEY").orderBy($"FACT_PREM_TRANS_KEY")
  var auditDF = queryDF.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")  

  val maxSK = spark.table(s"${harmonized_table}").count
  val w1  = Window.orderBy($"FACT_PREM_TRANS_KEY")

  auditDF = auditDF.withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ID", row_number.over(w1) + maxSK)
  
  auditDF= auditDF.withColumn(s"FACT_PREM_TRANS_ID", expr("CAST(ID AS INTEGER)")).drop("ID")
  
  println("auditDF:")
  println("auditDFCount :"+auditDF.count)
  queryDF.show(3,false)
 // queryDF.createOrReplaceGlobalTempView(s"V")
 // val hashDF = addHashColumn_clt("V","FACT_PREM_TRANS_ID") // pass the ID column name
 // auditDF.write.format("delta").mode("append").saveAsTable(harmonized_table)
  
  DeltaTable.forName(spark, harmonized_table)
  .as("events")
  .merge(
    auditDF.as("updates"),
    s"events.FACT_PREM_TRANS_KEY = updates.FACT_PREM_TRANS_KEY AND events.SOURCE_SYSTEM = 'PCIO'")  
  
  .whenNotMatched
  .insertAll()
  .execute()
 }
