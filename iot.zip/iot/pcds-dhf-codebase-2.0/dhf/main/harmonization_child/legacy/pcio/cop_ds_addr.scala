// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_addr(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT
   
'PCIO-COP-'||loc.CPE_MF_LC_PREFIX_A||loc.CPE_MF_LC_PREFIX_B||loc.CPE_MF_LC_POL_BRANCH||loc.CPE_MF_LC_POL_DEC||loc.CPE_MF_LC_POL_NUMBER||'-'||loc.CPE_MF_LC_REC_TYPE||'-'||loc.CPE_MF_LC_SEQ_NUM1||'-'||loc.CPE_MF_LC_VER_DATE AS ADDR_KEY,
IF(TO_TIMESTAMP(loc.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(loc.CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(loc.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'PCIO' AS SOURCE_SYSTEM,
loc.CPE_LC_ADDRESS as STREET_1_NAME,
' ' AS STREET_2_NAME,
'US' AS CNTRY_CD,
loc.CPE_LC_RATE_STATE AS REGION_CD,
loc.CPE_LC_CITY AS CITY_NAME,
loc.CPE_LC_ZIP_CODE_PREFIX||CPE_LC_ZIP_CODE_AREA as POSTAL_CD,
loc.CPE_LC_V_COUNTY_NAME as COUNTY_NAME,
loc.CPE_LC_COUNTY_CODE AS COUNTY_CD,
  'PCIO-COP' as PARTITION_VAL,
TO_DATE(LOC.CPE_MF_LC_VER_DATE, 'yyyyDDD') as END_EFF_DT,
TO_DATE(LOC.CPE_MF_LC_POL_EXP_DATE, 'yyyyDDD') as END_EXP_DT

FROM  
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
  ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
  {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE)
            )
     
            
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT distinct cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
           mb.CPE_MF_GN_PREFIX_A = cop_location.CPE_MF_LC_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_location.CPE_MF_LC_VER_DATE
  and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_location.CPE_GN_CYCLE_DATE is null, 'null', cop_location.CPE_GN_CYCLE_DATE)       

              )
  ) WHERE rn = 1  )          
  )loc
ON
  (gnrl.CPE_MF_GN_PREFIX_A = loc.CPE_MF_LC_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = loc.CPE_MF_LC_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = loc.CPE_MF_LC_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = loc.CPE_MF_LC_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = loc.CPE_MF_LC_POL_NUMBER
and gnrl.CPE_MF_GN_VER_DATE = loc.CPE_MF_LC_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(loc.CPE_GN_CYCLE_DATE is null, 'null', loc.CPE_GN_CYCLE_DATE))

  
  UNION all
  
SELECT 
 'PCIO-COP-'||mort.CPE_MF_MG_PREFIX_A||mort.CPE_MF_MG_PREFIX_B||mort.CPE_MF_MG_POL_BRANCH||mort.CPE_MF_MG_POL_DEC||mort.CPE_MF_MG_POL_NUMBER||'-'||mort.CPE_MF_MG_REC_TYPE||'-'||mort.CPE_MF_MG_SEQ_NUM1||'-'||mort.CPE_MF_MG_VER_DATE AS ADDR_KEY,
IF(TO_TIMESTAMP(MORT.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(MORT.CPE_MF_MG_DATE,'yyyyDDD'), TO_TIMESTAMP(MORT.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'PCIO' AS SOURCE_SYSTEM,
mort.CPE_MG_ADDR1 as STREET_1_NAME,
mort.CPE_MG_ADDR2 as STREET_2_NAME,
'US' AS CNTRY_CD,
mort.CPE_MG_STATE AS REGION_CD,
mort.CPE_MG_CITY AS CITY_NAME,
mort.CPE_MG_ZIP AS POSTAL_CD,
' ' AS COUNTY_NAME,
NULL AS COUNTY_CD,
  'PCIO-COP' as PARTITION_VAL,
TO_DATE(MORT.CPE_MF_MG_VER_DATE, 'yyyyDDD') as END_EFF_DT,
TO_DATE(MORT.CPE_MF_MG_POL_EXP_DATE, 'yyyyDDD') as END_EXP_DT  
  
  
 FROM  
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
  ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
  {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
     
            
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_MG_PREFIX_A,CPE_MF_MG_PREFIX_B, CPE_MF_MG_POL_BRANCH, CPE_MF_MG_POL_DEC, CPE_MF_MG_POL_NUMBER, CPE_MF_MG_VER_DATE, CPE_MF_MG_SEQ_NUM1,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_MG_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  distinct cop_MORTAGAGE.*
   from
   {rawDB}.cop_MORTAGAGE
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
           mb.CPE_MF_GN_PREFIX_A = cop_MORTAGAGE.CPE_MF_MG_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_MORTAGAGE.CPE_MF_MG_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_MORTAGAGE.CPE_MF_MG_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_MORTAGAGE.CPE_MF_MG_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_MORTAGAGE.CPE_MF_MG_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_MORTAGAGE.CPE_MF_MG_VER_DATE
 and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_MORTAGAGE.CPE_GN_CYCLE_DATE is null, 'null', cop_MORTAGAGE.CPE_GN_CYCLE_DATE)        

              )
  ) WHERE rn = 1  )          
  )MORT
 
  on
  (gnrl.CPE_MF_GN_PREFIX_A = MORT.CPE_MF_MG_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = MORT.CPE_MF_MG_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = MORT.CPE_MF_MG_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = MORT.CPE_MF_MG_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = MORT.CPE_MF_MG_POL_NUMBER
and gnrl.CPE_MF_GN_VER_DATE = MORT.CPE_MF_MG_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(MORT.CPE_GN_CYCLE_DATE is null, 'null', MORT.CPE_GN_CYCLE_DATE))
  
 
 UNION ALL
 
 SELECT
'PCIO-COP-'||INS.CPE_MF_IS_PREFIX_A||INS.CPE_MF_IS_PREFIX_B||INS.CPE_MF_IS_POL_BRANCH||INS.CPE_MF_IS_POL_DEC||INS.CPE_MF_IS_POL_NUMBER||'-'||INS.CPE_MF_IS_REC_TYPE||'-'||INS.CPE_MF_IS_SEQ_NUM1||'-'||INS.CPE_MF_IS_VER_DATE AS ADDR_KEY,
IF(TO_TIMESTAMP(INS.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(INS.CPE_MF_IS_DATE,'yyyyDDD'), TO_TIMESTAMP(INS.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'PCIO' AS SOURCE_SYSTEM,
' ' AS STREET_1_NAME,
' ' AS STREET_2_NAME,
'US' AS CNTRY_CD,
INS.CPE_IS_STATE as REGION_CD,
INS.CPE_IS_CITY AS CITY_NAME,
INS.CPE_IS_ZIP as POSTAL_CD,
' ' AS COUNTY_NAME,
NULL AS COUNTY_CD,
'PCIO-COP' as PARTITION_VAL,
TO_DATE(INS.CPE_MF_IS_VER_DATE, 'yyyyDDD') as END_EFF_DT,
TO_DATE(INS.CPE_MF_IS_POL_EXP_DATE, 'yyyyDDD') as END_EXP_DT

FROM  
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
  ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
  {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE)
            )
     
            
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IS_PREFIX_A,CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_SEQ_NUM1, CPE_MF_IS_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_IS_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT distinct cop_insured.*
   from
   {rawDB}.cop_insured
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
           mb.CPE_MF_GN_PREFIX_A = cop_insured.CPE_MF_IS_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_insured.CPE_MF_IS_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_insured.CPE_MF_IS_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_insured.CPE_MF_IS_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_insured.CPE_MF_IS_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_insured.CPE_MF_IS_VER_DATE
  and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_insured.CPE_GN_CYCLE_DATE is null, 'null', cop_insured.CPE_GN_CYCLE_DATE)       

              )
  ) WHERE rn = 1  )          
  )ins

on
(gnrl.CPE_MF_GN_PREFIX_A = ins.CPE_MF_IS_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = ins.CPE_MF_IS_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = ins.CPE_MF_IS_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = ins.CPE_MF_IS_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = ins.CPE_MF_IS_POL_NUMBER 
and gnrl.CPE_MF_GN_VER_DATE = ins.CPE_MF_IS_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(ins.CPE_GN_CYCLE_DATE is null, 'null', ins.CPE_GN_CYCLE_DATE))

"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_party_ADDR_micro_batch_gnrl")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("ADDR_KEY","END_EFF_DT"), harmonized_table, "ADDR_ID","PCIO-COP")
}
