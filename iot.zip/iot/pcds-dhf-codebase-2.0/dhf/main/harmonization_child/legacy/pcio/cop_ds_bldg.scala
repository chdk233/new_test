// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_bldg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

SELECT
'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_MF_BL_SEQ_NUM1||'-'||bldg.CPE_MF_BL_SEQ_NUM2 AS BLDG_KEY,
'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER AS POL_KEY,
'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_MF_BL_SEQ_NUM1 AS LOC_KEY,
to_Date(bldg.CPE_MF_BL_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_Date(bldg.CPE_MF_BL_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
--to_timestamp(bldg.CPE_MF_BL_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
IF(BLDG.CPE_GN_CYCLE_DATE IS NULL,TO_TIMESTAMP(BLDG.CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(BLDG.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
bldg.CPE_BL_YEAR_BUILT AS BUILD_YR,
CASE 
WHEN bldg.CPE_BL_BURG_BR1_IND='Y' THEN 'CENTRAL'
WHEN bldg.CPE_BL_BURG_BR2_IND='Y' THEN 'LOCAL'
ELSE ' '
END AS  BLDG_ALARM_TYPE_CD, 
bldg.CPE_MF_BL_SEQ_NUM2 AS BLDG_NO,
bldg.CPE_BL_CONST_TYPE AS CONSTR_TYPE_CD,
bldg.CPE_BL_DESCRIPTION AS BLDG_DESC,
bldg.CPE_BL_BCEG as EFFECTIVENESS_GRADE_CD, 
cast(bldg.CPE_BL_EQ_NUM_STR as int) AS STORIES_NO,
--cast(trim(bldg.CPE_BL_RES_UNITS) as int) AS UNITS_NO, 
cast(bldg.CPE_BL_SQUARE_FOOTAGE as int) AS TOT_AREA_SF_NO,
'PCIO-COP' AS PARTITION_VAL
from global_temp.cop_bldg_micro_batch micro_bldg
inner join  
( SELECT distinct * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A,CPE_MF_BL_PREFIX_B,CPE_MF_BL_POL_BRANCH,CPE_MF_BL_POL_DEC,CPE_MF_BL_POL_NUMBER,CPE_MF_BL_VER_DATE,CPE_MF_BL_SEQ_NUM1,CPE_MF_BL_SEQ_NUM2,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_BL_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_bldg_micro_batch mb
              on   mb.CPE_MF_BL_PREFIX_A = cop_bldg.CPE_MF_BL_PREFIX_A 
            and mb.CPE_MF_BL_PREFIX_B = cop_bldg.CPE_MF_BL_PREFIX_B 
            and mb.CPE_MF_BL_POL_BRANCH = cop_bldg.CPE_MF_BL_POL_BRANCH 
            and mb.CPE_MF_BL_POL_DEC = cop_bldg.CPE_MF_BL_POL_DEC 
            and mb.CPE_MF_BL_POL_NUMBER = cop_bldg.CPE_MF_BL_POL_NUMBER 
           and mb.CPE_MF_BL_VER_DATE = cop_bldg.CPE_MF_BL_VER_DATE
           and mb.CPE_MF_BL_SEQ_NUM1 = cop_bldg.CPE_MF_BL_SEQ_NUM1
           and mb.CPE_MF_BL_SEQ_NUM2 = cop_bldg.CPE_MF_BL_SEQ_NUM2
           and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_bldg.CPE_GN_CYCLE_DATE is null, 'null', cop_bldg.CPE_GN_CYCLE_DATE)
            

              )
  ) WHERE rn = 1  ) bldg
  on
  bldg.CPE_MF_BL_PREFIX_A = micro_bldg.CPE_MF_BL_PREFIX_A 
            and bldg.CPE_MF_BL_PREFIX_B = micro_bldg.CPE_MF_BL_PREFIX_B 
            and bldg.CPE_MF_BL_POL_BRANCH = micro_bldg.CPE_MF_BL_POL_BRANCH 
            and bldg.CPE_MF_BL_POL_DEC = micro_bldg.CPE_MF_BL_POL_DEC 
            and bldg.CPE_MF_BL_POL_NUMBER = micro_bldg.CPE_MF_BL_POL_NUMBER 
           and bldg.CPE_MF_BL_VER_DATE = micro_bldg.CPE_MF_BL_VER_DATE
           and bldg.CPE_MF_BL_SEQ_NUM1 = micro_bldg.CPE_MF_BL_SEQ_NUM1
           and bldg.CPE_MF_BL_SEQ_NUM2 = micro_bldg.CPE_MF_BL_SEQ_NUM2
           and if(bldg.CPE_GN_CYCLE_DATE is null,'null',bldg.CPE_GN_CYCLE_DATE) = if(micro_bldg.CPE_GN_CYCLE_DATE is null, 'null', micro_bldg.CPE_GN_CYCLE_DATE)

"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_bldg_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_bldg_micro_batch_bldg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("BLDG_KEY","END_EFF_DT"), harmonized_table, "BLDG_ID","PCIO-COP")
}
