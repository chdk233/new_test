// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_line_bldg(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 


SELECT
--'PCIO-COP-'||BLDG.CPE_MF_BL_PREFIX_A||BLDG.CPE_MF_BL_PREFIX_B||BLDG.CPE_MF_BL_POL_BRANCH||BLDG.CPE_MF_BL_POL_DEC||BLDG.CPE_MF_BL_POL_NUMBER||'-'||BLDG.CPE_BL_CLASS_CODE||'-'||BLDG.CPE_MF_BL_SEQ_NUM1||'-'||IF(CPE_MF_IT_SEQ_NUM3 IS NULL,BLDG.CPE_MF_BL_SEQ_NUM2||'-000',BLDG.CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3) AS LINE_BLDG_KEY,
'PCIO-COP-'||BLDG.CPE_MF_BL_PREFIX_A||BLDG.CPE_MF_BL_PREFIX_B||BLDG.CPE_MF_BL_POL_BRANCH||BLDG.CPE_MF_BL_POL_DEC||BLDG.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_MF_BL_SEQ_NUM1||'-'||IF(CPE_MF_IT_SEQ_NUM3 IS NULL,bldg.CPE_MF_BL_SEQ_NUM2||'-000',bldg.CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3) AS LINE_BLDG_KEY,  --CHANGED_NEW


'PCIO-COP-'||BLDG.CPE_MF_BL_PREFIX_A||BLDG.CPE_MF_BL_PREFIX_B||BLDG.CPE_MF_BL_POL_BRANCH||BLDG.CPE_MF_BL_POL_DEC||BLDG.CPE_MF_BL_POL_NUMBER AS POL_KEY,
--'PCIO-COP-'||BLDG.CPE_MF_BL_PREFIX_A||BLDG.CPE_MF_BL_PREFIX_B||BLDG.CPE_MF_BL_POL_BRANCH||BLDG.CPE_MF_BL_POL_DEC||BLDG.CPE_MF_BL_POL_NUMBER||'-'||BLDG.CPE_BL_CLASS_CODE||'-'||BLDG.CPE_MF_BL_SEQ_NUM1||'-'||BLDG.CPE_MF_BL_SEQ_NUM2  AS BLDG_KEY,
'PCIO-COP-'||BLDG.CPE_MF_BL_PREFIX_A||BLDG.CPE_MF_BL_PREFIX_B||BLDG.CPE_MF_BL_POL_BRANCH||BLDG.CPE_MF_BL_POL_DEC||BLDG.CPE_MF_BL_POL_NUMBER||'-'||BLDG.CPE_MF_BL_SEQ_NUM1||'-'||BLDG.CPE_MF_BL_SEQ_NUM2  AS BLDG_KEY,--CHNAGED_NEW

'PCIO-COP-'||BLDG.CPE_MF_BL_PREFIX_A||BLDG.CPE_MF_BL_PREFIX_B||BLDG.CPE_MF_BL_POL_BRANCH||BLDG.CPE_MF_BL_POL_DEC||BLDG.CPE_MF_BL_POL_NUMBER||'-'||BLDG.CPE_MF_BL_SEQ_NUM1 AS LINE_LOCATION_KEY,
'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_MF_BL_SEQ_NUM1 AS LOC_KEY,--changed_added

to_Date(BLDG.CPE_MF_BL_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_Date(BLDG.CPE_MF_BL_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
'PCIO' AS SOURCE_SYSTEM,
--'COPBUILDING' AS CVRBL_TYPE_CD,
'COPLINEBLDG' AS CVRBL_TYPE_CD, --changed_new
cast(ITEM.CPE_IT_AV_LIMIT as int) AS AGREED_VAL_LMT, 
BLDG.CPE_BL_PROT_P1_IND AS AUTOMATIC_SPRINKLER_SYS_FL,   
ITEM.CPE_IT_GROUP1_SPEC_RATE as BASE_GRP_I_TENT_LOSS_RATE, --from pm
BLDG.CPE_BL_SYMBOL AS BASE_GRP_II_SYMB,
case 
when BLDG.CPE_BL_SPEC_RATE_IND = 'Y' then 'SPECIFIC'
ELSE 'CLASS' 
END AS BASE_GRP_II_RATING_TYPE,
cast(BLDG.CPE_BL_BCEG as int) AS BCEG_CL,
BLDG.CPE_MF_BL_SEQ_NUM1||BLDG.CPE_MF_BL_SEQ_NUM2 AS BLDG_UNQ_ID,
cast(BLDG.CPE_BL_SQUARE_FOOTAGE as int) AS BLDG_SF_NO,
BLDG.CPE_BL_DESCRIPTION AS CL_RATE_CONVRT_CL_DESC,
BLDG.CPE_BL_CONST_TYPE AS CONSTR_CD, 
CASE WHEN BLDG.CPE_BL_CONST_TYPE='1' THEN 'Frame'
     WHEN BLDG.CPE_BL_CONST_TYPE='2' THEN 'Joisted Masonry - Other Than Reinforced'
     WHEN BLDG.CPE_BL_CONST_TYPE='3' THEN "Non-Combustible - Light Steel"
     WHEN BLDG.CPE_BL_CONST_TYPE='4' THEN 'Masonry Non-Combustible - Other Than Reinforced - Light Steel'
     WHEN BLDG.CPE_BL_CONST_TYPE='5' THEN 'Modified Fire Resistive - Other Than Reinforced Masonry - Light Steel'
     WHEN BLDG.CPE_BL_CONST_TYPE='6' THEN 'Fire Resistive - Other Than Reinforced Masonry - Light Steel' 
     ELSE ' '
     END AS CONSTR_TYPE, 
cast(BLDG.CPE_BL_YEAR_BUILT as int) AS CONSTR_YR_NO,
'Building' as  COVG_TYPE,
BLDG.CPE_BL_EQ_BLD_CLS AS EQ_CONSTR_CL, 
cast(BLDG.CPE_BL_HURR_DED_PCT as int) AS HURR_PCT_DED,
IF (GNRL.CPE_GN_BLANKET_BUILDING = 'Y' OR  GNRL.CPE_GN_BLANKET_BLDG_CNTS = 'Y', 'Y', 'N') as INCL_IN_BLNKT_FL, 
BLDG.CPE_BL_BCEG_INDIV_GR_EQ as INDIV_GRD_PRMS, 
cast(BLDG.CPE_MF_BL_SEQ_NUM2 as int) AS LEGACY_BLDG_NO,
cast(BLDG.CPE_BL_BCEG_RECERT_YR as int) AS OCCPNCY_RECERT_YR,
to_date(BLDG.CPE_BL_SPEC_RATE_DATE,'yyDDD') AS ONSITE_SURV_DTS, 
case 
when BLDG.CPE_BL_SPEC_RATE_IND = 'Y' then 'SPECIFIC'
ELSE 'CLASS' 
END AS  RATING_TYPE,
BLDG.CPE_BL_SPRINKLER_RISK_IND AS SPRINKLER_RED_FL, 
CASE WHEN BLDG.CPE_BL_SPRINKLER_RISK_IND = 'Y' AND ( BLDG.CPE_BL_SPEC_RATE_IND = 'Y' or BLDG.CPE_BL_SPEC_RATE_IND='N')
    THEN "Sprinklered Building, but Not Rated as Sprinklered"
    WHEN BLDG.CPE_BL_SPRINKLER_RISK_IND = 'N' AND  (BLDG.CPE_BL_SPEC_RATE_IND = 'Y' OR BLDG.CPE_BL_SPEC_RATE_IND='N')
    THEN "NONE"
    ELSE ' '
  END AS SPRINKLER_SYS,
cast(BLDG.CPE_BL_EQ_NUM_STR as int) AS STORIES_NO,
BLDG.CPE_BL_VACANCY_IND AS VACANT_BLDG_FL,
IF(BLDG.CPE_GN_CYCLE_DATE IS NULL,TO_TIMESTAMP(BLDG.CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(BLDG.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'PCIO-COP' AS PARTITION_VAL,
'COP' AS LOB_CD


from global_temp.cop_bldg_micro_batch micro_bldg
inner join  
( SELECT distinct * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A,CPE_MF_BL_PREFIX_B,CPE_MF_BL_POL_BRANCH,CPE_MF_BL_POL_DEC,CPE_MF_BL_POL_NUMBER,CPE_MF_BL_VER_DATE,CPE_MF_BL_SEQ_NUM1,CPE_MF_BL_SEQ_NUM2,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_BL_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_bldg_micro_batch mb
              on   mb.CPE_MF_BL_PREFIX_A = cop_bldg.CPE_MF_BL_PREFIX_A 
            and mb.CPE_MF_BL_PREFIX_B = cop_bldg.CPE_MF_BL_PREFIX_B 
            and mb.CPE_MF_BL_POL_BRANCH = cop_bldg.CPE_MF_BL_POL_BRANCH 
            and mb.CPE_MF_BL_POL_DEC = cop_bldg.CPE_MF_BL_POL_DEC 
            and mb.CPE_MF_BL_POL_NUMBER = cop_bldg.CPE_MF_BL_POL_NUMBER 
           and mb.CPE_MF_BL_VER_DATE = cop_bldg.CPE_MF_BL_VER_DATE
           and mb.CPE_MF_BL_SEQ_NUM1 = cop_bldg.CPE_MF_BL_SEQ_NUM1
           and mb.CPE_MF_BL_SEQ_NUM2 = cop_bldg.CPE_MF_BL_SEQ_NUM2
           and if(MB.CPE_GN_CYCLE_DATE is null,'null',MB.CPE_GN_CYCLE_DATE) = if(COP_BLDG.CPE_GN_CYCLE_DATE is null, 'null', COP_BLDG.CPE_GN_CYCLE_DATE)
            

              )
  ) WHERE rn = 1  ) bldg
  on
  bldg.CPE_MF_BL_PREFIX_A = micro_bldg.CPE_MF_BL_PREFIX_A 
            and bldg.CPE_MF_BL_PREFIX_B = micro_bldg.CPE_MF_BL_PREFIX_B 
            and bldg.CPE_MF_BL_POL_BRANCH = micro_bldg.CPE_MF_BL_POL_BRANCH 
            and bldg.CPE_MF_BL_POL_DEC = micro_bldg.CPE_MF_BL_POL_DEC 
            and bldg.CPE_MF_BL_POL_NUMBER = micro_bldg.CPE_MF_BL_POL_NUMBER 
           and bldg.CPE_MF_BL_VER_DATE = micro_bldg.CPE_MF_BL_VER_DATE
           and bldg.CPE_MF_BL_SEQ_NUM1 = micro_bldg.CPE_MF_BL_SEQ_NUM1
           and bldg.CPE_MF_BL_SEQ_NUM2 = micro_bldg.CPE_MF_BL_SEQ_NUM2
             and if(BLDG.CPE_GN_CYCLE_DATE is null,'null',BLDG.CPE_GN_CYCLE_DATE) = if(MICRO_BLDG.CPE_GN_CYCLE_DATE is null, 'null', MICRO_BLDG.CPE_GN_CYCLE_DATE)
left join
 
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
   {rawDB}.cop_gnrl
   inner join global_temp.cop_bldg_micro_batch mb
             on   mb.CPE_MF_BL_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_BL_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_BL_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_BL_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_BL_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_BL_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(MB.CPE_GN_CYCLE_DATE is null,'null',MB.CPE_GN_CYCLE_DATE) = if(COP_GNRL.CPE_GN_CYCLE_DATE is null, 'null', COP_GNRL.CPE_GN_CYCLE_DATE)
            
            
--               where cop_gnrl.CPE_GN_CYCLE_DATE <= mb.CPE_GN_CYCLE_DATE
              )
  ) WHERE rn = 1  ) gnrl
on
GNRL.CPE_MF_GN_PREFIX_A=BLDG.CPE_MF_BL_PREFIX_A and
GNRL.CPE_MF_GN_PREFIX_B=BLDG.CPE_MF_BL_PREFIX_B and
GNRL.CPE_MF_GN_POL_BRANCH=BLDG.CPE_MF_BL_POL_BRANCH and
GNRL.CPE_MF_GN_POL_DEC=BLDG.CPE_MF_BL_POL_DEC and
GNRL.CPE_MF_GN_POL_NUMBER=BLDG.CPE_MF_BL_POL_NUMBER and
GNRL.CPE_MF_GN_VER_DATE=BLDG.CPE_MF_BL_VER_DATE AND
GNRL.CPE_MF_GN_POL_EXP_DATE=BLDG.CPE_MF_BL_POL_EXP_DATE 
and if(GNRL.CPE_GN_CYCLE_DATE is null,'null',GNRL.CPE_GN_CYCLE_DATE) = if(BLDG.CPE_GN_CYCLE_DATE is null, 'null', BLDG.CPE_GN_CYCLE_DATE)
left join

(SELECT DISTINCT * FROM ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IT_PREFIX_A, CPE_MF_IT_PREFIX_B, CPE_MF_IT_POL_BRANCH, CPE_MF_IT_POL_DEC, CPE_MF_IT_POL_NUMBER, CPE_MF_IT_VER_DATE,  CPE_MF_IT_SEQ_NUM2, CPE_MF_IT_SEQ_NUM1, CPE_MF_IT_SEQ_NUM3,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_IT_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_item.*
   from
   {rawDB}.cop_item
   inner join global_temp.cop_bldg_micro_batch mb
   
              on  
          mb.CPE_MF_BL_PREFIX_A = cop_item.CPE_MF_IT_PREFIX_A
and mb.CPE_MF_BL_PREFIX_B = cop_item.CPE_MF_IT_PREFIX_B
and mb.CPE_MF_BL_POL_BRANCH = cop_item.CPE_MF_IT_POL_BRANCH
and mb.CPE_MF_BL_POL_DEC = cop_item.CPE_MF_IT_POL_DEC
and mb.CPE_MF_BL_POL_NUMBER = cop_item.CPE_MF_IT_POL_NUMBER
and mb.CPE_MF_BL_VER_DATE = cop_item.CPE_MF_IT_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_item.CPE_GN_CYCLE_DATE is null, 'null', cop_item.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )) item ON
bldg.CPE_MF_BL_PREFIX_A=item.CPE_MF_IT_PREFIX_A and 
bldg.CPE_MF_BL_PREFIX_B=item.CPE_MF_IT_PREFIX_B and
bldg.CPE_MF_BL_POL_BRANCH=item.CPE_MF_IT_POL_BRANCH and
bldg.CPE_MF_BL_POL_DEC=item.CPE_MF_IT_POL_DEC and
bldg.CPE_MF_BL_POL_NUMBER=item.CPE_MF_IT_POL_NUMBER and
bldg.CPE_MF_BL_SEQ_NUM1=ITEM.CPE_MF_IT_SEQ_NUM1 AND
bldg.CPE_MF_BL_SEQ_NUM2=ITEM.CPE_MF_IT_SEQ_NUM2 and
bldg.CPE_MF_BL_VER_DATE =item.CPE_MF_IT_VER_DATE AND
BLDG.CPE_MF_BL_POL_EXP_DATE=ITEM.CPE_MF_IT_POL_EXP_DATE  and
if(BLDG.CPE_GN_CYCLE_DATE is null,'null',BLDG.CPE_GN_CYCLE_DATE) = if(ITEM.CPE_GN_CYCLE_DATE is null, 'null', ITEM.CPE_GN_CYCLE_DATE) --and  trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J')
 and  trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G')--changed_new


"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_bldg_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_line_bldg_micro_batch_gnrl")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("LINE_BLDG_KEY","END_EFF_DT"), harmonized_table, "LINE_BLDG_ID","PCIO-COP")
}
