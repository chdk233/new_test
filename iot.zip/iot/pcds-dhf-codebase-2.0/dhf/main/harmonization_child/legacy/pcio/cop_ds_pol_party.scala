// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_pol_party(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select 
'PCIO-COP-'||ins.CPE_MF_IS_PREFIX_A||ins.CPE_MF_IS_PREFIX_B||ins.CPE_MF_IS_POL_BRANCH||ins.CPE_MF_IS_POL_DEC||ins.CPE_MF_IS_POL_NUMBER||'-'||ins.CPE_MF_IS_REC_TYPE||'-'||ins.CPE_MF_IS_SEQ_NUM1 as POL_PARTY_KEY,
'PCIO-COP-'||ins.CPE_MF_IS_PREFIX_A||ins.CPE_MF_IS_PREFIX_B||ins.CPE_MF_IS_POL_BRANCH||ins.CPE_MF_IS_POL_DEC||ins.CPE_MF_IS_POL_NUMBER as POL_KEY,
'PCIO-COP-'||ins.CPE_MF_IS_PREFIX_A||ins.CPE_MF_IS_PREFIX_B||ins.CPE_MF_IS_POL_BRANCH||ins.CPE_MF_IS_POL_DEC||ins.CPE_MF_IS_POL_NUMBER||'-'||ins.CPE_MF_IS_REC_TYPE||'-'||ins.CPE_MF_IS_SEQ_NUM1||'-'||ins.CPE_MF_IS_VER_DATE as PARTY_KEY,
TO_dATE(ins.CPE_MF_IS_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_Date(ins.CPE_MF_IS_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
IF(TO_TIMESTAMP(INS.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(INS.CPE_MF_IS_DATE,'yyyyDDD'), TO_TIMESTAMP(INS.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
'NamedInsured' as PARTY_ROLE_TYPE_CD,
'PCIO-COP' AS PARTITION_VAL,
CPE_IS_NAME as PARTY_NAME
FROM
  global_temp.cop_gnrl_micro_batch micro_gnrl
  
  INNER JOIN
  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A, CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, cpe_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  COP_GNRL.*
   from
   {rawDB}.COP_GNRL
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = COP_GNRL.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = COP_GNRL.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = COP_GNRL.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = COP_GNRL.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = COP_GNRL.CPE_MF_GN_POL_NUMBER 
            and mb.cpe_MF_GN_VER_DATE = COP_GNRL.cpe_MF_GN_VER_DATE
        and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
--               where CP_BLDG.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )     
   GNRL ON(
    trim(GNRL.CPE_MF_GN_PREFIX_A) = trim(micro_gnrl.CPE_MF_GN_PREFIX_A)
    and trim(GNRL.CPE_MF_GN_PREFIX_B) = trim(micro_gnrl.CPE_MF_GN_PREFIX_B)
    and trim(GNRL.CPE_MF_GN_POL_BRANCH) = trim(micro_gnrl.CPE_MF_GN_POL_BRANCH)
    and trim(GNRL.CPE_MF_GN_POL_DEC) = trim(micro_gnrl.CPE_MF_GN_POL_DEC)
    and trim(GNRL.CPE_MF_GN_POL_NUMBER) = trim(micro_gnrl.CPE_MF_GN_POL_NUMBER)
    and trim(GNRL.cpe_MF_GN_VER_DATE) = trim(micro_gnrl.cpe_MF_GN_VER_DATE)
    and if(GNRL.CPE_GN_CYCLE_DATE is null,'null',GNRL.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
    
   inner join
 
   ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IS_PREFIX_A, CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_VER_DATE, CPE_MF_IS_SEQ_NUM1,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_IS_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  COP_INSURED.*
   from
  {rawDB}.COP_INSURED
   inner join global_temp.cop_GNRL_micro_batch mb 
              on   mb.CPE_MF_GN_PREFIX_A = COP_INSURED.CPE_MF_IS_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = COP_INSURED.CPE_MF_IS_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = COP_INSURED.CPE_MF_IS_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = COP_INSURED.CPE_MF_IS_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = COP_INSURED.CPE_MF_IS_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = COP_INSURED.CPE_MF_IS_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(COP_INSURED.CPE_GN_CYCLE_DATE is null, 'null', COP_INSURED.CPE_GN_CYCLE_DATE)
--               where CP_GNRL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )             
   INS
  on 
trim(GNRL.CPE_MF_GN_PREFIX_A) = trim(INS.CPE_MF_IS_PREFIX_A)
and GNRL.cpe_mf_gn_prefix_b=INS.CPE_MF_IS_PREFIX_B
AND GNRL.CPE_MF_GN_POL_BRANCh = INS.CPE_MF_IS_POL_BRANCH
AND GNRL.CPE_MF_GN_POL_DEC = INS.CPE_MF_IS_POL_DEC
and  GNRL.CPE_MF_GN_POL_NUMBER =INS.CPE_MF_IS_POL_NUMBER
and  GNRL.CPE_MF_GN_VER_DATE=INS.CPE_MF_IS_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(INS.CPE_GN_CYCLE_DATE is null, 'null', INS.CPE_GN_CYCLE_DATE)

UNION all

select
'PCIO-COP-'||mort.CPE_MF_MG_PREFIX_A||mort.CPE_MF_MG_PREFIX_B||mort.CPE_MF_MG_POL_BRANCH||mort.CPE_MF_MG_POL_DEC||mort.CPE_MF_MG_POL_NUMBER||'-'||mort.CPE_MF_MG_REC_TYPE||'-'||mort.CPE_MF_MG_SEQ_NUM1 as POL_PARTY_KEY,
'PCIO-COP-'||mort.CPE_MF_MG_PREFIX_A||mort.CPE_MF_MG_PREFIX_B||mort.CPE_MF_MG_POL_BRANCH||mort.CPE_MF_MG_POL_DEC||mort.CPE_MF_MG_POL_NUMBER as POL_KEY,
'PCIO-COP-'||mort.CPE_MF_MG_PREFIX_A||mort.CPE_MF_MG_PREFIX_B||mort.CPE_MF_MG_POL_BRANCH||mort.CPE_MF_MG_POL_DEC||mort.CPE_MF_MG_POL_NUMBER||'-'||mort.CPE_MF_MG_REC_TYPE||'-'||mort.CPE_MF_MG_SEQ_NUM1||'-'||mort.CPE_MF_MG_VER_DATE AS PARTY_KEY,
TO_DATE(mort.CPE_MF_MG_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_Date(mort.CPE_MF_MG_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
IF(TO_TIMESTAMP(MORT.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(MORT.CPE_MF_MG_DATE,"yyyyDDD"), TO_TIMESTAMP(MORT.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
'AdditionalInterest' as PARTY_ROLE_TYPE_CD,
'PCIO-COP' AS PARTITION_VAL,
CPE_MG_NAME1||CPE_MG_NAME2||CPE_MG_NAME3 as  PARTY_NAME

 FROM
  global_temp.cop_gnrl_micro_batch micro_gnrl
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A, CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, cpe_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  COP_GNRL.*
   from
   {rawDB}.COP_GNRL
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = COP_GNRL.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = COP_GNRL.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = COP_GNRL.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = COP_GNRL.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = COP_GNRL.CPE_MF_GN_POL_NUMBER 
            and mb.cpe_MF_GN_VER_DATE = COP_GNRL.cpe_MF_GN_VER_DATE
           and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(COP_GNRL.CPE_GN_CYCLE_DATE is null, 'null', COP_GNRL.CPE_GN_CYCLE_DATE)
            
--               where CP_BLDG.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )         
   GNRL ON(
    trim(GNRL.CPE_MF_GN_PREFIX_A) = trim(micro_gnrl.CPE_MF_GN_PREFIX_A)
    and trim(GNRL.CPE_MF_GN_PREFIX_B) = trim(micro_gnrl.CPE_MF_GN_PREFIX_B)
    and trim(GNRL.CPE_MF_GN_POL_BRANCH) = trim(micro_gnrl.CPE_MF_GN_POL_BRANCH)
    and trim(GNRL.CPE_MF_GN_POL_DEC) = trim(micro_gnrl.CPE_MF_GN_POL_DEC)
    and trim(GNRL.CPE_MF_GN_POL_NUMBER) = trim(micro_gnrl.CPE_MF_GN_POL_NUMBER)
    and trim(GNRL.cpe_MF_GN_VER_DATE) = trim(micro_gnrl.cpe_MF_GN_VER_DATE) 
    and if(GNRL.CPE_GN_CYCLE_DATE is null,'null',GNRL.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
   inner join
 
   ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_MG_PREFIX_A, CPE_MF_MG_PREFIX_B, CPE_MF_MG_POL_BRANCH, CPE_MF_MG_POL_DEC , CPE_MF_MG_POL_NUMBER, CPE_MG_MORT_NUM, CPE_MF_MG_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_MG_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  COP_MORTAGAGE.*
   from
   {rawDB}.COP_MORTAGAGE
   inner join global_temp.cop_GNRL_micro_batch mb 
              on   mb.CPE_MF_GN_PREFIX_A = COP_MORTAGAGE.CPE_MF_MG_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = COP_MORTAGAGE.CPE_MF_MG_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = COP_MORTAGAGE.CPE_MF_MG_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = COP_MORTAGAGE.CPE_MF_MG_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = COP_MORTAGAGE.CPE_MF_MG_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = COP_MORTAGAGE.CPE_MF_MG_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(COP_MORTAGAGE.CPE_GN_CYCLE_DATE is null, 'null', COP_MORTAGAGE.CPE_GN_CYCLE_DATE)
--               where CP_GNRL.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  
MORT
  on 
trim(GNRL.CPE_MF_GN_PREFIX_A) = trim(MORT.CPE_MF_MG_PREFIX_A)
and GNRL.cpe_mf_gn_prefix_b=MORT.CPE_MF_MG_PREFIX_B
AND GNRL.CPE_MF_GN_POL_BRANCh = MORT.CPE_MF_MG_POL_BRANCH
AND GNRL.CPE_MF_GN_POL_DEC = MORT.CPE_MF_MG_POL_DEC
and GNRL.CPE_MF_GN_POL_NUMBER =MORT.CPE_MF_MG_POL_NUMBER
and  GNRL.CPE_MF_GN_VER_DATE=MORT.CPE_MF_MG_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(mort.CPE_GN_CYCLE_DATE is null, 'null', mort.CPE_GN_CYCLE_DATE)

"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_pol_party_micro_batch_gnrl")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("POL_PARTY_KEY","END_EFF_DT"), harmonized_table, "POL_PARTY_ID","PCIO-COP")
}
