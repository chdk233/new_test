// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_named_insured(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

SELECT 
'PCIO-COP-'||ins.CPE_MF_IS_PREFIX_A||ins.CPE_MF_IS_PREFIX_B||ins.CPE_MF_IS_POL_BRANCH||ins.CPE_MF_IS_POL_DEC||ins.CPE_MF_IS_POL_NUMBER||'-'||ins.CPE_MF_IS_SEQ_NUM1 as NAMED_INSURED_KEY,
'PCIO-COP-'||ins.CPE_MF_IS_PREFIX_A||ins.CPE_MF_IS_PREFIX_B||ins.CPE_MF_IS_POL_BRANCH||ins.CPE_MF_IS_POL_DEC||ins.CPE_MF_IS_POL_NUMBER AS POL_KEY,
TO_dATE(ins.CPE_MF_IS_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_Date(ins.CPE_MF_IS_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
IF(TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(ins.CPE_MF_IS_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
ins.CPE_IS_NAME as INSURED_NAME,
ins.CPE_IS_CITY as MAILING_CITY,
ins.CPE_IS_STATE as MAILING_STATE_CD,
ins.CPE_IS_ZIP as MAILING_ZIP_CD,
if(ranking=1,'Y','N') AS PRIM_INSURED_FL,
'PCIO-COP' AS PARTITION_VAL
FROM 
(SELECT *,
rank() over ( partition BY CPE_MF_IS_PREFIX_A, CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_VER_DATE order by CPE_MF_IS_PREFIX_A, CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_VER_DATE,CPE_MF_IS_SEQ_NUM1 ASC ) AS RANKING
FROM
  global_temp.cop_insured_micro_batch )micro_insured
    
  INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IS_PREFIX_A, CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_VER_DATE, CPE_MF_IS_SEQ_NUM1,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_IS_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_insured.*
   from
   {rawDB}.cop_insured 
   inner join global_temp.cop_insured_micro_batch mb
              on   mb.CPE_MF_IS_PREFIX_A = cop_insured.CPE_MF_IS_PREFIX_A 
            and mb.CPE_MF_IS_PREFIX_B = cop_insured.CPE_MF_IS_PREFIX_B 
            and mb.CPE_MF_IS_POL_BRANCH = cop_insured.CPE_MF_IS_POL_BRANCH 
            and mb.CPE_MF_IS_POL_DEC = cop_insured.CPE_MF_IS_POL_DEC 
            and mb.CPE_MF_IS_POL_NUMBER = cop_insured.CPE_MF_IS_POL_NUMBER 
            and mb.CPE_MF_IS_VER_DATE = cop_insured.CPE_MF_IS_VER_DATE
           and mb.CPE_MF_IS_SEQ_NUM1 = cop_insured.CPE_MF_IS_SEQ_NUM1
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_insured.CPE_GN_CYCLE_DATE is null, 'null', cop_insured.CPE_GN_CYCLE_DATE) 
            
            
--               where CP_INSURED.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
    INS ON 
    trim(INS.CPE_MF_IS_PREFIX_A) = trim(micro_insured.CPE_MF_IS_PREFIX_A)
   and trim(INS.CPE_MF_IS_PREFIX_B) = trim(micro_insured.CPE_MF_IS_PREFIX_B)
    and trim(INS.CPE_MF_IS_POL_BRANCH) = trim(micro_insured.CPE_MF_IS_POL_BRANCH)
    and trim(INS.CPE_MF_IS_POL_DEC) = trim(micro_insured.CPE_MF_IS_POL_DEC)
    and trim(INS.CPE_MF_IS_POL_NUMBER) = trim(micro_insured.CPE_MF_IS_POL_NUMBER)
    and trim(INS.CPE_MF_IS_VER_DATE) = trim(micro_insured.CPE_MF_IS_VER_DATE)
    and trim(INS.CPE_MF_IS_SEQ_NUM1) = trim(micro_insured.CPE_MF_IS_SEQ_NUM1)
    and if(INS.CPE_GN_CYCLE_DATE is null,'null',INS.CPE_GN_CYCLE_DATE) = if(micro_insured.CPE_GN_CYCLE_DATE is null, 'null', micro_insured.CPE_GN_CYCLE_DATE)

"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_insured_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_location_micro_batch_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("NAMED_INSURED_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table, "NAMED_INSURED_ID","PCIO-COP")
}
