// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_geo_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT
'PCIO-COP-'||loc.CPE_MF_LC_PREFIX_A||loc.CPE_MF_LC_PREFIX_B||loc.CPE_MF_LC_POL_BRANCH||loc.CPE_MF_LC_POL_DEC||loc.CPE_MF_LC_POL_NUMBER||'-'||loc.CPE_MF_LC_SEQ_NUM1 AS GEO_INFO_KEY,
'PCIO-COP-'||loc.CPE_MF_LC_PREFIX_A||loc.CPE_MF_LC_PREFIX_B||loc.CPE_MF_LC_POL_BRANCH||loc.CPE_MF_LC_POL_DEC||loc.CPE_MF_LC_POL_NUMBER AS POL_KEY,
'PCIO-COP-'||loc.CPE_MF_LC_PREFIX_A||loc.CPE_MF_LC_PREFIX_B||loc.CPE_MF_LC_POL_BRANCH||loc.CPE_MF_LC_POL_DEC||loc.CPE_MF_LC_POL_NUMBER||'-'||loc.CPE_MF_LC_SEQ_NUM1 AS LOC_KEY,
IF(loc.CPE_LC_VISTA_IND='O','Y',if(loc.CPE_LC_VISTA_IND='V','N','U'))  AS OVERRIDE_FL,
to_date(loc.CPE_MF_LC_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(loc.CPE_MF_LC_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
IF(TO_TIMESTAMP(loc.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(loc.CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(loc.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
loc.CPE_LC_CENTROID AS CENTROID_CD,
cast(loc.CPE_LC_TOWN_CODE as int) AS CITY_CD,
loc.CPE_LC_COASTAL_POL_ID AS  COASTAL_STRICT_CD,
loc.CPE_LC_COASTAL_NAME AS COASTAL_NAME,
cast(loc.CPE_LC_COUNTY_CODE as int )  AS COUNTY_CD,
loc.CPE_LC_V_COUNTY_NAME AS COUNTY_NAME,
cast(loc.CPE_LC_V_EQ_TERR as int ) as EQ_TERRITORY_ZONE_CD,
IF( CAST(loc.CPE_LC_RATE_STATE AS INT) IN ('7','12','33','31'),loc.CPE_LC_FIRE_DIST_CNTY,' ') as FIRE_DISTRICT_CD,
cast(loc.CPE_LC_FEET_TO_HYDRANT as int) as  FIRE_HYDRANT_DISTANCE_CD,
loc.CPE_LC_FIRE_DIST_NAME as FIRE_PROTECT_AREA_NAME,
cast(loc.CPE_LC_FEET_TO_HYDRANT as int )/100 as FIRE_STATION_DISTANCE_QTY,
loc.CPE_LC_PREM_TAX_QUAL_CODE as MATCH_QUALITY_CD,
loc.CPE_LC_CERT_FIRE_DEPT as MS_CERTD_FIRE_CR_ELGB_IND,
cast(loc.CPE_LC_MUNI_CODE as int ) as MUNICIPALITY_CD,
IF( CAST(loc.CPE_LC_RATE_STATE AS INT) IN ('9'),CAST(loc.CPE_LC_POLICY_FIRE_DIST_CODE AS INT),' ') AS  POLICE_TAX_CD, 
IF( CAST(loc.CPE_LC_RATE_STATE AS INT) IN ('16'),loc.CPE_LC_FIRE_DIST_CNTY,' ')  as PREM_TAX_CD, 
cast(loc.CPE_LC_PROT_CLASS as int) as PROTECTION_CL_CD,
loc.CPE_LC_PIRL_QUALITY_CODE as QUALITY_CD,
loc.CPE_LC_SPLT_PROT_IND as SPLIT_PROTECTION_CLASS_IND,
loc.CPE_LC_ALLIED_TERR as TERRITORY_CD, 
IF( CAST(loc.CPE_LC_RATE_STATE AS INT) IN ('39','1'),CAST(loc.CPE_LC_MUNI_CODE AS INT),' ') as TOWN_CD, 
loc.CPE_LC_MILES_FIRE_DEPT/100 as  FIRE_STATION_MILE_DIST_QTY,
'PCIO-COP' AS PARTITION_VAL
from global_temp.cop_location_micro_batch micro_loc
inner join  
( SELECT distinct * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_VER_DATE, CPE_MF_LC_SEQ_NUM1, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_location_micro_batch mb
              on   mb.CPE_MF_LC_PREFIX_A = cop_location.CPE_MF_LC_PREFIX_A 
            and mb.CPE_MF_LC_PREFIX_B = cop_location.CPE_MF_LC_PREFIX_B 
            and mb.CPE_MF_LC_POL_BRANCH = cop_location.CPE_MF_LC_POL_BRANCH 
            and mb.CPE_MF_LC_POL_DEC = cop_location.CPE_MF_LC_POL_DEC 
            and mb.CPE_MF_LC_POL_NUMBER = cop_location.CPE_MF_LC_POL_NUMBER 
           and mb.CPE_MF_LC_VER_DATE = cop_location.CPE_MF_LC_VER_DATE
           and mb.CPE_MF_LC_SEQ_NUM1 = cop_location.CPE_MF_LC_SEQ_NUM1
           and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_location.CPE_GN_CYCLE_DATE is null, 'null', cop_location.CPE_GN_CYCLE_DATE)  

              )
  ) WHERE rn = 1  ) loc
  on
  loc.CPE_MF_LC_PREFIX_A = micro_loc.CPE_MF_LC_PREFIX_A 
            and loc.CPE_MF_LC_PREFIX_B = micro_loc.CPE_MF_LC_PREFIX_B 
            and loc.CPE_MF_LC_POL_BRANCH = micro_loc.CPE_MF_LC_POL_BRANCH 
            and loc.CPE_MF_LC_POL_DEC = micro_loc.CPE_MF_LC_POL_DEC 
            and loc.CPE_MF_LC_POL_NUMBER = micro_loc.CPE_MF_LC_POL_NUMBER 
           and loc.CPE_MF_LC_VER_DATE = micro_loc.CPE_MF_LC_VER_DATE
           and loc.CPE_MF_LC_SEQ_NUM1 = micro_loc.CPE_MF_LC_SEQ_NUM1
          and if(loc.CPE_GN_CYCLE_DATE is null,'null',loc.CPE_GN_CYCLE_DATE) = if(micro_loc.CPE_GN_CYCLE_DATE is null, 'null', micro_loc.CPE_GN_CYCLE_DATE) 
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_location_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_GEO_INFO_micro_batch_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("GEO_INFO_KEY","END_EFF_DT","ETL_ROW_EFF_DTS"), harmonized_table, "GEO_INFO_ID","PCIO-COP")
}
