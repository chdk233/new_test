// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_occ_cl(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT
--'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_BL_CLASS_CODE||'-'||bldg.CPE_MF_BL_SEQ_NUM1||'-'||bldg.CPE_MF_BL_SEQ_NUM2 AS OCC_CL_KEY,

'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_MF_BL_SEQ_NUM1||'-'||bldg.CPE_MF_BL_SEQ_NUM2 AS OCC_CL_KEY,--CHANGED_NEW
'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER AS POL_KEY,
'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER AS POL_LINE_KEY,
--'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_BL_CLASS_CODE||'-'||bldg.CPE_MF_BL_SEQ_NUM1||'-'||bldg.CPE_MF_BL_SEQ_NUM2 AS BLDG_KEY,
'PCIO-COP-'||bldg.CPE_MF_BL_PREFIX_A||bldg.CPE_MF_BL_PREFIX_B||bldg.CPE_MF_BL_POL_BRANCH||bldg.CPE_MF_BL_POL_DEC||bldg.CPE_MF_BL_POL_NUMBER||'-'||bldg.CPE_MF_BL_SEQ_NUM1||'-'||bldg.CPE_MF_BL_SEQ_NUM2 AS BLDG_KEY,--changed_new

to_Date(bldg.CPE_MF_BL_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_Date(bldg.CPE_MF_BL_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
'PCIO' AS SOURCE_SYSTEM,
'COPOccupancyClass' AS CVRBL_TYPE_CD,
cast(bldg.CPE_MF_BL_SEQ_NUM2 as int) AS OCCPNCY_NO, 
case when 
bldg.CPE_BL_OCCUP_GROUP_CD=1 then "Residential Apartments and Condominiums" 
when  
bldg.CPE_BL_OCCUP_GROUP_CD=2 then "Contractors"  
when      
bldg.CPE_BL_OCCUP_GROUP_CD=3 then "Industrial and Processing"
when 
bldg.CPE_BL_OCCUP_GROUP_CD=4 then "Institutional" 
when     
bldg.CPE_BL_OCCUP_GROUP_CD=5 then "Mercantile"  
when       
bldg.CPE_BL_OCCUP_GROUP_CD=6 then "Motels and Hotels"     
when   
bldg.CPE_BL_OCCUP_GROUP_CD=7 then "Offices"      
when      
bldg.CPE_BL_OCCUP_GROUP_CD=8 then "Service" 
else " "
end as OCCPNCY_CATG,
cast(bldg.CPE_BL_SQUARE_FOOTAGE as int) as AREA_SF,
bldg.CPE_BL_CLASS_CODE AS CL_CD,
bldg.CPE_BL_DESCRIPTION AS CL_DESC,
bldg.CPE_BL_CONST_TYPE AS CONSTR_TYPE_USE,
IF(TO_TIMESTAMP(bldg.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL, TO_TIMESTAMP(bldg.CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(bldg.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL
from global_temp.cop_bldg_micro_batch micro_bldg
inner join  
( SELECT distinct * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A,CPE_MF_BL_PREFIX_B,CPE_MF_BL_POL_BRANCH,CPE_MF_BL_POL_DEC,CPE_MF_BL_POL_NUMBER,CPE_MF_BL_VER_DATE,CPE_MF_BL_SEQ_NUM1,CPE_MF_BL_SEQ_NUM2,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_BL_DATE, CPE_GN_AMEND_NUM)    DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_bldg_micro_batch mb
              on   mb.CPE_MF_BL_PREFIX_A = cop_bldg.CPE_MF_BL_PREFIX_A 
            and mb.CPE_MF_BL_PREFIX_B = cop_bldg.CPE_MF_BL_PREFIX_B 
            and mb.CPE_MF_BL_POL_BRANCH = cop_bldg.CPE_MF_BL_POL_BRANCH 
            and mb.CPE_MF_BL_POL_DEC = cop_bldg.CPE_MF_BL_POL_DEC 
            and mb.CPE_MF_BL_POL_NUMBER = cop_bldg.CPE_MF_BL_POL_NUMBER 
           and mb.CPE_MF_BL_VER_DATE = cop_bldg.CPE_MF_BL_VER_DATE
           and mb.CPE_MF_BL_SEQ_NUM1 = cop_bldg.CPE_MF_BL_SEQ_NUM1
           and mb.CPE_MF_BL_SEQ_NUM2 = cop_bldg.CPE_MF_BL_SEQ_NUM2
           and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_bldg.CPE_GN_CYCLE_DATE is null, 'null', cop_bldg.CPE_GN_CYCLE_DATE) 

              )
  ) WHERE rn = 1  ) bldg
  on
  bldg.CPE_MF_BL_PREFIX_A = micro_bldg.CPE_MF_BL_PREFIX_A 
            and bldg.CPE_MF_BL_PREFIX_B = micro_bldg.CPE_MF_BL_PREFIX_B 
            and bldg.CPE_MF_BL_POL_BRANCH = micro_bldg.CPE_MF_BL_POL_BRANCH 
            and bldg.CPE_MF_BL_POL_DEC = micro_bldg.CPE_MF_BL_POL_DEC 
            and bldg.CPE_MF_BL_POL_NUMBER = micro_bldg.CPE_MF_BL_POL_NUMBER 
           and bldg.CPE_MF_BL_VER_DATE = micro_bldg.CPE_MF_BL_VER_DATE
           and bldg.CPE_MF_BL_SEQ_NUM1 = micro_bldg.CPE_MF_BL_SEQ_NUM1
           and bldg.CPE_MF_BL_SEQ_NUM2 = micro_bldg.CPE_MF_BL_SEQ_NUM2
        and if(bldg.CPE_GN_CYCLE_DATE is null,'null',bldg.CPE_GN_CYCLE_DATE) = if(micro_bldg.CPE_GN_CYCLE_DATE is null, 'null', micro_bldg.CPE_GN_CYCLE_DATE)
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_bldg_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_occ_cl_micro_batch_bldg")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("OCC_CL_KEY","END_EFF_DT"), harmonized_table, "OCC_CL_ID","PCIO-COP")
}
