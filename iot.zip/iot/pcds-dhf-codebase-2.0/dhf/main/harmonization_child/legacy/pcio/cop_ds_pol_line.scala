// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_pol_line(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
SELECT
'PCIO-COP-'||GNRL.CPE_MF_GN_PREFIX_A||GNRL.CPE_MF_GN_PREFIX_B||GNRL.CPE_MF_GN_POL_BRANCH||GNRL.CPE_MF_GN_POL_DEC||GNRL.CPE_MF_GN_POL_NUMBER AS POL_LINE_KEY,
'PCIO-COP-'||GNRL.CPE_MF_GN_PREFIX_A||GNRL.CPE_MF_GN_PREFIX_B||GNRL.CPE_MF_GN_POL_BRANCH||GNRL.CPE_MF_GN_POL_DEC||GNRL.CPE_MF_GN_POL_NUMBER AS POL_KEY,
to_date(GNRL.CPE_MF_GN_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(GNRL.CPE_MF_GN_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
'PCIO' AS SOURCE_SYSTEM,
if(GNRL.CPE_GN_IRPM_CREDIT<>'000','Y','N')  AS IRPM_ELIG_FL,
GNRL.CPE_MF_GN_PREFIX_B AS LEGACY_PREFIXB,
IF(GNRL.CPE_GN_BLANKET_IND='Y','Y','N') AS BLKT_RATED_FL, 
IF (item.CPE_IT_EQ_SUB_LIMIT_IND = 'Y' and (GNRL.CPE_GN_BLANKET_BUILDING = 'Y' OR GNRL.CPE_GN_BLANKET_CONTENTS = 'Y' OR GNRL.CPE_GN_BLANKET_BUS_INCOME = 'Y' OR GNRL.CPE_GN_BLANKET_EXTRA_EXP = 'Y'), 'Y', 'N') AS EQ_SUB_LMT_BLNKT_FL,
IF(TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(gnrl.CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' as PARTITION_VAL

FROM 
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
   {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
             on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(MB.CPE_GN_CYCLE_DATE is null,'null',MB.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cop_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE )
     and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE)
            
             
LEFT JOIN 
(SELECT DISTINCT CPE_MF_IT_PREFIX_A,CPE_MF_IT_PREFIX_B,CPE_MF_IT_POL_BRANCH,CPE_MF_IT_POL_DEC,CPE_MF_IT_POL_NUMBER,CPE_MF_IT_VER_DATE,CPE_MF_IT_POL_EXP_DATE,CPE_IT_EQ_SUB_LIMIT_IND,CPE_GN_CYCLE_DATE  
FROM 
 ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IT_PREFIX_A, CPE_MF_IT_PREFIX_B, CPE_MF_IT_POL_BRANCH, CPE_MF_IT_POL_DEC, CPE_MF_IT_POL_NUMBER, CPE_MF_IT_VER_DATE,  CPE_MF_IT_SEQ_NUM2, CPE_MF_IT_SEQ_NUM1, CPE_MF_IT_SEQ_NUM3,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_IT_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_item.*
   from
   {rawDB}.cop_item
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
          mb.CPE_MF_GN_PREFIX_A = cop_item.CPE_MF_IT_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_item.CPE_MF_IT_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_item.CPE_MF_IT_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_item.CPE_MF_IT_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_item.CPE_MF_IT_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_item.CPE_MF_IT_VER_DATE
 and if(MB.CPE_GN_CYCLE_DATE is null,'null',MB.CPE_GN_CYCLE_DATE) = if(cop_item.CPE_GN_CYCLE_DATE is null, 'null', cop_item.CPE_GN_CYCLE_DATE)
                       

              )
  ) WHERE rn = 1  )          
WHERE CPE_IT_EQ_SUB_LIMIT_IND='Y')  ITEM 
ON
TRIM(gnrl.CPE_MF_GN_PREFIX_A)=TRIM(item.CPE_MF_IT_PREFIX_A) and
gnrl.CPE_MF_GN_PREFIX_B=item.CPE_MF_IT_PREFIX_B and
gnrl.CPE_MF_GN_POL_BRANCH=item.CPE_MF_IT_POL_BRANCH and
gnrl.CPE_MF_GN_POL_DEC=item.CPE_MF_IT_POL_DEC and
gnrl.CPE_MF_GN_POL_NUMBER=item.CPE_MF_IT_POL_NUMBER and
gnrl.CPE_MF_GN_VER_DATE=item.CPE_MF_IT_VER_DATE and
gnrl.CPE_MF_GN_POL_EXP_DATE=item.CPE_MF_IT_POL_EXP_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(item.CPE_GN_CYCLE_DATE is null, 'null', item.CPE_GN_CYCLE_DATE)
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_geo_bceg_micro_batch_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("POL_LINE_KEY","END_EFF_DT"), harmonized_table, "POL_LINE_ID","PCIO-COP")
}
