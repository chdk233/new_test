// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_form(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 


SELECT   
   
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-LOC-'||CPE_MF_LC_SEQ_NUM1||'-'||CPE_LC_FORM_NUMBER||'-'||CPE_LC_FORM_EDTN_DATE||'-'||CPE_LC_RATE_STATE AS FORM_KEY, 
'PCIO-COP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER AS POL_KEY,
to_date(CPE_MF_LC_VER_DATE,'yyyyDDD') AS END_EFF_DT,
to_date(CPE_MF_LC_POL_EXP_DATE,'yyyyDDD')  AS END_EXP_DT,
IF(TO_TIMESTAMP(CPE_GN_CYCLE_DATE_loc,'yyyyDDD') IS NULL, TO_TIMESTAMP(CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE_loc,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
CPE_LC_FORM_NUMBER AS FORM_NO, 
NULL AS END_NO, 
CPE_LC_FORM_EDTN_DATE AS EDITION,
CPE_LC_RATE_STATE as FORM_STATE_CD,
' ' as FORM_VAR_INFO,
'PCIO-COP' as PARTITION_VAL
FROM 
(SELECT *, loc.CPE_GN_CYCLE_DATE as CPE_GN_CYCLE_DATE_loc,
STACK(30,CPE_LC_FORM_NUMBER_1,CPE_LC_FORM_EDTN_DATE_1,
         CPE_LC_FORM_NUMBER_2,CPE_LC_FORM_EDTN_DATE_2,
         CPE_LC_FORM_NUMBER_3,CPE_LC_FORM_EDTN_DATE_3,
         CPE_LC_FORM_NUMBER_4,CPE_LC_FORM_EDTN_DATE_4,
         CPE_LC_FORM_NUMBER_5,CPE_LC_FORM_EDTN_DATE_5,
         CPE_LC_FORM_NUMBER_6,CPE_LC_FORM_EDTN_DATE_6,
         CPE_LC_FORM_NUMBER_7,CPE_LC_FORM_EDTN_DATE_7,
         CPE_LC_FORM_NUMBER_8,CPE_LC_FORM_EDTN_DATE_8,
         CPE_LC_FORM_NUMBER_9,CPE_LC_FORM_EDTN_DATE_9,
         CPE_LC_FORM_NUMBER_10,CPE_LC_FORM_EDTN_DATE_10,
         CPE_LC_FORM_NUMBER_11,CPE_LC_FORM_EDTN_DATE_11,
         CPE_LC_FORM_NUMBER_12,CPE_LC_FORM_EDTN_DATE_12,
         CPE_LC_FORM_NUMBER_13,CPE_LC_FORM_EDTN_DATE_13,
         CPE_LC_FORM_NUMBER_14,CPE_LC_FORM_EDTN_DATE_14,
         CPE_LC_FORM_NUMBER_15,CPE_LC_FORM_EDTN_DATE_15,
         CPE_LC_FORM_NUMBER_16,CPE_LC_FORM_EDTN_DATE_16,
         CPE_LC_FORM_NUMBER_17,CPE_LC_FORM_EDTN_DATE_17,
         CPE_LC_FORM_NUMBER_18,CPE_LC_FORM_EDTN_DATE_18,
         CPE_LC_FORM_NUMBER_19,CPE_LC_FORM_EDTN_DATE_19,
         CPE_LC_FORM_NUMBER_20,CPE_LC_FORM_EDTN_DATE_20,
         CPE_LC_FORM_NUMBER_21,CPE_LC_FORM_EDTN_DATE_21,
         CPE_LC_FORM_NUMBER_22,CPE_LC_FORM_EDTN_DATE_22,
         CPE_LC_FORM_NUMBER_23,CPE_LC_FORM_EDTN_DATE_23,
         CPE_LC_FORM_NUMBER_24,CPE_LC_FORM_EDTN_DATE_24,
         CPE_LC_FORM_NUMBER_25,CPE_LC_FORM_EDTN_DATE_25,
         CPE_LC_FORM_NUMBER_26,CPE_LC_FORM_EDTN_DATE_26,
         CPE_LC_FORM_NUMBER_27,CPE_LC_FORM_EDTN_DATE_27,
         CPE_LC_FORM_NUMBER_28,CPE_LC_FORM_EDTN_DATE_28,
         CPE_LC_FORM_NUMBER_29,CPE_LC_FORM_EDTN_DATE_29,
         CPE_LC_FORM_NUMBER_30,CPE_LC_FORM_EDTN_DATE_30)
         AS (CPE_LC_FORM_NUMBER,CPE_LC_FORM_EDTN_DATE)         
FROM  
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
  ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
  {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cop_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE )
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE)
            
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_LC_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
           mb.CPE_MF_GN_PREFIX_A = cop_location.CPE_MF_LC_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_location.CPE_MF_LC_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_location.CPE_GN_CYCLE_DATE is null, 'null', cop_location.CPE_GN_CYCLE_DATE)         

              )
  ) WHERE rn = 1  )          
  )loc

on

(gnrl.CPE_MF_GN_PREFIX_A = loc.CPE_MF_LC_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = loc.CPE_MF_LC_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = loc.CPE_MF_LC_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = loc.CPE_MF_LC_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = loc.CPE_MF_LC_POL_NUMBER
and gnrl.CPE_MF_GN_VER_DATE = loc.CPE_MF_LC_VER_DATE
and if(loc.CPE_GN_CYCLE_DATE is null,'null',loc.CPE_GN_CYCLE_DATE) = if(gnrl.CPE_GN_CYCLE_DATE is null, 'null', gnrl.CPE_GN_CYCLE_DATE)
)

)where  trim(CPE_lc_FORM_NUMBER)!='' and cast(CPE_lc_FORM_EDTN_DATE as int)!='0'

union all


SELECT   
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B|| CPE_MF_BL_POL_BRANCH|| CPE_MF_BL_POL_DEC|| CPE_MF_BL_POL_NUMBER||'-BLDG-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2||'-'||CPE_BL_FORM_NUMBER||'-'||CPE_BL_FORM_EDTN_DATE||'-'||CPE_LC_RATE_STATE  AS FORM_KEY,
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B|| CPE_MF_BL_POL_BRANCH|| CPE_MF_BL_POL_DEC|| CPE_MF_BL_POL_NUMBER AS POL_KEY,
to_date(CPE_MF_BL_VER_DATE,'yyyyDDD') as END_EFF_DT,
TO_DATE(CPE_MF_BL_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
IF(TO_TIMESTAMP(CPE_GN_CYCLE_DATE_bldg,'yyyyDDD') IS NULL, TO_TIMESTAMP(CPE_MF_BL_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE_bldg,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
CPE_BL_FORM_NUMBER AS FORM_NO, 
NULL AS END_NO, 
CPE_BL_FORM_EDTN_DATE AS EDITION, 
CPE_LC_RATE_STATE  as FORM_STATE_CD,
' ' as FORM_VAR_INFO,
'PCIO-COP' as PARTITION_VAL
FROM 
(SELECT *,bldg.CPE_GN_CYCLE_DATE as CPE_GN_CYCLE_DATE_bldg,
STACK(30,CPE_BL_FORM_NUMBER_1,CPE_BL_FORM_EDTN_DATE_1,
         CPE_BL_FORM_NUMBER_2,CPE_BL_FORM_EDTN_DATE_2,
         CPE_BL_FORM_NUMBER_3,CPE_BL_FORM_EDTN_DATE_3,
         CPE_BL_FORM_NUMBER_4,CPE_BL_FORM_EDTN_DATE_4,
         CPE_BL_FORM_NUMBER_5,CPE_BL_FORM_EDTN_DATE_5,
         CPE_BL_FORM_NUMBER_6,CPE_BL_FORM_EDTN_DATE_6,
         CPE_BL_FORM_NUMBER_7,CPE_BL_FORM_EDTN_DATE_7,
         CPE_BL_FORM_NUMBER_8,CPE_BL_FORM_EDTN_DATE_8,
         CPE_BL_FORM_NUMBER_9,CPE_BL_FORM_EDTN_DATE_9,
         CPE_BL_FORM_NUMBER_10,CPE_BL_FORM_EDTN_DATE_10,
         CPE_BL_FORM_NUMBER_11,CPE_BL_FORM_EDTN_DATE_11,
         CPE_BL_FORM_NUMBER_12,CPE_BL_FORM_EDTN_DATE_12,
         CPE_BL_FORM_NUMBER_13,CPE_BL_FORM_EDTN_DATE_13,
         CPE_BL_FORM_NUMBER_14,CPE_BL_FORM_EDTN_DATE_14,
         CPE_BL_FORM_NUMBER_15,CPE_BL_FORM_EDTN_DATE_15,
         CPE_BL_FORM_NUMBER_16,CPE_BL_FORM_EDTN_DATE_16,
         CPE_BL_FORM_NUMBER_17,CPE_BL_FORM_EDTN_DATE_17,
         CPE_BL_FORM_NUMBER_18,CPE_BL_FORM_EDTN_DATE_18,
         CPE_BL_FORM_NUMBER_19,CPE_BL_FORM_EDTN_DATE_19,
         CPE_BL_FORM_NUMBER_20,CPE_BL_FORM_EDTN_DATE_20,
         CPE_BL_FORM_NUMBER_21,CPE_BL_FORM_EDTN_DATE_21,
         CPE_BL_FORM_NUMBER_22,CPE_BL_FORM_EDTN_DATE_22,
         CPE_BL_FORM_NUMBER_23,CPE_BL_FORM_EDTN_DATE_23,
         CPE_BL_FORM_NUMBER_24,CPE_BL_FORM_EDTN_DATE_24,
         CPE_BL_FORM_NUMBER_25,CPE_BL_FORM_EDTN_DATE_25,
         CPE_BL_FORM_NUMBER_26,CPE_BL_FORM_EDTN_DATE_26,
         CPE_BL_FORM_NUMBER_27,CPE_BL_FORM_EDTN_DATE_27,
         CPE_BL_FORM_NUMBER_28,CPE_BL_FORM_EDTN_DATE_28,
         CPE_BL_FORM_NUMBER_29,CPE_BL_FORM_EDTN_DATE_29,
         CPE_BL_FORM_NUMBER_30,CPE_BL_FORM_EDTN_DATE_30)
         AS (CPE_BL_FORM_NUMBER,CPE_BL_FORM_EDTN_DATE)        
FROM  
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
  {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cop_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
     
            
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A, CPE_MF_BL_PREFIX_B, CPE_MF_BL_POL_BRANCH, CPE_MF_BL_POL_DEC, CPE_MF_BL_POL_NUMBER, CPE_MF_BL_VER_DATE,  CPE_MF_BL_SEQ_NUM1, CPE_MF_BL_SEQ_NUM2, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_BL_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
          mb.CPE_MF_GN_PREFIX_A = cop_bldg.CPE_MF_BL_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_bldg.CPE_MF_BL_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_bldg.CPE_MF_BL_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_bldg.CPE_MF_BL_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_bldg.CPE_MF_BL_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_bldg.CPE_MF_BL_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_bldg.CPE_GN_CYCLE_DATE is null, 'null', cop_bldg.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )          
  )bldg

on

(gnrl.CPE_MF_GN_PREFIX_A = bldg.CPE_MF_BL_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = bldg.CPE_MF_BL_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = bldg.CPE_MF_BL_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = bldg.CPE_MF_BL_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = bldg.CPE_MF_BL_POL_NUMBER
and gnrl.CPE_MF_GN_VER_DATE = bldg.CPE_MF_BL_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(bldg.CPE_GN_CYCLE_DATE is null, 'null', bldg.CPE_GN_CYCLE_DATE)
)
  
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_LC_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
         mb.CPE_MF_GN_PREFIX_A = cop_location.CPE_MF_LC_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_location.CPE_MF_LC_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_location.CPE_GN_CYCLE_DATE is null, 'null', cop_location.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )          
  )loc
ON
TRIM(CPE_MF_LC_PREFIX_A)=TRIM(CPE_MF_BL_PREFIX_A) AND
CPE_MF_LC_PREFIX_B=CPE_MF_BL_PREFIX_B AND
CPE_MF_LC_POL_BRANCH=CPE_MF_BL_POL_BRANCH AND
CPE_MF_LC_POL_DEC=CPE_MF_BL_POL_DEC AND
CPE_MF_LC_POL_NUMBER=CPE_MF_BL_POL_NUMBER AND
CPE_MF_LC_VER_DATE=CPE_MF_BL_VER_DATE AND
CPE_MF_LC_POL_EXP_DATE=CPE_MF_BL_POL_EXP_DATE AND
CPE_MF_LC_SEQ_NUM1=CPE_MF_BL_SEQ_NUM1
and if(loc.CPE_GN_CYCLE_DATE is null,'null',loc.CPE_GN_CYCLE_DATE) = if(bldg.CPE_GN_CYCLE_DATE is null, 'null', bldg.CPE_GN_CYCLE_DATE)
)where  trim(CPE_BL_FORM_NUMBER)!='' and cast(CPE_BL_FORM_EDTN_DATE as int)!='0'

union all

SELECT   
'PCIO-COP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER||'-ITEM-'||CPE_MF_IT_SEQ_NUM1||'-'||CPE_MF_IT_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3||'-'||CPE_IT_FORM_NUMBER||'-'||CPE_IT_FORM_EDTN_DATE||'-'||CPE_LC_RATE_STATE AS FORM_KEY ,
'PCIO-COP-'||CPE_MF_IT_PREFIX_A||CPE_MF_IT_PREFIX_B||CPE_MF_IT_POL_BRANCH||CPE_MF_IT_POL_DEC||CPE_MF_IT_POL_NUMBER AS POL_KEY,
to_date(CPE_MF_IT_VER_DATE,'yyyyDDD') AS END_EFF_DT,
to_date(CPE_MF_IT_POL_EXP_DATE,'yyyyDDD')  AS END_EXP_DT,
IF(TO_TIMESTAMP(CPE_GN_CYCLE_DATE_item,'yyyyDDD') IS NULL, TO_TIMESTAMP(CPE_MF_IT_DATE,'yyyyDDD'), TO_TIMESTAMP(CPE_GN_CYCLE_DATE_item,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
CPE_IT_FORM_NUMBER AS FORM_NO, 
NULL AS END_NO,
CPE_IT_FORM_EDTN_DATE  AS EDITION,
CPE_LC_RATE_STATE  as FORM_STATE_CD,
' '  as FORM_VAR_INFO,
'PCIO-COP' as PARTITION_VAL
FROM 
(SELECT *,item.CPE_GN_CYCLE_DATE as CPE_GN_CYCLE_DATE_item,
STACK(30,CPE_IT_FORM_NUMBER_1,CPE_IT_FORM_EDTN_DATE_1,
         CPE_IT_FORM_NUMBER_2,CPE_IT_FORM_EDTN_DATE_2,
         CPE_IT_FORM_NUMBER_3,CPE_IT_FORM_EDTN_DATE_3,
         CPE_IT_FORM_NUMBER_4,CPE_IT_FORM_EDTN_DATE_4,
         CPE_IT_FORM_NUMBER_5,CPE_IT_FORM_EDTN_DATE_5,
         CPE_IT_FORM_NUMBER_6,CPE_IT_FORM_EDTN_DATE_6,
         CPE_IT_FORM_NUMBER_7,CPE_IT_FORM_EDTN_DATE_7,
         CPE_IT_FORM_NUMBER_8,CPE_IT_FORM_EDTN_DATE_8,
         CPE_IT_FORM_NUMBER_9,CPE_IT_FORM_EDTN_DATE_9,
         CPE_IT_FORM_NUMBER_10,CPE_IT_FORM_EDTN_DATE_10,
         CPE_IT_FORM_NUMBER_11,CPE_IT_FORM_EDTN_DATE_11,
         CPE_IT_FORM_NUMBER_12,CPE_IT_FORM_EDTN_DATE_12,
         CPE_IT_FORM_NUMBER_13,CPE_IT_FORM_EDTN_DATE_13,
         CPE_IT_FORM_NUMBER_14,CPE_IT_FORM_EDTN_DATE_14,
         CPE_IT_FORM_NUMBER_15,CPE_IT_FORM_EDTN_DATE_15,
         CPE_IT_FORM_NUMBER_16,CPE_IT_FORM_EDTN_DATE_16,
         CPE_IT_FORM_NUMBER_17,CPE_IT_FORM_EDTN_DATE_17,
         CPE_IT_FORM_NUMBER_18,CPE_IT_FORM_EDTN_DATE_18,
         CPE_IT_FORM_NUMBER_19,CPE_IT_FORM_EDTN_DATE_19,
         CPE_IT_FORM_NUMBER_20,CPE_IT_FORM_EDTN_DATE_20,
         CPE_IT_FORM_NUMBER_21,CPE_IT_FORM_EDTN_DATE_21,
         CPE_IT_FORM_NUMBER_22,CPE_IT_FORM_EDTN_DATE_22,
         CPE_IT_FORM_NUMBER_23,CPE_IT_FORM_EDTN_DATE_23,
         CPE_IT_FORM_NUMBER_24,CPE_IT_FORM_EDTN_DATE_24,
         CPE_IT_FORM_NUMBER_25,CPE_IT_FORM_EDTN_DATE_25,
         CPE_IT_FORM_NUMBER_26,CPE_IT_FORM_EDTN_DATE_26,
         CPE_IT_FORM_NUMBER_27,CPE_IT_FORM_EDTN_DATE_27,
         CPE_IT_FORM_NUMBER_28,CPE_IT_FORM_EDTN_DATE_28,
         CPE_IT_FORM_NUMBER_29,CPE_IT_FORM_EDTN_DATE_29,
         CPE_IT_FORM_NUMBER_30,CPE_IT_FORM_EDTN_DATE_30)
         AS (CPE_IT_FORM_NUMBER,CPE_IT_FORM_EDTN_DATE)

FROM  
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
  ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
  {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
--               where cop_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
            
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IT_PREFIX_A, CPE_MF_IT_PREFIX_B, CPE_MF_IT_POL_BRANCH, CPE_MF_IT_POL_DEC, CPE_MF_IT_POL_NUMBER, CPE_MF_IT_VER_DATE,  CPE_MF_IT_SEQ_NUM2, CPE_MF_IT_SEQ_NUM1, CPE_MF_IT_SEQ_NUM3, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_IT_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_item.*
   from
   {rawDB}.cop_item
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
          mb.CPE_MF_GN_PREFIX_A = cop_item.CPE_MF_IT_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_item.CPE_MF_IT_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_item.CPE_MF_IT_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_item.CPE_MF_IT_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_item.CPE_MF_IT_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_item.CPE_MF_IT_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_item.CPE_GN_CYCLE_DATE is null, 'null', cop_item.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )          
  )item

on

(gnrl.CPE_MF_GN_PREFIX_A = item.CPE_MF_IT_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = item.CPE_MF_IT_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = item.CPE_MF_IT_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = item.CPE_MF_IT_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = item.CPE_MF_IT_POL_NUMBER
and gnrl.CPE_MF_GN_VER_DATE = item.CPE_MF_IT_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(item.CPE_GN_CYCLE_DATE is null, 'null', item.CPE_GN_CYCLE_DATE)
)
  
inner join 
(select * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_LC_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
   {rawDB}.cop_location
   inner join global_temp.cop_gnrl_micro_batch mb
   
              on  
          mb.CPE_MF_GN_PREFIX_A = cop_location.CPE_MF_LC_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_location.CPE_MF_LC_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_location.CPE_GN_CYCLE_DATE is null, 'null', cop_location.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )          
  )loc
ON
TRIM(CPE_MF_LC_PREFIX_A)=TRIM(CPE_MF_IT_PREFIX_A) AND
CPE_MF_LC_PREFIX_B=CPE_MF_IT_PREFIX_B AND
CPE_MF_LC_POL_BRANCH=CPE_MF_IT_POL_BRANCH AND
CPE_MF_LC_POL_DEC=CPE_MF_IT_POL_DEC AND
CPE_MF_LC_POL_NUMBER=CPE_MF_IT_POL_NUMBER AND
CPE_MF_LC_VER_DATE=CPE_MF_IT_VER_DATE AND
CPE_MF_LC_POL_EXP_DATE=CPE_MF_IT_POL_EXP_DATE AND
CPE_MF_LC_SEQ_NUM1=CPE_MF_IT_SEQ_NUM1
and if(loc.CPE_GN_CYCLE_DATE is null,'null',loc.CPE_GN_CYCLE_DATE) = if(item.CPE_GN_CYCLE_DATE is null, 'null', item.CPE_GN_CYCLE_DATE)
)where  trim(CPE_IT_FORM_NUMBER)!='' and cast(CPE_IT_FORM_EDTN_DATE as int)!='0'

union all

select 
'PCIO-COP-'||CPE_MF_GN_PREFIX_A||CPE_MF_GN_PREFIX_B||CPE_MF_GN_POL_BRANCH||CPE_MF_GN_POL_DEC||CPE_MF_GN_POL_NUMBER||'-GN-'||CPE_GN_FORM_NUMBER||'-'||CPE_GN_FORM_EDTN_DATE||'-'||CPE_GN_STATE as FORM_KEY,
'PCIO-COP-'||CPE_MF_GN_PREFIX_A||CPE_MF_GN_PREFIX_B||CPE_MF_GN_POL_BRANCH||CPE_MF_GN_POL_DEC||CPE_MF_GN_POL_NUMBER AS POL_KEY,
to_date(CPE_MF_GN_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(CPE_MF_GN_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
IF(TO_TIMESTAMP(gn.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL, TO_TIMESTAMP(CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(gn.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
CPE_GN_FORM_NUMBER AS FORM_NO,
NULL AS END_NO,
CPE_GN_FORM_EDTN_DATE AS EDITION,
CPE_GN_STATE AS FORM_STATE_CD,
' ' AS FORM_VAR_INFO,
'PCIO-COP' as PARTITION_VAL
FROM 
(SELECT gnrl.*,
STACK(30,gnrl.CPE_GN_FORM_NUMBER_1,gnrl.CPE_GN_FORM_EDTN_DATE_1,
         gnrl.CPE_GN_FORM_NUMBER_2,gnrl.CPE_GN_FORM_EDTN_DATE_2,
         gnrl.CPE_GN_FORM_NUMBER_3,gnrl.CPE_GN_FORM_EDTN_DATE_3,
         gnrl.CPE_GN_FORM_NUMBER_4,gnrl.CPE_GN_FORM_EDTN_DATE_4,
         gnrl.CPE_GN_FORM_NUMBER_5,gnrl.CPE_GN_FORM_EDTN_DATE_5,
         gnrl.CPE_GN_FORM_NUMBER_6,gnrl.CPE_GN_FORM_EDTN_DATE_6,
         gnrl.CPE_GN_FORM_NUMBER_7,gnrl.CPE_GN_FORM_EDTN_DATE_7,
         gnrl.CPE_GN_FORM_NUMBER_8,gnrl.CPE_GN_FORM_EDTN_DATE_8,
         gnrl.CPE_GN_FORM_NUMBER_9,gnrl.CPE_GN_FORM_EDTN_DATE_9,
         gnrl.CPE_GN_FORM_NUMBER_10,gnrl.CPE_GN_FORM_EDTN_DATE_10,
         gnrl.CPE_GN_FORM_NUMBER_11,gnrl.CPE_GN_FORM_EDTN_DATE_11,
         gnrl.CPE_GN_FORM_NUMBER_12,gnrl.CPE_GN_FORM_EDTN_DATE_12,
         gnrl.CPE_GN_FORM_NUMBER_13,gnrl.CPE_GN_FORM_EDTN_DATE_13,
         gnrl.CPE_GN_FORM_NUMBER_14,gnrl.CPE_GN_FORM_EDTN_DATE_14,
         gnrl.CPE_GN_FORM_NUMBER_15,gnrl.CPE_GN_FORM_EDTN_DATE_15,
         gnrl.CPE_GN_FORM_NUMBER_16,gnrl.CPE_GN_FORM_EDTN_DATE_16,
         gnrl.CPE_GN_FORM_NUMBER_17,gnrl.CPE_GN_FORM_EDTN_DATE_17,
         gnrl.CPE_GN_FORM_NUMBER_18,gnrl.CPE_GN_FORM_EDTN_DATE_18,
         gnrl.CPE_GN_FORM_NUMBER_19,gnrl.CPE_GN_FORM_EDTN_DATE_19,
         gnrl.CPE_GN_FORM_NUMBER_20,gnrl.CPE_GN_FORM_EDTN_DATE_20,
         gnrl.CPE_GN_FORM_NUMBER_21,gnrl.CPE_GN_FORM_EDTN_DATE_21,
         gnrl.CPE_GN_FORM_NUMBER_22,gnrl.CPE_GN_FORM_EDTN_DATE_22,
         gnrl.CPE_GN_FORM_NUMBER_23,gnrl.CPE_GN_FORM_EDTN_DATE_23,
         gnrl.CPE_GN_FORM_NUMBER_24,gnrl.CPE_GN_FORM_EDTN_DATE_24,
         gnrl.CPE_GN_FORM_NUMBER_25,gnrl.CPE_GN_FORM_EDTN_DATE_25,
         gnrl.CPE_GN_FORM_NUMBER_26,gnrl.CPE_GN_FORM_EDTN_DATE_26,
         gnrl.CPE_GN_FORM_NUMBER_27,gnrl.CPE_GN_FORM_EDTN_DATE_27,
         gnrl.CPE_GN_FORM_NUMBER_28,gnrl.CPE_GN_FORM_EDTN_DATE_28,
         gnrl.CPE_GN_FORM_NUMBER_29,gnrl.CPE_GN_FORM_EDTN_DATE_29,
         gnrl.CPE_GN_FORM_NUMBER_30,gnrl.CPE_GN_FORM_EDTN_DATE_30)
         AS (CPE_GN_FORM_NUMBER,CPE_GN_FORM_EDTN_DATE)        
FROM  
global_temp.cop_gnrl_micro_batch micro_gnrl
   inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
  {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)
            
--               where cop_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )          
   gnrl
              on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE)))gn

where  trim(CPE_GN_FORM_NUMBER)!='' and cast(CPE_GN_FORM_EDTN_DATE as int)!='0' --GNRL

union all

SELECT 
'PCIO-COP-'||CPE_MF_EF_PREFIX_A||CPE_MF_EF_PREFIX_B||CPE_MF_EF_POL_BRANCH||CPE_MF_EF_POL_DEC||CPE_MF_EF_POL_NUMBER||'-'||CPE_EF_END_NBR||'-'||CPE_EF_ED_DATE||'-'||CPE_EF_VER_NBR||'-'||CPE_EF_STATE as FORM_KEY,
'PCIO-COP-'||CPE_MF_EF_PREFIX_A||CPE_MF_EF_PREFIX_B||CPE_MF_EF_POL_BRANCH||CPE_MF_EF_POL_DEC||CPE_MF_EF_POL_NUMBER AS POL_KEY,
to_date(CPE_MF_EF_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(CPE_MF_EF_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,

IF(TO_TIMESTAMP(form.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL, TO_TIMESTAMP(CPE_MF_EF_DATE,'yyyyDDD'), TO_TIMESTAMP(form.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
CPE_EF_END_NBR AS FORM_NO,
CPE_EF_VER_NBR AS END_NO,
CPE_EF_ED_DATE AS EDITION,
CPE_EF_STATE AS FORM_STATE_CD,
ifnull(VAR1,'')||ifnull(VAR2,'')||ifnull(VAR3,'')||ifnull(VAR4,'') AS FORM_VAR_INFO,
'PCIO-COP' as PARTITION_VAL
FROM 
(select a.*,B.CPE_EF_VAR_DATA AS VAR1 ,C.CPE_EF_VAR_DATA AS VAR2,D.CPE_EF_VAR_DATA AS VAR3,E.CPE_EF_VAR_DATA AS VAR4
FROM 
global_temp.cop_gnrl_micro_batch micro_gnrl
INNER JOIN ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_gnrl.*
   from
   {rawDB}.cop_gnrl
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cop_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cop_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cop_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cop_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cop_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cop_gnrl.CPE_GN_CYCLE_DATE)

              )
  ) WHERE rn = 1  )          
   gnrl ON(
    gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
  
inner join
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_EF_PREFIX_A, CPE_MF_EF_PREFIX_B, CPE_MF_EF_POL_BRANCH, CPE_MF_EF_POL_DEC, CPE_MF_EF_POL_NUMBER,CPE_EF_END_NBR,CPE_MF_EF_VER_DATE,CPE_MF_EF_ITM_TYPE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_EF_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_form.*
   from
   {rawDB}.cop_form
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_form.CPE_MF_EF_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_form.CPE_MF_EF_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_form.CPE_MF_EF_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_form.CPE_MF_EF_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_form.CPE_MF_EF_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_form.CPE_MF_EF_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_form.CPE_GN_CYCLE_DATE is null, 'null', cop_form.CPE_GN_CYCLE_DATE)           

              )
  ) WHERE rn = 1  )          
   a
  
on 
gnrl.CPE_MF_GN_PREFIX_A = CPE_MF_EF_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = CPE_MF_EF_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = CPE_MF_EF_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = CPE_MF_EF_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = CPE_MF_EF_POL_NUMBER
and gnrl.CPE_MF_GN_VER_DATE = CPE_MF_EF_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(a.CPE_GN_CYCLE_DATE is null, 'null', a.CPE_GN_CYCLE_DATE)

LEFT join
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_EF_PREFIX_A, CPE_MF_EF_PREFIX_B, CPE_MF_EF_POL_BRANCH, CPE_MF_EF_POL_DEC, CPE_MF_EF_POL_NUMBER,CPE_EF_END_NBR,CPE_MF_EF_VER_DATE,CPE_MF_EF_ITM_TYPE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_EF_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_form.*
   from
   {rawDB}.cop_form
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_form.CPE_MF_EF_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_form.CPE_MF_EF_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_form.CPE_MF_EF_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_form.CPE_MF_EF_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_form.CPE_MF_EF_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_form.CPE_MF_EF_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_form.CPE_GN_CYCLE_DATE is null, 'null', cop_form.CPE_GN_CYCLE_DATE)           

              )
  ) WHERE rn = 1  )          
   b

on
a.CPE_MF_EF_PREFIX_A=b.CPE_MF_EF_PREFIX_A and 
a.CPE_MF_EF_PREFIX_B=b.CPE_MF_EF_PREFIX_B and 
a.CPE_MF_EF_POL_BRANCH=b.CPE_MF_EF_POL_BRANCH and 
a.CPE_MF_EF_POL_DEC=b.CPE_MF_EF_POL_DEC and 
a.CPE_MF_EF_POL_NUMBER=b.CPE_MF_EF_POL_NUMBER and 
a.CPE_EF_END_NBR=b.CPE_EF_END_NBR and
a.CPE_EF_VER_NBR=b.CPE_EF_VER_NBR and
a.CPE_EF_ED_DATE=b.CPE_EF_ED_DATE and
a.CPE_EF_STATE=b.CPE_EF_STATE and
a.CPE_MF_EF_VER_DATE=b.CPE_MF_EF_VER_DATE 
and a.CPE_MF_EF_POL_EXP_DATE=b.CPE_MF_EF_POL_EXP_DATE
and if(a.CPE_GN_CYCLE_DATE is null,'null',a.CPE_GN_CYCLE_DATE) = if(B.CPE_GN_CYCLE_DATE is null, 'null', B.CPE_GN_CYCLE_DATE)
and b.CPE_MF_EF_ITM_TYPE=' '

LEFT JOIN
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_EF_PREFIX_A, CPE_MF_EF_PREFIX_B, CPE_MF_EF_POL_BRANCH, CPE_MF_EF_POL_DEC, CPE_MF_EF_POL_NUMBER,CPE_EF_END_NBR,CPE_MF_EF_VER_DATE,CPE_MF_EF_ITM_TYPE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_EF_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_form.*
   from
   {rawDB}.cop_form
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_form.CPE_MF_EF_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_form.CPE_MF_EF_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_form.CPE_MF_EF_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_form.CPE_MF_EF_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_form.CPE_MF_EF_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_form.CPE_MF_EF_VER_DATE
 and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_form.CPE_GN_CYCLE_DATE is null, 'null', cop_form.CPE_GN_CYCLE_DATE)          

              )
  ) WHERE rn = 1  )          
   c

on
a.CPE_MF_EF_PREFIX_A=C.CPE_MF_EF_PREFIX_A and 
a.CPE_MF_EF_PREFIX_B=C.CPE_MF_EF_PREFIX_B and 
a.CPE_MF_EF_POL_BRANCH=C.CPE_MF_EF_POL_BRANCH and 
a.CPE_MF_EF_POL_DEC=C.CPE_MF_EF_POL_DEC and 
a.CPE_MF_EF_POL_NUMBER=C.CPE_MF_EF_POL_NUMBER and 
a.CPE_EF_END_NBR=C.CPE_EF_END_NBR and
a.CPE_EF_VER_NBR=C.CPE_EF_VER_NBR and
a.CPE_EF_ED_DATE=C.CPE_EF_ED_DATE and
a.CPE_EF_STATE=C.CPE_EF_STATE and
a.CPE_MF_EF_VER_DATE=C.CPE_MF_EF_VER_DATE 
and a.CPE_MF_EF_POL_EXP_DATE=C.CPE_MF_EF_POL_EXP_DATE
and if(a.CPE_GN_CYCLE_DATE is null,'null',a.CPE_GN_CYCLE_DATE) = if(C.CPE_GN_CYCLE_DATE is null, 'null', C.CPE_GN_CYCLE_DATE)
and c.CPE_MF_EF_ITM_TYPE='1'

LEFT JOIN
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_EF_PREFIX_A, CPE_MF_EF_PREFIX_B, CPE_MF_EF_POL_BRANCH, CPE_MF_EF_POL_DEC, CPE_MF_EF_POL_NUMBER,CPE_EF_END_NBR,CPE_MF_EF_VER_DATE,CPE_MF_EF_ITM_TYPE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_EF_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_form.*
   from
   {rawDB}.cop_form
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_form.CPE_MF_EF_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_form.CPE_MF_EF_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_form.CPE_MF_EF_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_form.CPE_MF_EF_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_form.CPE_MF_EF_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_form.CPE_MF_EF_VER_DATE
 and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_form.CPE_GN_CYCLE_DATE is null, 'null', cop_form.CPE_GN_CYCLE_DATE)          

              )
  ) WHERE rn = 1  )          
   d

on
a.CPE_MF_EF_PREFIX_A=D.CPE_MF_EF_PREFIX_A and 
a.CPE_MF_EF_PREFIX_B=D.CPE_MF_EF_PREFIX_B and 
a.CPE_MF_EF_POL_BRANCH=D.CPE_MF_EF_POL_BRANCH and 
a.CPE_MF_EF_POL_DEC=D.CPE_MF_EF_POL_DEC and 
a.CPE_MF_EF_POL_NUMBER=D.CPE_MF_EF_POL_NUMBER and 
a.CPE_EF_END_NBR=D.CPE_EF_END_NBR and
a.CPE_EF_VER_NBR=D.CPE_EF_VER_NBR and
a.CPE_EF_ED_DATE=D.CPE_EF_ED_DATE and
a.CPE_EF_STATE=D.CPE_EF_STATE and
a.CPE_MF_EF_VER_DATE=D.CPE_MF_EF_VER_DATE 
and if(a.CPE_GN_CYCLE_DATE is null,'null',a.CPE_GN_CYCLE_DATE) = if(D.CPE_GN_CYCLE_DATE is null, 'null', D.CPE_GN_CYCLE_DATE)
and a.CPE_MF_EF_POL_EXP_DATE=D.CPE_MF_EF_POL_EXP_DATE
and d.CPE_MF_EF_ITM_TYPE='2'

LEFT JOIN
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_EF_PREFIX_A, CPE_MF_EF_PREFIX_B, CPE_MF_EF_POL_BRANCH, CPE_MF_EF_POL_DEC, CPE_MF_EF_POL_NUMBER,CPE_EF_END_NBR,CPE_MF_EF_VER_DATE,CPE_MF_EF_ITM_TYPE, CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_EF_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_form.*
   from
   {rawDB}.cop_form
   inner join global_temp.cop_gnrl_micro_batch mb
              on   mb.CPE_MF_GN_PREFIX_A = cop_form.CPE_MF_EF_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cop_form.CPE_MF_EF_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cop_form.CPE_MF_EF_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cop_form.CPE_MF_EF_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cop_form.CPE_MF_EF_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cop_form.CPE_MF_EF_VER_DATE
 and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_form.CPE_GN_CYCLE_DATE is null, 'null', cop_form.CPE_GN_CYCLE_DATE)          

              )
  ) WHERE rn = 1  )          
   e

on
a.CPE_MF_EF_PREFIX_A=E.CPE_MF_EF_PREFIX_A and 
a.CPE_MF_EF_PREFIX_B=E.CPE_MF_EF_PREFIX_B and 
a.CPE_MF_EF_POL_BRANCH=E.CPE_MF_EF_POL_BRANCH and 
a.CPE_MF_EF_POL_DEC=E.CPE_MF_EF_POL_DEC and 
a.CPE_MF_EF_POL_NUMBER=E.CPE_MF_EF_POL_NUMBER and 
a.CPE_EF_END_NBR=E.CPE_EF_END_NBR and
a.CPE_EF_VER_NBR=E.CPE_EF_VER_NBR and
a.CPE_EF_ED_DATE=E.CPE_EF_ED_DATE and
a.CPE_EF_STATE=E.CPE_EF_STATE and
a.CPE_MF_EF_VER_DATE=E.CPE_MF_EF_VER_DATE
and if(a.CPE_GN_CYCLE_DATE is null,'null',a.CPE_GN_CYCLE_DATE) = if(E.CPE_GN_CYCLE_DATE is null, 'null', E.CPE_GN_CYCLE_DATE)
and a.CPE_MF_EF_POL_EXP_DATE=E.CPE_MF_EF_POL_EXP_DATE
and e.CPE_MF_EF_ITM_TYPE='3')form where CPE_MF_EF_ITM_TYPE=' ' --form



"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_form_micro_batch_gnrl")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("FORM_KEY","END_EFF_DT"), harmonized_table, "FORM_ID","PCIO-COP")
}
