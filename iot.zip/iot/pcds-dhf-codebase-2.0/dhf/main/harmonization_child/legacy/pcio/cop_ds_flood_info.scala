// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_flood_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

SELECT 
'PCIO-COP-'|| LOC.CPE_MF_LC_PREFIX_A||LOC.CPE_MF_LC_PREFIX_B||LOC.CPE_MF_LC_POL_BRANCH||LOC.CPE_MF_LC_POL_DEC||LOC.CPE_MF_LC_POL_NUMBER ||'-'||LOC.CPE_MF_LC_SEQ_NUM1 AS FLOOD_INFO_KEY,
'PCIO-COP-'|| LOC.CPE_MF_LC_PREFIX_A||LOC.CPE_MF_LC_PREFIX_B||LOC.CPE_MF_LC_POL_BRANCH||LOC.CPE_MF_LC_POL_DEC||LOC.CPE_MF_LC_POL_NUMBER  AS POL_KEY,
'PCIO-COP-'|| LOC.CPE_MF_LC_PREFIX_A||LOC.CPE_MF_LC_PREFIX_B||LOC.CPE_MF_LC_POL_BRANCH||LOC.CPE_MF_LC_POL_DEC||LOC.CPE_MF_LC_POL_NUMBER ||'-'||LOC.CPE_MF_LC_SEQ_NUM1 AS CVRBL_KEY,
to_date(LOC.CPE_MF_LC_VER_DATE,'yyyyDDD') AS END_EFF_DT,
to_date(LOC.CPE_MF_LC_POL_EXP_DATE,'yyyyDDD') AS END_EXP_DT,
IF(TO_TIMESTAMP(LOC.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(LOC.CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(LOC.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
'COPLOCATION' AS  CVRBL_TYPE_CD,
LOC.CPE_LC_FLOOD_SCORE AS FLOOD_RISK_SCORE,
LOC.CPE_LC_FLOOD_FLASH_SCORE AS FLASH_FLOOD_RISK_SCORE,
LOC.CPE_LC_FLOOD_ZONE AS FLOOD_ZONE,
'PCIO-COP' AS PARTITION_VAL 

FROM global_temp.cop_location_micro_batch MICRO_LOC
INNER JOIN 
(select distinct * from ( SELECT * FROM
  ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_LC_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_location.*
   from
  {rawDB}.cop_location
   inner join global_temp.cop_location_micro_batch mb
              on   mb.CPE_MF_LC_PREFIX_A = cop_location.CPE_MF_LC_PREFIX_A 
            and mb.CPE_MF_LC_PREFIX_B = cop_location.CPE_MF_LC_PREFIX_B 
            and mb.CPE_MF_LC_POL_BRANCH = cop_location.CPE_MF_LC_POL_BRANCH 
            and mb.CPE_MF_LC_POL_DEC = cop_location.CPE_MF_LC_POL_DEC 
            and mb.CPE_MF_LC_POL_NUMBER = cop_location.CPE_MF_LC_POL_NUMBER 
            and mb.CPE_MF_LC_SEQ_NUM1 = cop_location.CPE_MF_LC_SEQ_NUM1 
            and mb.CPE_MF_LC_VER_DATE = cop_location.CPE_MF_LC_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_location.CPE_GN_CYCLE_DATE is null, 'null', cop_location.CPE_GN_CYCLE_DATE)
            
--               where cop_location.loaded_time <= mb.CPE_GN_CYCLE_DATE
              )
  ) WHERE rn = 1  ) )LOC
  ON 
  MICRO_LOC.CPE_MF_LC_PREFIX_A = LOC.CPE_MF_LC_PREFIX_A 
            and MICRO_LOC.CPE_MF_LC_PREFIX_B = LOC.CPE_MF_LC_PREFIX_B 
            and MICRO_LOC.CPE_MF_LC_POL_BRANCH = LOC.CPE_MF_LC_POL_BRANCH 
            and MICRO_LOC.CPE_MF_LC_POL_DEC = LOC.CPE_MF_LC_POL_DEC 
            and MICRO_LOC.CPE_MF_LC_POL_NUMBER = LOC.CPE_MF_LC_POL_NUMBER 
            and MICRO_LOC.CPE_MF_LC_SEQ_NUM1 = LOC.CPE_MF_LC_SEQ_NUM1 
            and MICRO_LOC.CPE_MF_LC_VER_DATE = LOC.CPE_MF_LC_VER_DATE 
            and if(MICRO_LOC.CPE_GN_CYCLE_DATE is null,'null',MICRO_LOC.CPE_GN_CYCLE_DATE) = if(LOC.CPE_GN_CYCLE_DATE is null, 'null', LOC.CPE_GN_CYCLE_DATE)


"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_location_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.wc_dec_micro_batch_flood_info")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("FLOOD_INFO_KEY","END_EFF_DT"), harmonized_table, "FLOOD_INFO_ID","PCIO-COP")
}
