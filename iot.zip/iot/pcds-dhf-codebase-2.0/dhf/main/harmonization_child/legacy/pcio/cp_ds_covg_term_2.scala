// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cp_ds_covg_term_2(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)

  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

select 
'PCIO-CP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1||'-L-FLOOD-'||replacE(NAME,'_AMT','') AS COVG_TERM_KEY,
'PCIO-CP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER AS POL_KEY,
'PCIO-CP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER AS POL_LINE_KEY,
'PCIO-CP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1 AS CVRBL_KEY,
'PCIO-CP-'||CPE_MF_LC_PREFIX_A||CPE_MF_LC_PREFIX_B||CPE_MF_LC_POL_BRANCH||CPE_MF_LC_POL_DEC||CPE_MF_LC_POL_NUMBER||'-'||CPE_MF_LC_SEQ_NUM1||'-CPLOCATION-L-FLOOD' AS LINE_COVG_KEY,
to_date(CPE_MF_LC_VER_DATE,'yyyyDDD') AS END_EFF_DT,
to_date(CPE_MF_LC_POL_EXP_DATE,'yyyyDDD') AS END_EXP_DT,
--to_timestamp(CPE_MF_LC_DATE,'yyyyDDD') AS ETL_ROW_EFF_DTS,
IF(TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'CP' AS LOB_CD,
'PCIO-CP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,
'CPLOCATION' AS CVRBL_TYPE_CD, 
'L-FLOOD' AS COVG_CD,
replacE(NAME,'_AMT','') AS COVG_TERM_CD,
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT
FROM 
global_temp.cp_gnrl_micro_batch micro_gnrl
inner join  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)    DESC ) AS rn
   FROM
   (SELECT  cp_gnrl.*
   from
   {rawDB}.cp_gnrl
   inner join global_temp.cp_gnrl_micro_batch mb
             on   mb.CPE_MF_GN_PREFIX_A = cp_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cp_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cp_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cp_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cp_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cp_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cp_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) gnrl
  on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))
  inner join 
(select *,STACK(14,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_SCORE","NA"),CPE_LC_FLOOD_SCORE,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_FLASH_SCORE","NA"),CPE_LC_FLOOD_FLASH_SCORE,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_BLDG_FL","NA"),CPE_LC_FLOOD_BLDG,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_BPP_FL","NA"),CPE_LC_FLOOD_BPP,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_BI_FL","NA"),CPE_LC_FLOOD_BI,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_BLANKET","NA"),CPE_LC_FLOOD_BLANKET,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_RISK_TYPE","NA"),CPE_LC_FLOOD_RISK_TYPE,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_ZONE","NA"),CPE_LC_FLOOD_ZONE,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_CONT_VALUES","NA"),CPE_LC_FLOOD_CONT_VALUES,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_2X_AGG_LIMIT_FL","NA"),CPE_LC_FLOOD_AGG_LIMIT,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_LIMIT_AMT","NA"),CPE_LC_FLOOD_LIMIT,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_DED_AMT","NA"),CPE_LC_FLOOD_DED,
IF(CPE_LC_FLOOD_PREM>0,"FLOOD_MIN_DED_AMT","NA"),CPE_LC_FLOOD_MIN_DED,
IF(CPE_LC_FLOOD_PREM>0,"TOTAL_FLOOD_LMT_AMT","NA"),CPE_LC_TOTAL_FLOOD_LMT 
) AS (NAME,VALUE)
from  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_LC_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cp_location.*
   from
   {rawDB}.cp_location
   inner join global_temp.cp_gnrl_micro_batch mb
   
              on  
           mb.CPE_MF_GN_PREFIX_A = cp_location.CPE_MF_LC_PREFIX_A
and mb.CPE_MF_GN_PREFIX_B = cp_location.CPE_MF_LC_PREFIX_B
and mb.CPE_MF_GN_POL_BRANCH = cp_location.CPE_MF_LC_POL_BRANCH
and mb.CPE_MF_GN_POL_DEC = cp_location.CPE_MF_LC_POL_DEC
and mb.CPE_MF_GN_POL_NUMBER = cp_location.CPE_MF_LC_POL_NUMBER
and mb.CPE_MF_GN_VER_DATE = cp_location.CPE_MF_LC_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_location.CPE_GN_CYCLE_DATE is null, 'null', cp_location.CPE_GN_CYCLE_DATE)         

              )
  ) WHERE rn = 1  )  where CPE_MF_LC_PREFIX_B NOT LIKE '%COP%') loc
  on  
           gnrl.CPE_MF_GN_PREFIX_A = loc.CPE_MF_LC_PREFIX_A
and gnrl.CPE_MF_GN_PREFIX_B = loc.CPE_MF_LC_PREFIX_B
and gnrl.CPE_MF_GN_POL_BRANCH = loc.CPE_MF_LC_POL_BRANCH
and gnrl.CPE_MF_GN_POL_DEC = loc.CPE_MF_LC_POL_DEC
and gnrl.CPE_MF_GN_POL_NUMBER = loc.CPE_MF_LC_POL_NUMBER
and gnrl.CPE_MF_GN_VER_DATE = loc.CPE_MF_LC_VER_DATE
and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(loc.CPE_GN_CYCLE_DATE is null, 'null', loc.CPE_GN_CYCLE_DATE) 
WHERE NAME!='NA' and  trim(value)!=''

UNION ALL --4


select distinct 
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER||'-'||replacE(NAME,'_AMT','') AS COVG_TERM_KEY,
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER AS POL_KEY,
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER AS POL_LINE_KEY,
'PCIO-CP-'||gnrl.CPE_MF_GN_PREFIX_A||gnrl.CPE_MF_GN_PREFIX_B||gnrl.CPE_MF_GN_POL_BRANCH||gnrl.CPE_MF_GN_POL_DEC||gnrl.CPE_MF_GN_POL_NUMBER AS CVRBL_KEY,
'NOKEY' AS  LINE_COVG_KEY,
to_date(gnrl.CPE_MF_GN_VER_DATE,'yyyyDDD') as END_EFF_DT,
TO_DATE(gnrl.CPE_MF_GN_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
--TO_TIMESTAMP(gnrl.CPE_MF_GN_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS,
IF(to_timestamp(gnrl.CPE_GN_CYCLE_DATE, 'yyyyDDD' ) IS NULL,TO_TIMESTAMP(gnrl.CPE_MF_GN_DATE,'yyyyDDD'), TO_TIMESTAMP(gnrl.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS ,
'CP' AS LOB_CD,
'PCIO-CP' AS PARTITION_VAL,
'PCIO' AS SOURCE_SYSTEM,
'CPLINE' AS CVRBL_TYPE_CD, 
' ' AS COVG_CD,
replacE(NAME,'_AMT','') AS COVG_TERM_CD,
IF(NAME NOT  LIKE '%_AMT%',VALUE,'') AS TERM_VAL_CD,
IF(NAME LIKE '%_AMT%',VALUE,null) AS TERM_VAL_AMT
 FROM 
global_temp.cp_gnrl_micro_batch micro_gnrl
inner join    
(SELECT * FROM  (select *,
 stack(11,"BLANKET_IND",CPE_GN_BLANKET_IND,
         "BLANKET_BUILDING",CPE_GN_BLANKET_BUILDING,
         "BLANKET_CONTENTS",CPE_GN_BLANKET_CONTENTS,
         "BLANKET_BUS_INCOME",CPE_GN_BLANKET_BUS_INCOME,
         "BLANKET_COINS_PERCENT",CPE_GN_BLANKET_CO_PERCENT,
         "BLANKET_HIGH_WEIGHT",CPE_GN_BLANKET_HIGH_WEIGHT, 
         "BLANKET_BLDG_CNTS",CPE_GN_BLANKET_BLDG_CNTS,
         "BLANKET_OVERRIDE_VALUE",CPE_GN_BLANKET_OVERRIDE_VALUE,
         "BLKT_TOT_BLDG_LIMIT_AMT",CPE_GN_BLKT_TOT_BLDG_LIMIT,
         "BLKT_TOT_CONT_LIMIT_AMT",CPE_GN_BLKT_TOT_CONT_LIMIT,
         "BLKT_TOT_BUS_INCM_LIMIT_AMT",CPE_GN_BLKT_TOT_TIME_LIMIT
          ) AS (NAME,VALUE)
       FROM  ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_GN_DATE, CPE_GN_AMEND_NUM)    DESC ) AS rn
   FROM
   (SELECT  cp_gnrl.*
   from
   {rawDB}.cp_gnrl
   inner join global_temp.cp_gnrl_micro_batch mb
             on   mb.CPE_MF_GN_PREFIX_A = cp_gnrl.CPE_MF_GN_PREFIX_A 
            and mb.CPE_MF_GN_PREFIX_B = cp_gnrl.CPE_MF_GN_PREFIX_B 
            and mb.CPE_MF_GN_POL_BRANCH = cp_gnrl.CPE_MF_GN_POL_BRANCH 
            and mb.CPE_MF_GN_POL_DEC = cp_gnrl.CPE_MF_GN_POL_DEC 
            and mb.CPE_MF_GN_POL_NUMBER = cp_gnrl.CPE_MF_GN_POL_NUMBER 
            and mb.CPE_MF_GN_VER_DATE = cp_gnrl.CPE_MF_GN_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_gnrl.CPE_GN_CYCLE_DATE is null, 'null', cp_gnrl.CPE_GN_CYCLE_DATE)
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  ) gnrl1 where CPE_MF_GN_PREFIX_B not like '%COP%'
          )  )GNRL  on (  gnrl.CPE_MF_GN_PREFIX_A = micro_gnrl.CPE_MF_GN_PREFIX_A 
            and gnrl.CPE_MF_GN_PREFIX_B = micro_gnrl.CPE_MF_GN_PREFIX_B 
            and gnrl.CPE_MF_GN_POL_BRANCH = micro_gnrl.CPE_MF_GN_POL_BRANCH 
            and gnrl.CPE_MF_GN_POL_DEC = micro_gnrl.CPE_MF_GN_POL_DEC 
            and gnrl.CPE_MF_GN_POL_NUMBER = micro_gnrl.CPE_MF_GN_POL_NUMBER 
            and gnrl.CPE_MF_GN_VER_DATE = micro_gnrl.CPE_MF_GN_VER_DATE 
            and if(gnrl.CPE_GN_CYCLE_DATE is null,'null',gnrl.CPE_GN_CYCLE_DATE) = if(micro_gnrl.CPE_GN_CYCLE_DATE is null, 'null', micro_gnrl.CPE_GN_CYCLE_DATE))

"""
  
    microBatchDF.createOrReplaceGlobalTempView(s"cp_gnrl_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
  
     //queryDF.createOrReplaceGlobalTempView(s"V")
     // val hashDF = addHashColumn_clt("V","COVG_TERM_ID ")
    mergeAndWrite(queryDF,List("COVG_TERM_KEY","END_EFF_DT"), harmonized_table, "COVG_TERM_ID","PCIO-CP")
}

