// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cp_ds_flood_info(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

SELECT distinct 
'PCIO-CP-'|| LOC.CPE_MF_LC_PREFIX_A||LOC.CPE_MF_LC_PREFIX_B||LOC.CPE_MF_LC_POL_BRANCH||LOC.CPE_MF_LC_POL_DEC||LOC.CPE_MF_LC_POL_NUMBER   ||'-'||LOC.CPE_MF_LC_SEQ_NUM1 AS FLOOD_INFO_KEY,
'PCIO-CP-'|| LOC.CPE_MF_LC_PREFIX_A||LOC.CPE_MF_LC_PREFIX_B||LOC.CPE_MF_LC_POL_BRANCH||LOC.CPE_MF_LC_POL_DEC||LOC.CPE_MF_LC_POL_NUMBER  AS POL_KEY,
'PCIO-CP-'|| LOC.CPE_MF_LC_PREFIX_A||LOC.CPE_MF_LC_PREFIX_B||LOC.CPE_MF_LC_POL_BRANCH||LOC.CPE_MF_LC_POL_DEC||LOC.CPE_MF_LC_POL_NUMBER   ||'-'||LOC.CPE_MF_LC_SEQ_NUM1 AS CVRBL_KEY,
to_date(LOC.CPE_MF_LC_VER_DATE,'yyyyDDD') AS END_EFF_DT,
to_date(LOC.CPE_MF_LC_POL_EXP_DATE,'yyyyDDD') AS END_EXP_DT,
IF(TO_TIMESTAMP(LOC.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(LOC.CPE_MF_LC_DATE,'yyyyDDD'), TO_TIMESTAMP(LOC.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'CP' AS LOB_CD,
'PCIO' AS SOURCE_SYSTEM,
'CPLOCATION' AS  CVRBL_TYPE_CD,
CAST(LOC.CPE_LC_FLOOD_SCORE AS INT) AS FLOOD_RISK_SCORE,
CAST(LOC.CPE_LC_FLOOD_FLASH_SCORE AS INT) AS FLASH_FLOOD_RISK_SCORE,
LOC.CPE_LC_FLOOD_ZONE AS FLOOD_ZONE,
'PCIO-CP' AS PARTITION_VAL 

FROM global_temp.cp_location_micro_batch MICRO_LOC
INNER JOIN 
(select distinct * from ( SELECT * FROM
  ( SELECT *, row_number() over ( partition BY CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null, CPE_MF_LC_DATE, CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cp_location.*
   from
  {rawDB}.cp_location
   inner join global_temp.cp_location_micro_batch mb
              on   mb.CPE_MF_LC_PREFIX_A = cp_location.CPE_MF_LC_PREFIX_A 
            and mb.CPE_MF_LC_PREFIX_B = cp_location.CPE_MF_LC_PREFIX_B 
            and mb.CPE_MF_LC_POL_BRANCH = cp_location.CPE_MF_LC_POL_BRANCH 
            and mb.CPE_MF_LC_POL_DEC = cp_location.CPE_MF_LC_POL_DEC 
            and mb.CPE_MF_LC_POL_NUMBER = cp_location.CPE_MF_LC_POL_NUMBER 
            and mb.CPE_MF_LC_SEQ_NUM1 = cp_location.CPE_MF_LC_SEQ_NUM1 
            and mb.CPE_MF_LC_VER_DATE = cp_location.CPE_MF_LC_VER_DATE 
            and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cp_location.CPE_GN_CYCLE_DATE is null, 'null', cp_location.CPE_GN_CYCLE_DATE)
            
--               where cp_location.loaded_time <= mb.CPE_GN_CYCLE_DATE
              )
  ) WHERE rn = 1  )  where CPE_MF_LC_PREFIX_B NOT LIKE '%COP%')LOC
  ON 
  MICRO_LOC.CPE_MF_LC_PREFIX_A = LOC.CPE_MF_LC_PREFIX_A 
            and MICRO_LOC.CPE_MF_LC_PREFIX_B = LOC.CPE_MF_LC_PREFIX_B 
            and MICRO_LOC.CPE_MF_LC_POL_BRANCH = LOC.CPE_MF_LC_POL_BRANCH 
            and MICRO_LOC.CPE_MF_LC_POL_DEC = LOC.CPE_MF_LC_POL_DEC 
            and MICRO_LOC.CPE_MF_LC_POL_NUMBER = LOC.CPE_MF_LC_POL_NUMBER 
            and MICRO_LOC.CPE_MF_LC_SEQ_NUM1 = LOC.CPE_MF_LC_SEQ_NUM1 
            and MICRO_LOC.CPE_MF_LC_VER_DATE = LOC.CPE_MF_LC_VER_DATE 
            and if(MICRO_LOC.CPE_GN_CYCLE_DATE is null,'null',MICRO_LOC.CPE_GN_CYCLE_DATE) = if(LOC.CPE_GN_CYCLE_DATE is null, 'null', LOC.CPE_GN_CYCLE_DATE)


"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cp_location_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.micro_batch_flood_info")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("FLOOD_INFO_KEY","END_EFF_DT"), harmonized_table, "FLOOD_INFO_ID","PCIO-CP")
}
