// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_cop_ds_addl_intrst(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 


select
'PCIO-COP-'||assg.CPE_MF_MTGA_PREFIX_A||assg.CPE_MF_MTGA_PREFIX_B||assg.CPE_MF_MTGA_POL_BRANCH||assg.CPE_MF_MTGA_POL_DEC||assg.CPE_MF_MTGA_POL_NUMBER||'-AINT-'||MRTG_NUM||'-'||assg.CPE_MTGA_LOC_NUM||'-'||assg.CPE_MTGA_BLDG_NUM||'-'||assg.CPE_MTGA_ITEM_NUM||'-'||ASSG_NUM||'-'||occ_num as ADDL_INTRST_KEY,
'PCIO-COP-'||assg.CPE_MF_MTGA_PREFIX_A||assg.CPE_MF_MTGA_PREFIX_B||assg.CPE_MF_MTGA_POL_BRANCH||assg.CPE_MF_MTGA_POL_DEC||assg.CPE_MF_MTGA_POL_NUMBER AS POL_KEY,
'PCIO-COP-'||assg.CPE_MF_MTGA_PREFIX_A||assg.CPE_MF_MTGA_PREFIX_B||assg.CPE_MF_MTGA_POL_BRANCH||assg.CPE_MF_MTGA_POL_DEC||assg.CPE_MF_MTGA_POL_NUMBER||'-20-'||MRTG_NUM   as POL_PARTY_KEY,


case when trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G','E','I','X','C','K','S') then 
'PCIO-COP-'||CPE_MF_BL_PREFIX_A||CPE_MF_BL_PREFIX_B||CPE_MF_BL_POL_BRANCH||CPE_MF_BL_POL_DEC||CPE_MF_BL_POL_NUMBER||'-'||CPE_MF_BL_SEQ_NUM1||'-'||CPE_MF_BL_SEQ_NUM2||'-'||CPE_MF_IT_SEQ_NUM3
ELSE 'NOKEY'
END AS CVRBL_KEY, --changed_NEW
to_date(assg.CPE_MF_MTGA_VER_DATE,'yyyyDDD') as END_EFF_DT,
to_date(assg.CPE_MF_MTGA_POL_EXP_DATE,'yyyyDDD') as END_EXP_DT,
--Case when trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P') then   'COPBLDG'
Case when trim(CPE_IT_COV_TYPE) in ('B','D','F','H','J','P','G') then   'COPLINEBLDG' --changed_NEW

     when trim(CPE_IT_COV_TYPE) in ('E','I','X') then   'COPBUSINESSINCOME'
     when trim(CPE_IT_COV_TYPE) in ('C','K','S') then   'COPPERSPROP'
     ELSE ' '
     END as CVRBL_TYPE_CD,
LP_IND as ADDL_INTRST_TYPE_CD,
LOAN_NO as CONTRACT_NO,
'PCIO' AS SOURCE_SYSTEM,
IF(TO_TIMESTAMP(ASSG.CPE_GN_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(ASSG.CPE_MF_MTGA_DATE,'yyyyDDD'), TO_TIMESTAMP(ASSG.CPE_GN_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'COP' AS LOB_CD,
'PCIO-COP' AS PARTITION_VAL
--to_timestamp(assg.CPE_MF_MTGA_DATE,'yyyyDDD') as ETL_ROW_EFF_DTS
from
global_temp.COP_MORT_ASSG_micro_batch micro_assg 
inner join
(select distinct * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_MTGA_PREFIX_A,
CPE_MF_MTGA_PREFIX_B,CPE_MF_MTGA_POL_BRANCH,CPE_MF_MTGA_POL_DEC,CPE_MF_MTGA_POL_NUMBER,CPE_MF_MTGA_VER_DATE,CPE_MTGA_ITEM_NUM,CPE_MTGA_LOC_NUM,CPE_MTGA_BLDG_NUM,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_MTGA_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_mort_assg.*
   from
   {rawDB}.COP_MORT_ASSG 
   inner join global_temp.COP_MORT_ASSG_micro_batch mb
   
              on  
          mb.CPE_MF_MTGA_PREFIX_A = cop_mort_assg.CPE_MF_MTGA_PREFIX_A
and mb.CPE_MF_MTGA_PREFIX_B = cop_mort_assg.CPE_MF_MTGA_PREFIX_B
and mb.CPE_MF_MTGA_POL_BRANCH = cop_mort_assg.CPE_MF_MTGA_POL_BRANCH
and mb.CPE_MF_MTGA_POL_DEC = cop_mort_assg.CPE_MF_MTGA_POL_DEC
and mb.CPE_MF_MTGA_POL_NUMBER = cop_mort_assg.CPE_MF_MTGA_POL_NUMBER
and mb.CPE_MF_MTGA_VER_DATE = cop_mort_assg.CPE_MF_MTGA_VER_DATE
and mb.CPE_MTGA_BLDG_NUM = cop_mort_assg.CPE_MTGA_BLDG_NUM
and mb.CPE_MTGA_LOC_NUM = cop_mort_assg.CPE_MTGA_LOC_NUM
and mb.CPE_MTGA_ITEM_NUM = cop_mort_assg.CPE_MTGA_ITEM_NUM
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_mort_assg.CPE_GN_CYCLE_DATE is null, 'null', cop_mort_assg.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  ))
assg  on
ASSG.CPE_MF_MTGA_PREFIX_A=MICRO_ASSG.CPE_MF_MTGA_PREFIX_A and 
ASSG.CPE_MF_MTGA_PREFIX_B=MICRO_ASSG.CPE_MF_MTGA_PREFIX_B and
ASSG.CPE_MF_MTGA_POL_BRANCH=MICRO_ASSG.CPE_MF_MTGA_POL_BRANCH and
ASSG.CPE_MF_MTGA_POL_DEC=MICRO_ASSG.CPE_MF_MTGA_POL_DEC and
ASSG.CPE_MF_MTGA_POL_NUMBER=MICRO_ASSG.CPE_MF_MTGA_POL_NUMBER and
ASSG.CPE_MF_MTGA_VER_DATE=MICRO_ASSG.CPE_MF_MTGA_VER_DATE and
ASSG.CPE_MTGA_BLDG_NUM=MICRO_ASSG.CPE_MTGA_BLDG_NUM and
ASSG.CPE_MTGA_LOC_NUM=MICRO_ASSG.CPE_MTGA_LOC_NUM and
ASSG.CPE_MTGA_ITEM_NUM=MICRO_ASSG.CPE_MTGA_ITEM_NUM 
and if(assg.CPE_GN_CYCLE_DATE is null,'null',assg.CPE_GN_CYCLE_DATE) = if(micro_assg.CPE_GN_CYCLE_DATE is null, 'null', micro_assg.CPE_GN_CYCLE_DATE)


inner join
(SELECT  *,
STACK(10, 
CPE_MTGA_MORTGAGEE_NUM_1,CPE_MTGA_ASSIGNMT_NUM_1,CPE_MTGA_MORT_LP_IND_1,CPE_MTGA_LOAN_NO_1,1,
CPE_MTGA_MORTGAGEE_NUM_2,CPE_MTGA_ASSIGNMT_NUM_2,CPE_MTGA_MORT_LP_IND_2,CPE_MTGA_LOAN_NO_2,2,
CPE_MTGA_MORTGAGEE_NUM_3,CPE_MTGA_ASSIGNMT_NUM_3,CPE_MTGA_MORT_LP_IND_3,CPE_MTGA_LOAN_NO_3,3,
CPE_MTGA_MORTGAGEE_NUM_4,CPE_MTGA_ASSIGNMT_NUM_4,CPE_MTGA_MORT_LP_IND_4,CPE_MTGA_LOAN_NO_4,4,
CPE_MTGA_MORTGAGEE_NUM_5,CPE_MTGA_ASSIGNMT_NUM_5,CPE_MTGA_MORT_LP_IND_5,CPE_MTGA_LOAN_NO_5,5,
CPE_MTGA_MORTGAGEE_NUM_6,CPE_MTGA_ASSIGNMT_NUM_6,CPE_MTGA_MORT_LP_IND_6,CPE_MTGA_LOAN_NO_6,6,
CPE_MTGA_MORTGAGEE_NUM_7,CPE_MTGA_ASSIGNMT_NUM_7,CPE_MTGA_MORT_LP_IND_7,CPE_MTGA_LOAN_NO_7,7,
CPE_MTGA_MORTGAGEE_NUM_8,CPE_MTGA_ASSIGNMT_NUM_8,CPE_MTGA_MORT_LP_IND_8,CPE_MTGA_LOAN_NO_8,8,
CPE_MTGA_MORTGAGEE_NUM_9,CPE_MTGA_ASSIGNMT_NUM_9,CPE_MTGA_MORT_LP_IND_9,CPE_MTGA_LOAN_NO_9,9,
CPE_MTGA_MORTGAGEE_NUM_10,CPE_MTGA_ASSIGNMT_NUM_10,CPE_MTGA_MORT_LP_IND_10,CPE_MTGA_LOAN_NO_10,10) AS (MRTG_NUM,ASSG_NUM,LP_IND,LOAN_NO,OCC_NUM) 
from 
(select distinct * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_MTGA_PREFIX_A,
CPE_MF_MTGA_PREFIX_B,CPE_MF_MTGA_POL_BRANCH,CPE_MF_MTGA_POL_DEC,CPE_MF_MTGA_POL_NUMBER,CPE_MF_MTGA_VER_DATE,CPE_MTGA_ITEM_NUM,CPE_MTGA_LOC_NUM,CPE_MTGA_BLDG_NUM,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_MTGA_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_mort_assg.*
   from
   {rawDB}.COP_MORT_ASSG 
   inner join global_temp.COP_MORT_ASSG_micro_batch mb
   
              on  
          mb.CPE_MF_MTGA_PREFIX_A = cop_mort_assg.CPE_MF_MTGA_PREFIX_A
and mb.CPE_MF_MTGA_PREFIX_B = cop_mort_assg.CPE_MF_MTGA_PREFIX_B
and mb.CPE_MF_MTGA_POL_BRANCH = cop_mort_assg.CPE_MF_MTGA_POL_BRANCH
and mb.CPE_MF_MTGA_POL_DEC = cop_mort_assg.CPE_MF_MTGA_POL_DEC
and mb.CPE_MF_MTGA_POL_NUMBER = cop_mort_assg.CPE_MF_MTGA_POL_NUMBER
and mb.CPE_MF_MTGA_VER_DATE = cop_mort_assg.CPE_MF_MTGA_VER_DATE
and mb.CPE_MTGA_BLDG_NUM = cop_mort_assg.CPE_MTGA_BLDG_NUM
and mb.CPE_MTGA_LOC_NUM = cop_mort_assg.CPE_MTGA_LOC_NUM
and mb.CPE_MTGA_ITEM_NUM = cop_mort_assg.CPE_MTGA_ITEM_NUM
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_mort_assg.CPE_GN_CYCLE_DATE is null, 'null', cop_mort_assg.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )) assg1         
inner JOIN 
(SELECT DISTINCT * FROM ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_IT_PREFIX_A, CPE_MF_IT_PREFIX_B, CPE_MF_IT_POL_BRANCH, CPE_MF_IT_POL_DEC, CPE_MF_IT_POL_NUMBER, CPE_MF_IT_VER_DATE,  CPE_MF_IT_SEQ_NUM2, CPE_MF_IT_SEQ_NUM1, CPE_MF_IT_SEQ_NUM3,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_IT_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_item.*
   from
   {rawDB}.cop_item
   inner join global_temp.COP_MORT_ASSG_micro_batch mb
   
              on  
          mb.CPE_MF_MTGA_PREFIX_A = cop_item.CPE_MF_IT_PREFIX_A
and mb.CPE_MF_MTGA_PREFIX_B = cop_item.CPE_MF_IT_PREFIX_B
and mb.CPE_MF_MTGA_POL_BRANCH = cop_item.CPE_MF_IT_POL_BRANCH
and mb.CPE_MF_MTGA_POL_DEC = cop_item.CPE_MF_IT_POL_DEC
and mb.CPE_MF_MTGA_POL_NUMBER = cop_item.CPE_MF_IT_POL_NUMBER
and mb.CPE_MF_MTGA_VER_DATE = cop_item.CPE_MF_IT_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_item.CPE_GN_CYCLE_DATE is null, 'null', cop_item.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )) item
on
assg1.CPE_MF_MTGA_PREFIX_A=item.CPE_MF_IT_PREFIX_A and
assg1.CPE_MF_MTGA_PREFIX_B=item.CPE_MF_IT_PREFIX_B and
assg1.CPE_MF_MTGA_POL_BRANCH=item.CPE_MF_IT_POL_BRANCH and
assg1.CPE_MF_MTGA_POL_DEC=item.CPE_MF_IT_POL_DEC and
assg1.CPE_MF_MTGA_POL_NUMBER=ITEM.CPE_MF_IT_POL_NUMBER and
assg1.CPE_MTGA_LOC_NUM=item.CPE_MF_IT_SEQ_NUM1 and
assg1.CPE_MTGA_BLDG_NUM=item.CPE_MF_IT_SEQ_NUM2 and
assg1.CPE_MTGA_ITEM_NUM=item.CPE_MF_IT_SEQ_NUM3 and
assg1.CPE_MF_MTGA_POL_EXP_DATE=item.CPE_MF_IT_POL_EXP_DATE and
assg1.CPE_MF_MTGA_VER_DATE=item.CPE_MF_IT_VER_DATE
and if(assg1.CPE_GN_CYCLE_DATE is null,'null',assg1.CPE_GN_CYCLE_DATE) = if(item.CPE_GN_CYCLE_DATE is null, 'null', item.CPE_GN_CYCLE_DATE)
inner join

(select distinct * from ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY CPE_MF_BL_PREFIX_A, CPE_MF_BL_PREFIX_B, CPE_MF_BL_POL_BRANCH, CPE_MF_BL_POL_DEC, CPE_MF_BL_POL_NUMBER, CPE_MF_BL_VER_DATE,  CPE_MF_BL_SEQ_NUM1, CPE_MF_BL_SEQ_NUM2,CPE_GN_CYCLE_DATE ORDER BY if(CPE_GN_CYCLE_DATE is null,CPE_MF_BL_DATE,CPE_GN_AMEND_NUM)   DESC ) AS rn
   FROM
   (SELECT  cop_bldg.*
   from
   {rawDB}.cop_bldg
   inner join global_temp.COP_MORT_ASSG_micro_batch mb
   
              on  
          mb.CPE_MF_MTGA_PREFIX_A = cop_bldg.CPE_MF_BL_PREFIX_A
and mb.CPE_MF_MTGA_PREFIX_B = cop_bldg.CPE_MF_BL_PREFIX_B
and mb.CPE_MF_MTGA_POL_BRANCH = cop_bldg.CPE_MF_BL_POL_BRANCH
and mb.CPE_MF_MTGA_POL_DEC = cop_bldg.CPE_MF_BL_POL_DEC
and mb.CPE_MF_MTGA_POL_NUMBER = cop_bldg.CPE_MF_BL_POL_NUMBER
and mb.CPE_MF_MTGA_VER_DATE = cop_bldg.CPE_MF_BL_VER_DATE
and if(mb.CPE_GN_CYCLE_DATE is null,'null',mb.CPE_GN_CYCLE_DATE) = if(cop_bldg.CPE_GN_CYCLE_DATE is null, 'null', cop_bldg.CPE_GN_CYCLE_DATE)            

              )
  ) WHERE rn = 1  )) bldg 
on
item.CPE_MF_IT_PREFIX_A=bldg.CPE_MF_BL_PREFIX_A and 
item.CPE_MF_IT_PREFIX_B=bldg.CPE_MF_BL_PREFIX_B and
item.CPE_MF_IT_POL_BRANCH=bldg.CPE_MF_BL_POL_BRANCH and
item.CPE_MF_IT_POL_DEC=bldg.CPE_MF_BL_POL_DEC and
item.CPE_MF_IT_POL_NUMBER=bldg.CPE_MF_BL_POL_NUMBER and
item.CPE_MF_IT_SEQ_NUM1=bldg.CPE_MF_BL_SEQ_NUM1 and
item.CPE_MF_IT_SEQ_NUM2=bldg.CPE_MF_BL_SEQ_NUM2 and
item.CPE_MF_IT_POL_EXP_DATE=bldg.CPE_MF_BL_POL_EXP_DATE and
item.CPE_MF_IT_VER_DATE =bldg.CPE_MF_BL_VER_DATE
and if(item.CPE_GN_CYCLE_DATE is null,'null',item.CPE_GN_CYCLE_DATE) = if(bldg.CPE_GN_CYCLE_DATE is null, 'null', bldg.CPE_GN_CYCLE_DATE)
) assg2 on
assg2.CPE_MF_MTGA_PREFIX_A = micro_assg.CPE_MF_MTGA_PREFIX_A and
ASSG2.CPE_MF_MTGA_PREFIX_B=MICRO_ASSG.CPE_MF_MTGA_PREFIX_B and
ASSG2.CPE_MF_MTGA_POL_BRANCH=MICRO_ASSG.CPE_MF_MTGA_POL_BRANCH and
ASSG2.CPE_MF_MTGA_POL_DEC=MICRO_ASSG.CPE_MF_MTGA_POL_DEC and
ASSG2.CPE_MF_MTGA_POL_NUMBER=MICRO_ASSG.CPE_MF_MTGA_POL_NUMBER and
ASSG2.CPE_MF_MTGA_VER_DATE=MICRO_ASSG.CPE_MF_MTGA_VER_DATE and
ASSG2.CPE_MTGA_BLDG_NUM=MICRO_ASSG.CPE_MTGA_BLDG_NUM and
ASSG2.CPE_MTGA_LOC_NUM=MICRO_ASSG.CPE_MTGA_LOC_NUM and
ASSG2.CPE_MTGA_ITEM_NUM=MICRO_ASSG.CPE_MTGA_ITEM_NUM
and if(ASSG.CPE_GN_CYCLE_DATE is null,'null',ASSG.CPE_GN_CYCLE_DATE) = if(MICRO_ASSG.CPE_GN_CYCLE_DATE is null, 'null', MICRO_ASSG.CPE_GN_CYCLE_DATE)
WHERE TRIM(MRTG_NUM)!='000'
"""
  
   microBatchDF.createOrReplaceGlobalTempView(s"cop_mort_assg_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.cop_mort_assg_micro_batch_loc")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.show(3,false)
    mergeAndWrite(queryDF,List("ADDL_INTRST_KEY","END_EFF_DT"), harmonized_table, "ADDL_INTRST_ID","PCIO-COP")
}
