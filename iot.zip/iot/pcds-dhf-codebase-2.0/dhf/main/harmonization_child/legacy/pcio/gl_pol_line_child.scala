// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_pcio_gl_ds_pol_line(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                  print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
   
 

  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 

SELECT  
'PCIO-GL-'||dec.GLOE_MF_PREFIX_A||dec.GLE_PREFIX_B||dec.GLOE_MF_POL_BRANCH||dec.GLOE_MF_POL_DEC||dec.GLOE_MF_POL_NUMBER as POL_LINE_KEY,
'PCIO-GL-'||dec.GLOE_MF_PREFIX_A||dec.GLE_PREFIX_B||dec.GLOE_MF_POL_BRANCH||dec.GLOE_MF_POL_DEC||dec.GLOE_MF_POL_NUMBER as POL_KEY,
TO_DATE(dec.GLOE_MF_VER_DATE, 'yyyyDDD') as END_EFF_DT,
TO_DATE(dec.GLOE_MF_POL_EXP_DATE, 'yyyyDDD') as END_EXP_DT,
'PCIO' AS SOURCE_SYSTEM,
to_date(GLE_IDX_RETRO_DATE,'yyDDD') as CLAIMS_RETROACTIVE_DT, 
dec.GLE_PREFIX_B as LEGACY_PREFIXB,
--to_timestamp(dec.GLOE_MF_DATE, 'yyyyDDD') as ETL_ROW_EFF_DTS,
dec.GLE_PRCO_COMM/100 AS PRCO_CMISN_PCT,
dec.GLE_OTHER_COMM/100  AS OTHR_CMISN_PCT,
dec.GLE_PRCO_CONTRB/100 AS PRCO_CMISN_FCT,
dec.GLE_OTHER_CONTRB/100 AS OTHR_CMISN_FCT,
IF(TO_TIMESTAMP(dec.GLE_CYCLE_DATE,'yyyyDDD') IS NULL,TO_TIMESTAMP(dec.GLOE_MF_DATE,'yyyyDDD'), TO_TIMESTAMP(dec.GLE_CYCLE_DATE,'yyyyDDD')) as ETL_ROW_EFF_DTS,
'GL' AS LOB_CD,
'PCIO-GL' as PARTITION_VAL
FROM
(select distinct * from global_temp.gl_dec_micro_batch) micro_dec
inner join ( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY GLOE_MF_PREFIX_A,GLE_PREFIX_B,GLOE_MF_POL_BRANCH,GLOE_MF_POL_DEC,GLOE_MF_POL_NUMBER,GLOE_MF_VER_DATE,GLE_CYCLE_DATE ORDER BY if(GLE_CYCLE_DATE is null, GLOE_MF_DATE, GLE_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  gl_dec.*
   from
   {rawDB}.gl_dec
   inner join global_temp.gl_dec_micro_batch mb
             on  mb.GLOE_MF_PREFIX_A= gl_dec.GLOE_MF_PREFIX_A 
            and mb.GLOE_MF_POL_BRANCH=gl_dec.GLOE_MF_POL_BRANCH
            and mb.GLOE_MF_POL_DEC=gl_dec.GLOE_MF_POL_DEC
            and mb.GLOE_MF_POL_NUMBER=gl_dec.GLOE_MF_POL_NUMBER
            and mb.GLE_PREFIX_B=gl_dec.GLE_PREFIX_B
            and mb.GLOE_MF_VER_DATE=gl_dec.GLOE_MF_VER_DATE
            
            
--               where cp_gnrl.loaded_time <= mb.loaded_time
              )
  ) WHERE rn = 1  )  
  dec
on ( micro_dec.GLOE_MF_PREFIX_A= dec.GLOE_MF_PREFIX_A 
            and micro_dec.GLOE_MF_POL_BRANCH=dec.GLOE_MF_POL_BRANCH
            and micro_dec.GLOE_MF_POL_DEC=dec.GLOE_MF_POL_DEC
            and micro_dec.GLOE_MF_POL_NUMBER=dec.GLOE_MF_POL_NUMBER
            and micro_dec.GLE_PREFIX_B=dec.GLE_PREFIX_B
            and micro_dec.GLOE_MF_VER_DATE=dec.GLOE_MF_VER_DATE)


left join
(select distinct GLOE_MF_PREFIX_A,GLOE_MF_POL_BRANCH,GLOE_MF_POL_DEC,GLOE_MF_POL_NUMBER,GLE_IDX_PREFIX_B,GLOE_MF_VER_DATE,GLOE_MF_POL_EXP_DATE,
GLE_IDX_RETRO_DATE,GLE_CYCLE_DATE from
( SELECT * FROM
   ( SELECT *, row_number() over ( partition BY GLOE_MF_PREFIX_A,GLE_IDX_PREFIX_B,GLOE_MF_POL_BRANCH,GLOE_MF_POL_DEC,GLOE_MF_POL_NUMBER,GLOE_MF_VER_DATE,GLE_CYCLE_DATE ORDER BY if(GLE_CYCLE_DATE is null, GLOE_MF_DATE, GLE_AMEND_NUM) DESC ) AS rn
   FROM
   (SELECT  gl_index.*
   from
   {rawDB}.gl_index
   inner join global_temp.gl_dec_micro_batch mb
   
              on  
         mb.GLOE_MF_PREFIX_A= gl_index.GLOE_MF_PREFIX_A 
and mb.GLOE_MF_POL_BRANCH=gl_index.GLOE_MF_POL_BRANCH
and mb.GLOE_MF_POL_DEC=gl_index.GLOE_MF_POL_DEC
and mb.GLOE_MF_POL_NUMBER=gl_index.GLOE_MF_POL_NUMBER
and mb.GLE_PREFIX_B=gl_index.GLE_IDX_PREFIX_B
and mb.GLOE_MF_VER_DATE=gl_index.GLOE_MF_VER_DATE
            

              )
  ) WHERE rn = 1  )    
) idx
on
dec.GLOE_MF_PREFIX_A= idx.GLOE_MF_PREFIX_A 
and dec.GLOE_MF_POL_BRANCH=idx.GLOE_MF_POL_BRANCH
and dec.GLOE_MF_POL_DEC=idx.GLOE_MF_POL_DEC
and dec.GLOE_MF_POL_NUMBER=idx.GLOE_MF_POL_NUMBER
and dec.GLE_PREFIX_B=idx.GLE_IDX_PREFIX_B
and dec.GLOE_MF_VER_DATE=idx.GLOE_MF_VER_DATE
AND DEC.GLOE_MF_POL_EXP_DATE=idx.GLOE_MF_POL_EXP_DATE
and if(dec.GLE_CYCLE_DATE is null,'null',dec.GLE_CYCLE_DATE) = if(idx.GLE_CYCLE_DATE is null, 'null', idx.GLE_CYCLE_DATE)


"""
  
 
      microBatchDF.createOrReplaceGlobalTempView(s"gl_dec_micro_batch")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.gl_dec_micro_batch_PCIO_GL_POL_LINE")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
//    queryDF.createOrReplaceGlobalTempView(s"V")
//     val hashDF = addHashColumn_clt("V","FORM_ID")
  
    mergeAndWrite(queryDF,List("POL_LINE_KEY","END_EFF_DT"),harmonized_table,"POL_LINE_ID","PCIO-GL")
}