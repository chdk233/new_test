// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_pak_ds_cust_acct(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
  SELECT T1.ACCT_KEY,T1.AGCY_KEY,T1.AGNT_KEY,T1.FIN_AGCY_KEY,T1.FIN_AGNT_KEY,T1.ETL_ROW_EFF_DTS,T1.SOURCE_SYSTEM,T1.PARTITION_VAL,T1.ACCT_NO,T1.ACCT_NAME,T1.MAILING_ADDR_1,T1.MAILING_ADDR_2,T1.MAILING_CITY,T1.MAILING_STATE_CD,T1.MAILING_ZIP_CD,T1.ORIG_EFF_DT,T1.DOING_BUS_AS,T1.FIRST_NAME,T1.MIDDLE_NAME,T1.LAST_NAME,T1.BCD_CD FROM (
SELECT DISTINCT
'HV-PAK-'||i.Acct_no_txt AS ACCT_KEY,
ifnull(a.Agency_code_txt, 'NOKEY') AS AGCY_KEY,
ifnull(a.Agency_code_txt||a.NATIONAL_PRODUCER_NUM_TXT, 'NOKEY') AS AGNT_KEY,
ifnull(a.Agency_code_txt, 'NOKEY') AS FIN_AGCY_KEY,
ifnull(a.Agency_code_txt||a.NATIONAL_PRODUCER_NUM_TXT, 'NOKEY') AS FIN_AGNT_KEY,
ifnull(e.Start_dte,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
ifnull(rtrim(e.Source_system_txt), ' ') AS SOURCE_SYSTEM,
'HV-PAK' AS PARTITION_VAL,
ifnull(i.Acct_no_txt, ' ') AS ACCT_NO,
ifnull(rtrim(f.Full_nme), ' ') AS ACCT_NAME,
ifnull(rtrim(g.Address_line_1_txt), ' ') AS MAILING_ADDR_1,
ifnull(rtrim(g.Address_line_2_txt), ' ') AS MAILING_ADDR_2,
ifnull(rtrim(g.City_txt), ' ') AS MAILING_CITY,
ifnull(rtrim(g.State_abbrev_cde), ' ') AS MAILING_STATE_CD,
ifnull(rtrim(g.Postal_code_txt), ' ') AS MAILING_ZIP_CD,
ifnull(date(a.founded_dte), TO_DATE('1900-01-01','yyyy-mm-dd')) AS ORIG_EFF_DT,
ifnull(rtrim(i.Doing_business_as_nme), ' ') AS DOING_BUS_AS,
ifnull(rtrim(f.First_nme), ' ') AS FIRST_NAME,
ifnull(rtrim(f.Middle_nme), ' ') AS MIDDLE_NAME,
ifnull(rtrim(f.Last_nme), ' ') AS LAST_NAME,
ifnull(rtrim(i.Risk_class_selection_id), ' ') AS BCD_CD,
g.party_id AS G_PARTY_ID,
g.Contact_point_id AS G_CONTACT_PT_ID
from global_temp.party_micro_batch5 micro_party
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY party_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT PARTY.*
from
{rawDB}.PARTY
inner join global_temp.party_micro_batch5 mb
on mb.party_id = PARTY.party_id
-- where PARTY.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) a
ON micro_party.party_id = a.party_id
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY identifier ORDER BY End_dte DESC ) AS rn
FROM
(SELECT party_role_in_acct.*
from
{rawDB}.party_role_in_acct
inner join global_temp.party_micro_batch5 mb
on mb.party_id = party_role_in_acct.party_id
-- where PARTY.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) b
ON a.party_id = b.party_id
and b.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Insured_account_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT insured_account.*
from
{rawDB}.insured_account
)
) WHERE rn = 1 ) c
on b.account_id = c.account_id
and c.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY identifier ORDER BY End_dte DESC ) AS rn
FROM
(SELECT policy_acct_rl.*
from
{rawDB}.policy_acct_rl
)
) WHERE rn = 1 ) d
on c.account_id = d.account_id
and d.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY policy_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT policy.*
from
{rawDB}.policy
)
) WHERE rn = 1 ) e
on d.policy_id = e.policy_id
and e.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Party_name_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT party_name.*
from
{rawDB}.party_name
inner join global_temp.party_micro_batch5 mb
on mb.party_id = party_name.party_id
-- where party_name.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) f
on a.party_id = f.party_id
and f.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Contact_point_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT contact_point.*
from
{rawDB}.contact_point
inner join global_temp.party_micro_batch5 mb
on mb.party_id = contact_point.party_id
-- where contact_point.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) g
on a.party_id = g.party_id
and g.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join 
( SELECT * FROM
( SELECT *, row_number() over ( partition BY market_segmentation_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT Reporting_Market_Segmentation.*
from
{rawDB}.Reporting_Market_Segmentation
)
) WHERE rn = 1 ) h
on b.account_id = h.account_id
and h.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Insured_account_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT insured_account.*
from
{rawDB}.insured_account
)
) WHERE rn = 1 ) i
on b.account_id = i.account_id
and i.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
where date(c.end_dte) = '9999-12-31'
and date(b.end_dte) = '9999-12-31'
and date(e.effective_dte) >= '2009-12-31'
and a.Type_id = 7285 
and b.nature_id <> 1171
and trim(e.source_system_txt) = 'AQS'
and f.Party_name_id <> 5561248) T1
inner join (select l.party_id as lparty_id, min(l.Contact_point_id) as CONTACT_PT_ID from 
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Contact_point_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT contact_point.*
from
{rawDB}.contact_point
inner join global_temp.party_micro_batch5 mb
on mb.party_id = contact_point.party_id
-- where contact_point.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) l
where l.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy') group by l.party_id) T2
on T1.G_PARTY_ID = T2.lparty_id
and T1.G_CONTACT_PT_ID = T2.CONTACT_PT_ID
  """
  
 
    microBatchDF.createOrReplaceGlobalTempView(s"party_micro_batch5")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.party_micro_batch_hv_pak_custacct")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","ACCT_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("ACCT_KEY","ETL_ROW_EFF_DTS"),harmonized_table,"ACCT_ID","HV-PAK")
//     queryDF.show(3,false)
}