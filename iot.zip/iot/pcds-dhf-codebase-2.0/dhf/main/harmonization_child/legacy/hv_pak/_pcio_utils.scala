// Databricks notebook source
import org.apache.spark.sql.DataFrame

// COMMAND ----------

val pk_map = Map(
"bop_location" -> """SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B, SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_SEQ_NUM1, SBOE_MF_SEQ_NUM2, SBOE_MF_VER_DATE | loaded_time""",

"pak_reg_owner" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER,PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE|loaded_time",

"pak_prefix" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER,PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE|loaded_time",
  
"pak_drvr" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER,PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE|loaded_time",
  
"pak_master" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_SEQ_NUM1, PHE00100_SEQ_NUM2, PHE00100_VERSION_DATE, PHE00100_RECORD_ID, PHE00100_ITEM_CODE ,PHE00100_VARIABLE|loaded_time",
  
"bop_named_ins" -> "SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B, SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_SEQ_NUM1, SBOE_MF_VER_DATE|loaded_time",
  
"bop_mortgage" -> "SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B, SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_SEQ_NUM1, SBOE_MF_VER_DATE|loaded_time",
  
"bop_endrmnt" -> """SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B, SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_SEQ_NUM1, SBOE_M25_FORM_NUM, 
SBOE_M25_EDITION_DATE, SBOE_MF_VER_DATE|loaded_time""",
  
"pak_review_code" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER,PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE|loaded_time",
  
"bop_dec" -> "SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B, SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_VER_DATE|loaded_time",
  
"bop_mort_assg" -> "SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B, SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_SEQ_NUM1, SBOE_MF_VER_DATE,SBOE_MF_SEQ_NUM2|loaded_time",
  
"pak_named_ins" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE, PHE00100_SEQ_NUM2, PHE00100_ITEM_CODE|loaded_time",
  
"pak_addr" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER,PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE|loaded_time",
  
"bop_vrbl_edit" -> """SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B, SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_SEQ_NUM1, SBOE_MF_SEQ_NUM2,  SBOE_M25_END_NBR, SBOE_M25_END_ED_DATE, SBOE_MF_VER_DATE|loaded_time""",
  
"pak_insured_int" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER,PHE00100_SEQ_NUM1, PHE00100_VERSION_DATE|loaded_time",
  
"pak_gnrl" -> "PHE00100_PREFIX_A,  PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE|PHE00100_DATE_STAMP",
  
"bop_addl_insrd"  -> "SBOE_MF_PREFIX_A, SBOE_MF_PREFIX_B,  SBOE_MF_POL_BRANCH, SBOE_MF_POL_DEC, SBOE_MF_POL_NUMBER, SBOE_MF_SEQ_NUM1, SBOE_MF_SEQ_NUM2, SBOE_MF_VER_DATE|loaded_time",
  
"ba_other_details_rcrd"  -> "PHE00100_PREFIX_A, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE, PHE00100_SEQ_NUM1 , PHE00100_PREFIX_B, PHE00100_RECORD_ID, PHE00100_SEQ_NUM4|loaded_time",

"ccmlv_coverage_after_dedup"  -> "ETL_TRAN_ID, PHW93000_FILE_TYPE, PHW93000_POLICY_NUMBER, PHW93000_D_TRANS_EFF,PHW93000_D_CYCLE|DATA_AS_OF_DT",

"ccmlv_policy_ded"  -> "ETL_TRAN_ID, PHW93101_FILE_TYPE, PHW93101_POLICY_NUMBER, PHW93101_D_TRANS_EFF,PHW93101_D_CYCLE|DATA_AS_OF_DT",
  
"ba_vehicle_gnrl"  -> "PHE00100_PREFIX_A, PHE00100_PREFIX_B, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE, PHE00100_SEQ_NUM1|loaded_time",

"ba_other_gnrl"  -> "PHE00100_PREFIX_A, PHE00100_PREFIX_B, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE, PHE00100_RECORD_ID, PHE00100_SEQ_NUM1, PHE00100_SEQ_NUM2 |loaded_time",
  
  "ba_auto_stat"  -> "PHE00100_PREFIX_A, PHE00100_PREFIX_B, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE, PHE00100_RECORD_ID,PHE00100_SEQ_NUM1,PHE00100_VARIABLE|loaded_time",
  
  "ba_forms"  -> "PHE00100_PREFIX_A, PHE00100_PREFIX_B, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE, PHE00100_RECORD_ID,PHE00100_SEQ_NUM1,PHE00100_VARIABLE|loaded_time",
  
  "ba_general_coverage"  -> "PHE00100_PREFIX_A, PHE00100_PREFIX_B, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE, PHE00100_RECORD_ID, PHE00100_SEQ_NUM1, PHE00100_VARIABLE|loaded_time",
  
  "ba_covg_tracking_gnrl"  -> "PHE00100_PREFIX_A, PHE00100_PREFIX_B, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE, PHE00100_SEQ_NUM1|loaded_time",

 "ba_plcy_gnrl"  -> "PHE00100_PREFIX_A, PHE00100_PREFIX_B, PHE00100_POL_BRANCH, PHE00100_POL_DEC, PHE00100_POL_NUMBER, PHE00100_VERSION_DATE|loaded_time",
  
  "ba_covg_forms"  -> "PHE00100_PREFIX_A ,PHE00100_POL_BRANCH,PHE00100_POL_DEC,PHE00100_POL_NUMBER,PHE00100_PREFIX_B,PHE00100_VERSION_DATE, PHE00100_VARIABLE,PHE00100_FORM_SEQ_NUM,PHE00100_FORM_VAR_SEQ_NUM|loaded_time",
  
  "cp_locn_cyc9"  -> "CPE_MF_LC_PREFIX_A, CPE_MF_LC_PREFIX_B, CPE_MF_LC_POL_BRANCH, CPE_MF_LC_POL_DEC, CPE_MF_LC_POL_NUMBER, CPE_MF_LC_SEQ_NUM1, CPE_MF_LC_VER_DATE|loaded_time",
  
   "cp_bldg"  -> "CPE_MF_BL_PREFIX_A, CPE_MF_BL_PREFIX_B, CPE_MF_BL_POL_BRANCH, CPE_MF_BL_POL_DEC, CPE_MF_BL_POL_NUMBER, CPE_MF_BL_VER_DATE,  CPE_MF_BL_SEQ_NUM1, CPE_MF_BL_SEQ_NUM2|loaded_time",
  
   "cp_gnrl"  -> "CPE_MF_GN_PREFIX_A,  CPE_MF_GN_PREFIX_B, CPE_MF_GN_POL_BRANCH, CPE_MF_GN_POL_DEC, CPE_MF_GN_POL_NUMBER, CPE_MF_GN_VER_DATE|loaded_time",
  
   "cp_form"  -> "CPE_MF_EF_PREFIX_A, CPE_MF_EF_POL_BRANCH, CPE_MF_EF_POL_DEC, CPE_MF_EF_POL_NUMBER, CPE_MF_EF_TIME, CPE_MF_EF_VER_DATE, CPE_EF_END_NBR, CPE_MF_EF_SEQ_NUM3|loaded_time",
  
  "cp_insured"  -> "CPE_MF_IS_PREFIX_A,CPE_MF_IS_PREFIX_B, CPE_MF_IS_POL_BRANCH, CPE_MF_IS_POL_DEC, CPE_MF_IS_POL_NUMBER, CPE_MF_IS_SEQ_NUM1, CPE_MF_IS_VER_DATE|loaded_time",
  
  "cp_item"  -> "CPE_MF_IT_PREFIX_A, CPE_MF_IT_PREFIX_B, CPE_MF_IT_POL_BRANCH, CPE_MF_IT_POL_DEC, CPE_MF_IT_POL_NUMBER, CPE_MF_IT_VER_DATE,  CPE_MF_IT_SEQ_NUM2, CPE_MF_IT_SEQ_NUM1, CPE_MF_IT_SEQ_NUM3, CPE_IT_COV_TYPE|loaded_time",
  
   "cp_mortagagee"  -> "CPE_MF_MG_PREFIX_A,CPE_MF_MG_PREFIX_B, CPE_MF_MG_POL_BRANCH, CPE_MF_MG_POL_DEC, CPE_MF_MG_POL_NUMBER, CPE_MF_MG_VER_DATE, CPE_MF_MG_SEQ_NUM1|loaded_time",
  
"im_plcy_gnrl_02"  -> "PCE_MF_PREFIX_A,PCE_MF_POL_BRANCH,PCE_MF_POL_DEC,PCE_MF_POL_NUMBER,PCE_MF_PREFIX_B,PCE010_1_ACTION_EFF_DATE|loaded_time",
  
"im_nmd_ins_02"  -> "PCE_MF_PREFIX_A,PCE_MF_POL_BRANCH,PCE_MF_POL_DEC,PCE_MF_POL_NUMBER,PCE_MF_PREFIX_B,PCE020_1_ACTION_EFF_DATE,PCE020_1_UNIT|loaded_time",
  
 "im_loss_payee_02"  -> "PCE_MF_PREFIX_A,PCE_MF_POL_BRANCH,PCE_MF_POL_DEC,PCE_MF_POL_NUMBER,PCE_MF_PREFIX_B,PCE050_1_ACTION_EFF_DATE|loaded_time",
  
 "wc_addr"  -> "WCE_POL_PREFIX_A_18,WCE_POL_PREFIX_B_18,WCE_POL_NUMBER_BR_18,WCE_POL_NUMBER_7_18,WCE_POL_NUMBER_DEC_18,WCE_SEG_CNT_18,WCE_DEC_VERSION_18|loaded_time",
  
 "wc_dec"  -> "WCE_POL_PREFIX_A_10,WCE_POL_PREFIX_B_10,WCE_POL_NUMBER_BR_10,WCE_POL_NUMBER_7_10,WCE_POL_NUMBER_DEC_10,WCE_DEC_VERSION_10,WCE_DATE_VERSION_EFF|loaded_time",
 "fmp_gnrl_info"  -> "FME_SEG10_MF_PREFIX_A,FME_SEG10_MF_PREFIX_B,FME_SEG10_MF_POL_BRANCH,FME_SEG10_MF_POL_DEC,FME_SEG10_MF_POL_NUMBER,FME_SEG10_MF_VER_DATE,FME_CYCLE_DATE,FME_AMEND_NUM|loaded_time",
  
"fmp_mortagagee_master"  ->   "FME_SEG50_MF_PREFIX_A,FME_SEG50_MF_PREFIX_B,FME_SEG50_MF_POL_BRANCH,FME_SEG50_MF_POL_DEC,FME_SEG50_MF_POL_NUMBER,FME_SEG50_MF_VER_DATE,FME_AMEND_NUM,FME_CYCLE_DATE,FME_MORTGAGEE_NUM|loaded_time",
  
 "fmp_named_insured"  ->   "FME_SEG15_MF_PREFIX_A,FME_SEG15_MF_PREFIX_B,FME_SEG15_MF_POL_BRANCH,FME_SEG15_MF_POL_DEC,FME_SEG15_MF_POL_NUMBER,FME_SEG15_MF_VER_DATE,FME_AMEND_NUM,FME_CYCLE_DATE,FMP_ADDL_SEQ_NO|loaded_time"
)


// COMMAND ----------

var id_col_name = "NONE"
def createDefaultMap(tgtTable:String) : Map[String, String] 
= {
  
  var tbl_name = tgtTable.toUpperCase()

  val df = spark.read.text(s"dbfs:/pcds_legacy/dev/others/Harmonized_DDL/$tbl_name.sql")

  var col_map = Map("col_name" -> "default_val")

  for ( ln <- df.collect())
  {
    var line = ln(0).toString().trim()
    if(line.contains("DEFAULT") && ! line.contains("ETL") && ! line.contains("ETL"))
    {
      var col_name = line.split(" ")(0)
      var def_val = line.split("DEFAULT")(1)
      def_val = def_val.replace(",","")
      if(line.contains("1900-01-01"))
      {
        if(line.toUpperCase().contains(" DATE "))
        {
          def_val = "CAST('1900-01-01 00:00:00.000' AS DATE)"
        }
        else if(line.toUpperCase().contains(" TIMESTAMP "))
        {
          def_val = "CAST('1900-01-01 00:00:00.000' AS TIMESTAMP)"
        }
      }
      else if(line.contains("9999-12-31"))
      {
        if(line.toUpperCase().contains(" DATE "))
        {
          def_val = "CAST('9999-12-31 23.59.59.999' AS DATE)"
        }
        else if(line.toUpperCase().contains(" TIMESTAMP "))
        {
          def_val = "CAST('9999-12-31 23.59.59.999' AS TIMESTAMP)"
        }
      }
      else if(line.contains("NUMERIC"))
      {
        def_val =  "CAST(0 AS DOUBLE)"
      }
      col_map = col_map ++ Map(col_name -> def_val)
    }
    if(line.contains("IDENTITY"))
    {
      id_col_name = line.split(" ")(0)
    }
  }
  println("***************Default Value Mapping**************")
  println(col_map)
  println("***********************************************")
  return col_map
}

// COMMAND ----------

// MAGIC %scala
// MAGIC 
// MAGIC def getSubQyeryStr(table_name : String, parent : String) : String
// MAGIC = {
// MAGIC   println("Entering in getSubQyeryStr")
// MAGIC   var pk_1 : List[String] = pk_map(table_name.toLowerCase()).split("\\|").map(_.trim).toList
// MAGIC   var pk_2 : List[String] = pk_map(parent.toLowerCase()).split("\\|").map(_.trim).toList
// MAGIC   
// MAGIC   val pk_cols1 = pk_1(0)
// MAGIC   val pk_cols2 = pk_2(0)
// MAGIC   val order_col = pk_1(1)
// MAGIC 
// MAGIC   var pk_cols_lst1 = pk_cols1.toString().split(",")
// MAGIC   var pk_cols_lst2 = pk_cols2.toString().split(",")
// MAGIC   var pk_cols_lst = List(pk_cols_lst1, pk_cols_lst2).reduce((a, b) => a intersect b)
// MAGIC   val pk_cols = pk_cols_lst.mkString(",")
// MAGIC   var join_cond = " "
// MAGIC   for (pk <- pk_cols_lst)
// MAGIC   {
// MAGIC     var pk_col = pk.trim()
// MAGIC     join_cond = join_cond + s" mb.$pk_col = $table_name.$pk_col \n            and"
// MAGIC   }
// MAGIC   join_cond = join_cond.substring(0,join_cond.length()-3)
// MAGIC 
// MAGIC   val sql_final = s"""( SELECT * FROM
// MAGIC    ( SELECT *, row_number() over ( partition BY $pk_cols ORDER BY $order_col   DESC ) AS rn
// MAGIC    FROM
// MAGIC    (SELECT  $table_name.*
// MAGIC    from
// MAGIC    {rawDB}.$table_name
// MAGIC    inner join global_temp.$parent""" + s"""_micro_batch mb
// MAGIC               on $join_cond
// MAGIC --               where $table_name.$order_col <= mb.$order_col
// MAGIC               )
// MAGIC   ) WHERE rn = 1  )          
// MAGIC   """
// MAGIC   println("Returning in getSubQyeryStr")
// MAGIC   return(sql_final)
// MAGIC }

// COMMAND ----------

class MissingTargetField(s:String) extends Exception(s){}  

def parseLegacyQuery(harmz_query:String, tgtDB:String, tgtTable:String, idCol:String = "NONE") : String 
= {
  
  println("Entering in parseLegacyQuery")
  var defaultVals = Map("TEXT" -> "Not Defined", "FL" -> "U", "INT" -> "0", "STRING" ->  " ", "KEY" -> "NOKEY")
  var defColVals = createDefaultMap(tgtTable)
//   println(defColVals)
  val tblDescDF = spark.sql(s"desc table $tgtDB.$tgtTable")
//   tblDescDF.show()
  println("Original Harmonized Query")
  println(harmz_query + " limit 1")
  var srcColsList = spark.sql(harmz_query + " limit 1").columns.toList
  var tgtColsList = spark.sql(s"select * from $tgtDB.$tgtTable limit1").columns.toList
  srcColsList = srcColsList.map(e => e.toUpperCase)
  tgtColsList = tgtColsList.map(e => e.toUpperCase)
  print(s"Source Columns :\n $srcColsList\n")
  print(s"Target Columns :\n $tgtColsList\n")

  val srcMissCols = (srcColsList.filterNot(tgtColsList.contains(_)))
  val tgtMissCols = (tgtColsList.filterNot(srcColsList.contains(_)))
  var sql_fin = " select distinct "
  
  var surrID = idCol
  if (surrID == "NONE")
  {
    surrID = id_col_name
  }
  println(s"Surrogate Key : $surrID")
  
  if(srcMissCols.length > 0)
    {
      println("SQL Columns missing in Target, please make sure columns created in target ")
      println(srcMissCols)
      throw new MissingTargetField("SQL Columns missing in Target")
    }

  if(tgtMissCols.length > 0)
    {
      println("Target Columns missing in SQL, these columns will be defaulted ")
      println(tgtMissCols)

    for (col <- tgtColsList)
    {
      println(col)
      if((! (col.endsWith(surrID) || col.startsWith("ETL_")  )) ||  col.startsWith("ETL_ROW_EFF_DTS"))
      {
        var defval = "null"
        try
        { 
          defval = defColVals(col.toUpperCase())
        }
        catch 
        { 
          case e: Exception => None 
          defval = "null"
        }
        val colDataType = tblDescDF.filter(s"upper(col_name) = upper('$col')").select("data_type").collect()(0)(0)
        if(srcColsList.contains(col))
        {
          if(colDataType == "int" || colDataType == "double" )
          {
            sql_fin = sql_fin + s"\n cast(NVL($col,$defval) as $colDataType) as $col,"
          }
          else
          {
            sql_fin = sql_fin + s"\n  NVL($col,$defval) as $col,"
          }
        }
        else if(defval != "")
        {
          sql_fin = sql_fin + s"\n $defval as $col,"
        }
        else
        {
          sql_fin = sql_fin + s"\n null as $col,"
        }
      }
    }
   }
  else
  {
    println("Query is uptodate, no defaulting required")
    sql_fin = harmz_query 
  }
  sql_fin = sql_fin.substring(0,sql_fin.length() - 1)
  sql_fin = s"$sql_fin \n FROM \n(\n $harmz_query ) "
  println("Default columns added to the query")
  println("Returning in parseLegacyQuery")
  return(sql_fin)
}

// COMMAND ----------

def mergeAndWrite (df: DataFrame, keyList: List[String], harmonized_table: String,idCol : String,Partition_Val : String) = {
 
  var keyStr = ""
  var keyCond = ""
  for (key <- keyList)
  {
    keyStr = keyStr + key +","
    keyCond = keyCond + " events." + key + " = updates." + key + " and "
  }
  keyStr = keyStr.substring(0, keyStr.length()-1) 
  keyCond = keyCond.substring(0, keyCond.length()-4) 
  
  val w = Window.partitionBy(s"$keyStr".split(",").map(colName => col(colName)): _*).orderBy($"ETL_ROW_EFF_DTS")
  var auditDF = df.withColumn("rownum", row_number.over(w)).where($"rownum" === 1).drop("rownum")  

//   val maxSK = spark.table(s"${harmonized_table}").count 
  val maxSK = spark.sql(s"select ifnull(max($idCol),0) as surrid from $harmonized_table").collect()(0)(0)
  val w1  = Window.orderBy($"ETL_ROW_EFF_DTS")
  
  auditDF = auditDF.withColumn("ETL_ROW_EXP_DTS", lead($"ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N"))
            .withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp())
            .withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999-12-31", "Y").otherwise("N")).withColumn("ID", row_number.over(w1) + maxSK)

  auditDF= auditDF.withColumn(s"$idCol", expr("CAST(ID AS INTEGER)")).drop("ID")
  println("auditDF :"+auditDF.count)
  
  DeltaTable.forName(spark, harmonized_table)
  .as("events")
  .merge(
    auditDF.as("updates"),
    s"$keyCond AND events.md5_hash = updates.md5_hash AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.SOURCE_SYSTEM = 'AQS'")  
  
  .whenMatched
  .updateExpr( 
      Map("ETL_ROW_EXP_DTS" -> "updates.ETL_ROW_EXP_DTS",
          "ETL_CURR_ROW_FL" -> "'N'",
          "ETL_LAST_UPDATE_DTS" -> "current_timestamp()"
         )
    )
  .whenNotMatched
  .insertAll()
  .execute() 
  
}

// COMMAND ----------

def addHashColumn_clt(viewname: String, srgtkey : String) : DataFrame = {
  import org.apache.spark.sql.functions.sha2
  import org.apache.spark.sql.functions.concat_ws
  var allCols = spark.sql(s"select * from global_temp.${viewname}").schema.fieldNames.toList
  println("allCols: "+ allCols)
  val hash_exclude_cols = List("_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","md5_hash",s"$srgtkey") ++ List("ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS")
  println("hash_exclude_cols: "+ hash_exclude_cols)
  val hash_cols = allCols.map(_.toLowerCase) diff hash_exclude_cols.map(_.toLowerCase)
  println("hash_cols: "+ hash_cols)
  val df_new = spark.sql(s""" select * from global_temp.${viewname} """)
  val df_new1 = df_new.drop("MD5_HASH")
  val final_df = df_new1.withColumn("md5_hash", sha2(concat_ws("||", hash_cols.map(col):_*), 256))
  return(final_df)  
}
