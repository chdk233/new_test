// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_pak_ds_party_entity(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
Select distinct
'HV-PAK-'||rtrim(e.policy_prefix_txt)||LPAD(rtrim(e.policy_num_txt), 12, '0')||'-PTYETY-'||substr(cast(date(e.effective_dte) as string),1,4)||'-'||LPAD(CAST(rtrim(f.party_name_id) AS string), 8, '0')||'-'||CAST(a.Type_id AS string) AS PARTY_ENTITY_KEY,
'HV-PAK-'||rtrim(e.policy_prefix_txt)||LPAD(rtrim(e.policy_num_txt), 12, '0')||'-PTY-'||substr(cast(date(e.effective_dte) as string),1,4)||'-'||LPAD(CAST(rtrim(f.party_name_id) AS string), 8, '0')||'-'||CAST(a.Type_id AS string)  AS PARTY_KEY,
ifnull(rtrim(e.Source_system_txt), ' ') as SOURCE_SYSTEM,
'HV-PAK' AS PARTITION_VAL,
ifnull(rtrim(f.Full_nme), ' ') AS ENTITY_NAME,
ifnull(rtrim(a.legal_entity_cde), ' ') as PARTY_ENTITY_TYPE,
ifnull(e.Start_dte,to_timestamp('1900-01-01','yyyy-mm-dd')) AS ETL_ROW_EFF_DTS
from global_temp.party_micro_batch6 micro_party
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY party_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT PARTY.*
from
{rawDB}.PARTY
inner join global_temp.party_micro_batch6 mb
on mb.party_id = PARTY.party_id
-- where PARTY.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) a
ON micro_party.party_id = a.party_id
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY identifier ORDER BY End_dte DESC ) AS rn
FROM
(SELECT party_role_in_acct.*
from
{rawDB}.party_role_in_acct
inner join global_temp.party_micro_batch6 mb
on mb.party_id = party_role_in_acct.party_id
-- where PARTY.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) b
ON a.party_id = b.party_id
and b.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Insured_account_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT insured_account.*
from
{rawDB}.insured_account
)
) WHERE rn = 1 ) c
on b.account_id = c.account_id
and c.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY identifier ORDER BY End_dte DESC ) AS rn
FROM
(SELECT policy_acct_rl.*
from
{rawDB}.policy_acct_rl
)
) WHERE rn = 1 ) d
on c.account_id = d.account_id
and d.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY policy_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT policy.*
from
{rawDB}.policy
)
) WHERE rn = 1 ) e
on d.policy_id = e.policy_id
and e.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Party_name_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT party_name.*
from
{rawDB}.party_name
inner join global_temp.party_micro_batch6 mb
on mb.party_id = party_name.party_id
-- where party_name.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) f
on a.party_id = f.party_id
and f.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
where a.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
and date(e.effective_dte) >= '2009-12-31'
and rtrim(e.Source_system_txt) = 'AQS'
  """
  
  
    microBatchDF.createOrReplaceGlobalTempView(s"party_micro_batch6")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.party_micro_batch_hv_pak_partyentity")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","PARTY_ENTITY_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("PARTY_ENTITY_KEY","ETL_ROW_EFF_DTS"),harmonized_table,"PARTY_ENTITY_ID","HV-PAK")
//     queryDF.show(3,false)

}