// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

// MAGIC %run ./_pcio_utils

// COMMAND ----------

def merge_hv_pak_ds_addr(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {
  
    print("microBatchDF...in doHarmonize: \n")
    microBatchDF.show(false)
  
  //  RUN HARMONIZATION QUERY
  //  -----------------------  
    var harmz_query = s""" 
   SELECT T1.ADDR_KEY,T1.ETL_ROW_EFF_DTS,T1.STREET_1_NAME,T1.STREET_2_NAME,T1.CITY_NAME,T1.REGION_CD,T1.POSTAL_CD,T1.SOURCE_SYSTEM,T1.PARTITION_VAL FROM (
Select distinct 'HV-PAK-' || rtrim(e.policy_prefix_txt) || LPAD(rtrim(e.policy_num_txt), 12, '0') || '-ADD-' || substr(cast(date(e.effective_dte) as string), 1, 4) || '-' || LPAD(CAST(rtrim(f.party_name_id) AS string), 8, '0') || '-' || CAST(a.Type_id AS string) || '-' || substr(cast(date(e.Start_dte) as string), 1, 4) || substr(cast(date(e.Start_dte) as string), 6, 2) AS ADDR_KEY,
ifnull(e.Start_dte,to_timestamp('1900-01-01', 'yyyy-mm-dd')) AS ETL_ROW_EFF_DTS,
ifnull(rtrim(g.Address_line_1_txt), ' ') as STREET_1_NAME,
ifnull(rtrim(g.Address_line_2_txt), ' ') as STREET_2_NAME,
ifnull(rtrim(g.City_txt), ' ') as CITY_NAME,
ifnull(rtrim(g.State_abbrev_cde), ' ') as REGION_CD,
ifnull(rtrim(g.Postal_code_txt), ' ') as POSTAL_CD,
ifnull(rtrim(e.Source_system_txt), ' ') as SOURCE_SYSTEM,
'HV-PAK' AS PARTITION_VAL,
g.party_id AS G_PARTY_ID,
g.Contact_point_id AS G_CONTACT_PT_ID
from global_temp.party_micro_batch2 micro_party
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY party_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT PARTY.*
from
{rawDB}.PARTY
inner join global_temp.party_micro_batch2 mb
on mb.party_id = PARTY.party_id
-- where PARTY.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) a
ON micro_party.party_id = a.party_id
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY identifier ORDER BY End_dte DESC ) AS rn
FROM
(SELECT party_role_in_acct.*
from
{rawDB}.party_role_in_acct
inner join global_temp.party_micro_batch2 mb
on mb.party_id = party_role_in_acct.party_id
-- where PARTY.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) b
ON a.party_id = b.party_id
and b.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Insured_account_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT insured_account.*
from
{rawDB}.insured_account
)
) WHERE rn = 1 ) c
on b.account_id = c.account_id
and c.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY identifier ORDER BY End_dte DESC ) AS rn
FROM
(SELECT policy_acct_rl.*
from
{rawDB}.policy_acct_rl
)
) WHERE rn = 1 ) d
on c.account_id = d.account_id
and d.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY policy_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT policy.*
from
{rawDB}.policy
)
) WHERE rn = 1 ) e
on d.policy_id = e.policy_id
and e.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Party_name_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT party_name.*
from
{rawDB}.party_name
inner join global_temp.party_micro_batch2 mb
on mb.party_id = party_name.party_id
-- where party_name.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) f
on a.party_id = f.party_id
and f.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
inner join
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Contact_point_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT contact_point.*
from
{rawDB}.contact_point
inner join global_temp.party_micro_batch2 mb
on mb.party_id = contact_point.party_id
-- where contact_point.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) g
on a.party_id = g.party_id
and g.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
where  a.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy')
and date(e.effective_dte) >= '2009-12-31'
and a.Type_id <> 7397
and rtrim(e.Source_system_txt) = 'AQS') T1
inner join (select l.party_id as lparty_id, min(l.Contact_point_id) as CONTACT_PT_ID from 
( SELECT * FROM
( SELECT *, row_number() over ( partition BY Contact_point_id ORDER BY End_dte DESC ) AS rn
FROM
(SELECT contact_point.*
from
{rawDB}.contact_point
inner join global_temp.party_micro_batch2 mb
on mb.party_id = contact_point.party_id
-- where contact_point.End_dte <= mb.End_dte
)
) WHERE rn = 1 ) l
where l.end_dte = to_timestamp('12-31-9999','MM-dd-yyyy') group by l.party_id) T2
on T1.G_PARTY_ID = T2.lparty_id
and T1.G_CONTACT_PT_ID = T2.CONTACT_PT_ID
  """
  
 
    microBatchDF.createOrReplaceGlobalTempView(s"party_micro_batch2")
    println("microBatchDFcount :"+microBatchDF.count)
  
    microBatchDF.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("dhf_legacy_pcio_prem_harmonised_pt.party_micro_batch_hv_pak_addr")
  
    harmz_query=harmz_query.replace("{rawDB}", rawDB) 
    harmz_query = parseLegacyQuery(harmz_query,harmonizedDB,target)
    println("harmz_query after rawDB replace: \n"+ harmz_query)
    
    val harmonized_table = s"${harmonizedDB}.${target}"
    val queryDF=microBatchDF.sparkSession.sql(harmz_query)
    println("Harmonized query execution completed..")
    println("QueryDFCount :"+queryDF.count)
    queryDF.createOrReplaceGlobalTempView(s"V")
    val hashDF = addHashColumn_clt("V","ADDR_ID") // pass the ID column name
    mergeAndWrite(hashDF,List("ADDR_KEY","ETL_ROW_EFF_DTS"),harmonized_table,"ADDR_ID","HV-PAK")
//     queryDF.show(3,false)
    
}