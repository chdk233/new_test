// Databricks notebook source
// MAGIC %run ../../../harmonization/_event_harmonizer_library

// COMMAND ----------

def merge_cc_claim_ph2(microBatchDF: org.apache.spark.sql.Dataset[Row], batchId: Long, rawDB: String, harmonizedDB: String, target: String) = {   

                        print("\n entering merge_cc_claim_ph2 \n") 
                        val harmonized_table = harmonizedDB +"."+target
                        val key = "claim_id,address_id"

                        // Add Hash
                        microBatchDF.createOrReplaceGlobalTempView("V")
                        val hashDF = addHashColumn_clt_old("V")

                        // Dedup
                        val dedupDF = removeDuplicates_clt_old(hashDF, harmonized_table, key)

                        // Add Audit Columns
                        val auditDF = addAuditColumns_clt(dedupDF, key)

                        // Add SurrogateKey
                        val surrogateKeyDF = addSurrogateKey_clt(auditDF, harmonized_table)

                        //Merge Type2
                        defaultMerge_clt(surrogateKeyDF, harmonized_table)
}
