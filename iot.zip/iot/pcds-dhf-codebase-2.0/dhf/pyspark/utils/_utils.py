# Databricks notebook source
import json
from datetime import datetime
from datetime import date
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,LongType, DateType,TimestampType
from  pyspark.sql.functions import *
import time
import builtins

##For Email
import smtplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from string import Template

#for API
import os
import requests
import ssl
from urllib3.exceptions import InsecureRequestWarning

#for making taskgroup Inactive
import psycopg2

#for datakey Generation from AWS KMS
import base64
import boto3


# COMMAND ----------

token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().getOrElse(None)
dbhost = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().getOrElse(None)
workspaceID=json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()).get('tags', {}).get('orgId', None)

# COMMAND ----------

scope_name =f"dhf_{environment}" 


token    = dbutils.secrets.get(scope = scope_name, key = "JOBTOKEN")
hostName = dbutils.secrets.get(scope = scope_name, key = "PGHOST_NEW") # New postgregsql conn
pgPort   = dbutils.secrets.get(scope = scope_name, key = "PGPORT") # 5432
dbName   = dbutils.secrets.get(scope =scope_name, key = "PGDATABASE_NEW") # New postgregsql conn
user     = dbutils.secrets.get(scope = scope_name, key = "PGUSER_NEW") # New postgregsql conn
password = dbutils.secrets.get(scope = scope_name, key = "PGPASSWORD_NEW") # New postgregsql conn

currentSchema = ""
if(environment == "dev"):
  #currentSchema = "dhfconfigdevl"
  currentSchema = "dhfconfigdev"
elif(environment == "test"):
  currentSchema = "dhfconfigtest"
elif(environment == "prod"):
  currentSchema = "dhfconfigprod"


driverClass = "org.postgresql.Driver"   
jdbcUrlForConfigDB = f"jdbc:postgresql://{hostName}:{pgPort}/{dbName}"

sqlConnectionProperties = {
  "url":jdbcUrlForConfigDB,
  "user": user,
  "password": password,
  "currentSchema": currentSchema,
  "Driver": driverClass
}



# COMMAND ----------

def get_orchestration_domain_name(group_id):
  
  pushdown_query_tg = f"""(select task_group_newdomain_source_id as taskGroup_domain from dhfconfigdev.task_group_new_msapps where job_group_id ={group_id}) t"""
  pushdown_query_ws = f"""(select data_domain_id as warehouseSync_domain from dhfconfigdev.warehouse_sync_new_msapps where job_group_id ={group_id}) ws"""
  pushdown_query_ing = f"""(select domain as ingestion_domain from dhfconfigdev.ingestion_task_group where job_group_id ={group_id}) ing"""

  # print("pushdown_query ", pushdown_query)
  tg_domain_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query_tg).load()
  ws_domain_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query_ws).load()
  ing_domain_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query_ing).load()
  
  domain_id_list=list(map(lambda row:row.asDict(),ing_domain_df.collect())) + list(map(lambda row:row.asDict(),tg_domain_df.collect())) +  list(map(lambda row:row.asDict(),ws_domain_df.collect()))    

  print("Associated domains :::: ", domain_id_list, "in the order of 1. ingestion, 2.Harmonization/Curation(taskgroup), 3.Warehouse Sync; First available entry's domain will be picked for deciding e2h_job_creation_log_table schema")
  
  all_domain_ids = [[value for key,value in _.items() if value is not None and value !='None'] for _ in domain_id_list]
  non_empty_domain_ids = [_ for _ in all_domain_ids if len(_)>0]
  print("domain_ids",non_empty_domain_ids)
  domain_id = non_empty_domain_ids[0][0] if len(non_empty_domain_ids)>0 else None
  if domain_id:
    return getDomainName(domain_id)
  else:
    raise Exception("Please verify if domain id is passed")

# COMMAND ----------

def getTaskGroup(taskGroupId) :
  
  pushdown_query = f"(select * from task_group_new_msapps where id ={taskGroupId} and active ) t"
  print("pushdown_query ", pushdown_query)
  taskGroup_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  
  taskGroupList=list(map(lambda row:row.asDict(),taskGroup_df.collect()))              
  print("taskGroupList is :::: ", taskGroupList)



  if( len(taskGroupList)>1) :
    raise Exception("There should NOT be more than one entry for a task group in task_group table for a specific job_type. Please correct and resubmit the job")
  return taskGroupList[0]



# COMMAND ----------

def getTask(taskGroupId, job_type) :
  
  whereCond =  f""" WHERE task_group_id={taskGroupId} and  active """
  pushdown_query = f""" (select * from task_new_msapps {whereCond} ) t""" 
  
  task_df=spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  
  task=list(map(lambda row:row.asDict(),task_df.collect()))              
 
  return(task)



# COMMAND ----------

def makingTaskGroupInactive(task_group_id):
  try:
    conn = psycopg2.connect(host=hostName, dbname=dbName, user=user, password=password)
    cur = conn.cursor()
    cur.execute(f"""update {currentSchema}.task_group_new  set active='false' where id={task_group_id} """)
    conn.commit()
  except Exception as e :
    print("Failed to connect to ProstegreSQL with Exception",e)

# COMMAND ----------

def getGroup(groupId) :
  pushdown_query = f""" (select  * from job_group_new_msapps   where  id ={groupId} ) t """
  print("pushdown_query is ",pushdown_query)
  
  groupId_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  
  groupIdList=list(map(lambda row:row.asDict(),groupId_df.collect())) 
  print("GroupIdList is :::: ", groupIdList)
  
  
  if( len(groupIdList)>1) :
       raise Exception("There should NOT be more than one entry for a group_id in group_id table for a specific run_type. Please correct and resubmit the job")
      
  return groupIdList[0]

def get_temp_tasks_list(temp_group_id) :

  pushdown_query = f""" (select  * from temp_task_new_msapps  where active and  temp_group_id ={temp_group_id} ) t """
  print("pushdown_query is ",pushdown_query)
  temp_table_task_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  temp_table_task_list=list(map(lambda row:row.asDict(),temp_table_task_df.collect())) 
  print("Temp Tasks List is :::: ", temp_table_task_list)
  
  return temp_table_task_list

# COMMAND ----------

def getConfig(domain_source_id) :
  pushdown_query = f""" (select property_values from domain_source_msapps  where id ={domain_source_id} ) t"""
  print("pushdown_query is ",pushdown_query)
  
  Config_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  configList=Config_df.rdd.flatMap(lambda x: x).collect()
  print("configList is :::: ", configList)
  
  if(len(configList)==0 ) :
       raise Exception(f"no configuration found for domain_source_id {domain_source_id} in domain_source table. Please correct and resubmit the job")
      
  if( len(configList)>1) :
    raise Exception(f"There should NOT be more than one entry for a domain_source_id {domain_source_id} in domain_source table. Please correct and resubmit the job")
    
  return configList[0]
    
  

# COMMAND ----------

def getCheckpoint(domain_source_id) :
  pushdown_query = f""" (select check_point_base_directory from domain_source_msapps  where id ={domain_source_id} ) t"""
#   print("pushdown_query is ",pushdown_query)
  
  Config_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  configList=Config_df.rdd.flatMap(lambda x: x).collect()
#   print("configList is :::: ", configList)
  
  if(len(configList)==0 ) :
       raise Exception(f"no configuration found for domain_source_id {domain_source_id} in domain_source table. Please correct and resubmit the job")
      
  if( len(configList)>1) :
    raise Exception(f"There should NOT be more than one entry for a domain_source_id {domain_source_id} in domain_source table. Please correct and resubmit the job")
    
  return configList[0].strip()

# COMMAND ----------

#added as part of the aws instance profile
def getDomainName(domain_source_id) :
  pushdown_query = f""" (select name from domain_source_msapps  where id ={domain_source_id} ) t"""
#   print("pushdown_query is ",pushdown_query)
  
  Config_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  configList=Config_df.rdd.flatMap(lambda x: x).collect()
#   print("configList is :::: ", configList)
  
  if(len(configList)==0 ) :
       raise Exception(f"no configuration found for domain_source_id {domain_source_id} in domain_source table. Please correct and resubmit the job")
      
  if( len(configList)>1) :
    raise Exception(f"There should NOT be more than one entry for a domain_source_id {domain_source_id} in domain_source table. Please correct and resubmit the job")
    
  return configList[0].strip()

# COMMAND ----------



def getPropertyValue(propertyName, yamlString) :
  keyValueArray=yamlString.split(" ")
  for keyValue in keyValueArray:
    if propertyName in keyValue:
      valueList=keyValue.split("#")
      value=str(valueList[1]).strip()
      return value
  return ""



# COMMAND ----------

def getWarehouseTaskList(groupId) :
  
  pushdown_query = f""" ( select whtg.* , min_threshold,max_threshold from warehouse_sync_new_msapps whtg inner join job_threshold_config_new_msapps tc on whtg.id=tc.pipeline_stage_param where job_group_id ={groupId} and tc.pipeline_stage=\'WAREHOUSE_SYNC\' and active ) t"""
  
  print("pushdown_query is : ",pushdown_query)
  
  warehouseGroup_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  warehouseGroupList=list(map(lambda row:row.asDict(),warehouseGroup_df.collect())) 
  
  print("warehouseGroupList is :::: ", warehouseGroupList)
  
  return warehouseGroupList

# COMMAND ----------

def getTaskGroupList(groupId) :
  
  pushdown_query = f""" (select tg.*,min_threshold,max_threshold from task_group_new_msapps tg inner join job_threshold_config_new_msapps tc on tg.id=tc.pipeline_stage_param where job_group_id ={groupId} and tc.pipeline_stage=\'HARMONIZATION\' and active ) t""" #UI_related_updtae group_id to job_group_id
  
  print("pushdown_query is : ",pushdown_query)
  
  taskGroup_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  
  taskGroupList=list(map(lambda row:row.asDict(),taskGroup_df.collect()))

  print("taskGroupList is :::: ", taskGroupList)
  
  return taskGroupList

# COMMAND ----------

def getCurationTaskGroupList(groupId):
  
  pushdown_query = f""" (select tg.*,min_threshold,max_threshold from  task_group_new_msapps tg inner join job_threshold_config_new_msapps tc on tg.id=tc.pipeline_stage_param  where  job_group_id ={groupId} and tc.pipeline_stage=\'DATA_CURATION\' and active ) t""" #UI_related_updtae group_id to job_group_id
  
  print("pushdown_query is : ",pushdown_query)
  
  taskGroup_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  taskGroupList=list(map(lambda row:row.asDict(),taskGroup_df.collect())) 
  
  print("taskGroupList is :::: ", taskGroupList)
  
  return taskGroupList

# COMMAND ----------

# DBTITLE 1,Operational Metrics
context=json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
jobId=context.get('tags', {}).get('jobId', None) 
run_id_obj = context.get('currentRunId', {})
runId = run_id_obj.get('id', None) if run_id_obj else None 
clusterId=context.get('tags', {}).get('clusterId', None)
job_name=str(context.get('tags', {}).get('jobName', "Test"))


# COMMAND ----------


MetricCCPerBatch = StructType([ \
    StructField("group_id",StringType(),True), \
    StructField("job_id",StringType(),True), \
    StructField("job_type",StringType(),True), \
    StructField("run_type", StringType(), True), \
    StructField("run_id", StringType(), True), \
    StructField("batch_id", LongType(), True), \
    StructField("batch_size", LongType(), True), \
    StructField("batch_duration_min", StringType(), True) ,\
    StructField("batch_start_time", StringType(), True), \
    StructField("task_group_id", LongType(), True), \
    StructField("task_id", LongType(), True) ,\
    StructField("source_table", StringType(), True), \
    StructField("target_table", StringType(), True) ,\
    StructField("clusterId", StringType(), True) \
  ])

MetricCCPerBatch_ext = StructType([ \
    StructField("TaskGroupId",IntegerType(),True), \
    StructField("JobType",StringType(),True), \
    StructField("Run_Id",StringType(),True), \
    StructField("Status",StringType(),True), \
    StructField("InsertDate",DateType(),True), \
    StructField("InsertTime", TimestampType(), True)
                                  ])

MetricCCPerBatch_temp = StructType([ \
    StructField("temp_group_id",StringType(),True), \
    StructField("temp_task_id",StringType(),True), \
    StructField("temp_table_name",StringType(),True), \
    StructField("operation",StringType(),True), \
    StructField("Job_Id",StringType(),True), \
    StructField("Run_Id",StringType(),True), \
    StructField("Status",StringType(),True), \
    StructField("InsertDate",DateType(),True), \
    StructField("InsertTime", TimestampType(), True)
                                  ])
def persistLog_temp(jobMetrics, logTable) :
  df = spark.createDataFrame(jobMetrics,MetricCCPerBatch_temp).coalesce(1)
  df.write.format("delta").mode("append").partitionBy("InsertDate").saveAsTable(f"{logTable}")
  
def persistLog_external(jobMetrics, logTable) :
  df = spark.createDataFrame(jobMetrics,MetricCCPerBatch_ext).coalesce(1)
  pipelineLogTable = logTable.split(".")[0] + ".dhf_pipeline_status_metrics"
  df.write.format("delta").mode("append").partitionBy("InsertDate").saveAsTable(f"{pipelineLogTable}")

def persistLog(jobMetrics, logTable) :
  df = spark.createDataFrame(jobMetrics,MetricCCPerBatch).coalesce(1)
  
  df=df.withColumn("db_load_date",to_date(col('batch_start_time'))) 
  df.write.format("delta").mode("append").partitionBy("db_load_date").saveAsTable(f"{logTable}")
  

def persistLog_multitable(param_str,target_table):
  param_lst=param_str.split("#")
  jobMetrics=[[param_lst[0],param_lst[1],param_lst[2],param_lst[3],param_lst[4],int(param_lst[5]),int(param_lst[6]),"","",int(param_lst[7]),0,"", str(target_table + "_multi_table"),param_lst[8]]]
  
  df = spark.createDataFrame(jobMetrics,MetricCCPerBatch).coalesce(1)
  df=df.withColumn("db_load_date",lit(date.today()))
  df.write.format("delta").mode("append").partitionBy("db_load_date").saveAsTable(f"{metricsLogTable}")
  

# COMMAND ----------

WarehousePerBatch = StructType([ \
    StructField("group_id",StringType(),True), \
    StructField("job_id",StringType(),True), \
    StructField("job_type",StringType(),True), \
    StructField("run_type", StringType(), True), \
    StructField("run_id", StringType(), True), \
    StructField("batch_id", LongType(), True), \
    StructField("batch_size", LongType(), True), \
    StructField("batch_duration_min", StringType(), True) ,\
    StructField("batch_start_time", StringType(), True), \
    StructField("task_id", LongType(), True), \
    StructField("source_table", StringType(), True), \
    StructField("target_table", StringType(), True) ,\
    StructField("clusterId", StringType(), True) \
  ])



def warehousePersistLog(jobMetrics, logTable) :
  
  df = spark.createDataFrame(jobMetrics,WarehousePerBatch).coalesce(1)
  
  df=df.withColumn("db_load_date",to_date(col('batch_start_time')))
  
  df.write.format("delta").mode("append").partitionBy("db_load_date").saveAsTable(f"{logTable}")


# COMMAND ----------

# DBTITLE 1,Phase 4 Alerting and Monitoring
def pushToSplunk(event):
  try:
    jsonForSplunk = event
    splunkToken = dbutils.secrets.get(scope = scope_name, key = "splunk_token")
    splunkEndPoint= dbutils.secrets.get(scope = scope_name, key = "splunk_endpoint")

    api_out = requests.post(
      splunkEndPoint,
      headers={'Authorization': 'Splunk %s' % splunkToken , 'Content-Type': 'application/json'},
      json=jsonForSplunk
    )
   
    #print(api_out.json() )

  except Exception as e:
    print("Post to Splunk Failed",e)

# COMMAND ----------

def sendToSplunk(groupId, jobId, jobName, jobType, runType, runId, batchId, batchSize, start, totalTimeBatchMin, taskGroupId, taskId, source, harmonizedTable, clusterId, status):
  
  sourcetype= "DHFjobauditing_json"
  jsonForSplunkApi = {
                      'index': 'pc-dhf',
                      'host': 'datacollector4-d757dfc4d-fpn5k',
                      'source': 'test-streamsets-data-collector',
                      'sourcetype': f'{sourcetype}',
                      'event': { 'group_id': f'{groupId}',
                                 'job_id': f'{jobId}',
                                 'job_name': f'{job_name}',
                                 'job_type': f'{jobType}',
                                 'run_type': f'{runType}',
                                 'run_id': f'{runId}',
                                 'batch_id': f'{batchId}',
                                 'batch_size': f'{batchSize}',
                                 'total_batch_time': f'{totalTimeBatchMin}',
                                 'start_time': f'{start}',
                                 'task_group_id': f'{taskGroupId}',
                                 'task_id': f'{taskId}',
                                 'source_table': f'{source}',
                                 'target_table': f'{harmonizedTable}',
                                 'cluster_id': f'{clusterId}',
                                 'status': f'{status}'
                               }
  }
  

  print(f"Sending {status} Log info to splunk for {jobType}, batchid: {batchId},taskid: {taskId},taskgroup: {taskGroupId} ")
  pushToSplunk(jsonForSplunkApi)
  
  
 

# COMMAND ----------

# DBTITLE 1,SNOW TICKET PAYLOAD new one
def generatePayload(customerEventIdentifier,message, eventDetail, ticketSeverity, ticketGroup) :
  date_time=datetime.now()
  print(date_time)
  snow_app_key = dbutils.secrets.get(scope = scope_name, key = "bp_snow_app_key")
   
  jsonForNewSnow = {
"app_key": snow_app_key,
"primary_property":"bp_host",
"secondary_property":"bp_check",
"status": "critical",
"bp_description": f"{message}",
"bp_host":"DHF Job Issue",
"bp_check":f"{customerEventIdentifier}",
"bp_assignment_group": ticketGroup,
"bp_priority": ticketSeverity,
"any other fields": "You can add as many fields as desired, each field up to 2048 characters"
  }
   
  return jsonForNewSnow


# COMMAND ----------

#dhf_delta_incident_log table creation

SnowIncident = StructType([ \
    StructField("incident_number",StringType(),True), \
    StructField("job_type",StringType(),True), \
    StructField("job_id",StringType(),True), \
    StructField("run_id", StringType(), True), \
    StructField("group_id", StringType(), True), \
    StructField("task_group", StringType(), True), \
    StructField("task_id", StringType(), True), \
    StructField("created_date", StringType(), True) ,\
    StructField("incident_message", StringType(), True)
  ])



def incidentPersistLog(jobMetrics, logTable) :
  
  incidentLogTable = logTable.split(".")[0] + ".dhf_delta_incident_log"
  df = spark.createDataFrame(jobMetrics,SnowIncident).coalesce(1)
  
  df=df.withColumn("db_load_date",to_date(col('created_date')))
  
  df.write.format("delta").mode("append").partitionBy("db_load_date").saveAsTable(f"{incidentLogTable}")


# COMMAND ----------

# DBTITLE 1,SNOW TICKET FUNCTION- Parameterized 
def getUserPropertyValue(param,phrase):
  
  if phrase is not None and isinstance(phrase, str):
    splitted_param = phrase.split("#")
    required_param_pair = [param_pair for param_pair in splitted_param if param in param_pair]

    if len(required_param_pair) != 0:
      if "insta_profile" in required_param_pair[0]:
        return required_param_pair[0][required_param_pair[0].index(":")+1:len(required_param_pair[0])]
      else:
        return required_param_pair[0].split(":")[1]
    else:
      return None
  
  else:
    return None

#================================================================================================================================================


def createSnow(JobId, JobType, task_group, RunId, taskiD, groupId, job_name, customerEventIdentifier, message, eventDetail, counter,servicenow_property,metricsLogTable):
  Ticket_Number = ""
  counter_inc = counter
  try:
    if servicenow_property != None:
      ticketSeverity = getUserPropertyValue('severity',servicenow_property)
      ticketGroup = getUserPropertyValue('ticketGroup',servicenow_property)
      print("inside snow ticketing")
      print(f"ticketGroup: {ticketGroup}, ticketSeverity: {ticketSeverity}")

      if ticketGroup != None:
        if ticketSeverity == None:
          ticketSeverity = "P4"
        print(f"ticketGroup: {ticketGroup}, ticketSeverity: {ticketSeverity}") #toparameterize ticketSeverity, ticketGroup


        jsonForNewSnow = generatePayload(customerEventIdentifier, message, eventDetail, ticketSeverity, ticketGroup) #toadd

        snowEndPoint = dbutils.secrets.get(scope = scope_name, key = "bp_snow_endpoint")
        token = dbutils.secrets.get(scope = scope_name, key = "bp_snow_token")


        requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
        api_out = requests.post(
        snowEndPoint,
        headers={"Accept": "application/json",
                 "Authorization": token,
                 "Content-Type": "application/json"},
        json=jsonForNewSnow,
        verify=False
      )
        
        print(api_out)
        Ticket_Number="https://a.bigpanda.io/login"
        print("Bigpanda URL:=======", Ticket_Number)


#         Ticket_Number=api_out.json()['entry']['TicketNum']

#         if ("INC" not in Ticket_Number):
#           print(f"Ticket not created in {counter_inc} attempt. Sleeping for 90 sec")
#           time.sleep(90)
#           counter_inc = counter_inc + 1
#           if counter_inc <= 5:
#          #Calling snow fucntion to create ticket
#             Ticket_Number = createSnow(JobId, JobType, task_group, RunId, taskiD, groupId, job_name, customerEventIdentifier, message, eventDetail, counter_inc,user_properties)
#           else:
#             print("Ticket Number is not generated. As it exceeds time")

#         else:
#           print(f"Ticket Number {Ticket_Number}: generated successfully for taskid {taskiD} failure")
#         #Logging the Incident details in the Incident Log table

        jobMetrics=[[Ticket_Number, JobType, str(jobId), RunId, str(groupId), str(task_group), str(taskiD), str(datetime.now()), eventDetail]]
        incidentPersistLog(jobMetrics, metricsLogTable)

 
      else:
        print("ticket grp not defined, didnt create ticket")
        Ticket_Number = "No ticket generated as ticketGroup is not provided in taskGroup/warehouse_task"
    else:
      print("user input is None, didnt create ticket")
      Ticket_Number = "No ticket generated as Servicenow property field is left empty in taskGroup/warehouse_task"

  except Exception as e:
    failMsg = "API FAILED"
    description = f"failMsg: {e}"
    print(f"SNOW ticket creation failed, {Ticket_Number} is not available in JSON: ", description)
    Ticket_Number = "No ticket generated"
  
  return Ticket_Number


# COMMAND ----------

# DBTITLE 1,Function to check time for inline optimization
def isOptimizeTableTime(runTypeUpper, triggerOnce, optimizeStartHour, optimizeEndHour):
  currentEDTTimeInHour = spark.sql("select hour(from_utc_timestamp(current_timestamp, 'EST'))").collect()[0][0]

  return not runTypeUpper==triggerOnce and currentEDTTimeInHour >=  optimizeStartHour and currentEDTTimeInHour < optimizeEndHour




# COMMAND ----------

# DBTITLE 1,inline Optimization
def optimizeDeltaTable(taskGroup):
  silverDB= taskGroup['target_db']
  deltaTable = taskGroup['target_table']
  pkCols = taskGroup['z_order_cols']
  optimizeStartHour= int(str(taskGroup['optimize_start_hour']))
  optimizeEndHour = int(str(taskGroup['optimize_end_hour']))
  runTypeUpper = taskGroup['run_type']
  retention_hrs_vacuum = taskGroup['retention_hrs_vacuum']
  triggerOnce="AVAILABLE_NOW" 
  isOptimizeTime = isOptimizeTableTime(runTypeUpper, triggerOnce, optimizeStartHour, optimizeEndHour)
  round = getattr(builtins, "round")
  if isOptimizeTime:
    zorderColumns = ",".join([i.strip().upper() for i in pkCols.split(",")])
    sql = f"""optimize {silverDB}.{deltaTable} ZORDER BY {zorderColumns} """
    currentTimeStart = time.time()
    startTime = round(currentTimeStart*1000)
    print(f"{datetime.now()}: Optimize job is starting with QUERY: {sql}")
    try:
      spark.sql(sql)
    except Exception as e:
      print("Optimize Failed",e)

    currentTimeEnd = time.time()
    endTime = round(currentTimeEnd*1000)
    totalTime = (endTime - startTime) / (1000.0 * 60)
    print(f"{datetime.now()}: Optimize completed for {silverDB}.{deltaTable}. Took {totalTime} mins")
    if retention_hrs_vacuum != None:
      print(f"{datetime.now()}: Vacuum job is starting")
      currentTimeStart = time.time()
      startTime = round(currentTimeStart*1000)
      try:
        spark.sql(f"VACUUM {silverDB}.{deltaTable} RETAIN {retention_hrs_vacuum} HOURS") 
      except Exception as e:
        print("Vacuum Failed",e) 
        
      currentTimeEnd = time.time()
      endTime = round(currentTimeEnd*1000)
      totalTime = (endTime - startTime) / (1000.0 * 60)
      print(f"{datetime.now()}: Vacuum completed for {silverDB}.{deltaTable}. Took {totalTime} mins")
    else:
      print("Vacuum cannot will not be performed since retention period is empty")
  else:
    print("Current Time is not b/w start and end hour of optimization.Skipping optimization & vacuum")

# COMMAND ----------

# DBTITLE 1,Send Email Using SMTP
def sendEmail(toEmails , fromEmail, subject, body):
  
  mail_smtp_host= dbutils.secrets.get(scope = scope_name, key = "mail_smtp_host")
  mail_smtp_port= dbutils.secrets.get(scope = scope_name, key = "mail_smtp_port")
  
  print("email--" ,toEmails)
  
  try:
    if toEmails !=None  :
        
        toEmailList= toEmails.split(",")
        
        msg = MIMEMultipart()
        msg['From'] = fromEmail 
        msg['To'] = toEmails
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'html'))
        text = msg.as_string()
        
        server = smtplib.SMTP(mail_smtp_host, mail_smtp_port)
        server.sendmail(fromEmail, toEmailList, text)
 
    else :
      print("Email list is empty.No email will be sent.")
    
    
  
  except Exception as e:
    
    print("Mail delivery failed !!! " , e)
  

# COMMAND ----------

# DBTITLE 1,HTML E-Mail formatting
def format_email(errorMsg, changeTicket, jobUrl, jobId, jobName,message) :
    error_msg = errorMsg
    change_ticket = changeTicket
    Job_Url = jobUrl
    Job_Id = jobId
    Job_Name = jobName
    Job_description = message
    if "No ticket generated".lower() in change_ticket.lower():
      snow_message_details = "No Incident created"
    else:
      snow_message_details = f"Open the Bigpanda url. After login, navigate from the left side menu to Alert Source -> Self Service API. To locate your alert kindly enter a search term to narrow the view to just your recently set alert, bp_description=\"{Job_description}\""

    html_body = Template("""<!DOCTYPE html>
    <html>
    <head>
    </head>
    <style>
        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        </style>
    <body><p> Good Day! </p>
    <p>$message, find the details below: </p> 
    <table style="width:90%">
      <tr>
        <th>Items</th>
        <th>Details</th>

      </tr>
      <tr>
        <td>Job-Name</td>
        <td>$Job_Name</td>

      </tr>
      <tr>
        <td>Job Id</td>
        <td><a href="$Job_Url">$Job_Id</td>

      </tr>

      <tr>
        <td>Error Message</td>
        <td>$error_msg</td>

      </tr>

      <tr>
        <td>Bigpanda URL </td>
        <td><a href="">$change_ticket</td>

      </tr>
      
      <tr>
        <td>Search Incident </td>
        <td>$snow_message_details</td>
      </tr>
    </table>
    <p>NOTE : PLEASE DO NOT REPLY. This email is generated by an automated system.For any issues or concern related to Framework, connect to DHF Team</p>
    <p>DHF Team</p>
    <table1 style="width:100%">
    

    </body>
    </html>""")

       
    html_body=html_body.substitute(message=message,Job_Name=Job_Name,Job_Url=Job_Url,Job_Id=Job_Id,error_msg=error_msg,change_ticket=change_ticket,snow_message_details=snow_message_details)
    return html_body

# COMMAND ----------


def errorHandler(errorType,job_name,groupId,jobId,jobType,runId,batchId,maxThreshold,minThreshold,totalBatchTimeInMins,taskGroupId,taskId,errorMessage,to,servicenow_property,metricsLogTable):
  customerEventIdentifier=""
  message=""
  eventDetail=""
  ticketNum=""
  html_body=""
  fromEmail="dhfsid@nationwide.com"
  sub=""
  body=""
  jobUrl = f"https://nationwide-pcds-{environment}-virginia.cloud.databricks.com/?o={workspaceID}#job/{jobId}"
  
  if errorType=="minThreshold":
    if jobType == "WAREHOUSE_SYNC":
      message = f"Mininum Threshold Breached: JobId: {jobId}, Taskid: {taskId}, Batchid: {batchId}"
      eventDetail = f"The Groupid: {groupId}, Taskid: {taskId}, RunId: {runId}, Batchid: {batchId} has breached the min threshold: {minThreshold}. The total batch time: {totalBatchTimeInMins}"
    else:
      message = f"Mininum Threshold Breached: JobId: {jobId}, TaskgroupId: {taskGroupId}, Batchid: {batchId}"
      eventDetail = f"The Groupid: {groupId}, TaskgroupId: {taskGroupId}, RunId: {runId}, Batchid: {batchId} has breached the min threshold: {minThreshold}. The total batch time: {totalBatchTimeInMins}"
      
    html_body= format_email(eventDetail, "No Ticket Generated", jobUrl, jobId, job_name,message)
   
  elif errorType=="maxThreshold":
    if jobType == "WAREHOUSE_SYNC":
      customerEventIdentifier = f"DHF JOB {job_name} GROUP ID {groupId} taskId {taskId} RunId {runId} has breached the max threshold."
      message = f"Maximun Threshold Breached: JobId: {jobId}, taskId: {taskId}, Batchid: {batchId}."
      eventDetail = f"Batchid {batchId} has breached the maxthreshold limit of {maxThreshold} mins in merge stream handler .Total time the batch took to complete is {totalBatchTimeInMins} mins"
    else:
      customerEventIdentifier = f"DHF JOB {job_name} GROUP ID {groupId} TaskGroupId {taskGroupId} RunId {runId} has breached the max threshold."
      message = f"Maximun Threshold Breached: JobId: {jobId}, TaskgroupId: {taskGroupId}, Batchid: {batchId}."
      eventDetail = f"Batchid {batchId} has breached the maxthreshold limit of {maxThreshold} mins in merge stream handler .Total time the batch took to complete is {totalBatchTimeInMins} mins"

    ticketNum = createSnow(jobId, jobType, str(taskGroupId), runId, taskId, groupId,  job_name,customerEventIdentifier,message,eventDetail,1,servicenow_property,metricsLogTable)
    html_body= format_email(eventDetail, ticketNum, jobUrl, jobId, job_name,message)
   
  elif errorType=="exception":
    if jobType == "WAREHOUSE_SYNC":
      customerEventIdentifier = f"DHF JOB {job_name} GROUP ID {groupId} taskId {taskId} RunId {runId} has Failed."
      message = f"Job Abend: {jobId}, RunId: {runId} ,GROUP ID {groupId} Taskid: {taskId} has failed."
      eventDetail = f"DHF JobId: {jobId}, RunId: {runId} The JobName: {job_name}, Groupid: {groupId}, taskId {taskId} ,has has failed."

    else:
      customerEventIdentifier = f"DHF JOB {job_name} GROUP ID {groupId} TaskGroupId f{taskGroupId} RunId {runId} has Failed." ##added runId
      message = f"Job Abend: {jobId}, RunId: {runId} ,TaskGroupId: {taskGroupId} Taskid: {taskId} has failed."
      eventDetail = f"DHF JobId: {jobId}, RunId: {runId} The JobName: {job_name}, Groupid: {groupId}, TaskGroupId: {taskGroupId} ,has has failed."
      
    ticketNum = createSnow(jobId,jobType, str(taskGroupId), runId, taskId, groupId, job_name,customerEventIdentifier,message,eventDetail + errorMessage,1,servicenow_property,metricsLogTable)
    html_body= format_email(errorMessage, ticketNum, jobUrl, jobId, job_name,message)
  
  elif errorType=="inactive_task_group": 
    message = f"For Job : {jobId}, RunId: {runId} ,TaskGroupId: {taskGroupId} is made Inactive!!."
    customerEventIdentifier = f"DHF JOB {job_name} GROUP ID {groupId} TaskGroupId f{taskGroupId} RunId {runId} has Failed."
    eventDetail = f"DHF JobId: {jobId}, RunId: {runId} The JobName: {job_name}, Groupid: {groupId}, TaskGroupId: {taskGroupId} ,has has failed."
    html_body= format_email(errorMessage,"No Ticket Generated", jobUrl, jobId, job_name,message)  
  
  elif errorType=="failed_processing_taskgroup": 
    message = f"Harmonization For Job : {jobId}, RunId: {runId} ,TaskGroupId: {taskGroupId} is not completed!!."
    customerEventIdentifier = f"DHF JOB {job_name} GROUP ID {groupId} TaskGroupId f{taskGroupId} RunId {runId} Harmonization is not completed."
    eventDetail = f"DHF JobId: {jobId}, RunId: {runId} The JobName: {job_name}, Groupid: {groupId}, TaskGroupId: {taskGroupId} ,Harmonization is not completed."
    html_body= format_email(errorMessage,"No Ticket Generated", jobUrl, jobId, job_name,message) 
  
  sub = environment+":"+message
  body = html_body
  sendEmail(to,fromEmail,sub,body)

# COMMAND ----------

# DBTITLE 1,Encryption & Decryption Functions
#Encrypting dataframe
def encryptDataframe(df,columns,secretKey):
  columnList=columns.split('#')
  for column in columnList:
    col=column.strip().split(" ")[0]
    df=df.withColumn(f"{col}", expr(f" base64(aes_encrypt(cast ({col} as STRING), '{secretKey}')) "))
    
  print("Encrypted the dataframe")
  return df

#Decrypting dataframe
def decryptDataframe(df,columns,secretKey):
  columnList=columns.split('#')
  for column in columnList:
    col=column.strip().split(" ")[0]
    dataType=column.strip().split(" ")[1]
    df=df.withColumn(f"{col}", expr(f"cast(cast(aes_decrypt(unbase64({col}),'{secretKey}') AS STRING) as {dataType})"))
    
  print("Decrypted the dataframe")
  return df
 
#Function for getting encryption key from Databricks secrets
def getSecretKey(secret_key_details):
    if secret_key_details is not None and isinstance(secret_key_details, str):
      splitted_param = secret_key_details.split("#")
      scope_param = [param_pair for param_pair in splitted_param if "scopeName" in param_pair]
      key_param= [param_pair for param_pair in splitted_param if "keyName" in param_pair]
      
      if len(scope_param)!=0 and len(key_param)!=0:
        secretKeyScope=scope_param[0].split(':')[1]
        secretKeyName=key_param[0].split(':')[1]
        
        if (not( secretKeyScope==None  or len(secretKeyScope)==0  ) and not( secretKeyName==None  or len(secretKeyName)==0  ) ):
          try:
            secretKey= dbutils.secrets.get(scope = secretKeyScope, key = secretKeyName)
          except Exception as e :
            print(str(e))
            return None
          
        else:
          print("Secret key details are not proper. Ignore this if Encryption is not used")
          secretKey=None
        return secretKey
      
      else:
        print("Secret key details are not proper. Ignore this if Encryption is not used")
        return None
    else:
      print("Secret key details are not proper. Ignore this if Encryption is not used")
      return None 
    
#--------------------------------------------------------------------------------------------------------------------------------#

#Create Data Key using AWS KMS    
def create_data_key(kms_keyId, region ):
  
  kms_client = boto3.client("kms",region_name=region)
  response = kms_client.generate_data_key(KeyId=kms_keyId, KeySpec="AES_128")
#   print(response)
  print("Encrypted data key: " , response["CiphertextBlob"] )
  print("Plain data key: ",base64.b64encode(response["Plaintext"]))
    
  # Return the plain data key 
  return  (base64.b64encode(response["Plaintext"])).decode()

#--------------------------------------------------------------------------------------------------------------------------------#

#Function for Creating Dynamic View
def createDynamicViews( targetTable,sensitiveColumns,secretKey,userGroup,viewName):
  showColQuery=f"SHOW COLUMNS IN {targetTable}"
  targetCols=spark.sql(showColQuery).select('col_name').rdd.map(lambda x :x[0]).collect()
  print(targetCols)
  sensitiveCols=list(map(lambda x :x.strip().split(" ")[0],sensitiveColumns.split("#")))
  datatypeList =list(map(lambda x :x.strip().split(" ")[1],sensitiveColumns.split("#")))
  datatypeDict = {sensitiveCols[i]: datatypeList[i] for i in range(len(sensitiveCols))}
  print(sensitiveCols)
  if all(col in targetCols for col in sensitiveCols):
    print("Creating Dynamic view..")
    for col in targetCols:
      if col in sensitiveCols:
        targetCols[targetCols.index(col)] = f"CASE WHEN is_member('{userGroup}') THEN (cast(cast(aes_decrypt(unbase64({col}),'{secretKey}') AS STRING) as {datatypeDict[col]})) ELSE {col} END AS {col}"
        
    selectCol=",".join(targetCols)
    createQuery=f"""CREATE VIEW IF NOT EXISTS {viewName} AS SELECT {selectCol} FROM {targetTable}"""
    print(createQuery)
    spark.sql(createQuery)
    
  
  else:
    print("Columns mentioned are not present in target..Not creating dynamic view")

# COMMAND ----------

#input format:'replay_date_column:date_col,25-08-22#replay_key_column:ID,123,345;JOB_CD,103#replay_delta_history:25-08-22'
def replay_hramonization_curation(value,task,maxBytesPerTrigger):
  print("inside replay_hramonization_curation function")
  replay_date_column=getUserPropertyValue('replay_date_column',value)
  replay_key_column=getUserPropertyValue('replay_key_column',value)
  replay_delta_history=getUserPropertyValue('replay_delta_history',value)
  print("replay_date_column :",replay_date_column," replay_key_column :",replay_key_column," replay_delta_history :",replay_delta_history)
  if((replay_delta_history != None) and (replay_key_column != None) and (replay_date_column != None)):
    raise Exception("You have passed multiple values in replay column in task level")
  elif((replay_date_column != None) and (replay_key_column==None) and (replay_delta_history==None)):
    replay_date_column_name=replay_date_column.split(",")[0].strip()
    replay_date_column_value=replay_date_column.split(",")[1].strip()
    streamingDF = spark.readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).option("ignoreChanges",True).format("delta").table(f"{task['source_db']}.{task['source_table']}")
    streamingDF=streamingDF.filter(streamingDF[f'{replay_date_column_name}']>=replay_date_column_value)
  elif((replay_date_column == None) and (replay_key_column!=None) and (replay_delta_history)==None):
    filter_condition=replay_key_colum_filter_condition(replay_key_column)
    streamingDF = spark.readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).option("ignoreChanges",True).format("delta").table(f"{task['source_db']}.{task['source_table']}")
    streamingDF=streamingDF.filter(filter_condition)
  elif((replay_date_column == None) and (replay_key_column==None) and (replay_delta_history!=None)):
    streamingDF = spark.readStream.format("delta").option("ignoreChanges",True).option("startingTimestamp", replay_delta_history).table(f"{task['source_db']}.{task['source_table']}")
  elif(replay_date_column != None and replay_key_column != None):
    replay_date_column_name=replay_date_column.split(",")[0].strip()
    replay_date_column_value=replay_date_column.split(",")[1].strip()
    filter_condition=replay_key_colum_filter_condition(replay_key_column)
    streamingDF = spark.readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).option("ignoreChanges",True).format("delta").table(f"{task['source_db']}.{task['source_table']}")
    streamingDF=streamingDF.filter(streamingDF[f'{replay_date_column_name}']>=replay_date_column_value)
    streamingDF=streamingDF.filter(filter_condition)
  elif((replay_delta_history != None and replay_key_column != None) or (replay_date_column != None and replay_delta_history!=None)):
    raise Exception("You have passed multiple values in replay column in task level") 
  else:
    print("!!!You have enabled Replay Flag to True but in Task you haven't provided ReplayDateColumn or ReplayDate so ChangeLog table will be loaded with entire source records again!!!!")
    streamingDF = spark.readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).option("ignoreChanges",True).format("delta").table(f"{task['source_db']}.{task['source_table']}")
  print("completed replay_hramonization_curation function")  
  return streamingDF

def replay_warehouse_sync(value,warehouse,maxBytesPerTrigger,checkpoint_dir):
  print("inside replay_warehouse_sync function")
  sourceDB = warehouse["source_db"].replace(" ", "")
  source = warehouse["source_table"]
  replay_date_column=getUserPropertyValue('replay_date_column',value)
  replay_key_column=getUserPropertyValue('replay_key_column',value)
  replay_delta_history=getUserPropertyValue('replay_delta_history',value)
  print("replay_date_column :",replay_date_column," replay_key_column :",replay_key_column," replay_delta_history :",replay_delta_history)
  replay_list=[replay_date_column,replay_key_column,replay_delta_history]
  if(len(value.split("#"))==3):
    raise Exception("You have passed multiple values in replay column in task level")
  elif(len(value.split("#"))==2):
    if(replay_list.count(None)>1):
      raise Exception (f"please provide below input format for reaplydatecolumn in task {warehouse['id']} in UI Input Format:replay_date_column:starttime,25-08-22#replay_key_column:ID,123;JOB_CD,103#replay_delta_history:25-08-22")
    else:
      if(replay_date_column != None and replay_key_column != None):
        replay_date_column_name=replay_date_column.split(",")[0].strip()
        replay_date_column_value=replay_date_column.split(",")[1].strip()
        filter_condition=replay_key_colum_filter_condition(replay_key_column)
        checkpoint_deletion(checkpoint_dir,warehouse)
        streamingDF = spark.readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).option("ignoreChanges",True).format("delta").table(f"{sourceDB}.{source}")
        streamingDF=streamingDF.filter(streamingDF[f'{replay_date_column_name}']>=replay_date_column_value)
        streamingDF=streamingDF.filter(filter_condition)
      elif((replay_delta_history != None and replay_key_column != None) or (replay_date_column != None and replay_delta_history!=None)):
        raise Exception("You have passed multiple values in replay column in task level")
  elif(len(value.split("#"))==1):
    if(replay_date_column != None):
      replay_date_column_name=replay_date_column.split(",")[0].strip()
      replay_date_column_value=replay_date_column.split(",")[1].strip()
      checkpoint_deletion(checkpoint_dir,warehouse)
      streamingDF = spark.readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).option("ignoreChanges",True).format("delta").table(f"{sourceDB}.{source}")
      streamingDF=streamingDF.filter(streamingDF[f'{replay_date_column_name}']>=replay_date_column_value)
    elif((replay_key_column!=None)):
      filter_condition=replay_key_colum_filter_condition(replay_key_column)
      checkpoint_deletion(checkpoint_dir,warehouse)
      streamingDF = spark.readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).option("ignoreChanges",True).format("delta").table(f"{sourceDB}.{source}")
      streamingDF=streamingDF.filter(filter_condition)
    elif((replay_delta_history)!=None):
      checkpoint_deletion(checkpoint_dir,warehouse)
      streamingDF = spark.readStream.format("delta").option("ignoreChanges",True).option("startingTimestamp", replay_delta_history).table(f"{sourceDB}.{source}")
    else:
      raise Exception (f"please provide below input format for reaplydatecolumn in task {warehouse['id']} in UI Input Format:replay_date_column:starttime,25-08-22#replay_key_column:ID,123;JOB_CD,103#replay_delta_history:25-08-22")
  
  else:
    raise Exception (f"Please check input format you have passed in UI")  
  return streamingDF

   


def checkpoint_deletion(checkpoint_dir,warehouse):
  checkPoint_del=checkpoint_dir +"/"+"warehousesync"+"/"+str(warehouse["id"])+"/"
  dbutils.fs.rm(checkPoint_del,True)
  print(f"since Replay Flag is set to True checkpoint {checkPoint_del} is deleted")
  
def replay_key_colum_filter_condition(replay_key_column):
  column_names_values={}
  filter_condition=''
  replay_key_columns=replay_key_column.split(";")
  for cols in replay_key_columns:
    values=cols.split(",")
    required_column_values=''
    for i in range(1,len(values)):
        required_column_values=  required_column_values+"'"+values[i]+"'"+","
    column_names_values[values[0]]=required_column_values[:-1]
  for column_names in column_names_values:
     filter_condition=filter_condition+column_names+" in ("+ column_names_values[column_names]+")"+' and '
  return filter_condition[:-5]

# COMMAND ----------

def getingestionTaskGroupList(groupId):
  
  pushdown_query = f""" (select * from ingestion_task_group itg where job_group_id ={groupId} and active ) t"""
  print("pushdown_query is : ",pushdown_query)
  taskGroup_df = spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  taskGroupList=list(map(lambda row:row.asDict(),taskGroup_df.collect())) 
  print("taskGroupList is :::: ", taskGroupList)
  return taskGroupList

def getingestionJobCodes(taskGroupId) :
  whereCond =  f""" WHERE ingestion_task_group_id={taskGroupId} and  active """
  pushdown_query = f""" (select distinct(job_cd) from ingestion_task {whereCond} ) t""" 
  task_df=spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()         
  unq_job_codes =  task_df.rdd.flatMap(lambda x: x).collect()
  unq_job_codes = ",".join(str(i) for i in unq_job_codes)
  return(unq_job_codes)

# COMMAND ----------



# COMMAND ----------


