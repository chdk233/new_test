# Databricks notebook source
# MAGIC %run ../../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../../../harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

def merge_general_trans(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in merge_general_trans: \n")
  harmonized_table = harmonizedDB +"."+target 
  source_system="GWPC"
  lob_cd="IM"
  partition_val = source_system+"-"+lob_cd
  starttime = datetime.now()
  
  TaskGroupId = f'{param_str.split("#")[7]}'
  taskGroup = getTaskGroup(TaskGroupId ) 
  source_table = taskGroup["source_table"]
  microBatchDF.createOrReplaceGlobalTempView(f"{source_table}_micro_batch")
  
  harmz_query =  """ 
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgcost_ext_micro_batch),
v_pcx_imgcost_ext as
(select * from 
        (select *,row_number() over (partition by publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgcost_ext.*
            from {rawDB}.pcx_imgcost_ext pcx_imgcost_ext      
            inner join global_temp.pcx_imgcost_ext_micro_batch   mb  
               on cost_branchid = pcx_imgcost_ext.branchid 
            where pcx_imgcost_ext.updatetime <= mb.updatetime  
            )
        ) where rn = 1),
 
v_pc_policyperiod as 
   (select * from 
    (select polper.*,cost.publicid as pcx_imgcost_ext_publicid,cost.updatetime as pcx_imgcost_ext_updatetime,
      row_number() over (partition by cost.publicid,cost.updatetime,cost.BranchID  
      order by (unix_millis(cost.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pcx_imgcost_ext cost
      JOIN {rawDB}.pc_policyperiod  polper 
        on cost.BranchID = polper.ID 
        and polper.updatetime <= cost.updatetime  
    ) where rn=1
  union 
   select * from 
    (select polper.*,cost.publicid as pcx_imgcost_ext_publicid,cost.updatetime as pcx_imgcost_ext_updatetime,
      row_number() over (partition by cost.publicid,polper.updatetime,cost.BranchID  
      order by (unix_millis(polper.updatetime) - unix_millis(cost.updatetime)) asc ) rn 
      from v_pcx_imgcost_ext cost
      JOIN {rawDB}.pc_policyperiod  polper 
        on cost.BranchID = polper.ID 
        and cost.updatetime <= polper.updatetime 
    ) where rn=1
),
v_pc_job as 
   (select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn 
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  
    ) where rn=1
  union 
   select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime 
    ) where rn=1
),
v_pctl_job as (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_job jtype
Cross Join Events_Max_Updatetime mb  On jtype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
           Cross Join Events_Max_Updatetime mb  
            On status.z_meta_event_timestamp <= mb.mb_max_updatetime
        ) where rn=1
),
 
 v_pcx_imgtransaction_ext 
(
  select * from 
    (select trans.*,cost.PublicId as pcx_imgcost_ext_PublicId,cost.updatetime as pcx_imgcost_ext_updatetime,
      row_number() over (partition by cost.PublicId,cost.updatetime,cost.id  
      order by (unix_millis(cost.updatetime) - unix_millis(trans.updatetime)) asc ) rn 
      from v_pcx_imgcost_ext cost
      JOIN {rawDB}.pcx_imgtransaction_ext   trans 
        on cost.id = trans.IMGCost 
        and trans.updatetime <= cost.updatetime 
        and trans.writtendate is not null 
    ) where rn=1
  union 
    select * from 
    (select trans.*,cost.PublicId as pcx_imgcost_ext_PublicId,cost.updatetime as pcx_imgcost_ext_updatetime,
      row_number() over (partition by cost.PublicId,trans.updatetime,cost.id 
      order by (unix_millis(trans.updatetime) - unix_millis(cost.updatetime)) asc ) rn 
      from v_pcx_imgcost_ext cost
      JOIN {rawDB}.pcx_imgtransaction_ext   trans 
        on cost.id = trans.IMGCost 
        and cost.updatetime <= trans.updatetime 
        and trans.writtendate is not null 
    ) where rn=1
),
 v_pc_policyperiod_tran as 
   (select * from 
    (select polper.*,Trans.publicid as  pcx_imgtransaction_ext_publicid,Trans.updatetime as pcx_imgtransaction_ext_updatetime,
      row_number() over (partition by Trans.publicid,Trans.updatetime,Trans.BranchID  
      order by (unix_millis(Trans.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pcx_imgtransaction_ext Trans
      JOIN {rawDB}.pc_policyperiod  polper 
        on Trans.BranchID = polper.ID 
        and polper.updatetime <= Trans.updatetime  
    ) where rn=1
  union 
   select * from 
    (select polper.*,Trans.publicid as pcx_imgtransaction_ext_publicid,Trans.updatetime as pcx_imgtransaction_ext_updatetime,
      row_number() over (partition by Trans.publicid,polper.updatetime,Trans.BranchID  
      order by (unix_millis(polper.updatetime) - unix_millis(Trans.updatetime)) asc ) rn 
      from v_pcx_imgtransaction_ext Trans
      JOIN {rawDB}.pc_policyperiod  polper 
        on Trans.BranchID = polper.ID 
        and Trans.updatetime <= polper.updatetime 
    ) where rn=1
 ),
  
v_pc_job_tran as 
(
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_tran_publicid,polper.updatetime as pc_policyperiod_tran_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn 
      from v_pc_policyperiod_tran  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  
    ) where rn=1
  union 
    select * from 
    (select job.*,polper.publicid as pc_policyperiod_tran_publicid,polper.updatetime as pc_policyperiod_tran_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pc_policyperiod_tran  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime 
    ) where rn=1
), 
v_pcx_imgcommision_ext as 
(
    select * from 
    (select imgcomm.*,cost.publicid as pcx_imgcost_ext_publicid,cost.updatetime as pcx_imgcost_ext_updatetime,
      row_number() over (partition by cost.publicid,cost.updatetime,cost.BranchID,cost.fixedid,imgcomm.effectivedate,imgcomm.expirationdate   
      order by (unix_millis(cost.updatetime) - unix_millis(imgcomm.updatetime)) asc ) rn 
      from v_pcx_imgcost_ext cost
      JOIN {rawDB}.pcx_imgcommision_ext  imgcomm 
        on cost.BranchID = imgcomm.BranchID 
        and cost.fixedid = imgcomm.imgcost 
        and imgcomm.updatetime <= cost.updatetime  
    ) where rn=1
  union 
  select * from 
    (select imgcomm.*,cost.publicid as pcx_imgcost_ext_publicid,cost.updatetime as pcx_imgcost_ext_updatetime,
      row_number() over (partition by cost.publicid,imgcomm.updatetime,cost.BranchID,cost.fixedid,imgcomm.effectivedate,imgcomm.expirationdate   
      order by (unix_millis(imgcomm.updatetime) - unix_millis(cost.updatetime)) asc ) rn 
      from v_pcx_imgcost_ext cost
      JOIN {rawDB}.pcx_imgcommision_ext  imgcomm 
        on cost.BranchID = imgcomm.BranchID 
        and cost.fixedid = imgcomm.imgcost
        and cost.updatetime <= imgcomm.updatetime 
    ) where rn=1
),
 
HrzmQueryWithLD AS (
Select 
COALESCE(UPPER(CASE WHEN status.TypeCode <> 'Bound' THEN 'GWPC' ||'-'  || 'IMG' ||'-QT:'|| cost.PublicID
     ELSE 'GWPC' ||'-'  || 'IMG' ||'-'|| trans.PublicID END ), 'NOKEY' ) AS GENERAL_TRANS_KEY     
,COALESCE(UPPER('GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END ), 'NOKEY')  as POL_KEY
,COALESCE(UPPER('GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-' || 'IMGLine-'||CAST(cast(cost.IMGLine AS INTEGER) AS varchar(100))), 'NOKEY')  AS POL_LINE_KEY
, UPPER(CASE 
WHEN COST.IMGACCNTRECBLDGCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGACCOUNTSRECBLDG'|| '-' ||  cast(cast(COST.IMGACCNTRECBLDGCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGACCOUNTSRECCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGACCOUNTSREC'|| '-' || cast(cast(COST.IMGACCOUNTSRECCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGBLDRSRISKBLDGCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGBLDRSRISKBLDG'|| '-' || cast(cast(COST.IMGBLDRSRISKBLDGCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGBLDRSRISKCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGBLDRSRISK'|| '-' || cast(cast(COST.IMGBLDRSRISKCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGCESCHEDCOVITEMCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGCONTRSEQPIMGCOVGSI'|| '-' || cast(cast(COST.IMGCESCHEDCOVITEMCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGCONTRSADVCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGCONTRSADV'|| '-' || cast(cast(COST.IMGCONTRSADVCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGCONTRSEQPCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGCONTRSEQP'|| '-' || cast(cast(COST.IMGCONTRSEQPCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGDRYCLEANERCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGDRYCLEANER'|| '-' || cast(cast(COST.IMGDRYCLEANERCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGDRYCLNRPRGMBLDGCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGDRYCLNRPRGMBLDG'|| '-' || cast(cast(COST.IMGDRYCLNRPRGMBLDGCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGDRYCLNRPRGMCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGDRYCLNRPRGM'|| '-' || cast(cast(COST.IMGDRYCLNRPRGMCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGELECDATAPRBLDGCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGELECDATAPROCBLDG'|| '-' || cast(cast(COST.IMGELECDATAPRBLDGCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGELECDATAPROCCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGELECDATAPROC'|| '-' || cast(cast(COST.IMGELECDATAPROCCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGEQUIPSALERENTCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGEQUIPSALERENT'|| '-' || cast(cast(COST.IMGEQUIPSALERENTCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGFARMIRRGEQPCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGFARMIRRGEQP'|| '-' || cast(cast(COST.IMGFARMIRRGEQPCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGFARMMACHCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGFARMMACH'|| '-' || cast(cast(COST.IMGFARMMACHCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGFARMMACHSCHEDCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGFARMMACHSCHED'|| '-' || cast(cast(COST.IMGFARMMACHSCHEDCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGFINEARTSDLRCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGFINEARTSDLR'|| '-' || cast(cast(COST.IMGFINEARTSDLRCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGFINEARTSFLTRCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGFINEARTSFLTR'|| '-' || cast(cast(COST.IMGFINEARTSFLTRCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGFMSHSCHCOVITEMCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGFARMMACHSCHEDIMGCOVGSI'|| '-' || cast(cast(COST.IMGFMSHSCHCOVITEMCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGINSTLFLTRBLDGCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGINSTLFLTRBLDG'|| '-' || cast(cast(COST.IMGINSTLFLTRBLDGCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGINSTLFLTRCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGINSTLFLTR'|| '-' || cast(cast(COST.IMGINSTLFLTRCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGLIVESTOCKCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGLIVESTOCK'|| '-' || cast(cast(COST.IMGLIVESTOCKCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGMISCFLTRCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGMISCFLTR'|| '-' || cast(cast(COST.IMGMISCFLTRCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGMOTORCARGOCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGMOTORCARGO'|| '-' || cast(cast(COST.IMGMOTORCARGOCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGPODSCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGPODS'|| '-' || cast(cast(COST.IMGPODSCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGRIGGERCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGRIGGER'|| '-' || cast(cast(COST.IMGRIGGERCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGSCHEDPROPFLTRCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGSCHEDPROPFLTR'|| '-' || cast(cast(COST.IMGSCHEDPROPFLTRCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGSERVPROPRGMCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGSERVPROPRGM'|| '-' || cast(cast(COST.IMGSERVPROPRGMCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGSIGNCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGSIGN'|| '-' || cast(cast(COST.IMGSIGNCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGTOWEREQPCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGTOWEREQP'|| '-' || cast(cast(COST.IMGTOWEREQPCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGTRANSITCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGTRANSIT'|| '-' || cast(cast(COST.IMGTRANSITCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGVALUABLEPAPERCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGVALUABLEPAPER'|| '-' || cast(cast(COST.IMGVALUABLEPAPERCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGVPSCHDCOVITEMCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGVALUABLEPAPERIMGCOVGSI'|| '-' || cast(cast(COST.IMGVPSCHDCOVITEMCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGVPSCHSCHITEMCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGVALPAPERSCHEDCOVITEMIMGCOVGSI'|| '-' || cast(cast(COST.IMGVPSCHSCHITEMCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGWAREHOUSECOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGWAREHOUSE'|| '-' || cast(cast(COST.IMGWAREHOUSECOV AS INTEGER) AS VARCHAR (255))
WHEN COST.IMGYNGSTKRISRCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'IMGYNGSTKRISR'|| '-' || cast(cast(COST.IMGYNGSTKRISRCOV AS INTEGER) AS VARCHAR (255))
ELSE 'NOKEY' END )LINE_COVG_KEY
 
,CASE 
	   WHEN COST.IMGAccntRecBldgCov IS NOT NULL THEN 'IMGAccountsRecBldg'
	   WHEN COST.IMGAccountsRecCov IS NOT NULL THEN 'IMGAccountsRec'
	   WHEN COST.IMGBldrsRiskBldgCov IS NOT NULL THEN 'IMGBldrsRiskBldg'
	   WHEN COST.IMGBldrsRiskCov IS NOT NULL THEN 'IMGBldrsRisk'
       WHEN COST.IMGBldrsRiskCond IS NOT NULL THEN 'IMGBldrsRisk'
	   WHEN COST.IMGCESchedCovItemCov IS NOT NULL THEN 'IMGContrsEqpIMGCovgSI' 
	   WHEN COST.IMGContrsAdvCov IS NOT NULL THEN 'IMGContrsAdv'
	   WHEN COST.IMGContrsEqpCond IS NOT NULL THEN 'IMGContrsEqp' 
	   WHEN COST.IMGContrsEqpCov IS NOT NULL THEN 'IMGContrsEqp'
	   WHEN COST.IMGDryCleanerCov IS NOT NULL THEN 'IMGDryCleaner'
	   WHEN COST.IMGDryClnrPrgmBldgCov IS NOT NULL THEN 'IMGDryClnrPrgmBldg'
	   WHEN COST.IMGDryClnrPrgmCov IS NOT NULL THEN 'IMGDryClnrPrgm'
	   WHEN COST.IMGElecDataPrBldgCov IS NOT NULL THEN 'IMGElecDataProcBldg'
	   WHEN COST.IMGElecDataProcCov IS NOT NULL THEN 'IMGElecDataProc'
	   WHEN COST.IMGEquipSaleRentCov IS NOT NULL THEN 'IMGEquipSaleRent'
	   WHEN COST.IMGFarmIrrgEqpCov IS NOT NULL THEN 'IMGFarmIrrgEqp'
	   WHEN COST.IMGFMShSchCovItemCov IS NOT NULL THEN 'IMGFarmMachSchedIMGCovgSI' 
	   WHEN COST.IMGFarmMachSchedCov IS NOT NULL THEN 'IMGFarmMachSched'   
	   WHEN COST.IMGFarmMachCov IS NOT NULL THEN 'IMGFarmMach'
	   WHEN COST.IMGFineArtsDlrCov IS NOT NULL THEN 'IMGFineArtsDlr'
	   WHEN COST.IMGFineArtsFltrCov IS NOT NULL THEN 'IMGFineArtsFltr'
	   WHEN COST.IMGInstlFltrBldgCov IS NOT NULL THEN 'IMGInstlFltrBldg'
	   WHEN COST.IMGInstlFltrCond IS NOT NULL THEN 'IMGInstlFltr'
	   WHEN COST.IMGInstlFltrCov IS NOT NULL THEN 'IMGInstlFltr'
	   WHEN COST.IMGLivestockCond IS NOT NULL THEN 'IMGLivestock'
	   WHEN COST.IMGLivestockCov IS NOT NULL THEN 'IMGLivestock'
	   WHEN COST.IMGMiscFltrCov IS NOT NULL THEN 'IMGMiscFltr'
	   WHEN COST.IMGMotorCargoCond IS NOT NULL THEN 'IMGMotorCargo'
	   WHEN COST.IMGMotorCargoCov IS NOT NULL THEN 'IMGMotorCargo'
	   WHEN COST.IMGPodsCov IS NOT NULL THEN 'IMGPods'
	   WHEN COST.IMGRiggerCov IS NOT NULL THEN 'IMGRigger'
	   WHEN COST.IMGSchedPropFltrCond IS NOT NULL THEN 'IMGSchedPropFltr'
	   WHEN COST.IMGSchedPropFltrCov IS NOT NULL THEN 'IMGSchedPropFltr'
	   WHEN COST.IMGServproPrgmCov IS NOT NULL THEN 'IMGServproPrgm'
	   WHEN COST.IMGSignCov IS NOT NULL THEN 'IMGSign'
	   WHEN COST.IMGTowerEqpCov IS NOT NULL THEN 'IMGTowerEqp'
	   WHEN COST.IMGTransitCond IS NOT NULL THEN 'IMGTransit'
	   WHEN COST.IMGTransitCov IS NOT NULL THEN 'IMGTransit'
	   WHEN COST.IMGVPSchSchItemCov IS NOT NULL THEN 'IMGValPaperSchedCovItemIMGCovgSI'  
	   WHEN COST.IMGVPSchdCovItemCov IS NOT NULL THEN 'IMGValuablePaperIMGCovgSI' 
	   WHEN COST.IMGValuablePaperCov IS NOT NULL THEN 'IMGValuablePaper'
	   WHEN COST.IMGWarehouseCond IS NOT NULL THEN 'IMGWarehouse'
	   WHEN COST.IMGWarehouseCov IS NOT NULL THEN 'IMGWarehouse'
	   WHEN COST.IMGYngStkRisrCov IS NOT NULL THEN 'IMGYngStkRisr'
	   ELSE ' '
	 END  AS CVRBL_TYPE_CD 
 
,UPPER(CASE
  WHEN IMGBldrsRiskCond IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGBLDRSRISK'||'-'||cast(cast(COST.IMGBldrsRiskCond AS INTEGER) AS VARCHAR (255))
  WHEN IMGContrsEqpCond IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGCONTRSEQP'||'-'||cast(cast(COST.IMGContrsEqpCond AS INTEGER) AS VARCHAR (255))
  WHEN IMGInstlFltrCond IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGINSTLFLTR'||'-'||cast(cast(COST.IMGInstlFltrCond AS INTEGER) AS VARCHAR (255))
  WHEN IMGMotorCargoCond IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGMOTORCARGO'||'-'||cast(cast(COST.IMGMotorCargoCond AS INTEGER) AS VARCHAR (255))
  WHEN IMGSchedPropFltrCond IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGSCHEDPROPFLTR'||'-'|| cast(cast(COST.IMGSchedPropFltrCond AS INTEGER) AS VARCHAR (255))
  WHEN IMGTransitCond IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGTRANSIT'||'-'||cast(cast(COST.IMGTransitCond AS INTEGER) AS VARCHAR (255))
  WHEN IMGWarehouseCond IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGWAREHOUSE'||'-'||cast(cast(COST.IMGWarehouseCond AS INTEGER) AS VARCHAR (255))
  WHEN IMGLivestockCond IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-IMGLIVESTOCK-'||cast(cast(COST.IMGLivestockCond AS INTEGER) AS VARCHAR (255))
  ELSE 'NOKEY' END ) AS LINE_COND_KEY
  
, UPPER(CASE wHEN cost.IMGLineManuscript  IS  NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  ||'-' || CAST(CAST(cost.IMGLineManuscript AS INTEGER) AS varchar(100))   ELSE 'NOKEY' END  ) AS MANUSCRIPT_KEY 
, 'GWPC' as SOURCE_SYSTEM
, 'IM' as LOB_CD
,COALESCE(CASE WHEN status.TypeCode <> 'Bound' THEN polper_orig.UpdateTime ELSE job.CloseDate END, to_timestamp('9999-12-31 00:00:00.000000'))  AS TRANS_PROC_DTS 
,CASE WHEN status.TypeCode <> 'Bound' THEN cast(polper_orig.periodStart AS date) ELSE cast(trans.writtendate as date) END  AS written_DT 
,CASE WHEN status.TypeCode <> 'Bound' THEN cast(polper_orig.periodStart AS date) ELSE cast(trans.postedDate as date) END AS posted_DT
,COALESCE(CASE WHEN status.TypeCode <> 'Bound' THEN COALESCE(polper_orig.UpdateTime, polper_orig.CreateTime) ELSE job_orig.CloseDate END, to_timestamp('9999-12-31 00:00:00.000000')) AS ORIG_TRANS_PROC_DTS
,CAST( COALESCE (polper_orig.EditEffectiveDate, to_timestamp('1900-01-01 00:00:00.000000')) AS date) AS ORIG_END_EFF_DT
,CASE WHEN status.TypeCode <> 'Bound' THEN cast(polper_orig.periodStart AS date) ELSE CAST(trans.EffDate AS date) END   AS TRANS_EFF_DT
,CASE WHEN status.TypeCode <> 'Bound' THEN cast(polper_orig.periodEnd AS date)   ELSE CAST(trans.ExpDate AS date) END AS TRANS_EXP_DT 
,COALESCE(CASE WHEN status.TypeCode <> 'Bound' THEN jtype_orig.TYPECODE ELSE jtype.TYPECODE  END, ' ') AS TRANS_CD    
,COALESCE(costtype.TYPECODE, ' ' ) AS TRANS_TYPE_CD 
,COALESCE(CASE WHEN status.TypeCode <> 'Bound' THEN 1 ELSE trans.ID END, 0)  AS TRANS_SEQ                
,' ' AS JURS_CD
,' ' AS STATE_COST_TYPE_CD
,COALESCE(COST.ChargeGroup, ' ') AS CHRG_GROUP_NAME
,COALESCE(charge.TYPECODE, ' ')  AS CHRG_PTRN_CD 
,'ProRataByDays'  AS PRORATION_METHOD_CD
,' ' AS COV_EMP_COST_TYPE_CD
,' ' AS EL_INCR_COST_TYPE_CD
,' ' AS FED_EL_COV_EMP_COST_TYPE_CD
,' ' AS MAR_COV_EMP_COST_TYPE_CD
,' ' AS PREM_LEVEL_TYPE_CD
,COALESCE(rate_amt.typecode, ' ') AS RATE_AMT_TYPE_CD
,COALESCE(COST.StateExceptionStatCode, ' ') AS STAT_CD
,' ' AS ACT_AUDIT_MTHD_CD 
,IFNULL(IF(cost.SubjectToReporting = 0, 'N', 'Y'), 'U') as SUBJECT_TO_RPT_FL
,IFNULL(IF(TRANS.Written  = 0, 'N', 'Y'), 'U') as WRITTEN_FL
,IFNULL(IF(TRANS.Charged = 0, 'N', 'Y'), 'U') as CHARGED_FL
,IFNULL(IF(TRANS.ToBeAccrued = 0, 'N', 'Y'), 'U') as TO_BE_ACCRUED_FL
,COALESCE(COST.NUMDAYSINRATEDTERM, 0) AS RATED_TERM_DAYS_CNT
,COALESCE(cost.Basis, 0) AS PREM_BASIS_AMT
,cost.StandardBaseRate AS STD_BASE_RATE
,cost.StandardAdjRate AS STD_ADJ_RATE
,COALESCE(cost.StandardAmount, 0) AS STD_AMT
,COALESCE(cost.StandardTermAmount, 0) AS STD_TERM_AMT
,cost.OverrideBaseRate AS OVERRIDE_BASE_RATE
,cost.OverrideAdjRate AS OVERRIDE_ADJ_RATE
,COALESCE(cost.OverrideAmount,0) AS OVERRIDE_AMT
,COALESCE(cost.OverrideTermAmount, 0) AS OVERRIDE_TERM_AMT
,cost.ActualBaseRate AS ACT_BASE_RATE
,cost.ActualAdjRate AS ACT_ADJ_RATE
,COALESCE(cost.ActualAmount, 0) AS ACT_AMT
,COALESCE(cost.ActualTermAmount, 0) AS ACT_TERM_AMT 
,IFNULL(IF(status.TypeCode <> 'Bound', NULL, trans.Amount), 0)  AS TRANS_AMT 
,COALESCE(audittype.typecode, ' ') as AUDIT_TYPE_CD
,COALESCE(trans.AmountBilling, 0) as Billing_AMT
,polper.COMMCONTRIBUTIONFACTOR_EXT AS COMM_CONTRIBUTION_FCTR -- modified part of ALCIDES-203
,IMGCOMM.NETCMISNAMT as NET_COMM_AMT
,IMGCOMM.NETCMISNPCT as NET_COMM_PCT     
,IMGCOMM.SRVCPLUSCMISNAMT as SRVC_PLUS_COMM_AMT
,0 AS IRPM_ELGBL_PREM_AMT
,0 AS LPDP_ELGBL_PREM_AMT
,0 AS LPDP_FCTR
,0 AS RATE_CAPPING_FCTR
,0 AS TIERING_ELGBL_PREM_AMT
,0 AS TIERING_FCTR
,0 as LAYER_LMT
,' ' as LIAB_TYPE_CD
,' ' as BLDG_MULTI_TYPE_CD
,'N' as AUDITABLE_FL
,IFNULL(IF(TRANS.WRITTEN = '1' AND TRANS.TOBEACCRUED = '0', 'Y', 'N'), 'U') AS PREM_FULLY_EARNED_FL
,COALESCE(tfscosttype.typecode, ' ') AS TFS_COST_TYPE_CD
,COALESCE(linecosttype.typecode, ' ') AS LINE_COST_TYPE_CD
,COALESCE(cost.ClassCode, ' ') AS LINE_CLASS_CD
,COALESCE(ovridesrc.typecode, ' ') as OVERRIDE_SOURCE_CD
,COALESCE(COST.MajorPerilCode, ' ') as MAJOR_PERIL_CD
,current_timestamp as ETL_ADD_DTS
,current_timestamp as ETL_LAST_UPDATE_DTS
,'GWPC-IM' AS PARTITION_VAL
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper_orig.publicid as POLPER_PUBLICID
,cost.publicid as SRC_COST_PUBLICID
,cost.updatetime  as SRC_UPDATETIME
,cost.fixedid as SRC_COST_FIXEDID
,cost.effectivedate as SRC_COST_EFFECTIVEDATE
,cost.expirationdate as SRC_COST_EXPIRATIONDATE
,polper.updatetime as updatetime_tab1
,job.updatetime as updatetime_tab3
,trans.updatetime as updatetime_tab4
,polper_orig.updatetime as updatetime_tab5
,job_orig.updatetime as updatetime_tab6
,imgcomm.updatetime as updatetime_tab7
,trans.publicid as SRC_TRAN_PUBLICID
,trans.fixedid as SRC_TRAN_FIXEDID
,trans.effectivedate as SRC_TRAN_EFFECTIVEDATE
,trans.expirationdate as SRC_TRAN_EXPIRATIONDATE
,CASE WHEN TRIM(COALESCE(cost.effectivedate, polper.periodstart)) = TRIM(COALESCE(cost.expirationdate, polper.periodend)) OR (trans_hard_delete.publicid is not null OR cost_hard_delete.publicid is not null) THEN 'Y' ELSE 'N' END 
as QT_DELETE_IND
 
FROM  v_pcx_imgcost_ext as cost
INNER JOIN v_pc_policyperiod polper_orig
on cost.BranchID=polper_orig.ID
and cost.publicid=polper_orig.pcx_imgcost_ext_publicid
and cost.updatetime=polper_orig.pcx_imgcost_ext_updatetime 
 
inner join v_pctl_policyperiodstatus status  ON polper_orig.status = status.ID  
 
INNER JOIN v_pc_job job_orig
ON polper_orig.jobID = job_orig.id
and polper_orig.publicid=job_orig.pc_policyperiod_publicid
and polper_orig.updatetime=job_orig.pc_policyperiod_updatetime 
 
INNER  JOIN v_pctl_job jtype_orig  ON job_orig.subtype = jtype_orig.id
 
LEFT JOIN 
( select trans.* from v_pcx_imgtransaction_ext trans  
        inner join v_pc_policyperiod_tran polper2 on trans.BranchID = polper2.id
        and trans.publicid=polper2.pcx_imgtransaction_ext_publicid
        and trans.updatetime=polper2.pcx_imgtransaction_ext_updatetime 
        inner join v_pctl_policyperiodstatus status on polper2.status = status.id
        where status.typecode = 'Bound' 
 ) trans
ON Trans.IMGCost = cost.ID 
and cost.publicid=trans.pcx_imgcost_ext_publicid
and cost.updatetime=trans.pcx_imgcost_ext_updatetime
and  status.typecode = 'Bound'
 
LEFT JOIN v_pc_policyperiod_tran polper
on trans.BranchID=polper.ID
and trans.publicid=polper.pcx_imgtransaction_ext_publicid
and trans.updatetime=polper.pcx_imgtransaction_ext_updatetime 
 
LEFT JOIN v_pc_job_tran job
ON polper.jobID = job.id
and polper.publicid=job.pc_policyperiod_tran_publicid
and polper.updatetime=job.pc_policyperiod_tran_updatetime 
and not (polper.status = 9 and job.closedate is null)
 
LEFT JOIN v_pctl_job jtype  ON job.subtype = jtype.id 
 
LEFT JOIN v_pcx_imgcommision_ext IMGCOMM
ON cost.branchid = imgcomm.branchid 
and cost.fixedid = imgcomm.imgcost 
AND POLPER_ORIG.EDITEFFECTIVEDATE >= COALESCE(IMGCOMM.EFFECTIVEDATE, POLPER_ORIG.PERIODSTART) 
AND POLPER_ORIG.EDITEFFECTIVEDATE <  COALESCE(IMGCOMM.EXPIRATIONDATE, POLPER_ORIG.PERIODEND)
and cost.publicid=imgcomm.pcx_imgcost_ext_publicid
and cost.updatetime=imgcomm.pcx_imgcost_ext_updatetime 
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pc_auditinformation auditinfo
Cross Join Events_Max_Updatetime mb  On auditinfo.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) auditinfo 
on job.AuditInformationID = auditinfo.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pc_auditinformation auditinfo_orig
Cross Join Events_Max_Updatetime mb  On auditinfo_orig.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) auditinfo_orig 
on job_orig.AuditInformationID = auditinfo_orig.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_chargepattern charge
Cross Join Events_Max_Updatetime mb  On charge.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) charge 
on cost.ChargePattern = charge.ID
 
join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_imgcost_ext costtype
Cross Join Events_Max_Updatetime mb  On costtype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) costtype 
on cost.Subtype = costtype.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_auditscheduletype audittype
Cross Join Events_Max_Updatetime mb  On audittype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) audittype 
on auditinfo.AuditScheduleType = audittype.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_auditscheduletype audittype_orig
Cross Join Events_Max_Updatetime mb  On audittype_orig.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) audittype_orig 
on auditinfo_orig.AuditScheduleType = audittype_orig.ID
    
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_imglinecosttype_ext linecosttype
Cross Join Events_Max_Updatetime mb  On linecosttype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) linecosttype 
on linecosttype.id = cost.IMGLineCostType
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_tfscosttype_ext tfscosttype
Cross Join Events_Max_Updatetime mb  On tfscosttype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) tfscosttype 
on tfscosttype.id = cost.tfscosttype
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_rateamounttype rate_amt
Cross Join Events_Max_Updatetime mb  On rate_amt.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) rate_amt 
on rate_amt.ID = COST.RateAmountType
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_overridesourcetype ovridesrc
Cross Join Events_Max_Updatetime mb  On ovridesrc.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) ovridesrc 
on COST.OverrideSource = ovridesrc.ID
 
left join (select distinct publicid from {rawDB}.pcx_imgcost_ext where z_meta_operation  ='DELETE') as cost_hard_delete
on cost.publicid = cost_hard_delete.publicid
 
left join (select distinct publicid  from {rawDB}.pcx_imgtransaction_ext where z_meta_operation  ='DELETE') as trans_hard_delete
on trans.publicid = trans_hard_delete.publicid
 
where status.typecode = 'Bound' AND trans.publicID IS NOT NULL  or status.typecode <> 'Bound' and not (polper_orig.temporaryclonestatus <> 1 and jtype_orig.typecode = 'Submission' and status.typecode = 'Quoted')
)
SELECT * from HrzmQueryWithLD 
"""
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB).replace("{source_system}", source_system).replace("{harmonizedDB}",harmonizedDB) 
  print("harmz_query after rawDB replace: ", harmz_query)
  qryDF = spark.sql(harmz_query)
  
  queryDF = removeLogicalDelete_gt(qryDF)
  queryDF = removeTestAgency_clt(queryDF, rawDB, environment)
  print("queryDF:")
  queryDF.show(3) 
  print(queryDF.count())
  
  print("removeDuplicates Microbatch start:") 
  dedupMicroBatchDF = removeDuplicatesMicrobatch_clt(queryDF,"GENERAL_TRANS_KEY",    "updatetime_tab1,SRC_UPDATETIME,updatetime_tab3,updatetime_tab4,updatetime_tab5,updatetime_tab6,updatetime_tab7")
  dedupMicroBatchDF.show(3)
  print(dedupMicroBatchDF.count())
  
  print("removeAdditionalColsDF start:")
  removeAdditionalColsDF = removeAdditionalCols_clt(dedupMicroBatchDF, harmonized_table)
  #removeAdditionalColsDF.createOrReplaceGlobalTempView("V")
  removeAdditionalColsDF.show(3)
  #removeAdditionalColsDF.count()
  
  print("surrogateKeyDF start:")
  surrogateKeyDF = addSurrogateKey_Non_UDM(removeAdditionalColsDF,harmonized_table) 
  surrogateKeyDF.show(3)
  print(surrogateKeyDF.count())
  
  print("merge start :")  
  scdType1Merge_clt(surrogateKeyDF, harmonized_table, "GENERAL_TRANS_KEY", "PARTITION_VAL", partition_val, "GENERAL_TRANS_ID")
 
  print("Job Successfully Completed")
  endtime = datetime.now()
  print(" NoteBook Execution Start Time# ", starttime)
  print(" NoteBook Execution End  Time# " ,endtime)
  print(" NoteBook Run Time# " ,endtime - starttime )
  
