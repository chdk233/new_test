# Databricks notebook source
# MAGIC %run ../../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../../../../utils/_utils

# COMMAND ----------

# MAGIC %run ../_event_harmonizer_library_agreement

# COMMAND ----------

def agreement_clpc_covg_term(microBatchDF, batchId, rawDB, harmonizedDB, target ,param_str):
  print("microBatchDF...in agreement_clpc_covg_term: \n")
  
  try:
    microBatchDF.show(3,False) 
    parent = ""

    TaskGroupId = f'{param_str.split("#")[7]}'
    taskGroup = getTaskGroup(TaskGroupId ) 
    parent = taskGroup["source_table"]
    print("EH started for ** parent table ******* :-" ,parent)
    
    
    harmonized_table = harmonizedDB +"."+target
    keycol =df.collect()[0][1]
    end_eff_dt =df.collect()[0][2]
    etl_row_eff_dts =df.collect()[0][3]
    partition_val =df.collect()[0][4] 
    lob = df.collect()[0][5]    
    source_table = df.collect()[0][6]   
    coverable_type = df.collect()[0][7]   
    key = f"{keycol},{end_eff_dt}" 
    scdkey = f"{keycol},{end_eff_dt},{etl_row_eff_dts}"   
    harmonized_table = harmonizedDB +"."+target
    table =target+"_"+coverable_type

    if(microBatchDF.count() == 0):
      print("Micro Batch Size is 0, Skipping rest of the functions")
    else:
      df_parm  =spark.sql(f""" select distinct cvrbl_type,source_system,lob_cd,src_cvrbl_type from {harmonizedDB}.DS_COVERAGE_XREF where tablename = '{parent}' """) 
      cvrbl_type = str(df_parm.select(col("cvrbl_type")).collect()[0][0]).strip()
      source_system = str(df_parm.select(col("source_system")).collect()[0][0]).strip()
      lob_cd = str(df_parm.select(col("lob_cd")).collect()[0][0]).strip() 
      src_cvrbl_type = str(df_parm.select(col("src_cvrbl_type")).collect()[0][0]).strip()

      partition_val = f"{source_system}-{lob_cd}-{cvrbl_type}"
      print("partition_val  : "+ partition_val + "\n  ")

      cvrg_term_query = build_term(rawDB , parent , cvrbl_type,source_system,lob_cd,src_cvrbl_type )
      print("harmz_query  : "+ cvrg_term_query + "\n  ")

      microBatchDF.createOrReplaceGlobalTempView(f"""{parent}_micro_batch""") 
      harmonized_table = f"{harmonizedDB}.{target}"  
      qryDF = spark.sql(cvrg_term_query)  
      
      
      FinalDF = removeLogicalDelete_clt(qryDF)
      FinalDF = removeTestAgency_clt(FinalDF, rawDB, environment)

      print("removeDuplicates Microbatch start:")
      dedupMicroBatchDF = removeDuplicatesMicrobatch_clt(FinalDF, target[3:7]+"_TERM_KEY,ETL_ROW_EFF_DTS,END_EFF_DT", "updatetime_tab1,updatetime_tab2,updatetime_tab3")
      queryDF = removeAdditionalCols_clt(dedupMicroBatchDF, harmonized_table ) 
      print("queryDF:")
      queryDF.show(3,False) 

      queryDF.createOrReplaceGlobalTempView("V")

#       harmonized_table_stg = f"{harmonizedDB}_stage.stg_{target}_{partition_val}".replace("-","_").lower()
#       harmonizeStageDF = createHarmonizeStage_clt(harmonized_table_stg,"V")

#       harmonizeStageDF.createOrReplaceGlobalTempView("V1")
      print("Entering hashdf for Target- ",target ," for LOB - ",lob," coverable_type - ",  coverable_type)
      removeAdditionalColsDF.createOrReplaceGlobalTempView(f"v_{lob}_{target}_{source_table}")
      hashDF = addHashColumnXXHash_clt(f"v_{lob}_{target}_{source_table}")

      print("removeDuplicates by hash before SCD type 1:")
      deduphashDF = removeDuplicatesMicrobatchByHash_clt(hashDF, target[3:7]+"_TERM_KEY,END_EFF_DT")

      print("SCD Type1 start:")
      surrogateID = getSurrogateIDCol_clt(harmonized_table)
      scdDF = scdMerge_clt(deduphashDF, harmonized_table, target[3:7] + "_TERM_KEY,END_EFF_DT,ETL_ROW_EFF_DTS","PARTITION_VAL", partition_val, surrogateID)

      print("removeDuplicates Multistream start:")
      dedupDF = removeDuplicatesMultistream_clt(scdDF, harmonized_table,  target[3:7]+"_TERM_KEY,END_EFF_DT" ,  "PARTITION_VAL", partition_val )

      print("auditDF start:")
      auditDF = addAuditColumns_clt(dedupDF,  target[3:7]+"_TERM_KEY,END_EFF_DT" )     
      auditDF.show(3,False)

      print("SurrogateKey - start:")
      surrogateKeyDF = addSurrogateID_clt(auditDF,harmonized_table) 

      print("merge start:")
      defaultMergeMultistream_clt(surrogateKeyDF, harmonized_table, "PARTITION_VAL",  partition_val)

      print("orphan start:")
      orphanRecords_Clt(hashDF, harmonized_table,"PARTITION_VAL",partition_val, target[3:7]+"_TERM_KEY")
  except Exception as e:
    print("Template Notebook function agreement_clpc_covg_term failed")
    print(e)
  print("End of flow")

# COMMAND ----------


