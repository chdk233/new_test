# Databricks notebook source
# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_nm_class_source(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in NM Class Source: \n")
  harmz_query = """ 
    select 
       concat('NM-',nmretrievecls.companyid,'-',nmretrievecls.submissionid,'-',nmretrievecls.mainclassificationtype,'-',nmretrievecls.classificationCode,'-',nmretrievecls.type) as NM_CLASS_SOURCE_KEY,
    concat('NM-',nmretrievecls.companyid,'-',nmretrievecls.submissionid,'-',nmretrievecls.mainclassificationtype,'-',nmretrievecls.classificationCode) as NM_COMPANY_CLASS_KEY, 
    nmretrievecls.type as DTL_CLASS_TYPE_DESC, 
    nmretrievecls.urls as URLS_INFO,
    nmretrievecls.priority as SOURCE_PRIORITY_DESC,     
    'NM' as SOURCE_SYSTEM,
    nmretrievecls.timestamp as ETL_ROW_EFF_DTS 
    from global_temp.nm_class_source_micro_batch micro_retrieve
    inner join 
     (select * from 
		(select *,row_number() over (partition by companyId,submissionId,mainclassificationtype,classificationCode,type,timestamp order by timestamp desc) as rn 
         from
         (select nm_class_source.*
			from {rawDB}.nm_class_source nm_class_source  
			inner join global_temp.nm_class_source_micro_batch mb  
             ON mb.nm_submissionId = nm_class_source.submissionId 
              and mb.nm_classificationCode = nm_class_source.classificationCode 
              and mb.nm_companyId = nm_class_source.companyId
              and mb.nm_mainclassificationtype = nm_class_source.mainclassificationtype
			  and mb.nm_type = nm_class_source.type 
			where nm_class_source.timestamp <= mb.nm_timestamp  
			)
		) where rn = 1)  nmretrievecls
    on  nmretrievecls.submissionId = micro_retrieve.nm_submissionId 
    and nmretrievecls.classificationCode = micro_retrieve.nm_classificationCode
    and nmretrievecls.mainclassificationtype = micro_retrieve.nm_mainclassificationtype
    and nmretrievecls.companyId = micro_retrieve.nm_companyId 
    and micro_retrieve.nm_type = nmretrievecls.type 
  """
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB)       
  print("harmz_query after rawDB replace: "+ harmz_query)
  
  microBatchDF.createOrReplaceGlobalTempView(f"nm_class_source_micro_batch")
    
  queryDF=spark.sql(harmz_query)
    
  print("queryDF:")
  queryDF.show(3)
  print(queryDF.count())
  
  harmonized_table = f"{harmonizedDB}.{target}"
  
  queryDF.createOrReplaceGlobalTempView("hmquery_nm_class_source")
  hashDF = addHashColumn_clt("hmquery_nm_class_source")
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, "NM_CLASS_SOURCE_KEY")
  
  auditDF = addAuditColumns_clt(dedupDF, "NM_CLASS_SOURCE_KEY")

  surrogateKeyDF = addSurrogateKey_clt(auditDF,harmonized_table)
      
  defaultMerge_clt(surrogateKeyDF,harmonized_table)  
    
  print("Job Successfully Completed")
  endtime = datetime.now()
