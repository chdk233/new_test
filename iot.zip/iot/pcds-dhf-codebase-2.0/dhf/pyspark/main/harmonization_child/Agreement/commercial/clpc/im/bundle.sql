-- Databricks notebook source
delete from dhf_logs_dev.e2h_job_creation_log where group_id = 1298

-- COMMAND ----------

select distinct(partition_val) from dhf_harmonize_stromboli.ds_si_gwpc_im_chlg

-- COMMAND ----------

select * from dhf_harmonize_stromboli.ds_line_loc

-- COMMAND ----------

select * from dhf_harmonize_stromboli.ds_line_cvrbl_gwpc_im_chlg

-- COMMAND ----------

delete from dhf_harmonize_stromboli.ds_line_cvrbl_gwpc_im_chlg where PARTITION_VAL in ('GWPC-IM-IMGLivestock','GWPC-IM-IMGDryClnrPrgm','GWPC-IM-IMGFineArtsFltr','GWPC-IM-IMGSign','GWPC-IM-IMGWarehouse','GWPC-IM-IMGYngStkRisr') 

-- COMMAND ----------

delete from dhf_harmonize_stromboli.ds_line_cvrbl where PARTITION_VAL in ('GWPC-IM-IMGLivestock','GWPC-IM-IMGDryClnrPrgm','GWPC-IM-IMGFineArtsFltr','GWPC-IM-IMGSign','GWPC-IM-IMGWarehouse','GWPC-IM-IMGYngStkRisr') 

-- COMMAND ----------

delete from dhf_harmonize_stromboli.ds_line_loc_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_transit_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_pol_line_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_mod_rf_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_line_mod_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_line_bldg_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_addl_intrst_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_general_trans_gwpc_im_chlg;
delete from dhf_harmonize_stromboli.ds_motor_cargo_gwpc_im_chlg;

-- COMMAND ----------

delete from dhf_harmonize_stromboli.ds_line_loc;
delete from dhf_harmonize_stromboli.ds_transit;
delete from dhf_harmonize_stromboli.ds_pol_line;
delete from dhf_harmonize_stromboli.ds_mod_rf;
delete from dhf_harmonize_stromboli.ds_line_mod;
delete from dhf_harmonize_stromboli.ds_line_bldg;
delete from dhf_harmonize_stromboli.ds_addl_intrst;
delete from dhf_harmonize_stromboli.ds_general_trans;
delete from dhf_harmonize_stromboli.ds_motor_cargo;


-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli_qa.ds_line_loc;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli.ds_motor_cargo;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli.ds_general_trans;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli_qa.ds_addl_intrst;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli_qa.ds_line_bldg;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli_qa.ds_line_mod;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli_qa.ds_mod_rf;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli_qa.ds_pol_line;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli.ds_transit;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli_qa.ds_line_loc;

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli.ds_line_cvrbl where PARTITION_VAL in ('GWPC-IM-IMGLivestock','GWPC-IM-IMGDryClnrPrgm','GWPC-IM-IMGFineArtsFltr','GWPC-IM-IMGSign','GWPC-IM-IMGWarehouse','GWPC-IM-IMGYngStkRisr') 

-- COMMAND ----------

select count(*) from dhf_harmonize_stromboli.ds_line_cvrbl

-- COMMAND ----------

select PARTITION_VAL,count(*) from dhf_harmonize_stromboli_qa.ds_line_cvrbl group by PARTITION_VAL

-- COMMAND ----------

select PARTITION_VAL,count(*) from dhf_harmonize_stromboli.ds_line_cvrbl group by PARTITION_VAL
