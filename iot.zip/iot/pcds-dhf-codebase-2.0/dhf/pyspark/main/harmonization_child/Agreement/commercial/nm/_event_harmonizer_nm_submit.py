# Databricks notebook source
# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_nm_submit(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in NM submit: \n")
  harmz_query = """ 
select * from 
(
select
	concat('NM-',nmsubmit.request_id) as NM_SUBMIT_KEY,
	nmsubmit.submissionId as SUBMISSION_ID,
	nmsubmit.trackingId as TRACK_ID,
	nmsubmit.Response_ID as RQST_RESP_ID,
	'NM' as SOURCE_SYSTEM,
	'NM' as PARTITION_VAL,
	nmsubmit.timestamp as ETL_ROW_EFF_DTS,    
	nmsubmit.companyDBAName as COMPANY_DBA_NAME,
	nmsubmit.companyLegalName as COMPANY_LEGAL_NAME,
	nmsubmit.companyName as COMPANY_NAME,
	nmsubmit.streetAddress as ADDR_LINE,
	nmsubmit.city as CITY_NAME,
	nmsubmit.state as STATE_CD,
	nmsubmit.zipCode as ZIP_CD,
	nmsubmit.country as COUNTRY_NAME,
	nmsubmit.segment as SEGMENT_NAME,
	nmsubmit.companyAddress as COMPANY_ADDRESS,
	case when nmsubmit.onlineProcessing = 'FALSE' then 'N' else 'Y' END as ONLINE_PROCESSING_FL,
	nmsubmit.crawlSoftCommitDataStatus as CRAWL_SOFT_CMT_DATA_STATUS,
	nmsubmit.crawlSoftStop as CRAWL_SOFT_STOP,
	nmsubmit.crawlDataStatusCode as CRAWL_DATA_STATUS_CD,
	case when nmsubmit.crawlDataStatus = 'FALSE' then 'N' else 'Y' END as CRAWL_DATA_STATUS_FL,
	nmsubmit.status as STATUS_DESC,
	nmsubmit.statusCode as STATUS_CD,
	nmsubmit.classMapping as CLASS_MAPPING,
    to_timestamp(nmsubmit.submittedTime) as SUBMIT_DTS,
    nmsubmit.companyId as COMPANY_ID,
	to_timestamp(nmsubmit.CrawlStartTime) as CRAWL_START_DTS,
	to_timestamp(nmsubmit.CompletedTime) as COMPLETE_DTS,
	COALESCE(case when nmsubmit.update = 'false' then 'N' 
               when nmsubmit.update = 'True' then 'Y'
              Else ' ' END) as UPDATE_FL, 
	nmsubmit.timeDifference as TIME_DIFFERENCE,
	nmsubmit.ErrorMessage as ERROR_MSG
	
from global_temp.nm_submit_micro_batch micro_submit

inner join 

(select * from 
       (select *,row_number() over (partition by Request_ID, timestamp order by timestamp desc) as rn 
				from
				(select nm_submit.*
                    from {rawDB}.nm_submit nm_submit  
            
                    inner join global_temp.nm_submit_micro_batch mb  
            
                     on mb.nm_Request_ID  = nm_submit.Request_ID 
                    where nm_submit.timestamp <= mb.nm_timestamp  
                    )
                ) where rn = 1) nmsubmit
      
on nmsubmit.Request_ID = micro_submit.nm_Request_ID ) t_sub
union 
select * from 
(
select
	concat('NM-',nmupdate.Response_ID) as NM_SUBMIT_KEY,
    nmupdate.submissionId as SUBMISSION_ID,
    nmupdate.trackingId as TRACK_ID,
    nmupdate.Response_ID as RQST_RESP_ID,
    'NM' as SOURCE_SYSTEM,
    'NM' as PARTITION_VAL,
    nmupdate.timestamp as ETL_ROW_EFF_DTS,    
    'NULL' as COMPANY_DBA_NAME,
    'NULL' as COMPANY_LEGAL_NAME,
    nmupdate.companyName as COMPANY_NAME,
    'NULL' as ADDR_LINE,
    'NULL' as CITY_NAME,
    'NULL' as STATE_CD,
    'NULL' as ZIP_CD,
    'NULL' as COUNTRY_NAME,
    nmupdate.Req_segment as SEGMENT_NAME,
    nmupdate.companyAddress as COMPANY_ADDRESS,
    case when nmupdate.onlineProcessing = 'FALSE' then 'N' else 'Y' END as ONLINE_PROCESSING_FL,
    nmupdate.crawlSoftCommitDataStatus as CRAWL_SOFT_CMT_DATA_STATUS,
    nmupdate.crawlSoftStop as CRAWL_SOFT_STOP,
    nmupdate.crawlDataStatusCode as CRAWL_DATA_STATUS_CD,
    case when nmupdate.crawlDataStatus = 'FALSE' then 'N' else 'Y' END as CRAWL_DATA_STATUS_FL,
    nmupdate.status as STATUS_DESC,
    nmupdate.statusCode as STATUS_CD,
    nmupdate.Req_classMapping as CLASS_MAPPING,
    to_timestamp(nmupdate.submittedTime) as SUBMIT_DTS,
    nmupdate.companyId as COMPANY_ID,
    to_timestamp(nmupdate.CrawlStartTime) as CRAWL_START_DTS,
    to_timestamp(nmupdate.CompletedTime) as COMPLETE_DTS,
    COALESCE(case when nmupdate.update = 'FALSE' then 'N'
     when nmupdate.update = 'TRUE' then 'Y'
    else ' ' END) as UPDATE_FL,
    nmupdate.timeDifference as TIME_DIFFERENCE,
    nmupdate.ErrorMessage as ERROR_MSG
from global_temp.nm_submit_micro_batch micro_submit_update

inner join 
 
 (select * from 
        (select *,row_number() over (partition by Response_ID, timestamp order by timestamp desc) as rn 
         from
		 (select nm_submit_update.*
            from {rawDB}.nm_submit_update nm_submit_update 
            
            inner join global_temp.nm_submit_micro_batch mb  
            
             on mb.nm_Request_ID  = nm_submit_update.Response_ID 
            where nm_submit_update.timestamp <= mb.nm_timestamp  
            )
         ) where rn = 1) nmupdate
      
on nmupdate.Response_ID = micro_submit_update.nm_Request_ID ) t_upd 

  """

  harmz_query=harmz_query.replace("{rawDB}", rawDB)       
  print("harmz_query after rawDB replace: "+ harmz_query)
   
  microBatchDF.createOrReplaceGlobalTempView(f"nm_submit_micro_batch")
   
  queryDF=spark.sql(harmz_query)

  print("queryDF:")
  queryDF.show(3)  
  print(queryDF.count())
  
  harmonized_table = f"{harmonizedDB}.{target}"
  queryDF.createOrReplaceGlobalTempView("V")
  hashDF = addHashColumn_clt("V")
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, "NM_SUBMIT_KEY")
    
  auditDF = addAuditColumns_clt(dedupDF, "NM_SUBMIT_KEY")

  surrogateKeyDF = addSurrogateKey_clt(auditDF,harmonized_table)
  print("FinalDF:")
  surrogateKeyDF.show(3)
  
  defaultMerge_clt(surrogateKeyDF,harmonized_table)
  
  print("Job Successfully Completed")
  endtime = datetime.now()
