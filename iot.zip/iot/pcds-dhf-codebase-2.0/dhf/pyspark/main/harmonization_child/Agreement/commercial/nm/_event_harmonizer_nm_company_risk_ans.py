# Databricks notebook source
# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_nm_company_risk_ans(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in NM Company Risk Ans: \n")
  harmz_query = """ 
    select
concat('NM-',nmretrieveriskans.retrievecompanyid,'-',nmretrieveriskans.submissionId,'-',nmretrieveriskans.id) as NM_COMPANY_RISK_ANS_KEY, 
concat('NM-',nmretrieveriskans.retrievecompanyid,'-',nmretrieveriskans.submissionId) as NM_RETRIEVE_KEY,
'NM' as SOURCE_SYSTEM,
nmretrieveriskans.questionId as QSTN_ID,
nmretrieveriskans.question as QSTN_DESC,
nmretrieveriskans.companySegment as COMPANY_SEGMENT,
nmretrieveriskans.questionDataClass as QSTN_DATA_CL,
nmretrieveriskans.clientRiskId as CLIENT_RISK_ID,
nmretrieveriskans.companyId as COMPANY_ID,
nmretrieveriskans.confidenceScore as CONFIDENCE_SCORE,
to_timestamp(nmretrieveriskans.updDate) as ANS_UPDATE_DTS,
nmretrieveriskans.answer as ANS_DESC,
nmretrieveriskans.source as SOURCE_WEB_ADDR,
nmretrieveriskans.modelVersion as MODEL_VERSION,
nmretrieveriskans.id as SMART_RATIO_RISK_ID,  
nmretrieveriskans.companyVersion as COMPANY_VERSION,
nmretrieveriskans.userValidated as VALIDATION_USER_ID,
nmretrieveriskans.validationResult as VALIDATION_RESULT,
to_timestamp(nmretrieveriskans.timestamp) as ETL_ROW_EFF_DTS
from global_temp.nm_company_risk_ans_micro_batch micro_retrieve_risk_answer

inner join 
 
 (select * from 
		(select *,row_number() over (partition by retrievecompanyid,submissionId,id,timestamp order by timestamp desc) as rn 
         from
         (select nm_company_risk_ans.*
			from {rawDB}.nm_company_risk_ans nm_company_risk_ans  
            
			inner join global_temp.nm_company_risk_ans_micro_batch mb  
             on mb.nm_retrievecompanyid = nm_company_risk_ans.retrievecompanyid 
             and mb.nm_submissionId = nm_company_risk_ans.submissionId 
			where nm_company_risk_ans.timestamp <= mb.nm_timestamp  
			)
		) where rn = 1)  nmretrieveriskans

on nmretrieveriskans.retrievecompanyid = micro_retrieve_risk_answer.nm_retrievecompanyid 
and nmretrieveriskans.submissionId = micro_retrieve_risk_answer.nm_submissionId 
and nmretrieveriskans.id = micro_retrieve_risk_answer.nm_id
"""
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB)       
  print("harmz_query after rawDB replace: "+ harmz_query)
   
  microBatchDF.createOrReplaceGlobalTempView(f"nm_company_risk_ans_micro_batch")
 
  queryDF=spark.sql(harmz_query)
  print("queryDF:")
  queryDF.show(3)  
  print(queryDF.count())
  
  harmonized_table = f"{harmonizedDB}.{target}"
  
  queryDF.createOrReplaceGlobalTempView("hmquery_nm_company_risk_ans")
  hashDF = addHashColumn_clt("hmquery_nm_company_risk_ans")
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, "NM_COMPANY_RISK_ANS_KEY")
  auditDF = addAuditColumns_clt(dedupDF, "NM_COMPANY_RISK_ANS_KEY")

  surrogateKeyDF = addSurrogateKey_clt(auditDF,harmonized_table) 
  defaultMerge_clt(surrogateKeyDF,harmonized_table)  

  print("Job Successfully Completed")
  endtime = datetime.now()
