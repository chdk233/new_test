-- Databricks notebook source
-- MAGIC %md
-- MAGIC ds_si

-- COMMAND ----------

--select distinct ETL_ROW_EFF_DTS, count(*)  from dhf_harmonize_stromboli.ds_si group by 1
select *  from dhf_harmonize_stromboli.ds_si where ETL_ROW_EFF_DTS is null

-- COMMAND ----------

SELECT  SI_KEY, END_EFF_DT, ETL_ROW_EFF_DTS, COUNT(*)
FROM dhf_harmonize_stromboli.ds_si
GROUP BY SI_KEY, END_EFF_DT, ETL_ROW_EFF_DTS
HAVING COUNT(*) > 1

-- COMMAND ----------

select 'ds_si' as table_name , count(*) as id_dups from ( select SI_ID , count(*) as dup_count from dhf_harmonize_stromboli.ds_si group by SI_ID having count(*) > 1)

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_si where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'

-- COMMAND ----------

select SI_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,count(*) , PARTITION_VAL
from dhf_harmonize_stromboli.ds_si
where ETL_CURR_ROW_FL='Y' 
group by SI_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,PARTITION_VAL
having count(*) > 1
