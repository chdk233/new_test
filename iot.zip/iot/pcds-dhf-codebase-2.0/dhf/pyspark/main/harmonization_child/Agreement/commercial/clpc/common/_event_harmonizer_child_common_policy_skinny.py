# Databricks notebook source
# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

def agreement_clpc_policy_skinny(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str  ):
  
  
  
  starttime = datetime.now()
  TaskGroupId = f'{param_str.split("#")[7]}'
  taskGroup = getTaskGroup(TaskGroupId ) 
  source_table = taskGroup["source_table"]
  print("EH started for ** source table ******* :-" ,source_table)
  key = "POL_KEY,END_EFF_DT" 
  scdkey = "POL_KEY,END_EFF_DT,ETL_ROW_EFF_DTS"  
  partition_val="GWPC"
  print("\n *EH processing for Target - ",target," for partition-",partition_val,"\n")

  microBatchDF.createOrReplaceGlobalTempView(f"{source_table}_micro_batch")
  
  
  harmz_query =  f"""
            with Events_Max_Updatetime as (
          select
              max(updatetime) as mb_max_updatetime
          from
              global_temp.pc_effectivedatedfields_micro_batch),
          pc_effectivedatedfields_micro_batch as (
          select
              distinct branchid,
              updatetime
          from
              global_temp.pc_effectivedatedfields_micro_batch ),
          v_pc_effectivedatedfields as (
          select
              *
          from
              (
              select
                  *,
                  row_number() over (partition by publicid,
                  updatetime
              order by
                  updatetime desc ) as rn
              from
                  (
                  select
                      pc_effdt.*
                  from
                      {rawDB}.pc_effectivedatedfields pc_effdt
                  inner join pc_effectivedatedfields_micro_batch mb on
                      mb.branchid = pc_effdt.branchid
                  where
                      pc_effdt.updatetime <= mb.updatetime ) )
          where
              rn = 1 ),
          v_pc_policyperiod as (
          select
              *
          from
              (
              select
                  polper.*,
                  effdtflds.publicid as pc_effectivedatedfields_publicid,
                  effdtflds.updatetime as pc_effectivedatedfields_updatetime,
                  row_number() over (partition by effdtflds.publicid,
                  effdtflds.updatetime,
                  effdtflds.BranchID
              order by
                  (unix_millis(effdtflds.updatetime) - unix_millis(polper.updatetime)) asc ) rn
              from
                  v_pc_effectivedatedfields effdtflds
              join {rawDB}.pc_policyperiod polper on
                  effdtflds.BranchID = polper.ID
                  and polper.updatetime <= effdtflds.updatetime
                  and substring(polper.policynumber, 5, 2) in ('CI', 'CO') )
          where
              rn = 1
          union
          select
              *
          from
              (
              select
                  polper.*,
                  effdtflds.publicid as pc_effectivedatedfields_publicid,
                  effdtflds.updatetime as pc_effectivedatedfields_updatetime,
                  row_number() over (partition by effdtflds.publicid,
                  polper.updatetime,
                  effdtflds.BranchID
              order by
                  (unix_millis(polper.updatetime) - unix_millis(effdtflds.updatetime)) asc ) rn
              from
                  v_pc_effectivedatedfields effdtflds
              join {rawDB}.pc_policyperiod polper on
                  effdtflds.BranchID = polper.ID
                  and effdtflds.updatetime <= polper.updatetime
                  -- and substring(polper.policynumber,5,2) in ('CI','CO')
          )
          where
              rn = 1 ) ,
          v_pc_policy as (
          select
              *
          from
              (
              select
                  pol.*,
                  polper.publicid as pc_policyperiod_publicid,
                  polper.updatetime as pc_policyperiod_updatetime,
                  row_number() over (partition by polper.publicid,
                  polper.updatetime,
                  polper.PolicyID
              order by
                  (unix_millis(polper.updatetime) - unix_millis(pol.updatetime)) asc ) rn
              from
                  v_pc_policyperiod polper
              join {rawDB}.pc_policy pol on
                  polper.PolicyID = pol.ID
                  and pol.updatetime <= polper.updatetime )
          where
              rn = 1
          union
          select
              *
          from
              (
              select
                  pol.*,
                  polper.publicid as pc_policyperiod_publicid,
                  polper.updatetime as pc_policyperiod_updatetime,
                  row_number() over (partition by polper.publicid,
                  pol.updatetime,
                  polper.PolicyID
              order by
                  (unix_millis(pol.updatetime) - unix_millis(polper.updatetime)) asc ) rn
              from
                  v_pc_policyperiod polper
              join {rawDB}.pc_policy pol on
                  polper.PolicyID = pol.ID
                  and polper.updatetime <= pol.updatetime )
          where
              rn = 1 ),
          v_pc_job as (
          select
              *
          from
              (
              select
                  job.*,
                  polper.publicid as pc_policyperiod_publicid,
                  polper.updatetime as pc_policyperiod_updatetime,
                  row_number() over (partition by polper.publicid,
                  polper.updatetime,
                  polper.Jobid
              order by
                  (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn
              from
                  v_pc_policyperiod polper
              join {rawDB}.pc_job job on
                  polper.JobId = Job.ID
                  and job.updatetime <= polper.updatetime )
          where
              rn = 1
          union
          select
              *
          from
              (
              select
                  job.*,
                  polper.publicid as pc_policyperiod_publicid,
                  polper.updatetime as pc_policyperiod_updatetime,
                  row_number() over (partition by polper.publicid,
                  job.updatetime,
                  polper.Jobid
              order by
                  (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn
              from
                  v_pc_policyperiod polper
              join {rawDB}.pc_job job on
                  polper.JobId = Job.ID
                  and polper.updatetime <= job.updatetime )
          where
              rn = 1 ),
          v_pc_producercode as (
          select
              *
          from
              (
              select
                  prodcode.*,
                  polper.publicid as pc_policyperiod_publicid,
                  polper.updatetime as pc_policyperiod_updatetime,
                  row_number() over (partition by polper.publicid,
                  polper.updatetime,
                  polper.ProducerCodeOfRecordID
              order by
                  (unix_millis(polper.updatetime) - unix_millis(prodcode.updatetime)) asc) rn
              from
                  v_pc_policyperiod polper
              join {rawDB}.pc_producercode prodcode on
                  polper.ProducerCodeOfRecordID = prodcode.ID
                  and prodcode.updatetime <= polper.updatetime )
          where
              rn = 1
          union
          select
              *
          from
              (
              select
                  prodcode.*,
                  polper.publicid as pc_policyperiod_publicid,
                  polper.updatetime as pc_policyperiod_updatetime,
                  row_number() over (partition by polper.publicid,
                  prodcode.updatetime,
                  polper.ProducerCodeOfRecordID
              order by
                  (unix_millis(prodcode.updatetime) - unix_millis(polper.updatetime)) asc ) rn
              from
                  v_pc_policyperiod polper
              join {rawDB}.pc_producercode prodcode on
                  polper.ProducerCodeOfRecordID = prodcode.ID
                  and polper.updatetime <= prodcode.updatetime )
          where
              rn = 1 ),
          v_pc_group as (
          select
              *
          from
              (
              select
                  grp.*,
                  prodcode.publicid as pc_producercode_publicid,
                  prodcode.updatetime as pc_producercode_updatetime,
                  row_number() over (partition by prodcode.publicid,
                  prodcode.updatetime,
                  prodcode.branchID
              order by
                  (unix_millis(prodcode.updatetime) - unix_millis(grp.updatetime)) asc ) rn
              from
                  v_pc_producercode prodcode
              join {rawDB}.pc_group grp on
                  prodcode.branchID = grp.id
                  and grp.updatetime <= prodcode.updatetime )
          where
              rn = 1
          union
          select
              *
          from
              (
              select
                  grp.*,
                  prodcode.publicid as pc_producercode_publicid,
                  prodcode.updatetime as pc_producercode_updatetime,
                  row_number() over (partition by prodcode.publicid,
                  grp.updatetime,
                  prodcode.branchID
              order by
                  (unix_millis(grp.updatetime) - unix_millis(prodcode.updatetime)) asc ) rn
              from
                  v_pc_producercode prodcode
              join {rawDB}.pc_group grp on
                  prodcode.branchID = grp.id
                  and prodcode.updatetime <= grp.updatetime )
          where
              rn = 1 ) ,
          v_pc_account as (
          select
              *
          from
              (
              select
                  account.*,
                  pol.publicid as pc_policy_publicid,
                  pol.updatetime as pc_policy_updatetime,
                  row_number() over (partition by pol.publicid,
                  pol.accountID,
                  pol.updatetime
              order by
                  (unix_millis(pol.updatetime) - unix_millis(account.updatetime)) asc ) rn
              from
                  v_pc_policy pol
              join {rawDB}.pc_account account on
                  pol.AccountID = account.ID
                  and account.updatetime <= pol.updatetime )
          where
              rn = 1
          union
          select
              *
          from
              (
              select
                  account.*,
                  pol.publicid as pc_policy_publicid,
                  pol.updatetime as pc_policy_updatetime,
                  row_number() over (partition by pol.publicid,
                  account.updatetime,
                  pol.updatetime
              order by
                  (unix_millis(account.updatetime) - unix_millis(pol.updatetime)) asc ) rn
              from
                  v_pc_policy pol
              join {rawDB}.pc_account account on
                  pol.AccountID = account.ID
                  and pol.updatetime <= account.updatetime )
          where
              rn = 1 ) ,
          v_pc_policyperiod_origeffdt as (
          select
              *
          from
              ( (
              select
                  polper_1.PolicyID,
                  polper_1.PeriodStart,
                  polper_1.updatetime
              from
                  v_pc_policyperiod polper_1
              where
                  polper_1.Status = 9
                  and polper_1.ModelNumberIndex = '1'
                  and polper_1.TermNumber = '1'
                  and polper_1.retired = 0 ) origeffdt ) ),
          v_pc_policyPeriod_temp as (
          select
              *
          from
              (
              select
                  tmp.*,
                  polper.publicid as pc_policyperiod_publicid,
                  polper.updatetime as pc_policyperiod_updatetime,
                  row_number() over (partition by polper.publicid,
                  polper.updatetime,
                  polper.policyTermID,
                  polper.id,
                  polper.status
              order by
                  (unix_millis(polper.updatetime) - unix_millis(TMP.updatetime)) asc ) rn
              from
                  v_pc_policyperiod polper
              join (
                  select
                      polper2.policyTermID,
                      polper2.status,
                      polper2.updatetime,
                      MAX(ID) mx_id
                  from
                      {rawDB}.pc_policyPeriod polper2
                  group by
                      polper2.policyTermID,
                      polper2.status,
                      polper2.updatetime ) TMP on
                  polper.policyTermID = TMP.policyTermID
                  and polper.id = TMP.mx_id
                  and polper.status = TMP.status )
          where
              rn = 1 ),
          v_pctl_policyperiodstatus as (
          select
              *
          from
              (
              select
                  *,
                  row_number() over (partition by Id
              order by
                  z_meta_event_timestamp  desc) as rn
              from
                  {rawDB}.pctl_policyperiodstatus status
              cross join Events_Max_Updatetime mb on
                  status.z_meta_event_timestamp  <= mb.mb_max_updatetime )
          where
              rn = 1 ) ,
          v_pctl_job as (
          select
              *
          from
              (
              select
                  *,
                  row_number() over (partition by id
              order by
                  id desc) as rn
              from
                  {rawDB}.pctl_job jbt2
              cross join Events_Max_Updatetime mb on
                  jbt2.z_meta_event_timestamp  <= mb.mb_max_updatetime )
          where
              rn = 1 ) ,
          v_pctl_cancellationsource as (
          select
              *
          from
              (
              select
                  *,
                  row_number() over (partition by id
              order by
                  z_meta_event_timestamp  desc) as rn
              from
                  {rawDB}.pctl_cancellationsource csd
              cross join Events_Max_Updatetime mb on
                  csd.z_meta_event_timestamp  <= mb.mb_max_updatetime )
          where
              rn = 1 ) ,
          v_pctl_reasoncode as (
          select
              *
          from
              (
              select
                  *,
                  row_number() over (partition by id
              order by
                  z_meta_event_timestamp  desc) as rn
              from
                  {rawDB}.pctl_reasoncode rc
              cross join Events_Max_Updatetime mb on
                  rc.z_meta_event_timestamp  <= mb.mb_max_updatetime )
          where
              rn = 1 ) ,
          HRZ_Query as (
          select
              coalesce(UPPER('GWPC' || '-' || cast(cast(polper.PeriodID as INTEGER) as VARCHAR (255)) || case when status.TypeCode <> 'Bound' then '-QT:' || cast(polper.publicID as VARCHAR(255)) else '' end) , 'NOKEY') as POL_KEY,
              cast(coalesce(effDated.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) as DATE) as END_EFF_DT,
              coalesce(cast(coalesce(effDated.ExpirationDate, polper.PeriodEnd) as date), DATE '9999-12-31') as END_EXP_DT,
              'GWPC' as SOURCE_SYSTEM,
              coalesce(UPPER('DPIM' || '-' || grp.Agencynum_Ext), 'NOKEY') as AGCY_KEY,
              coalesce(UPPER('DPIM' || '-' || prodcode.PublicID), 'NOKEY') as AGNT_KEY ,
              UPPER('GWPC' || '-' || cast(polper.PeriodID as INTEGER)|| '-' || cast(effdated.PrimaryNamedInsured as INTEGER)) as PRIM_NAMED_INSURED_KEY,
              coalesce(status.TypeCode, ' ') as pol_period_status_cd,
              coalesce(polper.PolicyNumber, ' ' ) as POL_NO,
              cast(coalesce(polper.PeriodStart, date '1900-01-01') as date) as POL_EFF_DT,
              cast(coalesce(polper.PeriodEnd, date '1900-01-01') as date) as POL_EXP_DT,
              coalesce(UPPER('GWPC' || '-' || account.AccountNumber), 'NOKEY') as ACCT_KEY,
              coalesce(case when status.TypeCode = 'Bound' then job.CloseDate else coalesce(polper.UpdateTime, polper.CreateTime) end , to_timestamp('1900-01-01 00:00:00.000000')) as ETL_ROW_EFF_DTS,
              case
                  when polper.INDUSTRYGLCLASSCODE_EXT is not null then 'GWPC-GLCLASS-' || cast(polper.INDUSTRYGLCLASSCODE_EXT as INTEGER)
                  else 'NOKEY'
              end as BUSN_CL_CD_KEY,
              coalesce(job.CloseDate, polper.UpdateTime, polper.CreateTime) as LAST_STATUS_PROC_DTS,
              cast(polper.EditEffectiveDate as date) as LAST_STATUS_EFF_DT,
              case
                  jbt2.TYPECODE when 'Submission' then 'NEW BUSINESS'
                  when 'Issuance' then 'NEW BUSINESS'
                  when 'Renewal' then 'RENEWAL'
                  when 'Reinstatement' then 'REINSTATEMENT'
                  when 'Rewrite' then 'REWRITE'
                  when 'RewriteNewAccount' then 'REWRITE'
                  else rc.TYPECODE
              end as LAST_STATUS_REASON_CD,
              case
                  when jbt2.TYPECODE = 'Cancellation' then 'CANCELLED'
                  else 'ACTIVE'
              end as LAST_STATUS_CD,
              csd.typecode as CANCEL_SRCE_CD ,
              coalesce(UPPER(SUBSTR(POLPER.POLICYNUMBER, 5, 2)), ' ') as LOB_CD
              --,pol.LegacySecPolicyNumber_Ext AS LEGACY_SCNDRY_POL_NB 
          ,
              'GWPC' as PARTITION_VAL ,
              effdated.branchid as SRC_BRANCHID ,
              effdated.fixedid as SRC_FIXEDID ,
              effdated.effectivedate as SRC_EFFECTIVEDATE ,
              effdated.expirationdate as SRC_EXPIRATIONDATE ,
              polper.periodstart as POLPER_PERIODSTART ,
              polper.periodend as POLPER_PERIODEND ,
              polper.publicid as POLPER_PUBLICID ,
              effdated.createtime as SRC_CREATETIME ,
              effdated.updatetime as SRC_UPDATETIME ,
              effdated.publicid as SRC_PUBLICID ,
              effdated.updatetime as updatetime_tab1 ,
              polper.updatetime as updatetime_tab2 ,
              pol.updatetime as updatetime_tab3 ,
              JOB.updatetime as updatetime_tab4 ,
              prodcode.updatetime as updatetime_tab5 ,
              grp.updatetime as updatetime_tab6 ,
              ACCOUNT.updatetime as updatetime_tab7
          from
              v_pc_effectivedatedfields effdated
          inner join v_pc_policyperiod polper on
              effdated.BranchID = polper.ID
              and effdated.publicid = polper.pc_effectivedatedfields_publicid
              and effdated.updatetime = polper.pc_effectivedatedfields_updatetime
          left join v_pctl_policyperiodstatus status on
              polper.Status = status.ID
          inner join v_pc_policy pol on
              polper.PolicyID = pol.ID
              and polper.publicid = pol.pc_policyperiod_publicid
              and polper.updatetime = pol.pc_policyperiod_updatetime
          inner join v_pc_job JOB on
              polper.JobID = job.ID
              and polper.publicid = job.pc_policyperiod_publicid
              and polper.updatetime = job.pc_policyperiod_updatetime
              and not ( status.typecode = 'Bound'
              and job.closedate is null)
          inner join v_pctl_job jbt2 on
              job.Subtype = jbt2.id
          left join v_pc_producercode prodcode on
              polper.ProducerCodeOfRecordID = prodcode.ID
              and polper.publicid = prodcode.pc_policyperiod_publicid
              and polper.updatetime = prodcode.pc_policyperiod_updatetime
          left join v_pc_group grp on
              prodcode.branchID = grp.id
              and prodcode.publicid = grp.pc_producercode_publicid
              and prodcode.updatetime = grp.pc_producercode_updatetime
          left join v_pc_account ACCOUNT on
              pol.AccountID = account.ID
              and pol.publicid = account.pc_policy_publicid
              and pol.updatetime = account.pc_policy_updatetime
          left join v_pctl_reasoncode rc on
              job.CancelReasonCode = rc.ID
          left join v_pctl_cancellationsource csd on
              job.Source = csd.ID
          where
              status.typecode = 'Bound'
              or status.typecode <> 'Bound'
              and not (polper.temporaryclonestatus <> 1
              and jbt2.typecode = 'Submission'
              and status.typecode = 'Quoted') )
          select
              *
          from
              HRZ_Query
  """

  print("harmz_query   for Target- DS_POLICY_SKINNY : " , harmz_query)
  qryDF=spark.sql(f"{harmz_query}")
  qryDF.show(1)


  print("Entering queryDF for Target- DS_POLICY_SKINNY")
  queryDF = removeLogicalDelete_clt(qryDF)
  queryDF = removeTestAgency_clt(queryDF, rawDB,environment)

  dedupMicroBatchDF = removeDuplicatesMicrobatch_clt(queryDF,scdkey, "updatetime_tab1,updatetime_tab2,updatetime_tab3")
  dedupMicroBatchDF.show(1)

  print("Entering removeAdditionalColsDF for Target- DS_POLICY_SKINNY")
  harmonized_table = f"{harmonizedDB}.{target}"
  removeAdditionalColsDF = removeAdditionalCols_clt(dedupMicroBatchDF, harmonized_table)

  print("Entering hashdf for Target- ",target )
  removeAdditionalColsDF.createOrReplaceGlobalTempView(f"v_common_{target}")
  hashDF = addHashColumnXXHash_clt(f"v_common_{target}")

  print("Entering deduphashDF for Target- ",target )
  deduphashDF = removeDuplicatesMicrobatchByHash_clt(hashDF,  key)
  deduphashDF.show(1)

  print("Entering surrogateID for Target- ",target )
  surrogateID = getSurrogateIDCol_clt(harmonized_table)

  print("Entering scdDF for Target- ",target)
  scdDF = scdMerge_clt(deduphashDF, harmonized_table, scdkey, "PARTITION_VAL", partition_val, surrogateID)
  
  scdDF.show(1)

  print("Entering auditDF for Target- ",target)
  auditDF = addAuditColumnsRemoveDupsCdcSyncMultistream_clt(scdDF, harmonized_table, key,"PARTITION_VAL",  partition_val) 
  auditDF.show(1)

  print("Entering surrogateKeyDF for Target- ",target, " \n")
  surrogateKeyDF = addSurrogateKey_Non_UDM(auditDF, harmonized_table)

  print("Entering defaultMerge for Target- ",target, " \n")
  defaultMergeCdcMultistream_clt(surrogateKeyDF, harmonized_table, "PARTITION_VAL", partition_val)

  print("Entering orphanRecords_Clt for Target- ",target, " \n")
  orphanRecords_Clt (hashDF,harmonized_table, "PARTITION_VAL",  partition_val,"POL_KEY") 
  print("  orphanRecords_Clt completed for Target- ",target , " \n")
  print("\n *** EH  END for Target- ",target, " \n")
  endtime = datetime.now()
  print(" NoteBook Execution Start Time# ", starttime)
  print(" NoteBook Execution End  Time# " ,endtime)
  print(" NoteBook Run Time# " ,endtime - starttime )  
        
#       else :
#           print("Micro Batch Size is 0, Skipping rest of the functions for Target - " , target,"  and partition-",partition_val,"\n")
        
       

# COMMAND ----------


