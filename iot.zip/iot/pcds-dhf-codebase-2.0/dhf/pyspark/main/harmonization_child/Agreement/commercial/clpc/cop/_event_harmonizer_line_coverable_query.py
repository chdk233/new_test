# Databricks notebook source
def build_ds_pol_line_COPLine (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.PC_POLICYLINE_cop_micro_batch),
  PC_POLICYLINE_micro_batch as (select distinct branchid,updatetime from global_temp.PC_POLICYLINE_cop_micro_batch )
,v_PC_POLICYLINE as
  (select * from 
      (select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select PC_POLICYLINE.*
           from {rawDB}.PC_POLICYLINE  PC_POLICYLINE         
            inner join PC_POLICYLINE_micro_batch mb  
               on mb.branchid = PC_POLICYLINE.branchid 
               where PC_POLICYLINE.updatetime <= mb.updatetime  
              )
                ) where rn = 1)

/*****************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,PL.updatetime,PL.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(PL.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_PC_POLICYLINE  PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and polper.updatetime <= PL.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,polper.updatetime,PL.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(PL.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_PC_POLICYLINE PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and PL.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
************************/
             ------------Change code starts here for optimization----------------

,v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    POLPER.UWCOMPANY,
    polper.BaseState,
    Polper.policyid,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as PC_POLICYLINE_publicid,
    p.updatetime as PC_POLICYLINE_updatetime
  from
    V_PC_POLICYLINE p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization---------------
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
                                Cross Join Events_Max_Updatetime mb  
                                           On status.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_PCTL_POLICYLINE as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCTL_POLICYLINE POLLINE    
                                Cross Join Events_Max_Updatetime mb  
                                On POLLINE.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
, v_pc_policy as 
(
  --consider parent record as driving record
  select * from 
    (select pol.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.policyId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(pol.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_policy pol
        on polper.policyId = pol.ID 
        and pol.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select pol.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,pol.updatetime,polper.policyId   --updatetime should be from childe in partition clause
      order by (unix_millis(pol.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_policy  pol
        on polper.policyId = pol.ID 
        and polper.updatetime <= pol.updatetime  --parent update time <= child update time
    ) where rn=1 
)
,v_PC_UWCOMPANY as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PC_UWCOMPANY UW    
                                Cross Join Events_Max_Updatetime mb  
                                On UW.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_PCTL_PROGRAMTYPE_EXT as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCTL_PROGRAMTYPE_EXT PROGTYPE    
                                Cross Join Events_Max_Updatetime mb  
                                On PROGTYPE.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_PCTL_UWCOMPANYCODE as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCTL_UWCOMPANYCODE UWCOMP    
                                Cross Join Events_Max_Updatetime mb  
                                On UWCOMP.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_pctl_jurisdiction as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_jurisdiction jurisdiction    
                                Cross Join Events_Max_Updatetime mb  
                                On jurisdiction.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_pctl_copcrimeoptions_ext as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_copcrimeoptions_ext crime_options    
                                Cross Join Events_Max_Updatetime mb  
                                On crime_options.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_PCX_LEGACYPREFIXBCODE_EXT as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCX_LEGACYPREFIXBCODE_EXT pref    
                                Cross Join Events_Max_Updatetime mb  
                                On pref.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,HRZ_Query as 
(
SELECT UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (100)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'COPLine' || '-' || CAST(CAST(POLLINE.FixedID AS INTEGER)  AS VARCHAR (255))) AS POL_LINE_KEY,
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (100)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
'NOKEY' AS FARM_AFFINITY_KEY,
CAST ( COALESCE (POLLINE.EffectiveDATE, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (POLLINE.ExpirationDATE, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(progtype.typecode,' ') AS PROG_CD,
COALESCE(progtype.DESCRIPTION, 'Not Defined') AS PROG_TEXT,
' ' AS BP_LINE_BUS_TYPE_CD,
'Not Defined' AS BP_LINE_BUS_TYPE_TEXT,
NULL AS BUS_START_DT,
' ' AS BUS_DESC,
COALESCE(CASE WHEN POLLINE.IRPMELIGIBILITYINDICATOR_EXT = 1 THEN 'Y' WHEN POLLINE.IRPMELIGIBILITYINDICATOR_EXT = 0 THEN 'N' ELSE CAST ( POLLINE.IRPMELIGIBILITYINDICATOR_EXT AS VARCHAR (1)) END,'U')  AS IRPM_ELIG_FL,
'U' AS BLNKT_BPP_TIB_COV_FL,
'U' AS BLNKT_BLDG_COV_FL,
'U' AS BLNKT_EQUAK_BPP_TIB_COV_FL,
'U' AS BLNKT_EQUAK_COV_FL,
'U' AS BLNKT_EQSL_BPP_TIB_COV_FL,
'U' AS BLNKT_EQSL_COV_FL,
NULL AS BLNKT_BLDG_COV_LMT,
NULL AS TOT_BLNKT_ERTHQK_BPP_TIB_LMT,
NULL AS TOT_BLNKT_ERTHQK_BLDG_COV_LMT,
NULL AS TOT_BLNKT_BPP_TIB_LMT,
'NOKEY ' AS GOV_CL_CD_KEY,
COALESCE(POLLINE.IRPM_ABS_THRSHLD_EXT,NULL) AS IRPM_ABS_THRSHLD,
' ' AS DIV_STATUS_CD,
'Not Defined' AS DIV_STATUS_TEXT,
' ' AS QUES_FRANCHISE_CD,
' ' AS QUES_SEASONAL_CD,
' ' AS QUES_TRAVEL_RADIUS_CD,
' ' AS QUES_OTHER_EMP_CD,
' ' AS QUES_DRIVING_EXPSR_CD,
' ' AS QUES_INTNL_TRAVEL_CD,
' ' AS QUES_AGE_RANGE_CD,
NULL AS AUTO_SMBL_MNUL_EDIT_DT,
' ' AS CSTM_AUTO_SMBL_DESC,
NULL AS ESTMT_POWER_UNIT_CNT,
' ' AS FLEET_TYPE_CD,
'Not Defined' AS FLEET_TYPE_TEXT,
' ' AS LEGAL_ENTITY_TYPE_CD,
' ' AS CA_POL_TYPE_CD,
'U' AS EXPER_RATING_FL,
'U' AS SCHED_RATING_MOD_FL,
'U' AS PRIOR_TELEMATICS_VNDR_FL,
' ' AS PRIOR_TELEMATICS_VNDR_NAME,
' ' AS TELEMATICS_SOLUTION_DESC,
' ' AS TELEMATICS_EMAIL_ADDR,
' ' AS HAZARD_GRADE_CD,
'Not Defined' AS HAZARD_GRADE_TEXT,
NULL AS UM_FIRST_ML_PREM_RATE,
NULL AS UIM_FIRST_ML_PREM_RATE,
NULL AS CLAIMS_ORIG_EFF_DT,
NULL AS CLAIMS_RETROACTIVE_DT,
'U' AS LOC_LIMITS_FL,
'U' AS POLLUTION_CLEANUP_EXP_FL,
NULL AS EXPER_RATE_MOD,
'U' AS EXPER_RATE_MOD_FL,
NULL AS PKG_MOD,
' ' AS COVG_REPRESENTED_CD,
'Not Defined' AS COVG_REPRESENTED_TEXT,
'U' AS FA_PP_FL,
'U' AS FA_BLDG_STRUCT_FL,
'U' AS FA_MEM_PROG_FL,
'U' AS REC_VEH_FL,
'U' AS RES_HH_PP_FL,
'U' AS SCHED_PP_FL,
' ' AS MOD_TYPE_CD,
'Not Defined' AS MOD_TYPE_TEXT,
CASE WHEN POLLINE.APPLYTRANSFERPLAN_EXT = 1 THEN 'Y' WHEN POLLINE.APPLYTRANSFERPLAN_EXT = 0 THEN 'N' ELSE 'U' END AS APLY_TRNSFR_PLN_FL,
CASE WHEN POLLINE.DIFFINCONDITIONIND = 1 THEN 'Y' WHEN POLLINE.DIFFINCONDITIONIND = 0 THEN 'N' ELSE 'U' END AS DIFF_COND_FL,
' ' AS CP_POL_TYPE,
'U' AS BLKT_RATED_FL,
' ' AS COVG_CERT_TISM_DESC,
' ' AS TRIA_TYPE,
NULL AS TRIA_EXP_DT,
' ' AS TRIA_COND_EXCL,
' ' AS TRIA_POST_EXCL,
'U' AS EQ_SUB_LMT_BLNKT_FL,
'U' AS FLOOD_COVG_BLNKT_FL,
' ' AS FUNG_WETDRYROT_BACT_COVG_DESC,
'U' AS MULTI_PREM_DISP_CR_FL,
NULL AS MULTI_PREM_DISP_CR_FTR,
' ' AS COND_EXCL_RATE_OPT,
'U' AS MU_BLKT_RATE_FL,
' ' AS MU_POL_TYPE,
NULL AS RISK_TYPE,
NULL AS PA_UM_PREM_RATE,
NULL AS PA_UIM_PREM_RATE,
NULL AS MANL_EXPER_RATE_MOD,
CASE WHEN POLLINE.EQUIPBREAKOPTOUTIND = 1 or POLLINE.EQBREAKDOWNOPTOUT_EXT = 1 THEN 'Y' WHEN POLLINE.EQUIPBREAKOPTOUTIND = 0 or POLLINE.EQBREAKDOWNOPTOUT_EXT= 0 THEN 'N' ELSE 'U' END AS EQUIP_BRKDN_OPT_OUT,
' ' AS BCD_CRIME_DESC,
' ' AS BCD_CRIME_DESC_ID,
' ' AS CRIME_CL_CD_DESC,
' ' AS CRIME_CL_CD_NO,
' ' AS CRIME_APPETITE_CD,
'Not Defined' AS CRIME_APPETITE_TEXT,
' ' AS CRIME_HZRD_CD,
'Not Defined' AS CRIME_HZRD_TEXT,
NULL AS RATABLE_EMP_CNT,
NULL AS TOT_EMP_CNT,
COALESCE(POLLINE.bldgbppcategory,' ') AS BLDG_BPP_CAT,
COALESCE(POLLINE.bldgbppclass,' ') AS BLDG_BPP_CL,
COALESCE(POLLINE.BLDGBPPGROUPNUM,' ') AS BLDG_BPP_GRP_NO,
COALESCE(POLLINE.BLDGBPPISOCLASS,' ') AS BLDG_BPP_ISO_CL,
COALESCE(POLLINE.CRIMEANNUALGROSSSALES,NULL) AS CRIME_ANNL_GROSS_SALE,
COALESCE(POLLINE.CRIMECATEGORY,' ') AS CRIME_CAT,
COALESCE(POLLINE.CRIMECLASS,' ') AS CRIME_CL_DESC,
COALESCE(POLLINE.CRIMECLASSCODE,' ') AS CRIME_CL_CD,
CASE WHEN POLLINE.CRIMECOVGSBLKTEDIND = 1 THEN 'Y' WHEN POLLINE.CRIMECOVGSBLKTEDIND = 0 THEN 'N' ELSE 'U' END AS CRIME_COVG_BLKT_FL,
COALESCE(POLLINE.CRIMEGROUPNUM,' ') AS CRIME_GRP_NO,
COALESCE(POLLINE.CRIMENUMOFEMPL,NULL) AS CRIME_EMP_CNT,
COALESCE(CRIME_OPTIONS.TYPECODE,' ') AS CRIME_LMT_OPTION_CD,
COALESCE(CRIME_OPTIONS.DESCRIPTION,'Not Defined') AS CRIME_LMT_OPTION_TEXT,
CASE WHEN POLLINE.CRIMEOTHRTHNEFDMSIND = 1 THEN 'Y' WHEN POLLINE.CRIMEOTHRTHNEFDMSIND = 0 THEN 'N' ELSE 'U' END AS CRIME_OTEFD_COVG_FL,
coalesce(POLLINE.CRIMERATABLEEMPL,NULL) AS CRIME_RATABLE_EMPL,
CASE WHEN POLLINE.EMPLFRAUDDISHONESTYIND = 1 THEN 'Y' WHEN POLLINE.EMPLFRAUDDISHONESTYIND = 0 THEN 'N' ELSE 'U' END AS CRIME_EFD_COVG_FL,
CASE WHEN POLLINE.EQBREAKDOWNOPTOUT_EXT = 1 THEN 'Y' WHEN POLLINE.EQBREAKDOWNOPTOUT_EXT = 0 THEN 'N' ELSE 'U' END AS EQUIO_BREK_OTH_FL,
COALESCE(POLLINE.spoilageclass,' ') AS SPOIL_CL,
COALESCE(POLLINE.spoilagegroupnum,' ') AS SPOIL_GRP_NO,
' ' as COMPOSITE_RATE ,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) 
AS ETL_ROW_EFF_DTS,
' ' AS COVERAGE_FORM,
COALESCE (pref_1.legacyPrefixB,pref_2.legacyPrefixB,pref_3.legacyPrefixB,pref_4.legacyPrefixB,' ') AS LEGACY_PREFIXB,
'GWPC-COP-COPLine' AS PARTITION_VAL,
'COP' AS LOB_CD,
NULL AS TOT_ANL_PAYROLL ,
POLLINE.branchid as SRC_BRANCHID,
POLLINE.fixedid as SRC_FIXEDID,
POLLINE.effectivedate as SRC_EFFECTIVEDATE,
POLLINE.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
POLLINE.createtime as SRC_CREATETIME,
POLLINE.updatetime  as SRC_UPDATETIME,
POLLINE.publicid as SRC_PUBLICID,
POLLINE.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3,
null as PRCO_CMISN_PCT,
null as OTHR_CMISN_PCT,
null as PRCO_CMISN_FCT,
null as OTHR_CMISN_FCT,
POLLINE.BldgAndBPPBlktInd as BLNKT_BLDG_BPP_CVRG_IN,
null as TOT_BLNKT_BLDG_BPP_LMT,
null as PLCY_RTG_RNWL_DT,
null as MIN_PREM_AM,
null as CRM_CVRG_TP_DS, 
null as QT_DAY_CT
FROM v_PC_POLICYLINE as POLLINE 
INNER JOIN v_PCTL_POLICYLINE SUBTYPE ON POLLINE.SUBTYPE = SUBTYPE.ID AND SUBTYPE.TypeCode = 'COPLine_Ext'  
INNER JOIN v_pc_policyperiod polper 
        on POLLINE.BranchID=polper.ID
        and POLLINE.publicid=polper.PC_POLICYLINE_publicid
        and POLLINE.updatetime=polper.PC_POLICYLINE_updatetime 
INNER JOIN v_pc_job job 
        on polper.jobid=job.id
        and polper.publicid=job.pc_policyperiod_publicid
        and polper.updatetime=job.pc_policyperiod_updatetime
INNER JOIN v_PC_POLICY POL ON POLPER.POLICYID = POL.ID  
        and polper.publicid=pol.pc_policyperiod_publicid
        and polper.updatetime=pol.pc_policyperiod_updatetime
LEFT JOIN v_PC_UWCOMPANY UW ON POLPER.UWCOMPANY = UW.ID 
INNER JOIN v_pctl_policyperiodstatus status ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join v_pctl_job jbt
ON job.Subtype = jbt.id
LEFT JOIN v_pctl_programtype_ext progtype ON progtype.id = polline.programtype_ext 
LEFT JOIN v_pctl_uwcompanycode uwcomp ON uw.Code = uwcomp.ID 
LEFT JOIN v_pctl_jurisdiction jurisdiction ON polper.BaseState = jurisdiction.ID 
LEFT JOIN v_pctl_copcrimeoptions_ext crime_options ON polline.crimeoptions = crime_options.ID 
LEFT JOIN v_PCX_LEGACYPREFIXBCODE_EXT pref_1
          ON uwcomp.typecode = pref_1.uwcompanycode
          AND pol.productcode = pref_1.productcode
          AND pref_1.programtypecode = progtype.typecode
          AND pref_1.statecode = jurisdiction.typecode
LEFT JOIN  v_PCX_LEGACYPREFIXBCODE_EXT pref_2
          on uwcomp.typecode = pref_2.uwcompanycode
          AND pol.productcode = pref_2.productcode
          AND pref_2.programtypecode = progtype.typecode
          AND pref_2.statecode = '*'
LEFT JOIN  v_PCX_LEGACYPREFIXBCODE_EXT pref_3
          on uwcomp.typecode = pref_3.uwcompanycode
          AND pol.productcode = pref_3.productcode
          AND pref_3.programtypecode = '*'
          AND pref_3.statecode = jurisdiction.typecode
LEFT JOIN  v_PCX_LEGACYPREFIXBCODE_EXT pref_4
          on uwcomp.typecode = pref_4.uwcompanycode
          AND pol.productcode = pref_4.productcode
          AND pref_4.programtypecode = '*'
          AND pref_4.statecode = '*'
WHERE status.typecode = 'Bound' or status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted')
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_loc_COPLocation (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_coplocation_ext_micro_batch), 
 pcx_coplocation_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_coplocation_ext_micro_batch )
,v_pcx_coplocation_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_coplocation_ext.*
			from {rawDB}.pcx_coplocation_ext        
            inner join pcx_coplocation_ext_micro_batch mb  
			   on mb.branchid = pcx_coplocation_ext.branchid 
			where pcx_coplocation_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,PL.updatetime,PL.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(PL.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_PC_POLICYLINE  PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and polper.updatetime <= PL.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,polper.updatetime,PL.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(PL.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_PC_POLICYLINE PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and PL.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
***********/
             ------------Change code starts here for optimization----------------

,v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_coplocation_ext_publicid,
    p.updatetime as pcx_coplocation_ext_updatetime
  from 
    v_pcx_coplocation_ext as  p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization---------------
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_coplocwindzone_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_coplocwindzone_ext jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
    
, HRZ_Query as
(
SELECT UPPER ( 'GWPC'|| '-'|| cast(CAST(polper.PeriodID AS INTEGER ) as varchar(255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'COPLocation' || '-' || cast(CAST(COPLOCATION.FixedID AS INTEGER )as varchar(255)) ) AS LINE_LOC_KEY,			
UPPER ('GWPC' || '-' || cast(CAST(polper.PeriodID AS INTEGER) as varchar(255)) || CASE WHEN STATUS.TYPECODE <> 'Bound' THEN '-' || 'QT:' || CAST (POLPER.PUBLICID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,			
UPPER ('GWPC'|| '-'|| cast(CAST( polper.PeriodID AS INTEGER ) as varchar(255))|| CASE WHEN STATUS.TYPECODE <> 'Bound' THEN '-' || 'QT:' || CAST (POLPER.PUBLICID AS VARCHAR (255)) ELSE '' END || '-' || 'COPLine' || '-' || cast(CAST(COPLOCATION.COPLINE AS INTEGER ) as varchar(255))) AS POL_LINE_KEY,
UPPER ( CASE WHEN COPLOCATION.LOCATION IS NULL THEN 'NOKEY' ELSE 'GWPC' || '-' || cast(CAST(polper.PeriodID AS INTEGER ) as varchar(255))|| CASE WHEN STATUS.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (POLPER.PUBLICID AS VARCHAR (255)) ELSE '' END || '-' || CAST (CAST (COPLOCATION.LOCATION AS INTEGER) AS VARCHAR (255)) END) AS   LOC_KEY,
'NOKEY' AS HZRD_INFO_KEY
,'NOKEY' AS SUBLINE_TYPE_KEY 
,cast(coalesce(coplocation.EffectiveDate, polper.PeriodStart) as date) as END_EFF_DT
,cast(coalesce(coplocation.ExpirationDate, polper.PeriodEnd) as date) as END_EXP_DT
,CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate       ELSE COALESCE(polper.UpdateTime, polper.CreateTime)       END AS ETL_ROW_EFF_DTS
,'COP' as LOB_CD,  
'GWPC' AS SOURCE_SYSTEM,
'COPLocation' AS CVRBL_TYPE_CD,
'GWPC'||'-'||'COP'||'-'||'COPLocation' AS PARTITION_VAL,
0 AS LINE_LOC_NO,
' ' AS FEET_HYDRANT_CD,
'Not Defined' AS FEET_HYDRANT_TEXT,
' ' AS BP_FIRE_PROT_CL_CD  ,
'Not Defined' AS FIRE_PROT_CL_TEXT,
0 AS LIQUOR_LIAB_GRADE,
' ' AS UNIT_NO,
'U' AS PERIL_FL,
NULL AS FA_PP_SEQ  ,
NULL AS FA_RES_SEQ,
NULL AS FA_STRUCT_SEQ ,
' ' AS EQ_LOSS_CAUSE_FORM ,
' ' AS MULTI_RES_SPCL_CR ,
' ' AS PROT_CL ,
'U' AS FLOOD_COVG_FL  ,
' ' AS LIQUOR_DED  ,
 ' ' AS LIQUOR_LIAB_TERR  ,
 ' ' AS LIQUOR_LIAB_TERR_CD ,
' ' AS  OC_TERR  ,
' ' AS POLL_TERR  ,
' ' AS PREFD_COVG_CURR  ,
' ' AS PO_BI_DED  ,
' ' AS PO_BIPD_DED  ,
' ' AS PO_PD_DED ,
' ' AS PO_TERR ,
' ' AS PO_TERR_CD  ,
' ' AS PC_OPS_BI_DED  ,
' ' AS PC_OPS_BIPD_DED  ,
' ' AS PC_OPS_PD_DED  ,
' ' AS PC_OPS_TERR  ,
' ' AS PW_DED  ,
' ' AS RAILROAD_TERR  ,
' ' AS BASE_GRP_I_DSTR_TERR ,
' ' AS BASE_GRP_I_RATE_TERR ,
' ' AS BASE_GRP_I_REDCT_CRD ,
' ' AS BASE_GRP_II_RATE_TERR ,
' ' AS COUNTY_NAME ,
' ' AS CITY_NAME ,
' ' AS CITY_OVRRD ,
' ' AS DSGN_CAT_AREA,
' ' AS DISTR_NAME ,
' ' AS EQ_TERR ,
'U' AS FD_FL ,
' ' AS FD_NAME ,
' ' AS FIRE_HYDR_DIST_CD ,
'Not Defined' as FIRE_HYDR_DIST_TEXT  ,
'U' as FUNG_WET_DRY_ROT_BACT_FL  ,
' ' AS FUNG_WET_DRY_ROT_BACT_SUB_LMT  ,
' ' AS GEO_WIND_HZRD_TERR ,
'U' AS MINE_SUBSID_FL  ,
'U' AS ONE_OPER_UNIT_FL ,
' ' AS SPCL_RATE_TERR ,
' ' AS TERR_ZONE ,
' ' AS TERRSM_TERR,
' ' AS TERRSM_TERR_OVRRD ,
' ' AS ZIP_CD ,
' ' AS ZIP_CD_OVRD,
CASE WHEN  EXCLEQCOVGLOCIND = 1 THEN 'Y'    WHEN   EXCLEQCOVGLOCIND = 0 THEN 'N' ELSE 'U' END AS  EXCL_EQ_COVG_LOC_FL,
CASE WHEN  EXCLFLOODCOVGLOCIND = 1 THEN 'Y'   WHEN   EXCLFLOODCOVGLOCIND = 0 THEN 'N'    ELSE 'U' END AS  EXCL_FLOOD_COVG_LOC_FL,
CASE WHEN  MULTIRESIDLOCIND = 1 THEN 'Y'   WHEN   MULTIRESIDLOCIND = 0 THEN 'N'    ELSE 'U' END AS  MULTI_RESID_LOC_FL,
COPLOCATION.TerrorismLoadFactor AS TERRSM_LOAD_FCT,
COPLOCATION.AutoIncreaseOverride AS AUTO_INCR_OVRD_PCT,
CASE WHEN COPLOCATION.LocEastOfWestBankInd=1 THEN 'Y' WHEN COPLOCATION.LocEastOfWestBankInd =0 THEN 'N' ELSE 'U' END AS LOC_EAST_OF_WEST_BANK_IND,
COALESCE(WINDZONE.TYPECODE,' ') AS WIND_ZONE_CD,
cast(CAST( coplocation.FixedID   AS INTEGER ) as varchar(255)) as LIFE_OBJECT_NO,
'U' AS AUTO_BRGLR_ALARM_FL,
'U' AS AUTO_FIRE_ALARM_FL,
'U' AS AUTO_SPRINKLR_FL,
' ' AS MOD_MERCALLI_INTS_RT,
coplocation.branchid as SRC_BRANCHID,
coplocation.fixedid as SRC_FIXEDID,
coplocation.effectivedate as SRC_EFFECTIVEDATE,
coplocation.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
coplocation.createtime as SRC_CREATETIME,
coplocation.updatetime  as SRC_UPDATETIME,
coplocation.publicid as SRC_PUBLICID,
 polper.updatetime as updatetime_tab1,
 coplocation.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
                
FROM   v_pcx_coplocation_ext as coplocation
INNER JOIN v_pc_policyperiod polper
on coplocation.BranchID=polper.ID
and coplocation.publicid=polper.pcx_coplocation_ext_publicid
and coplocation.updatetime=polper.pcx_coplocation_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
 
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join v_pctl_job jbt
ON job.Subtype = jbt.id
 
left join v_pctl_coplocwindzone_ext windzone 
ON COPLocation.WINDZONE = WINDZONE.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_bldg_COPBuilding (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_copbuilding_ext_micro_batch), 
 pcx_copbuilding_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_copbuilding_ext_micro_batch )
,v_pcx_copbuilding_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_copbuilding_ext.*
			from {rawDB}.pcx_copbuilding_ext        
            inner join pcx_copbuilding_ext_micro_batch mb  
			   on mb.branchid = pcx_copbuilding_ext.branchid 
			where pcx_copbuilding_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,PL.updatetime,PL.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(PL.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_PC_POLICYLINE  PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and polper.updatetime <= PL.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,polper.updatetime,PL.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(PL.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_PC_POLICYLINE PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and PL.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
*******/
             ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_copbuilding_ext_publicid,
    p.updatetime as pcx_copbuilding_ext_updatetime
  from
    v_pcx_copbuilding_ext  p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization---------------
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_nwconstructiontype_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_nwconstructiontype_ext nc    
		   Cross Join Events_Max_Updatetime mb  
		   On nc.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_copeqclass_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_copeqclass_ext oc    
		   Cross Join Events_Max_Updatetime mb  
		   On oc.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_copeqgrade_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_copeqgrade_ext oc    
		   Cross Join Events_Max_Updatetime mb  
		   On oc.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_copeqconsdetail_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_copeqconsdetail_ext oc    
		   Cross Join Events_Max_Updatetime mb  
		   On oc.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_copvaluationlaw_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_copvaluationlaw_ext oc    
		   Cross Join Events_Max_Updatetime mb  
		   On oc.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,  
HRZ_Query AS (
SELECT UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE   WHEN STATUS.TypeCode <> 'Bound'   THEN   '-'   || 'QT:'   || CAST (polper.PublicID AS VARCHAR (255))    ELSE   ''    END   || '-'|| CAST ('COPBuilding' AS VARCHAR (255))  || '-'   ||  CAST (CAST(COPBUILDING.FixedID AS INTEGER)AS VARCHAR (255)) ) AS LINE_BLDG_KEY,
UPPER ( 'GWPC'|| '-'|| CAST(CAST(polper.PeriodID AS INTEGER)AS VARCHAR (255))  || CASE    WHEN STATUS.TypeCode <> 'Bound' THEN '-'|| 'QT:'  || CAST (polper.PublicID AS VARCHAR (255)) ELSE  ''  END) AS POL_KEY,
UPPER ( CASE  WHEN COPBUILDING.BUILDING IS NULL THEN 'NOKEY'  ELSE    'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN STATUS.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST  (POLPER.PUBLICID AS VARCHAR (255)) ELSE ''   END || '-' || CAST (CAST( COPBUILDING.BUILDING AS INTEGER) AS VARCHAR (255))   END) AS BLDG_KEY,
'NOKEY' AS LOC_KEY,
UPPER ( CASE WHEN COPBUILDING.CopLocation IS NULL  THEN 'NOKEY' ELSE    'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE  WHEN STATUS.TypeCode <> 'Bound' THEN   '-'  || 'QT:' || CAST (POLPER.PUBLICID AS VARCHAR (255))   ELSE  '' END || '-' || 'COPLocation' || '-' || CAST (CAST(COPBUILDING.CopLocation AS INTEGER) AS VARCHAR (255))   END) AS LINE_LOCATION_KEY,             
'NOKEY' AS CVRBL_KEY,
CAST (COALESCE (COPBUILDING.EffectiveDate, polper.PeriodStart) AS DATE)  AS END_EFF_DT,
CAST ( COALESCE (COPBUILDING.ExpirationDate, polper.PeriodEnd) AS DATE)  AS END_EXP_DT,				   
CASE WHEN status.TypeCode = 'Bound' THEN  job.CloseDate   ELSE  COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END AS ETL_ROW_EFF_DTS  ,
'GWPC'||'-'||'COP'||'-'||'COPBuilding' AS PARTITION_VAL,
'COP' AS LOB_CD ,
CAST ('GWPC' AS VARCHAR (10)) AS SOURCE_SYSTEM,
CAST ('COPBuilding' AS VARCHAR (255)) AS CVRBL_TYPE_CD,
CAST(CAST( COPBUILDING.fixedid   AS INTEGER ) as varchar(255))   AS LIFE_OBJECT_NO ,  
NULL AS AGREED_VAL_LMT,
'U' AS ALL_CONSTR_APPL_RATNG_FL,
' ' AS AREA_OF_STATE_CD,
'Not Defined' AS AREA_OF_STATE_TEXT,
NULL AS AUTO_SPRINKLR_GRADE_RPT_ID,
'U' AS AUTOMATIC_SPRINKLER_SYS_FL,
' ' AS BASE_GRP_II_RISK_COVG_TYPE,
' ' AS BASE_GRP_II_RISK_SP_CL,
' ' AS BASE_GRP_II_COVG_TYPE,
' ' AS BASE_GRP_II_COVG_SEC_CONSTR,
' ' AS BASE_GRP_II_MIX_CONSTR,
' ' AS BASE_GRP_II_SEC_SYMB,
' ' AS BASE_GRP_II_SHED_SUPR_CONSTADJ,
' ' AS BASE_GRP_II_SIGN_FLUSH_WALL,
' ' AS BASE_GRP_II_SP_CL,
' ' AS BASE_GRP_II_SP_CL_SEC_CONSTR,
' ' AS BASE_GRP_II_SUPWINDRESCONST_TP,
' ' AS BASE_GRP_II_SWRCTSC,
' ' AS BASE_GRP_II_SYMB,
' ' AS BASE_GRP_II_SYMB_PCT_CONSTR,
' ' AS BASE_GRP_II_TANK_WOOD,
NULL AS BASE_GRP_II_SPCF_LOSS_RATE,
NULL AS BASE_GRP_I_TENT_LOSS_RATE,
' ' AS BASE_GRP_II_RATING_TYPE,
' ' AS BCEG_CD,
'Not Defined' AS BCEG_TEXT,
' ' AS BCEG_CL_CD,
'Not Defined' AS BCEG_CL_TEXT,
' ' AS BCEG_CL,
' ' AS BCEG_CL_DESC,
' ' AS BCEG_DESC,
'U' AS BLDG_INC_OPER_UNIT_FL,
' ' AS BLNKT_LOSS_CAUSE_VAL,
NULL AS BLNKT_ID_NO,
' ' AS BLDG_COND_CD,
'Not Defined' AS BLDG_COND_TEXT,
' ' AS BLDG_UNQ_ID,
' ' AS BLDG_GRND_FLR_AREA,
NULL AS BLDG_OCCP_PCT,
NULL AS BLDG_SF_NO,
' ' AS BLDG_INCL_OPER_UNT,
' ' AS BLDG_UNIT_NO,
0 AS BP_BLDG_NO,
'U' AS BRGLR_ALARM_CR_FL,
'U' AS CNTRL_FIRE_STATION_FL,
' ' AS CERTF_LVL,
'U' AS CLASS_BASE_GRP_II_FL,
' ' AS CL_RATE_CONVRT_CL_DESC,
' ' AS CLASS_SUB_CD,
' ' AS COMP_BASE_GRP_II_SYMB,
'U' AS CMPLNC_WIND_MTGN_FL,
0 AS CONDO_BLDG_AREA_SF_QT,
' ' AS CONFORM_CONDO_ACT,
COALESCE(CONST_TYPE.TypeCode,' ' ) AS BP_CONSTR_TYPE_CD,
COALESCE(CONST_TYPE.DESCRIPTION,'Not Defined') AS BP_CONSTR_TYPE_TEXT,
' ' AS CONSTR_CD,
' ' AS CONSTR_TYPE,
' ' AS CONSTR_QLTY_LEVEL_CD,
'Not Defined' AS CONSTR_QLTY_LEVEL_TEXT,
' ' AS CONSTR_TYPE_USE,
' ' AS CONSTR_YR_CD,
NULL AS CONSTR_YR_NO,
' ' AS COVG_TYPE,
NULL AS FUNG_COVG_SUB_LMT,
' ' AS EQ_SCP_GRADE_CD,
' ' AS EQ_RATE_GRADE_CD,
' ' AS EQ_ADDL_HZRD,
' ' AS EQ_BLDG_CONSTR_DTL,
0 AS EQ_LOSS_CAUSE_BLNKT_ID_NO,
' ' AS EQ_COVG_DESC,
' ' AS EQ_CONSTR_CL,
'U' AS EQ_ROOF_TANK_HZRD_FL,
' ' AS EXTR_WALL_CLAY,
' ' AS EXTR_WALL_CLAY_SEC_CONSTR,
' ' AS GRD_CL_BASE_GRP_II,
' ' AS GRD_OCCP_BASE_GRP_II,
' ' AS HZRD_GRADE_CD,
'Not Defined' AS HZRD_GRADE_TEXT,
' ' AS HEAT_PLANT,
' ' AS HURR_DED_TYPE,
' ' AS HURR_PCT_DED,
'U' AS HURR_PCT_DED_FL,
' ' AS INC_APRTM,
'U' AS INCL_IN_BLNKT_FL,
' ' AS INDIV_GRD_PRMS,
'U' AS INDSTR_EQP_INCL_FL,
'U' AS INITIAL_COND_FL,
'U' AS INITIAL_COVG_FL,
'U' AS INITIAL_EXCL_FL,
'U' AS IBHS_CERT_FL,
NULL AS ISO_CRIME_SCR,
COALESCE(COPBUILDING.ITVActualCashValAmt,0) as ITV_ACT_CASH_VAL_AMT,
COALESCE(COPBUILDING.ITVRplcmntCostValAmt,0) as ITV_REPL_COST_VAL_AMT,
0 AS ITV_VAL_AMT,
'U' AS LEAD_ABATEMENT_FL,
NULL AS LEGACY_BLDG_NO,
' ' AS LMT_EQ_RES_RISK_APPLY,
NULL AS LOSS_COST_EFF_DTS,
NULL AS MASONRY_VENEER_PCT,
' ' AS MINE_SUBSD_TYPE,
' ' AS NAME_STORM_PCT_DED,
'U' AS NAME_STORM_DED_APPLY_FL,
' ' AS OCCP_TYPE,
NULL AS OCCPNCY_RECERT_YR,
NULL AS ONSITE_SURV_DTS,
' ' AS OPEN_PROT_CD,
'Not Defined' AS OPEN_PROT_TEXT,
'U' AS OPEN_SIDES_FL,
' ' AS OWNER_OCCUPIED_PCT_CD,
'Not Defined' AS OWNER_OCCUPIED_PCT_TEXT,
' ' AS PLASTIC_GREENHOUSE,
' ' AS PREDOMN_CONSTR_TYPE,
' ' AS PRMS_GRADE_CD,
'Not Defined' AS PRMS_GRADE_TEXT,
' ' AS PROP_TYPE_CD,
'Not Defined' AS PROP_TYPE_TEXT,
' ' AS PUBL_INST_PROP_PLAN_APPLY,
'U' AS PUBL_PROP_FL,
'U' AS RENTAL_PROP_FL,
' ' AS RATING_TYPE,
NULL AS RCP_CD,
'U' AS REINF_WIDTH_DOOR_FL,
NULL AS ROOF_AGE,
' ' AS ROOF_LVL,
' ' AS ROOF_DECK_ATTCH_CD,
'Not Defined' AS ROOF_DECK_ATTCH_TEXT,
'U' AS ROOF_COVERING_FL,
' ' AS ROOF_WALL_CONN_CD,
'Not Defined' AS ROOF_WALL_CONN_TEXT,
' ' AS ROOF_SHAPE_CD,
'Not Defined' AS ROOF_SHAPE_TEXT,
' ' AS ROOF_SUBDECK,
'U' AS SEC_WATER_PROT_FL,
0 AS SPECIFIC_GROUP_II_RATE,
0 AS SPECIFIC_GROUP_I_RATE,
'U' AS SEP_ANNL_AGGR_LMT_FL,
' ' AS SIMPL_CONSTR_TYPE,
'U' AS SPRAY_PAINT_FL,
CASE WHEN COPBUILDING.SPRINKLERSYSTEMIND = 1 THEN 'Y' WHEN COPBUILDING.SPRINKLERSYSTEMIND = 0 THEN 'N' ELSE 'U' END AS SPRINKLER_RED_FL,
' ' AS SPRINKLER_SYS,
'U' AS STATE_OWNED_PROP_FL,
' ' AS STORIES_NO,
'U' AS SUB_STD_COND_A_FL,
'U' AS SUB_STD_COND_B_FL,
'U' AS SUB_STD_COND_C_FL,
'U' AS SUB_STD_COND_D_FL,
'U' AS SUB_STD_COND_E_FL,
0 AS TANK_QTY,
0 AS TERRSM_OVRRD_PREM_AMT,
'U' AS TERRSM_OVRRD_PREM_FL,
'U' AS TRIPLE_NET_LEASE_FL,
' ' AS UNITS_1_4,
'U' AS UNDER_FOUR_UNIT_FL,
NULL AS UNITS_NO,
'U' AS VACANT_BLDG_FL,
' ' AS VALUATION_LAW,
' ' AS VALUATION_ID,
'U' AS WHSALE_STORAGE_FL,
'U' AS WIND_CREDIT_FL,
'U' AS WINDSTORM_PROT_DVC_FL,
NULL AS EXPSR_GROUP,
NULL AS NORMAL_LOSS_RATE,
NULL AS PROP_EXPSR_RATE_PLAN_FTR,
NULL AS PROP_EXPSR_RATE_PLAN_DED_FTR,
COPBUILDING.asgr AS ASGR,
COALESCE(COPBUILDING.COPCLASSCODE,' ') AS CLASS_CD,
COALESCE(COPBUILDING.COPCLASSIFICATIONDESCRIPTION,' ') AS CLASS_DESC,
COALESCE(EARTH_Q_CLASS.TYPECODE,' ') AS EQ_CL_CD,
COALESCE(EARTH_Q_CLASS.DESCRIPTION,'Not Defined') AS EQ_CL_TEXT,
COALESCE(EQ_GRADE.TYPECODE,' ') AS EQ_GRADE_CD,
COALESCE(EQ_GRADE.DESCRIPTION,'Not Defined') AS EQ_GRADE_TEXT,
COALESCE(EQ_CONST_DTL.TYPECODE,' ') AS EQ_BUILD_CONSTR_DTL_CD,
COALESCE(EQ_CONST_DTL.DESCRIPTION,'Not Defined') AS EQ_BUILD_CONSTR_DTL_TEXT,
CASE WHEN COPBUILDING.EXCLEQCOVGBLDGIND = 1 THEN 'Y' WHEN COPBUILDING.EXCLEQCOVGBLDGIND = 0 THEN 'N' ELSE 'U' END AS EXCL_EQ_COVG_BLDG_FL,
CASE WHEN COPBUILDING.EXCLFLOODCOVGBLDGIND = 1 THEN 'Y' WHEN COPBUILDING.EXCLFLOODCOVGBLDGIND = 0 THEN 'N' ELSE 'U' END AS EXCL_FLOOD_COVG_BLDG_FL,
coalesce(COPBUILDING.COPHAZARDGRADE,' ') AS HAZARD_GRADE,
CASE WHEN COPBUILDING.INDUSTRYEQUIPMENTIND = 1 THEN 'Y' WHEN COPBUILDING.INDUSTRYEQUIPMENTIND = 0 THEN 'N' ELSE 'U' END AS INDUSTRY_EQUIP_FL,
COALESCE(COPBUILDING.MODIFIEDMERCALLIINTENSITY,' ') AS MODIFIED_MER_CALL_INTENSITY,
COPBUILDING.NUMOFRESUNITS AS NUM_OF_RES_UNITS,
COPBUILDING.PERCENTOFOCC AS PERCENT_OF_OCC,
COALESCE(COP_VALUVATION.TYPECODE,' ') AS VALUATION_LAW_CD,
COALESCE(COP_VALUVATION.DESCRIPTION,'Not Defined') AS VALUATION_LAW_TEXT,
COPBUILDING.branchid as SRC_BRANCHID,
COPBUILDING.fixedid as SRC_FIXEDID,
COPBUILDING.effectivedate as SRC_EFFECTIVEDATE,
COPBUILDING.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
COPBUILDING.createtime as SRC_CREATETIME,
COPBUILDING.updatetime  as SRC_UPDATETIME,
COPBUILDING.publicid as SRC_PUBLICID,
polper.updatetime as updatetime_tab2,
COPBUILDING.updatetime as updatetime_tab1,
job.updatetime as updatetime_tab3,
' ' as LEAD_ABATEMENT_CD,
NULL as BLDG_ELVTN_DS
                
FROM   v_pcx_copbuilding_ext as COPBUILDING 
INNER JOIN v_pc_policyperiod polper
on COPBUILDING.BranchID=polper.ID
and COPBUILDING.publicid=polper.pcx_copbuilding_ext_publicid
and COPBUILDING.updatetime=polper.pcx_copbuilding_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
 
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
 
left join v_pctl_job jbt
ON job.Subtype = jbt.id
                
LEFT JOIN  v_pctl_nwconstructiontype_ext CONST_TYPE
    ON COPBUILDING.CONSTRUCTIONTYPE = CONST_TYPE.ID
	
LEFT JOIN v_pctl_copeqclass_ext EARTH_Q_CLASS
    ON COPBUILDING.COPEQCLASS_EXT = EARTH_Q_CLASS.ID
    LEFT JOIN v_pctl_copeqgrade_ext EQ_GRADE
    ON COPBUILDING.COPEQGRADE_EXT = EQ_GRADE.ID
    LEFT JOIN v_pctl_copeqconsdetail_ext EQ_CONST_DTL
    ON COPBUILDING.COPEQCONSDETAIL_EXT = EQ_CONST_DTL.ID
    LEFT JOIN v_pctl_copvaluationlaw_ext COP_VALUVATION
    ON COPBUILDING.COPVALUATIONLAW_EXT = COP_VALUVATION.ID
    WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
    )
 

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_jurs_COPJurisdiction (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_copjurisdiction_ext_micro_batch),
  pcx_copjurisdiction_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_copjurisdiction_ext_micro_batch )
,v_pcx_copjurisdiction_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_copjurisdiction_ext.*
			from {rawDB}.pcx_copjurisdiction_ext          
            inner join pcx_copjurisdiction_ext_micro_batch   mb  
			   on mb.branchid = pcx_copjurisdiction_ext.branchid 
			where pcx_copjurisdiction_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,PL.updatetime,PL.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(PL.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_PC_POLICYLINE  PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and polper.updatetime <= PL.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,polper.updatetime,PL.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(PL.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_PC_POLICYLINE PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and PL.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
*******/
             ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_copjurisdiction_ext_publicid,
    p.updatetime as pcx_copjurisdiction_ext_updatetime
  from
    v_pcx_copjurisdiction_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization---------------
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'||'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' ||'{CVRBL_TYPE_CD_VAL}' || '-' || CAST(CAST (COPJURD.FixedID AS INTEGER) AS VARCHAR (255))) AS JURS_KEY,
UPPER ('GWPC'|| '-' ||CAST( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
UPPER ('GWPC' ||'-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'COPLine' || '-' || CAST(CAST (COPJURD.COPLINE AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS OWNING_CVRBL_KEY,
CAST ( COALESCE (COPJURD.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (COPJURD.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
COALESCE (STATE.TYPECODE,'') AS JURS_CD,
'GWPC'||'-'||'COP'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
 COALESCE (STATE.DESCRIPTION,'Not Defined') AS JURS_TEXT,
  NULL AS ANNIV_RATING_DT,
  0 AS JURS_PREM,
0 AS SCHDL_RTG_ABS_THRSHLD,
  ' ' AS SCHDL_RTG_ELGBTY_IND,
  0 AS NON_AUDIT_PREM_AMT,
   ' ' AS SPLIT_RTG_IND,
 NULL AS ADDL_INS_HH_PER_LIB_CNT,
   'U' AS LESSOR_RISK_LIVESTK_FL,
  NULL AS PRIM_LIVESTK_NO,
  ' ' AS PRIM_LIVESTK_CD,
   'Not Defined' AS PRIM_LIVESTK_TEXT,
  NULL AS SEC_LIVESTK_NO,
  ' ' AS SEC_LIVESTK_CD,
  'Not Defined' AS SEC_LIVESTK_TEXT,
 NULL AS TOTAL_LIVESTK_NO,
	NULL AS MINE_SUBS_COVG, 
    'COP' AS LOB_CD,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
COPJURD.branchid as SRC_BRANCHID,
COPJURD.fixedid as SRC_FIXEDID,
COPJURD.effectivedate as SRC_EFFECTIVEDATE,
COPJURD.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
COPJURD.createtime as SRC_CREATETIME,
COPJURD.updatetime  as SRC_UPDATETIME,
COPJURD.publicid as SRC_PUBLICID,
COPJURD.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3,
null as ELGBL_MANL_PREM_AM ,
null as ELGBL_WRTN_PREM_AM ,
null as TOT_MANL_PREM_AM ,
null as TOT_WRTN_PREM_AM ,
'NOKEY' AS LINE_CL_CD_KEY
 
FROM 
v_pcx_copjurisdiction_ext as COPJURD
INNER JOIN v_pc_policyperiod polper
on COPJURD.BranchID=polper.ID
and COPJURD.publicid=polper.pcx_copjurisdiction_ext_publicid
and COPJURD.updatetime=polper.pcx_copjurisdiction_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_jurisdiction STATE
Cross Join Events_Max_Updatetime mb  On STATE.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) STATE 
on COPJURD.STATE = STATE.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_flood_info_COPBldg (rawDB,CVRBL_TYPE_CD_VAL):
  print("build_ds_flood_info")
  harmz_query = """
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_floodinfo_ext_micro_batch), 
 pcx_floodinfo_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_floodinfo_ext_micro_batch )
 
,v_pcx_floodinfo_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_floodinfo_ext.*
			from {rawDB}.pcx_floodinfo_ext        
            inner join pcx_floodinfo_ext_micro_batch mb  
			   on mb.branchid = pcx_floodinfo_ext.branchid 
			where pcx_floodinfo_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,PL.updatetime,PL.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(PL.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_PC_POLICYLINE  PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and polper.updatetime <= PL.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,polper.updatetime,PL.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(PL.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_PC_POLICYLINE PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and PL.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
*******/
             ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_floodinfo_ext_publicid,
    p.updatetime as pcx_floodinfo_ext_updatetime
  from
    v_pcx_floodinfo_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization---------------
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pcx_copbuilding_ext as 
(
  --consider parent record as driving record
  select * from 
    (select child.*,driv.publicid as PCX_FLOODINFO_EXT_publicid,driv.updatetime as PCX_FLOODINFO_EXT_updatetime,
      row_number() over (partition by driv.publicid,driv.updatetime,driv.COPBUILDING  --updatetime should be from parent in partition clause
      order by (unix_timestamp(driv.updatetime) - unix_timestamp(child.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from V_PCX_FLOODINFO_EXT driv
      JOIN {rawDB}.PCX_COPBUILDING_EXT child
        on driv.COPBUILDING = child.FIXEDID 
		AND driv.BRANCHID = child.BRANCHID
        and child.updatetime <= driv.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select child.*,driv.publicid as PCX_FLOODINFO_EXT_publicid,driv.updatetime as PCX_FLOODINFO_EXT_updatetime,
      row_number() over (partition by driv.publicid,child.updatetime,driv.COPBUILDING   --updatetime should be from childe in partition clause
      order by (unix_timestamp(child.updatetime) - unix_timestamp(driv.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from V_PCX_FLOODINFO_EXT driv
      JOIN {rawDB}.PCX_COPBUILDING_EXT  child
        on driv.COPBUILDING = child.FIXEDID 
		AND driv.BRANCHID = child.BRANCHID
        and driv.updatetime <= child.updatetime  --parent update time <= child update time
    ) where rn=1 
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
),
HRZ_Query as 
(
SELECT 
  coalesce(UPPER('GWPC' || '-' || cast(cast(polper.PeriodID as integer) as varchar(255)) || 
      CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) 
      ELSE '' END || '-' || 'COPBldg' ||'-'||
      cast(cast(flood.FixedID as integer) as varchar(255))),'NOKEY') AS FLOOD_INFO_KEY
   
    ,coalesce(UPPER('GWPC' || '-' || cast(cast(polper.PeriodID as integer) as varchar(255)) || 
    CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) 
    ELSE ''
    END),'NOKEY') as POL_KEY  
      ,coalesce(UPPER('GWPC' || '-' || cast(cast(polper.PeriodID as integer) as varchar(255)) || 
   CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) 
        ELSE '' END ||'-' ||
  'COPBldg' || '-' || cast(cast(COPBldg.FixedID as integer) as varchar(255))),'NOKEY')  as CVRBL_KEY
,cast(coalesce(flood.EffectiveDate, polper.PeriodStart) as date) as END_EFF_DT
,cast(coalesce(flood.ExpirationDate, polper.PeriodEnd) as date) as END_EXP_DT
,'GWPC' as SOURCE_SYSTEM
,'COP' AS LOB_CD
,coalesce('COPBldg',' ') as CVRBL_TYPE_CD
,'GWPC'||'-'||'COP'||'-'||'COPBldg' AS PARTITION_VAL
,cast(coalesce(flood.FLASHFLOODRISKSCORE,0) as NUMERIC(18,4)) AS FLASH_FLOOD_RISK_SCORE
,cast(coalesce(flood.FLOODDISTANCETO100YRZONES,0) as NUMERIC(18,4)) AS FLOOD_DISTNC_100_ZONE
,cast(coalesce(flood.FLOODDISTANCETO500YRZONES,0) as NUMERIC(18,4)) AS FLOOD_DISTNC_500_ZONE
,cast(coalesce(flood.FLOODELEVATIONVARIANCE,0) as NUMERIC(18,4)) AS FLOOD_ELVTN_VRNC
,coalesce(floodres.TYPECODE, ' ') AS FLOOD_RESULT_CD
,cast(coalesce(flood.FLOODRISKSCORE,0) as NUMERIC(18,4)) AS FLOOD_RISK_SCORE
,coalesce(flood.FLOODZONE,' ') AS FLOOD_ZONE
,coalesce(case when status.TypeCode = 'Bound' then job.CloseDate else coalesce (polper.UpdateTime, polper.CreateTime) end ,to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS
,coalesce(floodres.description,'Not Defined') as FLOOD_RESULT_TEXT
,flood.branchid as SRC_BRANCHID 
,flood.fixedid as SRC_FIXEDID 
,flood.effectivedate as SRC_EFFECTIVEDATE 
,flood.expirationdate as SRC_EXPIRATIONDATE 
,polper.periodstart as POLPER_PERIODSTART 
,polper.periodend as POLPER_PERIODEND 
,polper.publicid as POLPER_PUBLICID 
,flood.createtime as SRC_CREATETIME 
,flood.updatetime  as SRC_UPDATETIME 
,flood.publicid as SRC_PUBLICID 
,flood.updatetime as updatetime_tab1 
,polper.updatetime as updatetime_tab2 
,job.updatetime as updatetime_tab3
from 
v_pcx_floodinfo_ext flood
inner join v_pc_policyperiod polper
on flood.BranchID=polper.ID
inner join v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
inner join v_pcx_copbuilding_ext copbldg
on flood.copbuilding= copbldg.fixedid
and flood.branchid = copbldg.branchid
and coalesce(flood.effectivedate, polper.periodstart) >= coalesce(copbldg.effectivedate, polper.periodstart)
and coalesce(flood.effectivedate, polper.periodstart) <  coalesce(copbldg.expirationdate, polper.periodend) 
inner join v_pctl_policyperiodstatus status
on polper.status = status.ID
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_hazardresult_ext floodres
Cross Join Events_Max_Updatetime mb  On floodres.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) floodres 
on flood.FLOODRESULT = floodres.id
left join v_pctl_job jbt
ON job.Subtype = jbt.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)
 
"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)