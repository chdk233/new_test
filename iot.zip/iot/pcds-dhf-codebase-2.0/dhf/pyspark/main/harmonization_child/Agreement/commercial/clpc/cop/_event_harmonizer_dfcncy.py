# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

# MAGIC %run ../../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../_event_library_agreement

# COMMAND ----------

# MAGIC %run ../../../../../harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

# MAGIC %scala
# MAGIC // configuration to reduce th DBIO file fragments 
# MAGIC spark.conf.set("spark.databricks.io.cache.enabled", "false")

# COMMAND ----------

def agreement_clpc_cop_dfncy(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str):
    print("microBatchDF...in agreement_clpc_cop_dfncy: \n")
    starttime = datetime.now()  
    try:
          
          TaskGroupId = f'{param_str.split("#")[7]}'
          taskGroup = getTaskGroup(TaskGroupId ) 
          parent = taskGroup["source_table"] 
          key_col = target[3:]+"_KEY"
          key = target[3:]+"_KEY,END_EFF_DT"
          scdkey = target[3:]+"_KEY,ETL_ROW_EFF_DTS,END_EFF_DT"
          micro_batch_view =f"{parent}" +"_micro_batch" 
          print("micro_batch_view"+micro_batch_view)  
          microBatchDF.createOrReplaceGlobalTempView(micro_batch_view) 
          df_parm = spark.sql(f""" select source_system,LOB,coverable_type from {harmonizedDB}.AGGREMENT_GWPC_IMCOP_KEY_XREF where TABLE_NAME = '{target}'  LIMIT 1 """) 
          source_system = (df_parm.select(col("source_system")).collect()[0][0]).strip()
          lob_cd = (df_parm.select(col("LOB")).collect()[0][0]).strip()
          cvrbl_type = (df_parm.select(col("coverable_type")).collect()[0][0]).strip()
          partition_val = f"""{source_system}-{lob_cd}-{cvrbl_type}"""
          print("partition_val :"+partition_val)
          harmonized_table = harmonizedDB +"."+target
          
          if(microBatchDF.count() > 0):
        
              print("********************Before build  copdfncy query ******* :-") 
              harmz_query =  globals()['build_' + target](micro_batch_view,rawDB,cvrbl_type,lob_cd,source_system)    
              print("********************After copdfncy_query******* :-")                    
              print("********************Before generate Query ******* :-") 
              harmz_query = generate_DHF_query(harmz_query, scdkey, harmonized_table, micro_batch_view)
              print("********************After generate Query******* :-") 
              print("********************Executing the harmz_query******* :-")
              df = spark.sql(harmz_query)
              #caching the result of the harmonization query
              print("*********************harmz_query execution is complete******* :-")
              df.persist()


              print("Entering deduphashDF for Target- ",target ," for LOB - ",lob_cd," cvrbl_type - ",  cvrbl_type)
              deduphashDF = removeDuplicatesMicrobatchByHash_clt(df,  key)
              deduphashDF.persist()
              print("deduphashDF  count for " , cvrbl_type ,"--" ,deduphashDF.count(),"\n")
              
              print("count before scd Merge ", df.count(), datetime.now(), "\n")
              surrogateID = f'{harmonized_table.split(".")[1][3:]}_ID'     
              scdDF = scdMerge_clt_perf(deduphashDF, harmonized_table, scdkey, "PARTITION_VAL", partition_val, surrogateID )
              scdDF.persist()
              print("scdDFCount:",scdDF.count(),datetime.now(),"\n")
              scdDF.show(1)

                      
              print("Entering auditDF for Target- ",target ," for LOB - ",lob_cd," cvrbl_type - ",  cvrbl_type)
              auditDF = addAuditColumnsRemoveDupsCdcSyncMultistream_clt_pt_perf(scdDF, harmonized_table, key,"PARTITION_VAL",  partition_val)
              auditDF.persist() 
              print("auditDF  count for " ,cvrbl_type ,"--" , auditDF.count(), " Completed at ", datetime.now(), "\n")

              print("Entering surrogateKeyDF for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type, " \n")
              surrogateKeyDF = addSurrogateKey_Non_UDM(auditDF, harmonized_table)
              print("surrogateKeyDF  count for " ,cvrbl_type ,"--" , surrogateKeyDF.count(), " Completed at ", datetime.now(), "\n")

              #caching the result of the surrogate key function output
              surrogateKeyDF.persist()

              print("Entering defaultMerge for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type, " \n")
              defaultMergeCdcMultistream_clt(surrogateKeyDF, harmonized_table, "PARTITION_VAL", partition_val)
              print("defaultMergeCdcMultistream_clt  count for " ,cvrbl_type ,"--" ,  " Completed at ", datetime.now(), "\n")
                      
            # print("Entering orphanRecords_Clt_pt  for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type, " \n")
            #  orphanRecords_Clt_pt (df,harmonized_table, "PARTITION_VAL",  partition_val, keycol) 
            #  print("orphanRecords_Clt completed for Target- ",target ," for LOB - ",lob_cd," cvrbl_type - ",  cvrbl_type,  datetime.now(), "\n")
      
          else :
                print("Micro Batch Size is 0, Skipping rest of the functions for Target - " , target,"  and partition-",partition_val,"\n")
    except Exception as err:
            print("In Exception", err) 

    finally:
            print("Job Successfully Completed")
            endtime = datetime.now()
            print(" NoteBook Execution Start Time# ", starttime)
            print(" NoteBook Execution End  Time# " ,endtime)
            print(" NoteBook Run Time# " ,endtime - starttime )