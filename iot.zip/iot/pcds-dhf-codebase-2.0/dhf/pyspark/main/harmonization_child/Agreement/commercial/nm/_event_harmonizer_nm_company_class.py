# Databricks notebook source
# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_nm_company_class(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in NM Company Class: \n")
  harmz_query = """ 
    select concat('NM-',companyclass.companyid,'-',companyclass.submissionid,'-',companyclass.mainclassificationtype,'-',companyclass.classificationCode) as NM_COMPANY_CLASS_KEY,
		concat('NM-',companyclass.companyid,'-',companyclass.submissionid) as NM_RETRIEVE_KEY, 
		companyclass.mainclassificationtype as MAIN_CLASS_TYPE_DESC, 
		companyclass.classificationType as DTL_CLASS_TYPE_DESC,
		companyclass.classificationCode as CLASS_CD,     
		companyclass.classificationConfScore as CLASS_CONFIDENCE_SCORE,
		companyclass.classificationCodeDesc as CLASS_CD_DESC,
		'NM' as SOURCE_SYSTEM,
		companyclass.timestamp as ETL_ROW_EFF_DTS 
		from global_temp.nm_company_class_micro_batch micro_companyclass

		inner join 
 
		(select * from 
        (select *,row_number() over (partition by companyId,submissionId,mainclassificationtype,classificationCode,timestamp,offset order by timestamp desc) as rn 
				from
				(select nm_company_class.*
					from {rawDB}.nm_company_class nm_company_class  
            
				inner join global_temp.nm_company_class_micro_batch mb  
					ON mb.nm_submissionId = nm_company_class.submissionId 
					and mb.nm_classificationCode = nm_company_class.classificationCode 
					and mb.nm_companyId = nm_company_class.companyId 
                    and mb.nm_mainclassificationtype = nm_company_class.mainclassificationtype
						where nm_company_class.timestamp <= mb.nm_timestamp  
							)
						) where rn = 1)  companyclass
			on  companyclass.submissionId = micro_companyclass.nm_submissionId 
			and companyclass.classificationCode = micro_companyclass.nm_classificationCode 
			and companyclass.companyId = micro_companyclass.nm_companyId
            and companyclass.mainclassificationtype = micro_companyclass.nm_mainclassificationtype
            
"""
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB)       
  print("harmz_query after rawDB replace: "+ harmz_query)
    
  microBatchDF.createOrReplaceGlobalTempView(f"nm_company_class_micro_batch")
  queryDF=spark.sql(harmz_query)
  print("queryDF:")
  queryDF.show(3)  
  
  harmonized_table = f"{harmonizedDB}.{target}"
  
  queryDF.createOrReplaceGlobalTempView("hmquery_nm_company_class")
  hashDF = addHashColumn_clt("hmquery_nm_company_class")
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, "NM_COMPANY_CLASS_KEY")
   
  auditDF = addAuditColumns_clt(dedupDF, "NM_COMPANY_CLASS_KEY")

  surrogateKeyDF = addSurrogateKey_clt(auditDF,harmonized_table) 
   
  defaultMerge_clt(surrogateKeyDF,harmonized_table)  
  
  print("Job Successfully Completed")
  endtime = datetime.now()

