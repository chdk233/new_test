# Databricks notebook source
from pyspark.sql.functions import lit,col,count,row_number
from pyspark.sql import Window

# COMMAND ----------

def clean_metrics_table(  DB: str,  parent:str):
  df = spark.sql( f"""  SHOW TABLES FROM  {DB} LIKE "harmonize_*_{parent}"    """) 

  for rec in df.collect():
    tbl = i[1]
    print(f"dropping  tracking table   {DB}.{tbl}")
    spark.sql(f"DROP TABLE IF EXISTS {DB}.{tbl}")

# COMMAND ----------

def build_term( rawDB: str,  parent:str ,  cvrbl_type:str, source_system:str, lob_cd:str,src_cvrbl_type:str):
  table_type ="" 
  parent1 = parent.upper() 
  micro_bacth = "global_temp." + parent + "_micro_batch" 
  NOTERMS = "'Noterms',IF("
  
  ttype = ""
  if(parent1.endswith("COND_EXT")):
    ttype = "COND"
  elif(parent1.endswith("EXCL_EXT")):
    ttype = "EXCL"
  elif(parent1.endswith("COV_EXT")):
    ttype = "COVG"
    
  df1= spark.sql(   f"SHOW COLUMNS IN  {rawDB}.{parent}").filter(col("col_name").like("%term%")).filter(~col("col_name").like("%avl%")).withColumn("table_name" ,lit(parent))
  
  df3 = df1.withColumn("tot_rows", count("*").over( Window.partitionBy("table_name")))\
            .withColumn("row_num",row_number().over(Window.partitionBy("table_name").orderBy(col("col_name")) ) )
  
  print("cvrbl_type is : ", cvrbl_type)
  print("\n ttype is : ", ttype)

  STACK_COUNT = int(df3.count()) + 1
  VIEW_NM = f"V_{cvrbl_type}_{ttype}"
  STACK  = f"stack ({STACK_COUNT},"

  print("\n VIEW_NM is : ", VIEW_NM)
  
  df3.createOrReplaceTempView(VIEW_NM)
  
  df = spark.sql( f""" select  row_num ,tot_rows ,  case when row_num = tot_rows then   concat( 'ISNULL(' , col_name ,'),',"'",'1',"'",',NULL)' )   else concat( 'ISNULL(' , col_name ,')',' AND')  END AS tabl_noterm_cols ,
                        case when row_num = tot_rows then   concat( "'" , col_name , "'" , ', TRIM(CAST(' , col_name , ' AS VARCHAR(255))) ') ELSE concat(  "'" , col_name , "'"  ,' , TRIM(CAST(' ,col_name , ' AS VARCHAR(255))), ')  END AS stack_cols  
                  FROM  {VIEW_NM} """ )
  
  tabl_noterm_cols = ""
  stack_cols = ""
  for rec1 in df.collect():
    tabl_noterm_cols = str(rec1[2])
    stack_cols = str(rec1[3])
    NOTERMS_value =  tabl_noterm_cols.strip()       
    STACK_value =  stack_cols.strip()  
    NOTERMS = NOTERMS  + ' ' + NOTERMS_value       
    STACK = STACK   + ' ' + STACK_value
    
  harmz_query = f""" 
           WITH SESSION_PARAM as (SELECT '{source_system}' as source_system , to_date('9999-12-31','YYYY-MM-DD') as to_date  , to_date('1900-01-01','YYYY-MM-DD')  as from_date , '{cvrbl_type}' as CVRBL_TYPE, '{lob_cd}' as LOB_CD  ) 
         ,  {parent}_micro_batch  as (select distinct branchid,updatetime from   {micro_bacth} )  
         ,  Events_Max_Updatetime as (Select max(updatetime) as mb_max_updatetime from {micro_bacth} )
        ,v_pctl_policyperiodstatus as 
         (
            select * from
                (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
                   from {rawDB}.pctl_policyperiodstatus status    
                   Cross Join Events_Max_Updatetime mb  
                    On status.z_meta_event_timestamp  <= mb.mb_max_updatetime
                ) where rn=1
         )

        ,v_pc_etlclausepattern as 
         (
            select * from
                (select *,row_number() over (partition by Id order by z_meta_event_timestamp   desc) as rn 
                   from {rawDB}.pc_etlclausepattern etlclausepattern    
                   Cross Join Events_Max_Updatetime mb  
                    On etlclausepattern.z_meta_event_timestamp  <= mb.mb_max_updatetime
                ) where rn=1
         )
        ,v_pc_etlcovtermpattern as 
         (
            select * from
                (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
                   from {rawDB}.pc_etlcovtermpattern etlcovtermpattern    
                   Cross Join Events_Max_Updatetime mb  
                    On etlcovtermpattern.z_meta_event_timestamp  <= mb.mb_max_updatetime
                ) where rn=1
         )
        ,v_pc_etlcovtermpackage as 
         (
            select * from
                (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
                   from {rawDB}.pc_etlcovtermpackage etlcovtermpackage    
                   Cross Join Events_Max_Updatetime mb  
                    On etlcovtermpackage.z_meta_event_timestamp  <= mb.mb_max_updatetime
                ) where rn=1
         )
        ,v_pc_etlpackterm as 
         (
            select * from
                (select *,row_number() over (partition by Id order by z_meta_event_timestamp   desc) as rn 
                   from {rawDB}.pc_etlpackterm etlpackterm    
                   Cross Join Events_Max_Updatetime mb  
                    On etlpackterm.z_meta_event_timestamp  <= mb.mb_max_updatetime
                ) where rn=1
         )
        ,v_pc_etlcovtermoption as 
         (
            select * from
                (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
                   from {rawDB}.pc_etlcovtermoption etlcovtermoption    
                   Cross Join Events_Max_Updatetime mb  
                    On etlcovtermoption.z_meta_event_timestamp  <= mb.mb_max_updatetime
                ) where rn=1
         )
        ,v_pctl_job as 
         (
            select * from
                (select *,row_number() over (partition by Id order by z_meta_event_timestamp   desc) as rn 
                   from {rawDB}.pctl_job job    
                   Cross Join Events_Max_Updatetime mb  
                    On job.z_meta_event_timestamp  <= mb.mb_max_updatetime
                ) where rn=1
         )

        ,v_{parent} as
        (select * from 
                (select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
                 from
                 (select {parent}.*
                    from {rawDB}.{parent}          
                    inner join  {micro_bacth}   mb  
                       on mb.branchid = {parent} .branchid 
                    where {parent} .updatetime <= mb.updatetime  
                    )
                ) where rn = 1)  

          /**********,v_pc_policyperiod as 
        (
          --consider parent record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,p.updatetime,p.BranchID  --updatetime should be from parent in partition clause
              order by (unix_millis(p.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_{parent}  p
              JOIN  {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and polper.updatetime <= p.updatetime  --child update time <= parent update  time
            ) where rn=1
          union 
          --consider child record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,polper.updatetime,p.BranchID  --updatetime should be from child in partition clause
              order by (unix_millis(polper.updatetime) - unix_millis(p.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
              from v_{parent}  p
              JOIN {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and p.updatetime <= polper.updatetime --parent update time <= child update time
            ) where rn=1
        )************************/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as {parent}_publicid,
            p.updatetime as {parent}_updatetime
          from
            v_{parent}  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
        , v_pc_job as 
        (
          --consider parent record as driving record
          select * from 
            (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
              row_number() over (partition by polper.publicid,polper.updatetime,polper.Jobid  --updatetime should be from parent in partition clause
              order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_pc_policyperiod polper
              JOIN {rawDB}.pc_job  job
                on polper.JobId = Job.ID 
                and job.updatetime <= polper.updatetime  --child update time <= parent update time
            ) where rn=1 
          union
          --consider child record as driving record
          select * from 
            (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
              row_number() over (partition by polper.publicid,job.updatetime,polper.Jobid   --updatetime should be from childe in partition clause
              order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_pc_policyperiod polper
              JOIN {rawDB}.pc_job  job
                on polper.JobId = Job.ID 
                and polper.updatetime <= job.updatetime  --parent update time <= child update time
            ) where rn=1 
        )

        , HRZ_Query as (
                                  select   DISTINCT
                                    UPPER(CAST( SP.SOURCE_SYSTEM || '-' || CAST(CAST( TERM.PeriodId AS INTEGER) AS VARCHAR(100)) ||     
                                      CASE WHEN TERM.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(TERM.publicID AS VARCHAR(255)) 
                                      ELSE ''
                                      END || '-' || 
                                      SP.CVRBL_TYPE || '-' || 
                                      CAST(CAST( TERM.FixedID AS INTEGER) AS VARCHAR(100)) || '-' ||
                                      CASE WHEN (termpatt.PatternID IS NULL) AND (pkgs.PatternID IS NULL) then clausepatt.PatternID
                                           WHEN pkgs.PatternID IS NULL then termpatt.PatternID
                                           ELSE termpatt.PatternID || '-' || pkgs.PatternID
                                      END 
                                    AS VARCHAR(255)))AS {ttype}_TERM_KEY             

                                    ,UPPER(SP.SOURCE_SYSTEM || '-' || cast(CAST( TERM.PeriodId AS INTEGER) as varchar(255)) || 
                                        CASE WHEN TERM.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(TERM.publicID AS VARCHAR(255)) 
                                        ELSE ''
                                        END )as POL_KEY                                
                                    ,UPPER(CASE WHEN TERM.CVRBL IS NOT NULL
                                         THEN SP.SOURCE_SYSTEM || '-' || CAST(CAST( TERM.PeriodId AS INTEGER) AS varchar(255)) || 
                                         CASE WHEN TERM.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(TERM.publicID AS VARCHAR(255)) 
                                              ELSE ''
                                              END || '-' ||  SP.CVRBL_TYPE || '-'|| CAST(CAST( TERM.CVRBL AS INTEGER) AS varchar(255))
                                              ELSE NULL
                                     END )AS CVRBL_KEY  

                                    ,UPPER(SP.SOURCE_SYSTEM  || '-' || CAST(CAST( TERM.PeriodId AS INTEGER) AS VARCHAR(100)) ||    
                                        CASE WHEN TERM.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(TERM.publicID AS VARCHAR(255)) 
                                        ELSE ''
                                        END || '-' || SP.CVRBL_TYPE || '-' || CAST(CAST( TERM.FixedID AS INTEGER) AS VARCHAR(100)) ) AS LINE_{ttype}_KEY

                                  ,CAST(COALESCE(TERM.EffectiveDate,TERM.PeriodStart) AS DATE)AS END_EFF_DT
                                  ,CAST(COALESCE(TERM.ExpirationDate,TERM.PeriodEnd) AS DATE)AS END_EXP_DT
                                  ,SP.SOURCE_SYSTEM as SOURCE_SYSTEM
                                  ,SP.CVRBL_TYPE AS CVRBL_TYPE_CD
                                  ,TERM.PatternCode AS {ttype}_CD
                                  ,CASE WHEN (termpatt.PatternID IS NULL) and (pkgs.Name IS NULL) THEN clausepatt.PatternID
                                    WHEN pkgs.Name IS NULL THEN termpatt.PatternID
                                    ELSE CAST(termpatt.PatternID || '-' || pkgs.Name as varchar(255))
                                  END AS {ttype}_TERM_CD                          
                                  ,CASE WHEN (termpatt.PatternID IS NULL) and (pkgs.Name IS NULL) THEN clausepatt.codeidentifier
                                    WHEN pkgs.Name IS NULL THEN termpatt.codeidentifier
                                    ELSE CAST(termpatt.codeidentifier || '-' || pkgs.Name as varchar(255))
                                   END AS {ttype}_TERM_TEXT 
                                    ,COALESCE(termpkg.NAME, termopt.OPTIONCODE, TERM.TermValue) as TERM_VAL_CD
                                    ,COALESCE (
                                     CAST (pkgs.VALUE AS VARCHAR (255)),
                                     CAST (termopt.VALUE AS VARCHAR (255)),
                                     CASE   WHEN TRIM ( REGEXP_REPLACE (TERM.TermValue, '[0-9\.]', ''))
                                         <> ''  THEN NULL ELSE TERM.TermValue  END ) AS TERM_VAL_AMT                           
                                    ,COALESCE(pkgs.VALUETYPE, termpatt.VALUETYPE) as TERM_VAL_TYPE_CD                              
                                    ,CASE WHEN TERM.TypeCode = 'Bound' THEN TERM.CloseDate
                                        ELSE COALESCE(TERM.UpdateTime, TERM.CreateTime)
                                     END AS ETL_ROW_EFF_DTS                          
                                        ,'NOKEY' AS POL_LINE_KEY                            
                                       -- ,CAST(TERM.PeriodStart AS DATE) AS POL_EFF_DT
                                      --  ,CAST(TERM.PeriodEnd AS DATE) AS POL_EXP_DT
                                      --  ,TERM.changetype AS POL_CHNG_TYPE  
                                       ,  CASE WHEN term_hard_delete.publicid is not null THEN 'Y' ELSE 'N' END AS QT_DELETE_IND
                                       , NULL as SPCL_TERM_VAL_TT
                                        , SP.LOB_CD AS LOB_CD 
                                        , SP.SOURCE_SYSTEM||'-'||SP.LOB_CD||'-'||SP.CVRBL_TYPE AS PARTITION_VAL
                                        , updatetime_tab1 , updatetime_tab2 , updatetime_tab3
                                         ,  SRC_BRANCHID , SRC_FIXEDID , SRC_EFFECTIVEDATE , SRC_EXPIRATIONDATE ,  POLPER_PERIODSTART ,  POLPER_PERIODEND , POLPER_PUBLICID , SRC_PUBLICID , SRC_UPDATETIME , SRC_CREATETIME
                                     FROM ( select PeriodID,PublicID, CreateTime,UpdateTime, typecode, FixedID, PeriodStart, PeriodEnd, EffectiveDate, 
                                       ExpirationDate, CloseDate,PatternCode,ModelNumber, CVRBL, CoverageTerm, TermValue,changetype  
                                         , updatetime_tab1 , updatetime_tab2 , updatetime_tab3
                                        , SRC_BRANCHID , SRC_FIXEDID , SRC_EFFECTIVEDATE , SRC_EXPIRATIONDATE ,  POLPER_PERIODSTART ,  POLPER_PERIODEND , POLPER_PUBLICID , SRC_PUBLICID , SRC_UPDATETIME , SRC_CREATETIME
                                from (
                                SELECT  
                                    POLPER.PeriodID
                                   ,POLPER.PublicID
                                   ,POLPER.CreateTime
                                   ,POLPER.UpdateTime
                                   ,STATUS.TYPECODE
                                   ,FixedID
                                   ,POLPER.PeriodStart
                                   ,POLPER.PeriodEnd
                                   ,EffectiveDate
                                   ,ExpirationDate
                                   ,job.CloseDate
                                   ,PatternCode
                                   ,POLPER.ModelNumber 
                                   ,{ttype}.changetype
                                   , POLPER.updatetime as updatetime_tab1 
                                   , {ttype}.updatetime as updatetime_tab2 
                                   , job.updatetime as updatetime_tab3 
                                   , {ttype}.branchid as SRC_BRANCHID
                                   , {ttype}.fixedid as SRC_FIXEDID
                                   , {ttype}.effectivedate as SRC_EFFECTIVEDATE
                                   , {ttype}.expirationdate as SRC_EXPIRATIONDATE
                                   , POLPER.periodstart as POLPER_PERIODSTART
                                   , POLPER.periodend as POLPER_PERIODEND
                                   , POLPER.publicid as POLPER_PUBLICID
                                   , {ttype}.publicid as SRC_PUBLICID
                                   , {ttype}.updatetime as SRC_UPDATETIME
                                   , {ttype}.createtime as SRC_CREATETIME
                                   ,{src_cvrbl_type} as cvrbl ,{STACK},{NOTERMS}                           
                                   ) AS (coverageterm, termvalue)

                                   FROM
                                       v_{parent}  {ttype}
                                       JOIN v_pc_policyperiod polper 
                                        on {ttype}.BranchID = polper.ID 
                                       and {ttype}.publicid=polper.{parent}_publicid
                                       and {ttype}.updatetime=polper.{parent}_updatetime

                                        JOIN v_pc_job job 
                                        on polper.JobID = job.ID
                                        and polper.publicid=job.pc_policyperiod_publicid
                                        and polper.updatetime=job.pc_policyperiod_updatetime                      

                                        JOIN  v_pctl_policyperiodstatus STATUS ON STATUS.ID = POLPER.Status and not ( status.typecode = 'Bound' and job.closedate is null)

                                        left join v_pctl_job jbt on job.Subtype = jbt.id 

                                        WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
                                         ) {ttype}_PIVOT 

                                         ) TERM
                               JOIN v_pc_etlclausepattern clausepatt on TERM.PatternCode = clausepatt.PatternID
                LEFT JOIN v_pc_etlcovtermpattern termpatt on clausepatt.ID = termpatt.ClausePatternID and upper(TERM.CoverageTerm) = upper(termpatt.ColumnName)
                LEFT JOIN v_pc_etlcovtermoption termopt on termpatt.ID = termopt.CoverageTermPatternID and TERM.TermValue = termopt.PatternID
                LEFT JOIN v_pc_etlcovtermpackage termpkg on termpatt.ID = termpkg.CoverageTermPatternID and TERM.TermValue = termpkg.PatternID
                LEFT JOIN v_pc_etlpackterm pkgs on termpkg.ID = pkgs.CovTermPackID
                left join (select distinct publicid,updatetime  from {rawDB}.{parent} where z_meta_operation  ='DELETE') as term_hard_delete
                        on TERM.SRC_PUBLICID = term_hard_delete.publicid and term_hard_delete.updatetime=TERM.SRC_UPDATETIME
                                            CROSS JOIN SESSION_PARAM SP              
                                            where TERM.TermValue is not null 
                                            )  
          """
   
  return harmz_query
    

# COMMAND ----------

def buildSIScheduleCoverageLogicGen(rawDB: str,  parent:str ,cvrblType: str):
  dfScheduleCoverageCol =spark.sql(f"show columns in {rawDB}.{parent}").filter(col("col_name").like( "schedulecoverage" ))
  ScheduleCoverageColCount = int(dfScheduleCoverageCol.count())
  
  if(ScheduleCoverageColCount == 1):
    ScheduleCoverageLogic = "schedulecoverage"
  else:
    ScheduleCoverageLogic = "schedulecondition"
  
  return ScheduleCoverageLogic


# COMMAND ----------

def build_si_condition( rawDB: str,  parent:str ,  cvrbl_type:str, childtable:str, source_system:str, lob_cd:str, si_type:str):
  parent1 = parent.upper()
  micro_bacth = "global_temp."+ parent +"_micro_batch_"+cvrbl_type+si_type
  ttype =  cvrbl_type[3:]  
  ScheduleCoverageLogic = buildSIScheduleCoverageLogicGen(rawDB,parent,ttype) 
  print("source_system is : ", source_system)
  print("\n lob_cd is : ", lob_cd)
  harmz_query = f""" WITH SESSION_PARAM as (SELECT '{source_system}' as source_system , '{lob_cd}' as LOB_CD, '{cvrbl_type}' as CVRBL_TYPE , '{si_type}' AS SI_TYPE_COND  ) 
                ,  {parent}_micro_batch  as (select distinct branchid,updatetime from   {micro_bacth} )  
                ,  Events_Max_Updatetime as (Select max(updatetime) as mb_max_updatetime from {micro_bacth} )
                , v_pctl_policyperiodstatus as 
                 (  select * from
                        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
                           from {rawDB}.pctl_policyperiodstatus status    
                                                   Cross Join Events_Max_Updatetime mb  
                                                                On status.z_meta_event_timestamp <= mb.mb_max_updatetime
                                                ) where rn=1
                )

                 /*, v_childtable as 
                 ( select * from
                        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
                           from {rawDB}.{childtable} child  
                                                   Cross Join Events_Max_Updatetime mb  
                                                                On child.z_meta_event_timestamp <= mb.mb_max_updatetime
                                                ) where rn=1
                )*/
                ,v_{parent} as
                (select * from 
                                                (select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
                         from
                         (select {parent}.*
                                                                from {rawDB}.{parent}          
                            inner join  {micro_bacth} mb  
                                                                   on mb.branchid = {parent} .branchid 
                                                                where {parent} .updatetime <= mb.updatetime  
                                                                )
                                                ) where rn = 1)  

                       /**********,v_pc_policyperiod as 
        (
          --consider parent record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,p.updatetime,p.BranchID  --updatetime should be from parent in partition clause
              order by (unix_millis(p.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_{parent}  p
              JOIN  {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and polper.updatetime <= p.updatetime  --child update time <= parent update  time
            ) where rn=1
          union 
          --consider child record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,polper.updatetime,p.BranchID  --updatetime should be from child in partition clause
              order by (unix_millis(polper.updatetime) - unix_millis(p.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
              from v_{parent}  p
              JOIN {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and p.updatetime <= polper.updatetime --parent update time <= child update time
            ) where rn=1
        )************************/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            polper.PolicyNumber,
            polper.editeffectivedate,
            polper.basestate,
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as {parent}_publicid,
            p.updatetime as {parent}_updatetime
          from
            v_{parent}  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
                , v_pc_job as 
                (
                  --consider parent record as driving record
                  select * from 
                    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
                      row_number() over (partition by polper.publicid,polper.updatetime,polper.Jobid  --updatetime should be from parent in partition clause
                      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
                      from v_pc_policyperiod polper
                      JOIN {rawDB}.pc_job  job
                        on polper.JobId = Job.ID 
                        and job.updatetime <= polper.updatetime  --child update time <= parent update time
                    ) where rn=1 
                  union
                  --consider child record as driving record
                  select * from 
                    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
                      row_number() over (partition by polper.publicid,job.updatetime,polper.Jobid   --updatetime should be from childe in partition clause
                      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
                      from v_pc_policyperiod polper
                      JOIN {rawDB}.pc_job  job
                        on polper.JobId = Job.ID 
                        and polper.updatetime <= job.updatetime  --parent update time <= child update time
                    ) where rn=1 
                )
                , v_childtable as 
                (
                  --consider parent record as driving record
                  select * from 
                    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
                      row_number() over (partition by drv.publicid,drv.updatetime,drv.BranchID,drv.{ScheduleCoverageLogic},child.effectivedate,child.expirationdate   --updatetime should be from parent in partition clause
                      order by (unix_millis(drv.updatetime) - unix_millis(child.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
                      from v_{parent} drv
                      JOIN {rawDB}.{childtable} child
                        on drv.{ScheduleCoverageLogic} =child.fixedid
                        and drv.branchid = child.branchid
                        and child.updatetime <= drv.updatetime  --child update time <= parent update time
                    ) where rn=1 
                  union
                  --consider child record as driving record
                  select * from 
                    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
                      row_number() over (partition by drv.publicid,child.updatetime,drv.BranchID,drv.{ScheduleCoverageLogic},child.effectivedate,child.expirationdate   --updatetime should be from childe in partition clause
                      order by (unix_millis(child.updatetime) - unix_millis(drv.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
                      from v_{parent} drv
                      JOIN {rawDB}.{childtable}  child
                        on drv.{ScheduleCoverageLogic} =child.fixedid
                        and drv.branchid = child.branchid
                        and drv.updatetime <= child.updatetime  --parent update time <= child update time
                    ) where rn=1 
                )
                ,v_pctl_job as 
                (
                    select * from
                        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
                           from {rawDB}.pctl_job jbt    
                                                   Cross Join Events_Max_Updatetime mb  
                                                   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
                                                ) where rn=1
                )

                ,HRZ_Query as (
 
                SELECT UPPER ( SI.SOURCE_SYSTEM|| '-'|| CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255))|| '-'ELSE ''END || SI.CVRBL_TYPE || SI.SI_TYPE || '-' || CAST (CAST(SI.FixedID AS INTEGER) AS VARCHAR (255))) AS SI_KEY,
                UPPER (SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN SI.TypeCode <> 'Bound' THEN '-QT:' || CAST (SI.publicID AS VARCHAR (255)) ELSE ''END)AS POL_KEY,
                'NOKEY' AS POL_LINE_KEY,
                'NOKEY' AS LINE_EXCL_KEY,
                'NOKEY' AS LINE_COVG_KEY, 
                UPPER (CASE WHEN SI.SCHED_TYP IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM  || '-'  || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.SCHED_TYP AS INTEGER) AS VARCHAR (255)) END) AS LINE_COND_KEY, 
                UPPER (CASE WHEN SI.OWNING_CVRBL IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.OWNING_CVRBL AS INTEGER) AS VARCHAR (255)) END) AS OWNING_CVRBL_KEY,
                'NOKEY' AS POL_PARTY_KEY,  
                UPPER ( CASE WHEN SI.NamedInsured IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || CAST (SI.NamedInsured AS VARCHAR (255)) END) AS LINE_POL_PARTY_KEY,
                'NOKEY' AS LOC_KEY,
                UPPER ( CASE WHEN SI.Location IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.Location AS INTEGER) AS VARCHAR (255)) END) AS LINE_LOCATION_KEY,
                'NOKEY' AS ADDL_INTRST_KEY,
                CAST (COALESCE (SI.EffectiveDate, SI.PeriodStart) AS DATE) AS END_EFF_DT, CAST (COALESCE (SI.ExpirationDate, SI.PeriodEnd) AS DATE) AS END_EXP_DT, SI.SOURCE_SYSTEM AS SOURCE_SYSTEM, SI.CVRBL_TYPE || SI.SI_TYPE AS CVRBL_TYPE_CD, 
                CAST(SI.SCHED_NO AS INT) AS SCHED_NO, 
                COALESCE(SI.TypeKeyCol1, ' ') AS TYPE_KEY_COL_1, COALESCE(SI.TypeKeyCol2, ' ') AS TYPE_KEY_COL_2, ' ' AS TYPE_KEY_COL_3, ' ' AS TYPE_KEY_COL_4, ' ' AS TYPE_KEY_COL_5, ' ' AS TYPE_KEY_COL_6, COALESCE(SI.StringCol1, ' ') AS STR_COL_1, COALESCE(SI.StringCol2, ' ') AS STR_COL_2, COALESCE(SI.StringCol3, ' ') AS STR_COL_3, COALESCE(SI.StringCol4, ' ') AS STR_COL_4, COALESCE(SI.StringCol5, ' ') AS STR_COL_5, COALESCE(SI.STRINGCOL6, ' ') AS STR_COL_6, COALESCE(SI.STRINGCOL7, ' ') AS STR_COL_7, COALESCE(SI.STRINGCOL8, ' ') AS STR_COL_8,
                ' ' AS LONG_STR_COL_1, 
                ' ' AS LONG_STR_COL_2, 
                SI.DATECOL1 AS DT_COL_1_DTS, 
                NULL AS DT_COL_2_DTS, 
                NULL AS DT_COL_3_DTS,
                CAST(SI.FixedID AS INTEGER) AS LIFE_OBJECT_NO,
                SI.IntCol1 AS INT_COL_1, 
                SI.IntCol2 AS INT_COL_2, 
                SI.IntCol3 AS INT_COL_3, 
                SI.IntCol4 AS INT_COL_4, 
                SI.IntCol5 AS INT_COL_5,
                SI.INTCOL6 AS INT_COL_6, 
                SI.INTCOL7 AS  INT_COL_7  ,  
                SI.PosIntCol1 AS POS_INT_COL_1, 
                SI.NONNEGATIVEINTCOL1 AS NON_NEG_INT_1, 
                SI.NONNEGATIVEINTCOL2 AS NON_NEG_INT_2, 
                SI.NONNEGATIVEINTCOL3 AS NON_NEG_INT_3, 
                NULL AS NON_NEG_INT_4, 
                NULL AS NON_NEG_INT_5, 
                COALESCE(SI.BoolCol1, 'U') AS Bool_COL_1_FL, 
                COALESCE(SI.BoolCol2, 'U') AS Bool_COL_2_FL, 
                'U' AS Bool_COL_3_FL,
                'U' AS Bool_COL_4_FL,
                'U' AS Bool_COL_5_FL,
                'U' AS Bool_COL_6_FL,
                'U' AS Bool_COL_7_FL,
                'U' AS Bool_COL_8_FL,
                SI.DECIMALCOL1 AS DECIMAL_COL_1, 
                SI.DECIMALCOL2 AS DECIMAL_COL_2, 
                SI.DECIMALCOL3 AS DECIMAL_COL_3, 
                ' ' AS OPT_COL_1,
                ' ' AS OPT_COL_2,   
                ' ' AS OPT_COL_3, 
                ' ' AS OPT_COL_4, 
                ' ' AS OPT_COL_5, 
                ' ' AS OPT_COL_6, 
                ' ' AS OPT_COL_7, 
                ' ' AS OPT_COL_8, 
                ' ' AS OPT_COL_9, 
                ' ' AS OPT_COL_10, 
                ' ' AS OPT_COL_11, 
                ' ' AS OPT_COL_12, 
                ' ' AS OPT_COL_13, 
                ' ' AS OPT_COL_14, 
                ' ' AS OPT_COL_15, 
                ' ' AS OPT_COL_16, 
                ' ' AS OPT_COL_17, 
                ' ' AS OPT_COL_18, 
                ' ' AS OPT_COL_19, 
                ' ' AS OPT_COL_20, 
                ' ' AS OPT_COL_21, 
                ' ' AS OPT_COL_22, 
                ' ' AS OPT_COL_23, 
                SI.YEARCOL1 AS YEAR_COL_1,
                ' ' AS ADDL_INS_TYPE_CD,
                SI.LOB_CD AS LOB_CD,
                SI.SOURCE_SYSTEM||'-'||SI.LOB_CD||'-'||SI.CVRBL_TYPE || SI.SI_TYPE AS PARTITION_VAL
                ,CAST(COALESCE(SI.LEGACY_SI_NB, ' ') AS INT) AS LEGACY_SI_NB,
                CASE WHEN SI.TypeCode = 'Bound' THEN SI.CloseDate ELSE COALESCE (polper_UpdateTime, polper_CreateTime) END AS ETL_ROW_EFF_DTS
                ,SI.updatetime_tab1,SI.updatetime_tab2,SI.updatetime_tab3,SI.updatetime_tab4,SI.SRC_BRANCHID, SI.SRC_FIXEDID,SI.SRC_EFFECTIVEDATE,SI.SRC_EXPIRATIONDATE,SI.POLPER_PERIODSTART
                ,SI.POLPER_PERIODEND,SI.POLPER_PUBLICID,SI.SRC_PUBLICID,SI.SRC_UPDATETIME,SI.SRC_CREATETIME
                FROM (SELECT SP.SOURCE_SYSTEM AS SOURCE_SYSTEM, SP.LOB_CD as LOB_CD, SP.CVRBL_TYPE AS CVRBL_TYPE, SP.SI_TYPE_COND AS SI_TYPE,child.{cvrbl_type} AS OWNING_CVRBL,{ttype}.NamedInsured,{ttype}.Policylocation Location,{ttype}.FixedID,{ttype}.EffectiveDate,{ttype}.ExpirationDate,{ttype}.ScheduleNumber SCHED_NO,{ttype}.TYPEKEYCOL1,{ttype}.TYPEKEYCOL2,{ttype}.STRINGCOL1,{ttype}.STRINGCOL2,{ttype}.STRINGCOL3,{ttype}.STRINGCOL4,{ttype}.STRINGCOL5,{ttype}.STRINGCOL6,{ttype}.STRINGCOL7,{ttype}.STRINGCOL8,{ttype}.DATECOL1,{ttype}.INTCOL1,{ttype}.INTCOL2,{ttype}.INTCOL3,{ttype}.INTCOL4,{ttype}.INTCOL5,{ttype}.INTCOL6,{ttype}.INTCOL7,{ttype}.POSINTCOL1,{ttype}.NONNEGATIVEINTCOL1,{ttype}.NONNEGATIVEINTCOL2,{ttype}.NONNEGATIVEINTCOL3,{ttype}.BOOLCOL1,{ttype}.BOOLCOL2,{ttype}.DECIMALCOL1,{ttype}.DECIMALCOL2,{ttype}.DECIMALCOL3,{ttype}.YEARCOL1,{ttype}.{ScheduleCoverageLogic} AS SCHED_TYP,' 'as LEGACY_SI_NB,status.TypeCode,job.CloseDate,{ttype}.UpdateTime,{ttype}.CreateTime,polper.updateTime polper_updatetime,polper.CreateTime polper_Createtime,POLPER.PUBLICID,POLPER.PERIODID,POLPER.PERIODSTART,POLPER.PERIODEND, POLPER.updatetime as updatetime_tab1 , {ttype}.updatetime as updatetime_tab2 , job.updatetime as updatetime_tab3 ,child.updatetime as updatetime_tab4, {ttype}.branchid as SRC_BRANCHID
                , {ttype}.fixedid as SRC_FIXEDID, {ttype}.effectivedate as SRC_EFFECTIVEDATE, {ttype}.expirationdate as SRC_EXPIRATIONDATE, POLPER.periodstart as POLPER_PERIODSTART, POLPER.periodend as POLPER_PERIODEND, POLPER.publicid as POLPER_PUBLICID, {ttype}.publicid as SRC_PUBLICID, {ttype}.updatetime as SRC_UPDATETIME, {ttype}.createtime as SRC_CREATETIME

                 FROM v_{parent} {ttype} CROSS JOIN SESSION_PARAM SP
                     JOIN v_pc_policyperiod polper ON {ttype}.BranchID = polper.ID 
                                 and {ttype}.publicid=polper.{parent}_publicid
                     and {ttype}.updatetime=polper.{parent}_updatetime

                     JOIN v_childtable child ON {ttype}.{ScheduleCoverageLogic} = child.FixedID   
                     AND {ttype}.BranchID = child.BranchID 
                     and {ttype}.publicid=child.{parent}_publicid
                     and {ttype}.updatetime=child.{parent}_updatetime
                                 AND polper.EditEffectiveDate >= COALESCE (child.EffectiveDate, polper.PeriodStart)   
                                 AND polper.EditEffectiveDate < COALESCE (child.ExpirationDate, polper.PeriodEnd)

                     JOIN v_pc_job job on polper.JobID = job.ID
                     and polper.publicid=job.pc_policyperiod_publicid
                     and polper.updatetime=job.pc_policyperiod_updatetime  

                     JOIN v_pctl_policyperiodstatus STATUS ON STATUS.ID = POLPER.Status and not ( status.typecode = 'Bound' and job.closedate is null)

                     LEFT JOIN v_pctl_job  JBT ON JOB.SUBTYPE = JBT.ID 
                     WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
                     ) SI   
                       )
                  """
  return harmz_query
  

# COMMAND ----------


def build_si_exclusion( rawDB: str,  parent:str,  cvrbl_type:str, childtable:str, source_system:str, lob_cd:str, si_type:str):
                
  parent1 = parent.upper() 
  micro_bacth = "global_temp."+ parent +"_micro_batch_"+cvrbl_type+si_type
  ttype =  cvrbl_type[0:3]   
  
  harmz_query = f""" WITH SESSION_PARAM as (SELECT '{source_system}' as source_system , '{lob_cd}' as LOB_CD, '{cvrbl_type}' as  CVRBL_TYPE , '{si_type}' AS SI_TYPE_COVG  ) 
,  {parent}_micro_batch  as (select distinct branchid,updatetime from   {micro_bacth} )  
,  Events_Max_Updatetime as (Select max(updatetime) as mb_max_updatetime from {micro_bacth} )
, v_pctl_policyperiodstatus as 
 (  select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
 )
 
/* , v_childtable as 
 ( select * from
        (select *,row_number() over (partition by Id order by curr_timestamp desc) as rn 
           from {rawDB}.{childtable} child  
		   Cross Join Events_Max_Updatetime mb  
			On child.curr_timestamp<= mb.mb_max_updatetime
		) where rn=1
 )*/
 
,v_{parent} as
(select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select {parent}.*
			from {rawDB}.{parent}          
            inner join  {micro_bacth} mb  
			   on mb.branchid = {parent} .branchid 
			where {parent} .updatetime <= mb.updatetime  
			)
		) where rn = 1)  

/**********,v_pc_policyperiod as 
        (
          --consider parent record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,p.updatetime,p.BranchID  --updatetime should be from parent in partition clause
              order by (unix_millis(p.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_{parent}  p
              JOIN  {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and polper.updatetime <= p.updatetime  --child update time <= parent update  time
            ) where rn=1
          union 
          --consider child record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,polper.updatetime,p.BranchID  --updatetime should be from child in partition clause
              order by (unix_millis(polper.updatetime) - unix_millis(p.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
              from v_{parent}  p
              JOIN {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and p.updatetime <= polper.updatetime --parent update time <= child update time
            ) where rn=1
        )************************/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            polper.PolicyNumber,
            polper.editeffectivedate,
            polper.basestate,            
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as {parent}_publicid,
            p.updatetime as {parent}_updatetime
          from
            v_{parent}  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
, v_pc_job as 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.Jobid  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.Jobid   --updatetime should be from childe in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and polper.updatetime <= job.updatetime  --parent update time <= child update time
    ) where rn=1 
)
, v_childtable as 
(
  --consider parent record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,drv.updatetime,drv.BranchID,drv.scheduleexclusion,child.effectivedate,child.expirationdate --updatetime should be from parent in partition clause
      order by (unix_millis(drv.updatetime) - unix_millis(child.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable} child
		on drv.scheduleexclusion =child.fixedid
        and drv.branchid = child.branchid
        and child.updatetime <= drv.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,child.updatetime,drv.BranchID,drv.scheduleexclusion,child.effectivedate,child.expirationdate --updatetime should be from childe in partition clause
      order by (unix_millis(child.updatetime) - unix_millis(drv.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable}  child
        on drv.scheduleexclusion =child.fixedid
        and drv.branchid = child.branchid
        and drv.updatetime <= child.updatetime  --parent update time <= child update time
    ) where rn=1 
)

,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
  
,HRZ_Query as (
 
SELECT UPPER ( SI.SOURCE_SYSTEM|| '-'|| CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255))|| '-'ELSE ''END || SI.CVRBL_TYPE || SI.SI_TYPE || '-' || CAST (CAST(SI.FixedID AS INTEGER) AS VARCHAR (255))) AS SI_KEY,
UPPER (SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN SI.TypeCode <> 'Bound' THEN '-QT:' || CAST (SI.publicID AS VARCHAR (255)) ELSE ''END)AS POL_KEY,
'NOKEY' AS POL_LINE_KEY,
'NOKEY' AS LINE_COND_KEY,
'NOKEY' AS LINE_COVG_KEY, 
UPPER (CASE WHEN SI.SCHED_TYP IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM  || '-'  || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.SCHED_TYP AS INTEGER) AS VARCHAR (255)) END) AS LINE_EXCL_KEY, 
UPPER (CASE WHEN SI.OWNING_CVRBL IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.OWNING_CVRBL AS INTEGER) AS VARCHAR (255)) END) AS OWNING_CVRBL_KEY,
'NOKEY' AS POL_PARTY_KEY,  
UPPER ( CASE WHEN SI.NamedInsured IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || CAST (SI.NamedInsured AS VARCHAR (255)) END) AS LINE_POL_PARTY_KEY,
'NOKEY' AS LOC_KEY,
UPPER ( CASE WHEN SI.Location IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.Location AS INTEGER) AS VARCHAR (255)) END) AS LINE_LOCATION_KEY,
'NOKEY' AS ADDL_INTRST_KEY,
CAST (COALESCE (SI.EffectiveDate, SI.PeriodStart) AS DATE) AS END_EFF_DT, CAST (COALESCE (SI.ExpirationDate, SI.PeriodEnd) AS DATE) AS END_EXP_DT, SI.SOURCE_SYSTEM AS SOURCE_SYSTEM, SI.CVRBL_TYPE || SI.SI_TYPE AS CVRBL_TYPE_CD, SI.SCHED_NO AS SCHED_NO, 
COALESCE(SI.TypeKeyCol1, ' ') AS TYPE_KEY_COL_1, COALESCE(SI.TypeKeyCol2, ' ') AS TYPE_KEY_COL_2, ' ' AS TYPE_KEY_COL_3, ' ' AS TYPE_KEY_COL_4, ' ' AS TYPE_KEY_COL_5, ' ' AS TYPE_KEY_COL_6, COALESCE(SI.StringCol1, ' ') AS STR_COL_1, COALESCE(SI.StringCol2, ' ') AS STR_COL_2, COALESCE(SI.StringCol3, ' ') AS STR_COL_3, COALESCE(SI.StringCol4, ' ') AS STR_COL_4, COALESCE(SI.StringCol5, ' ') AS STR_COL_5, COALESCE(SI.STRINGCOL6, ' ') AS STR_COL_6, COALESCE(SI.STRINGCOL7, ' ') AS STR_COL_7, COALESCE(SI.STRINGCOL8, ' ') AS STR_COL_8,
' ' AS LONG_STR_COL_1, 
' ' AS LONG_STR_COL_2, 
SI.DATECOL1 AS DT_COL_1_DTS, 
NULL AS DT_COL_2_DTS, 
NULL AS DT_COL_3_DTS,
CAST(SI.FixedID AS INTEGER) AS LIFE_OBJECT_NO,
SI.IntCol1 AS INT_COL_1, 
SI.IntCol2 AS INT_COL_2, 
SI.IntCol3 AS INT_COL_3, 
SI.IntCol4 AS INT_COL_4, 
SI.IntCol5 AS INT_COL_5,
SI.INTCOL6 AS INT_COL_6, 
SI.INTCOL7 AS  INT_COL_7  ,  
SI.PosIntCol1 AS POS_INT_COL_1, 
SI.NONNEGATIVEINTCOL1 AS NON_NEG_INT_1, 
SI.NONNEGATIVEINTCOL2 AS NON_NEG_INT_2, 
SI.NONNEGATIVEINTCOL3 AS NON_NEG_INT_3, 
NULL AS NON_NEG_INT_4, 
NULL AS NON_NEG_INT_5, 
COALESCE(SI.BoolCol1, 'U') AS Bool_COL_1_FL, 
COALESCE(SI.BoolCol2, 'U') AS Bool_COL_2_FL, 
'U' AS Bool_COL_3_FL,
'U' AS Bool_COL_4_FL,
'U' AS Bool_COL_5_FL,
'U' AS Bool_COL_6_FL,
'U' AS Bool_COL_7_FL,
'U' AS Bool_COL_8_FL,
SI.DECIMALCOL1 AS DECIMAL_COL_1, 
SI.DECIMALCOL2 AS DECIMAL_COL_2, 
SI.DECIMALCOL3 AS DECIMAL_COL_3, 
' ' AS OPT_COL_1,
' ' AS OPT_COL_2,   
' ' AS OPT_COL_3, 
' ' AS OPT_COL_4, 
' ' AS OPT_COL_5, 
' ' AS OPT_COL_6, 
' ' AS OPT_COL_7, 
' ' AS OPT_COL_8, 
' ' AS OPT_COL_9, 
' ' AS OPT_COL_10, 
' ' AS OPT_COL_11, 
' ' AS OPT_COL_12, 
' ' AS OPT_COL_13, 
' ' AS OPT_COL_14, 
' ' AS OPT_COL_15, 
' ' AS OPT_COL_16, 
' ' AS OPT_COL_17, 
' ' AS OPT_COL_18, 
' ' AS OPT_COL_19, 
' ' AS OPT_COL_20, 
' ' AS OPT_COL_21, 
' ' AS OPT_COL_22, 
' ' AS OPT_COL_23, 
SI.YEARCOL1 AS YEAR_COL_1,
' ' AS ADDL_INS_TYPE_CD,
SI.LOB_CD AS LOB_CD,
SI.SOURCE_SYSTEM||'-'||SI.LOB_CD||'-'||SI.CVRBL_TYPE || SI.SI_TYPE AS PARTITION_VAL
,COALESCE(SI.LEGACY_SI_NB, ' ') AS LEGACY_SI_NB,
CASE WHEN SI.TypeCode = 'Bound' THEN SI.CloseDate ELSE COALESCE (polper_UpdateTime, polper_CreateTime) END AS ETL_ROW_EFF_DTS
,SI.updatetime_tab1,SI.updatetime_tab2,SI.updatetime_tab3,SI.updatetime_tab4,SI.SRC_BRANCHID, SI.SRC_FIXEDID,SI.SRC_EFFECTIVEDATE,SI.SRC_EXPIRATIONDATE,SI.POLPER_PERIODSTART
,SI.POLPER_PERIODEND,SI.POLPER_PUBLICID,SI.SRC_PUBLICID,SI.SRC_UPDATETIME,SI.SRC_CREATETIME
FROM (SELECT SP.SOURCE_SYSTEM AS SOURCE_SYSTEM, SP.LOB_CD as LOB_CD, SP.CVRBL_TYPE AS CVRBL_TYPE, SP.SI_TYPE_COVG AS SI_TYPE,child.{cvrbl_type} AS OWNING_CVRBL,{ttype}.NamedInsured,{ttype}.Policylocation Location,{ttype}.FixedID,{ttype}.EffectiveDate,{ttype}.ExpirationDate,{ttype}.ScheduleNumber SCHED_NO,{ttype}.TYPEKEYCOL1,{ttype}.TYPEKEYCOL2,{ttype}.STRINGCOL1,{ttype}.STRINGCOL2,{ttype}.STRINGCOL3,{ttype}.STRINGCOL4,{ttype}.STRINGCOL5,{ttype}.STRINGCOL6,{ttype}.STRINGCOL7,{ttype}.STRINGCOL8,{ttype}.DATECOL1,{ttype}.INTCOL1,{ttype}.INTCOL2,{ttype}.INTCOL3,{ttype}.INTCOL4,{ttype}.INTCOL5,{ttype}.INTCOL6,{ttype}.INTCOL7,{ttype}.POSINTCOL1,{ttype}.NONNEGATIVEINTCOL1,{ttype}.NONNEGATIVEINTCOL2,{ttype}.NONNEGATIVEINTCOL3,{ttype}.BOOLCOL1,{ttype}.BOOLCOL2,{ttype}.DECIMALCOL1,{ttype}.DECIMALCOL2,{ttype}.DECIMALCOL3,{ttype}.YEARCOL1,{ttype}.SCHEDULEEXCLUSION AS SCHED_TYP,' ' as LEGACY_SI_NB,status.TypeCode,job.CloseDate,{ttype}.UpdateTime,{ttype}.CreateTime,polper.updateTime polper_updatetime,polper.CreateTime polper_Createtime,POLPER.PUBLICID,POLPER.PERIODID,POLPER.PERIODSTART,POLPER.PERIODEND, POLPER.updatetime as updatetime_tab1 , {ttype}.updatetime as updatetime_tab2 , job.updatetime as updatetime_tab3 ,child.updatetime as updatetime_tab4, {ttype}.branchid as SRC_BRANCHID
, {ttype}.fixedid as SRC_FIXEDID, {ttype}.effectivedate as SRC_EFFECTIVEDATE, {ttype}.expirationdate as SRC_EXPIRATIONDATE, POLPER.periodstart as POLPER_PERIODSTART, POLPER.periodend as POLPER_PERIODEND, POLPER.publicid as POLPER_PUBLICID, {ttype}.publicid as SRC_PUBLICID, {ttype}.updatetime as SRC_UPDATETIME, {ttype}.createtime as SRC_CREATETIME
		 
 FROM v_{parent} {ttype} CROSS JOIN SESSION_PARAM SP
     JOIN v_pc_policyperiod polper ON {ttype}.BranchID = polper.ID 
	 and {ttype}.publicid=polper.{parent}_publicid
     and {ttype}.updatetime=polper.{parent}_updatetime
      
     JOIN v_childtable child ON {ttype}.SCHEDULEEXCLUSION = child.FixedID   
     AND {ttype}.BranchID = child.BranchID   
     and {ttype}.publicid=child.{parent}_publicid
     and {ttype}.updatetime=child.{parent}_updatetime
     
	 AND polper.EditEffectiveDate >= COALESCE (child.EffectiveDate, polper.PeriodStart)   
	 AND polper.EditEffectiveDate < COALESCE (child.ExpirationDate, polper.PeriodEnd)
		 
     JOIN v_pc_job job on polper.JobID = job.ID
     and polper.publicid=job.pc_policyperiod_publicid
     and polper.updatetime=job.pc_policyperiod_updatetime  
         
     JOIN v_pctl_policyperiodstatus STATUS ON STATUS.ID = POLPER.Status and not ( status.typecode = 'Bound' and job.closedate is null)
        
     LEFT JOIN v_pctl_job  JBT ON JOB.SUBTYPE = JBT.ID 
     WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
     ) SI   
       )

  """
  return harmz_query



# COMMAND ----------

def build_si_exclusion_cop( rawDB: str,  parent:str ,  cvrbl_type:str, childtable:str,  source_system:str,lob_cd:str, si_type:str):
 
  parent1 = parent.upper() 
  micro_bacth = "global_temp."+ parent +"_micro_batch_"+cvrbl_type+si_type
  ttype =  cvrbl_type[0:3]   
  
  
  harmz_query = f""" WITH SESSION_PARAM as (SELECT '{source_system}' as source_system , '{lob_cd}' as LOB_CD, '{cvrbl_type}' as CVRBL_TYPE , '{si_type}' AS SI_TYPE_COVG  ) 
,  {parent}_micro_batch  as (select distinct branchid,updatetime from   {micro_bacth} )  
,  Events_Max_Updatetime as (Select max(updatetime) as mb_max_updatetime from {micro_bacth} )
, v_pctl_policyperiodstatus as 
 (  select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
 )
 
/* , v_childtable as 
 ( select * from
        (select *,row_number() over (partition by Id order by curr_timestamp desc) as rn 
           from {rawDB}.{childtable} child  
		   Cross Join Events_Max_Updatetime mb  
			On child.curr_timestamp<= mb.mb_max_updatetime
		) where rn=1
 )*/
,v_{parent} as
(select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select {parent}.*
			from {rawDB}.{parent}          
            inner join  {micro_bacth} mb  
			   on mb.branchid = {parent} .branchid 
			where {parent} .updatetime <= mb.updatetime  
			)
		) where rn = 1)  

/**********,v_pc_policyperiod as 
        (
          --consider parent record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,p.updatetime,p.BranchID  --updatetime should be from parent in partition clause
              order by (unix_millis(p.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_{parent}  p
              JOIN  {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and polper.updatetime <= p.updatetime  --child update time <= parent update  time
            ) where rn=1
          union 
          --consider child record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,polper.updatetime,p.BranchID  --updatetime should be from child in partition clause
              order by (unix_millis(polper.updatetime) - unix_millis(p.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
              from v_{parent}  p
              JOIN {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and p.updatetime <= polper.updatetime --parent update time <= child update time
            ) where rn=1
        )************************/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            polper.PolicyNumber,
            polper.editeffectivedate,
            polper.basestate,            
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as {parent}_publicid,
            p.updatetime as {parent}_updatetime
          from
            v_{parent}  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
, v_pc_job as 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.Jobid  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.Jobid   --updatetime should be from childe in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and polper.updatetime <= job.updatetime  --parent update time <= child update time
    ) where rn=1 
)
, v_childtable as 
(
  --consider parent record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,drv.updatetime,drv.BranchID,drv.scheduleexclusion,child.effectivedate,child.expirationdate  --updatetime should be from parent in partition clause
      order by (unix_millis(drv.updatetime) - unix_millis(child.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable} child
		on drv.scheduleexclusion =child.fixedid
        and drv.branchid = child.branchid
        and child.updatetime <= drv.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,child.updatetime,drv.BranchID,drv.scheduleexclusion,child.effectivedate,child.expirationdate   --updatetime should be from childe in partition clause
      order by (unix_millis(child.updatetime) - unix_millis(drv.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable}  child
        on drv.scheduleexclusion =child.fixedid
        and drv.branchid = child.branchid
        and drv.updatetime <= child.updatetime  --parent update time <= child update time
    ) where rn=1 
)

,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
  
,HRZ_Query as (
 
SELECT UPPER ( SI.SOURCE_SYSTEM|| '-'|| CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255))|| '-'ELSE ''END || SI.CVRBL_TYPE || SI.SI_TYPE || '-' || CAST (CAST(SI.FixedID AS INTEGER) AS VARCHAR (255))) AS SI_KEY,
UPPER (SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN SI.TypeCode <> 'Bound' THEN '-QT:' || CAST (SI.publicID AS VARCHAR (255)) ELSE ''END)AS POL_KEY,
UPPER ( CASE WHEN SI.copline IS NULL THEN 'NOKEY' ELSE SI.Source_System || '-' || CAST (CAST (SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.copline AS INTEGER)AS VARCHAR (255)) END) AS POL_LINE_KEY,
'NOKEY' AS LINE_COND_KEY,
'NOKEY' AS LINE_COVG_KEY, 
UPPER (CASE WHEN SI.SCHED_TYP IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM  || '-'  || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.SCHED_TYP AS INTEGER) AS VARCHAR (255)) END) AS LINE_EXCL_KEY, 
UPPER (CASE WHEN SI.OWNING_CVRBL IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.OWNING_CVRBL AS INTEGER) AS VARCHAR (255)) END) AS OWNING_CVRBL_KEY,
'NOKEY' AS POL_PARTY_KEY,  
UPPER ( CASE WHEN SI.NamedInsured IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || CAST (SI.NamedInsured AS VARCHAR (255)) END) AS LINE_POL_PARTY_KEY,
'NOKEY' AS LOC_KEY,
UPPER ( CASE WHEN SI.Location IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.Location AS INTEGER) AS VARCHAR (255)) END) AS LINE_LOCATION_KEY,
'NOKEY' AS ADDL_INTRST_KEY,
CAST (COALESCE (SI.EffectiveDate, SI.PeriodStart) AS DATE) AS END_EFF_DT, CAST (COALESCE (SI.ExpirationDate, SI.PeriodEnd) AS DATE) AS END_EXP_DT, SI.SOURCE_SYSTEM AS SOURCE_SYSTEM, SI.CVRBL_TYPE || SI.SI_TYPE AS CVRBL_TYPE_CD, SI.SCHED_NO AS SCHED_NO, 
COALESCE(SI.TypeKeyCol1, ' ') AS TYPE_KEY_COL_1, COALESCE(SI.TypeKeyCol2, ' ') AS TYPE_KEY_COL_2, ' ' AS TYPE_KEY_COL_3, ' ' AS TYPE_KEY_COL_4, ' ' AS TYPE_KEY_COL_5, ' ' AS TYPE_KEY_COL_6, COALESCE(SI.StringCol1, ' ') AS STR_COL_1, COALESCE(SI.StringCol2, ' ') AS STR_COL_2, COALESCE(SI.StringCol3, ' ') AS STR_COL_3, COALESCE(SI.StringCol4, ' ') AS STR_COL_4, COALESCE(SI.StringCol5, ' ') AS STR_COL_5, COALESCE(SI.STRINGCOL6, ' ') AS STR_COL_6, COALESCE(SI.STRINGCOL7, ' ') AS STR_COL_7,  ' ' AS STR_COL_8,
' ' AS LONG_STR_COL_1, 
' ' AS LONG_STR_COL_2, 
SI.DATECOL1 AS DT_COL_1_DTS, 
SI.DATECOL2 AS DT_COL_2_DTS, 
SI.DATECOL3 AS DT_COL_3_DTS,
CAST(SI.FixedID AS INTEGER) AS LIFE_OBJECT_NO,
SI.IntCol1 AS INT_COL_1, 
SI.IntCol2 AS INT_COL_2, 
SI.IntCol3 AS INT_COL_3, 
NULL AS INT_COL_4, 
NULL AS INT_COL_5,
NULL AS INT_COL_6, 
NULL AS INT_COL_7,  
SI.PosIntCol1 AS POS_INT_COL_1, 
SI.NONNEGATIVEINTCOL1 AS NON_NEG_INT_1, 
NULL AS NON_NEG_INT_2, 
NULL AS NON_NEG_INT_3, 
NULL AS NON_NEG_INT_4, 
NULL AS NON_NEG_INT_5,  
CASE WHEN SI.BoolCol1 =1 THEN 'Y' WHEN SI.BoolCol1=0 THEN 'N' ELSE 'U' END AS BOOL_COL_1_FL,
CASE WHEN SI.BoolCol2 =1 THEN 'Y' WHEN SI.BoolCol2=0 THEN 'N' ELSE 'U' END AS BOOL_COL_2_FL,
CASE WHEN SI.BoolCol3 =1 THEN 'Y' WHEN SI.BoolCol3=0 THEN 'N' ELSE 'U' END AS BOOL_COL_3_FL,
CASE WHEN SI.BoolCol4 =1 THEN 'Y' WHEN SI.BoolCol4=0 THEN 'N' ELSE 'U' END AS BOOL_COL_4_FL,
CASE WHEN SI.BoolCol5 =1 THEN 'Y' WHEN SI.BoolCol5=0 THEN 'N' ELSE 'U' END AS BOOL_COL_5_FL,
CASE WHEN SI.BoolCol6 =1 THEN 'Y' WHEN SI.BoolCol6=0 THEN 'N' ELSE 'U' END AS BOOL_COL_6_FL,
CASE WHEN SI.BoolCol7 =1 THEN 'Y' WHEN SI.BoolCol7=0 THEN 'N' ELSE 'U' END AS BOOL_COL_7_FL,
CASE WHEN SI.BoolCol8 =1 THEN 'Y' WHEN SI.BoolCol8=0 THEN 'N' ELSE 'U' END AS BOOL_COL_8_FL,
NULL AS DECIMAL_COL_1, 
NULL AS DECIMAL_COL_2, 
NULL AS DECIMAL_COL_3,
COALESCE(SI.OptionCol1, ' ') AS OPT_COL_1,
' ' AS OPT_COL_2,   
' ' AS OPT_COL_3, 
' ' AS OPT_COL_4, 
' ' AS OPT_COL_5, 
' ' AS OPT_COL_6, 
' ' AS OPT_COL_7, 
' ' AS OPT_COL_8, 
' ' AS OPT_COL_9, 
' ' AS OPT_COL_10, 
' ' AS OPT_COL_11, 
' ' AS OPT_COL_12, 
' ' AS OPT_COL_13, 
' ' AS OPT_COL_14, 
' ' AS OPT_COL_15, 
' ' AS OPT_COL_16, 
' ' AS OPT_COL_17, 
' ' AS OPT_COL_18, 
' ' AS OPT_COL_19, 
' ' AS OPT_COL_20, 
' ' AS OPT_COL_21, 
' ' AS OPT_COL_22, 
' ' AS OPT_COL_23, 
SI.YEARCOL1 AS YEAR_COL_1,
' ' AS ADDL_INS_TYPE_CD,
SI.LOB_CD AS LOB_CD,
SI.SOURCE_SYSTEM||'-'||SI.LOB_CD||'-'||SI.CVRBL_TYPE || SI.SI_TYPE AS PARTITION_VAL
,NULL AS LEGACY_SI_NB,
CASE WHEN SI.TypeCode = 'Bound' THEN SI.CloseDate ELSE COALESCE (polper_UpdateTime, polper_CreateTime) END AS ETL_ROW_EFF_DTS
,SI.updatetime_tab1,SI.updatetime_tab2,SI.updatetime_tab3,SI.updatetime_tab4,SI.SRC_BRANCHID, SI.SRC_FIXEDID,SI.SRC_EFFECTIVEDATE,SI.SRC_EXPIRATIONDATE,SI.POLPER_PERIODSTART
,SI.POLPER_PERIODEND,SI.POLPER_PUBLICID,SI.SRC_PUBLICID,SI.SRC_UPDATETIME,SI.SRC_CREATETIME
FROM (SELECT SP.SOURCE_SYSTEM AS SOURCE_SYSTEM, SP.LOB_CD as LOB_CD, SP.CVRBL_TYPE AS CVRBL_TYPE, SP.SI_TYPE_COVG AS SI_TYPE,child.{cvrbl_type} AS copline,child.{cvrbl_type} AS OWNING_CVRBL,{ttype}.NamedInsured,{ttype}.Policylocation Location,{ttype}.FixedID,{ttype}.EffectiveDate,{ttype}.ExpirationDate,{ttype}.ScheduleNumber SCHED_NO,{ttype}.TYPEKEYCOL1,{ttype}.TYPEKEYCOL2,{ttype}.STRINGCOL1,{ttype}.STRINGCOL2,{ttype}.STRINGCOL3,{ttype}.STRINGCOL4,{ttype}.STRINGCOL5,{ttype}.STRINGCOL6,{ttype}.STRINGCOL7,{ttype}.DATECOL1,{ttype}.DATECOL2,{ttype}.DATECOL3,{ttype}.INTCOL1,{ttype}.INTCOL2,{ttype}.INTCOL3,{ttype}.POSINTCOL1,{ttype}.NONNEGATIVEINTCOL1,{ttype}.BOOLCOL1,{ttype}.BOOLCOL2,{ttype}.BOOLCOL3,{ttype}.BOOLCOL4,{ttype}.BOOLCOL5,{ttype}.BOOLCOL6,{ttype}.BOOLCOL7,{ttype}.BOOLCOL8,{ttype}.YEARCOL1,{ttype}.OPTIONCOL1,{ttype}.SCHEDULEEXCLUSION AS SCHED_TYP,{ttype}.SCHEDULENUMBER as LEGACY_SI_NB,status.TypeCode,job.CloseDate,{ttype}.UpdateTime,{ttype}.CreateTime,polper.updateTime polper_updatetime,polper.CreateTime polper_Createtime,POLPER.PUBLICID,POLPER.PERIODID,POLPER.PERIODSTART,POLPER.PERIODEND, POLPER.updatetime as updatetime_tab1 , {ttype}.updatetime as updatetime_tab2 , job.updatetime as updatetime_tab3 ,child.updatetime as updatetime_tab4, {ttype}.branchid as SRC_BRANCHID
, {ttype}.fixedid as SRC_FIXEDID, {ttype}.effectivedate as SRC_EFFECTIVEDATE, {ttype}.expirationdate as SRC_EXPIRATIONDATE, POLPER.periodstart as POLPER_PERIODSTART, POLPER.periodend as POLPER_PERIODEND, POLPER.publicid as POLPER_PUBLICID, {ttype}.publicid as SRC_PUBLICID, {ttype}.updatetime as SRC_UPDATETIME, {ttype}.createtime as SRC_CREATETIME
		 
 FROM v_{parent} {ttype} CROSS JOIN SESSION_PARAM SP
     JOIN v_pc_policyperiod polper ON {ttype}.BranchID = polper.ID 
	 and {ttype}.publicid=polper.{parent}_publicid
     and {ttype}.updatetime=polper.{parent}_updatetime
      
     JOIN v_childtable child ON {ttype}.SCHEDULEEXCLUSION = child.FixedID   
     AND {ttype}.BranchID = child.BranchID   
     and {ttype}.publicid=child.{parent}_publicid
     and {ttype}.updatetime=child.{parent}_updatetime
     
	 AND polper.EditEffectiveDate >= COALESCE (child.EffectiveDate, polper.PeriodStart)   
	 AND polper.EditEffectiveDate < COALESCE (child.ExpirationDate, polper.PeriodEnd)
		 
     JOIN v_pc_job job on polper.JobID = job.ID
     and polper.publicid=job.pc_policyperiod_publicid
     and polper.updatetime=job.pc_policyperiod_updatetime  
         
     JOIN v_pctl_policyperiodstatus STATUS ON STATUS.ID = POLPER.Status and not ( status.typecode = 'Bound' and job.closedate is null)
        
     LEFT JOIN v_pctl_job  JBT ON JOB.SUBTYPE = JBT.ID 
     WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
     ) SI   
       )
  """
 
  return harmz_query


# COMMAND ----------

def buildSILegacyScheduleNumLogicGen(rawDB: str,  parent:str ,cvrblType: str) : 
  dfLegacyScheduleNumCol =spark.sql(f"show columns in {rawDB}.{parent}").filter(col("col_name").like( "legacyschedulenum" ))
  legacyScheduleNumColCount = int(dfLegacyScheduleNumCol.count())
  if (legacyScheduleNumColCount == 1) :
    legacyScheduleNumLogic  = f"{cvrblType}.LEGACYSCHEDULENUM"
    return legacyScheduleNumLogic
  else:
      legacyScheduleNumLogic = "' '"
      return legacyScheduleNumLogic


# COMMAND ----------

def build_si_coverable( rawDB:str,parent:str ,cvrbl_type:str, childtable:str,source_system:str, lob_cd:str, si_type:str):
  parent1 = parent.upper()
  micro_bacth = "global_temp."+ parent +"_micro_batch_"+cvrbl_type+si_type
  ttype = cvrbl_type[:3] 
  
  legacyScheduleNumLogic = buildSILegacyScheduleNumLogicGen(rawDB,parent,ttype)
  
  harmz_query = f""" 
          WITH SESSION_PARAM as (SELECT '{source_system}' as source_system , '{lob_cd}' as LOB_CD, '{cvrbl_type}' as CVRBL_TYPE , '{si_type}' AS SI_TYPE_COVG  ) 
,  {parent}_micro_batch  as (select distinct branchid,updatetime from   {micro_bacth} )  
			,  Events_Max_Updatetime as (Select max(updatetime) as mb_max_updatetime from {micro_bacth} )
, v_pctl_policyperiodstatus as 
 (  select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp   desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp  <= mb.mb_max_updatetime
		) where rn=1
 )
 
 /*, v_childtable as 
 ( select * from
        (select *,row_number() over (partition by Id order by curr_timestamp desc) as rn 
           from {rawDB}.{childtable} child  
		   Cross Join Events_Max_Updatetime mb  
			On child.curr_timestamp<= mb.mb_max_updatetime
		) where rn=1
 )*/
,v_{parent} as
(select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select {parent}.*
			from {rawDB}.{parent}          
            inner join  {micro_bacth}   mb  
			   on mb.branchid = {parent} .branchid 
			where {parent} .updatetime <= mb.updatetime  
			)
		) where rn = 1)  

/**********,v_pc_policyperiod as 
        (
          --consider parent record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,p.updatetime,p.BranchID  --updatetime should be from parent in partition clause
              order by (unix_millis(p.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_{parent}  p
              JOIN  {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and polper.updatetime <= p.updatetime  --child update time <= parent update  time
            ) where rn=1
          union 
          --consider child record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,polper.updatetime,p.BranchID  --updatetime should be from child in partition clause
              order by (unix_millis(polper.updatetime) - unix_millis(p.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
              from v_{parent}  p
              JOIN {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and p.updatetime <= polper.updatetime --parent update time <= child update time
            ) where rn=1
        )************************/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            polper.PolicyNumber,
            polper.editeffectivedate,
            polper.basestate,            
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as {parent}_publicid,
            p.updatetime as {parent}_updatetime
          from
            v_{parent}  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
, v_pc_job as 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.Jobid  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.Jobid   --updatetime should be from childe in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and polper.updatetime <= job.updatetime  --parent update time <= child update time
    ) where rn=1 
)
, v_childtable as 
(
  --consider parent record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,drv.updatetime,drv.BranchID,drv.schedulecoverage,child.effectivedate,child.expirationdate   --updatetime should be from parent in partition clause
      order by (unix_millis(drv.updatetime) - unix_millis(child.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable} child
		on drv.schedulecoverage =child.fixedid
        and drv.branchid = child.branchid
        and child.updatetime <= drv.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,child.updatetime, drv.BranchID,drv.schedulecoverage,child.effectivedate,child.expirationdate    --updatetime should be from childe in partition clause
      order by (unix_millis(child.updatetime) - unix_millis(drv.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable}  child
        on drv.schedulecoverage =child.fixedid
        and drv.branchid = child.branchid
        and drv.updatetime <= child.updatetime  --parent update time <= child update time
    ) where rn=1 
)

,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp   desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp  <= mb.mb_max_updatetime
		) where rn=1
)
  
,HRZ_Query as (
 
SELECT UPPER ( SI.SOURCE_SYSTEM|| '-'|| CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255))|| '-'ELSE ''END || (case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then SI.CVRBL_TYPE else SI.CVRBL_TYPE || SI.SI_TYPE END) || '-' || CAST (CAST(SI.FixedID AS INTEGER) AS VARCHAR (255))) AS SI_KEY,
UPPER (SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN SI.TypeCode <> 'Bound' THEN '-QT:' || CAST (SI.publicID AS VARCHAR (255)) ELSE ''END)AS POL_KEY,
'NOKEY' AS POL_LINE_KEY,
'NOKEY' AS LINE_COND_KEY,
UPPER (CASE WHEN SI.SCHED_TYP IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM  || '-'  || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then 'IMGValuablePaper'||SI.SI_TYPE else SI.CVRBL_TYPE END || '-' || CAST (CAST(SI.SCHED_TYP AS INTEGER) AS VARCHAR (255)) END) AS LINE_COVG_KEY, 
'NOKEY' AS LINE_EXCL_KEY, 
UPPER (CASE WHEN SI.OWNING_CVRBL IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then 'IMGValuablePaper'||SI.SI_TYPE else SI.CVRBL_TYPE END || '-' || CAST(SI.OWNING_CVRBL AS VARCHAR (255)) END) AS OWNING_CVRBL_KEY,
'NOKEY' AS POL_PARTY_KEY,  
UPPER ( CASE WHEN SI.NamedInsured IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || CAST (SI.NamedInsured AS VARCHAR (255)) END) AS LINE_POL_PARTY_KEY, 
UPPER (
        CASE  WHEN SI.Location IS NULL THEN 'NOKEY'
              ELSE 
              SI.Source_System || '-' || CAST (CAST (SI.PeriodID AS INTEGER) AS VARCHAR (255))|| '-' || 
              CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-'
                   ELSE '' END || CAST (CAST (SI.Location AS INTEGER) AS VARCHAR (255)) END
                   ) AS LOC_KEY, 
 'NOKEY'  AS LINE_LOCATION_KEY,
'NOKEY' AS ADDL_INTRST_KEY, 
CAST (COALESCE (SI.EffectiveDate, SI.PeriodStart) AS DATE) AS END_EFF_DT, CAST (COALESCE (SI.ExpirationDate, SI.PeriodEnd) AS DATE) AS END_EXP_DT, SI.SOURCE_SYSTEM AS SOURCE_SYSTEM, (case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then SI.CVRBL_TYPE else SI.CVRBL_TYPE || SI.SI_TYPE END) AS CVRBL_TYPE_CD, SI.SCHED_NO AS SCHED_NO, 
COALESCE(SI.TypeKeyCol1, ' ') AS TYPE_KEY_COL_1, COALESCE(SI.TypeKeyCol2, ' ') AS TYPE_KEY_COL_2, ' ' AS TYPE_KEY_COL_3, ' ' AS TYPE_KEY_COL_4, ' ' AS TYPE_KEY_COL_5, ' ' AS TYPE_KEY_COL_6, COALESCE(SI.StringCol1, ' ') AS STR_COL_1, COALESCE(SI.StringCol2, ' ') AS STR_COL_2, COALESCE(SI.StringCol3, ' ') AS STR_COL_3, COALESCE(SI.StringCol4, ' ') AS STR_COL_4, COALESCE(SI.StringCol5, ' ') AS STR_COL_5, COALESCE(SI.STRINGCOL6, ' ') AS STR_COL_6, COALESCE(SI.STRINGCOL7, ' ') AS STR_COL_7, COALESCE(SI.STRINGCOL8, ' ') AS STR_COL_8,
' ' AS LONG_STR_COL_1, 
' ' AS LONG_STR_COL_2, 
SI.DATECOL1 AS DT_COL_1_DTS, 
NULL AS DT_COL_2_DTS, 
NULL AS DT_COL_3_DTS,
CAST(SI.FixedID AS INTEGER) AS LIFE_OBJECT_NO,
SI.IntCol1 AS INT_COL_1, 
SI.IntCol2 AS INT_COL_2, 
SI.IntCol3 AS INT_COL_3, 
SI.IntCol4 AS INT_COL_4, 
SI.IntCol5 AS INT_COL_5,
SI.INTCOL6 AS INT_COL_6, 
SI.INTCOL7 AS  INT_COL_7  ,  
SI.PosIntCol1 AS POS_INT_COL_1, 
SI.NONNEGATIVEINTCOL1 AS NON_NEG_INT_1, 
SI.NONNEGATIVEINTCOL2 AS NON_NEG_INT_2, 
SI.NONNEGATIVEINTCOL3 AS NON_NEG_INT_3, 
NULL AS NON_NEG_INT_4, 
NULL AS NON_NEG_INT_5, 
COALESCE(SI.BoolCol1, 'U') AS Bool_COL_1_FL, 
COALESCE(SI.BoolCol2, 'U') AS Bool_COL_2_FL, 
'U' AS Bool_COL_3_FL,
'U' AS Bool_COL_4_FL,
'U' AS Bool_COL_5_FL,
'U' AS Bool_COL_6_FL,
'U' AS Bool_COL_7_FL,
'U' AS Bool_COL_8_FL,
SI.DECIMALCOL1 AS DECIMAL_COL_1, 
SI.DECIMALCOL2 AS DECIMAL_COL_2, 
SI.DECIMALCOL3 AS DECIMAL_COL_3, 
' ' AS OPT_COL_1,
' ' AS OPT_COL_2,   
' ' AS OPT_COL_3, 
' ' AS OPT_COL_4, 
' ' AS OPT_COL_5, 
' ' AS OPT_COL_6, 
' ' AS OPT_COL_7, 
' ' AS OPT_COL_8, 
' ' AS OPT_COL_9, 
' ' AS OPT_COL_10, 
' ' AS OPT_COL_11, 
' ' AS OPT_COL_12, 
' ' AS OPT_COL_13, 
' ' AS OPT_COL_14, 
' ' AS OPT_COL_15, 
' ' AS OPT_COL_16, 
' ' AS OPT_COL_17, 
' ' AS OPT_COL_18, 
' ' AS OPT_COL_19, 
' ' AS OPT_COL_20, 
' ' AS OPT_COL_21, 
' ' AS OPT_COL_22, 
' ' AS OPT_COL_23, 
SI.YEARCOL1 AS YEAR_COL_1,
' ' AS ADDL_INS_TYPE_CD,
SI.LOB_CD AS LOB_CD,
(case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then SI.SOURCE_SYSTEM||'-'||SI.LOB_CD||'-'||SI.CVRBL_TYPE else SI.SOURCE_SYSTEM||'-'||SI.LOB_CD||'-'||SI.CVRBL_TYPE || SI.SI_TYPE END) AS PARTITION_VAL
,SI.LEGACY_SI_NB AS LEGACY_SI_NB
,CASE WHEN SI.TypeCode = 'Bound' THEN SI.CloseDate ELSE COALESCE (polper_UpdateTime, polper_CreateTime) END AS ETL_ROW_EFF_DTS
,SI.updatetime_tab1,SI.updatetime_tab2,SI.updatetime_tab3,SI.updatetime_tab4,SI.SRC_BRANCHID, SI.SRC_FIXEDID,SI.SRC_EFFECTIVEDATE,SI.SRC_EXPIRATIONDATE,SI.POLPER_PERIODSTART
,SI.POLPER_PERIODEND,SI.POLPER_PUBLICID,SI.SRC_PUBLICID,SI.SRC_UPDATETIME,SI.SRC_CREATETIME
FROM (SELECT SP.CVRBL_TYPE as SP_CVRBL_TYPE, SP.SOURCE_SYSTEM AS SOURCE_SYSTEM, SP.LOB_CD as LOB_CD, (case when SP.CVRBL_TYPE ='IMGValPaperSchedCovItem' then SP.CVRBL_TYPE ||SP.SI_TYPE_COVG else SP.CVRBL_TYPE end) as CVRBL_TYPE, SP.SI_TYPE_COVG AS SI_TYPE,
cast(child.{cvrbl_type} as integer) AS OWNING_CVRBL,{ttype}.NamedInsured,{ttype}.Policylocation Location,{ttype}.FixedID,{ttype}.EffectiveDate,{ttype}.ExpirationDate,{ttype}.ScheduleNumber SCHED_NO,{ttype}.TYPEKEYCOL1,{ttype}.TYPEKEYCOL2,{ttype}.STRINGCOL1,{ttype}.STRINGCOL2,{ttype}.STRINGCOL3,{ttype}.STRINGCOL4,{ttype}.STRINGCOL5,{ttype}.STRINGCOL6,{ttype}.STRINGCOL7,{ttype}.STRINGCOL8,{ttype}.DATECOL1,{ttype}.INTCOL1,{ttype}.INTCOL2,{ttype}.INTCOL3,{ttype}.INTCOL4,{ttype}.INTCOL5,{ttype}.INTCOL6,{ttype}.INTCOL7,{ttype}.POSINTCOL1,{ttype}.NONNEGATIVEINTCOL1,{ttype}.NONNEGATIVEINTCOL2,{ttype}.NONNEGATIVEINTCOL3,{ttype}.BOOLCOL1,{ttype}.BOOLCOL2,{ttype}.DECIMALCOL1,{ttype}.DECIMALCOL2,{ttype}.DECIMALCOL3,{ttype}.YEARCOL1,{ttype}.SCHEDULECOVERAGE AS SCHED_TYP,{legacyScheduleNumLogic} as LEGACY_SI_NB,status.TypeCode,job.CloseDate,{ttype}.UpdateTime,{ttype}.CreateTime,polper.updateTime polper_updatetime,polper.CreateTime polper_Createtime,POLPER.PUBLICID,POLPER.PERIODID,POLPER.PERIODSTART,POLPER.PERIODEND, POLPER.updatetime as updatetime_tab1 , {ttype}.updatetime as updatetime_tab2 , job.updatetime as updatetime_tab3 , child.updatetime as updatetime_tab4, {ttype}.branchid as SRC_BRANCHID
, {ttype}.fixedid as SRC_FIXEDID, {ttype}.effectivedate as SRC_EFFECTIVEDATE, {ttype}.expirationdate as SRC_EXPIRATIONDATE, POLPER.periodstart as POLPER_PERIODSTART, POLPER.periodend as POLPER_PERIODEND, POLPER.publicid as POLPER_PUBLICID, {ttype}.publicid as SRC_PUBLICID, {ttype}.updatetime as SRC_UPDATETIME, {ttype}.createtime as SRC_CREATETIME
		 
 FROM v_{parent} {ttype} CROSS JOIN SESSION_PARAM SP
     JOIN v_pc_policyperiod polper ON {ttype}.BranchID = polper.ID 
	 and {ttype}.publicid=polper.{parent}_publicid
     and {ttype}.updatetime=polper.{parent}_updatetime
      
     JOIN v_childtable child  ON  {ttype}.SCHEDULECOVERAGE = child.FixedID   
     AND {ttype}.BranchID = child.BranchID
     and {ttype}.publicid=child.{parent}_publicid
     and {ttype}.updatetime=child.{parent}_updatetime
	 AND polper.EditEffectiveDate >= COALESCE ( child.EffectiveDate, polper.PeriodStart)   
	 AND polper.EditEffectiveDate < COALESCE ( child.ExpirationDate, polper.PeriodEnd)
		 
     JOIN v_pc_job job on polper.JobID = job.ID
     and polper.publicid=job.pc_policyperiod_publicid
     and polper.updatetime=job.pc_policyperiod_updatetime  
         
     JOIN v_pctl_policyperiodstatus STATUS ON STATUS.ID = POLPER.Status and not ( status.typecode = 'Bound' and job.closedate is null)
        
     LEFT JOIN v_pctl_job  JBT ON JOB.SUBTYPE = JBT.ID 
     WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
     ) SI   
     
       )
  """

  return harmz_query

# COMMAND ----------

def build_si_coverable_cop( rawDB: str,  parent:str ,  cvrbl_type:str, childtable:str, source_system:str, lob_cd:str, si_type:str):
  parent1 = parent.upper()
  micro_bacth = "global_temp."+ parent +"_micro_batch_"+cvrbl_type+si_type
  ttype = cvrbl_type[:3] 
  legacyScheduleNumLogic = buildSILegacyScheduleNumLogicGen(rawDB,parent,ttype)
  ScheduleCoverageLogic = buildSIScheduleCoverageLogicGen_COP(rawDB,parent,ttype)
  harmz_query = f""" 
			WITH SESSION_PARAM as (SELECT '{source_system}' as source_system , '{lob_cd}' as LOB_CD, '{cvrbl_type}' as CVRBL_TYPE , '{si_type}' AS SI_TYPE_COVG  ) 
,  {parent}_micro_batch  as (select distinct branchid,updatetime from   {micro_bacth} )  
,  Events_Max_Updatetime as (Select max(updatetime) as mb_max_updatetime from {micro_bacth} )
, v_pctl_policyperiodstatus as 
 (  select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
 )
 
 /*, v_childtable as 
 ( select * from
        (select *,row_number() over (partition by Id order by curr_timestamp desc) as rn 
           from {rawDB}.{childtable} child  
		   Cross Join Events_Max_Updatetime mb  
			On child.curr_timestamp<= mb.mb_max_updatetime
		) where rn=1
 )*/
,v_{parent} as
(select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select {parent}.*
			from {rawDB}.{parent}          
            inner join  {micro_bacth}   mb  
			   on mb.branchid = {parent} .branchid 
			where {parent} .updatetime <= mb.updatetime  
			)
		) where rn = 1)  

/**********,v_pc_policyperiod as 
        (
          --consider parent record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,p.updatetime,p.BranchID  --updatetime should be from parent in partition clause
              order by (unix_millis(p.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
              from v_{parent}  p
              JOIN  {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and polper.updatetime <= p.updatetime  --child update time <= parent update  time
            ) where rn=1
          union 
          --consider child record as driving record
          select * from 
            (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
              row_number() over (partition by p.publicid,polper.updatetime,p.BranchID  --updatetime should be from child in partition clause
              order by (unix_millis(polper.updatetime) - unix_millis(p.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
              from v_{parent}  p
              JOIN {rawDB}.pc_policyperiod  polper 
                on p.BranchID = polper.ID 
                and p.updatetime <= polper.updatetime --parent update time <= child update time
            ) where rn=1
        )************************/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            polper.PolicyNumber,
            polper.editeffectivedate,
            polper.basestate,            
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as {parent}_publicid,
            p.updatetime as {parent}_updatetime
          from
            v_{parent}  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
, v_pc_job as 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.Jobid  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.Jobid   --updatetime should be from childe in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and polper.updatetime <= job.updatetime  --parent update time <= child update time
    ) where rn=1 
)
, v_childtable as 
(
  --consider parent record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,drv.updatetime,drv.BranchID,drv.{ScheduleCoverageLogic},child.effectivedate,child.expirationdate  --updatetime should be from parent in partition clause
      order by (unix_millis(drv.updatetime) - unix_millis(child.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable} child
		on drv.{ScheduleCoverageLogic} =child.fixedid
        and drv.branchid = child.branchid
        and child.updatetime <= drv.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select child.*,drv.publicid as {parent}_publicid,drv.updatetime as {parent}_updatetime,
      row_number() over (partition by drv.publicid,child.updatetime,drv.BranchID,drv.{ScheduleCoverageLogic},child.effectivedate,child.expirationdate   --updatetime should be from childe in partition clause
      order by (unix_millis(child.updatetime) - unix_millis(drv.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent} drv
      JOIN {rawDB}.{childtable}  child
        on drv.{ScheduleCoverageLogic} =child.fixedid
        and drv.branchid = child.branchid
        and drv.updatetime <= child.updatetime  --parent update time <= child update time
    ) where rn=1 
)

,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
  
,HRZ_Query as ( 
 
SELECT UPPER ( SI.SOURCE_SYSTEM|| '-'|| CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255))|| '-'ELSE ''END || (case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then SI.CVRBL_TYPE else SI.CVRBL_TYPE || SI.SI_TYPE END) || '-' || CAST (CAST(SI.FixedID AS INTEGER) AS VARCHAR (255))) AS SI_KEY,
UPPER (SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN SI.TypeCode <> 'Bound' THEN '-QT:' || CAST (SI.publicID AS VARCHAR (255)) ELSE ''END)AS POL_KEY,
UPPER ( CASE WHEN SI.copline IS NULL or SI.SP_CVRBL_TYPE='COPBuilding'or SI.SP_CVRBL_TYPE='COPLocation' THEN 'NOKEY' ELSE SI.Source_System || '-' || CAST (CAST (SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.copline AS INTEGER)AS VARCHAR (255)) END) AS POL_LINE_KEY,
'NOKEY' AS LINE_COND_KEY,
UPPER (CASE WHEN SI.SCHED_TYP IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM  || '-'  || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.SCHED_TYP AS INTEGER) AS VARCHAR (255)) END) AS LINE_COVG_KEY, 
'NOKEY' AS LINE_EXCL_KEY, 
UPPER (CASE WHEN SI.OWNING_CVRBL IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then 'IMGValuablePaper'||SI.SI_TYPE else SI.CVRBL_TYPE END || '-' || CAST(SI.OWNING_CVRBL AS VARCHAR (255)) END) AS OWNING_CVRBL_KEY,
'NOKEY' AS POL_PARTY_KEY,  
UPPER ( CASE WHEN SI.NamedInsured IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || CAST (SI.NamedInsured AS VARCHAR (255)) END) AS LINE_POL_PARTY_KEY, 
'NOKEY' AS LOC_KEY, 
UPPER ( CASE WHEN SI.Location IS NULL THEN 'NOKEY' ELSE SI.SOURCE_SYSTEM || '-' || CAST (CAST(SI.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN SI.TypeCode <> 'Bound' THEN 'QT:' || CAST (SI.publicID AS VARCHAR (255)) || '-' ELSE '' END || SI.CVRBL_TYPE || '-' || CAST (CAST(SI.Location AS INTEGER) AS VARCHAR (255)) END) AS LINE_LOCATION_KEY, 
'NOKEY' AS ADDL_INTRST_KEY, 
CAST (COALESCE (SI.EffectiveDate, SI.PeriodStart) AS DATE) AS END_EFF_DT, CAST (COALESCE (SI.ExpirationDate, SI.PeriodEnd) AS DATE) AS END_EXP_DT, SI.SOURCE_SYSTEM AS SOURCE_SYSTEM, (case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then SI.CVRBL_TYPE else SI.CVRBL_TYPE || SI.SI_TYPE END) AS CVRBL_TYPE_CD, SI.SCHED_NO AS SCHED_NO, 
COALESCE(SI.TypeKeyCol1, ' ') AS TYPE_KEY_COL_1, COALESCE(SI.TypeKeyCol2, ' ') AS TYPE_KEY_COL_2, ' ' AS TYPE_KEY_COL_3, ' ' AS TYPE_KEY_COL_4, ' ' AS TYPE_KEY_COL_5, ' ' AS TYPE_KEY_COL_6, COALESCE(SI.StringCol1, ' ') AS STR_COL_1, COALESCE(SI.StringCol2, ' ') AS STR_COL_2, COALESCE(SI.StringCol3, ' ') AS STR_COL_3, COALESCE(SI.StringCol4, ' ') AS STR_COL_4, COALESCE(SI.StringCol5, ' ') AS STR_COL_5, COALESCE(SI.STRINGCOL6, ' ') AS STR_COL_6, COALESCE(SI.STRINGCOL7, ' ') AS STR_COL_7,  ' ' AS STR_COL_8,
' ' AS LONG_STR_COL_1, 
' ' AS LONG_STR_COL_2, 
SI.DATECOL1 AS DT_COL_1_DTS, 
SI.DATECOL2 AS DT_COL_2_DTS, 
SI.DATECOL3 AS DT_COL_3_DTS,
CAST(SI.FixedID AS INTEGER) AS LIFE_OBJECT_NO,
SI.IntCol1 AS INT_COL_1, 
SI.IntCol2 AS INT_COL_2, 
SI.IntCol3 AS INT_COL_3, 
NULL AS INT_COL_4, 
NULL AS INT_COL_5,
NULL AS INT_COL_6, 
NULL AS INT_COL_7  ,  
SI.PosIntCol1 AS POS_INT_COL_1, 
SI.NONNEGATIVEINTCOL1 AS NON_NEG_INT_1, 
NULL AS NON_NEG_INT_2, 
NULL AS NON_NEG_INT_3, 
NULL AS NON_NEG_INT_4, 
NULL AS NON_NEG_INT_5, 
CASE WHEN SI.BoolCol1 =1 THEN 'Y' WHEN SI.BoolCol1=0 THEN 'N' ELSE 'U' END AS BOOL_COL_1_FL,
CASE WHEN SI.BoolCol2 =1 THEN 'Y' WHEN SI.BoolCol2=0 THEN 'N' ELSE 'U' END AS BOOL_COL_2_FL,
CASE WHEN SI.BoolCol3 =1 THEN 'Y' WHEN SI.BoolCol3=0 THEN 'N' ELSE 'U' END AS BOOL_COL_3_FL,
CASE WHEN SI.BoolCol4 =1 THEN 'Y' WHEN SI.BoolCol4=0 THEN 'N' ELSE 'U' END AS BOOL_COL_4_FL,
CASE WHEN SI.BoolCol5 =1 THEN 'Y' WHEN SI.BoolCol5=0 THEN 'N' ELSE 'U' END AS BOOL_COL_5_FL,
CASE WHEN SI.BoolCol6 =1 THEN 'Y' WHEN SI.BoolCol6=0 THEN 'N' ELSE 'U' END AS BOOL_COL_6_FL,
CASE WHEN SI.BoolCol7 =1 THEN 'Y' WHEN SI.BoolCol7=0 THEN 'N' ELSE 'U' END AS BOOL_COL_7_FL,
CASE WHEN SI.BoolCol8 =1 THEN 'Y' WHEN SI.BoolCol8=0 THEN 'N' ELSE 'U' END AS BOOL_COL_8_FL,
NULL AS DECIMAL_COL_1, 
NULL AS DECIMAL_COL_2, 
NULL AS DECIMAL_COL_3, 
COALESCE(SI.OptionCol1, ' ') AS OPT_COL_1,
' ' AS OPT_COL_2,   
' ' AS OPT_COL_3, 
' ' AS OPT_COL_4, 
' ' AS OPT_COL_5, 
' ' AS OPT_COL_6, 
' ' AS OPT_COL_7, 
' ' AS OPT_COL_8, 
' ' AS OPT_COL_9, 
' ' AS OPT_COL_10, 
' ' AS OPT_COL_11, 
' ' AS OPT_COL_12, 
' ' AS OPT_COL_13, 
' ' AS OPT_COL_14, 
' ' AS OPT_COL_15, 
' ' AS OPT_COL_16, 
' ' AS OPT_COL_17, 
' ' AS OPT_COL_18, 
' ' AS OPT_COL_19, 
' ' AS OPT_COL_20, 
' ' AS OPT_COL_21, 
' ' AS OPT_COL_22, 
' ' AS OPT_COL_23, 
SI.YEARCOL1 AS YEAR_COL_1,
' ' AS ADDL_INS_TYPE_CD,
SI.LOB_CD AS LOB_CD,
(case when SI.SP_CVRBL_TYPE='IMGValPaperSchedCovItem' then SI.SOURCE_SYSTEM||'-'||SI.LOB_CD||'-'||SI.CVRBL_TYPE else SI.SOURCE_SYSTEM||'-'||SI.LOB_CD||'-'||SI.CVRBL_TYPE || SI.SI_TYPE END) AS PARTITION_VAL
,NULL AS LEGACY_SI_NB
,CASE WHEN SI.TypeCode = 'Bound' THEN SI.CloseDate ELSE COALESCE (polper_UpdateTime, polper_CreateTime) END AS ETL_ROW_EFF_DTS
,SI.updatetime_tab1,SI.updatetime_tab2,SI.updatetime_tab3,SI.updatetime_tab4,SI.SRC_BRANCHID, SI.SRC_FIXEDID,SI.SRC_EFFECTIVEDATE,SI.SRC_EXPIRATIONDATE,SI.POLPER_PERIODSTART
,SI.POLPER_PERIODEND,SI.POLPER_PUBLICID,SI.SRC_PUBLICID,SI.SRC_UPDATETIME,SI.SRC_CREATETIME
FROM (SELECT SP.CVRBL_TYPE as SP_CVRBL_TYPE, SP.SOURCE_SYSTEM AS SOURCE_SYSTEM, SP.LOB_CD as LOB_CD, (case when SP.CVRBL_TYPE ='IMGValPaperSchedCovItem' then 'IMGValuablePaper'||SP.SI_TYPE_COVG else SP.CVRBL_TYPE end) as CVRBL_TYPE, SP.SI_TYPE_COVG AS SI_TYPE,
cast(child.{cvrbl_type} as integer) AS OWNING_CVRBL,child.{cvrbl_type} AS copline,{ttype}.NamedInsured,{ttype}.Policylocation Location,{ttype}.FixedID,{ttype}.EffectiveDate,{ttype}.ExpirationDate,{ttype}.ScheduleNumber SCHED_NO,{ttype}.TYPEKEYCOL1,{ttype}.TYPEKEYCOL2,{ttype}.STRINGCOL1,{ttype}.STRINGCOL2,{ttype}.STRINGCOL3,{ttype}.STRINGCOL4,{ttype}.STRINGCOL5,{ttype}.STRINGCOL6,{ttype}.STRINGCOL7,{ttype}.DATECOL1,{ttype}.DATECOL2,{ttype}.DATECOL3,{ttype}.INTCOL1,{ttype}.INTCOL2,{ttype}.INTCOL3,{ttype}.POSINTCOL1,{ttype}.NONNEGATIVEINTCOL1,{ttype}.BOOLCOL1,{ttype}.BOOLCOL2,{ttype}.BOOLCOL3,{ttype}.BOOLCOL4,{ttype}.BOOLCOL5,{ttype}.BOOLCOL6,{ttype}.BOOLCOL7,{ttype}.BOOLCOL8,{ttype}.YEARCOL1,{ttype}.OPTIONCOL1,{ttype}.{ScheduleCoverageLogic} AS SCHED_TYP,{ttype}.SCHEDULENUMBER as LEGACY_SI_NB,status.TypeCode,job.CloseDate,{ttype}.UpdateTime,{ttype}.CreateTime,polper.updateTime polper_updatetime,polper.CreateTime polper_Createtime,POLPER.PUBLICID,POLPER.PERIODID,POLPER.PERIODSTART,POLPER.PERIODEND, POLPER.updatetime as updatetime_tab1 , {ttype}.updatetime as updatetime_tab2 , job.updatetime as updatetime_tab3 , child.updatetime as updatetime_tab4, {ttype}.branchid as SRC_BRANCHID
, {ttype}.fixedid as SRC_FIXEDID, {ttype}.effectivedate as SRC_EFFECTIVEDATE, {ttype}.expirationdate as SRC_EXPIRATIONDATE, POLPER.periodstart as POLPER_PERIODSTART, POLPER.periodend as POLPER_PERIODEND, POLPER.publicid as POLPER_PUBLICID, {ttype}.publicid as SRC_PUBLICID, {ttype}.updatetime as SRC_UPDATETIME, {ttype}.createtime as SRC_CREATETIME
		 
 FROM v_{parent} {ttype} CROSS JOIN SESSION_PARAM SP
     JOIN v_pc_policyperiod polper ON {ttype}.BranchID = polper.ID 
	 and {ttype}.publicid=polper.{parent}_publicid
     and {ttype}.updatetime=polper.{parent}_updatetime
      
     JOIN v_childtable child  ON  {ttype}.{ScheduleCoverageLogic} = child.FixedID   
     AND {ttype}.BranchID = child.BranchID
     and {ttype}.publicid=child.{parent}_publicid
     and {ttype}.updatetime=child.{parent}_updatetime
	 AND polper.EditEffectiveDate >= COALESCE ( child.EffectiveDate, polper.PeriodStart)   
	 AND polper.EditEffectiveDate < COALESCE ( child.ExpirationDate, polper.PeriodEnd)
		 
     JOIN v_pc_job job on polper.JobID = job.ID
     and polper.publicid=job.pc_policyperiod_publicid
     and polper.updatetime=job.pc_policyperiod_updatetime  
         
     JOIN v_pctl_policyperiodstatus STATUS ON STATUS.ID = POLPER.Status and not ( status.typecode = 'Bound' and job.closedate is null)
        
     LEFT JOIN v_pctl_job  JBT ON JOB.SUBTYPE = JBT.ID 
     WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
     ) SI   
       )
  """
  
  return harmz_query


# COMMAND ----------

def build_pol_ans( rawDB,  parent,  cvrbl_type,  src_cvrbl_type):
  #Convert to uppercase
  parent1 = parent.upper()
  micro_bacth = "global_temp."+ parent +"_micro_batch" 
  #Extract sub string after the third element of the string
  ttype =  cvrbl_type[3:]
  print(ttype)
  harmz_query = f""" WITH SESSION_PARAM as (SELECT 'GWPC' as source_system ,  '{cvrbl_type}' as CVRBL_TYPE    ) 
,  {parent}_micro_batch  as (select distinct branchid,updatetime from   {micro_bacth} )  
,  Events_Max_Updatetime as (Select max(updatetime) as mb_max_updatetime from {micro_bacth} )
,v_{parent} as
(select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select {parent}.*
			from {rawDB}.{parent}          
            inner join  {micro_bacth}   mb  
			   on mb.branchid = {parent}.branchid 
			where {parent}.updatetime <= mb.updatetime  
			)
		) where rn = 1)
, v_pctl_policyperiodstatus as 
 (
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
 )
 
 /********,v_pc_policyperiod as 
(
  --consider parent record as driving record
  select * from 
    (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
      row_number() over (partition by p.publicid,p.updatetime,p.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(p.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_{parent}  p
      JOIN  {rawDB}.pc_policyperiod  polper 
        on p.BranchID = polper.ID 
        and polper.updatetime <= p.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,p.publicid as {parent}_publicid,p.updatetime as {parent}_updatetime,
      row_number() over (partition by p.publicid,polper.updatetime,p.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(p.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_{parent}  p
      JOIN {rawDB}.pc_policyperiod  polper 
        on p.BranchID = polper.ID 
        and p.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)****/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            polper.PolicyNumber,
            polper.editeffectivedate,
            polper.basestate,            
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            Polper.policyid,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as {parent}_publicid,
            p.updatetime as {parent}_updatetime
          from
            v_{parent}  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------

, v_pc_policy as 
(
  --consider parent record as driving record
  select * from 
    (select pol.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.policyId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(pol.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_policy pol
        on polper.policyId = pol.ID 
        and pol.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select pol.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,pol.updatetime,polper.policyId   --updatetime should be from childe in partition clause
      order by (unix_millis(pol.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_policy  pol
        on polper.policyId = pol.ID 
        and polper.updatetime <= pol.updatetime  --parent update time <= child update time
    ) where rn=1 
)
, v_pc_job as 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.Jobid  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.Jobid   --updatetime should be from childe in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_job  job
        on polper.JobId = Job.ID 
        and polper.updatetime <= job.updatetime  --parent update time <= child update time
    ) where rn=1 
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
  
, DS_LINE_ANS as ( SELECT UPPER(SP.SOURCE_SYSTEM || '-' || 
                  CAST(CAST(polper.PeriodID AS INTEGER) AS varchar(255)) || '-' || 
                  CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST(polper.publicID AS VARCHAR(255)) || '-' 
                       ELSE ''
                   END || SP.CVRBL_TYPE || '-' || CAST( {ttype}.FixedId  AS INTEGER)  ) AS POL_ANS_KEY
             ,'NOKEY' AS POL_LINE_KEY
             ,UPPER(SP.SOURCE_SYSTEM || '-' ||  CAST(CAST(polper.PeriodID AS INTEGER) AS varchar(255))   || 
                 CASE WHEN status.TypeCode <> 'Bound' THEN '-QT:' || CAST(polper.publicID AS VARCHAR(255)) 
                      ELSE ''
                  END ) AS POL_KEY
             ,'NOKEY' as BLDG_KEY
             ,UPPER(SP.SOURCE_SYSTEM || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS varchar(255))  || 
                     CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(POLPER.publicID AS VARCHAR(255)) 
                          ELSE ''
                           END || '-' || SP.CVRBL_TYPE || '-'|| CAST( CAST(COALESCE({ttype}.{cvrbl_type},{ttype}.{src_cvrbl_type}) AS INTEGER) AS varchar(255))
                         -- END || '-' ||  SP.CVRBL_TYPE || '-'|| CAST( CAST({ttype}.{src_cvrbl_type}  AS INTEGER)  AS varchar(255))
                    )AS CVRBL_KEY 
             ,CAST(COALESCE( {ttype}.EffectiveDate, polper.PeriodStart) AS date) AS END_EFF_DT 
             ,CAST(COALESCE( {ttype}.ExpirationDate, polper.PeriodEnd) AS date) AS END_EXP_DT
             ,SP.SOURCE_SYSTEM AS SOURCE_SYSTEM
             ,POL.PRODUCTCODE AS POL_LINE_TYPE_CD
             ,SP.CVRBL_TYPE as CVRBL_TYPE_CD
             ,CASE WHEN booleananswer='1' THEN 'Y' WHEN booleananswer='0' THEN 'N' ELSE 'U' END  AS BOOLEAN_ANS
             ,dateanswer AS DT_ANS
             ,integeranswer AS INTEGER_ANS
             ,questioncode AS QSTN_CD             
             ,textanswer AS TEXT_ANS
             ,choiceanswercode AS CHOICE_ANS_CD
             ,polper.periodstart AS POL_EFF_DT
             ,polper.periodend AS POL_EXP_DT
             , {ttype}.changetype AS POL_CHNG_TYPE
             ,CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate
                  ELSE COALESCE(polper.UpdateTime, polper.CreateTime)
              END AS ETL_ROW_EFF_DTS,
              SP.SOURCE_SYSTEM||'-'||'IM'||'-'||SP.CVRBL_TYPE AS PARTITION_VAL
, POLPER.updatetime as updatetime_tab1 
, {ttype}.updatetime as updatetime_tab2 
, job.updatetime as updatetime_tab3 
, {ttype}.branchid as SRC_BRANCHID
, {ttype}.fixedid as SRC_FIXEDID
, {ttype}.effectivedate as SRC_EFFECTIVEDATE
, {ttype}.expirationdate as SRC_EXPIRATIONDATE
, POLPER.periodstart as POLPER_PERIODSTART
, POLPER.periodend as POLPER_PERIODEND
, POLPER.publicid as POLPER_PUBLICID
, {ttype}.publicid as SRC_PUBLICID
, {ttype}.updatetime as SRC_UPDATETIME
, {ttype}.createtime as SRC_CREATETIME
,  CASE WHEN ans_hard_delete.publicid is not null THEN 'Y' ELSE 'N' END AS QT_DELETE_IND
              
       FROM  v_{parent} {ttype} CROSS JOIN SESSION_PARAM SP
        
              JOIN v_pc_policyperiod polper 
               on {ttype}.BranchID = polper.ID 
              and {ttype}.publicid=polper.{parent}_publicid
              and {ttype}.updatetime=polper.{parent}_updatetime
              
               JOIN v_pc_job job 
               on polper.JobID = job.ID
               and polper.publicid=job.pc_policyperiod_publicid
               and polper.updatetime=job.pc_policyperiod_updatetime                      
               
              JOIN v_pctl_policyperiodstatus STATUS ON STATUS.ID = POLPER.Status and not ( status.typecode = 'Bound' and job.closedate is null)
              JOIN v_pctl_job  JBT ON JOB.SUBTYPE = JBT.ID 
              JOIN v_pc_policy pol ON pol.id = polper.policyid
              and polper.publicid=pol.pc_policyperiod_publicid
              and polper.updatetime=pol.pc_policyperiod_updatetime
              
              left join (select distinct publicid,updatetime  from {rawDB}.{parent} where z_meta_operation  ='DELETE') as ans_hard_delete
                on {ttype}.publicid = ans_hard_delete.publicid and ans_hard_delete.updatetime={ttype}.updatetime
              WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
         
       )
,HRZ_Query as 
(
  SELECT    
   POL_ANS_KEY
  ,POL_KEY
  ,POL_LINE_KEY
  ,BLDG_KEY
  ,CVRBL_KEY
  ,END_EFF_DT
  ,END_EXP_DT
  ,SOURCE_SYSTEM
  ,PARTITION_VAL
  ,COALESCE(POL_LINE_TYPE_CD, ' ') AS POL_LINE_TYPE_CD
  ,CVRBL_TYPE_CD
  ,COALESCE(BOOLEAN_ANS, 'U') AS BOOLEAN_ANS
  ,COALESCE(DT_ANS, '9999-12-31') AS DT_ANS
  ,COALESCE(INTEGER_ANS, '0') AS INTEGER_ANS
  ,COALESCE( ans.QSTN_CD, ' ') AS  QSTN_CD
  ,COALESCE(QA.QSTN_DESC , ' ') AS   QSTN_DESC
  ,COALESCE(TEXT_ANS , ' ') AS  TEXT_ANS
  ,COALESCE(CHOICE_ANS_CD , ' ') AS  CHOICE_ANS_CD
  ,ETL_ROW_EFF_DTS
  ,'IM' as LOB_CD
  ,QT_DELETE_IND
  ,updatetime_tab1 
  ,updatetime_tab2 
  ,updatetime_tab3 
  ,SRC_BRANCHID
  ,SRC_FIXEDID
  ,SRC_EFFECTIVEDATE
  ,SRC_EXPIRATIONDATE
  ,POLPER_PERIODSTART
  ,POLPER_PERIODEND
  ,POLPER_PUBLICID
  ,SRC_PUBLICID
  ,SRC_UPDATETIME
  ,SRC_CREATETIME
from DS_LINE_ANS  ans
LEFT JOIN  {rawDB}.POL_ANS_QSTN_CD_XREF QA 
on ANS.QSTN_CD = QA.QSTN_CD
WHERE QA.TABLENAME = 'DS_POL_ANS' )
  """

  return harmz_query

# COMMAND ----------

def build_covg_term_detail(harmonizedDB, curatedDB, target, cvrbl_type, lob, source_system, Key_col, incr_covg_term_view):
  ## surrgogate_id creation
  surrogateID= (target[3:]+"_ID").upper()
  exclude_cols = ["POL_KEY","LINE_CVRBL_KEY","CVRBL_TYPE_CD","LOB_CD","SOURCE_SYSTEM","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS","END_EFF_DT","END_EXP_DT","MD5_HASH","PARTITION_VAL", surrogateID, Key_col] 
  
  #print(surrogateID, exclude_cols)

  detail_table  = f"{curatedDB}.{target}"
  transpose_xref = "transpose_xref" 
  #print(detail_table, transpose_xref)
  query = f"""SELECT DISTINCT TRIM(UPPER(TRANSPOSE_ALIAS)) as col_name FROM  {harmonizedDB}.{transpose_xref} WHERE   trim(CVRBL_TYPE_CD) = '{cvrbl_type}' AND lower(LOB) = lower('{lob}') AND lower(TARGET) = lower('{target}') """
  print(query)
  df_xref= spark.sql(query).rdd.flatMap(lambda x:x).collect()

  df_detail= spark.sql(f"""SHOW COLUMNS IN {detail_table}""").withColumn("col_name_Upper", upper("col_name")).select( col("col_name_Upper") ).rdd.flatMap(lambda x:x).collect()
 
  NullExpr = " null AS "

  df_nullcol = list(set(df_detail) - set(df_xref) - set(exclude_cols))
  NVL_expr ="NVL( "
  cols_null =" "
  entity_cols =" "
  entity_cols_nvl =" "
  entity_cols_pivot =" "
  entity_cols_select =" "
  for null_col in df_nullcol :
    cols_null = cols_null + NullExpr +  (null_col) + ",  "
  
  
  for xref_col in df_xref :
    entity_cols_nvl = entity_cols_nvl + NVL_expr + xref_col + ", null)  AS " +  xref_col  + ",  "
    entity_cols_pivot = entity_cols_pivot + "'" + xref_col +   "'" + ",  "
    entity_cols_select = entity_cols_select   + xref_col + ",  "
  
  
  entity_cols_pivot_new = entity_cols_pivot.strip()[:-1]

  harmz_query = f""" WITH  GET_BATCH_DELTA_AT_PIVOT_LVL AS
( SELECT DISTINCT
          TERM.CVRBL_KEY AS {Key_col},
           TERM.ETL_ROW_EFF_DTS,
           POL_EFF_DT,
           POL_EXP_DT,
           TERM.POL_KEY
      FROM {harmonizedDB}.DS_COVG_TERM  TERM
       JOIN  global_temp.{incr_covg_term_view} incr  ON incr.POL_KEY = TERM.POL_KEY  
       JOIN  {harmonizedDB}.ds_policy_skny_r5 POL
       -- JOIN  {harmonizedDB}.ds_policy POL        
        -- JOIN dhf_clpc_harmonize_tin_ddit1.ds_policy POL 
        ON      TERM.POL_KEY = POL.POL_KEY  AND  TERM.ETL_ROW_EFF_DTS >= POL.ETL_ROW_EFF_DTS AND  TERM.ETL_ROW_EFF_DTS < POL.ETL_ROW_EXP_DTS
        AND TERM.END_EFF_DT >=POL.POL_EFF_DT AND TERM.END_EFF_DT < POL.POL_EXP_DT
        AND  TERM.CVRBL_TYPE_CD = '{cvrbl_type}'
        AND TERM.SOURCE_SYSTEM = '{source_system}'
        AND TERM.LOB_CD = '{lob}' 
        AND TERM.QT_DELETE_IND ='N'
        
)
, STG_COVG_TERM AS  
( SELECT CT.COVG_TERM_KEY,
           CT.CVRBL_KEY AS {Key_col}  ,
           GBD.POL_EFF_DT,
           GBD.POL_EXP_DT,
           CT.END_EFF_DT,
           CT.END_EXP_DT,
           CT.COVG_TERM_CD,
           CT.TERM_VAL_CD,
           GBD.ETL_ROW_EFF_DTS,
           CT.LOB_CD,CT.SOURCE_SYSTEM,CT.CVRBL_TYPE_CD,
           ( CT.SOURCE_SYSTEM||'-'||CT.LOB_CD||'-'||CT.CVRBL_TYPE_CD) AS  PARTITION_VAL , CT.POL_KEY
      FROM GET_BATCH_DELTA_AT_PIVOT_LVL GBD
     INNER
      JOIN {harmonizedDB}.DS_COVG_TERM  CT
        ON GBD.{Key_col} = CT.CVRBL_KEY
        AND CT.END_EFF_DT>=GBD.POL_EFF_DT
        AND CT.END_EFF_DT < GBD.POL_EXP_DT
        AND GBD.ETL_ROW_EFF_DTS>=CT.ETL_ROW_EFF_DTS
        AND GBD.ETL_ROW_EFF_DTS <CT.ETL_ROW_EXP_DTS
        AND CT.QT_DELETE_IND ='N'
   
 
)
 ,TMP_DI_COVGTERMP_CDC2 AS (
          SELECT
            {Key_col}
           ,POL_EFF_DT
           ,POL_EXP_DT
           ,ETL_ROW_EFF_DTS
           ,END_EFF_DT, LOB_CD ,  SOURCE_SYSTEM ,CVRBL_TYPE_CD,PARTITION_VAL,  POL_KEY
           ,DENSE_RANK() OVER (PARTITION BY {Key_col}, ETL_ROW_EFF_DTS ORDER BY END_EFF_DT) AS Rank
  
          FROM (
           
           SELECT DISTINCT
             t1.{Key_col}           
            ,t2.POL_EFF_DT
            ,t2.POL_EXP_DT
            ,t1.ETL_ROW_EFF_DTS
            ,TO_DATE(t1.END_EFF_DT) AS END_EFF_DT , LOB_CD ,  SOURCE_SYSTEM , CVRBL_TYPE_CD ,PARTITION_VAL , POL_KEY
           FROM STG_COVG_TERM t1
           JOIN (SELECT DISTINCT  BP.{Key_col} --, BP.POL_KEY 
                   ,BP.POL_EFF_DT  ,BP.POL_EXP_DT   ,BP.ETL_ROW_EFF_DTS   
                   FROM STG_COVG_TERM BP  
           ) t2 ON t1.{Key_col} = t2.{Key_col}
            AND t1.ETL_ROW_EFF_DTS = t2.ETL_ROW_EFF_DTS  
            
           UNION
          
           SELECT DISTINCT
             t1.{Key_col}
            ,t2.POL_EFF_DT
            ,t2.POL_EXP_DT
            ,t1.ETL_ROW_EFF_DTS
            ,TO_DATE(t1.END_EXP_DT) AS END_EFF_DT , LOB_CD ,  SOURCE_SYSTEM ,CVRBL_TYPE_CD,PARTITION_VAL ,POL_KEY
           FROM STG_COVG_TERM t1
           JOIN (SELECT DISTINCT  BP.{Key_col} -- ,BP.POL_KEY
                 , BP.POL_EFF_DT ,BP.POL_EXP_DT ,BP.ETL_ROW_EFF_DTS   
           FROM STG_COVG_TERM BP  
           ) t2 ON t1.{Key_col} = t2.{Key_col}
            AND t1.ETL_ROW_EFF_DTS = t2.ETL_ROW_EFF_DTS
           where t1.END_EXP_DT < t2.POL_EXP_DT 
          )  T
)
 , SELF_JOIN_RANK AS 
 (
  SELECT 
        T1.{Key_col}
        --,T1.POL_KEY
        ,T1.ETL_ROW_EFF_DTS
       ,T1.END_EFF_DT
        ,COALESCE(T2.END_EFF_DT,T1.POL_EXP_DT) AS END_EXP_DT, T1.LOB_CD ,  T1.SOURCE_SYSTEM ,T1.CVRBL_TYPE_CD, T1.PARTITION_VAL , T1.POL_KEY
       FROM TMP_DI_COVGTERMP_CDC2 T1
       LEFT JOIN TMP_DI_COVGTERMP_CDC2 T2 ON T1.{Key_col} = T2.{Key_col}
         AND T1.ETL_ROW_EFF_DTS = T2.ETL_ROW_EFF_DTS
         AND T1.Rank = T2.Rank - 1
) 
 
, RANKED_TRF_COVG_TERM_REJOINED AS
(
      SELECT DISTINCT
        T2.{Key_col}
      --  ,T2.POL_KEY
       ,T2.ETL_ROW_EFF_DTS
       ,T1.END_EFF_DT
       ,T1.END_EXP_DT
       --,T2.SOURCE_SYSTEM
      -- ,T2.COVG_TERM_CD
       ,T2.TERM_VAL_CD AS VAL
       ,UPPER(TRIM(XREF.TRANSPOSE_ALIAS)) AS TRANSPOSE_ALIAS ,T1.LOB_CD ,  T1.SOURCE_SYSTEM ,T1.CVRBL_TYPE_CD,T1.PARTITION_VAL,T1.POL_KEY
             
      FROM SELF_JOIN_RANK T1
       JOIN STG_COVG_TERM T2 ON T1.{Key_col} = T2.{Key_col}
        AND T1.ETL_ROW_EFF_DTS = T2.ETL_ROW_EFF_DTS
        AND TO_DATE(T1.END_EFF_DT) >= TO_DATE(T2.END_EFF_DT)
        AND TO_DATE(T1.END_EFF_DT) < TO_DATE(T2.END_EXP_DT)
        LEFT JOIN {harmonizedDB}.transpose_xref XREF
        ON T2.covg_term_cd = XREF.input_cd
        
      ORDER BY T2.{Key_col}, T2.ETL_ROW_EFF_DTS, T1.END_EFF_DT asc
      )
 , FINAL_PIVOT_RESULT  AS (
select  
{Key_col},
{entity_cols_nvl}
{cols_null}
CVRBL_TYPE_CD,END_EFF_DT,END_EXP_DT,ETL_ROW_EFF_DTS,LOB_CD , SOURCE_SYSTEM ,PARTITION_VAL,POL_KEY
 
FROM RANKED_TRF_COVG_TERM_REJOINED   X
PIVOT (MAX(VAL) FOR TRANSPOSE_ALIAS IN (
{entity_cols_pivot_new}
 ))
  
)      
select * from FINAL_PIVOT_RESULT
 """


  return harmz_query


# COMMAND ----------

def build_ans_detail(harmonizedDB, curatedDB, target, cvrbl_type, lob, source_system, incr_ans_detail_view):
  ## surrgogate_id creation
  surrogateID= (target[3:]+"_ID").upper()
  exclude_cols = ["LINE_CVRBL_KEY","POL_KEY","CVRBL_TYPE_CD","LOB_CD","SOURCE_SYSTEM","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS","END_EFF_DT","END_EXP_DT","MD5_HASH","PARTITION_VAL", surrogateID] 
  
  #print(surrogateID, exclude_cols)

  detail_table  = f"{curatedDB}.{target}"
  transpose_xref = "transpose_xref" 
  #print(detail_table, transpose_xref)
  query = f"""SELECT DISTINCT UPPER(TRANSPOSE_ALIAS) as col_name FROM  {harmonizedDB}.{transpose_xref} WHERE   lower(trim(CVRBL_TYPE_CD)) = lower('{cvrbl_type}') AND lower(LOB) = lower('{lob}') AND lower(TARGET) = lower('{target}') """
  print(query)
  df_xref= spark.sql(query).rdd.flatMap(lambda x:x).collect()

  df_detail= spark.sql(f"""SHOW COLUMNS IN {detail_table}""").withColumn("col_name_Upper", upper("col_name")).select( col("col_name_Upper") ).rdd.flatMap(lambda x:x).collect()
 
  NullExpr = " null AS "

  df_nullcol = list(set(df_detail) - set(df_xref) - set(exclude_cols))

  NVL_expr ="NVL( "
  cols_null =" "
  entity_cols =" "
  entity_cols_nvl =" "
  entity_cols_pivot =" "
  entity_cols_select =" "
  for null_col in df_nullcol :
    cols_null = cols_null + NullExpr +  (null_col) + ",  "
    
  for xref_col in df_xref :
    entity_cols_nvl = entity_cols_nvl + NVL_expr + xref_col + ", null)  AS " +  xref_col  + ",  "
    entity_cols_pivot = entity_cols_pivot + "'" + xref_col +   "'" + ",  "
    entity_cols_select = entity_cols_select   + xref_col + ",  "
  
  
  entity_cols_pivot_new = entity_cols_pivot.strip()[:-1]


  harmz_query = f""" 
  WITH  GET_BATCH_DELTA_AT_PIVOT_LVL AS
( SELECT DISTINCT
           ANS.CVRBL_KEY ,
           ANS.ETL_ROW_EFF_DTS,
           POL_EFF_DT,
           POL_EXP_DT
      FROM {harmonizedDB}.DS_POL_ANS ANS 
       JOIN  global_temp.{incr_ans_detail_view} incr  ON incr.POL_KEY = ANS.POL_KEY                 
       JOIN  {harmonizedDB}.ds_policy_skny_r5 POL
       --JOIN  {harmonizedDB}.ds_policy POL
        ON   ANS.POL_KEY = POL.POL_KEY  AND  ANS.ETL_ROW_EFF_DTS >= POL.ETL_ROW_EFF_DTS AND  ANS.ETL_ROW_EFF_DTS < POL.ETL_ROW_EXP_DTS
        AND ANS.END_EFF_DT >=POL.POL_EFF_DT AND ANS.END_EFF_DT < POL.POL_EXP_DT
        AND ANS.QT_DELETE_IND ='N'
           AND  ANS.CVRBL_TYPE_CD = '{cvrbl_type}'
           AND ANS.SOURCE_SYSTEM = '{source_system}'
           AND ANS.LOB_CD = '{lob}'
          
         
)
,TMP_STG_ANS AS 
(
SELECT 
  POL_ANS.POL_KEY,
  POL_ANS.POL_LINE_KEY,
  POL_ANS.CVRBL_KEY,
  POL_ANS.CVRBL_TYPE_CD,
  POL_ANS.BOOLEAN_ANS,
  POL_ANS.DT_ANS,
  POL_ANS.INTEGER_ANS,
  POL_ANS.QSTN_CD,
  POL_ANS.TEXT_ANS,
  POL_ANS.CHOICE_ANS_CD,
  POL_ANS.END_EFF_DT,
  POL_ANS.END_EXP_DT,
  POL_ANS.SOURCE_SYSTEM,
  POL_ANS.ETL_ROW_EFF_DTS,
  POL_EFF_DT,
  POL_EXP_DT ,  POL_ANS.LOB_CD,( POL_ANS.SOURCE_SYSTEM||'-'||POL_ANS.LOB_CD||'-'||POL_ANS.CVRBL_TYPE_CD) AS  PARTITION_VAL
  FROM GET_BATCH_DELTA_AT_PIVOT_LVL GBD
  INNER JOIN {harmonizedDB}.DS_POL_ANS POL_ANS
        ON GBD.CVRBL_KEY = POL_ANS.CVRBL_KEY
        AND POL_ANS.END_EFF_DT>=GBD.POL_EFF_DT
        AND POL_ANS.END_EFF_DT < GBD.POL_EXP_DT
        AND GBD.ETL_ROW_EFF_DTS>=POL_ANS.ETL_ROW_EFF_DTS
        AND GBD.ETL_ROW_EFF_DTS <POL_ANS.ETL_ROW_EXP_DTS
       AND POL_ANS.QT_DELETE_IND ='N'
)
, TMP_DI_IMPOLANS_CDC2
     AS (SELECT  CVRBL_KEY  ,
                POL_KEY,
                POL_EFF_DT,
                POL_EXP_DT,
                ETL_ROW_EFF_DTS,
                END_EFF_DT,
                DENSE_RANK () OVER (PARTITION BY  CVRBL_KEY, ETL_ROW_EFF_DTS ORDER BY END_EFF_DT) AS RANK
           FROM (SELECT DISTINCT t1.CVRBL_KEY,
                                 t1.POL_KEY,
                                 t2.POL_EFF_DT,
                                 t2.POL_EXP_DT,
                                 t1.ETL_ROW_EFF_DTS,
                                 TO_DATE (t1.END_EFF_DT) AS END_EFF_DT ,   LOB_CD ,  SOURCE_SYSTEM , PARTITION_VAL
                   FROM TMP_STG_ANS t1
                   JOIN (SELECT DISTINCT polans.CVRBL_KEY,
                                         polans.POL_KEY,
                                         polans.POL_EFF_DT,
                                         polans.POL_EXP_DT,
                                         polans.ETL_ROW_EFF_DTS
                          FROM TMP_STG_ANS polans
                         ) t2 ON t1.CVRBL_KEY = t2.CVRBL_KEY
                           AND t1.ETL_ROW_EFF_DTS = t2.ETL_ROW_EFF_DTS
                              
                 UNION
                 SELECT DISTINCT t1.CVRBL_KEY,
                                 t1.POL_KEY,
                                 t2.POL_EFF_DT,
                                 t2.POL_EXP_DT,
                                 t1.ETL_ROW_EFF_DTS,
                                 TO_DATE (t1.END_EXP_DT) AS END_EFF_DT ,   LOB_CD ,  SOURCE_SYSTEM , PARTITION_VAL
                   FROM TMP_STG_ANS t1
                   JOIN (SELECT DISTINCT polans.CVRBL_KEY,
                                              polans.POL_KEY,
                                              polans.POL_EFF_DT,
                                              polans.POL_EXP_DT,
                                              polans.ETL_ROW_EFF_DTS
                                FROM TMP_STG_ANS polans
                             ) t2
                     ON t1.CVRBL_KEY = t2.CVRBL_KEY
                     AND t1.ETL_ROW_EFF_DTS = t2.ETL_ROW_EFF_DTS
                     WHERE t1.END_EXP_DT < t2.POL_EXP_DT) T)
 
, SELF_JOIN_RANK AS 
 (SELECT T1.CVRBL_KEY,
         T1.POL_KEY,
         T1.ETL_ROW_EFF_DTS,
         T1.END_EFF_DT,
         TO_DATE (COALESCE (T2.END_EFF_DT, T1.POL_EXP_DT)) AS END_EXP_DT
   FROM TMP_DI_IMPOLANS_CDC2 T1
   LEFT JOIN TMP_DI_IMPOLANS_CDC2 T2
   ON  T1.CVRBL_KEY = T2.CVRBL_KEY
   AND T1.ETL_ROW_EFF_DTS = T2.ETL_ROW_EFF_DTS
   AND T1.RANK = T2.RANK - 1)
 
, RANKED_TRF_ANS_REJOINED
     AS (  SELECT DISTINCT T2.CVRBL_KEY  ,
                           T2.SOURCE_SYSTEM,
                           T2.POL_KEY,
                           T2.POL_LINE_KEY,
                           T2.ETL_ROW_EFF_DTS,
                           T1.END_EFF_DT,
                           T1.END_EXP_DT,
                           T2.QSTN_CD,
                           T2.CVRBL_TYPE_CD,
                           T2.BOOLEAN_ANS,
                           T2.DT_ANS,
                           T2.INTEGER_ANS,
                           t2.text_ans,
                           t2.CHOICE_ANS_CD ,
                           XREF.TRANSPOSE_ALIAS  ,    LOB_CD  , PARTITION_VAL
             FROM SELF_JOIN_RANK T1
                  JOIN TMP_STG_ANS T2
                     ON     T1.CVRBL_KEY = T2.CVRBL_KEY
                        AND T1.ETL_ROW_EFF_DTS = T2.ETL_ROW_EFF_DTS
                        AND TO_DATE (T1.END_EFF_DT) >= TO_DATE (T2.END_EFF_DT)
                        AND TO_DATE (T1.END_EFF_DT) < TO_DATE (T2.END_EXP_DT)
                      LEFT JOIN {harmonizedDB}.transpose_xref XREF 
                      ON T2.QSTN_CD = XREF.input_cd
         ORDER BY T2.CVRBL_KEY, T2.ETL_ROW_EFF_DTS, T1.END_EFF_DT ASC)
   
   
 , RANKED_TRF_ANS_REJOINED_UNION  
   AS (
    select AnsUnion.POL_KEY ,AnsUnion.CVRBL_TYPE_CD,
    AnsUnion.POL_LINE_KEY, AnsUnion.CVRBL_KEY AS LINE_CVRBL_KEY, AnsUnion.ETL_ROW_EFF_DTS, AnsUnion.END_EFF_DT,AnsUnion.END_EXP_DT,AnsUnion.SOURCE_SYSTEM,AnsUnion.TRANSPOSE_ALIAS, ANSWER ,LOB_CD , PARTITION_VAL
    from (
            select POL_KEY,CVRBL_TYPE_CD,
            POL_LINE_KEY, CVRBL_KEY, ETL_ROW_EFF_DTS, END_EFF_DT,END_EXP_DT,SOURCE_SYSTEM,QSTN_CD,TRANSPOSE_ALIAS,BOOLEAN_ANS as ANSWER,    LOB_CD , PARTITION_VAL
            from RANKED_TRF_ANS_REJOINED
            
            union all
            
            select POL_KEY,CVRBL_TYPE_CD,
            POL_LINE_KEY, CVRBL_KEY, ETL_ROW_EFF_DTS, END_EFF_DT,END_EXP_DT,SOURCE_SYSTEM,QSTN_CD,TRANSPOSE_ALIAS,
            case when cast(INTEGER_ANS as varchar(255)) = 0 then ' ' else cast(INTEGER_ANS as varchar(255)) end  as ANSWER,    LOB_CD , PARTITION_VAL
            from RANKED_TRF_ANS_REJOINED
            
            union all
             
            select POL_KEY,CVRBL_TYPE_CD,
            POL_LINE_KEY, CVRBL_KEY, ETL_ROW_EFF_DTS, END_EFF_DT,END_EXP_DT,SOURCE_SYSTEM,QSTN_CD,TRANSPOSE_ALIAS,
            case when cast(to_date(DT_ANS) as varchar(255)) = '9999-12-31' then ' ' else cast(to_date(DT_ANS) as varchar(255)) END as ANSWER,    LOB_CD , PARTITION_VAL
            from RANKED_TRF_ANS_REJOINED
            
            union all
             
            select POL_KEY,CVRBL_TYPE_CD,
            POL_LINE_KEY, CVRBL_KEY, ETL_ROW_EFF_DTS, END_EFF_DT,END_EXP_DT,SOURCE_SYSTEM,QSTN_CD,TRANSPOSE_ALIAS,cast(TEXT_ANS as varchar(255)) as ANSWER,    LOB_CD , PARTITION_VAL
            from RANKED_TRF_ANS_REJOINED
            
            union all
             
            select POL_KEY,CVRBL_TYPE_CD,
            POL_LINE_KEY, CVRBL_KEY, ETL_ROW_EFF_DTS, END_EFF_DT,END_EXP_DT,SOURCE_SYSTEM,QSTN_CD,TRANSPOSE_ALIAS,cast(CHOICE_ANS_CD as varchar(255)) as ANSWER,    LOB_CD , PARTITION_VAL
            from RANKED_TRF_ANS_REJOINED 
           
        )AnsUnion
  group by AnsUnion.POL_KEY,AnsUnion.CVRBL_TYPE_CD,
  AnsUnion.POL_LINE_KEY, AnsUnion.CVRBL_KEY, AnsUnion.ETL_ROW_EFF_DTS, AnsUnion.END_EFF_DT,AnsUnion.END_EXP_DT,AnsUnion.SOURCE_SYSTEM,AnsUnion.QSTN_CD, AnsUnion.ANSWER , AnsUnion.TRANSPOSE_ALIAS , AnsUnion.LOB_CD , AnsUnion.PARTITION_VAL
    ) 
    
 , FINAL_PIVOT_RESULT  AS (
select  
LINE_CVRBL_KEY,
{entity_cols_nvl}
{cols_null}
POL_KEY,CVRBL_TYPE_CD,END_EFF_DT,END_EXP_DT,ETL_ROW_EFF_DTS,LOB_CD , SOURCE_SYSTEM ,PARTITION_VAL
 
FROM RANKED_TRF_ANS_REJOINED_UNION   X
PIVOT (MAX(ANSWER) FOR TRANSPOSE_ALIAS IN (
{entity_cols_pivot_new}
 ))
  
)      
select * from FINAL_PIVOT_RESULT
  
  """
 
  return harmz_query
  

# COMMAND ----------

def build_addnl_intrst(micro_batch_view,rawDB,harmonizedDB,im_lob_cd,cop_lob_cd,source_system):
  harmz_query = f""" With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.{micro_batch_view}),pc_addlinterestdetail_micro_batch as (select distinct branchid,updatetime from global_temp.{micro_batch_view})
,v_pc_addlinterestdetail as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pc_addlinterestdetail.*
			from {rawDB}.pc_addlinterestdetail   pc_addlinterestdetail      
            inner join pc_addlinterestdetail_micro_batch   mb  
			   on mb.branchid = pc_addlinterestdetail.branchid 
			where pc_addlinterestdetail.updatetime <= mb.updatetime  
			)
		) where rn = 1)   
,v_pctl_job as
(
select * from
(select *,row_number() over (partition by Id order by z_meta_event_timestamp   desc) as rn
from {rawDB}.pctl_job jbt
Cross Join Events_Max_Updatetime mb
On jbt.z_meta_event_timestamp  <= mb.mb_max_updatetime
) where rn=1
)

/****,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,ADDLINTRST.publicid as pc_addlinterestdetail_publicid,ADDLINTRST.updatetime as pc_addlinterestdetail_updatetime,
      row_number() over (partition by ADDLINTRST.publicid,ADDLINTRST.updatetime,ADDLINTRST.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(ADDLINTRST.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_addlinterestdetail  ADDLINTRST
      JOIN {rawDB}.pc_policyperiod  polper 
        on ADDLINTRST.BranchID = polper.ID 
        and polper.updatetime <= ADDLINTRST.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,ADDLINTRST.publicid as pc_addlinterestdetail_publicid,ADDLINTRST.updatetime as pc_addlinterestdetail_updatetime,
      row_number() over (partition by ADDLINTRST.publicid,polper.updatetime,ADDLINTRST.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(ADDLINTRST.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_addlinterestdetail ADDLINTRST
      JOIN {rawDB}.pc_policyperiod  polper 
        on ADDLINTRST.BranchID = polper.ID 
        and ADDLINTRST.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)***/

      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            polper.PolicyNumber,
            polper.editeffectivedate,
            polper.basestate,            
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as pc_addlinterestdetail_publicid,
            p.updatetime as pc_addlinterestdetail_updatetime
          from
            v_pc_addlinterestdetail  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp   desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp  <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
COALESCE(UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound'THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || CAST(CAST (ADDLINTRST.FixedID AS INTEGER)AS VARCHAR (255))),'NOKEY') AS ADDL_INTRST_KEY,
COALESCE(UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END),'NOKEY') AS POL_KEY,
COALESCE(CASE WHEN ADDLINTRST.IMGBLDRSRISKBLDG IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGBldrsRiskBldg' || '-' || CAST (CAST(ADDLINTRST.IMGBLDRSRISKBLDG AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGACCOUNTSREC_EXTID IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGAccountsRec' || '-' || CAST (CAST(ADDLINTRST.IMGACCOUNTSREC_EXTID  AS INTEGER)AS VARCHAR (255)))
WHEN ADDLINTRST.IMGCONTRSADV_EXTID IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGContrsAdv' || '-' || CAST (CAST(ADDLINTRST.IMGCONTRSADV_EXTID AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGCONTRSEQP IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGContrsEqp' || '-' || CAST(CAST(ADDLINTRST.IMGCONTRSEQP AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGDRYCLEANER IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGDryCleaner' || '-' || CAST(CAST (ADDLINTRST.IMGDRYCLEANER AS INTEGER)AS VARCHAR (255)))
WHEN ADDLINTRST.IMGELECDATAPRBLD IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGElecDataProcBldg'|| '-' || CAST(CAST (ADDLINTRST.IMGELECDATAPRBLD AS INTEGER)AS VARCHAR (255)))
WHEN ADDLINTRST.IMGEQPSLRNTBLD IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGEqupSaleRentBldg'|| '-' || CAST(CAST (ADDLINTRST.IMGEQPSLRNTBLD AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGFARMIRRGEUIP IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGFarmIrrgEqp'|| '-' || CAST(CAST (ADDLINTRST.IMGFARMIRRGEUIP AS INTEGER)AS VARCHAR (255)))
WHEN ADDLINTRST.IMGFARMMACHBLK IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGFarmMach'|| '-' || CAST(CAST (ADDLINTRST.IMGFARMMACHBLK AS INTEGER)AS VARCHAR (255))) 
WHEN ADDLINTRST.IMGFARMMACHSCH IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGFarmMachSched'|| '-' || CAST(CAST (ADDLINTRST.IMGFARMMACHSCH AS INTEGER)AS VARCHAR (255)))
WHEN ADDLINTRST.IMGFINEARTSDLR_EXTID IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGFineArtsDlr'|| '-' || CAST(CAST (ADDLINTRST.IMGFINEARTSDLR_EXTID AS INTEGER)AS VARCHAR (255))) 
WHEN ADDLINTRST.IMGINSTFLTRBLDG IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGInstlFltrBldg'|| '-' || CAST (CAST(ADDLINTRST.IMGINSTFLTRBLDG AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGINSTLFLTR IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGInstlFltr'|| '-' || CAST(CAST (ADDLINTRST.IMGINSTLFLTR AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGLIVESTOCK_EXTID IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGLivestock'|| '-' || CAST(CAST (ADDLINTRST.IMGLIVESTOCK_EXTID AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGMOTORCARGO IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGMotorCargo'|| '-' || CAST(CAST (ADDLINTRST.IMGMOTORCARGO AS INTEGER)AS VARCHAR (255)))
WHEN ADDLINTRST.IMGRIGGER IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGRigger'|| '-' || CAST(CAST (ADDLINTRST.IMGRIGGER AS INTEGER)AS VARCHAR (255)))                 
WHEN ADDLINTRST.IMGTOWEREQP IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGTowerEqp'|| '-' || CAST(CAST (ADDLINTRST.IMGTOWEREQP AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGTRANSIT IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGTransit'|| '-' || CAST(CAST (ADDLINTRST.IMGTRANSIT AS INTEGER) AS VARCHAR (255)))                  
WHEN ADDLINTRST.IMGVALPAPER IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGValuablePaper'|| '-' || CAST(CAST (ADDLINTRST.IMGVALPAPER AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGFINEARTSFLTR IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGFineArtsFltr'|| '-' || CAST(CAST (ADDLINTRST.IMGFINEARTSFLTR AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGMISCFLTR IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGMiscFltr'|| '-' || CAST(CAST (ADDLINTRST.IMGMISCFLTR AS INTEGER) AS VARCHAR (255)))                 
WHEN ADDLINTRST.IMGSCHEDPROPFLTR IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGSchedPropFltr'|| '-' || CAST(CAST (ADDLINTRST.IMGSCHEDPROPFLTR AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGSIGN IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGSign'|| '-' || CAST(CAST (ADDLINTRST.IMGSIGN AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGYNGSTKRAISER IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGYngStkRisr'|| '-' || CAST(CAST (ADDLINTRST.IMGYNGSTKRAISER AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGWAREHOUSE IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGWarehouse' || '-' || CAST(CAST (ADDLINTRST.IMGWAREHOUSE AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.IMGDRYCLNRPRBLDG IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGDryClnrPrgmBldg' || '-' || CAST(CAST (ADDLINTRST.IMGDRYCLNRPRBLDG AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.COPLINE IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'COPLine' || '-' || CAST (CAST(ADDLINTRST.COPLINE AS INTEGER) AS VARCHAR (255)))
WHEN ADDLINTRST.COPBUILDING IS NOT NULL THEN UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'COPBuilding' || '-' || CAST (CAST(ADDLINTRST.COPBUILDING AS INTEGER) AS VARCHAR (255))) END,'NOKEY') AS CVRBL_KEY,
COALESCE(UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || CAST(CAST(ADDLINTRST.PolicyAddlInterest AS INTEGER) AS VARCHAR (255))),'NOKEY') AS POL_PARTY_KEY,
'NOKEY' AS LINE_POL_PARTY_KEY,
CAST ( COALESCE (ADDLINTRST.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST ( COALESCE (ADDLINTRST.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN ADDLINTRST.IMGYNGSTKRAISER IS NOT NULL  THEN 'IMGYngStkRisr'
WHEN ADDLINTRST.IMGSIGN IS NOT NULL THEN 'IMGSign'
WHEN ADDLINTRST.IMGSCHEDPROPFLTR IS NOT NULL THEN 'IMGSchedPropFltr'
WHEN ADDLINTRST.IMGMISCFLTR IS NOT NULL THEN 'IMGMiscFltr'
WHEN ADDLINTRST.IMGFINEARTSFLTR IS NOT NULL THEN 'IMGFineArtsFltr'
WHEN ADDLINTRST.IMGVALPAPER IS NOT NULL THEN 'IMGValuablePaper'
WHEN ADDLINTRST.IMGTRANSIT IS NOT NULL THEN 'IMGTransit'
WHEN ADDLINTRST.IMGTOWEREQP IS NOT NULL THEN 'IMGTowerEqp'
WHEN ADDLINTRST.IMGRIGGER IS NOT NULL THEN 'IMGRigger'
WHEN ADDLINTRST.IMGMOTORCARGO IS NOT NULL THEN 'IMGMotorCargo'
WHEN ADDLINTRST.IMGLIVESTOCK_EXTID IS NOT NULL THEN 'IMGLivestock'
WHEN ADDLINTRST.IMGINSTLFLTR IS NOT NULL THEN 'IMGInstlFltr'
WHEN ADDLINTRST.IMGINSTFLTRBLDG IS NOT NULL THEN 'IMGInstlFltrBldg'
WHEN ADDLINTRST.IMGFINEARTSDLR_EXTID IS NOT NULL THEN 'IMGFineArtsDlr'
WHEN ADDLINTRST.IMGFARMMACHSCH IS NOT NULL THEN 'IMGFarmMachSched'
WHEN ADDLINTRST.IMGFARMMACHBLK IS NOT NULL THEN 'IMGFarmMach'
WHEN ADDLINTRST.IMGFARMIRRGEUIP IS NOT NULL THEN 'IMGFarmIrrgEqp'
WHEN ADDLINTRST.IMGEQPSLRNTBLD IS NOT NULL THEN 'IMGEqupSaleRentBldg'
WHEN ADDLINTRST.IMGELECDATAPRBLD IS NOT NULL THEN 'IMGElecDataProc'
WHEN ADDLINTRST.IMGDRYCLEANER IS NOT NULL THEN 'IMGDryCleaner'
WHEN ADDLINTRST.IMGCONTRSEQP IS NOT NULL THEN 'IMGContrsEqp'
WHEN ADDLINTRST.IMGCONTRSADV_EXTID IS NOT NULL THEN 'IMGContrsAdv'
WHEN ADDLINTRST.IMGACCOUNTSREC_EXTID IS NOT NULL THEN 'IMGAccountsRec'
WHEN ADDLINTRST.IMGBLDRSRISKBLDG IS NOT NULL THEN 'IMGBldrsRiskBldg'
WHEN ADDLINTRST.IMGWAREHOUSE IS NOT NULL THEN 'IMGWarehouse'
WHEN ADDLINTRST.IMGDRYCLNRPRBLDG IS NOT NULL THEN 'IMGDryClnrPrgmBldg'
WHEN ADDLINTRST.COPLINE IS NOT NULL  THEN 'COPLine'
WHEN ADDLINTRST.COPBUILDING IS NOT NULL THEN 'COPBuilding' END,' ') AS CVRBL_TYPE_CD,
COALESCE(ADDLINTRST_TYPE.TYPECODE,' ') AS ADDL_INTRST_TYPE_CD,
COALESCE(ADDLINTRST_TYPE.NAME,'Not Defined') AS ADDL_INTRST_TYPE_TEXT,
COALESCE(ADDLINTRST.ContractNumber,' ') AS CONTRACT_NO,
CASE when subtype.TYPECODE like ('IM%') then '{im_lob_cd}'
when subtype.TYPECODE like ('COP%') then '{cop_lob_cd}' END AS LOB_CD,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS
,ADDLINTRST.branchid as SRC_BRANCHID
,ADDLINTRST.fixedid as SRC_FIXEDID
,ADDLINTRST.effectivedate as SRC_EFFECTIVEDATE
,ADDLINTRST.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,ADDLINTRST.createtime as SRC_CREATETIME
,ADDLINTRST.updatetime  as SRC_UPDATETIME
,ADDLINTRST.publicid as SRC_PUBLICID
,ADDLINTRST.updatetime as updatetime_tab1
,polper.updatetime as updatetime_tab2
,job.updatetime as updatetime_tab3
,CASE when subtype.TYPECODE like ('IM%') then '{source_system}-{im_lob_cd}'
when subtype.TYPECODE like ('COP%') then '{source_system}-{cop_lob_cd}' END AS PARTITION_VAL
,NULL AS ADTNL_INTRST_PRPRTY_DS
 
FROM 
v_pc_addlinterestdetail as ADDLINTRST
INNER JOIN v_pc_policyperiod polper
on ADDLINTRST.BranchID=polper.ID
and ADDLINTRST.publicid=polper.pc_addlinterestdetail_publicid
and ADDLINTRST.updatetime=polper.pc_addlinterestdetail_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
JOIN 
      (
		select * from
           (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_addlinterestdetail subtype
            Cross Join Events_Max_Updatetime mb  On subtype.z_meta_event_timestamp <= mb.mb_max_updatetime)
             where rn=1)
             subtype
               ON ADDLINTRST.Subtype = subtype.ID
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not (status.typecode = 'Bound' and job.closedate is null)
LEFT JOIN 
        (
		select * from
           (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_additionalinteresttype ADDLINTRST_TYPE
           Cross Join Events_Max_Updatetime mb  On ADDLINTRST_TYPE.z_meta_event_timestamp <= mb.mb_max_updatetime)
             where rn=1)
             ADDLINTRST_TYPE
ON ADDLINTRST.AdditionalInterestType = ADDLINTRST_TYPE.ID
WHERE COALESCE (ADDLINTRST.IMGYNGSTKRAISER,ADDLINTRST.IMGSIGN,ADDLINTRST.IMGSCHEDPROPFLTR,ADDLINTRST.IMGMISCFLTR,ADDLINTRST.IMGFINEARTSFLTR,ADDLINTRST.IMGVALPAPER,ADDLINTRST.IMGTRANSIT,ADDLINTRST.IMGTOWEREQP,ADDLINTRST.IMGRIGGER,ADDLINTRST.IMGMOTORCARGO,ADDLINTRST.IMGLIVESTOCK_EXTID,ADDLINTRST.IMGINSTLFLTR,ADDLINTRST.IMGINSTFLTRBLDG,ADDLINTRST.IMGFINEARTSDLR_EXTID,ADDLINTRST.IMGFARMMACHSCH,ADDLINTRST.IMGFARMMACHBLK,ADDLINTRST.IMGFARMIRRGEUIP,ADDLINTRST.IMGEQPSLRNTBLD,ADDLINTRST.IMGELECDATAPRBLD,ADDLINTRST.IMGDRYCLEANER,ADDLINTRST.IMGCONTRSEQP,ADDLINTRST.IMGCONTRSADV_EXTID,ADDLINTRST.IMGACCOUNTSREC_EXTID,ADDLINTRST.IMGBLDRSRISKBLDG,ADDLINTRST.IMGWAREHOUSE,ADDLINTRST.IMGDRYCLNRPRBLDG,ADDLINTRST.COPLINE,ADDLINTRST.COPBUILDING) > 0 AND (subtype.TYPECODE like ('IM%') or subtype.TYPECODE like ('COP%') ) AND (status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted')))
)
"""
  
  return harmz_query

# COMMAND ----------

def build_ds_spoil_dfncy(micro_batch_view,rawDB,cvrbl_type,lob_cd,source_system):
  harmz_query = f"""With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.{micro_batch_view}),
  pcx_copspoildeficiencypts_ext_micro_batch as (select distinct branchid,updatetime from global_temp.{micro_batch_view} )
,v_pcx_copspoildeficiencypts_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_copspoildeficiencypts_ext.*
			from {rawDB}.pcx_copspoildeficiencypts_ext          
            inner join pcx_copspoildeficiencypts_ext_micro_batch   mb  
			   on mb.branchid = pcx_copspoildeficiencypts_ext.branchid 
			where pcx_copspoildeficiencypts_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/****,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,COPSPOILDPTS.publicid as pcx_copspoildeficiencypts_ext_publicid,COPSPOILDPTS.updatetime as pcx_copspoildeficiencypts_ext_updatetime,
      row_number() over (partition by COPSPOILDPTS.publicid,COPSPOILDPTS.updatetime,COPSPOILDPTS.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(COPSPOILDPTS.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_copspoildeficiencypts_ext  COPSPOILDPTS
      JOIN {rawDB}.pc_policyperiod  polper 
        on COPSPOILDPTS.BranchID = polper.ID 
        and polper.updatetime <= COPSPOILDPTS.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,COPSPOILDPTS.publicid as pcx_copspoildeficiencypts_ext_publicid,COPSPOILDPTS.updatetime as pcx_copspoildeficiencypts_ext_updatetime,
      row_number() over (partition by COPSPOILDPTS.publicid,polper.updatetime,COPSPOILDPTS.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(COPSPOILDPTS.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_copspoildeficiencypts_ext COPSPOILDPTS
      JOIN {rawDB}.pc_policyperiod  polper 
        on COPSPOILDPTS.BranchID = polper.ID 
        and COPSPOILDPTS.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)***/



      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as pcx_copspoildeficiencypts_ext_publicid,
            p.updatetime as pcx_copspoildeficiencypts_ext_updatetime
          from
            v_pcx_copspoildeficiencypts_ext  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------

,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'||'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' ||'COPLine' || '-' || CAST(CAST (COPSPOILDPTS.FixedID AS INTEGER) AS VARCHAR (255))) AS SPOIL_DFNCY_KEY,
UPPER ('GWPC'|| '-' ||CAST( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
CAST ( COALESCE (COPSPOILDPTS.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (COPSPOILDPTS.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
  'COP' AS LOB_CD,
  '{source_system}-{lob_cd}-{cvrbl_type}' AS PARTITION_VAL,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
COPSPOILDPTS.ADDLLOSSINCOME AS ADDL_LOSS_INCOME ,
COALESCE(COPSPOILDPTS.ADDLLOSSINCOMENOTE,' ') AS ADDL_LOSS_INCOME_NOTE,
COPSPOILDPTS.CONDOFCOVEREDOBJECTS AS COV_OBJ_COND,
COALESCE(COPSPOILDPTS.CONDOFCOVOBJNOTE,' ') AS COV_OBJ_COND_NOTE ,
COPSPOILDPTS.DEDUCTIBLEAMT AS DED_AMT,
COALESCE(COPSPOILDPTS.DEDUCTIBLEAMTNOTE,' ') AS DED_AMT_NOTE,
COPSPOILDPTS.DISASTEREXPOSURE AS DISASTER_EXPSR,
COALESCE(COPSPOILDPTS.DISASTEREXPOSURENOTE,' ') AS DISASTER_EXPSR_NOTE,
COPSPOILDPTS.INCEXPOCOV AS INC_EXPSR_COVG ,
COALESCE(COPSPOILDPTS.INCEXPOCOVNOTE,' ') AS INC_EXPSR_COVG_NOTE,
COPSPOILDPTS.JURISINSPECTION AS JURS_INSP,
COALESCE(COPSPOILDPTS.JURISINSPECTIONNOTE,' ') AS JURS_INSP_NOTE ,
COPSPOILDPTS.MAINTAINOFCOVEREDOBJECT AS COV_OBJ_MAINT ,
COALESCE(COPSPOILDPTS.MAINTAINOFCOVOBJNOTE,' ') AS COV_OBJ_MAINT_NOTE,
COPSPOILDPTS.SPECINSARRANGE AS SPEC_INS_ARNGMT,
COPSPOILDPTS.SPECINSARRANGENOTE AS SPEC_INS_ARNGMT_NOTE ,
COPSPOILDPTS.SPOILAGEPREM AS SPOIL_PREM,
COPSPOILDPTS.SPOILAGERATE AS SPOIL_RATE ,
COPSPOILDPTS.SPOILDEFPTCHARGE AS SPOIL_DFNCY_POINT_CHRG ,
COPSPOILDPTS.TOTALDEFICIENCYPTS AS TOT_DFNCY_PTS ,
COPSPOILDPTS.TYPEOFCOVEREDOBJECTS AS COV_OBJ_TYPE,
COALESCE(COPSPOILDPTS.TypeOfCovObjNote,' ') AS COV_OBJ_TYPE_NOTE,
COALESCE(COPSPOILDPTS.UnderwritingNotes,' ') as UW_NOTE, 
COPSPOILDPTS.branchid as SRC_BRANCHID,
COPSPOILDPTS.fixedid as SRC_FIXEDID,
COPSPOILDPTS.effectivedate as SRC_EFFECTIVEDATE,
COPSPOILDPTS.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
COPSPOILDPTS.createtime as SRC_CREATETIME,
COPSPOILDPTS.updatetime  as SRC_UPDATETIME,
COPSPOILDPTS.publicid as SRC_PUBLICID,
COPSPOILDPTS.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_copspoildeficiencypts_ext as COPSPOILDPTS
INNER JOIN v_pc_policyperiod polper
on COPSPOILDPTS.BranchID=polper.ID
and COPSPOILDPTS.publicid=polper.pcx_copspoildeficiencypts_ext_publicid
and COPSPOILDPTS.updatetime=polper.pcx_copspoildeficiencypts_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)
"""
  return harmz_query

# COMMAND ----------

def build_ds_prpty_dfncy(micro_batch_view,rawDB,cvrbl_type,lob_cd,source_system):
  harmz_query = f""" With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.{micro_batch_view}),
  pcx_copperpdefpointstable_ext_micro_batch as (select distinct branchid,updatetime from global_temp.{micro_batch_view} )
,v_pcx_copperpdefpointstable_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_copperpdefpointstable_ext.*
			from {rawDB}.pcx_copperpdefpointstable_ext          
            inner join pcx_copperpdefpointstable_ext_micro_batch   mb  
			   on mb.branchid = pcx_copperpdefpointstable_ext.branchid 
			where pcx_copperpdefpointstable_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/****,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,COPPROPDEFPTS.publicid as pcx_copperpdefpointstable_ext_publicid,COPPROPDEFPTS.updatetime as pcx_copperpdefpointstable_ext_updatetime,
      row_number() over (partition by COPPROPDEFPTS.publicid,COPPROPDEFPTS.updatetime,COPPROPDEFPTS.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(COPPROPDEFPTS.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_copperpdefpointstable_ext  COPPROPDEFPTS
      JOIN {rawDB}.pc_policyperiod  polper 
        on COPPROPDEFPTS.BranchID = polper.ID 
        and polper.updatetime <= COPPROPDEFPTS.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,COPPROPDEFPTS.publicid as pcx_copperpdefpointstable_ext_publicid,COPPROPDEFPTS.updatetime as pcx_copperpdefpointstable_ext_updatetime,
      row_number() over (partition by COPPROPDEFPTS.publicid,polper.updatetime,COPPROPDEFPTS.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(COPPROPDEFPTS.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_copperpdefpointstable_ext COPPROPDEFPTS
      JOIN {rawDB}.pc_policyperiod  polper 
        on COPPROPDEFPTS.BranchID = polper.ID 
        and COPPROPDEFPTS.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)***/


      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as pcx_copperpdefpointstable_ext_publicid,
            p.updatetime as pcx_copperpdefpointstable_ext_updatetime
          from
            v_pcx_copperpdefpointstable_ext  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'||'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' ||'COPLine' || '-' || CAST(CAST (COPPROPDEFPTS.FixedID AS INTEGER) AS VARCHAR (255))) AS PRPTY_DFNCY_KEY,
UPPER ('GWPC'|| '-' ||CAST( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
CAST ( COALESCE (COPPROPDEFPTS.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (COPPROPDEFPTS.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
  'COP' AS LOB_CD,
  '{source_system}-{lob_cd}-{cvrbl_type}' AS PARTITION_VAL,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
COPPROPDEFPTS.ARRANGESPECINCOMEINS AS SPEC_INCM_INS_ARNGMT,
COALESCE(COPPROPDEFPTS.ARRANGESPECINCINSNOTE,' ') AS SPEC_INCM_INS_ARNGMT_NOTE,
COALESCE(COPPROPDEFPTS.ARRANGESPECINSNOTE,' ') AS SPEC_INS_ARNGMT_NOTE  ,
COPPROPDEFPTS.BLDGARRANGESPECINS AS  BLDG_SPEC_INS_ARNGMT ,
COPPROPDEFPTS.BLDGCLIMATICALHAZARDS AS BLDG_CLIMAT_HZRD  ,
COPPROPDEFPTS.BLDGCOMBUSTSUSCEPTBLTY AS BLDG_COMBUSTBLTY_SUSCEPT  ,
COPPROPDEFPTS.BLDGCONSTRUCTION AS BLDG_CONSTR  ,
COPPROPDEFPTS.BLDGDEFPTCHARGE AS BLDG_DFNCY_POINT_CHRG ,
COPPROPDEFPTS.BLDGDISASTEREXPOSURE AS BLDG_DISASTER_EXPSR  ,
COPPROPDEFPTS.BLDGEARTHMOVEMENT AS BLDG_EARTH_MVMNT  ,
COPPROPDEFPTS.BLDGEXTERNALEXPOSURE AS BLDG_XTRNL_EXPSR,
COPPROPDEFPTS.BLDGLOWERDEDUCTIBLE AS  BLDG_LOWR_DED,
COPPROPDEFPTS.BLDGPREM AS BLDG_PREM,
COPPROPDEFPTS.BLDGPRIVATEPROTECTION AS BLDG_PRVT_PROT,
COPPROPDEFPTS.BLDGPUBLICPROTECTION AS BLDG_PUB_PROT,
COPPROPDEFPTS.BLDGRATE AS BLDG_RATE,
COPPROPDEFPTS.BLDGSPLOCCHAZORPOLCOND AS BLDG_SPEC_OCCPCY_HZRD,
COPPROPDEFPTS.BLDGTOTALDEFICIENCYPTS AS BLDG_TOT_DFNCY_PTS,
COPPROPDEFPTS.BLDGWATERDAMAGE AS BLDG_WATER_DMG,
COPPROPDEFPTS.BPPARRANGESPECINS AS BPP_SPEC_INS_ARNGMT,
COPPROPDEFPTS.BPPCLIMATICALHAZARDS AS BPP_CLIMAT_HZRD,
COPPROPDEFPTS.BPPCOMBUSTSUSCEPTBLTY AS BPP_COMBUSTBLTY_SUSCEPT,
COPPROPDEFPTS.BPPCONSTRUCTION AS BPP_CONSTR,
COPPROPDEFPTS.BPPDEFPTCHARGE AS BPP_DFNCY_POINT_CHRG,
COPPROPDEFPTS.BPPDISASTEREXPOSURE AS BPP_DISASTER_EXPSR,
COPPROPDEFPTS.BPPEARTHMOVEMENT AS BPP_EARTH_MVMNT,
COPPROPDEFPTS.BPPEXTERNALEXPOSURE AS BPP_XTRNL_EXPSR,
COPPROPDEFPTS.BPPLOWERDEDUCTIBLE AS BPP_LOWR_DED,
COPPROPDEFPTS.BPPPREM AS BPP_PREM,
COPPROPDEFPTS.BPPPRIVATEPROTECTION AS BPP_PRVT_PROT,
COPPROPDEFPTS.BPPPUBLICPROTECTION AS   BPP_PUB_PROT,
COPPROPDEFPTS.BPPRATE AS BPP_RATE,
COPPROPDEFPTS.BPPSPLOCCHAZORPOLCOND AS BPP_SPEC_OCCPCY_HZRD,
COPPROPDEFPTS.BPPTOTALDEFICIENCYPTS AS BPP_TOT_DFNCY_PTS,
COPPROPDEFPTS.BPPTRANSORFLOATEQUIP AS BPP_TRNST_FLOAT_EQUIP,
COPPROPDEFPTS.BPPWATERDAMAGE AS BPP_WATER_DMG,
COALESCE(COPPROPDEFPTS.CLIMATICALHAZARDSNOTE,' ') AS CLIMAT_HZRD_NOTE,
COALESCE(COPPROPDEFPTS.COMBUSTSUSCEPTBLTYNOTE,' ') AS COMBUSTBLTY_SUSCEPT_NOTE,
COALESCE(COPPROPDEFPTS.CONSTRUCTIONNOTE,' ') AS CONSTR_NOTE,
COALESCE(COPPROPDEFPTS.DISASTEREXPOSURENOTE,' ') AS DISASTER_EXPSR_NOTE,
COALESCE(COPPROPDEFPTS.EARTHMOVEMENTNOTE,' ') AS EARTH_MVMNT,
COALESCE(COPPROPDEFPTS.EXTERNALEXPOSURENOTE,' ') AS XTRNL_EXPSR_NOTE,
COPPROPDEFPTS.INCARRANGESPECINS AS INCM_SPEC_INS_ARNGMT,
COPPROPDEFPTS.INCCLIMATICALHAZARDS AS INCM_CLIMAT_HZRD,
COPPROPDEFPTS.INCCOMBUSTSUSCEPTBLTY AS INCM_COMBUSTBLTY_SUSCEPT,
COPPROPDEFPTS.INCCONSTRUCTION AS    INCM_CONSTR ,
COPPROPDEFPTS.INCDEFPTCHARGE AS INCM_DFNCY_POINT_CHRG ,
COPPROPDEFPTS.INCDISASTEREXPOSURE AS INCM_DISASTER_EXPSR,
COPPROPDEFPTS.INCEARTHMOVEMENT AS  INCM_EARTH_MVMNT,
COPPROPDEFPTS.INCEXTERNALEXPOSURE AS INCM_XTRNL_EXPSR,
COPPROPDEFPTS.INCLOWERDEDUCTIBLE AS  INCM_LOWR_DED,
COPPROPDEFPTS.INCPREM AS  INCM_PREM,
COPPROPDEFPTS.INCPRIVATEPROTECTION AS INCM_PRVT_PROT ,
COPPROPDEFPTS.INCPUBLICPROTECTION AS  INCM_PUB_PROT,
COPPROPDEFPTS.INCRATE AS  INCM_RATE,
COPPROPDEFPTS.INCSPLOCCHAZORPOLCOND AS INCM_SPEC_OCCPCY_HZRD,
COPPROPDEFPTS.INCTOTALDEFICIENCYPTS AS INCM_TOT_DFNCY_PTS,
COPPROPDEFPTS.INCTRANSORFLOATEQUIP AS  INCM_TRNST_FLOAT_EQUIP,
COPPROPDEFPTS.INCWATERDAMAGE AS INCM_WATER_DMG,
COALESCE(COPPROPDEFPTS.LOWERDEDUCTIBLENOTE,' ') AS  LOWR_DED_NOTE,
COALESCE(COPPROPDEFPTS.PRIVATEPROTECTIONNOTE,' ') AS PRVT_PROT_NOTE ,
COALESCE(COPPROPDEFPTS.PUBLICPROTECTIONNOTE,' ') AS PUB_PROT_NOTE,
COALESCE(COPPROPDEFPTS.SPLOCCHAZORPOLCONDNOTE,' ') AS SPEC_OCCPCY_HZRD_NOTE,
COALESCE(COPPROPDEFPTS.TRANSORFLTEQUIPNOTE,' ') AS TRNST_FLOAT_EQUIP_NOTE,
COALESCE(COPPROPDEFPTS.UNDERWRITINGNOTES,' ') AS UW_NOTE,
COALESCE(COPPROPDEFPTS.WATERDAMAGENOTE,' ') AS WATER_DMG_NOTE,
COPPROPDEFPTS.branchid as SRC_BRANCHID,
COPPROPDEFPTS.fixedid as SRC_FIXEDID,
COPPROPDEFPTS.effectivedate as SRC_EFFECTIVEDATE,
COPPROPDEFPTS.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
COPPROPDEFPTS.createtime as SRC_CREATETIME,
COPPROPDEFPTS.updatetime  as SRC_UPDATETIME,
COPPROPDEFPTS.publicid as SRC_PUBLICID,
COPPROPDEFPTS.updatetime  as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_copperpdefpointstable_ext as COPPROPDEFPTS
INNER JOIN v_pc_policyperiod polper
on COPPROPDEFPTS.BranchID=polper.ID
and COPPROPDEFPTS.publicid=polper.pcx_copperpdefpointstable_ext_publicid
and COPPROPDEFPTS.updatetime=polper.pcx_copperpdefpointstable_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

  """
  return harmz_query

# COMMAND ----------

def build_ds_crime_dfncy(micro_batch_view,rawDB,cvrbl_type,lob_cd,source_system):
  harmz_query =f""" With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.{micro_batch_view}),
  pcx_copcrimedeficiencypts_ext_micro_batch as (select distinct branchid,updatetime from global_temp.{micro_batch_view} )
,v_pcx_copcrimedeficiencypts_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_copcrimedeficiencypts_ext.*
			from {rawDB}.pcx_copcrimedeficiencypts_ext          
            inner join pcx_copcrimedeficiencypts_ext_micro_batch   mb  
			   on mb.branchid = pcx_copcrimedeficiencypts_ext.branchid 
			where pcx_copcrimedeficiencypts_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/******,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,COPCRIMEDEFPTS.publicid as pcx_copcrimedeficiencypts_ext_publicid,COPCRIMEDEFPTS.updatetime as pcx_copcrimedeficiencypts_ext_updatetime,
      row_number() over (partition by COPCRIMEDEFPTS.publicid,COPCRIMEDEFPTS.updatetime,COPCRIMEDEFPTS.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(COPCRIMEDEFPTS.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_copcrimedeficiencypts_ext  COPCRIMEDEFPTS
      JOIN {rawDB}.pc_policyperiod  polper 
        on COPCRIMEDEFPTS.BranchID = polper.ID 
        and polper.updatetime <= COPCRIMEDEFPTS.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,COPCRIMEDEFPTS.publicid as pcx_copcrimedeficiencypts_ext_publicid,COPCRIMEDEFPTS.updatetime as pcx_copcrimedeficiencypts_ext_updatetime,
      row_number() over (partition by COPCRIMEDEFPTS.publicid,polper.updatetime,COPCRIMEDEFPTS.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(COPCRIMEDEFPTS.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_copcrimedeficiencypts_ext COPCRIMEDEFPTS
      JOIN {rawDB}.pc_policyperiod  polper 
        on COPCRIMEDEFPTS.BranchID = polper.ID 
        and COPCRIMEDEFPTS.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*****/


      , v_pc_policyperiod_bulk as (
            select
            POLPER.PeriodID,
            polper.PublicID,
            polper.CreateTime,
            polper.UpdateTime,
            polper.ID as polper_BranchID,
            p.updatetime as p_updatetime,
            p.BranchID as p_BranchID,
            polper.PeriodStart,
            polper.PeriodEnd,
            POLPER.periodstart as POLPER_PERIODSTART,
            POLPER.periodend as POLPER_PERIODEND,
            POLPER.publicid as POLPER_PUBLICID,
            Polper.Id,
            polper.status,
            polper.temporaryclonestatus,
            polper.jobId,
            POLPER.ModelNumber,
            p.publicid as p_publicid,
            p.publicid as pcx_copcrimedeficiencypts_ext_publicid,
            p.updatetime as pcx_copcrimedeficiencypts_ext_updatetime
          from
            v_pcx_copcrimedeficiencypts_ext  p
            JOIN {rawDB}.pc_policyperiod polper --child
            on p.BranchID = polper.ID
            JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
            JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
            and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
            and grp.Agencynum_ext != '00019999'
            and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
        ),
        v_pc_policyperiod as (
          select
            *
          from(
            ---consider parent record as driving record---
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.p_updatetime, --updatetime should be from parent in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
            )
          where
            rn = 1
            
        union all

        --consider child record as driving record
        select
            *
          from(
              select
                *,
                row_number() over (
                  partition by blk.p_publicid,
                  blk.updatetime,  --updatetime should be from child in partition clause
                  blk.p_BranchID
                  order by
                    (
                      unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
                    ) asc
                ) rn
              from
                v_pc_policyperiod_bulk blk
              where
                blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
            )
          where
            rn = 1
        )

   ------------Change code ends here for optimization----------------
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'||'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' ||'COPLine' || '-' || CAST(CAST (COPCRIMEDEFPTS.FixedID AS INTEGER) AS VARCHAR (255))) AS CRIME_DFNCY_KEY,
UPPER ('GWPC'|| '-' ||CAST( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
CAST ( COALESCE (COPCRIMEDEFPTS.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (COPCRIMEDEFPTS.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
  'COP' AS LOB_CD,
  '{source_system}-{lob_cd}-{cvrbl_type}' AS PARTITION_VAL,
 COPCRIMEDEFPTS.COMPDATAPROCESS AS COMP_FRAUD_DATA_CONTROL  ,
 COPCRIMEDEFPTS.COMPELECTRANSACTION AS COMP_FRAUD_ELCTN_TRANS  ,
 COPCRIMEDEFPTS.COMPEXPOSURENOC AS COMP_FRAUD_EFDE  ,
 COPCRIMEDEFPTS.COMPEXTEXPOSURE AS COMP_FRAUD_XTRNL_EXPSR  ,
 COPCRIMEDEFPTS.COMPINTCOVPROP AS COMP_FRAUD_IC_COV_PRPTY  ,
 COPCRIMEDEFPTS.COMPINTMONEY AS COMP_FRAUD_IC_MNY  ,
 COPCRIMEDEFPTS.COMPINTSECURITY AS COMP_FRAUD_IC_SECURITY  ,
COPCRIMEDEFPTS.COMPLARGEEXPOSURE AS COMP_FRAUD_LRGE_LOSS_EXPSR  ,
COPCRIMEDEFPTS.COMPLOWERDEDUCT AS COMP_FRAUD_LOWR_DED  ,
COPCRIMEDEFPTS.COMPMANAGEMENT AS COMP_FRAUD_MGMT_SUPERVSN  ,
COPCRIMEDEFPTS.CTFraudDefPointCharge AS COMP_FRAUD_DFNCY_POINT_CHRG  ,
COPCRIMEDEFPTS.COMPOFFPREEXPOSURE AS COMP_FRAUD_OFF_PRMS_EXPSR  ,
COPCRIMEDEFPTS.COMPPRIVATEPROT AS COMP_FRAUD_PRVT_PROT  ,
COPCRIMEDEFPTS.COMPSPECINCOME AS COMP_FRAUD_SPEC_INCM_INS_ARGMT  ,
COPCRIMEDEFPTS.COMPSPLOCCHAZ AS COMP_FRAUD_SPEC_OCCPCY_HZRD  ,
COPCRIMEDEFPTS.COMPTELFRAUDPREM AS COMP_FRAUD_PREM  ,
COPCRIMEDEFPTS.COMPTELFRAUDRATE AS COMP_FRAUD_RATE  ,
COPCRIMEDEFPTS.COMPTOTALDEFPTS AS COMP_FRAUD_TOT_DFNCY_PTS  ,
COPCRIMEDEFPTS.COUNTDATAPROCESS AS CNTFT_MNY_DATA_CONTROL  ,
COPCRIMEDEFPTS.COUNTELECTRANSACTION AS CNTFT_MNY_ELCTN_TRANS  ,
COPCRIMEDEFPTS.COUNTERFEITMONEYPREM AS CNTFT_MNY_PREM  ,
COPCRIMEDEFPTS.COUNTERFEITMONEYRATE AS CNTFT_MNY_RATE  ,
COPCRIMEDEFPTS.COUNTEXPOSURENOC AS CNTFT_MNY_EFDE  ,
COPCRIMEDEFPTS.COUNTEXTEXPOSURE AS CNTFT_MNY_XTRNL_EXPSR  ,
COPCRIMEDEFPTS.COUNTINTCOVPROP AS CNTFT_MNY_IC_COV_PRPTY  ,
COPCRIMEDEFPTS.COUNTINTMONEY AS CNTFT_MNY_IC_MNY  ,
COPCRIMEDEFPTS.COUNTINTSECURITY AS CNTFT_MNY_IC_SECURITY  ,
COPCRIMEDEFPTS.COUNTLARGEEXPOSURE AS CNTFT_MNY_LRGE_LOSS_EXPSR  ,
COPCRIMEDEFPTS.COUNTLOWERDEDUCT AS CNTFT_MNY_LOWR_DED  ,
COPCRIMEDEFPTS.COUNTMANAGEMENT AS CNTFT_MNY_MGMT_SUPERVSN  ,
COPCRIMEDEFPTS.COUNTMONDEFPOINTCHARGE AS CNTFT_MNY_DFNCY_POINT_CHRG  ,
COPCRIMEDEFPTS.COUNTOFFPREEXPOSURE AS CNTFT_MNY_OFF_PRMS_EXPSR  ,
COPCRIMEDEFPTS.COUNTPRIVATEPROT AS CNTFT_MNY_PRVT_PROT  ,
COPCRIMEDEFPTS.COUNTSPECINCOME AS CNTFT_MNY_SPEC_INCM_INS_ARGMT  ,
COPCRIMEDEFPTS.COUNTSPLOCCHAZ AS CNTFT_MNY_SPEC_OCCPCY_HZRD  ,
COPCRIMEDEFPTS.COUNTTOTALDEFPTS AS CNTFT_MNY_TOT_DFNCY_PTS  ,
COPCRIMEDEFPTS.EMPDATAPROCESS AS EFD_DATA_CONTROL  ,
COPCRIMEDEFPTS.EMPELECTRANSACTION AS EFD_ELCTN_TRANS  ,
COPCRIMEDEFPTS.EMPFRAUDDISHONESTYPREM AS EFD_PREM  ,
COPCRIMEDEFPTS.EMPFRAUDDISHONESTYRATE AS EFD_RATE  ,
COPCRIMEDEFPTS.EMPEXPOSURENOC AS EFD_EFDE  ,
COPCRIMEDEFPTS.EMPEXTEXPOSURE AS EFD_XTRNL_EXPSR  ,
COPCRIMEDEFPTS.EMPINTCOVPROP AS EFD_IC_COV_PRPTY  ,
COPCRIMEDEFPTS.EMPINTMONEY AS EFD_IC_MNY  ,
COPCRIMEDEFPTS.EMPINTSECURITY AS EFD_IC_SECURITY  ,
COPCRIMEDEFPTS.EMPLARGEEXPOSURE AS EFD_LRGE_LOSS_EXPSR  ,
COPCRIMEDEFPTS.EMPLOWERDEDUCT AS EFD_LOWR_DED  ,
COPCRIMEDEFPTS.EMPMANAGEMENT AS EFD_MGMT_SUPERVSN  ,
COPCRIMEDEFPTS.EFDDefPointCharge AS EFD_DFNCY_POINT_CHRG,  
COPCRIMEDEFPTS.EMPOFFPREEXPOSURE AS EFD_OFF_PRMS_EXPSR  ,
COPCRIMEDEFPTS.EMPPRIVATEPROT AS EFD_PRVT_PROT  ,
COPCRIMEDEFPTS.EMPSPECINCOME AS EFD_SPEC_INCM_INS_ARGMT ,
COPCRIMEDEFPTS.EMPSPLOCCHAZ AS EFD_SPEC_OCCPCY_HZRD  ,
COPCRIMEDEFPTS.EMPTOTALDEFPTS AS EFD_TOT_DFNCY_PTS  ,
COPCRIMEDEFPTS.FORGEDCHKDATAPROCESS AS FC_DATA_CONTROL  ,
COPCRIMEDEFPTS.FORGEDCHKELECTRANSACTION AS FC_ELCTN_TRANS  ,
COPCRIMEDEFPTS.FORGEDCHECKSPREM AS FC_PREM  ,
COPCRIMEDEFPTS.FORGEDCHECKSRATE AS FC_RATE  ,
COPCRIMEDEFPTS.FORGEDCHKEXPOSURENOC AS FC_EFDE  ,
COPCRIMEDEFPTS.FORGEDCHKEXTEXPOSURE AS FC_XTRNL_EXPSR  ,
COPCRIMEDEFPTS.FORGEDCHKINTCOVPROP AS FC_IC_COV_PRPTY  ,
COPCRIMEDEFPTS.FORGEDCHKINTMONEY AS FC_IC_MNY  ,
COPCRIMEDEFPTS.FORGEDCHKINTSECURITY AS FC_IC_SECURITY  ,
COPCRIMEDEFPTS.FORGEDCHKEXPOSURE AS FC_LRGE_LOSS_EXPSR  ,
COPCRIMEDEFPTS.FORGEDCHKLOWERDEDUCT AS FC_LOWR_DED  ,
COPCRIMEDEFPTS.FORGEDCHKMANAGEMENT AS FC_MGMT_SUPERVSN  ,
COPCRIMEDEFPTS.FORGEDCCDEFPOINTCHARGE AS FC_DFNCY_POINT_CHRG  ,
COPCRIMEDEFPTS.FORGEDCHKOFFPREEXPOSURE AS FC_OFF_PRMS_EXPSR  ,
COPCRIMEDEFPTS.FORGEDCHKPRIVATEPROT AS FC_PRVT_PROT  ,
COPCRIMEDEFPTS.FORGEDCHKSPECINCOME AS FC_SPEC_INCM_INS_ARGMT  ,
COPCRIMEDEFPTS.FORGEDCHKSPLOCCHAZ AS FC_SPEC_OCCPCY_HZRD  ,
COPCRIMEDEFPTS.FORGEDCHKTOTALDEFPTS AS FC_TOT_DFNCY_PTS  ,
COPCRIMEDEFPTS.FORGEDDATAPROCESS AS FCC_DATA_CONTROL  ,
COPCRIMEDEFPTS.FORGEDELECTRANSACTION AS FCC_ELCTN_TRANS  ,
COPCRIMEDEFPTS.FORGEDCREDITCARDPREM AS FCC_PREM  ,
COPCRIMEDEFPTS.FORGEDCREDITCARDRATE AS FCC_RATE  ,
COPCRIMEDEFPTS.FORGEDEXPOSURENOC AS FCC_EFDE  ,
COPCRIMEDEFPTS.FORGEDEXTEXPOSURE AS FCC_XTRNL_EXPSR  ,
COPCRIMEDEFPTS.FORGEDINTCOVPROP AS FCC_IC_COV_PRPTY  ,
COPCRIMEDEFPTS.FORGEDINTMONEY AS FCC_IC_MNY  ,
COPCRIMEDEFPTS.FORGEDINTSECURITY AS FCC_IC_SECURITY  ,
COPCRIMEDEFPTS.FORGEDLARGEEXPOSURE AS FCC_LRGE_LOSS_EXPSR  ,
COPCRIMEDEFPTS.FORGEDLOWERDEDUCT AS FCC_LOWR_DED  ,
COPCRIMEDEFPTS.FORGEDMANAGEMENT AS FCC_MGMT_SUPERVSN  ,
COPCRIMEDEFPTS.FORGEDCHKDEFPOINTCHARGE AS FCC_DFNCY_POINT_CHRG  ,   
COPCRIMEDEFPTS.FORGEDOFFPREEXPOSURE AS FCC_OFF_PRMS_EXPSR  ,
COPCRIMEDEFPTS.FORGEDPRIVATEPROT AS FCC_PRVT_PROT  ,
COPCRIMEDEFPTS.FORGEDSPECINCOME AS FCC_SPEC_INCM_INS_ARGMT  ,
COPCRIMEDEFPTS.FORGEDSPLOCCHAZ AS FCC_SPEC_OCCPCY_HZRD  ,
COPCRIMEDEFPTS.FORGEDTOTALDEFPTS AS FCC_TOT_DFNCY_PTS  ,
COPCRIMEDEFPTS.MONEYDATAPROCESS AS MS_DATA_CONTROL  ,
COPCRIMEDEFPTS.MONEYELECTRANSACTION AS MS_ELCTN_TRANS  ,
COPCRIMEDEFPTS.MoneySecuritiesAtPrem AS MS_AT_PREM  ,
COPCRIMEDEFPTS.MoneySecuritiesAtRate AS MS_AT_RATE  ,
COPCRIMEDEFPTS.MoneySecuritiesAwayPrem AS MS_AWAY_PREM  ,
COPCRIMEDEFPTS.MoneySecuritiesAwayRate AS MS_AWAY_RATE  ,
COPCRIMEDEFPTS.MONEYEXPOSURENOC AS MS_EFDE  ,
COPCRIMEDEFPTS.MONEYEXTEXPOSURE AS MS_XTRNL_EXPSR  ,
COPCRIMEDEFPTS.MONEYINTCOVPROP AS MS_IC_COV_PRPTY  ,
COPCRIMEDEFPTS.MONEYINTMONEY AS MS_IC_MNY  ,
COPCRIMEDEFPTS.MONEYINTSECURITY AS MS_IC_SECURITY  ,
COPCRIMEDEFPTS.MONEYLARGEEXPOSURE AS MS_LRGE_LOSS_EXPSR  ,
COPCRIMEDEFPTS.MONEYLOWERDEDUCT AS MS_LOWR_DED  ,
COPCRIMEDEFPTS.MONEYMANAGEMENT AS MS_MGMT_SUPERVSN  ,
COPCRIMEDEFPTS.MSDEFPOINTCHARGE AS MS_DFNCY_POINT_CHRG  ,
COPCRIMEDEFPTS.MONEYOFFPREEXPOSURE AS MS_OFF_PRMS_EXPSR  ,
COPCRIMEDEFPTS.MONEYPRIVATEPROT AS MS_PRVT_PROT  ,               
COPCRIMEDEFPTS.MONEYSPECINCOME AS MS_SPEC_INCM_INS_ARGMT  ,
COPCRIMEDEFPTS.MONEYSPLOCCHAZ AS MS_SPEC_OCCPCY_HZRD  ,
COPCRIMEDEFPTS.MONEYTOTALDEFPTS AS MS_TOT_DFNCY_PTS  ,
COALESCE(COPCRIMEDEFPTS.DATAPROCESSCONTNOTE,' ') AS DATA_CONTROL_NOTE  ,
COALESCE(COPCRIMEDEFPTS.ELECTRANSACTIONNOTE,' ') AS ELCTN_TRANS_NOTE  ,
COALESCE(COPCRIMEDEFPTS.EMPFRAUDANDDISEXPNOCNOTE,' ') AS EFDE_NOTE,
COALESCE(COPCRIMEDEFPTS.EXTERNALEXPOSURENOTE,' ') AS XTRNL_EXPSR_NOTE  ,
COALESCE(COPCRIMEDEFPTS.INTCONTCOVPROPNOTE,' ') AS IC_COV_PRPTY_NOTE  ,
COALESCE(COPCRIMEDEFPTS.INTCONTMONEYNOTE,' ') AS IC_MNY_NOTE  ,
COALESCE(COPCRIMEDEFPTS.INTCONTSECURITIESNOTE,' ') AS IC_SECURITY_NOTE ,
COALESCE(COPCRIMEDEFPTS.LARGELOSSEXPOSURENOTE,' ') AS LRGE_LOSS_EXPSR_NOTE  ,
COALESCE(COPCRIMEDEFPTS.LOWERDEDUCTIBLENOTE,' ') AS LOWR_DED_NOTE  ,
COALESCE(COPCRIMEDEFPTS.MANAGEMENTSUPERVISIONNOTE,' ') AS MGMT_SUPERVSN_NOTE  ,
COALESCE(COPCRIMEDEFPTS.OFFPREMISESEXPOSURENOTE,' ') AS OFF_PRMS_EXPSR_NOTE ,
COALESCE(COPCRIMEDEFPTS.PRIVATEPHYSICALPROTECTIONNOTE,' ') AS PRVT_PROT_NOTE  ,
COALESCE(COPCRIMEDEFPTS.SPLOCCHAZNOTE,' ') AS SPEC_OCCPCY_HZRD_NOTE  ,
COALESCE(COPCRIMEDEFPTS.ARRSPECINSURANCENOTE,' ') AS SPEC_INCM_INS_ARGMT  ,
COALESCE(COPCRIMEDEFPTS.UNDERWRITINGNOTES,' ') AS UW_NOTE , 
 
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
COPCRIMEDEFPTS.branchid as SRC_BRANCHID,
COPCRIMEDEFPTS.fixedid as SRC_FIXEDID,
COPCRIMEDEFPTS.effectivedate as SRC_EFFECTIVEDATE,
COPCRIMEDEFPTS.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
COPCRIMEDEFPTS.createtime as SRC_CREATETIME,
COPCRIMEDEFPTS.updatetime  as SRC_UPDATETIME,
COPCRIMEDEFPTS.publicid as SRC_PUBLICID,
COPCRIMEDEFPTS.updatetime  as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_copcrimedeficiencypts_ext as COPCRIMEDEFPTS
INNER JOIN v_pc_policyperiod polper
on COPCRIMEDEFPTS.BranchID=polper.ID
and COPCRIMEDEFPTS.publicid=polper.pcx_copcrimedeficiencypts_ext_publicid
and COPCRIMEDEFPTS.updatetime=polper.pcx_copcrimedeficiencypts_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE   status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query

# COMMAND ----------

def buildSIScheduleCoverageLogicGen_COP(rawDB: str,  parent:str ,cvrblType: str):
  dfScheduleCoverageCol =spark.sql(f"show columns in {rawDB}.{parent}").filter(col("col_name").like( "schedulecoverage" ))
  ScheduleCoverageColCount = int(dfScheduleCoverageCol.count())
  
  if(ScheduleCoverageColCount == 1):
    ScheduleCoverageLogic = "schedulecoverage"
  else:
    ScheduleCoverageLogic = "schedule"
  
  return ScheduleCoverageLogic