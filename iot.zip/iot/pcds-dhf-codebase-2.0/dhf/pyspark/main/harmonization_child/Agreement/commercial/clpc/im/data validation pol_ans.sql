-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###ds_line_cvrbl

-- COMMAND ----------

--select distinct ETL_ROW_EFF_DTS, count(*)  from dhf_harmonize_stromboli.ds_line_cvrbl group by 1
select *  from dhf_harmonize_stromboli.ds_pol_ans where ETL_ROW_EFF_DTS is null

-- COMMAND ----------

SELECT  POL_ANS_KEY, END_EFF_DT, ETL_ROW_EFF_DTS, COUNT(*)
FROM dhf_harmonize_stromboli.ds_pol_ans
GROUP BY POL_ANS_KEY, END_EFF_DT, ETL_ROW_EFF_DTS
HAVING COUNT(*) > 1

-- COMMAND ----------

select 'ds_pol_ans' as table_name , count(*) as id_dups from ( select pol_ans_id , count(*) as dup_count from dhf_harmonize_stromboli.ds_pol_ans group by pol_ans_id having count(*) > 1)

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_pol_ans where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'

-- COMMAND ----------

select POL_ANS_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,count(*)
from dhf_harmonize_stromboli.ds_pol_ans 
where ETL_CURR_ROW_FL='Y'
group by POL_ANS_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL
having count(*) > 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###DS_EXCL_TERM

-- COMMAND ----------

--select distinct ETL_ROW_EFF_DTS, count(*)  from dhf_harmonize_stromboli.DS_EXCL_TERM group by 1
select *  from dhf_harmonize_stromboli.DS_EXCL_TERM where ETL_ROW_EFF_DTS is null

-- COMMAND ----------

SELECT  EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS, COUNT(*)
FROM dhf_harmonize_stromboli.ds_excl_term
GROUP BY EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS
HAVING COUNT(*) > 1

-- COMMAND ----------

select 'ds_excl_term' as table_name , count(*) as id_dups from ( select EXCL_TERM_ID , count(*) as dup_count from dhf_harmonize_stromboli.ds_excl_term group by EXCL_TERM_ID having count(*) > 1)

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_excl_term where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'

-- COMMAND ----------

select EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,count(*)
from dhf_harmonize_stromboli.ds_excl_term
where ETL_CURR_ROW_FL='Y'
group by EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL
having count(*) > 1
