# Databricks notebook source
# MAGIC %run ../../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../../../harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

# MAGIC %sql
# MAGIC use pc_agrmnt_clpc_raw;

# COMMAND ----------

def build_ds_line_cvrbl_IMGContrsAdv(rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgcontrsadv_ext_micro_batch)
  ,pcx_imgcontrsadv_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgcontrsadv_ext_micro_batch )
,v_pcx_imgcontrsadv_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgcontrsadv_ext.*
			from {rawDB}.pcx_imgcontrsadv_ext          
            inner join pcx_imgcontrsadv_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgcontrsadv_ext.branchid 
			where pcx_imgcontrsadv_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/***,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,CONAD.publicid as pcx_imgcontrsadv_ext_publicid,CONAD.updatetime as pcx_imgcontrsadv_ext_updatetime,
      row_number() over (partition by CONAD.publicid,CONAD.updatetime,CONAD.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(CONAD.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgcontrsadv_ext  CONAD
      JOIN {rawDB}.pc_policyperiod  polper 
        on CONAD.BranchID = polper.ID 
        and polper.updatetime <= CONAD.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,CONAD.publicid as pcx_imgcontrsadv_ext_publicid,CONAD.updatetime as pcx_imgcontrsadv_ext_updatetime,
      row_number() over (partition by CONAD.publicid,polper.updatetime,CONAD.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(CONAD.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgcontrsadv_ext CONAD
      JOIN {rawDB}.pc_policyperiod  polper 
        on CONAD.BranchID = polper.ID 
        and CONAD.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgcontrsadv_ext_publicid,
    p.updatetime as pcx_imgcontrsadv_ext_updatetime
  from
    v_pcx_imgcontrsadv_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------

,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
) 
,HRZ_Query as 
( SELECT 
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST(polper.publicID  AS VARCHAR (255)) || '-' ELSE '' END  || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST(CAST(conad.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE  WHEN status.TypeCode <> 'Bound'  THEN  '-' || 'QT:' ||  CAST(polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC'|| '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE ''END || '-'|| 'IMGLine' || '-' || CAST(CAST (conad.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
COALESCE(UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'  || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST(polper.publicID AS VARCHAR (255)) || '-' ELSE  ''  END || 'IMGLoc' || '-' || CAST(CAST(conad.IMGLocation AS INTEGER) AS VARCHAR (255))), 'NOKEY')  AS LINE_LOC_KEY,
CAST ( COALESCE (CONAD.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (CONAD.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
'IM' AS LOB_CD ,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
COALESCE(ANPYRL.TYPECODE, ' ')   AS ANNUAL_PAYROLL_CD,
COALESCE(ANPYRL.description, 'Not Defined') AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(CONAD.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(CONAD.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
CONAD.LegacyItemNum AS LGCY_ITEM_NO,
CONAD.LegacyItemIdentifier AS LEGACY_ITEM_ID,
CONAD.branchid as SRC_BRANCHID,
CONAD.fixedid as SRC_FIXEDID,
CONAD.effectivedate as SRC_EFFECTIVEDATE,
CONAD.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
CONAD.createtime as SRC_CREATETIME,
CONAD.updatetime  as SRC_UPDATETIME,
CONAD.publicid as SRC_PUBLICID,
CONAD.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgcontrsadv_ext as CONAD
INNER JOIN v_pc_policyperiod polper
on CONAD.BranchID=polper.ID
and CONAD.publicid=polper.pcx_imgcontrsadv_ext_publicid
and CONAD.updatetime=polper.pcx_imgcontrsadv_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join 
		(
		select * from 
			(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn 
			from {rawDB}.pctl_imgcontradvanulpayrol_ext anpyrl
			Cross Join Events_Max_Updatetime mb  On anpyrl.z_meta_event_timestamp <= mb.mb_max_updatetime)
			where rn=1) anpyrl 
on CONAD.AnnualPayroll = anpyrl.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL) 

# COMMAND ----------

def build_ds_line_cvrbl_IMGSign(rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgsign_ext_micro_batch),
  pcx_imgsign_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgsign_ext_micro_batch )
,v_pcx_imgsign_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgsign_ext.*
			from {rawDB}.pcx_imgsign_ext pcx_imgsign_ext         
            inner join pcx_imgsign_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgsign_ext.branchid 
			where pcx_imgsign_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*********************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,sign.publicid as pcx_imgsign_ext_publicid,sign.updatetime as pcx_imgsign_ext_updatetime,
      row_number() over (partition by sign.publicid,sign.updatetime,sign.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(sign.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgsign_ext  sign
      JOIN {rawDB}.pc_policyperiod  polper 
        on sign.BranchID = polper.ID 
        and polper.updatetime <= sign.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,sign.publicid as pcx_imgsign_ext_publicid,sign.updatetime as pcx_imgsign_ext_updatetime,
      row_number() over (partition by sign.publicid,polper.updatetime,sign.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(sign.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgsign_ext sign
      JOIN {rawDB}.pc_policyperiod  polper 
        on sign.BranchID = polper.ID 
        and sign.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgsign_ext_publicid,
    p.updatetime as pcx_imgsign_ext_updatetime
  from
    v_pcx_imgsign_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
) 
,HRZ_Query as 
( SELECT 
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END  || 'IMGSign' || '-' || CAST(CAST(sign.FixedID AS INTEGER)  AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE  WHEN status.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ( 'GWPC' || '-' ||CAST (CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound'  THEN  '-'  || 'QT:'|| CAST (polper.publicID  AS VARCHAR (255)) ELSE ''  END || '-' || 'IMGLine' || '-' || CAST(CAST (sign.IMGLine AS INTEGER)AS VARCHAR (255))) AS POL_LINE_KEY ,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (sign.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (sign.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(sign.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(sign.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
sign.LegacyItemNum AS LGCY_ITEM_NO,
sign.LegacyItemIdentifier AS LEGACY_ITEM_ID,
sign.branchid as SRC_BRANCHID,
sign.fixedid as SRC_FIXEDID,
sign.effectivedate as SRC_EFFECTIVEDATE,
sign.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
sign.createtime as SRC_CREATETIME,
sign.updatetime  as SRC_UPDATETIME,
sign.publicid as SRC_PUBLICID,
sign.updatetime  as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgsign_ext as sign
INNER JOIN v_pc_policyperiod polper
on sign.BranchID=polper.ID
and sign.publicid=polper.pcx_imgsign_ext_publicid
and sign.updatetime=polper.pcx_imgsign_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGYngStkRisr(rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgyngstkrisr_ext_micro_batch),
  pcx_imgyngstkrisr_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgyngstkrisr_ext_micro_batch ) 
  
,v_pcx_imgyngstkrisr_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgyngstkrisr_ext.*
			from {rawDB}.pcx_imgyngstkrisr_ext          
            inner join pcx_imgyngstkrisr_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgyngstkrisr_ext.branchid 
			where pcx_imgyngstkrisr_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/****************************,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,YSR.publicid as pcx_imgyngstkrisr_ext_publicid,YSR.updatetime as pcx_imgyngstkrisr_ext_updatetime,
      row_number() over (partition by YSR.publicid,YSR.updatetime,YSR.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(YSR.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgyngstkrisr_ext YSR
      JOIN {rawDB}.pc_policyperiod polper 
        on YSR.BranchID = polper.ID 
        and polper.updatetime <= YSR.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,YSR.publicid as pcx_imgyngstkrisr_ext_publicid,YSR.updatetime as pcx_imgyngstkrisr_ext_updatetime,
      row_number() over (partition by YSR.publicid,polper.updatetime,YSR.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(YSR.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgyngstkrisr_ext YSR
      JOIN {rawDB}.pc_policyperiod  polper 
        on YSR.BranchID = polper.ID 
        and YSR.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgyngstkrisr_ext_publicid,
    p.updatetime as pcx_imgyngstkrisr_ext_updatetime
  from
    v_pcx_imgyngstkrisr_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as (
SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGYngStkRisr' || '-' || CAST (CAST(YSR.FixedID AS INTEGER)AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
 UPPER ( 'GWPC' || '-' ||CAST (CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound'  THEN  '-'  || 'QT:'|| CAST (polper.publicID  AS VARCHAR (255)) ELSE ''  END || '-' || 'IMGLine' || '-' || CAST(CAST (YSR.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY ,
'NOKEY' AS LINE_LOC_KEY, 
CAST ( COALESCE (YSR.EffectiveDate, polper.PeriodStart , to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT,
CAST ( COALESCE (YSR.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,  
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS, 
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
' ' AS ANNUAL_PAYROLL_CD,
NULL AS ANNUAL_GROSS_RECEIPT_AMT , 
'Not Defined' AS ANNUAL_PAYROLL_TEXT ,
NULL AS ANNUAL_RENT_EXP ,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD ,
 NULL AS DED_FCTR , 
 NULL AS DED_OVR_FCTR , 
 NULL AS DELAY_IN_COMPLETION_FCTR , 
 NULL AS DELAY_IN_COMPLETION_OVR_FCTR , 
'U' AS EQP_BRKDWN_OPT_OUT_FL , 
 NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR , 
 NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
  NULL AS LSE_RENT_EQP_FCTR , 
NULL AS LSE_RENT_EQP_OVR_FCTR ,
COALESCE(YSR.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(YSR.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
YSR.LegacyItemNum AS LGCY_ITEM_NO,
YSR.LegacyItemIdentifier AS LEGACY_ITEM_ID,
 NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
 NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR , 
 'U' AS POWER_GEN_COMPANY_FL , 
'U' AS POWER_GEN_EQUIP_FL ,
 'U' AS PROD_MACH_INSTALL_FL , 
 'U' AS PROJ_EXCEED_24_MON_FL ,
 ' ' AS PROJECT_TYPE_CD , 
 'Not Defined' AS PROJECT_TYPE_TEXT , 
 'U' AS REFRIG_WAREHOUSING_FL ,
   ' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
  'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT , 
  NULL AS SALE_OFFICE_MOD_FCTR ,
   NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
    NULL AS THEFT_DEDUCTIBLE_FCTR ,
    NULL AS THEFT_DEDUCTIBLE_OVR_FCTR , 
   NULL AS TOTAL_LOAD_FCTR , 
    NULL AS TOTAL_LOAD_OVR_FCTR , 
    NULL AS UN_SCH_TOOL_EQP_PREM_FCTR , 
    NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
YSR.branchid as SRC_BRANCHID,
YSR.fixedid as SRC_FIXEDID,
YSR.effectivedate as SRC_EFFECTIVEDATE,
YSR.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
YSR.createtime as SRC_CREATETIME,
YSR.updatetime  as SRC_UPDATETIME,
YSR.publicid as SRC_PUBLICID,
YSR.updatetime  as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
FROM 
v_pcx_imgyngstkrisr_ext as YSR
INNER JOIN v_pc_policyperiod polper
on YSR.BranchID=polper.ID
and YSR.publicid=polper.pcx_imgyngstkrisr_ext_publicid
and YSR.updatetime=polper.pcx_imgyngstkrisr_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
	
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
		
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGValuablePaper(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgvaluablepaper_ext_micro_batch),
  pcx_imgvaluablepaper_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgvaluablepaper_ext_micro_batch ) 
,v_pcx_imgvaluablepaper_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgvaluablepaper_ext.*
			from {rawDB}.pcx_imgvaluablepaper_ext          
            inner join pcx_imgvaluablepaper_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgvaluablepaper_ext.branchid 
			where pcx_imgvaluablepaper_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,vp.publicid as pcx_imgvaluablepaper_ext_publicid,vp.updatetime as pcx_imgvaluablepaper_ext_updatetime,
      row_number() over (partition by vp.publicid,vp.updatetime,vp.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(vp.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgvaluablepaper_ext vp
      JOIN {rawDB}.pc_policyperiod polper 
        on vp.BranchID = polper.ID 
        and polper.updatetime <= vp.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,vp.publicid as pcx_imgvaluablepaper_ext_publicid,vp.updatetime as pcx_imgvaluablepaper_ext_updatetime,
      row_number() over (partition by vp.publicid,polper.updatetime,vp.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(vp.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgvaluablepaper_ext vp
      JOIN {rawDB}.pc_policyperiod  polper 
        on vp.BranchID = polper.ID 
        and vp.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgvaluablepaper_ext_publicid,
    p.updatetime as pcx_imgvaluablepaper_ext_updatetime
  from
    v_pcx_imgvaluablepaper_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
 ,HRZ_Query as (
SELECT 
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END  || 'IMGValuablePaper' || '-' || CAST(CAST(vp.FixedID AS INTEGER)  AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE  WHEN status.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE  WHEN status.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (vp.IMGLine AS INTEGER) AS VARCHAR (255)) )  AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (vp.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (vp.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC'  AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD ,
'IM' AS LOB_CD
,NULL AS ANNUAL_GROSS_RECEIPT_AMT
,' '  AS ANNUAL_PAYROLL_CD
,'Not Defined' AS  ANNUAL_PAYROLL_TEXT
, NULL AS ANNUAL_RENT_EXP
, ' ' AS AVERAGE_JOB_LENGTH_CD
, 'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT
, ' ' AS CLASS_CD
, 'Not Defined' AS CLASS_TEXT
, NULL AS DED_FCTR
, NULL AS DED_OVR_FCTR
, NULL AS DELAY_IN_COMPLETION_FCTR
, NULL AS DELAY_IN_COMPLETION_OVR_FCTR
, 'U' AS EQP_BRKDWN_OPT_OUT_FL
, NULL AS EQP_LEASE_FROM_OTH_PREM
, NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR
, NULL AS HIST_PRE_TAX_OVR_CRED_FCTR
, 'U' AS INS_INC_EXPSR_FL
, NULL AS LSE_RENT_EQP_FCTR
, NULL AS LSE_RENT_EQP_OVR_FCTR
        , COALESCE(vp.LegacyClassCode, ' ')  AS LGCY_CL_CD
        , COALESCE(vp.LegacyClassDesc, ' ')   AS LGCY_CL_DESC
        , vp.LegacyItemNum AS LGCY_ITEM_NO
        , vp.LegacyItemIdentifier AS LEGACY_ITEM_ID
, NULL AS OFF_SITE_SERVER_LOAD_FCTR
, NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR
, 'U' AS POWER_GEN_COMPANY_FL
, 'U' AS POWER_GEN_EQUIP_FL
, 'U' AS PROD_MACH_INSTALL_FL
, 'U' AS PROJ_EXCEED_24_MON_FL
, ' ' AS PROJECT_TYPE_CD
, 'Not Defined' AS PROJECT_TYPE_TEXT
, 'U' AS REFRIG_WAREHOUSING_FL
, ' ' AS SALE_OFFICE_BLDG_TYPE_CD
, 'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT
, NULL AS SALE_OFFICE_MOD_FCTR
, NULL AS SALE_OFFICE_MOD_OVR_FCTR
, NULL AS THEFT_DEDUCTIBLE_FCTR
, NULL AS THEFT_DEDUCTIBLE_OVR_FCTR
, NULL AS TOTAL_LOAD_FCTR
, NULL AS TOTAL_LOAD_OVR_FCTR
, NULL AS UN_SCH_TOOL_EQP_PREM_FCTR
, NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
vp.branchid as SRC_BRANCHID,
vp.fixedid as SRC_FIXEDID,
vp.effectivedate as SRC_EFFECTIVEDATE,
vp.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID,
vp.createtime as SRC_CREATETIME,
vp.updatetime  as SRC_UPDATETIME,
vp.publicid as SRC_PUBLICID,
vp.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
FROM 
v_pcx_imgvaluablepaper_ext as vp
INNER JOIN v_pc_policyperiod polper
on vp.BranchID=polper.ID
and vp.publicid=polper.pcx_imgvaluablepaper_ext_publicid
and vp.updatetime=polper.pcx_imgvaluablepaper_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
		
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
	
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL) 

# COMMAND ----------

def build_ds_line_cvrbl_IMGServproPrgm(rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgservproprgm_ext_micro_batch)
  ,pcx_imgservproprgm_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgservproprgm_ext_micro_batch )
,v_pcx_imgservproprgm_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgservproprgm_ext.*
			from {rawDB}.pcx_imgservproprgm_ext          
            inner join pcx_imgservproprgm_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgservproprgm_ext.branchid 
			where pcx_imgservproprgm_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/***************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,SRVPROPRGM.publicid as pcx_imgservproprgm_ext_publicid,SRVPROPRGM.updatetime as pcx_imgservproprgm_ext_updatetime,
      row_number() over (partition by SRVPROPRGM.publicid,SRVPROPRGM.updatetime,SRVPROPRGM.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(SRVPROPRGM.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgservproprgm_ext  SRVPROPRGM
      JOIN {rawDB}.pc_policyperiod  polper 
        on SRVPROPRGM.BranchID = polper.ID 
        and polper.updatetime <= SRVPROPRGM.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,SRVPROPRGM.publicid as pcx_imgservproprgm_ext_publicid,SRVPROPRGM.updatetime as pcx_imgservproprgm_ext_updatetime,
      row_number() over (partition by SRVPROPRGM.publicid,polper.updatetime,SRVPROPRGM.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(SRVPROPRGM.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgservproprgm_ext SRVPROPRGM
      JOIN {rawDB}.pc_policyperiod  polper 
        on SRVPROPRGM.BranchID = polper.ID 
        and SRVPROPRGM.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgservproprgm_ext_publicid,
    p.updatetime as pcx_imgservproprgm_ext_updatetime
  from
    v_pcx_imgservproprgm_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST (CAST(SRVPROPRGM.FixedID AS INTEGER)AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (SRVPROPRGM.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (SRVPROPRGM.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (SRVPROPRGM.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate  ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(SRVPROPRGM.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(SRVPROPRGM.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
SRVPROPRGM.LegacyItemNum AS LGCY_ITEM_NO,
SRVPROPRGM.LegacyItemIdentifier AS LEGACY_ITEM_ID,
SRVPROPRGM.branchid as SRC_BRANCHID,
SRVPROPRGM.fixedid as SRC_FIXEDID,
SRVPROPRGM.effectivedate as SRC_EFFECTIVEDATE,
SRVPROPRGM.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
SRVPROPRGM.createtime as SRC_CREATETIME,
SRVPROPRGM.updatetime  as SRC_UPDATETIME,
SRVPROPRGM.publicid as SRC_PUBLICID,
SRVPROPRGM.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgservproprgm_ext as SRVPROPRGM
INNER JOIN v_pc_policyperiod polper
on SRVPROPRGM.BranchID=polper.ID
and SRVPROPRGM.publicid=polper.pcx_imgservproprgm_ext_publicid
and SRVPROPRGM.updatetime=polper.pcx_imgservproprgm_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL) 

# COMMAND ----------

def build_ds_line_cvrbl_IMGTowerEqp(rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgtowereqp_ext_micro_batch),
   pcx_imgtowereqp_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgtowereqp_ext_micro_batch ) 
,v_pcx_imgtowereqp_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgtowereqp_ext.*
			from {rawDB}.pcx_imgtowereqp_ext          
            inner join pcx_imgtowereqp_ext_micro_batch mb  
			   on mb.branchid = pcx_imgtowereqp_ext.branchid 
			where pcx_imgtowereqp_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,TWEQ.publicid as pcx_imgtowereqp_ext_publicid,TWEQ.updatetime as pcx_imgtowereqp_ext_updatetime,
      row_number() over (partition by TWEQ.publicid,TWEQ.updatetime,TWEQ.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(TWEQ.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgtowereqp_ext TWEQ
      JOIN {rawDB}.pc_policyperiod  polper 
        on TWEQ.BranchID = polper.ID 
        and polper.updatetime <= TWEQ.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,TWEQ.publicid as pcx_imgtowereqp_ext_publicid,TWEQ.updatetime as pcx_imgtowereqp_ext_updatetime,
      row_number() over (partition by TWEQ.publicid,polper.updatetime,TWEQ.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(TWEQ.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgtowereqp_ext TWEQ
      JOIN {rawDB}.pc_policyperiod  polper 
        on TWEQ.BranchID = polper.ID 
        and TWEQ.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgtowereqp_ext_publicid,
    p.updatetime as pcx_imgtowereqp_ext_updatetime
  from
    v_pcx_imgtowereqp_ext as   p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
) 
,HRZ_Query as 
( SELECT 
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END  || 'IMGTowerEqp' || '-' || CAST(CAST(TWEQ.FixedID AS INTEGER)  AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE  WHEN status.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ( 'GWPC' || '-' ||CAST (CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound'  THEN  '-'  || 'QT:'||CAST (polper.publicID AS VARCHAR (255)) ELSE ''  END || '-' || 'IMGLine' || '-' || CAST (CAST(TWEQ.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY ,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (TWEQ.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (TWEQ.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
 ' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(TWEQ.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(TWEQ.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
TWEQ.LegacyItemNum AS LGCY_ITEM_NO,
TWEQ.LegacyItemIdentifier AS LEGACY_ITEM_ID,
TWEQ.branchid as SRC_BRANCHID,
TWEQ.fixedid as SRC_FIXEDID,
TWEQ.effectivedate as SRC_EFFECTIVEDATE,
TWEQ.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
TWEQ.createtime as SRC_CREATETIME,
TWEQ.updatetime  as SRC_UPDATETIME,
TWEQ.publicid as SRC_PUBLICID,
TWEQ.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgtowereqp_ext as TWEQ
INNER JOIN v_pc_policyperiod polper
on TWEQ.BranchID=polper.ID
and TWEQ.publicid=polper.pcx_imgtowereqp_ext_publicid
and TWEQ.updatetime=polper.pcx_imgtowereqp_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL) 
  

# COMMAND ----------

def build_ds_line_cvrbl_IMGFineArtsFltr(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """ 
    With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgfineartsfltr_ext_micro_batch),
  pcx_imgfineartsfltr_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgfineartsfltr_ext_micro_batch ) 
     
,v_pcx_imgfineartsfltr_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgfineartsfltr_ext.*
			from {rawDB}.pcx_imgfineartsfltr_ext  pcx_imgfineartsfltr_ext        
            inner join pcx_imgfineartsfltr_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgfineartsfltr_ext.branchid 
			where pcx_imgfineartsfltr_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
 
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,faf.publicid as pcx_imgfineartsfltr_ext_publicid,faf.updatetime as pcx_imgfineartsfltr_ext_updatetime,
      row_number() over (partition by faf.publicid,faf.updatetime,faf.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(faf.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgfineartsfltr_ext faf
      JOIN {rawDB}.pc_policyperiod polper 
        on faf.BranchID = polper.ID 
        and polper.updatetime <= faf.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,faf.publicid as pcx_imgfineartsfltr_ext_publicid,faf.updatetime as pcx_imgfineartsfltr_ext_updatetime,
      row_number() over (partition by faf.publicid,polper.updatetime,faf.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(faf.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgfineartsfltr_ext faf
      JOIN {rawDB}.pc_policyperiod  polper 
        on faf.BranchID = polper.ID 
        and faf.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgfineartsfltr_ext_publicid,
    p.updatetime as pcx_imgfineartsfltr_ext_updatetime
  from
    v_pcx_imgfineartsfltr_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as (
SELECT 
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGFineArtsFltr'|| '-' || CAST (CAST(FAF.FixedID AS INTEGER)AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE ''END) AS POL_KEY,
UPPER ('GWPC'|| '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE ''END || '-' || 'IMGLine' || '-' || CAST(CAST (FAF.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (faf.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (FAF.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT,
COALESCE(FLTCLASS.TYPECODE,' ') AS CLASS_CD ,
COALESCE(FLTCLASS.DESCRIPTION,'Not Defined') AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
COALESCE(FAF.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(FAF.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
FAF.LegacyItemNum  AS LGCY_ITEM_NO, 
FAF.LegacyItemIdentifier AS LEGACY_ITEM_ID,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
FAF.branchid as SRC_BRANCHID,
FAF.fixedid as SRC_FIXEDID,
FAF.effectivedate as SRC_EFFECTIVEDATE,
FAF.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
FAF.createtime as SRC_CREATETIME,
FAF.updatetime  as SRC_UPDATETIME,
FAF.publicid as SRC_PUBLICID,
    FAF.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
           from 
		    
v_pcx_imgfineartsfltr_ext as FAF
        
INNER JOIN v_pc_policyperiod polper
				
ON FAF.BranchID = polper.ID
and FAF.publicid=polper.pcx_imgfineartsfltr_ext_publicid
and FAF.updatetime=polper.pcx_imgfineartsfltr_ext_updatetime
		
INNER JOIN v_pc_job job
ON polper.JobId = job.Id 
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
		
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join 
		(
		select * from
           (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_imgfafloaterclass_ext fltclass     
		    Cross Join Events_Max_Updatetime mb  On fltclass.z_meta_event_timestamp <= mb.mb_max_updatetime)
             where rn=1)
              fltclass
ON faf.floaterclass = fltclass.ID
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL) 

# COMMAND ----------

def build_ds_line_cvrbl_IMGDryClnrPrgm(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgdryclnrprgm_ext_micro_batch),
pcx_imgdryclnrprgm_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgdryclnrprgm_ext_micro_batch ) 
,v_pcx_imgdryclnrprgm_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgdryclnrprgm_ext.*
			from {rawDB}.pcx_imgdryclnrprgm_ext          
            inner join pcx_imgdryclnrprgm_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgdryclnrprgm_ext.branchid 
			where pcx_imgdryclnrprgm_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/********************,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,DCP.publicid as pcx_imgdryclnrprgm_ext_publicid,DCP.updatetime as pcx_imgdryclnrprgm_ext_updatetime,
      row_number() over (partition by DCP.publicid,DCP.updatetime,DCP.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(DCP.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgdryclnrprgm_ext  DCP
      JOIN {rawDB}.pc_policyperiod  polper 
        on DCP.BranchID = polper.ID 
        and polper.updatetime <= DCP.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,DCP.publicid as pcx_imgdryclnrprgm_ext_publicid,DCP.updatetime as pcx_imgdryclnrprgm_ext_updatetime,
      row_number() over (partition by DCP.publicid,polper.updatetime,DCP.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(DCP.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgdryclnrprgm_ext DCP
      JOIN {rawDB}.pc_policyperiod  polper 
        on DCP.BranchID = polper.ID 
        and DCP.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgdryclnrprgm_ext_publicid,
    p.updatetime as pcx_imgdryclnrprgm_ext_updatetime
  from
    v_pcx_imgdryclnrprgm_ext as p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
) 
,HRZ_Query as 
( SELECT 
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END  || 'IMGDryClnrPrgm' || '-' || CAST(CAST(DCP.FixedID AS INTEGER)  AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE  WHEN status.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ( 'GWPC' || '-' ||CAST (CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound'  THEN  '-'  || 'QT:'|| CAST (polper.publicID  AS VARCHAR (255)) ELSE ''  END || '-' || 'IMGLine' || '-' || CAST(CAST (DCP.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY ,
 'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (DCP.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (DCP.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate  ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS, 
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(DCP.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(DCP.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
DCP.LegacyItemNum AS LGCY_ITEM_NO,
DCP.LegacyItemIdentifier AS LEGACY_ITEM_ID,
DCP.branchid as SRC_BRANCHID,
DCP.fixedid as SRC_FIXEDID,
DCP.effectivedate as SRC_EFFECTIVEDATE,
DCP.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
DCP.createtime as SRC_CREATETIME,
DCP.updatetime  as SRC_UPDATETIME,
DCP.publicid as SRC_PUBLICID,
DCP.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgdryclnrprgm_ext as DCP
INNER JOIN v_pc_policyperiod polper
on DCP.BranchID=polper.ID
and DCP.publicid=polper.pcx_imgdryclnrprgm_ext_publicid
and DCP.updatetime=polper.pcx_imgdryclnrprgm_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGLivestock(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imglivestock_ext_micro_batch),
    pcx_imglivestock_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imglivestock_ext_micro_batch ) 
,v_pcx_imglivestock_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imglivestock_ext.*
			from {rawDB}.pcx_imglivestock_ext          
            inner join pcx_imglivestock_ext_micro_batch  mb  
			   on mb.branchid = pcx_imglivestock_ext.branchid 
			where pcx_imglivestock_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,LS.publicid as pcx_imglivestock_ext_publicid,LS.updatetime as pcx_imglivestock_ext_updatetime,
      row_number() over (partition by LS.publicid,LS.updatetime,LS.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(LS.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imglivestock_ext LS
      JOIN {rawDB}.pc_policyperiod polper 
        on LS.BranchID = polper.ID 
        and polper.updatetime <= LS.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,LS.publicid as pcx_imglivestock_ext_publicid,LS.updatetime as pcx_imglivestock_ext_updatetime,
      row_number() over (partition by LS.publicid,polper.updatetime,LS.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(LS.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imglivestock_ext LS
      JOIN {rawDB}.pc_policyperiod  polper 
        on LS.BranchID = polper.ID 
        and LS.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imglivestock_ext_publicid,
    p.updatetime as pcx_imglivestock_ext_updatetime
  from
    v_pcx_imglivestock_ext as  p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
 ,HRZ_Query as ( 
select 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGLivestock' || '-' || CAST (CAST(LS.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY, 
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
UPPER ( 'GWPC' || '-' ||CAST (CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound'  THEN  '-'  || 'QT:'|| CAST (polper.publicID  AS VARCHAR (255)) ELSE ''  END || '-' ||'IMGLine'|| '-' || CAST(CAST (LS.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY , 
'NOKEY' AS  LINE_LOC_KEY,
CAST ( COALESCE (LS.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST ( COALESCE (LS.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,
 'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS, 
 '{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD ,
 'IM' AS LOB_CD ,
 'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
 ' '  AS ANNUAL_PAYROLL_CD, 
 NULL AS ANNUAL_GROSS_RECEIPT_AMT , 
 'Not Defined' AS ANNUAL_PAYROLL_TEXT , 
 NULL AS ANNUAL_RENT_EXP , 
 ' ' AS AVERAGE_JOB_LENGTH_CD , 
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT , 
 ' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
 NULL AS DED_FCTR , 
NULL AS DED_OVR_FCTR , 
 NULL AS DELAY_IN_COMPLETION_FCTR , 
 NULL  AS DELAY_IN_COMPLETION_OVR_FCTR , 
 'U' AS EQP_BRKDWN_OPT_OUT_FL , 
 NULL  AS EQP_LEASE_FROM_OTH_PREM , 
 NULL  AS EQP_LEASE_OTH_PREM_OVR_FCTR , 
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR , 
 'U' AS INS_INC_EXPSR_FL , 
 NULL AS LSE_RENT_EQP_FCTR , 
 NULL AS LSE_RENT_EQP_OVR_FCTR ,
 COALESCE(LS.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(LS.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
LS.LegacyItemNum AS LGCY_ITEM_NO,
LS.LegacyItemIdentifier AS LEGACY_ITEM_ID,
 NULL AS OFF_SITE_SERVER_LOAD_FCTR , 
 NULL  AS OFF_SITE_SERVER_LOAD_OVR_FCTR , 
 'U' AS POWER_GEN_COMPANY_FL , 
 'U' AS POWER_GEN_EQUIP_FL , 
 'U' AS PROD_MACH_INSTALL_FL ,
 'U' AS PROJ_EXCEED_24_MON_FL ,
 ' ' AS PROJECT_TYPE_CD , 
 'Not Defined' AS PROJECT_TYPE_TEXT , 
 'U' AS REFRIG_WAREHOUSING_FL , 
 ' ' AS SALE_OFFICE_BLDG_TYPE_CD , 
 'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT , 
 NULL AS SALE_OFFICE_MOD_FCTR , 
NULL  AS SALE_OFFICE_MOD_OVR_FCTR , 
NULL AS THEFT_DEDUCTIBLE_FCTR , 
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR , 
NULL AS TOTAL_LOAD_FCTR , 
NULL  AS TOTAL_LOAD_OVR_FCTR ,
NULL  AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL  AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
LS.branchid as SRC_BRANCHID,
LS.fixedid as SRC_FIXEDID,
LS.effectivedate as SRC_EFFECTIVEDATE,
LS.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
LS.createtime as SRC_CREATETIME,
LS.updatetime  as SRC_UPDATETIME,
LS.publicid as SRC_PUBLICID,
LS.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
FROM 
v_pcx_imglivestock_ext as LS
INNER JOIN v_pc_policyperiod polper
on LS.BranchID=polper.ID
and LS.publicid=polper.pcx_imglivestock_ext_publicid
and LS.updatetime=polper.pcx_imglivestock_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
		
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
	
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGAccountsRec(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgaccountsrec_ext_micro_batch),
  pcx_imgaccountsrec_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgaccountsrec_ext_micro_batch)
,v_pcx_imgaccountsrec_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgaccountsrec_ext.*
			from {rawDB}.pcx_imgaccountsrec_ext          
            inner join pcx_imgaccountsrec_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgaccountsrec_ext.branchid 
			where pcx_imgaccountsrec_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,ACCREC.publicid as pcx_imgaccountsrec_ext_publicid,ACCREC.updatetime as pcx_imgaccountsrec_ext_updatetime,
      row_number() over (partition by ACCREC.publicid,ACCREC.updatetime,ACCREC.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(ACCREC.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgaccountsrec_ext  ACCREC
      JOIN {rawDB}.pc_policyperiod  polper 
        on ACCREC.BranchID = polper.ID 
        and polper.updatetime <= ACCREC.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,ACCREC.publicid as pcx_imgaccountsrec_ext_publicid,ACCREC.updatetime as pcx_imgaccountsrec_ext_updatetime,
      row_number() over (partition by ACCREC.publicid,polper.updatetime,ACCREC.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(ACCREC.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgaccountsrec_ext ACCREC
      JOIN {rawDB}.pc_policyperiod  polper 
        on ACCREC.BranchID = polper.ID 
        and ACCREC.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgaccountsrec_ext_publicid,
    p.updatetime as pcx_imgaccountsrec_ext_updatetime
  from
    v_pcx_imgaccountsrec_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST(CAST (accrec.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-' ||CAST( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
UPPER ('GWPC' ||'-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (accrec.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (accrec.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (accrec.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(ACCREC.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(ACCREC.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
accrec.LegacyItemNum  AS LGCY_ITEM_NO,
accrec.LegacyItemIdentifier AS LEGACY_ITEM_ID,
accrec.branchid as SRC_BRANCHID,
accrec.fixedid as SRC_FIXEDID,
accrec.effectivedate as SRC_EFFECTIVEDATE,
accrec.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
accrec.createtime as SRC_CREATETIME,
accrec.updatetime  as SRC_UPDATETIME,
accrec.publicid as SRC_PUBLICID,
accrec.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgaccountsrec_ext as accrec
INNER JOIN v_pc_policyperiod polper
on ACCREC.BranchID=polper.ID
and ACCREC.publicid=polper.pcx_imgaccountsrec_ext_publicid
and ACCREC.updatetime=polper.pcx_imgaccountsrec_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGBldrsRisk(  rawDB,CVRBL_TYPE_CD_VAL): 
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgbldrsrisk_ext_micro_batch), 
  pcx_imgbldrsrisk_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgbldrsrisk_ext_micro_batch )
,v_pcx_imgbldrsrisk_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgbldrsrisk_ext.*
			from {rawDB}.pcx_imgbldrsrisk_ext          
            inner join pcx_imgbldrsrisk_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgbldrsrisk_ext.branchid 
			where pcx_imgbldrsrisk_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*****************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,BR.publicid as pcx_imgbldrsrisk_ext_publicid,BR.updatetime as pcx_imgbldrsrisk_ext_updatetime,
      row_number() over (partition by BR.publicid,BR.updatetime,BR.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(BR.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgbldrsrisk_ext  BR
      JOIN {rawDB}.pc_policyperiod  polper 
        on BR.BranchID = polper.ID 
        and polper.updatetime <= BR.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,BR.publicid as pcx_imgbldrsrisk_ext_publicid,BR.updatetime as pcx_imgbldrsrisk_ext_updatetime,
      row_number() over (partition by BR.publicid,polper.updatetime,BR.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(BR.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgbldrsrisk_ext BR
      JOIN {rawDB}.pc_policyperiod  polper 
        on BR.BranchID = polper.ID 
        and BR.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgbldrsrisk_ext_publicid,
    p.updatetime as pcx_imgbldrsrisk_ext_updatetime
  from
    v_pcx_imgbldrsrisk_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}'|| '-' || CAST(CAST (BR.FixedID AS INTEGER)AS VARCHAR (255)))  AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE ''END) AS POL_KEY,
UPPER ('GWPC'|| '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE ''END || '-'|| 'IMGLine' || '-' || CAST(CAST (BR.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (BR.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (BR.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
COALESCE(IMClass.TYPECODE,' ') AS CLASS_CD ,
COALESCE(IMClass.DESCRIPTION,'Not Defined') AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
COALESCE(CASE WHEN BR.OptOutEBCovInd = 1 THEN 'Y' WHEN BR.OptOutEBCovInd = 0 THEN 'N' ELSE CAST (BR.OptOutEBCovInd AS VARCHAR (255))END,'U') AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
BR.HISTPRETAXCREDITFACTOROVER AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
COALESCE(CASE WHEN BR.IncludePGEInd = 1 THEN 'Y' WHEN BR.IncludePGEInd = 0 THEN 'N' ELSE CAST (BR.IncludePGEInd AS VARCHAR (255)) END,'U') AS POWER_GEN_EQUIP_FL ,
COALESCE(CASE WHEN BR.IncludePMIInd = 1 THEN 'Y' WHEN BR.IncludePMIInd = 0 THEN 'N' ELSE CAST (BR.IncludePMIInd AS VARCHAR (255)) END,'U') AS PROD_MACH_INSTALL_FL ,
COALESCE(CASE WHEN BR.EXCEED24MONTHSIND = 1 THEN 'Y'  WHEN BR.EXCEED24MONTHSIND = 0 THEN 'N' ELSE CAST (BR.EXCEED24MONTHSIND AS VARCHAR (255)) END,'U') AS PROJ_EXCEED_24_MON_FL,                            
COALESCE(IMProjTyp.TYPECODE,' ') AS PROJECT_TYPE_CD ,
COALESCE(IMProjTyp.DESCRIPTION,'Not Defined') AS PROJECT_TYPE_TEXT ,
COALESCE(CASE WHEN BR.RefrigWareHousingInd = 1 THEN 'Y' WHEN BR.RefrigWareHousingInd = 0 THEN 'N' ELSE CAST (BR.RefrigWareHousingInd AS VARCHAR (255)) END,'U') AS REFRIG_WAREHOUSING_FL ,
--saloffbldgtype.TYPECODE as   SALE_OFFICE_BLDG_TYPE_CD ,
--saloffbldgtype.Description as   SALE_OFFICE_BLDG_TYPE_TEXT,
COALESCE(saloffbldgtype.TYPECODE,' ') AS SALE_OFFICE_BLDG_TYPE_CD ,
COALESCE(saloffbldgtype.Description,'Not Defined') AS SALE_OFFICE_BLDG_TYPE_TEXT ,
--' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
--'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
BR.SaleOfficeModFactor AS SALE_OFFICE_MOD_FCTR ,
BR.SaleOfficeModFactorOver AS SALE_OFFICE_MOD_OVR_FCTR ,
BR.TheftDedFactor AS THEFT_DEDUCTIBLE_FCTR ,
BR.TheftDedFactorOver AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(BR.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(BR.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
br.LegacyItemNum  AS LGCY_ITEM_NO,
br.LegacyItemIdentifier AS LEGACY_ITEM_ID,
BR.branchid as SRC_BRANCHID,
BR.fixedid as SRC_FIXEDID,
BR.effectivedate as SRC_EFFECTIVEDATE,
BR.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
BR.createtime as SRC_CREATETIME,
BR.updatetime  as SRC_UPDATETIME,
BR.publicid as SRC_PUBLICID,
BR.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgbldrsrisk_ext as BR
INNER JOIN v_pc_policyperiod polper
on BR.BranchID=polper.ID
and BR.publicid=polper.pcx_imgbldrsrisk_ext_publicid
and BR.updatetime=polper.pcx_imgbldrsrisk_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_imgcovpartclass_ext IMClass
Cross Join Events_Max_Updatetime mb  On IMClass.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) IMClass 
on BR.IMGBRiskClass = IMClass.id
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_imgprojecttype_ext IMProjTyp
Cross Join Events_Max_Updatetime mb  On IMProjTyp.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) IMProjTyp 
on BR.ProjectType = IMProjTyp.id
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_imgsalesoffbldgtype_ext saloffbldgtype
Cross Join Events_Max_Updatetime mb  On saloffbldgtype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) saloffbldgtype 
on BR.SalesOffBldgType = saloffbldgtype.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)  

# COMMAND ----------

def build_ds_line_cvrbl_IMGMiscFltr(  rawDB,CVRBL_TYPE_CD_VAL): 
  harmz_query = """
  
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgmiscfltr_ext_micro_batch), 
  pcx_imgmiscfltr_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgmiscfltr_ext_micro_batch )
,v_pcx_imgmiscfltr_ext  as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgmiscfltr_ext.*
			from {rawDB}.pcx_imgmiscfltr_ext          
            inner join pcx_imgmiscfltr_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgmiscfltr_ext.branchid 
			where pcx_imgmiscfltr_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*****************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,MSCFLTR.publicid as pcx_imgmiscfltr_ext_publicid,MSCFLTR.updatetime as pcx_imgmiscfltr_ext_updatetime,
      row_number() over (partition by MSCFLTR.publicid,MSCFLTR.updatetime,MSCFLTR.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(MSCFLTR.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgmiscfltr_ext MSCFLTR 
      JOIN {rawDB}.pc_policyperiod  polper 
        on MSCFLTR.BranchID = polper.ID 
        and polper.updatetime <= MSCFLTR.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,MSCFLTR.publicid as pcx_imgmiscfltr_ext_publicid,MSCFLTR.updatetime as pcx_imgmiscfltr_ext_updatetime,
      row_number() over (partition by MSCFLTR.publicid,polper.updatetime,MSCFLTR.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(MSCFLTR.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgmiscfltr_ext MSCFLTR 
      JOIN {rawDB}.pc_policyperiod  polper 
        on MSCFLTR.BranchID = polper.ID 
        and MSCFLTR.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgmiscfltr_ext_publicid,
    p.updatetime as pcx_imgmiscfltr_ext_updatetime
  from
    v_pcx_imgmiscfltr_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST(CAST (mscfltr.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' ||CAST(CAST (mscfltr.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (mscfltr.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (mscfltr.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(MSCFLTR.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(MSCFLTR.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
MSCFLTR.LegacyItemNum  AS LGCY_ITEM_NO,
MSCFLTR.LegacyItemIdentifier AS LEGACY_ITEM_ID,
MSCFLTR.branchid as SRC_BRANCHID,
MSCFLTR.fixedid as SRC_FIXEDID,
MSCFLTR.effectivedate as SRC_EFFECTIVEDATE,
MSCFLTR.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
MSCFLTR.createtime as SRC_CREATETIME,
MSCFLTR.updatetime  as SRC_UPDATETIME,
MSCFLTR.publicid as SRC_PUBLICID,
MSCFLTR.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgmiscfltr_ext as MSCFLTR 
INNER JOIN v_pc_policyperiod polper
on MSCFLTR.BranchID=polper.ID
and MSCFLTR.publicid=polper.pcx_imgmiscfltr_ext_publicid
and MSCFLTR.updatetime=polper.pcx_imgmiscfltr_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGWarehouse(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgwarehouse_ext_micro_batch),
  pcx_imgwarehouse_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgwarehouse_ext_micro_batch ) 
,v_pcx_imgwarehouse_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgwarehouse_ext.*
			from {rawDB}.pcx_imgwarehouse_ext          
            inner join pcx_imgwarehouse_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgwarehouse_ext.branchid 
			where pcx_imgwarehouse_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,warehouse.publicid as pcx_imgwarehouse_ext_publicid,warehouse.updatetime as pcx_imgwarehouse_ext_updatetime,
      row_number() over (partition by warehouse.publicid,warehouse.updatetime,warehouse.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(warehouse.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgwarehouse_ext warehouse
      JOIN {rawDB}.pc_policyperiod polper 
        on warehouse.BranchID = polper.ID 
        and polper.updatetime <= warehouse.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,warehouse.publicid as pcx_imgwarehouse_ext_publicid,warehouse.updatetime as pcx_imgwarehouse_ext_updatetime,
      row_number() over (partition by warehouse.publicid,polper.updatetime,warehouse.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(warehouse.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgwarehouse_ext warehouse
      JOIN {rawDB}.pc_policyperiod  polper 
        on warehouse.BranchID = polper.ID 
        and warehouse.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgwarehouse_ext_publicid,
    p.updatetime as pcx_imgwarehouse_ext_updatetime
  from
    v_pcx_imgwarehouse_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as (
    SELECT
        UPPER ('GWPC'|| '-'|| CAST(CAST(polper.PeriodID  AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' 
		THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END|| 'IMGWarehouse'|| '-'|| CAST (CAST (warehouse.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
		UPPER ('GWPC'|| '-'||CAST(CAST(polper.PeriodID  AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' 
		THEN '-'|| 'QT:'|| CAST (polper.publicID AS VARCHAR (255))ELSE''END) AS POL_KEY,
		UPPER ('GWPC'|| '-'|| CAST(CAST(polper.PeriodID  AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound'
		THEN'-'|| 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE''END || '-' || 'IMGLine' || '-' ||  CAST(CAST(warehouse.IMGLine AS INTEGER)AS VARCHAR (255))) AS POL_LINE_KEY,
		CAST (COALESCE (warehouse.EffectiveDate, polper.PeriodStart) AS DATE) AS END_EFF_DT,
		CAST (COALESCE (warehouse.ExpirationDate, polper.PeriodEnd) AS DATE) AS END_EXP_DT,
		'GWPC'AS SOURCE_SYSTEM,
        COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate  ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS, 
        'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
        '{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD
        , 'IM' AS LOB_CD
        , 'NOKEY' as LINE_LOC_KEY
        , NULL AS ANNUAL_GROSS_RECEIPT_AMT
		, ' ' AS ANNUAL_PAYROLL_CD
        ,'Not Defined' AS ANNUAL_PAYROLL_TEXT
        , NULL AS ANNUAL_RENT_EXP
		, ' ' AS AVERAGE_JOB_LENGTH_CD
		,'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT
		, ' ' AS CLASS_CD
		, 'Not Defined' AS CLASS_TEXT
		, NULL AS DED_FCTR
		, NULL AS DED_OVR_FCTR
		, NULL AS DELAY_IN_COMPLETION_FCTR
		, NULL AS DELAY_IN_COMPLETION_OVR_FCTR
		, 'U' AS EQP_BRKDWN_OPT_OUT_FL
		, NULL AS EQP_LEASE_FROM_OTH_PREM
		, NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR
		, NULL AS HIST_PRE_TAX_OVR_CRED_FCTR
		, 'U' AS INS_INC_EXPSR_FL
		, NULL AS LSE_RENT_EQP_FCTR
		, NULL AS LSE_RENT_EQP_OVR_FCTR
        , COALESCE(warehouse.LegacyClassCode, ' ') AS LGCY_CL_CD
        , COALESCE(warehouse.LegacyClassDesc, ' ') AS LGCY_CL_DESC
        , warehouse.LegacyItemNum AS LGCY_ITEM_NO
        , warehouse.LegacyItemIdentifier AS LEGACY_ITEM_ID
		, NULL AS OFF_SITE_SERVER_LOAD_FCTR
		, NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR
		, 'U' AS POWER_GEN_COMPANY_FL
		, 'U' AS POWER_GEN_EQUIP_FL
		, 'U' AS PROD_MACH_INSTALL_FL
		, 'U' AS PROJ_EXCEED_24_MON_FL
		, ' ' AS PROJECT_TYPE_CD
		, 'Not Defined' AS PROJECT_TYPE_TEXT
		, 'U' AS REFRIG_WAREHOUSING_FL
		, ' ' AS SALE_OFFICE_BLDG_TYPE_CD
		, 'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT
		, NULL AS SALE_OFFICE_MOD_FCTR
		, NULL AS SALE_OFFICE_MOD_OVR_FCTR
		, NULL AS THEFT_DEDUCTIBLE_FCTR
		, NULL AS THEFT_DEDUCTIBLE_OVR_FCTR
		, NULL AS TOTAL_LOAD_FCTR
		, NULL AS TOTAL_LOAD_OVR_FCTR
		, NULL AS UN_SCH_TOOL_EQP_PREM_FCTR
		, NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
warehouse.branchid as SRC_BRANCHID,
warehouse.fixedid as SRC_FIXEDID,
warehouse.effectivedate as SRC_EFFECTIVEDATE,
warehouse.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID,
warehouse.createtime as SRC_CREATETIME,
warehouse.updatetime  as SRC_UPDATETIME,
warehouse.publicid as SRC_PUBLICID,
warehouse.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,     
job.updatetime as updatetime_tab3
		
FROM 
v_pcx_imgwarehouse_ext as warehouse
INNER JOIN v_pc_policyperiod polper
on warehouse.BranchID=polper.ID
and warehouse.publicid=polper.pcx_imgwarehouse_ext_publicid
and warehouse.updatetime=polper.pcx_imgwarehouse_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
	
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
	
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_im_bldg_proj_IMGInstlFltrBldg(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
 With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imginstlfltrbldg_ext_micro_batch),
  pcx_imginstlfltrbldg_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imginstlfltrbldg_ext_micro_batch ) 
  
,v_pcx_imginstlfltrbldg_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imginstlfltrbldg_ext.*
			from {rawDB}.pcx_imginstlfltrbldg_ext          
            inner join pcx_imginstlfltrbldg_ext_micro_batch  mb  
			   on mb.branchid = pcx_imginstlfltrbldg_ext.branchid 
			where pcx_imginstlfltrbldg_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/********************,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,INSBDG.publicid as pcx_imginstlfltrbldg_ext_publicid,INSBDG.updatetime as pcx_imginstlfltrbldg_ext_updatetime,
      row_number() over (partition by INSBDG.publicid,INSBDG.updatetime,INSBDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(INSBDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imginstlfltrbldg_ext INSBDG
      JOIN {rawDB}.pc_policyperiod polper 
        on INSBDG.BranchID = polper.ID 
        and polper.updatetime <= INSBDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,INSBDG.publicid as pcx_imginstlfltrbldg_ext_publicid,INSBDG.updatetime as pcx_imginstlfltrbldg_ext_updatetime,
      row_number() over (partition by INSBDG.publicid,polper.updatetime,INSBDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(INSBDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imginstlfltrbldg_ext INSBDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on INSBDG.BranchID = polper.ID 
        and INSBDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imginstlfltrbldg_ext_publicid,
    p.updatetime as pcx_imginstlfltrbldg_ext_updatetime
  from
    v_pcx_imginstlfltrbldg_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as (
SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGInstlFltrBldg' || '-' || CAST (CAST(INSBDG.FixedID AS INTEGER)AS VARCHAR (255))) AS IM_BLDG_PROJ_KEY,
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END|| '-IMGInstlFltr-'|| CAST(CAST (INSBDG.IMGInstlFltr AS INTEGER) AS VARCHAR (255) ))AS LINE_CVRBL_KEY,
CASE WHEN INSBDG.IMGBuilding is not null then UPPER('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST(polper.publicID AS VARCHAR(255)) || '-' ELSE ''END ||'IMGBldg'|| '-' || CAST(cast(INSBDG.IMGBuilding AS INTEGER)as varchar(255)))else 'NOKEY' end as LINE_BLDG_KEY, 
CAST ( COALESCE (INSBDG.EffectiveDate, polper.PeriodStart , to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT,
CAST ( COALESCE (INSBDG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,  
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS, 
'GWPC' AS SOURCE_SYSTEM,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD ,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL as ANNUAL_DRY_CLN_STORE_REC_AMT,
NULL AS ANNUAL_DRY_CLN_REC_AMT,
NULL AS ANNUAL_REST_REC_AMT,
NULL AS ANNUAL_REST_STORE_REC_AMT,
NULL AS AVG_CHRG_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_DAYS_ON_PREM_RES_CNT,
NULL AS AVG_DAYS_ON_PREM_DRY_CLN_CNT,
NULL AS AVG_RSTRN_CHRG_PER_ORDER_AMT,
NULL AS AVG_VAL_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_VAL_PER_ORDER_RSTRN_AMT,
NULL AS CLASS_HOUR_LABEL_DESC,
NULL AS COMP_DELAY_FCTR,
NULL AS COMP_DELAY_OVR_FCTR,
NULL AS CONTAINER_DESC,
NULL AS CONTAINER_MANURACTURER_DESC,
NULL AS EXIST_BLDG_MOD_OVR_FCTR,
NULL AS INC_COV_LOAD_FCTR,
NULL AS INC_COV_LOAD_OVR_FCTR,
IMjl.TYPECODE as JOB_LENGTH_CD,
IMjl.Description AS JOB_LENGTH_TEXT,
NULL AS LABEL_ISSUER_DESC,
NULL AS MAX_DRY_CLN_STORE_VAL_AMT,
NULL AS MAX_RSTRN_STORE_VAL_AMT,
NULL AS PROJ_END_DTS,
INSBDG.ProjInstReceipt as PROJ_INSTL_REC_AMT,
NULL AS PROJ_START_DTS,
INSBDG.TotalLoad as TOTAL_LOAD_FCTR,
INSBDG.TotLoadOver as TOTAL_LOAD_OVR_FCTR,
NULL AS MAX_FUR_STORE_EXCS_LIAB,
NULL AS MAX_RSTRN_FUR_STORE_EXCS_LIAB,
INSBDG.branchid as SRC_BRANCHID,
INSBDG.fixedid as SRC_FIXEDID,
INSBDG.effectivedate as SRC_EFFECTIVEDATE,
INSBDG.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
INSBDG.createtime as SRC_CREATETIME,
INSBDG.updatetime  as SRC_UPDATETIME,
INSBDG.publicid as SRC_PUBLICID,
INSBDG.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
FROM 
v_pcx_imginstlfltrbldg_ext as INSBDG
INNER JOIN v_pc_policyperiod polper
on INSBDG.BranchID=polper.ID
and INSBDG.publicid=polper.pcx_imginstlfltrbldg_ext_publicid
and INSBDG.updatetime=polper.pcx_imginstlfltrbldg_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
	
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
		
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
			   
left join 
		(
		select * from
           (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_imgavgjoblength_ext IMjl     
		    Cross Join Events_Max_Updatetime mb  On IMjl.z_meta_event_timestamp <= mb.mb_max_updatetime)
             where rn=1)IMjl
              
ON INSBDG.JobLength = IMjl.ID
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_im_bldg_proj_IMGFineArtsFltrBldg(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
 With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgfineartsfltrbldg_ext_micro_batch),
  pcx_imgfineartsfltrbldg_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgfineartsfltrbldg_ext_micro_batch ) 
  
,v_pcx_imgfineartsfltrbldg_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgfineartsfltrbldg_ext.*
			from {rawDB}.pcx_imgfineartsfltrbldg_ext          
            inner join pcx_imgfineartsfltrbldg_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgfineartsfltrbldg_ext.branchid 
			where pcx_imgfineartsfltrbldg_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,FAFBDG.publicid as pcx_imgfineartsfltrbldg_ext_publicid,FAFBDG.updatetime as pcx_imgfineartsfltrbldg_ext_updatetime,
      row_number() over (partition by FAFBDG.publicid,FAFBDG.updatetime,FAFBDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(FAFBDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgfineartsfltrbldg_ext FAFBDG
      JOIN {rawDB}.pc_policyperiod polper 
        on FAFBDG.BranchID = polper.ID 
        and polper.updatetime <= FAFBDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,FAFBDG.publicid as pcx_imgfineartsfltrbldg_ext_publicid,FAFBDG.updatetime as pcx_imgfineartsfltrbldg_ext_updatetime,
      row_number() over (partition by FAFBDG.publicid,polper.updatetime,FAFBDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(FAFBDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgfineartsfltrbldg_ext FAFBDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAFBDG.BranchID = polper.ID 
        and FAFBDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgfineartsfltrbldg_ext_publicid,
    p.updatetime as pcx_imgfineartsfltrbldg_ext_updatetime
  from
    v_pcx_imgfineartsfltrbldg_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as (
SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGFineArtsFltrBldg' || '-' || CAST (CAST(FAFBDG.FixedID AS INTEGER)AS VARCHAR (255))) AS IM_BLDG_PROJ_KEY,
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END|| '-IMGFineArtsFltr-'|| CAST(CAST (FAFBDG.IMGFineArtsFltr AS INTEGER) AS VARCHAR (255) ))AS LINE_CVRBL_KEY,
CASE WHEN FAFBDG.IMGBuilding is not null then UPPER('GWPC' || '-' || cast(cast(polper.PeriodID as integer) as varchar(255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST(polper.publicID AS VARCHAR(255)) || '-' ELSE ''END ||'IMGBldg'|| '-' || CAST(cast(FAFBDG.IMGBuilding AS INTEGER) as varchar(255)))else 'NOKEY' end as LINE_BLDG_KEY, 
CAST ( COALESCE (FAFBDG.EffectiveDate, polper.PeriodStart , to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT,
CAST ( COALESCE (FAFBDG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,  
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS, 
'GWPC' AS SOURCE_SYSTEM,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD ,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_DRY_CLN_STORE_REC_AMT,
NULL AS ANNUAL_DRY_CLN_REC_AMT,
NULL AS ANNUAL_REST_REC_AMT,
NULL AS ANNUAL_REST_STORE_REC_AMT,
NULL AS AVG_CHRG_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_DAYS_ON_PREM_RES_CNT,
NULL AS AVG_DAYS_ON_PREM_DRY_CLN_CNT,
NULL AS AVG_RSTRN_CHRG_PER_ORDER_AMT,
NULL AS AVG_VAL_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_VAL_PER_ORDER_RSTRN_AMT,
NULL AS CLASS_HOUR_LABEL_DESC,
NULL AS COMP_DELAY_FCTR,
NULL AS COMP_DELAY_OVR_FCTR,
NULL AS CONTAINER_DESC,
NULL AS CONTAINER_MANURACTURER_DESC,
NULL AS EXIST_BLDG_MOD_OVR_FCTR,
NULL AS INC_COV_LOAD_FCTR,
NULL AS INC_COV_LOAD_OVR_FCTR,
NULL as JOB_LENGTH_CD,
NULL AS JOB_LENGTH_TEXT,
NULL AS LABEL_ISSUER_DESC,
NULL AS MAX_DRY_CLN_STORE_VAL_AMT,
NULL AS MAX_RSTRN_STORE_VAL_AMT,
NULL AS PROJ_END_DTS,
NULL as PROJ_INSTL_REC_AMT,
NULL AS PROJ_START_DTS,
NULL as TOTAL_LOAD_FCTR,
NULL as TOTAL_LOAD_OVR_FCTR,
NULL AS MAX_FUR_STORE_EXCS_LIAB,
NULL AS MAX_RSTRN_FUR_STORE_EXCS_LIAB,
FAFBDG.branchid as SRC_BRANCHID,
FAFBDG.fixedid as SRC_FIXEDID,
FAFBDG.effectivedate as SRC_EFFECTIVEDATE,
FAFBDG.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
FAFBDG.createtime as SRC_CREATETIME,
FAFBDG.updatetime  as SRC_UPDATETIME,
FAFBDG.publicid as SRC_PUBLICID,
 FAFBDG.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
FROM 
v_pcx_imgfineartsfltrbldg_ext as FAFBDG
INNER JOIN v_pc_policyperiod polper
on FAFBDG.BranchID=polper.ID
and FAFBDG.publicid=polper.pcx_imgfineartsfltrbldg_ext_publicid
and FAFBDG.updatetime=polper.pcx_imgfineartsfltrbldg_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
	
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
		
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))	   
)


"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_im_bldg_proj_IMGEqupSaleRentBldg(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """

With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgequpsalerentbldg_ext_micro_batch),
  pcx_imgequpsalerentbldg_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgequpsalerentbldg_ext_micro_batch ) 
     
,v_pcx_imgequpsalerentbldg_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgequpsalerentbldg_ext.*
			from {rawDB}.pcx_imgequpsalerentbldg_ext          
            inner join pcx_imgequpsalerentbldg_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgequpsalerentbldg_ext.branchid 
			where pcx_imgequpsalerentbldg_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
 
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,EQPSLSRNTBLDG.publicid as pcx_imgequpsalerentbldg_ext_publicid,EQPSLSRNTBLDG.updatetime as pcx_imgequpsalerentbldg_ext_updatetime,
      row_number() over (partition by EQPSLSRNTBLDG.publicid,EQPSLSRNTBLDG.updatetime,EQPSLSRNTBLDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(EQPSLSRNTBLDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgequpsalerentbldg_ext EQPSLSRNTBLDG
      JOIN {rawDB}.pc_policyperiod polper 
        on EQPSLSRNTBLDG.BranchID = polper.ID 
        and polper.updatetime <= EQPSLSRNTBLDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,EQPSLSRNTBLDG.publicid as pcx_imgequpsalerentbldg_ext_publicid,EQPSLSRNTBLDG.updatetime as pcx_imgequpsalerentbldg_ext_updatetime,
      row_number() over (partition by EQPSLSRNTBLDG.publicid,polper.updatetime,EQPSLSRNTBLDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(EQPSLSRNTBLDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgequpsalerentbldg_ext EQPSLSRNTBLDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on EQPSLSRNTBLDG.BranchID = polper.ID 
        and EQPSLSRNTBLDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgequpsalerentbldg_ext_publicid,
    p.updatetime as pcx_imgequpsalerentbldg_ext_updatetime
  from
    v_pcx_imgequpsalerentbldg_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as (
SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGEqupSaleRentBldg' || '-' || CAST (CAST(EQPSLSRNTBLDG.FixedID AS INTEGER) AS VARCHAR (255))) AS IM_BLDG_PROJ_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-IMGEquipSaleRent-'|| CAST(CAST(EQPSLSRNTBLDG.IMGEquipSaleRent AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
CASE WHEN EQPSLSRNTBLDG.IMGBUILDING IS NOT NULL THEN UPPER('GWPC' || '-' || CAST(CAST(POLPER.PERIODID AS INTEGER)AS VARCHAR(255)) || '-' || CASE WHEN STATUS.TYPECODE <> 'Bound' THEN 'QT:' || CAST(POLPER.PUBLICID AS VARCHAR(255)) || '-' ELSE '' END || 'IMGBldg' || '-' || CAST(CAST(EQPSLSRNTBLDG.IMGBUILDING AS INTEGER) AS VARCHAR(255))) ELSE 'NOKEY' END AS LINE_BLDG_KEY,
CAST ( COALESCE (EQPSLSRNTBLDG.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (EQPSLSRNTBLDG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_DRY_CLN_STORE_REC_AMT,
NULL AS ANNUAL_DRY_CLN_REC_AMT,
NULL AS ANNUAL_REST_REC_AMT,
NULL AS ANNUAL_REST_STORE_REC_AMT,
NULL AS AVG_CHRG_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_DAYS_ON_PREM_RES_CNT,
NULL AS AVG_DAYS_ON_PREM_DRY_CLN_CNT,
NULL AS AVG_RSTRN_CHRG_PER_ORDER_AMT,
NULL AS AVG_VAL_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_VAL_PER_ORDER_RSTRN_AMT,
NULL AS CLASS_HOUR_LABEL_DESC,
NULL AS COMP_DELAY_FCTR,
NULL AS COMP_DELAY_OVR_FCTR,
NULL AS CONTAINER_DESC,
NULL AS CONTAINER_MANURACTURER_DESC,
'{CVRBL_TYPE_CD_VAL}' CVRBL_TYPE_CD,
NULL AS EXIST_BLDG_MOD_OVR_FCTR,
NULL AS  INC_COV_LOAD_FCTR,
NULL AS  INC_COV_LOAD_OVR_FCTR,
NULL AS JOB_LENGTH_CD,
NULL AS JOB_LENGTH_TEXT,
NULL AS LABEL_ISSUER_DESC,
NULL AS MAX_DRY_CLN_STORE_VAL_AMT,
NULL AS MAX_RSTRN_STORE_VAL_AMT,
NULL AS PROJ_END_DTS,
NULL AS PROJ_INSTL_REC_AMT,
NULL AS PROJ_START_DTS,
NULL AS TOTAL_LOAD_FCTR,
NULL AS TOTAL_LOAD_OVR_FCTR,
NULL AS MAX_FUR_STORE_EXCS_LIAB,
NULL AS MAX_RSTRN_FUR_STORE_EXCS_LIAB,
EQPSLSRNTBLDG.branchid as SRC_BRANCHID,
EQPSLSRNTBLDG.fixedid as SRC_FIXEDID,
EQPSLSRNTBLDG.effectivedate as SRC_EFFECTIVEDATE,
EQPSLSRNTBLDG.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
EQPSLSRNTBLDG.createtime as SRC_CREATETIME,
EQPSLSRNTBLDG.updatetime  as SRC_UPDATETIME,
EQPSLSRNTBLDG.publicid as SRC_PUBLICID,
EQPSLSRNTBLDG.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
from v_pcx_imgequpsalerentbldg_ext as EQPSLSRNTBLDG        
INNER JOIN v_pc_policyperiod polper
ON EQPSLSRNTBLDG.BranchID = polper.ID
and EQPSLSRNTBLDG.publicid=polper.pcx_imgequpsalerentbldg_ext_publicid		
and EQPSLSRNTBLDG.updatetime=polper.pcx_imgequpsalerentbldg_ext_updatetime
INNER JOIN v_pc_job job
ON polper.JobId = job.Id 
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
	
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)


"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_im_bldg_proj_IMGElecDataProcBldg(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgelecdataprocbldg_ext_micro_batch),
  pcx_imgelecdataprocbldg_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgelecdataprocbldg_ext_micro_batch ) 
     
,v_pcx_imgelecdataprocbldg_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgelecdataprocbldg_ext.*
			from {rawDB}.pcx_imgelecdataprocbldg_ext          
            inner join pcx_imgelecdataprocbldg_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgelecdataprocbldg_ext.branchid 
			where pcx_imgelecdataprocbldg_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
 
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,EDPBLDG.publicid as pcx_imgelecdataprocbldg_ext_publicid,EDPBLDG.updatetime as pcx_imgelecdataprocbldg_ext_updatetime,
      row_number() over (partition by EDPBLDG.publicid,EDPBLDG.updatetime,EDPBLDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(EDPBLDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgelecdataprocbldg_ext EDPBLDG
      JOIN {rawDB}.pc_policyperiod polper 
        on EDPBLDG.BranchID = polper.ID 
        and polper.updatetime <= EDPBLDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,EDPBLDG.publicid as pcx_imgelecdataprocbldg_ext_publicid,EDPBLDG.updatetime as pcx_imgelecdataprocbldg_ext_updatetime,
      row_number() over (partition by EDPBLDG.publicid,polper.updatetime,EDPBLDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(EDPBLDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgelecdataprocbldg_ext EDPBLDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on EDPBLDG.BranchID = polper.ID 
        and EDPBLDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgelecdataprocbldg_ext_publicid,
    p.updatetime as pcx_imgelecdataprocbldg_ext_updatetime
  from
    v_pcx_imgelecdataprocbldg_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGElecDataProcBldg' || '-' || CAST (CAST(EDPBLDG.FixedID AS INTEGER) AS VARCHAR (255))) AS IM_BLDG_PROJ_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID  AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-IMGElecDataProc-'|| CAST(CAST(EDPBLDG.IMGElecDataProc AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
CASE WHEN EDPBLDG.IMGBUILDING IS NOT NULL THEN UPPER('GWPC' || '-' || CAST(CAST(POLPER.PERIODID AS INTEGER) AS VARCHAR(255)) || '-' || CASE WHEN STATUS.TYPECODE <> 'Bound' THEN 'QT:' || CAST(POLPER.PUBLICID  AS VARCHAR(255)) || '-' ELSE '' END || 'IMGBldg' || '-' || CAST(CAST(EDPBLDG.IMGBUILDING AS INTEGER) AS VARCHAR(255))) ELSE 'NOKEY' END AS LINE_BLDG_KEY,
CAST ( COALESCE (EDPBLDG.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (EDPBLDG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_DRY_CLN_STORE_REC_AMT,
NULL AS ANNUAL_DRY_CLN_REC_AMT,
NULL AS ANNUAL_REST_REC_AMT,
NULL AS ANNUAL_REST_STORE_REC_AMT,
NULL AS AVG_CHRG_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_DAYS_ON_PREM_RES_CNT,
NULL AS AVG_DAYS_ON_PREM_DRY_CLN_CNT,
NULL AS AVG_RSTRN_CHRG_PER_ORDER_AMT,
NULL AS AVG_VAL_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_VAL_PER_ORDER_RSTRN_AMT,
NULL AS CLASS_HOUR_LABEL_DESC,
NULL AS COMP_DELAY_FCTR,
NULL AS COMP_DELAY_OVR_FCTR,
NULL AS CONTAINER_DESC,
NULL AS CONTAINER_MANURACTURER_DESC,
'{CVRBL_TYPE_CD_VAL}' CVRBL_TYPE_CD,
NULL AS EXIST_BLDG_MOD_OVR_FCTR,
EDPBLDG.IncCovLoadStand as INC_COV_LOAD_FCTR,
EDPBLDG.IncCovLoadOver as INC_COV_LOAD_OVR_FCTR,
NULL AS JOB_LENGTH_CD,
NULL AS JOB_LENGTH_TEXT,
NULL AS LABEL_ISSUER_DESC,
NULL AS MAX_DRY_CLN_STORE_VAL_AMT,
NULL AS MAX_RSTRN_STORE_VAL_AMT,
NULL AS PROJ_END_DTS,
NULL AS PROJ_INSTL_REC_AMT,
NULL AS PROJ_START_DTS,
EDPBLDG.TotLoadStand as TOTAL_LOAD_FCTR,
EDPBLDG.TotLoadOver as TOTAL_LOAD_OVR_FCTR,
NULL AS MAX_FUR_STORE_EXCS_LIAB,
NULL AS MAX_RSTRN_FUR_STORE_EXCS_LIAB,
EDPBLDG.branchid as SRC_BRANCHID,
EDPBLDG.fixedid as SRC_FIXEDID,
EDPBLDG.effectivedate as SRC_EFFECTIVEDATE,
EDPBLDG.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
EDPBLDG.createtime as SRC_CREATETIME,
EDPBLDG.updatetime  as SRC_UPDATETIME,
EDPBLDG.publicid as SRC_PUBLICID,
EDPBLDG.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
from v_pcx_imgelecdataprocbldg_ext as EDPBLDG        
INNER JOIN v_pc_policyperiod polper
ON EDPBLDG.BranchID = polper.ID
and EDPBLDG.publicid=polper.pcx_imgelecdataprocbldg_ext_publicid		
and EDPBLDG.updatetime=polper.pcx_imgelecdataprocbldg_ext_updatetime
INNER JOIN v_pc_job job
ON polper.JobId = job.Id 
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
	
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)


"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_im_bldg_proj_IMGDryClnrPrgmBldg(rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """ 
    With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgdryclnrprgmbldg_ext_micro_batch),
  pcx_imgdryclnrprgmbldg_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgdryclnrprgmbldg_ext_micro_batch ) 
     
,v_pcx_imgdryclnrprgmbldg_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgdryclnrprgmbldg_ext.*
			from {rawDB}.pcx_imgdryclnrprgmbldg_ext          
            inner join pcx_imgdryclnrprgmbldg_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgdryclnrprgmbldg_ext.branchid 
			where pcx_imgdryclnrprgmbldg_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
 
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,DCPBLDG.publicid as pcx_imgdryclnrprgmbldg_ext_publicid,DCPBLDG.updatetime as pcx_imgdryclnrprgmbldg_ext_updatetime,
      row_number() over (partition by DCPBLDG.publicid,DCPBLDG.updatetime,DCPBLDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(DCPBLDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgdryclnrprgmbldg_ext DCPBLDG
      JOIN {rawDB}.pc_policyperiod polper 
        on DCPBLDG.BranchID = polper.ID 
        and polper.updatetime <= DCPBLDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,DCPBLDG.publicid as pcx_imgdryclnrprgmbldg_ext_publicid,DCPBLDG.updatetime as pcx_imgdryclnrprgmbldg_ext_updatetime,
      row_number() over (partition by DCPBLDG.publicid,polper.updatetime,DCPBLDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(DCPBLDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgdryclnrprgmbldg_ext DCPBLDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on DCPBLDG.BranchID = polper.ID 
        and DCPBLDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgdryclnrprgmbldg_ext_publicid,
    p.updatetime as pcx_imgdryclnrprgmbldg_ext_updatetime
  from
    v_pcx_imgdryclnrprgmbldg_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END || 'IMGDryClnrPrgmBldg' || '-' || CAST (CAST(DCPBLDG.FixedID  AS INTEGER)AS VARCHAR (255))) AS IM_BLDG_PROJ_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID  AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-IMGDryClnrPrgm-' || CAST(CAST(DCPBLDG.IMGDryClnrPrgm AS INTEGER)AS VARCHAR (255))) AS LINE_CVRBL_KEY,
CASE WHEN DCPBLDG.IMGBUILDING IS NOT NULL THEN UPPER('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN STATUS.TYPECODE <> 'Bound' THEN 'QT:' || CAST(POLPER.PUBLICID AS VARCHAR(255)) || '-' ELSE '' END || 'IMGBldg' || '-' || CAST (CAST(DCPBLDG.IMGBUILDING AS INTEGER) AS VARCHAR(255))) ELSE 'NOKEY' END AS LINE_BLDG_KEY,
CAST ( COALESCE (DCPBLDG.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (DCPBLDG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
DCPBLDG.AnnDryClnRec as ANNUAL_DRY_CLN_STORE_REC_AMT,
DCPBLDG.AnDCRec as ANNUAL_DRY_CLN_REC_AMT,
DCPBLDG.AnResRec as ANNUAL_REST_REC_AMT,
DCPBLDG.AnResStorRec as ANNUAL_REST_STORE_REC_AMT,
DCPBLDG.AvgChrgPerOrderDC as AVG_CHRG_PER_ORDER_DRY_CLN_AMT,
DCPBLDG.AvDayOnPremRes as AVG_DAYS_ON_PREM_RES_CNT,
DCPBLDG.AvgDaysOnPremDC as AVG_DAYS_ON_PREM_DRY_CLN_CNT,
DCPBLDG.AvResChrgPerOrd as AVG_RSTRN_CHRG_PER_ORDER_AMT,
DCPBLDG.AvgValPerOrderDC as AVG_VAL_PER_ORDER_DRY_CLN_AMT,
DCPBLDG.AvValPerOrdRes as AVG_VAL_PER_ORDER_RSTRN_AMT,
NULL AS CLASS_HOUR_LABEL_DESC,
NULL AS COMP_DELAY_FCTR,
NULL AS COMP_DELAY_OVR_FCTR,
NULL AS CONTAINER_DESC,
NULL AS CONTAINER_MANURACTURER_DESC,
'{CVRBL_TYPE_CD_VAL}' CVRBL_TYPE_CD,
NULL AS EXIST_BLDG_MOD_OVR_FCTR,
NULL AS INC_COV_LOAD_FCTR,
NULL AS INC_COV_LOAD_OVR_FCTR,
NULL AS JOB_LENGTH_CD,
NULL AS JOB_LENGTH_TEXT,
NULL AS LABEL_ISSUER_DESC,
DCPBLDG.MaxDCStorValOne as MAX_DRY_CLN_STORE_VAL_AMT,
DCPBLDG.MaxResStorValOne as MAX_RSTRN_STORE_VAL_AMT,
DCPBLDG.MaxFurStorExcLegOne AS MAX_FUR_STORE_EXCS_LIAB ,
DCPBLDG.MaxResFurStorExcLegOne AS MAX_RSTRN_FUR_STORE_EXCS_LIAB ,
NULL AS PROJ_END_DTS,
NULL AS PROJ_INSTL_REC_AMT,
NULL AS PROJ_START_DTS,
NULL AS TOTAL_LOAD_FCTR,
NULL AS TOTAL_LOAD_OVR_FCTR,
DCPBLDG.branchid as SRC_BRANCHID,
DCPBLDG.fixedid as SRC_FIXEDID,
DCPBLDG.effectivedate as SRC_EFFECTIVEDATE,
DCPBLDG.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
DCPBLDG.createtime as SRC_CREATETIME,
DCPBLDG.updatetime  as SRC_UPDATETIME,
DCPBLDG.publicid as SRC_PUBLICID,
DCPBLDG.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
from v_pcx_imgdryclnrprgmbldg_ext as DCPBLDG        
INNER JOIN v_pc_policyperiod polper
ON DCPBLDG.BranchID = polper.ID
and DCPBLDG.publicid=polper.pcx_imgdryclnrprgmbldg_ext_publicid		
and DCPBLDG.updatetime=polper.pcx_imgdryclnrprgmbldg_ext_updatetime
INNER JOIN v_pc_job job
ON polper.JobId = job.Id 
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
	
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)
  

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_im_bldg_proj_IMGBldrsRiskBldg(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgbldrsriskbldg_ext_micro_batch), 
  pcx_imgbldrsriskbldg_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgbldrsriskbldg_ext_micro_batch )
,v_pcx_imgbldrsriskbldg_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgbldrsriskbldg_ext.*
			from {rawDB}.pcx_imgbldrsriskbldg_ext          
            inner join pcx_imgbldrsriskbldg_ext_micro_batch mb  
			   on mb.branchid = pcx_imgbldrsriskbldg_ext.branchid 
			where pcx_imgbldrsriskbldg_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/******************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,BDG.publicid as pcx_imgbldrsriskbldg_ext_publicid,BDG.updatetime as pcx_imgbldrsriskbldg_ext_updatetime,
      row_number() over (partition by BDG.publicid,BDG.updatetime,BDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(BDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgbldrsriskbldg_ext  BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and polper.updatetime <= BDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,BDG.publicid as pcx_imgbldrsriskbldg_ext_publicid,BDG.updatetime as pcx_imgbldrsriskbldg_ext_updatetime,
      row_number() over (partition by BDG.publicid,polper.updatetime,BDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(BDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgbldrsriskbldg_ext BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and BDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgbldrsriskbldg_ext_publicid,
    p.updatetime as pcx_imgbldrsriskbldg_ext_updatetime
  from
    v_pcx_imgbldrsriskbldg_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
( 
SELECT UPPER ('GWPC'|| '-'||CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS  VARCHAR (255)) || '-' ELSE '' END || 'IMGBldrsRiskBldg' || '-' || CAST (CAST(BDG.FixedID AS INTEGER) AS VARCHAR (255))) AS IM_BLDG_PROJ_KEY,
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID  AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-IMGBldrsRisk-' || CAST (CAST(BDG.IMGBldrsRisk AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
case when bdg.IMGBuilding is not null then UPPER('GWPC'|| '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGBldg' || '-' || CAST (CAST(BDG.IMGBuilding AS INTEGER) AS VARCHAR (255))) else 'NOKEY' end as LINE_BLDG_KEY,
CAST ( COALESCE (BDG.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (BDG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL as CLASS_HOUR_LABEL_DESC,
NULL as CONTAINER_DESC,
NULL as CONTAINER_MANURACTURER_DESC,
NULL as LABEL_ISSUER_DESC,
BDG.branchid as SRC_BRANCHID,
BDG.fixedid as SRC_FIXEDID,
BDG.effectivedate as SRC_EFFECTIVEDATE,
BDG.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
BDG.createtime as SRC_CREATETIME,
BDG.updatetime  as SRC_UPDATETIME,
BDG.publicid as SRC_PUBLICID,
BDG.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3,
BDG.DICFactor as COMP_DELAY_FCTR,
BDG.DICFactOver as COMP_DELAY_OVR_FCTR,
BDG.ExisBldgModFactOvr as EXIST_BLDG_MOD_OVR_FCTR,
BDG.IMGBRiskLocProjEnd as PROJ_END_DTS,
BDG.IMGBRiskLocProjStart as PROJ_START_DTS,
BDG.TotalLoad as TOTAL_LOAD_FCTR,
BDG.TotLoadOver as TOTAL_LOAD_OVR_FCTR,
NULL AS ANNUAL_DRY_CLN_STORE_REC_AMT,
NULL AS ANNUAL_DRY_CLN_REC_AMT,
NULL AS ANNUAL_REST_REC_AMT,
NULL AS ANNUAL_REST_STORE_REC_AMT,
NULL AS AVG_CHRG_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_DAYS_ON_PREM_RES_CNT,
NULL AS AVG_DAYS_ON_PREM_DRY_CLN_CNT,
NULL AS AVG_RSTRN_CHRG_PER_ORDER_AMT,
NULL AS AVG_VAL_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_VAL_PER_ORDER_RSTRN_AMT,
NULL AS INC_COV_LOAD_FCTR,
NULL AS INC_COV_LOAD_OVR_FCTR,
NULL AS JOB_LENGTH_CD,
NULL AS JOB_LENGTH_TEXT,
NULL AS MAX_DRY_CLN_STORE_VAL_AMT,
NULL AS MAX_RSTRN_STORE_VAL_AMT,
NULL AS MAX_FUR_STORE_EXCS_LIAB,
NULL AS MAX_RSTRN_FUR_STORE_EXCS_LIAB,
NULL AS PROJ_INSTL_REC_AMT 
FROM 
v_pcx_imgbldrsriskbldg_ext as BDG
INNER JOIN v_pc_policyperiod polper
on BDG.BranchID=polper.ID
and BDG.publicid=polper.pcx_imgbldrsriskbldg_ext_publicid
and BDG.updatetime=polper.pcx_imgbldrsriskbldg_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)


"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_im_bldg_proj_IMGAccountsRecBldg(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgaccountsrecbldg_ext_micro_batch), 
  pcx_imgaccountsrecbldg_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgaccountsrecbldg_ext_micro_batch )
,v_pcx_imgaccountsrecbldg_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgaccountsrecbldg_ext.*
			from {rawDB}.pcx_imgaccountsrecbldg_ext          
            inner join pcx_imgaccountsrecbldg_ext_micro_batch mb  
			   on mb.branchid = pcx_imgaccountsrecbldg_ext.branchid 
			where pcx_imgaccountsrecbldg_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,BDG.publicid as pcx_imgaccountsrecbldg_ext_publicid,BDG.updatetime as pcx_imgaccountsrecbldg_ext_updatetime,
      row_number() over (partition by BDG.publicid,BDG.updatetime,BDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(BDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgaccountsrecbldg_ext  BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and polper.updatetime <= BDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,BDG.publicid as pcx_imgaccountsrecbldg_ext_publicid,BDG.updatetime as pcx_imgaccountsrecbldg_ext_updatetime,
      row_number() over (partition by BDG.publicid,polper.updatetime,BDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(BDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgaccountsrecbldg_ext BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and BDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgaccountsrecbldg_ext_publicid,
    p.updatetime as pcx_imgaccountsrecbldg_ext_updatetime
  from
    v_pcx_imgaccountsrecbldg_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
( 
SELECT UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGAccountsRecBldg' || '-' || CAST (CAST(BDG.FixedID AS INTEGER) AS VARCHAR (255)) ) AS IM_BLDG_PROJ_KEY,
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-IMGAccountsRec-' || CAST (CAST(BDG.IMGAccountsRec AS INTEGER) AS VARCHAR (255)) ) AS LINE_CVRBL_KEY,
case when bdg.IMGBuilding is not null then UPPER('GWPC'|| '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGBldg' || '-' || CAST (CAST(BDG.IMGBuilding AS INTEGER) AS VARCHAR (255))) else 'NOKEY' end as LINE_BLDG_KEY,
CAST ( COALESCE (BDG.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (BDG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
BDG.ClassOrHourLabel as CLASS_HOUR_LABEL_DESC,
BDG.ContainerDesc as CONTAINER_DESC,
BDG.ContainerManf as CONTAINER_MANURACTURER_DESC,
BDG.IssuerOfLabel as LABEL_ISSUER_DESC,
BDG.branchid  as SRC_BRANCHID,
BDG.fixedid as SRC_FIXEDID,
BDG.effectivedate as SRC_EFFECTIVEDATE,
BDG.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
BDG.createtime as SRC_CREATETIME,
BDG.updatetime  as SRC_UPDATETIME,
BDG.publicid as SRC_PUBLICID,
BDG.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3,
NULL AS COMP_DELAY_FCTR,
NULL AS COMP_DELAY_OVR_FCTR,
NULL AS ANNUAL_DRY_CLN_STORE_REC_AMT,
NULL AS ANNUAL_DRY_CLN_REC_AMT,
NULL AS ANNUAL_REST_REC_AMT,
NULL AS ANNUAL_REST_STORE_REC_AMT,
NULL AS AVG_CHRG_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_DAYS_ON_PREM_RES_CNT,
NULL AS AVG_DAYS_ON_PREM_DRY_CLN_CNT,
NULL AS AVG_RSTRN_CHRG_PER_ORDER_AMT,
NULL AS AVG_VAL_PER_ORDER_DRY_CLN_AMT,
NULL AS AVG_VAL_PER_ORDER_RSTRN_AMT,
NULL AS EXIST_BLDG_MOD_OVR_FCTR,
NULL AS INC_COV_LOAD_FCTR,
NULL AS INC_COV_LOAD_OVR_FCTR,
NULL AS JOB_LENGTH_CD,
NULL AS JOB_LENGTH_TEXT,
NULL AS MAX_DRY_CLN_STORE_VAL_AMT,
NULL AS MAX_RSTRN_STORE_VAL_AMT,
NULL AS PROJ_END_DTS,
NULL AS PROJ_INSTL_REC_AMT,
NULL AS PROJ_START_DTS,
NULL AS MAX_FUR_STORE_EXCS_LIAB,
NULL AS MAX_RSTRN_FUR_STORE_EXCS_LIAB,
NULL AS TOTAL_LOAD_FCTR,
NULL AS TOTAL_LOAD_OVR_FCTR 
FROM 
v_pcx_imgaccountsrecbldg_ext as BDG
INNER JOIN v_pc_policyperiod polper
on BDG.BranchID=polper.ID
and BDG.publicid=polper.pcx_imgaccountsrecbldg_ext_publicid
and BDG.updatetime=polper.pcx_imgaccountsrecbldg_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGPods(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgpods_ext_micro_batch),
  pcx_imgpods_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgpods_ext_micro_batch ) 
,v_pcx_imgpods_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgpods_ext.*
			from {rawDB}.pcx_imgpods_ext          
            inner join pcx_imgpods_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgpods_ext.branchid 
			where pcx_imgpods_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,pods.publicid as pcx_imgpods_ext_publicid,pods.updatetime as pcx_imgpods_ext_updatetime,
      row_number() over (partition by pods.publicid,pods.updatetime,pods.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(pods.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgpods_ext pods
      JOIN {rawDB}.pc_policyperiod polper 
        on pods.BranchID = polper.ID 
        and polper.updatetime <= pods.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,pods.publicid as pcx_imgpods_ext_publicid,pods.updatetime as pcx_imgpods_ext_updatetime,
      row_number() over (partition by pods.publicid,polper.updatetime,pods.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(pods.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgpods_ext pods
      JOIN {rawDB}.pc_policyperiod  polper 
        on pods.BranchID = polper.ID 
        and pods.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgpods_ext_publicid,
    p.updatetime as pcx_imgpods_ext_updatetime
  from
    v_pcx_imgpods_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
 ,v_pctl_job as 
(
select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as (
SELECT  
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END  || 'IMGPods' || '-' || CAST(CAST(pods.FixedID AS INTEGER)  AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE  WHEN status.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
'NOKEY' AS LINE_LOC_KEY  ,
COALESCE(UPPER ( 'GWPC' || '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))  || CASE WHEN status.TypeCode <> 'Bound' THEN '-QT:' || CAST (polper.publicID AS VARCHAR (255))   ELSE  ''  END || '-'|| 'IMGLine' || '-' || CAST(CAST(pods.IMGLine AS INTEGER)  AS VARCHAR (255))), 'NOKEY')  AS POL_LINE_KEY,
CAST ( COALESCE (pods.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT,
CAST ( COALESCE (pods.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)  AS END_EXP_DT,
'GWPC'  AS SOURCE_SYSTEM,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS
,'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD 
,'IM' AS LOB_CD
,NULL AS ANNUAL_GROSS_RECEIPT_AMT
,' '  AS ANNUAL_PAYROLL_CD
,'Not Defined' AS ANNUAL_PAYROLL_TEXT
, NULL AS ANNUAL_RENT_EXP
,' ' AS AVERAGE_JOB_LENGTH_CD
,'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT
,' ' AS CLASS_CD
,'Not Defined' AS CLASS_TEXT
,NULL AS DED_FCTR
,NULL AS DED_OVR_FCTR
,NULL AS DELAY_IN_COMPLETION_FCTR
,NULL AS DELAY_IN_COMPLETION_OVR_FCTR
,'U'  AS EQP_BRKDWN_OPT_OUT_FL
,NULL AS EQP_LEASE_FROM_OTH_PREM
,NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR
,NULL AS HIST_PRE_TAX_OVR_CRED_FCTR
,'U'  AS INS_INC_EXPSR_FL
,NULL AS LSE_RENT_EQP_FCTR
,NULL AS LSE_RENT_EQP_OVR_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR
,'U'  AS POWER_GEN_COMPANY_FL
,'U'  AS POWER_GEN_EQUIP_FL
,'U'  AS PROD_MACH_INSTALL_FL
,'U'  AS PROJ_EXCEED_24_MON_FL
,' '  AS PROJECT_TYPE_CD
,'Not Defined' AS PROJECT_TYPE_TEXT
,'U'  AS REFRIG_WAREHOUSING_FL
,' '  AS SALE_OFFICE_BLDG_TYPE_CD
,'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT
,NULL AS SALE_OFFICE_MOD_FCTR
,NULL AS SALE_OFFICE_MOD_OVR_FCTR
,NULL AS THEFT_DEDUCTIBLE_FCTR
,NULL AS THEFT_DEDUCTIBLE_OVR_FCTR
,NULL AS  TOTAL_LOAD_FCTR
,NULL AS TOTAL_LOAD_OVR_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR
,COALESCE(pods.LegacyClassCode, ' ') AS LGCY_CL_CD 
,COALESCE(pods.LegacyClassDesc , ' ') AS LGCY_CL_DESC 
,pods.LegacyItemNum  AS LGCY_ITEM_NO,
pods.LegacyItemIdentifier AS LEGACY_ITEM_ID,
pods.branchid as SRC_BRANCHID,
pods.fixedid as SRC_FIXEDID,
pods.effectivedate as SRC_EFFECTIVEDATE,
pods.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
pods.createtime as SRC_CREATETIME,
pods.updatetime  as SRC_UPDATETIME,
pods.publicid as SRC_PUBLICID,
pods.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
FROM 
v_pcx_imgpods_ext as pods
INNER JOIN v_pc_policyperiod polper
on pods.BranchID=polper.ID
and pods.publicid=polper.pcx_imgpods_ext_publicid
and pods.updatetime=polper.pcx_imgpods_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
		
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
		
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGRigger(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgrigger_ext_micro_batch),
  pcx_imgrigger_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgrigger_ext_micro_batch )
,v_pcx_imgrigger_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgrigger_ext.*
			from {rawDB}.pcx_imgrigger_ext pcx_imgrigger_ext        
            inner join pcx_imgrigger_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgrigger_ext.branchid 
			where pcx_imgrigger_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,RIGLIAB.publicid as pcx_imgrigger_ext_publicid,RIGLIAB.updatetime as pcx_imgrigger_ext_updatetime,
      row_number() over (partition by RIGLIAB.publicid,RIGLIAB.updatetime,RIGLIAB.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(RIGLIAB.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgrigger_ext  RIGLIAB
      JOIN {rawDB}.pc_policyperiod  polper 
        on RIGLIAB.BranchID = polper.ID 
        and polper.updatetime <= RIGLIAB.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,RIGLIAB.publicid as pcx_imgrigger_ext_publicid,RIGLIAB.updatetime as pcx_imgrigger_ext_updatetime,
      row_number() over (partition by RIGLIAB.publicid,polper.updatetime,RIGLIAB.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(RIGLIAB.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgrigger_ext RIGLIAB
      JOIN {rawDB}.pc_policyperiod  polper 
        on RIGLIAB.BranchID = polper.ID 
        and RIGLIAB.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgrigger_ext_publicid,
    p.updatetime as pcx_imgrigger_ext_updatetime
  from
    v_pcx_imgrigger_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(   
SELECT 
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END ||'{CVRBL_TYPE_CD_VAL}'||'-'||CAST(CAST(RIG.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255))
 ELSE  '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255))
 ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (RIG.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (RIG.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST ( COALESCE (RIG.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT , 
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT , 
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD 
,NULL AS ANNUAL_RENT_EXP
, ' ' AS AVERAGE_JOB_LENGTH_CD
,'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT
, ' ' AS CLASS_CD
,'Not Defined' AS CLASS_TEXT
,NULL AS DED_FCTR
,NULL AS DED_OVR_FCTR
,NULL AS DELAY_IN_COMPLETION_FCTR
,NULL AS DELAY_IN_COMPLETION_OVR_FCTR
, 'U' AS EQP_BRKDWN_OPT_OUT_FL
,NULL AS EQP_LEASE_FROM_OTH_PREM
,NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR
,NULL AS HIST_PRE_TAX_OVR_CRED_FCTR
, 'U' AS INS_INC_EXPSR_FL
,NULL AS LSE_RENT_EQP_FCTR
,NULL AS LSE_RENT_EQP_OVR_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR
, 'U' AS POWER_GEN_COMPANY_FL
, 'U' AS POWER_GEN_EQUIP_FL
, 'U' AS PROD_MACH_INSTALL_FL
, 'U' AS PROJ_EXCEED_24_MON_FL
, ' ' AS PROJECT_TYPE_CD
,'Not Defined' AS PROJECT_TYPE_TEXT
, 'U' AS REFRIG_WAREHOUSING_FL
, ' ' AS SALE_OFFICE_BLDG_TYPE_CD
,'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT
,NULL AS SALE_OFFICE_MOD_FCTR
,NULL AS SALE_OFFICE_MOD_OVR_FCTR
,NULL AS THEFT_DEDUCTIBLE_FCTR
,NULL AS THEFT_DEDUCTIBLE_OVR_FCTR
,NULL AS TOTAL_LOAD_FCTR
,NULL AS TOTAL_LOAD_OVR_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR
,COALESCE(RIG.LegacyClassCode, ' ') AS LGCY_CL_CD 
,COALESCE(RIG.LegacyClassDesc, ' ') AS LGCY_CL_DESC 
,RIG.LegacyItemNum AS LGCY_ITEM_NO
,RIG.LegacyItemIdentifier AS LEGACY_ITEM_ID
,RIG.branchid as SRC_BRANCHID
,RIG.fixedid as SRC_FIXEDID
,RIG.effectivedate as SRC_EFFECTIVEDATE
,RIG.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,RIG.createtime as SRC_CREATETIME
,RIG.updatetime  as SRC_UPDATETIME
,RIG.publicid as SRC_PUBLICID
,RIG.updatetime as updatetime_tab1
,polper.updatetime as updatetime_tab2
,job.updatetime as updatetime_tab3 
FROM 
v_pcx_imgrigger_ext as RIG
INNER JOIN v_pc_policyperiod polper
on RIG.BranchID=polper.ID
and RIG.publicid=polper.pcx_imgrigger_ext_publicid
and RIG.updatetime=polper.pcx_imgrigger_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGSchedPropFltr(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgschedpropfltr_ext_micro_batch)
  ,pcx_imgschedpropfltr_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgschedpropfltr_ext_micro_batch )
,v_pcx_imgschedpropfltr_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgschedpropfltr_ext.*
			from {rawDB}.pcx_imgschedpropfltr_ext          
            inner join pcx_imgschedpropfltr_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgschedpropfltr_ext.branchid 
			where pcx_imgschedpropfltr_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,SCHPROPFLTR.publicid as pcx_imgschedpropfltr_ext_publicid,SCHPROPFLTR.updatetime as pcx_imgschedpropfltr_ext_updatetime,
      row_number() over (partition by SCHPROPFLTR.publicid,SCHPROPFLTR.updatetime,SCHPROPFLTR.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(SCHPROPFLTR.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgschedpropfltr_ext  SCHPROPFLTR
      JOIN {rawDB}.pc_policyperiod  polper 
        on SCHPROPFLTR.BranchID = polper.ID 
        and polper.updatetime <= SCHPROPFLTR.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,SCHPROPFLTR.publicid as pcx_imgschedpropfltr_ext_publicid,SCHPROPFLTR.updatetime as pcx_imgschedpropfltr_ext_updatetime,
      row_number() over (partition by SCHPROPFLTR.publicid,polper.updatetime,SCHPROPFLTR.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(SCHPROPFLTR.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgschedpropfltr_ext SCHPROPFLTR
      JOIN {rawDB}.pc_policyperiod  polper 
        on SCHPROPFLTR.BranchID = polper.ID 
        and SCHPROPFLTR.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgschedpropfltr_ext_publicid,
    p.updatetime as pcx_imgschedpropfltr_ext_updatetime
  from
    v_pcx_imgschedpropfltr_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST (CAST(SCHPROPFLTR.FixedID AS INTEGER)AS VARCHAR (255)))  AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'||CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (SCHPROPFLTR.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (SCHPROPFLTR.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (SCHPROPFLTR.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(SCHPROPFLTR.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(SCHPROPFLTR.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
SCHPROPFLTR.LegacyItemNum  AS LGCY_ITEM_NO,
SCHPROPFLTR.LegacyItemIdentifier AS LEGACY_ITEM_ID,
SCHPROPFLTR.branchid as SRC_BRANCHID,
SCHPROPFLTR.fixedid as SRC_FIXEDID,
SCHPROPFLTR.effectivedate as SRC_EFFECTIVEDATE,
SCHPROPFLTR.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
SCHPROPFLTR.createtime as SRC_CREATETIME,
SCHPROPFLTR.updatetime  as SRC_UPDATETIME,
SCHPROPFLTR.publicid as SRC_PUBLICID,
SCHPROPFLTR.updatetime  as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgschedpropfltr_ext as SCHPROPFLTR
INNER JOIN v_pc_policyperiod polper
on SCHPROPFLTR.BranchID=polper.ID
and SCHPROPFLTR.publicid=polper.pcx_imgschedpropfltr_ext_publicid
and SCHPROPFLTR.updatetime=polper.pcx_imgschedpropfltr_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGContrsEqp(  rawDB,CVRBL_TYPE_CD_VAL):
  print("**************In build_ds_line_cvrbl_IMGContrsEqp query function********************","\n")
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgcontrseqp_ext_micro_batch), 
  pcx_imgcontrseqp_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgcontrseqp_ext_micro_batch )
,v_pcx_imgcontrseqp_ext  as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgcontrseqp_ext.*
			from {rawDB}.pcx_imgcontrseqp_ext          
            inner join pcx_imgcontrseqp_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgcontrseqp_ext.branchid 
			where pcx_imgcontrseqp_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,CONTREQP.publicid as pcx_imgcontrseqp_ext_publicid,CONTREQP.updatetime as pcx_imgcontrseqp_ext_updatetime,
      row_number() over (partition by CONTREQP.publicid,CONTREQP.updatetime,CONTREQP.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(CONTREQP.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgcontrseqp_ext  CONTREQP
      JOIN {rawDB}.pc_policyperiod  polper 
        on CONTREQP.BranchID = polper.ID 
        and polper.updatetime <= CONTREQP.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,CONTREQP.publicid as pcx_imgbldrsrisk_ext_publicid,CONTREQP.updatetime as pcx_imgcontrseqp_ext_updatetime,
      row_number() over (partition by CONTREQP.publicid,polper.updatetime,CONTREQP.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(CONTREQP.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgcontrseqp_ext CONTREQP
      JOIN {rawDB}.pc_policyperiod  polper 
        on CONTREQP.BranchID = polper.ID 
        and CONTREQP.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgcontrseqp_ext_publicid,
    p.updatetime as pcx_imgcontrseqp_ext_updatetime
  from
    v_pcx_imgcontrseqp_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST(CAST (CONTREQP.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END ||'-' ||'IMGLine' || '-' || CAST(CAST (CONTREQP.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (CONTREQP.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (CONTREQP.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
'IM' AS LOB_CD ,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
COALESCE(CONTREQP.ANNUALRENTEXP,NULL) AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
CONTREQP.DEDFACTOR AS DED_FCTR,
CONTREQP.DEDFACTOROVER AS DED_OVR_FCTR,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
CONTREQP.EQLEASEFROMOTHERPREM AS EQP_LEASE_FROM_OTH_PREM,
CONTREQP.EQLEASEFROMOTHERPREMOVER AS EQP_LEASE_OTH_PREM_OVR_FCTR,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
CONTREQP.LEASERENTEQRATE AS LSE_RENT_EQP_FCTR ,
CONTREQP.LEASERENTEQRATEOVER AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
CONTREQP.UNSCHEDTOOLEQPREM AS UN_SCH_TOOL_EQP_PREM_FCTR ,
CONTREQP.UNSCHEDTOOLEQPREMOVER AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE (CONTREQP.LegacyClassCode,' ') AS LGCY_CL_CD,
COALESCE (CONTREQP.LegacyClassDesc,' ') AS lgcy_cl_DESC,
CONTREQP.LegacyItemNum AS LGCY_ITEM_NO,
CONTREQP.LegacyItemIdentifier AS LEGACY_ITEM_ID,
CONTREQP.branchid as SRC_BRANCHID,
CONTREQP.fixedid as SRC_FIXEDID,
CONTREQP.effectivedate as SRC_EFFECTIVEDATE,
CONTREQP.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
CONTREQP.createtime as SRC_CREATETIME,
CONTREQP.updatetime  as SRC_UPDATETIME,
CONTREQP.publicid as SRC_PUBLICID,
CONTREQP.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgcontrseqp_ext as CONTREQP
INNER JOIN v_pc_policyperiod polper
on CONTREQP.BranchID=polper.ID
and CONTREQP.publicid=polper.pcx_imgcontrseqp_ext_publicid
and CONTREQP.updatetime=polper.pcx_imgcontrseqp_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGDryCleaner(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgdrycleaner_ext_micro_batch), 
  pcx_imgdrycleaner_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgdrycleaner_ext_micro_batch )
,v_pcx_imgdrycleaner_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgdrycleaner_ext.*
			from {rawDB}.pcx_imgdrycleaner_ext          
            inner join pcx_imgdrycleaner_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgdrycleaner_ext.branchid 
			where pcx_imgdrycleaner_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/***************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,dc.publicid as pcx_imgdrycleaner_ext_publicid,dc.updatetime as pcx_imgdrycleaner_ext_updatetime,
      row_number() over (partition by dc.publicid,dc.updatetime,dc.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(dc.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgdrycleaner_ext  dc
      JOIN {rawDB}.pc_policyperiod  polper 
        on dc.BranchID = polper.ID 
        and polper.updatetime <= dc.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,dc.publicid as pcx_imgdrycleaner_ext_publicid,dc.updatetime as pcx_imgdrycleaner_ext_updatetime,
      row_number() over (partition by dc.publicid,polper.updatetime,dc.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(dc.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgdrycleaner_ext dc
      JOIN {rawDB}.pc_policyperiod  polper 
        on dc.BranchID = polper.ID 
        and dc.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgdrycleaner_ext_publicid,
    p.updatetime as pcx_imgdrycleaner_ext_updatetime
  from
    v_pcx_imgdrycleaner_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
, HRZ_Query AS (SELECT 
UPPER ('GWPC'|| '-'||CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST(polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGDryCleaner'|| '-' || CAST(CAST(dc.FixedID AS INTEGER)  AS VARCHAR (255)))  AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'|| CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE ''END) AS POL_KEY,
UPPER ('GWPC'|| '-' || CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:'|| CAST (polper.publicID AS VARCHAR (255)) ELSE ''END || '-'|| 'IMGLine' || '-' || CAST(CAST (dc.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (dc.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (dc.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(dc.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(dc.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
dc.LegacyItemNum  AS LGCY_ITEM_NO,
dc.LegacyItemIdentifier AS LEGACY_ITEM_ID,
dc.branchid as SRC_BRANCHID,
dc.fixedid as SRC_FIXEDID,
dc.effectivedate as SRC_EFFECTIVEDATE,
dc.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
dc.createtime as SRC_CREATETIME,
dc.updatetime  as SRC_UPDATETIME,
dc.publicid as SRC_PUBLICID,
dc.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
FROM 
v_pcx_imgdrycleaner_ext as dc
INNER JOIN v_pc_policyperiod polper
on dc.BranchID=polper.ID
and dc.publicid=polper.pcx_imgdrycleaner_ext_publicid
and dc.updatetime=polper.pcx_imgdrycleaner_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)
 
"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGElecDataProc(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgelecdataproc_ext_micro_batch), 
  pcx_imgelecdataproc_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgelecdataproc_ext_micro_batch )
,v_pcx_imgelecdataproc_ext  as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgelecdataproc_ext.*
			from {rawDB}.pcx_imgelecdataproc_ext          
            inner join pcx_imgelecdataproc_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgelecdataproc_ext.branchid 
			where pcx_imgelecdataproc_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/********************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,EDP.publicid as pcx_imgelecdataproc_ext_publicid,EDP.updatetime as pcx_imgelecdataproc_ext_updatetime,
      row_number() over (partition by EDP.publicid,EDP.updatetime,EDP.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(EDP.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgelecdataproc_ext EDP 
      JOIN {rawDB}.pc_policyperiod  polper 
        on EDP.BranchID = polper.ID 
        and polper.updatetime <= EDP.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,EDP.publicid as pcx_imgelecdataproc_ext_publicid,EDP.updatetime as pcx_imgelecdataproc_ext_updatetime,
      row_number() over (partition by EDP.publicid,polper.updatetime,EDP.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(EDP.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgelecdataproc_ext EDP 
      JOIN {rawDB}.pc_policyperiod  polper 
        on EDP.BranchID = polper.ID 
        and EDP.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgelecdataproc_ext_publicid,
    p.updatetime as pcx_imgelecdataproc_ext_updatetime
  from
    v_pcx_imgelecdataproc_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST(CAST (EDP.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (EDP.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (EDP.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (EDP.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
'IM' AS LOB_CD ,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
case when EDP.IsIncExpoInLimit = 1 then 'Y' when EDP.IsIncExpoInLimit = 0 then 'N' else 'U' end AS INS_INC_EXPSR_FL,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
EDP.OffSiteServLoadStand AS OFF_SITE_SERVER_LOAD_FCTR,
EDP.OffSiteServLoadOver AS OFF_SITE_SERVER_LOAD_OVR_FCTR,
case when EDP.IsPowerGenComp = 1 then 'Y' when EDP.IsPowerGenComp = 0 then 'N' else 'U' end AS POWER_GEN_COMPANY_FL,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(EDP.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(EDP.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
EDP.LegacyItemNum  AS LGCY_ITEM_NO,
EDP.LegacyItemIdentifier AS LEGACY_ITEM_ID,
EDP.branchid as SRC_BRANCHID,
EDP.fixedid as SRC_FIXEDID,
EDP.effectivedate as SRC_EFFECTIVEDATE,
EDP.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
EDP.createtime as SRC_CREATETIME,
EDP.updatetime  as SRC_UPDATETIME,
EDP.publicid as SRC_PUBLICID,
EDP.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgelecdataproc_ext as EDP 
INNER JOIN v_pc_policyperiod polper
on EDP.BranchID=polper.ID
and EDP.publicid=polper.pcx_imgelecdataproc_ext_publicid
and EDP.updatetime=polper.pcx_imgelecdataproc_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGEquipSaleRent(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgequipsalerent_ext_micro_batch),
  pcx_imgequipsalerent_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgequipsalerent_ext_micro_batch )
,v_pcx_imgequipsalerent_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgequipsalerent_ext.*
			from {rawDB}.pcx_imgequipsalerent_ext   pcx_imgequipsalerent_ext       
            inner join pcx_imgequipsalerent_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgequipsalerent_ext.branchid 
			where pcx_imgequipsalerent_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/***********************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,EQPSLSRNT.publicid as pcx_imgequipsalerent_ext_publicid,EQPSLSRNT.updatetime as pcx_imgequipsalerent_ext_updatetime,
      row_number() over (partition by EQPSLSRNT.publicid,EQPSLSRNT.updatetime,EQPSLSRNT.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(EQPSLSRNT.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgequipsalerent_ext  EQPSLSRNT
      JOIN {rawDB}.pc_policyperiod  polper 
        on EQPSLSRNT.BranchID = polper.ID 
        and polper.updatetime <= EQPSLSRNT.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,EQPSLSRNT.publicid as pcx_imgequipsalerent_ext_publicid,EQPSLSRNT.updatetime as pcx_imgequipsalerent_ext_updatetime,
      row_number() over (partition by EQPSLSRNT.publicid,polper.updatetime,EQPSLSRNT.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(EQPSLSRNT.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgequipsalerent_ext EQPSLSRNT
      JOIN {rawDB}.pc_policyperiod  polper 
        on EQPSLSRNT.BranchID = polper.ID 
        and EQPSLSRNT.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgequipsalerent_ext_publicid,
    p.updatetime as pcx_imgequipsalerent_ext_updatetime
  from
    v_pcx_imgequipsalerent_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END ||'{CVRBL_TYPE_CD_VAL}'||'-'||CAST(CAST(EDC.FixedID AS INTEGER)AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER)AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255))
 ELSE  '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255))
 ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (EDC.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (EDC.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST ( COALESCE (EDC.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT , 
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT , 
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD 
,NULL AS ANNUAL_RENT_EXP
, ' ' AS AVERAGE_JOB_LENGTH_CD
,'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT
, ' ' AS CLASS_CD
,'Not Defined' AS CLASS_TEXT
,NULL AS DED_FCTR
,NULL AS DED_OVR_FCTR
,NULL AS DELAY_IN_COMPLETION_FCTR
,NULL AS DELAY_IN_COMPLETION_OVR_FCTR
, 'U' AS EQP_BRKDWN_OPT_OUT_FL
,NULL AS EQP_LEASE_FROM_OTH_PREM
,NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR
,NULL AS HIST_PRE_TAX_OVR_CRED_FCTR
, 'U' AS INS_INC_EXPSR_FL
,NULL AS LSE_RENT_EQP_FCTR
,NULL AS LSE_RENT_EQP_OVR_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR
, 'U' AS POWER_GEN_COMPANY_FL
, 'U' AS POWER_GEN_EQUIP_FL
, 'U' AS PROD_MACH_INSTALL_FL
, 'U' AS PROJ_EXCEED_24_MON_FL
, ' ' AS PROJECT_TYPE_CD
,'Not Defined' AS PROJECT_TYPE_TEXT
, 'U' AS REFRIG_WAREHOUSING_FL
, ' ' AS SALE_OFFICE_BLDG_TYPE_CD
,'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT
,NULL AS SALE_OFFICE_MOD_FCTR
,NULL AS SALE_OFFICE_MOD_OVR_FCTR
,NULL AS THEFT_DEDUCTIBLE_FCTR
,NULL AS THEFT_DEDUCTIBLE_OVR_FCTR
,NULL AS TOTAL_LOAD_FCTR
,NULL AS TOTAL_LOAD_OVR_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR
,COALESCE(EDC.LegacyClassCode, ' ') AS LGCY_CL_CD 
,COALESCE(EDC.LegacyClassDesc, ' ') AS LGCY_CL_DESC 
,EDC.LegacyItemNum AS LGCY_ITEM_NO
,EDC.LegacyItemIdentifier AS LEGACY_ITEM_ID
,EDC.branchid as SRC_BRANCHID
,EDC.fixedid as SRC_FIXEDID
,EDC.effectivedate as SRC_EFFECTIVEDATE
,EDC.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,EDC.createtime as SRC_CREATETIME
,EDC.updatetime  as SRC_UPDATETIME
,EDC.publicid as SRC_PUBLICID
,EDC.updatetime as updatetime_tab1
,polper.updatetime as updatetime_tab2
,job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgequipsalerent_ext as EDC
INNER JOIN v_pc_policyperiod polper
on EDC.BranchID=polper.ID
and EDC.publicid=polper.pcx_imgequipsalerent_ext_publicid
and EDC.updatetime=polper.pcx_imgequipsalerent_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGFarmIrrgEqp(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgfarmirrgeqp_ext_micro_batch),
pcx_imgfarmirrgeqp_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgfarmirrgeqp_ext_micro_batch )  
,v_pcx_imgfarmirrgeqp_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgfarmirrgeqp_ext.*
			from {rawDB}.pcx_imgfarmirrgeqp_ext          
            inner join pcx_imgfarmirrgeqp_ext_micro_batch  mb  
			   on mb.branchid = pcx_imgfarmirrgeqp_ext.branchid 
			where pcx_imgfarmirrgeqp_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,FAIRR.publicid as pcx_imgfarmirrgeqp_ext_publicid,FAIRR.updatetime as pcx_imgfarmirrgeqp_ext_updatetime,
      row_number() over (partition by FAIRR.publicid,FAIRR.updatetime,FAIRR.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(FAIRR.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgfarmirrgeqp_ext FAIRR
      JOIN {rawDB}.pc_policyperiod polper 
        on FAIRR.BranchID = polper.ID 
        and polper.updatetime <= FAIRR.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,FAIRR.publicid as pcx_imgfarmirrgeqp_ext_publicid,FAIRR.updatetime as pcx_imgfarmirrgeqp_ext_updatetime,
      row_number() over (partition by FAIRR.publicid,polper.updatetime,FAIRR.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(FAIRR.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgfarmirrgeqp_ext FAIRR
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAIRR.BranchID = polper.ID 
        and FAIRR.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgfarmirrgeqp_ext_publicid,
    p.updatetime as pcx_imgfarmirrgeqp_ext_updatetime
  from
    v_pcx_imgfarmirrgeqp_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
) 
,HRZ_Query as 
( SELECT 
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGFarmIrrgEqp' || '-' || CAST (CAST(FAIRR.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY, 
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
'NOKEY' AS  LINE_LOC_KEY,
UPPER ( 'GWPC' || '-' ||CAST (CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound'  THEN  '-'  || 'QT:'|| CAST (polper.publicID AS  VARCHAR (255)) ELSE ''  END || '-' || 'IMGLine' || '-' || CAST (CAST(FAIRR.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY ,
CAST ( COALESCE (FAIRR.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST ( COALESCE (FAIRR.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,  
 'IM' AS LOB_CD ,
 'GWPC' AS SOURCE_SYSTEM,
 'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
 ' ' AS ANNUAL_PAYROLL_CD, 
 NULL AS ANNUAL_GROSS_RECEIPT_AMT , 
 'Not Defined' AS ANNUAL_PAYROLL_TEXT ,
 '{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD ,
 NULL AS ANNUAL_RENT_EXP , 
 ' ' AS AVERAGE_JOB_LENGTH_CD , 
 'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT , 
 ' ' AS CLASS_CD ,
 'Not Defined' AS CLASS_TEXT ,
 NULL AS DED_FCTR , 
NULL AS DED_OVR_FCTR , 
 NULL AS DELAY_IN_COMPLETION_FCTR , 
 NULL AS DELAY_IN_COMPLETION_OVR_FCTR , 
 'U' AS EQP_BRKDWN_OPT_OUT_FL , 
 NULL AS EQP_LEASE_FROM_OTH_PREM , 
 NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR , 
 NULL AS HIST_PRE_TAX_OVR_CRED_FCTR , 
 'U' AS INS_INC_EXPSR_FL ,
 NULL AS LSE_RENT_EQP_FCTR , 
 NULL AS LSE_RENT_EQP_OVR_FCTR ,
 COALESCE(FAIRR.LegacyClassCode, ' ') AS LGCY_CL_CD,
 COALESCE(FAIRR.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
 FAIRR.LegacyItemNum AS LGCY_ITEM_NO,
 FAIRR.LegacyItemIdentifier AS LEGACY_ITEM_ID,
 NULL AS OFF_SITE_SERVER_LOAD_FCTR , 
 NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR , 
 'U' AS POWER_GEN_COMPANY_FL , 
 'U' AS POWER_GEN_EQUIP_FL , 
 'U' AS PROD_MACH_INSTALL_FL ,
 'U' AS PROJ_EXCEED_24_MON_FL ,
 ' ' AS PROJECT_TYPE_CD , 
 'Not Defined' AS PROJECT_TYPE_TEXT , 
 'U' AS REFRIG_WAREHOUSING_FL , 
 ' ' AS SALE_OFFICE_BLDG_TYPE_CD , 
 'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT , 
 NULL AS SALE_OFFICE_MOD_FCTR , 
 NULL AS SALE_OFFICE_MOD_OVR_FCTR , 
 NULL AS THEFT_DEDUCTIBLE_FCTR , 
 NULL AS THEFT_DEDUCTIBLE_OVR_FCTR , 
 NULL AS TOTAL_LOAD_FCTR , 
 NULL AS TOTAL_LOAD_OVR_FCTR ,
 NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
 NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
FAIRR.branchid as SRC_BRANCHID,
FAIRR.fixedid as SRC_FIXEDID,
FAIRR.effectivedate as SRC_EFFECTIVEDATE,
FAIRR.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
FAIRR.createtime as SRC_CREATETIME,
FAIRR.updatetime  as SRC_UPDATETIME,
FAIRR.publicid as SRC_PUBLICID,
FAIRR.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
 
 job.updatetime as updatetime_tab3
 
 FROM   
v_pcx_imgfarmirrgeqp_ext as FAIRR
INNER JOIN v_pc_policyperiod polper
on FAIRR.BranchID=polper.ID
and FAIRR.publicid=polper.pcx_imgfarmirrgeqp_ext_publicid
and FAIRR.updatetime=polper.pcx_imgfarmirrgeqp_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
	
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGFineArtsDlr(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgfineartsdlr_ext_micro_batch), 
  pcx_imgfineartsdlr_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgfineartsdlr_ext_micro_batch ) 
,v_pcx_imgfineartsdlr_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgfineartsdlr_ext.*
			from {rawDB}.pcx_imgfineartsdlr_ext          
            inner join pcx_imgfineartsdlr_ext_micro_batch   mb  
			   on mb.branchid = pcx_imgfineartsdlr_ext.branchid 
			where pcx_imgfineartsdlr_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*************************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,FAD.publicid as pcx_imgfineartsdlr_ext_publicid,FAD.updatetime as pcx_imgfineartsdlr_ext_updatetime,
      row_number() over (partition by FAD.publicid,FAD.updatetime,FAD.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(FAD.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgfineartsdlr_ext  FAD
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAD.BranchID = polper.ID 
        and polper.updatetime <= FAD.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,FAD.publicid as pcx_imgfineartsdlr_ext_publicid,FAD.updatetime as pcx_imgfineartsdlr_ext_updatetime,
      row_number() over (partition by FAD.publicid,polper.updatetime,FAD.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(FAD.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgfineartsdlr_ext FAD
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAD.BranchID = polper.ID 
        and FAD.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgfineartsdlr_ext_publicid,
    p.updatetime as pcx_imgfineartsdlr_ext_updatetime
  from
    v_pcx_imgfineartsdlr_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || '{CVRBL_TYPE_CD_VAL}' || '-' ||CAST( CAST (FAD.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
UPPER ('GWPC' || '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-'|| 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (FAD.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (FAD.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (FAD.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT,
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT,
NULL AS ANNUAL_RENT_EXP,
' ' AS AVERAGE_JOB_LENGTH_CD ,
'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
NULL AS DELAY_IN_COMPLETION_FCTR ,
NULL AS DELAY_IN_COMPLETION_OVR_FCTR ,
'U' AS EQP_BRKDWN_OPT_OUT_FL ,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
'U' AS POWER_GEN_EQUIP_FL ,
'U' AS PROD_MACH_INSTALL_FL ,
'U' AS PROJ_EXCEED_24_MON_FL ,
' ' AS PROJECT_TYPE_CD ,
'Not Defined' AS PROJECT_TYPE_TEXT ,
'U' AS REFRIG_WAREHOUSING_FL ,
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
NULL AS TOTAL_LOAD_FCTR ,
NULL AS TOTAL_LOAD_OVR_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(FAD.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(FAD.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
FAD.LegacyItemNum  AS LGCY_ITEM_NO,
FAD.LegacyItemIdentifier AS LEGACY_ITEM_ID,
FAD.branchid as SRC_BRANCHID,
FAD.fixedid as SRC_FIXEDID,
FAD.effectivedate as SRC_EFFECTIVEDATE,
FAD.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
FAD.createtime as SRC_CREATETIME,
FAD.updatetime  as SRC_UPDATETIME,
FAD.publicid as SRC_PUBLICID,
FAD.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgfineartsdlr_ext as FAD
INNER JOIN v_pc_policyperiod polper
on FAD.BranchID=polper.ID
and FAD.publicid=polper.pcx_imgfineartsdlr_ext_publicid
and FAD.updatetime=polper.pcx_imgfineartsdlr_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGFarmMachSched(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgfarmmachsched_ext_micro_batch),
  pcx_imgfarmmachsched_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgfarmmachsched_ext_micro_batch )
,v_pcx_imgfarmmachsched_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgfarmmachsched_ext.*
			from {rawDB}.pcx_imgfarmmachsched_ext          
            inner join pcx_imgfarmmachsched_ext_micro_batch mb  
			   on mb.branchid = pcx_imgfarmmachsched_ext.branchid 
			where pcx_imgfarmmachsched_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*******************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,FAMACHSCHD.publicid as pcx_imgfarmmachsched_ext_publicid,FAMACHSCHD.updatetime as pcx_imgfarmmachsched_ext_updatetime,
      row_number() over (partition by FAMACHSCHD.publicid,FAMACHSCHD.updatetime,FAMACHSCHD.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(FAMACHSCHD.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgfarmmachsched_ext  FAMACHSCHD
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAMACHSCHD.BranchID = polper.ID 
        and polper.updatetime <= FAMACHSCHD.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,FAMACHSCHD.publicid as pcx_imgfarmmachsched_ext_publicid,FAMACHSCHD.updatetime as pcx_imgfarmmachsched_ext_updatetime,
      row_number() over (partition by FAMACHSCHD.publicid,polper.updatetime,FAMACHSCHD.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(FAMACHSCHD.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgfarmmachsched_ext FAMACHSCHD
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAMACHSCHD.BranchID = polper.ID 
        and FAMACHSCHD.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgfarmmachsched_ext_publicid,
    p.updatetime as pcx_imgfarmmachsched_ext_updatetime
  from
    v_pcx_imgfarmmachsched_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
			On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID  AS VARCHAR (255))|| '-' ELSE '' END ||'IMGFarmMachSched'||'-'||CAST (CAST(FAMACHSCHD.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) 
 ELSE  '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) 
 ELSE '' END || '-' || 'IMGLine' || '-' || CAST (CAST(FAMACHSCHD.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (FAMACHSCHD.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST ( COALESCE (FAMACHSCHD.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD , 
NULL AS ANNUAL_GROSS_RECEIPT_AMT , 
' ' AS ANNUAL_PAYROLL_CD,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
'Not Defined' AS ANNUAL_PAYROLL_TEXT , 
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD 
,NULL AS ANNUAL_RENT_EXP
, ' ' AS AVERAGE_JOB_LENGTH_CD
,'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT
, ' ' AS CLASS_CD
,'Not Defined' AS CLASS_TEXT
,NULL AS DED_FCTR
,NULL AS DED_OVR_FCTR
,NULL AS DELAY_IN_COMPLETION_FCTR
,NULL AS DELAY_IN_COMPLETION_OVR_FCTR
, 'U' AS EQP_BRKDWN_OPT_OUT_FL
,NULL AS EQP_LEASE_FROM_OTH_PREM
,NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR
,NULL AS HIST_PRE_TAX_OVR_CRED_FCTR
, 'U' AS INS_INC_EXPSR_FL
,NULL AS LSE_RENT_EQP_FCTR
,NULL AS LSE_RENT_EQP_OVR_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR
, 'U' AS POWER_GEN_COMPANY_FL
, 'U' AS POWER_GEN_EQUIP_FL
, 'U' AS PROD_MACH_INSTALL_FL
, 'U' AS PROJ_EXCEED_24_MON_FL
, ' ' AS PROJECT_TYPE_CD
,'Not Defined' AS PROJECT_TYPE_TEXT
, 'U' AS REFRIG_WAREHOUSING_FL
, ' ' AS SALE_OFFICE_BLDG_TYPE_CD
,'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT
,NULL AS SALE_OFFICE_MOD_FCTR
,NULL AS SALE_OFFICE_MOD_OVR_FCTR
,NULL AS THEFT_DEDUCTIBLE_FCTR
,NULL AS THEFT_DEDUCTIBLE_OVR_FCTR
,NULL AS TOTAL_LOAD_FCTR
,NULL AS TOTAL_LOAD_OVR_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR
,COALESCE(FAMACHSCHD.LegacyClassCode, ' ') AS LGCY_CL_CD 
,COALESCE(FAMACHSCHD.LegacyClassDesc, ' ') AS LGCY_CL_DESC 
,FAMACHSCHD.LegacyItemNum AS LGCY_ITEM_NO
,FAMACHSCHD.LegacyItemIdentifier AS LEGACY_ITEM_ID
,FAMACHSCHD.branchid as SRC_BRANCHID
,FAMACHSCHD.fixedid as SRC_FIXEDID
,FAMACHSCHD.effectivedate as SRC_EFFECTIVEDATE
,FAMACHSCHD.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,FAMACHSCHD.createtime as SRC_CREATETIME
,FAMACHSCHD.updatetime  as SRC_UPDATETIME
,FAMACHSCHD.publicid as SRC_PUBLICID
,polper.updatetime as updatetime_tab2
,FAMACHSCHD.updatetime as updatetime_tab1
,job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgfarmmachsched_ext as FAMACHSCHD
INNER JOIN v_pc_policyperiod polper
on FAMACHSCHD.BranchID=polper.ID
and FAMACHSCHD.publicid=polper.pcx_imgfarmmachsched_ext_publicid
and FAMACHSCHD.updatetime=polper.pcx_imgfarmmachsched_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGInstlFltr(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imginstlfltr_ext_micro_batch) 
  ,pcx_imginstlfltr_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imginstlfltr_ext_micro_batch )
,v_pcx_imginstlfltr_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imginstlfltr_ext.*
			from {rawDB}.pcx_imginstlfltr_ext          
            inner join pcx_imginstlfltr_ext_micro_batch   mb  
			   on mb.branchid = pcx_imginstlfltr_ext.branchid 
			where pcx_imginstlfltr_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*********************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,INSTFLTR.publicid as pcx_imginstlfltr_ext_publicid,INSTFLTR.updatetime as pcx_imginstlfltr_ext_updatetime,
      row_number() over (partition by INSTFLTR.publicid,INSTFLTR.updatetime,INSTFLTR.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(INSTFLTR.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imginstlfltr_ext  INSTFLTR
      JOIN {rawDB}.pc_policyperiod  polper 
        on INSTFLTR.BranchID = polper.ID 
        and polper.updatetime <= INSTFLTR.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,INSTFLTR.publicid as pcx_imginstlfltr_ext_publicid,INSTFLTR.updatetime as pcx_imginstlfltr_ext_updatetime,
      row_number() over (partition by INSTFLTR.publicid,polper.updatetime,INSTFLTR.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(INSTFLTR.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imginstlfltr_ext INSTFLTR
      JOIN {rawDB}.pc_policyperiod  polper 
        on INSTFLTR.BranchID = polper.ID 
        and INSTFLTR.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imginstlfltr_ext_publicid,
    p.updatetime as pcx_imginstlfltr_ext_updatetime
  from
    v_pcx_imginstlfltr_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-' ELSE '' END ||'{CVRBL_TYPE_CD_VAL}'||'-'||CAST (CAST(INSTFLTR.FixedID AS INTEGER)AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE  '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST(CAST (INSTFLTR.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (INSTFLTR.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (INSTFLTR.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
COALESCE(INSTFLTR.AnnualGrossReceipt,NULL) AS ANNUAL_GROSS_RECEIPT_AMT, 
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT, 
NULL AS ANNUAL_RENT_EXP,
 COALESCE(AVGJOBLEN.TYPECODE,' ') AS AVERAGE_JOB_LENGTH_CD,
 COALESCE(AVGJOBLEN.DESCRIPTION,'Not Defined') AS AVERAGE_JOB_LENGTH_TEXT ,
' ' AS CLASS_CD ,
'Not Defined' AS CLASS_TEXT ,
NULL AS DED_FCTR ,
NULL AS DED_OVR_FCTR ,
 INSTFLTR.DelayInCompFactor AS DELAY_IN_COMPLETION_FCTR ,
 INSTFLTR.DelayInCompFactorOver AS DELAY_IN_COMPLETION_OVR_FCTR,
 CASE WHEN INSTFLTR.OPTOUTEBCOVIND=1 THEN 'Y' WHEN INSTFLTR.OPTOUTEBCOVIND=0 THEN 'N' ELSE 'U' END  AS EQP_BRKDWN_OPT_OUT_FL,
NULL AS EQP_LEASE_FROM_OTH_PREM ,
NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR ,
NULL AS HIST_PRE_TAX_OVR_CRED_FCTR ,
'U' AS INS_INC_EXPSR_FL ,
NULL AS LSE_RENT_EQP_FCTR ,
NULL AS LSE_RENT_EQP_OVR_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_FCTR ,
NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR ,
'U' AS POWER_GEN_COMPANY_FL ,
CASE WHEN INSTFLTR.INCLUDEPGEIND=1 THEN 'Y' WHEN INSTFLTR.INCLUDEPGEIND=0 THEN 'N' ELSE 'U' END AS POWER_GEN_EQUIP_FL,
 CASE WHEN INSTFLTR.INCLUDEPMIIND=1 THEN 'Y' WHEN INSTFLTR.INCLUDEPMIIND=0 THEN 'N' ELSE 'U' END AS PROD_MACH_INSTALL_FL, 
 CASE WHEN INSTFLTR.EXCEED24MONTHSIND=1 THEN 'Y' WHEN INSTFLTR.EXCEED24MONTHSIND=0 THEN 'N' ELSE 'U' END  AS PROJ_EXCEED_24_MON_FL, 
 COALESCE(PROJTYP.TYPECODE,' ') AS PROJECT_TYPE_CD, 
 COALESCE(PROJTYP.DESCRIPTION,'Not Defined') AS PROJECT_TYPE_TEXT ,
 CASE WHEN INSTFLTR.REFRIGWAREHOUSINGIND=1 THEN 'Y' WHEN INSTFLTR.REFRIGWAREHOUSINGIND=0 THEN 'N' ELSE 'U' END AS REFRIG_WAREHOUSING_FL, 
' ' AS SALE_OFFICE_BLDG_TYPE_CD ,
'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT ,
NULL AS SALE_OFFICE_MOD_FCTR ,
NULL AS SALE_OFFICE_MOD_OVR_FCTR ,
NULL AS THEFT_DEDUCTIBLE_FCTR ,
NULL AS THEFT_DEDUCTIBLE_OVR_FCTR ,
INSTFLTR.TotalLoad AS TOTAL_LOAD_FCTR,
INSTFLTR.TotalLoadOver AS TOTAL_LOAD_OVR_FCTR,
NULL AS UN_SCH_TOOL_EQP_PREM_FCTR ,
NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR,
COALESCE(INSTFLTR.LegacyClassCode, ' ') AS LGCY_CL_CD,
COALESCE(INSTFLTR.LegacyClassDesc, ' ') AS LGCY_CL_DESC,
INSTFLTR.LegacyItemNum as LGCY_ITEM_NO,
INSTFLTR.LegacyItemIdentifier AS LEGACY_ITEM_ID,
INSTFLTR.branchid as SRC_BRANCHID,
INSTFLTR.fixedid as SRC_FIXEDID,
INSTFLTR.effectivedate as SRC_EFFECTIVEDATE,
INSTFLTR.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
INSTFLTR.createtime as SRC_CREATETIME,
INSTFLTR.updatetime  as SRC_UPDATETIME,
INSTFLTR.publicid as SRC_PUBLICID,
INSTFLTR.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imginstlfltr_ext as INSTFLTR
INNER JOIN v_pc_policyperiod polper
on INSTFLTR.BranchID=polper.ID
and INSTFLTR.publicid=polper.pcx_imginstlfltr_ext_publicid
and INSTFLTR.updatetime=polper.pcx_imginstlfltr_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join 
        (
        select * from 
            (select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn 
            from {rawDB}.pctl_imgavgjoblength_ext joblen
			Cross Join Events_Max_Updatetime mb  On joblen.z_meta_event_timestamp <= mb.mb_max_updatetime)
            where rn=1) AVGJOBLEN
            ON AVGJOBLEN.ID = INSTFLTR.AvgJobLength 
            
left join 
       (select * from 
           (select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_imgprojecttype_ext typ
		   Cross Join Events_Max_Updatetime mb  On typ.z_meta_event_timestamp <= mb.mb_max_updatetime) 
           where rn=1) PROJTYP ON PROJTYP.ID = INSTFLTR.ProjectType
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)


"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_cvrbl_IMGFarmMach(  rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
   With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgfarmmach_ext_micro_batch),
  pcx_imgfarmmach_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgfarmmach_ext_micro_batch )
,v_pcx_imgfarmmach_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgfarmmach_ext.*
			from {rawDB}.pcx_imgfarmmach_ext          
            inner join pcx_imgfarmmach_ext_micro_batch mb  
			   on mb.branchid = pcx_imgfarmmach_ext.branchid 
			where pcx_imgfarmmach_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,FAMACH.publicid as pcx_imgfarmmach_ext_publicid,FAMACH.updatetime as pcx_imgfarmmach_ext_updatetime,
      row_number() over (partition by FAMACH.publicid,FAMACH.updatetime,FAMACH.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(FAMACH.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgfarmmach_ext  FAMACH
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAMACH.BranchID = polper.ID 
        and polper.updatetime <= FAMACH.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,FAMACH.publicid as pcx_imgfarmmach_ext_publicid,FAMACH.updatetime as pcx_imgfarmmach_ext_updatetime,
      row_number() over (partition by FAMACH.publicid,polper.updatetime,FAMACH.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(FAMACH.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgfarmmach_ext FAMACH
      JOIN {rawDB}.pc_policyperiod  polper 
        on FAMACH.BranchID = polper.ID 
        and FAMACH.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgfarmmach_ext_publicid,
    p.updatetime as pcx_imgfarmmach_ext_updatetime
  from
    v_pcx_imgfarmmach_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
			On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER ('GWPC'|| '-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| '-'|| CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID  AS VARCHAR (255))|| '-' ELSE '' END ||'IMGFarmMach'||'-'||CAST (CAST(FAMACH.FixedID AS INTEGER) AS VARCHAR (255))) AS LINE_CVRBL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) 
 ELSE  '' END) AS POL_KEY,
UPPER ('GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) 
 ELSE '' END || '-' || 'IMGLine' || '-' || CAST (CAST(FAMACH.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY,
'NOKEY' AS LINE_LOC_KEY,
CAST ( COALESCE (FAMACH.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST ( COALESCE (FAMACH.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM,
'IM' AS LOB_CD ,
'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
NULL AS ANNUAL_GROSS_RECEIPT_AMT , 
' ' AS ANNUAL_PAYROLL_CD,
'Not Defined' AS ANNUAL_PAYROLL_TEXT , 
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD 
,NULL AS ANNUAL_RENT_EXP
, ' ' AS AVERAGE_JOB_LENGTH_CD
,'Not Defined' AS AVERAGE_JOB_LENGTH_TEXT
, ' ' AS CLASS_CD
,'Not Defined' AS CLASS_TEXT
,NULL AS DED_FCTR
,NULL AS DED_OVR_FCTR
,NULL AS DELAY_IN_COMPLETION_FCTR
,NULL AS DELAY_IN_COMPLETION_OVR_FCTR
, 'U' AS EQP_BRKDWN_OPT_OUT_FL
,NULL AS EQP_LEASE_FROM_OTH_PREM
,NULL AS EQP_LEASE_OTH_PREM_OVR_FCTR
,NULL AS HIST_PRE_TAX_OVR_CRED_FCTR
, 'U' AS INS_INC_EXPSR_FL
,NULL AS LSE_RENT_EQP_FCTR
,NULL AS LSE_RENT_EQP_OVR_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_FCTR
,NULL AS OFF_SITE_SERVER_LOAD_OVR_FCTR
, 'U' AS POWER_GEN_COMPANY_FL
, 'U' AS POWER_GEN_EQUIP_FL
, 'U' AS PROD_MACH_INSTALL_FL
, 'U' AS PROJ_EXCEED_24_MON_FL
, ' ' AS PROJECT_TYPE_CD
,'Not Defined' AS PROJECT_TYPE_TEXT
, 'U' AS REFRIG_WAREHOUSING_FL
, ' ' AS SALE_OFFICE_BLDG_TYPE_CD
,'Not Defined' AS SALE_OFFICE_BLDG_TYPE_TEXT
,NULL AS SALE_OFFICE_MOD_FCTR
,NULL AS SALE_OFFICE_MOD_OVR_FCTR
,NULL AS THEFT_DEDUCTIBLE_FCTR
,NULL AS THEFT_DEDUCTIBLE_OVR_FCTR
,NULL AS TOTAL_LOAD_FCTR
,NULL AS TOTAL_LOAD_OVR_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_FCTR
,NULL AS UN_SCH_TOOL_EQP_PREM_OVR_FCTR
,COALESCE(FAMACH.LegacyClassCode, ' ') AS LGCY_CL_CD 
,COALESCE(FAMACH.LegacyClassDesc, ' ') AS LGCY_CL_DESC 
,FAMACH.LegacyItemNum AS LGCY_ITEM_NO
,FAMACH.LegacyItemIdentifier AS LEGACY_ITEM_ID
,FAMACH.branchid as SRC_BRANCHID
,FAMACH.fixedid as SRC_FIXEDID
,FAMACH.effectivedate as SRC_EFFECTIVEDATE
,FAMACH.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,FAMACH.createtime as SRC_CREATETIME
,FAMACH.updatetime  as SRC_UPDATETIME
,FAMACH.publicid as SRC_PUBLICID
,polper.updatetime as updatetime_tab2
,FAMACH.updatetime as updatetime_tab1
,job.updatetime as updatetime_tab3
 
FROM 
v_pcx_imgfarmmach_ext as FAMACH
INNER JOIN v_pc_policyperiod polper
on FAMACH.BranchID=polper.ID
and FAMACH.publicid=polper.pcx_imgfarmmach_ext_publicid
and FAMACH.updatetime=polper.pcx_imgfarmmach_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_mod_IMGLine (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imglinemod_ext_micro_batch)
  ,pcx_imglinemod_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imglinemod_ext_micro_batch )
,v_pcx_imglinemod_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imglinemod_ext.*
			from {rawDB}.pcx_imglinemod_ext pcx_imglinemod_ext
            inner join pcx_imglinemod_ext_micro_batch mb  
			   on mb.branchid = pcx_imglinemod_ext.branchid 
			where pcx_imglinemod_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********,v_pc_policyperiod as
( --consider parent record as driving record
  select * from 
    (select polper.*,linemod.publicid as pcx_imglinemod_ext_publicid,linemod.updatetime as pcx_imglinemod_ext_updatetime,
      row_number() over (partition by linemod.publicid,linemod.updatetime,linemod.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(linemod.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imglinemod_ext  linemod
      JOIN {rawDB}.pc_policyperiod  polper 
        on linemod.BranchID = polper.ID 
        and polper.updatetime <= linemod.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,linemod.publicid as pcx_imglinemod_ext_publicid,linemod.updatetime as pcx_imglinemod_ext_updatetime,
      row_number() over (partition by linemod.publicid,polper.updatetime,linemod.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(linemod.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imglinemod_ext linemod
      JOIN {rawDB}.pc_policyperiod  polper 
        on linemod.BranchID = polper.ID 
        and linemod.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imglinemod_ext_publicid,
    p.updatetime as pcx_imglinemod_ext_updatetime
  from
    v_pcx_imglinemod_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
) 
,HRZ_Query as 
( SELECT 
UPPER('GWPC'  ||'-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (100)) || case when status.TYPECODE<> 'Bound' then '-QT:' || POLPER.publicid ELSE '' END ||'-' || 'IMGLine' || '-' || CAST(cast(linemod.FixedID AS INTEGER) as varchar(100))) as LINE_MOD_KEY,
'GWPC'|| '-' ||linemod.PatternCode AS MOD_KEY,
UPPER('GWPC' ||'-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (100)) || case when status.TYPECODE<> 'Bound' then '-QT:' || POLPER.publicid ELSE '' END ) as POL_KEY,
UPPER('GWPC'  ||'-'|| CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (100)) || case when status.TYPECODE<> 'Bound' then '-QT:' || POLPER.publicid ELSE '' END ||'-' || 'IMGLine' || '-' || CAST(cast(linemod.IMGLine AS INTEGER) as varchar(100))) as POL_LINE_KEY,
CAST ( COALESCE (linemod.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (linemod.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
'NOKEY' as CVRBL_KEY,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
linemod.PatternCode as LINE_MOD_CD,
jurs.TYPECODE as JURS_CD,
COALESCE(jurs.Name, 'Not Defined') as JURS_TEXT,
case
    when linemod.DateModifier is not null then cast(linemod.DateModifier as varchar (100))
    when linemod.BooleanModifier is not null then cast(linemod.BooleanModifier as varchar (100))
    when linemod.RateModifier is not null then CAST(linemod.RateModifier as varchar (100))
    when linemod.TypeKeyModifier is not null then linemod.TypeKeyModifier
   end as MOD_VAL,
COALESCE(linemod.SUGGESTEDMINIMUMFACTOR_EXT,0) as SGSTD_MIN_FCTR,
COALESCE(linemod.SUGGESTEDMAXIMUMFACTOR_EXT,0) as SGSTD_MAX_FCTR,
COALESCE(linemod.SuggestedFactor_EXT,0) as SGSTD_FCTR,
COALESCE(linemod.Justification,' ') as JUST_DESC,
COALESCE(pricingmod.typecode,' ') as PRICING_MOD_OPT_TYPE_CD,
COALESCE(pricingmod.Name,'Not Defined') as PRICING_MOD_OPT_TYPE_TEXT,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate  ELSE COALESCE (POLPER.UPDATETIME, POLPER.CREATETIME) END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS,
'IM' AS LOB_CD,
' ' as EXPER_MOD_STATUS_CD,
'Not Defined' as EXPER_MOD_STATUS_TEXT,
linemod.branchid as SRC_BRANCHID,
linemod.fixedid as SRC_FIXEDID,
linemod.effectivedate as SRC_EFFECTIVEDATE,
linemod.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
linemod.createtime as SRC_CREATETIME,
linemod.updatetime  as SRC_UPDATETIME,
linemod.publicid as SRC_PUBLICID,
linemod.updatetime  as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
,'GWPC-IM-{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL 
 
FROM 
v_pcx_imglinemod_ext as linemod
INNER JOIN v_pc_policyperiod polper
on linemod.BranchID=polper.ID
and linemod.publicid=polper.pcx_imglinemod_ext_publicid
and linemod.updatetime=polper.pcx_imglinemod_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join 
		(
		select * from 
			(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn 
			from {rawDB}.pctl_jurisdiction jurs
			Cross Join Events_Max_Updatetime mb  On jurs.z_meta_event_timestamp <= mb.mb_max_updatetime)
			where rn=1) jurs 
on linemod.State = jurs.id
left join 
		(
		select * from 
			(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn 
			from {rawDB}.pctl_pricingmodoption_ext pricingmod
			Cross Join Events_Max_Updatetime mb  On pricingmod.z_meta_event_timestamp <= mb.mb_max_updatetime)
			where rn=1) pricingmod 
on  pricingmod.id =linemod.pricingmodoptiontype_ext
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_line_bldg_IMGBldg (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgbuilding_ext_micro_batch), 
 pcx_imgbuilding_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imgbuilding_ext_micro_batch )
,v_pcx_imgbuilding_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imgbuilding_ext.*
			from {rawDB}.pcx_imgbuilding_ext        
            inner join pcx_imgbuilding_ext_micro_batch mb  
			   on mb.branchid = pcx_imgbuilding_ext.branchid 
			where pcx_imgbuilding_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
     (select polper.*,BDG.publicid as pcx_imgbuilding_ext_publicid,BDG.updatetime as pcx_imgbuilding_ext_updatetime,
      row_number() over (partition by BDG.publicid,BDG.updatetime,BDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(BDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imgbuilding_ext  BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and polper.updatetime <= BDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
      (select polper.*,BDG.publicid as pcx_imgbuilding_ext_publicid,BDG.updatetime as pcx_imgbuilding_ext_updatetime,
      row_number() over (partition by BDG.publicid,polper.updatetime,BDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(BDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imgbuilding_ext BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and BDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgbuilding_ext_publicid,
    p.updatetime as pcx_imgbuilding_ext_updatetime
  from
    v_pcx_imgbuilding_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_nwconstructiontype_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_nwconstructiontype_ext nc    
		   Cross Join Events_Max_Updatetime mb  
		   On nc.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_imgoccupancy_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_imgoccupancy_ext oc    
		   Cross Join Events_Max_Updatetime mb  
		   On oc.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,  SESSION_PARAMS
     AS ( 
           SELECT     'GWPC' AS Source_System,                       
                'IMGBldg' AS PV_CVRBL_TYPE,
                'IMGLoc' AS PV_IMG_LOCATION           ),
     HRZ_Query
     AS (SELECT UPPER (sp.Source_System || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE   WHEN STATUS.TypeCode <> 'Bound'   THEN   '-'   || 'QT:'   || CAST (polper.PublicID AS VARCHAR (255))    ELSE   ''    END   || '-'|| CAST (PV_CVRBL_TYPE AS VARCHAR (255))  || '-'   ||  CAST (CAST(IMGBUILDING.FixedID AS INTEGER)AS VARCHAR (255)) )
                   AS LINE_BLDG_KEY,
         UPPER ( sp.Source_System|| '-'|| CAST(CAST(polper.PeriodID AS INTEGER)AS VARCHAR (255))  || CASE    WHEN STATUS.TypeCode <> 'Bound' THEN '-'|| 'QT:'  || CAST (polper.PublicID AS VARCHAR (255)) ELSE  ''  END)
                   AS POL_KEY,
          UPPER ( CASE  WHEN IMGBUILDING.BUILDING IS NULL THEN 'NOKEY'  ELSE    sp.Source_System || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN STATUS.TypeCode <> 'Bound'  THEN  '-' || 'QT:' || CAST  (POLPER.PUBLICID AS VARCHAR (255)) ELSE ''   END || '-' || CAST (CAST( IMGBUILDING.BUILDING AS INTEGER) AS VARCHAR (255))   END) AS BLDG_KEY,
                'NOKEY' AS LOC_KEY,
                UPPER ( CASE WHEN IMGBUILDING.IMGLocation IS NULL  THEN 'NOKEY' ELSE    sp.SOURCE_SYSTEM || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE  WHEN STATUS.TypeCode <> 'Bound' THEN   '-'  || 'QT:' || CAST (POLPER.PUBLICID AS VARCHAR (255))   ELSE  '' END || '-' || sp.PV_IMG_LOCATION || '-' || CAST (CAST(IMGBUILDING.IMGLocation AS INTEGER) AS VARCHAR (255))   END)
                   AS LINE_LOCATION_KEY,             
                'NOKEY' AS CVRBL_KEY,
                CAST (COALESCE (IMGBUILDING.EffectiveDate, polper.PeriodStart) AS DATE)  AS END_EFF_DT,
                CAST ( COALESCE (IMGBUILDING.ExpirationDate, polper.PeriodEnd) AS DATE)  AS END_EXP_DT,				   
                CASE WHEN status.TypeCode = 'Bound' THEN  job.CloseDate   ELSE  COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END AS ETL_ROW_EFF_DTS  ,                        
                'GWPC'||'-'||'IM'||'-'||'IMGBldg' AS PARTITION_VAL,
                 'IM' AS LOB_CD ,
                CAST (sp.SOURCE_SYSTEM AS VARCHAR (10)) AS SOURCE_SYSTEM,
                CAST(CAST( IMGBUILDING.fixedid   AS INTEGER ) as varchar(255))   AS LIFE_OBJECT_NO ,                
                CAST (sp.PV_CVRBL_TYPE AS VARCHAR (255)) AS CVRBL_TYPE_CD,
                NULL AS AGREED_VAL_LMT,
                'U' AS ALL_CONSTR_APPL_RATNG_FL,
                ' ' AS AREA_OF_STATE_CD,
                'Not Defined' AS AREA_OF_STATE_TEXT,
                NULL AS AUTO_SPRINKLR_GRADE_RPT_ID,
                'U' AS AUTOMATIC_SPRINKLER_SYS_FL,
                ' ' AS BASE_GRP_II_RISK_COVG_TYPE,
                ' ' AS BASE_GRP_II_RISK_SP_CL,
                ' ' AS BASE_GRP_II_COVG_TYPE,
                ' ' AS BASE_GRP_II_COVG_SEC_CONSTR,
                ' ' AS BASE_GRP_II_MIX_CONSTR,
                ' ' AS BASE_GRP_II_SEC_SYMB,
                ' ' AS BASE_GRP_II_SHED_SUPR_CONSTADJ,
                ' ' AS BASE_GRP_II_SIGN_FLUSH_WALL,
                ' ' AS BASE_GRP_II_SP_CL,
                ' ' AS BASE_GRP_II_SP_CL_SEC_CONSTR,
                ' ' AS BASE_GRP_II_SUPWINDRESCONST_TP,
                ' ' AS BASE_GRP_II_SWRCTSC,
                ' ' AS BASE_GRP_II_SYMB,
                ' ' AS BASE_GRP_II_SYMB_PCT_CONSTR,
                ' ' AS BASE_GRP_II_TANK_WOOD,
                NULL AS BASE_GRP_II_SPCF_LOSS_RATE,
                NULL AS BASE_GRP_I_TENT_LOSS_RATE,
                ' ' AS BASE_GRP_II_RATING_TYPE,
                NVL(IMGBCEG,' ') AS BCEG_CD,
                'Not Defined' AS BCEG_TEXT,
                ' ' AS BCEG_CL_CD,
                'Not Defined' AS BCEG_CL_TEXT,
                ' ' AS BCEG_CL,
                ' ' AS BCEG_CL_DESC,
                ' ' AS BCEG_DESC,
                'U' AS BLDG_INC_OPER_UNIT_FL,
                ' ' AS BLNKT_LOSS_CAUSE_VAL,
                NULL AS BLNKT_ID_NO,
                ' ' AS BLDG_COND_CD,
                'Not Defined' AS BLDG_COND_TEXT,
                ' ' AS BLDG_UNQ_ID,
                ' ' AS BLDG_GRND_FLR_AREA,
                NULL AS BLDG_OCCP_PCT,
                NULL AS BLDG_SF_NO,
                ' ' AS BLDG_INCL_OPER_UNT,
                ' ' AS BLDG_UNIT_NO,
                0 AS BP_BLDG_NO,
                'U' AS BRGLR_ALARM_CR_FL,
                'U' AS CNTRL_FIRE_STATION_FL,
                ' ' AS CERTF_LVL,
                'U' AS CLASS_BASE_GRP_II_FL,
                ' ' AS CL_RATE_CONVRT_CL_DESC,
                ' ' AS CLASS_SUB_CD,
                ' ' AS COMP_BASE_GRP_II_SYMB,
                'U' AS CMPLNC_WIND_MTGN_FL,
                0 AS CONDO_BLDG_AREA_SF_QT,
                ' ' AS CONFORM_CONDO_ACT,
                NVL(CONST_TYPE.TypeCode ,  ' ' ) AS BP_CONSTR_TYPE_CD,   
                COALESCE (  CONST_TYPE.DESCRIPTION  , 'Not Defined')  AS BP_CONSTR_TYPE_TEXT,  
                ' ' AS CONSTR_CD,
                ' ' AS CONSTR_TYPE,
                ' ' AS CONSTR_QLTY_LEVEL_CD,
                'Not Defined' AS CONSTR_QLTY_LEVEL_TEXT,
                ' ' AS CONSTR_TYPE_USE,
                ' ' AS CONSTR_YR_CD,
                NULL AS CONSTR_YR_NO,
                ' ' AS COVG_TYPE,
                NULL AS FUNG_COVG_SUB_LMT,
                ' ' AS EQ_SCP_GRADE_CD,
                ' ' AS EQ_RATE_GRADE_CD,
                ' ' AS EQ_ADDL_HZRD,
                ' ' AS EQ_BLDG_CONSTR_DTL,
                0 AS EQ_LOSS_CAUSE_BLNKT_ID_NO,
                ' ' AS EQ_COVG_DESC,
                ' ' AS EQ_CONSTR_CL,
                'U' AS EQ_ROOF_TANK_HZRD_FL,
                ' ' AS EXTR_WALL_CLAY,
                ' ' AS EXTR_WALL_CLAY_SEC_CONSTR,
                ' ' AS GRD_CL_BASE_GRP_II,
                ' ' AS GRD_OCCP_BASE_GRP_II,
                ' ' AS HZRD_GRADE_CD,
                'Not Defined' AS HZRD_GRADE_TEXT,
                ' ' AS HEAT_PLANT,
                ' ' AS HURR_DED_TYPE,
                ' ' AS HURR_PCT_DED,
                'U' AS HURR_PCT_DED_FL,
                ' ' AS INC_APRTM,
                'U' AS INCL_IN_BLNKT_FL,
                ' ' AS INDIV_GRD_PRMS,
                'U' AS INDSTR_EQP_INCL_FL,
                'U' AS INITIAL_COND_FL,
                'U' AS INITIAL_COVG_FL,
                'U' AS INITIAL_EXCL_FL,
                'U' AS IBHS_CERT_FL,
                NULL AS ISO_CRIME_SCR,
                0 AS ITV_ACT_CASH_VAL_AMT,
                0 AS ITV_REPL_COST_VAL_AMT,
                0 AS ITV_VAL_AMT,
                'U' AS LEAD_ABATEMENT_FL,
                LEGACYBUILDINGNUM AS LEGACY_BLDG_NO,  
                ' ' AS LMT_EQ_RES_RISK_APPLY,
                NULL AS LOSS_COST_EFF_DTS,
                NULL AS MASONRY_VENEER_PCT,
                ' ' AS MINE_SUBSD_TYPE,
                ' ' AS NAME_STORM_PCT_DED,
                'U' AS NAME_STORM_DED_APPLY_FL,
                NVL(occ_type.TypeCode, ' ')  AS OCCP_TYPE,  
                NULL AS OCCPNCY_RECERT_YR,
                NULL AS ONSITE_SURV_DTS,
                ' ' AS OPEN_PROT_CD,
                'Not Defined' AS OPEN_PROT_TEXT,
                'U' AS OPEN_SIDES_FL,
                ' ' AS OWNER_OCCUPIED_PCT_CD,
                'Not Defined' AS OWNER_OCCUPIED_PCT_TEXT,
                ' ' AS PLASTIC_GREENHOUSE,
                ' ' AS PREDOMN_CONSTR_TYPE,
                ' ' AS PRMS_GRADE_CD,
                'Not Defined' AS PRMS_GRADE_TEXT,
                ' ' AS PROP_TYPE_CD,
                'Not Defined' AS PROP_TYPE_TEXT,
                ' ' AS PUBL_INST_PROP_PLAN_APPLY,
                'U' AS PUBL_PROP_FL,
                'U' AS RENTAL_PROP_FL,
                ' ' AS RATING_TYPE,
                NULL AS RCP_CD,
                'U' AS REINF_WIDTH_DOOR_FL,
                NULL AS ROOF_AGE,
                ' ' AS ROOF_LVL,
                ' ' AS ROOF_DECK_ATTCH_CD,
                'Not Defined' AS ROOF_DECK_ATTCH_TEXT,
                'U' AS ROOF_COVERING_FL,
                ' ' AS ROOF_WALL_CONN_CD,
                'Not Defined' AS ROOF_WALL_CONN_TEXT,
                ' ' AS ROOF_SHAPE_CD,
                'Not Defined' AS ROOF_SHAPE_TEXT,
                ' ' AS ROOF_SUBDECK,
                'U' AS SEC_WATER_PROT_FL,
                0 AS SPECIFIC_GROUP_II_RATE,
                0 AS SPECIFIC_GROUP_I_RATE,
                'U' AS SEP_ANNL_AGGR_LMT_FL,
                ' ' AS SIMPL_CONSTR_TYPE,
                'U' AS SPRAY_PAINT_FL,
                'U' AS SPRINKLER_RED_FL,
                ' ' AS SPRINKLER_SYS,
                'U' AS STATE_OWNED_PROP_FL,
                ' ' AS STORIES_NO,
                'U' AS SUB_STD_COND_A_FL,
                'U' AS SUB_STD_COND_B_FL,
                'U' AS SUB_STD_COND_C_FL,
                'U' AS SUB_STD_COND_D_FL,
                'U' AS SUB_STD_COND_E_FL,
                0 AS TANK_QTY,
                0 AS TERRSM_OVRRD_PREM_AMT,
                'U' AS TERRSM_OVRRD_PREM_FL,
                'U' AS TRIPLE_NET_LEASE_FL,
                ' ' AS UNITS_1_4,
                'U' AS UNDER_FOUR_UNIT_FL,
                NULL AS UNITS_NO,
                'U' AS VACANT_BLDG_FL,
                ' ' AS VALUATION_LAW,
                ' ' AS VALUATION_ID,
                'U' AS WHSALE_STORAGE_FL,
                'U' AS WIND_CREDIT_FL,
                'U' AS WINDSTORM_PROT_DVC_FL,
                NULL AS EXPSR_GROUP,
                NULL AS NORMAL_LOSS_RATE,
                NULL AS PROP_EXPSR_RATE_PLAN_FTR,
                NULL AS PROP_EXPSR_RATE_PLAN_DED_FTR,
                NULL AS ASGR,
                ' ' AS CLASS_CD,
                ' ' AS CLASS_DESC,
                ' ' EQ_CL_CD,
                'Not Defined' AS EQ_CL_TEXT,
                ' ' AS EQ_GRADE_CD,
                'Not Defined' AS EQ_GRADE_TEXT,
                ' ' AS EQ_BUILD_CONSTR_DTL_CD,
                'Not Defined' AS EQ_BUILD_CONSTR_DTL_TEXT,                
                'U'    AS EXCL_EQ_COVG_BLDG_FL,
                'U'   AS EXCL_FLOOD_COVG_BLDG_FL,
                ' ' AS HAZARD_GRADE,
                'U' AS INDUSTRY_EQUIP_FL,
                ' ' MODIFIED_MER_CALL_INTENSITY,
                0  NUM_OF_RES_UNITS,
                NULL AS PERCENT_OF_OCC,
                ' ' VALUATION_LAW_CD,
                'Not Defined' VALUATION_LAW_TEXT,
                IMGBUILDING.branchid as SRC_BRANCHID,
IMGBUILDING.fixedid as SRC_FIXEDID,
IMGBUILDING.effectivedate as SRC_EFFECTIVEDATE,
IMGBUILDING.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
IMGBUILDING.createtime as SRC_CREATETIME,
IMGBUILDING.updatetime  as SRC_UPDATETIME,
IMGBUILDING.publicid as SRC_PUBLICID,
 IMGBUILDING.updatetime as updatetime_tab1,
 polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3,
 ' ' as LEAD_ABATEMENT_CD,
NULL as BLDG_ELVTN_DS
                
FROM   v_pcx_imgbuilding_ext as IMGBUILDING
CROSS JOIN SESSION_PARAMS sp
INNER JOIN v_pc_policyperiod polper
on IMGBUILDING.BranchID=polper.ID
and IMGBUILDING.publicid=polper.pcx_imgbuilding_ext_publicid
and IMGBUILDING.updatetime=polper.pcx_imgbuilding_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
 
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
 
left join v_pctl_job jbt
ON job.Subtype = jbt.id
                
 LEFT JOIN  v_pctl_nwconstructiontype_ext CONST_TYPE
    ON IMGBUILDING.CONSTRUCTIONTYPE = CONST_TYPE.ID
	
LEFT JOIN v_pctl_imgoccupancy_ext occ_type
    ON IMGBUILDING.OCCUPANCY = occ_type.ID
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
    )
 
"""
  return harmz_query.replace("{rawDB}",rawDB)

# COMMAND ----------

def build_ds_line_loc_IMGLoc (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
 With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imglocation_ext_micro_batch), 
 pcx_imglocation_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imglocation_ext_micro_batch )
,v_pcx_imglocation_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imglocation_ext.*
			from {rawDB}.pcx_imglocation_ext        
            inner join pcx_imglocation_ext_micro_batch mb  
			   on mb.branchid = pcx_imglocation_ext.branchid 
			where pcx_imglocation_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*****************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
     (select polper.*,BDG.publicid as pcx_imglocation_ext_publicid,BDG.updatetime as pcx_imglocation_ext_updatetime,
      row_number() over (partition by BDG.publicid,BDG.updatetime,BDG.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(BDG.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imglocation_ext  BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and polper.updatetime <= BDG.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
      (select polper.*,BDG.publicid as pcx_imglocation_ext_publicid,BDG.updatetime as pcx_imglocation_ext_updatetime,
      row_number() over (partition by BDG.publicid,polper.updatetime,BDG.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(BDG.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imglocation_ext BDG
      JOIN {rawDB}.pc_policyperiod  polper 
        on BDG.BranchID = polper.ID 
        and BDG.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imglocation_ext_publicid,
    p.updatetime as pcx_imglocation_ext_updatetime
  from
    v_pcx_imglocation_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
, SESSION_PARAM as ( select  'GWPC' as SOURCE_SYSTEM ,'IMGLoc' as CVRBL_TYPE_IMLOC   )
     
, HRZ_Query as
(
select 
 upper(SP.SOURCE_SYSTEM || '-' || cast(CAST(polper.PeriodID AS INTEGER ) as varchar(255)) ||  
     CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) 
            ELSE '' END || '-' ||SP.CVRBL_TYPE_IMLOC || '-' || cast(CAST(imloc.FixedID AS INTEGER )as varchar(255)) ) as LINE_LOC_KEY 
,upper(SP.SOURCE_SYSTEM||'-'||cast(CAST(polper.PeriodID AS INTEGER) as varchar(255))||CASE WHEN status.TypeCode <> 'Bound' THEN '-'||'QT:'||CAST(polper.publicID AS VARCHAR(255)) ELSE '' END ) as POL_KEY  
,COALESCE(upper(SP.SOURCE_SYSTEM ||'-'||cast(CAST( polper.PeriodID AS INTEGER ) as varchar(255))||CASE WHEN status.TypeCode <> 'Bound' THEN '-'||'QT:'||CAST(polper.publicID AS VARCHAR(255)) ELSE '' END ||'-'|| 'IMGLine' ||'-'|| cast(CAST( imloc.IMGLine AS INTEGER ) as varchar(255))),'NOKEY') as POL_LINE_KEY
,UPPER (SP.SOURCE_SYSTEM || '-' || cast(CAST(polper.PeriodID AS INTEGER) as varchar(255)) || CASE WHEN status.TypeCode <> 'Bound'
THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE ''
END || '-'|| cast(CAST(imloc.Location AS INTEGER) as VARCHAR (255))) AS LOC_KEY
,'NOKEY' AS HZRD_INFO_KEY
,'NOKEY' AS SUBLINE_TYPE_KEY 
,cast(coalesce(imloc.EffectiveDate, polper.PeriodStart) as date) as END_EFF_DT
,cast(coalesce(imloc.ExpirationDate, polper.PeriodEnd) as date) as END_EXP_DT
,CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate       ELSE COALESCE(polper.UpdateTime, polper.CreateTime)       END AS ETL_ROW_EFF_DTS
,'IM' as LOB_CD    
, SP.SOURCE_SYSTEM as SOURCE_SYSTEM
,'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL
,  cast(CAST( imloc.FixedID   AS INTEGER ) as varchar(255)) as LIFE_OBJECT_NO
,SP.CVRBL_TYPE_IMLOC as CVRBL_TYPE_CD
,imloc.LocationNumber as LINE_LOC_NO ,
' '   AS    FEET_HYDRANT_CD,
 'Not Defined'   AS    FEET_HYDRANT_TEXT,
' '   AS    BP_FIRE_PROT_CL_CD,
 'Not Defined'   AS    FIRE_PROT_CL_TEXT,
0   AS    LIQUOR_LIAB_GRADE,
' '   AS    UNIT_NO,
'U'  AS    PERIL_FL,
NULL  AS    FA_PP_SEQ,
NULL  AS    FA_RES_SEQ,
NULL  AS    FA_STRUCT_SEQ,
' '   AS    EQ_LOSS_CAUSE_FORM,
' '   AS    MULTI_RES_SPCL_CR,
' '   AS    PROT_CL,
'U'  AS    FLOOD_COVG_FL,
' '   AS    LIQUOR_DED,
' '   AS    LIQUOR_LIAB_TERR,
' '   AS    LIQUOR_LIAB_TERR_CD,
' '   AS    OC_TERR,
' '   AS    POLL_TERR,
' '   AS    PREFD_COVG_CURR,
' '   AS    PO_BI_DED,
' '   AS    PO_BIPD_DED,
' '   AS    PO_PD_DED,
' '   AS    PO_TERR,
' '   AS    PO_TERR_CD,
' '   AS    PC_OPS_BI_DED,
' '   AS    PC_OPS_BIPD_DED,
' '   AS    PC_OPS_PD_DED,
' '   AS    PC_OPS_TERR,
' '   AS    PW_DED,
' '   AS    RAILROAD_TERR,
' '   AS    BASE_GRP_I_DSTR_TERR,
' '   AS    BASE_GRP_I_RATE_TERR,
' '   AS    BASE_GRP_I_REDCT_CRD,
' '   AS    BASE_GRP_II_RATE_TERR,
' '   AS    COUNTY_NAME,
' '   AS    CITY_NAME,
' '   AS    CITY_OVRRD,
' '   AS    DSGN_CAT_AREA,
' '   AS    DISTR_NAME,
' '   AS    EQ_TERR,
'U'   AS    FD_FL,
' '   AS    FD_NAME,
' '   AS    FIRE_HYDR_DIST_CD,
 'Not Defined'   AS    FIRE_HYDR_DIST_TEXT,
'U'  AS    FUNG_WET_DRY_ROT_BACT_FL,
'U'  AS    FUNG_WET_DRY_ROT_BACT_SUB_LMT,
' '   AS    GEO_WIND_HZRD_TERR,
'U'  AS    MINE_SUBSID_FL,
'U'  AS    ONE_OPER_UNIT_FL,
' '   AS    SPCL_RATE_TERR,
' '   AS    TERR_ZONE,
' '   AS    TERRSM_TERR,
' '   AS    TERRSM_TERR_OVRRD,
' '   AS    ZIP_CD,
' '   AS    ZIP_CD_OVRD
,CASE WHEN AutoBurglarAlarmInd = 0 THEN 'N'       WHEN AutoBurglarAlarmInd = 1 THEN 'Y'      ELSE 'U' END as AUTO_BRGLR_ALARM_FL
,CASE WHEN AutoFireAlarmInd = 0 THEN 'N'       WHEN AutoFireAlarmInd = 1 THEN 'Y'       ELSE 'U' END as AUTO_FIRE_ALARM_FL
,CASE WHEN AutoSprinklerInd = 0 THEN 'N'       WHEN AutoSprinklerInd = 1 THEN 'Y'       ELSE 'U' END as AUTO_SPRINKLR_FL
,NVL(ModifiedMercalliIntensity, ' ' ) as MOD_MERCALLI_INTS_RT ,
'U'  AS    EXCL_EQ_COVG_LOC_FL,
'U'  AS    EXCL_FLOOD_COVG_LOC_FL,
'U'  AS    MULTI_RESID_LOC_FL ,
NULL  AS    TERRSM_LOAD_FCT,
NULL  AS    AUTO_INCR_OVRD_PCT,
'U' AS LOC_EAST_OF_WEST_BANK_IND,
' ' AS WIND_ZONE_CD,
imloc.branchid as SRC_BRANCHID,
imloc.fixedid as SRC_FIXEDID,
imloc.effectivedate as SRC_EFFECTIVEDATE,
imloc.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
imloc.createtime as SRC_CREATETIME,
imloc.updatetime  as SRC_UPDATETIME,
imloc.publicid as SRC_PUBLICID,
 polper.updatetime as updatetime_tab1,
 imloc.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
                
FROM   v_pcx_imglocation_ext as imloc
CROSS JOIN SESSION_PARAM sp
INNER JOIN v_pc_policyperiod polper
on imloc.BranchID=polper.ID
and imloc.publicid=polper.pcx_imglocation_ext_publicid
and imloc.updatetime=polper.pcx_imglocation_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
 
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
 
left join v_pctl_job jbt
ON job.Subtype = jbt.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
   )

 
"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_pol_line_IMGLine (rawDB,CVRBL_TYPE_CD_VAL):
  source_system ="GWPC"  
  lob = "IM"
  harmz_query ="""
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pc_policyline_micro_batch),
  pc_policyline_micro_batch as (select distinct branchid,updatetime from global_temp.pc_policyline_micro_batch )
,v_pc_policyline as
  (select * from 
      (select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pc_policyline.*
           from {rawDB}.pc_policyline  pc_policyline         
            inner join pc_policyline_micro_batch mb  
               on mb.branchid = pc_policyline.branchid 
               where PC_POLICYLINE.updatetime <= mb.updatetime  
              )
                ) where rn = 1)
/*****************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,PL.updatetime,PL.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(PL.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_PC_POLICYLINE  PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and polper.updatetime <= PL.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,PL.publicid as PC_POLICYLINE_publicid,PL.updatetime as PC_POLICYLINE_updatetime,
      row_number() over (partition by PL.publicid,polper.updatetime,PL.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(PL.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_PC_POLICYLINE PL
      JOIN {rawDB}.pc_policyperiod  polper 
        on PL.BranchID = polper.ID 
        and PL.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    Polper.policyid,
    Polper.UWCOMPANY,
    Polper.BaseState,
    Polper.policynumber,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pc_policyline_publicid,
    p.updatetime as pc_policyline_updatetime
  from
    v_pc_policyline p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
                                Cross Join Events_Max_Updatetime mb  
                                           On status.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_PCTL_POLICYLINE as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCTL_POLICYLINE POLLINE    
                                Cross Join Events_Max_Updatetime mb  
                                On POLLINE.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
, v_pc_policy as 
(
  --consider parent record as driving record
  select * from 
    (select pol.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.policyId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(pol.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_policy pol
        on polper.policyId = pol.ID 
        and pol.updatetime <= polper.updatetime  --child update time <= parent update time
    ) where rn=1 
  union
  --consider child record as driving record
  select * from 
    (select pol.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,pol.updatetime,polper.policyId   --updatetime should be from childe in partition clause
      order by (unix_millis(pol.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod polper
      JOIN {rawDB}.pc_policy  pol
        on polper.policyId = pol.ID 
        and polper.updatetime <= pol.updatetime  --parent update time <= child update time
    ) where rn=1 
)
,v_PC_UWCOMPANY as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PC_UWCOMPANY UW    
                                Cross Join Events_Max_Updatetime mb  
                                On UW.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_PCTL_PROGRAMTYPE_EXT as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCTL_PROGRAMTYPE_EXT PROGTYPE    
                                Cross Join Events_Max_Updatetime mb  
                                On PROGTYPE.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_PCTL_UWCOMPANYCODE as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCTL_UWCOMPANYCODE UWCOMP    
                                Cross Join Events_Max_Updatetime mb  
                                On UWCOMP.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_pctl_jurisdiction as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_jurisdiction jurisdiction    
                                Cross Join Events_Max_Updatetime mb  
                                On jurisdiction.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_PCX_LEGACYPREFIXBCODE_EXT as
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.PCX_LEGACYPREFIXBCODE_EXT pref    
                                Cross Join Events_Max_Updatetime mb  
                                On pref.z_meta_event_timestamp <= mb.mb_max_updatetime
                             ) where rn=1
)
,v_pctl_job as
(
select * from
(select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn
from {rawDB}.pctl_job jbt
Cross Join Events_Max_Updatetime mb
On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1
)
,HRZ_Query as 
(
SELECT UPPER ('{source_system}' || '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || '{CVRBL_TYPE_CD_VAL}' || '-' || CAST(CAST (POLLINE.FixedID AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY, 
UPPER ('{source_system}'|| '-'|| CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255))|| CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY,
'NOKEY' AS FARM_AFFINITY_KEY,
CAST ( COALESCE (POLLINE.EffectiveDATE, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (POLLINE.ExpirationDATE, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'{source_system}' AS SOURCE_SYSTEM,
COALESCE(progtype.typecode, ' ') AS PROG_CD,
COALESCE(progtype.DESCRIPTION,'Not Defined') AS PROG_TEXT,
' ' as BP_LINE_BUS_TYPE_CD,
'Not Defined' as BP_LINE_BUS_TYPE_TEXT,
NULL as BUS_START_DT,
' ' AS BUS_DESC,
'U' as IRPM_ELIG_FL,
COALESCE (pref_1.legacyPrefixB,pref_2.legacyPrefixB,pref_3.legacyPrefixB,pref_4.legacyPrefixB,' ')
AS LEGACY_PREFIXB,
'U' AS BLNKT_BPP_TIB_COV_FL,
'U' AS BLNKT_BLDG_COV_FL,
'U' AS BLNKT_EQUAK_BPP_TIB_COV_FL,
'U' AS BLNKT_EQUAK_COV_FL,
'U' AS BLNKT_EQSL_BPP_TIB_COV_FL,
'U' AS BLNKT_EQSL_COV_FL,
NULL AS BLNKT_BLDG_COV_LMT,
NULL AS TOT_BLNKT_ERTHQK_BPP_TIB_LMT,
NULL AS TOT_BLNKT_ERTHQK_BLDG_COV_LMT,
NULL AS TOT_BLNKT_BPP_TIB_LMT,
'NOKEY ' AS GOV_CL_CD_KEY,
COALESCE(POLLINE.IRPM_ABS_THRSHLD_EXT, NULL) AS IRPM_ABS_THRSHLD, 
' ' AS DIV_STATUS_CD,
'Not Defined' AS DIV_STATUS_TEXT,
' ' AS QUES_FRANCHISE_CD,
' ' AS QUES_SEASONAL_CD,
' ' AS QUES_TRAVEL_RADIUS_CD,
' ' AS QUES_OTHER_EMP_CD,
' ' AS QUES_DRIVING_EXPSR_CD,
' ' AS QUES_INTNL_TRAVEL_CD,
' ' AS QUES_AGE_RANGE_CD,
NULL AS AUTO_SMBL_MNUL_EDIT_DT,
' ' AS CSTM_AUTO_SMBL_DESC,
NULL AS ESTMT_POWER_UNIT_CNT,
' ' AS FLEET_TYPE_CD,
'Not Defined' AS FLEET_TYPE_TEXT,
' ' AS LEGAL_ENTITY_TYPE_CD,
' ' AS CA_POL_TYPE_CD,
'U' AS EXPER_RATING_FL,
'U' AS SCHED_RATING_MOD_FL,
'U' AS PRIOR_TELEMATICS_VNDR_FL,
' ' AS PRIOR_TELEMATICS_VNDR_NAME,
' ' AS TELEMATICS_SOLUTION_DESC,
' ' AS TELEMATICS_EMAIL_ADDR,
' ' AS HAZARD_GRADE_CD,
'Not Defined' AS HAZARD_GRADE_TEXT,
NULL AS UM_FIRST_ML_PREM_RATE,
NULL AS UIM_FIRST_ML_PREM_RATE,
NULL AS CLAIMS_ORIG_EFF_DT,
NULL AS CLAIMS_RETROACTIVE_DT,
'U' AS LOC_LIMITS_FL,
'U' AS POLLUTION_CLEANUP_EXP_FL,
NULL AS EXPER_RATE_MOD,
'U' AS EXPER_RATE_MOD_FL,
NULL AS PKG_MOD,
' ' AS COVG_REPRESENTED_CD,
'Not Defined' AS COVG_REPRESENTED_TEXT,
'U' AS FA_PP_FL,
'U' AS FA_BLDG_STRUCT_FL,
'U' AS FA_MEM_PROG_FL,
'U' AS REC_VEH_FL,
'U' AS RES_HH_PP_FL,
'U' AS SCHED_PP_FL,
' ' AS MOD_TYPE_CD,
'Not Defined' AS MOD_TYPE_TEXT,
CASE
WHEN POLLINE.APPLYTRANSFERPLAN_EXT = 1 THEN 'Y'
WHEN POLLINE.APPLYTRANSFERPLAN_EXT = 0 THEN 'N'
ELSE 'U'
END
AS APLY_TRNSFR_PLN_FL,
CASE
WHEN POLLINE.DIFFINCONDITIONIND = 1 THEN 'Y'
WHEN POLLINE.DIFFINCONDITIONIND = 0 THEN 'N'
ELSE 'U'
END
AS DIFF_COND_FL,
' ' AS CP_POL_TYPE,
'U' AS BLKT_RATED_FL,
' ' AS COVG_CERT_TISM_DESC,
' ' AS TRIA_TYPE,
NULL AS TRIA_EXP_DT,
' ' AS TRIA_COND_EXCL,
' ' AS TRIA_POST_EXCL,
'U' AS EQ_SUB_LMT_BLNKT_FL,
'U' AS FLOOD_COVG_BLNKT_FL,
' ' AS FUNG_WETDRYROT_BACT_COVG_DESC,
'U' AS MULTI_PREM_DISP_CR_FL,
NULL AS MULTI_PREM_DISP_CR_FTR,
' ' AS COND_EXCL_RATE_OPT,
'U' AS MU_BLKT_RATE_FL,
' ' AS MU_POL_TYPE,
NULL AS RISK_TYPE,
NULL AS PA_UM_PREM_RATE,
NULL AS PA_UIM_PREM_RATE,
NULL AS MANL_EXPER_RATE_MOD,
CASE
WHEN POLLINE.EQUIPBREAKOPTOUTIND = 1 or POLLINE.EQBREAKDOWNOPTOUT_EXT = 1 THEN 'Y'
WHEN POLLINE.EQUIPBREAKOPTOUTIND = 0 or POLLINE.EQBREAKDOWNOPTOUT_EXT= 0 THEN 'N'
ELSE 'U'
END
AS EQUIP_BRKDN_OPT_OUT,
' ' AS BCD_CRIME_DESC,
' ' AS BCD_CRIME_DESC_ID,
' ' AS CRIME_CL_CD_DESC,
' ' AS CRIME_CL_CD_NO,
' ' AS CRIME_APPETITE_CD,
'Not Defined' AS CRIME_APPETITE_TEXT,
' ' AS CRIME_HZRD_CD,
'Not Defined' AS CRIME_HZRD_TEXT,
NULL AS RATABLE_EMP_CNT,
NULL AS TOT_EMP_CNT,
NULL AS TOT_ANL_PAYROLL ,
COALESCE(POLLINE.bldgbppcategory,' ' ) AS BLDG_BPP_CAT,
COALESCE(POLLINE.bldgbppclass,' ' ) AS BLDG_BPP_CL,
COALESCE(POLLINE.BLDGBPPGROUPNUM,' ' ) AS BLDG_BPP_GRP_NO,
COALESCE(POLLINE.BLDGBPPISOCLASS,' ' ) AS BLDG_BPP_ISO_CL,
POLLINE.CRIMEANNUALGROSSSALES AS CRIME_ANNL_GROSS_SALE,
COALESCE(POLLINE.CRIMECATEGORY,' ' ) AS CRIME_CAT,
COALESCE(POLLINE.CRIMECLASS,' ' ) AS CRIME_CL_DESC,
COALESCE(POLLINE.CRIMECLASSCODE,' ' ) AS CRIME_CL_CD,
CASE WHEN POLLINE.CRIMECOVGSBLKTEDIND = 1 THEN 'Y' WHEN POLLINE.CRIMECOVGSBLKTEDIND = 0 THEN 'N'
ELSE 'U'
END
AS CRIME_COVG_BLKT_FL,
COALESCE(POLLINE.CRIMEGROUPNUM,' ' ) AS CRIME_GRP_NO,
POLLINE.CRIMENUMOFEMPL AS CRIME_EMP_CNT,
' ' AS CRIME_LMT_OPTION_CD,
'Not Defined' AS CRIME_LMT_OPTION_TEXT,
CASE
WHEN POLLINE.CRIMEOTHRTHNEFDMSIND = 1 THEN 'Y'
WHEN POLLINE.CRIMEOTHRTHNEFDMSIND = 0 THEN 'N'
ELSE 'U'
END
AS CRIME_OTEFD_COVG_FL ,
POLLINE.CRIMERATABLEEMPL AS CRIME_RATABLE_EMPL ,
CASE
WHEN POLLINE.EMPLFRAUDDISHONESTYIND = 1 THEN 'Y'
WHEN POLLINE.EMPLFRAUDDISHONESTYIND = 0 THEN 'N'
ELSE 'U'
END
AS CRIME_EFD_COVG_FL ,
CASE
WHEN POLLINE.EQBREAKDOWNOPTOUT_EXT = 1 THEN 'Y'
WHEN POLLINE.EQBREAKDOWNOPTOUT_EXT = 0 THEN 'N'
ELSE 'U'
END
AS EQUIO_BREK_OTH_FL,
COALESCE(POLLINE.spoilageclass,' ' ) AS SPOIL_CL,
COALESCE(POLLINE.spoilagegroupnum,' ' ) AS SPOIL_GRP_NO,
' ' as COMPOSITE_RATE ,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END, to_timestamp('1900-01-01 00:00:00.000000')) 
AS ETL_ROW_EFF_DTS,
null AS COVERAGE_FORM,
'{source_system}-{lob}-{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL,
'IM' AS LOB_CD,
POLLINE.branchid as SRC_BRANCHID,
POLLINE.fixedid as SRC_FIXEDID,
POLLINE.effectivedate as SRC_EFFECTIVEDATE,
POLLINE.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
POLLINE.createtime as SRC_CREATETIME,
POLLINE.updatetime  as SRC_UPDATETIME,
POLLINE.publicid as SRC_PUBLICID,
POLLINE.updatetime  as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3,
null as PRCO_CMISN_PCT,
null as OTHR_CMISN_PCT,
null as PRCO_CMISN_FCT,
null as OTHR_CMISN_FCT,
null as BLNKT_BLDG_BPP_CVRG_IN,
null as TOT_BLNKT_BLDG_BPP_LMT,
null as PLCY_RTG_RNWL_DT,
null as MIN_PREM_AM,
null as CRM_CVRG_TP_DS, 
null as QT_DAY_CT
FROM v_pc_policyline as POLLINE 
INNER JOIN v_PCTL_POLICYLINE SUBTYPE ON POLLINE.SUBTYPE = SUBTYPE.ID AND SUBTYPE.TypeCode = 'IMGLine_Ext'  
INNER JOIN v_pc_policyperiod polper 
        on POLLINE.BranchID=polper.ID
        and POLLINE.publicid=polper.PC_POLICYLINE_publicid
        and POLLINE.updatetime=polper.PC_POLICYLINE_updatetime 
INNER JOIN v_pc_job job 
        on polper.jobid=job.id
        and polper.publicid=job.pc_policyperiod_publicid
        and polper.updatetime=job.pc_policyperiod_updatetime
INNER JOIN v_PC_POLICY POL ON POLPER.POLICYID = POL.ID  
        and polper.publicid=pol.pc_policyperiod_publicid
        and polper.updatetime=pol.pc_policyperiod_updatetime
LEFT JOIN v_PC_UWCOMPANY UW ON POLPER.UWCOMPANY = UW.ID 
INNER JOIN v_pctl_policyperiodstatus status ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)  
left join v_pctl_job jbt
ON job.Subtype = jbt.id
--TYPELISTS
--LEFT JOIN {rawDB}.PCTL_PROGRAMTYPE_EXT PROGTYPE ON PROGTYPE.ID = POLLINE.PROGRAMTYPE_EXT
--LEFT JOIN {rawDB}.PCTL_UWCOMPANYCODE UWCOMP ON UW.CODE = UWCOMP.ID
-- Added for NW specific Extensions
LEFT JOIN v_pctl_programtype_ext progtype ON progtype.id = polline.programtype_ext 
LEFT JOIN v_pctl_uwcompanycode uwcomp ON uw.Code = uwcomp.ID 
LEFT JOIN v_pctl_jurisdiction jurisdiction ON polper.BaseState = jurisdiction.ID 
LEFT JOIN v_PCX_LEGACYPREFIXBCODE_EXT pref_1
          ON uwcomp.typecode = pref_1.uwcompanycode
          AND pol.productcode = pref_1.productcode
          AND pref_1.programtypecode = progtype.typecode
          AND pref_1.statecode = jurisdiction.typecode
LEFT JOIN  v_PCX_LEGACYPREFIXBCODE_EXT pref_2
          on uwcomp.typecode = pref_2.uwcompanycode
          AND pol.productcode = pref_2.productcode
          AND pref_2.programtypecode = progtype.typecode
          AND pref_2.statecode = '*'
LEFT JOIN  v_PCX_LEGACYPREFIXBCODE_EXT pref_3
          on uwcomp.typecode = pref_3.uwcompanycode
          AND pol.productcode = pref_3.productcode
          AND pref_3.programtypecode = '*'
          AND pref_3.statecode = jurisdiction.typecode
LEFT JOIN  v_PCX_LEGACYPREFIXBCODE_EXT pref_4
          on uwcomp.typecode = pref_4.uwcompanycode
          AND pol.productcode = pref_4.productcode
          AND pref_4.programtypecode = '*'
          AND pref_4.statecode = '*'
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL).replace("{source_system}",source_system).replace("{lob}",lob)

# COMMAND ----------

def build_ds_motor_cargo_IMGMotorCargo (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query ="""
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.PCX_IMGMOTORCARGO_EXT_micro_batch)
,v_PCX_IMGMOTORCARGO_EXT as
(select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select PCX_IMGMOTORCARGO_EXT.*
			from {rawDB}.PCX_IMGMOTORCARGO_EXT          
            inner join global_temp.PCX_IMGMOTORCARGO_EXT_micro_batch   mb  
			   on mb.branchid = PCX_IMGMOTORCARGO_EXT.branchid 
			where PCX_IMGMOTORCARGO_EXT.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/*********,v_pc_policyperiod as
(
  select * from 
    (select polper.*,MotorCargo.publicid as PCX_IMGMOTORCARGO_EXT_publicid,MotorCargo.updatetime as PCX_IMGMOTORCARGO_EXT_updatetime,
      row_number() over (partition by MotorCargo.publicid,MotorCargo.updatetime,MotorCargo.BranchID 
      order by (unix_millis(MotorCargo.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_PCX_IMGMOTORCARGO_EXT MotorCargo
      JOIN {rawDB}.pc_policyperiod  polper 
        on MotorCargo.BranchID = polper.ID 
        and polper.updatetime <= MotorCargo.updatetime
    ) where rn=1
  union 
  select * from 
    (select polper.*,MotorCargo.publicid as PCX_IMGMOTORCARGO_EXT_publicid,MotorCargo.updatetime as PCX_IMGMOTORCARGO_EXT_updatetime,
      row_number() over (partition by MotorCargo.publicid,polper.updatetime,MotorCargo.BranchID
      order by (unix_millis(polper.updatetime) - unix_millis(MotorCargo.updatetime)) asc ) rn
      from v_PCX_IMGMOTORCARGO_EXT MotorCargo
      JOIN {rawDB}.pc_policyperiod  polper 
        on MotorCargo.BranchID = polper.ID 
        and MotorCargo.updatetime <= polper.updatetime
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as PCX_IMGMOTORCARGO_EXT_publicid,
    p.updatetime as PCX_IMGMOTORCARGO_EXT_updatetime
  from
    v_PCX_IMGMOTORCARGO_EXT p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId 
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn 
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime 
    ) where rn=1
  union 
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_imgcommodity_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_imgcommodity_ext IMComm    
		   Cross Join Events_Max_Updatetime mb  
			On IMComm.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_imgradius_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_imgradius_ext radius    
		   Cross Join Events_Max_Updatetime mb  
			On radius.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as
(
select * from
(select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn
from {rawDB}.pctl_job jbt
Cross Join Events_Max_Updatetime mb
On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1
)
,v_pctl_imgratingbasis_ext as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_imgratingbasis_ext ratingbasis    
		   Cross Join Events_Max_Updatetime mb  
			On ratingbasis.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
),
HRZ_Query as 
(
SELECT
  UPPER('GWPC'|| '-' || CAST ( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-'|| 
			CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:'|| CAST (polper.publicID AS VARCHAR (255))|| '-'
             ELSE '' END || 
			'IMGMotorCargo' || '-'|| CAST ( CAST (MotorCargo.FixedID AS INTEGER) AS VARCHAR (255)) 
		) AS MOTOR_CARGO_KEY
	,UPPER('GWPC' || '-' || cast( CAST (polper.PeriodID AS INTEGER) as varchar(255)) || 
		    CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) 
			ELSE ''
			END 
		)as POL_KEY
	,UPPER ('GWPC' || '-' || CAST ( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) || 
			CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST (polper.publicID AS VARCHAR(255))
            ELSE ''
            END || '-'|| 'IMGLine' || '-' || CAST ( CAST (MotorCargo.IMGLine AS INTEGER) AS VARCHAR (255))
		)AS POL_LINE_KEY
	,CAST (COALESCE (MotorCargo.EffectiveDate, polper.PeriodStart) AS DATE) AS END_EFF_DT
  ,CAST (COALESCE (MotorCargo.ExpirationDate, polper.PeriodEnd) AS DATE) AS END_EXP_DT
	,'GWPC' AS SOURCE_SYSTEM
	,'IM' as LOB_CD
	
	,AdulFoodLoadStand          as 	ADLT_FOOD_LOAD_STND_FCTR 
	,AdulFoodLoadOver           as 	ADLT_FOOD_LOAD_OVR_FCTR 
	,AnnGrossRec                as 	ANNUAL_GROSS_RECEIPT_AMT 
	,IMComm.TypeCode            as 	COMMODITY_CD 
	,IMComm.DESCRIPTION         as 	COMMODITY_TEXT 
	,CommodityClassCode         as 	COMMODITY_CLASS_CD 
	,ElecEquipLoadStand         as 	ELEC_EQP_LOAD_STND_FCTR 
	,ElecEquipLoadOver          as 	ELEC_EQP_LOAD_OVR_FCTR 
	,HouseholdGoodsInd          as 	HSHLD_GOODS_FL 
	,LegacyClassCode            as 	LGCY_CL_CD 
	,LegacyClassDesc 	          as      LGCY_CL_DESC 
	,LegacyItemNum              as 	LGCY_ITEM_NO 
	,MC2444FormInd   		    as      MC2444_FORM_FL 
	,MobEquipLoadStand          AS 	MOBILE_EQP_LOAD_STND_FCTR
	,MobEquipLoadOver           AS 	MOBILE_EQP_LOAD_OVR_FCTR 
	,MotorFilingsInd            as 	MOTOR_FILINGS_FL         
	,PerspropLoadOver           as 	PRSNL_PROP_LOAD_OVR_FCTR
	,PerspropLoadStand          as 	PRSNL_PROP_LOAD_STND_FCTR 
	,radius.TYPECODE            as 	RADIUS_CD 
	,radius.description         as 	RADIUS_TEXT 
	,RATINGBASIS.Typecode       as 	RATING_BASIS_CD 
	,RATINGBASIS.Description    as 	RATING_BASIS_TEXT        
	,TempAlarmInd		    as      TEMP_ALARM_FL            
	,TotLoadRecStand            as 	TOTAL_LOAD_REC_STND_FCTR 
	,TotLoadRecOver  		    as      TOTAL_LOAD_REC_OVR_FCTR  
	,TotLoadVchStand            as 	TOTAL_LOAD_VEH_STND_FCTR 
	,TotLoadVchOver             as 	TOTAL_LOAD_VEH_OVR_FCTR  
	,TrailCovLoadStand          as 	TRAIL_COV_LOAD_STND_FCTR 
	,TrailCovLoadOver           as 	TRAIL_COV_LOAD_OVR_FCTR  
	,NumVeh                     as 	VEH_CNT
	,CASE WHEN Status.TypeCode = 'Bound' THEN JOB.CloseDate
        ELSE COALESCE(POLPER.UpdateTime, POLPER.CreateTime)
     END AS ETL_ROW_EFF_DTS
,MotorCargo.branchid as SRC_BRANCHID
,MotorCargo.fixedid as SRC_FIXEDID
,MotorCargo.effectivedate as SRC_EFFECTIVEDATE
,MotorCargo.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,MotorCargo.createtime as SRC_CREATETIME
,MotorCargo.updatetime  as SRC_UPDATETIME
,MotorCargo.publicid as SRC_PUBLICID
,MotorCargo.updatetime as updatetime_tab1
,polper.updatetime as updatetime_tab2
,job.updatetime as updatetime_tab3
,'GWPC-IM-{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL
FROM
v_PCX_IMGMOTORCARGO_EXT as MotorCargo
INNER JOIN v_pc_policyperiod polper
on MotorCargo.BranchID=polper.ID
and MotorCargo.publicid=polper.PCX_IMGMOTORCARGO_EXT_publicid
and MotorCargo.updatetime=polper.PCX_IMGMOTORCARGO_EXT_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
JOIN v_pctl_policyperiodstatus status ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
LEFT JOIN v_pctl_imgcommodity_ext IMComm ON MotorCargo.Commodity = IMComm.ID
LEFT JOIN v_pctl_imgradius_ext radius ON MotorCargo.RADIUS = Radius.ID
LEFT JOIN v_pctl_imgratingbasis_ext ratingbasis ON MotorCargo.RATINGBASIS = ratingbasis.ID
left join v_pctl_job jbt
ON job.Subtype = jbt.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_transit_IMGTransit (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """   
With Events_Max_Updatetime As ( Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imgtransit_ext_micro_batch)
,v_pcx_imgtransit_ext as
(select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc) as rn 
         from
         (select pcx_imgtransit_ext.*
			from {rawDB}.pcx_imgtransit_ext pcx_imgtransit_ext  
 			inner join global_temp.pcx_imgtransit_ext_micro_batch mb  
			 on pcx_imgtransit_ext.BranchID = mb.BranchID  
			where pcx_imgtransit_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/******************,v_pc_policyperiod as
(
  select * from 
    (select polper.*,transit.publicid as pcx_imgtransit_ext_publicid,transit.updatetime as pcx_imgtransit_ext_updatetime,
      row_number() over (partition by transit.publicid,transit.updatetime,transit.BranchID 
      order by (unix_millis(transit.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pcx_imgtransit_ext transit
      JOIN {rawDB}.pc_policyperiod  polper 
        on transit.BranchID = polper.ID 
        and polper.updatetime <= transit.updatetime
    ) where rn=1
  union 
  select * from 
    (select polper.*,transit.publicid as pcx_imgtransit_ext_publicid,transit.updatetime as pcx_imgtransit_ext_updatetime,
      row_number() over (partition by transit.publicid,polper.updatetime,transit.BranchID
      order by (unix_millis(polper.updatetime) - unix_millis(transit.updatetime)) asc ) rn
      from v_pcx_imgtransit_ext transit
      JOIN {rawDB}.pc_policyperiod  polper 
        on transit.BranchID = polper.ID 
        and transit.updatetime <= polper.updatetime
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imgtransit_ext_publicid,
    p.updatetime as pcx_imgtransit_ext_updatetime
  from
    v_pcx_imgtransit_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job as
(
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId 
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn 
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime 
    ) where rn=1
  union 
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime
    ) where rn=1
)
 ,v_pctl_job as
(
select * from
(select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn
from {rawDB}.pctl_job jbt
Cross Join Events_Max_Updatetime mb
On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1
)
,v_pctl_policyperiodstatus as 
(select * from
(select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_policyperiodstatus status    
Cross Join Events_Max_Updatetime mb On status.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1 )
,v_pctl_imgcommodity_ext as 
(select * from 
(select *,row_number() over (partition by id order by id desc) as rn from {rawDB}.pctl_imgcommodity_ext imgcommodity
Cross Join Events_Max_Updatetime mb On imgcommodity.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1)
,v_pctl_imgradius_ext as 
(
select * from (select *,row_number() over (partition by id order by id desc) as rn from {rawDB}.pctl_imgradius_ext imgradius
Cross Join Events_Max_Updatetime   mb  On imgradius.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1 )
,v_pctl_imgratingbasis_ext as 
(select * from (select *,row_number() over (partition by id order by id desc) as rn from {rawDB}.pctl_imgratingbasis_ext imgratingbasis
Cross Join Events_Max_Updatetime   mb  On imgratingbasis.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1)
,v_pctl_imgtransitclass_ext as 
(select * from (select *,row_number() over (partition by id order by id desc) as rn from {rawDB}.pctl_imgtransitclass_ext imgtransitclass 
Cross Join Events_Max_Updatetime   mb  On imgtransitclass.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1)
,
HRZ_Query as 
(
SELECT 
UPPER ( 'GWPC' || '-' ||CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || '-' || CASE WHEN status.TypeCode <> 'Bound' THEN 'QT:' || CAST (polper.publicID AS VARCHAR (255)) || '-' ELSE '' END || 'IMGTransit' || '-' || CAST(CAST (transit.FixedID AS INTEGER) AS VARCHAR (255))) AS TRANSIT_KEY, 
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END) AS POL_KEY, 
UPPER ( 'GWPC' || '-' || CAST (CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) || CASE WHEN status.TypeCode <> 'Bound' THEN '-' || 'QT:' || CAST (polper.publicID AS VARCHAR (255)) ELSE '' END || '-' || 'IMGLine' || '-' || CAST (cast (transit.IMGLine AS INTEGER) AS VARCHAR (255))) AS POL_LINE_KEY, 
CAST (COALESCE (transit.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE) AS END_EFF_DT, 
CAST (COALESCE (transit.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE) AS END_EXP_DT, 
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'GWPC' AS SOURCE_SYSTEM, 
'IM' as LOB_CD, 
transit.AnnValAir  as ANNUAL_AIR_VALUE_AMT, 
transit.AnnValCarr  as ANNUAL_CARRIER_VALUE_AMT, 
transit.AnnValOwnVeh  as ANNUAL_OWNED_VEH_VALUE_AMT, 
transit. AnnValRail  as ANNUAL_RR_SHIP_VALUE_AMT, 
transit.AnnValShip  as ANNUAL_SHIP_VALUE_AMT, 
transit.BLAirShipStand  as BSC_LOAD_AIR_SHIP_FCTR, 
transit.BLAirShipOver  as BSC_LOAD_AIR_SHIP_OVR_FCTR, 
transit.BLCommCarStand  as BSC_LOAD_COMM_CAR_FCTR, 
transit.BLCommCarOver  as BSC_LOAD_COMM_CAR_OVR_FCTR, 
transit.BLOwnVehStand  as BSC_LOAD_OWN_VEH_FCTR, 
transit.BLOwnVehOver  as BSC_LOAD_OWN_VEH_OVR_FCTR, 
transit.BLPerVehStand  as BSC_LOAD_PER_VEH_FCTR, 
transit.BLPerVehOver  as BSC_LOAD_PER_VEH_OVR_FCTR, 
transit.BLRailShipStand  as BSC_LOAD_RR_SHIPMENT_FCTR, 
transit.BLRailShipOver  as BSC_LOAD_RR_SHIPMENT_OVR_FCTR, 
IMComm.TYPECODE as COMMODITY_CD, 
IMComm.Description AS COMMODITY_TEXT, 
transit.CommodityClassCode as COMMODITY_CLASS_CD,
transit.DateFrom as DATE_FROM_DTS, 
transit.DateTo as DATE_TO_DTS,
transit.LegacyClassCode   AS LGCY_CL_CD,
transit.LegacyClassDesc  AS LGCY_CL_DESC,
transit.LegacyItemNum  AS LGCY_ITEM_NO,
IMRad.TYPECODE as RADIUS_CD, 
IMRad.Description AS RADIUS_TEXT, 
IMRat.Typecode as RATING_BASIS_CD, 
IMRat.Description AS RATING_BASIS_TEXT, 
transit.RefBreadkVehStand  as REFRIG_BRKDWN_VEH_FCTR,
transit.RefBreadkVehOver  as REFRIG_BRKDWN_VEH_OVR_FCTR, 
transit.RefBreakVolStand  as REFRIG_BRKDWN_VOL_FCTR, 
transit.RefBreakVolOver  as REFRIG_BRKDWN_VOL_OVR_FCTR, 
transit.ShipFrom as SHIP_FROM_DESC, transit.ShipTo as SHIP_TO_DESC, 
transit.TargetModStand  as TARGET_CARGO_MOD_FCTR, 
transit.TargetModOver  as TARGET_CARGO_MOD_OVR_FCTR,
transit.TempAlarm as TEMP_ALARM_FL, 
IMTransitclass.TypeCode as TRANSIT_CLASS_CD, 
IMTransitclass.Description AS TRANSIT_CLASS_TEXT, 
transit.TripTranModOver as TRIP_TRANSIT_MOD_OVR_FCTR, 
transit.NumOwnVeh as VEH_QTY
,transit.branchid as SRC_BRANCHID
,transit.fixedid as SRC_FIXEDID
,transit.effectivedate as SRC_EFFECTIVEDATE
,transit.expirationdate as SRC_EXPIRATIONDATE
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,transit.createtime as SRC_CREATETIME
,transit.updatetime  as SRC_UPDATETIME
,transit.publicid as SRC_PUBLICID
,transit.updatetime as updatetime_tab1
,polper.updatetime as updatetime_tab2
,job.updatetime as updatetime_tab3
,'GWPC-IM-IMGTransit' AS PARTITION_VAL 
FROM v_pcx_imgtransit_ext transit 
INNER JOIN v_pc_policyperiod polper
on transit.BranchID=polper.ID
and transit.publicid=polper.pcx_imgtransit_ext_publicid
and transit.updatetime=polper.pcx_imgtransit_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
JOIN v_pctl_policyperiodstatus status ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join v_pctl_job jbt
ON job.Subtype = jbt.id
LEFT JOIN v_pctl_imgcommodity_ext IMComm ON transit.Commodity = IMComm.ID
LEFT JOIN v_pctl_imgradius_ext IMRad ON transit.RADIUS = IMRad.ID
LEFT JOIN v_pctl_imgratingbasis_ext IMRat ON transit.RATINGBASIS = IMRat.ID
LEFT JOIN v_pctl_imgtransitclass_ext IMTransitclass on transit.TransitClass = IMTransitclass.ID 
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
) 
 
"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)

# COMMAND ----------

def build_ds_mod_rf_IMGLine (rawDB,CVRBL_TYPE_CD_VAL):
  source_system = "GWPC"
  lob_cd = "IM"  
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_imglinerf_ext_micro_batch)
  ,pcx_imglinerf_ext_micro_batch as (select distinct branchid,updatetime from global_temp.pcx_imglinerf_ext_micro_batch )
,v_pcx_imglinerf_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_imglinerf_ext.*
			from {rawDB}.pcx_imglinerf_ext pcx_imglinerf_ext
            inner join pcx_imglinerf_ext_micro_batch   mb  
			   on mb.branchid = pcx_imglinerf_ext.branchid 
			where pcx_imglinerf_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/************************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,linerf.publicid as pcx_imglinerf_ext_publicid,linerf.updatetime as pcx_imglinerf_ext_updatetime,
      row_number() over (partition by linerf.publicid,linerf.updatetime,linerf.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(linerf.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_imglinerf_ext  linerf
      JOIN {rawDB}.pc_policyperiod  polper 
        on linerf.BranchID = polper.ID 
        and polper.updatetime <= linerf.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,linerf.publicid as pcx_imglinerf_ext_publicid,linerf.updatetime as pcx_imglinerf_ext_updatetime,
      row_number() over (partition by linerf.publicid,polper.updatetime,linerf.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(linerf.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_imglinerf_ext linerf
      JOIN {rawDB}.pc_policyperiod  polper 
        on linerf.BranchID = polper.ID 
        and linerf.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_imglinerf_ext_publicid,
    p.updatetime as pcx_imglinerf_ext_updatetime
  from
    v_pcx_imglinerf_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
 
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
) 
,HRZ_Query as 
( SELECT 
UPPER('GWPC'  ||'-'|| cast(polper.PeriodID as INTEGER) || case when status.TYPECODE<> 'Bound' then '-QT:' || POLPER.publicid ELSE '' END ||'-' || 'IMGLine' || '-' || cast(linerf.FixedID as INTEGER) )as MOD_RF_KEY
,UPPER('GWPC' ||'-'|| cast(polper.PeriodID as INTEGER) || case when status.TYPECODE<> 'Bound' then '-QT:' || POLPER.publicid ELSE '' END ) as POL_KEY
,UPPER('GWPC'  ||'-'|| cast(polper.PeriodID as INTEGER) || case when status.TYPECODE<> 'Bound' then '-QT:' || POLPER.publicid ELSE '' END ||'-' || 'IMGLine' || '-' || cast(linerf.IMGLineModifier as INTEGER) ) as LINE_MOD_KEY,
CAST ( COALESCE (linerf.EffectiveDate, polper.PeriodStart, to_timestamp('1900-01-01 00:00:00.000000')) AS DATE)    AS END_EFF_DT,
CAST ( COALESCE (linerf.ExpirationDate, polper.PeriodEnd, to_timestamp('9999-12-31 00:00:00.000000')) AS DATE)     AS END_EXP_DT,
'GWPC' AS SOURCE_SYSTEM,
COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime) END ,to_timestamp('1900-01-01 00:00:00.000000'))  AS ETL_ROW_EFF_DTS,
'{CVRBL_TYPE_CD_VAL}' AS CVRBL_TYPE_CD,
'IM' AS LOB_CD ,
COALESCE(linerf.PatternCode, ' ') AS RF_CD,
COALESCE(RF_CD.RATEFACTORTYPE, 'Not Defined') AS RF_TEXT,
COALESCE(linerf.Assessment, 0 ) AS ASSESS_RATE,
COALESCE(linerf.Justification, ' ') AS JUST_DESC,
COALESCE(linerf.AVAILABLECREDITFACTOR, 0) AS AVLBL_CR_FCTR,
COALESCE(linerf.AVAILABLEDEBITFACTOR, 0) AS AVLBL_DB_FCTR,
COALESCE(pj.TYPECODE, ' ') AS PRICING_JUST_TYPE_CD,
COALESCE(Pj.Name, 'Not Defined') AS PRICING_JUST_TYPE_TEXT,
COALESCE(linerf.RECOMMENDEDFACTOR, 0) AS RCMND_FCTR,
COALESCE(linerf.SUGGESTEDMINFACTOR, 0) AS SGSTD_MIN_FCTR,
linerf.branchid as SRC_BRANCHID,
linerf.fixedid as SRC_FIXEDID,
linerf.effectivedate as SRC_EFFECTIVEDATE,
linerf.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
linerf.createtime as SRC_CREATETIME,
linerf.updatetime  as SRC_UPDATETIME,
linerf.publicid as SRC_PUBLICID,
linerf.updatetime as updatetime_tab1,
polper.updatetime  as updatetime_tab2,
job.updatetime as updatetime_tab3
--,'{source_system}-{lob_cd}-{cvrbl_type}' AS PARTITION_VAL 
,'{source_system}-{lob_cd}-{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL 
 
FROM 
v_pcx_imglinerf_ext as linerf
INNER JOIN v_pc_policyperiod polper
on linerf.BranchID=polper.ID
and linerf.publicid=polper.pcx_imglinerf_ext_publicid
and linerf.updatetime=polper.pcx_imglinerf_ext_updatetime
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
left join v_pctl_job jbt
ON job.Subtype = jbt.id
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join 
		(
		select * from 
			(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn 
			from {rawDB}.pctl_pricingjustification_ext pj
			Cross Join Events_Max_Updatetime mb  On pj.z_meta_event_timestamp <= mb.mb_max_updatetime)
			where rn=1) pj 
on linerf.rcmndjustificationtype_ext = pj.id
left join 
		(
		select * from 
			(select *,row_number() over (partition by patternid order by z_meta_event_timestamp  desc) as rn 
			from {rawDB}.pc_etlratefactorpattern rf_cd
			Cross Join Events_Max_Updatetime mb  On rf_cd.z_meta_event_timestamp <= mb.mb_max_updatetime)
			where rn=1) rf_cd 
on linerf.patterncode = rf_cd.patternid
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL).replace("{source_system}", source_system).replace("{lob_cd}", lob_cd)

# COMMAND ----------

def build_ds_flood_info_IMGLoc (rawDB,CVRBL_TYPE_CD_VAL):
  harmz_query = """
  With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_floodinfo_ext_micro_batch), 
  pcx_floodinfo_ext_micro_batch as (select distinct BranchID,updatetime from global_temp.pcx_floodinfo_ext_micro_batch )
  
,v_pcx_floodinfo_ext as
  (select * from 
		(select *,row_number() over (partition by  publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_floodinfo_ext.*
			from {rawDB}.pcx_floodinfo_ext          
            inner join pcx_floodinfo_ext_micro_batch   mb  
			   on mb.BranchID = pcx_floodinfo_ext.BranchID 
			where pcx_floodinfo_ext.updatetime <= mb.updatetime  
			)
		) where rn = 1)
/**********************,v_pc_policyperiod
( --consider parent record as driving record
  select * from 
    (select polper.*,flood.publicid as pcx_floodinfo_ext_publicid,flood.updatetime as pcx_floodinfo_ext_updatetime,
      row_number() over (partition by flood.publicid,flood.updatetime,flood.BranchID  --updatetime should be from parent in partition clause
      order by (unix_millis(flood.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_floodinfo_ext  flood
      JOIN {rawDB}.pc_policyperiod  polper 
        on flood.BranchID = polper.ID 
        and polper.updatetime <= flood.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select polper.*,flood.publicid as pcx_floodinfo_ext_publicid,flood.updatetime as pcx_floodinfo_ext_updatetime,
      row_number() over (partition by flood.publicid,polper.updatetime,flood.BranchID  --updatetime should be from child in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(flood.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_floodinfo_ext flood
      JOIN {rawDB}.pc_policyperiod  polper 
        on flood.BranchID = polper.ID 
        and flood.updatetime <= polper.updatetime --parent update time <= child update time
    ) where rn=1
)*************************/

              ------------Change code starts here for optimization----------------

  , v_pc_policyperiod_bulk as (
  select
    POLPER.PeriodID,
    polper.PublicID,
    polper.CreateTime,
    polper.UpdateTime,
    polper.ID as polper_BranchID,
    p.updatetime as p_updatetime,
    p.BranchID as p_BranchID,
    polper.PeriodStart,
    polper.PeriodEnd,
    POLPER.periodstart as POLPER_PERIODSTART,
    POLPER.periodend as POLPER_PERIODEND,
    POLPER.publicid as POLPER_PUBLICID,
    Polper.Id,
    polper.status,
    polper.temporaryclonestatus,
    polper.jobId,
    POLPER.ModelNumber,
    p.publicid as p_publicid,
    p.publicid as pcx_floodinfo_ext_publicid,
    p.updatetime as pcx_floodinfo_ext_updatetime
  from
    v_pcx_floodinfo_ext p  --parent
    JOIN {rawDB}.pc_policyperiod polper --child
    on p.BranchID = polper.ID
    JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID
    JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id
    and cast(substr(Agencynum_ext, 4) as int) not between 29800 and 29999
    and grp.Agencynum_ext != '00019999'
    and polper.PolicyNumber NOT IN ('ACP BP013200000000', 'ACP BP013200000761')
),
v_pc_policyperiod as (
  select
    *
  from(
    ---consider parent record as driving record---
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.p_updatetime, --updatetime should be from parent in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(p_updatetime) - unix_millis(updatetime)  --order by should be based on parent updatetime minus child update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.updatetime <= blk.p_updatetime  --child update time <= parent update  time
    )
  where
    rn = 1
    
union all

--consider child record as driving record
select
    *
  from(
      select
        *,
        row_number() over (
          partition by blk.p_publicid,
          blk.updatetime,  --updatetime should be from child in partition clause
          blk.p_BranchID
          order by
            (
              unix_millis(updatetime) - unix_millis(p_updatetime) --order by should be based on child updatetime minus parent update time of joining tables
            ) asc
        ) rn
      from
        v_pc_policyperiod_bulk blk
      where
        blk.p_updatetime <= blk.updatetime  --parent update time <= child update time
    )
  where
    rn = 1
)

   ------------Change code ends here for optimization----------------
   
,v_pc_job 
(
  --consider parent record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  --updatetime should be from parent in partition clause
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  --updatetime should be from child in partition clause
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime --parent update time <= child update time
    ) where rn=1
),
v_pcx_imglocation_ext
( --consider parent record as driving record
  select * from 
    (select imgloc.*,flood.publicid as pcx_floodinfo_ext_publicid,flood.updatetime as pcx_floodinfo_ext_updatetime,
      row_number() over (partition by flood.publicid,flood.updatetime,flood.IMGLOCATION  --updatetime should be from parent in partition clause
      order by (unix_millis(flood.updatetime) - unix_millis(imgloc.updatetime)) asc ) rn -- order by should be based on parent updatetime minus child update time of joining tables
      from v_pcx_floodinfo_ext  flood
      JOIN {rawDB}.PCX_IMGLOCATION_EXT  imgloc 
        on flood.IMGLOCATION = imgloc.FIXEDID 
          AND flood.BRANCHID = imgloc.BRANCHID
        and imgloc.updatetime <= flood.updatetime  --child update time <= parent update  time
    ) where rn=1
  union 
  --consider child record as driving record
  select * from 
    (select imgloc.*,flood.publicid as pcx_floodinfo_ext_publicid,flood.updatetime as pcx_floodinfo_ext_updatetime,
      row_number() over (partition by flood.publicid,imgloc.updatetime,flood.IMGLOCATION  --updatetime should be from child in partition clause
      order by (unix_millis(imgloc.updatetime) - unix_millis(flood.updatetime)) asc ) rn -- order by should be based on child updatetime minus parent update time of joining tables
      from v_pcx_floodinfo_ext flood
      JOIN {rawDB}.PCX_IMGLOCATION_EXT  imgloc 
         on flood.IMGLOCATION = imgloc.FIXEDID 
          AND flood.BRANCHID = imgloc.BRANCHID
        and flood.updatetime <= imgloc.updatetime --parent update time <= child update time
    ) where rn=1
)
,v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
		   Cross Join Events_Max_Updatetime mb  
			On status.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,v_pctl_job as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_job jbt    
		   Cross Join Events_Max_Updatetime mb  
		   On jbt.z_meta_event_timestamp <= mb.mb_max_updatetime
		) where rn=1
)
,HRZ_Query as 
(
SELECT 
UPPER('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) ||CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) ELSE '' END|| '-' ||'{CVRBL_TYPE_CD_VAL}' ||'-'||CAST(CAST (flood.FixedID AS INTEGER) AS VARCHAR (255))) AS FLOOD_INFO_KEY
,COALESCE(UPPER('GWPC' || '-' || CAST( CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) ||CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) ELSE ''END),'NOKEY') as POL_KEY  
,COALESCE(UPPER('GWPC' || '-' || CAST(CAST (polper.PeriodID AS INTEGER) AS VARCHAR (255)) ||CASE WHEN status.TypeCode <> 'Bound' THEN '-'  || 'QT:' || CAST(polper.publicID AS VARCHAR(255)) ELSE '' END ||'-' ||'{CVRBL_TYPE_CD_VAL}' || '-' || CAST(cast(IMGLOC.FixedID AS INTEGER)as varchar(255))),'NOKEY')  as CVRBL_KEY
,CAST(coalesce(flood.EffectiveDate, polper.PeriodStart,('1900-01-01')) as date) as END_EFF_DT
,CAST(coalesce(flood.ExpirationDate, polper.PeriodEnd,('9999-12-31')) as date) as END_EXP_DT
,COALESCE(CASE WHEN status.TypeCode = 'Bound' THEN job.CloseDate 
ELSE COALESCE (POLPER.UpdateTime, POLPER.CreateTime)
 END, to_timestamp('1900-01-01 00:00:00.000000')) AS ETL_ROW_EFF_DTS
,'GWPC' as SOURCE_SYSTEM
,'IM' AS LOB_CD
,'{CVRBL_TYPE_CD_VAL}' as CVRBL_TYPE_CD
,'GWPC'||'-'||'IM'||'-'||'{CVRBL_TYPE_CD_VAL}' AS PARTITION_VAL
,NVL(cast(coalesce(flood.FLOODRISKSCORE,0) as NUMERIC(18,4)),0) AS FLOOD_RISK_SCORE
,NVL(cast(coalesce(flood.FLASHFLOODRISKSCORE,0) as NUMERIC(18,4)),0) AS FLASH_FLOOD_RISK_SCORE
,NVL(cast(coalesce(flood.FLOODDISTANCETO100YRZONES,0) as NUMERIC(18,4)),0) AS FLOOD_DISTNC_100_ZONE
,NVL(cast(coalesce(flood.FLOODDISTANCETO500YRZONES,0) as NUMERIC(18,4)),0) AS FLOOD_DISTNC_500_ZONE
,NVL(cast(coalesce(flood.FLOODELEVATIONVARIANCE,0) as NUMERIC(18,4)),0) AS FLOOD_ELVTN_VRNC
,COALESCE(floodres.TYPECODE,' ') AS FLOOD_RESULT_CD
,COALESCE(floodres.DESCRIPTION,'Not Defined') AS FLOOD_RESULT_TEXT
,COALESCE(flood.FLOODZONE,' ') AS FLOOD_ZONE,
flood.branchid as SRC_BRANCHID,
flood.fixedid as SRC_FIXEDID,
flood.effectivedate as SRC_EFFECTIVEDATE,
flood.expirationdate as SRC_EXPIRATIONDATE,
polper.periodstart as POLPER_PERIODSTART,
polper.periodend as POLPER_PERIODEND,
polper.publicid as POLPER_PUBLICID,
flood.createtime as SRC_CREATETIME,
flood.updatetime  as SRC_UPDATETIME,
flood.publicid as SRC_PUBLICID,
flood.updatetime as updatetime_tab1,
polper.updatetime as updatetime_tab2,
job.updatetime as updatetime_tab3
 
FROM 
v_pcx_floodinfo_ext flood
INNER JOIN v_pc_policyperiod polper
on flood.BranchID=polper.ID
INNER JOIN v_pc_job job
on polper.jobid=job.id
and polper.publicid=job.pc_policyperiod_publicid
and polper.updatetime=job.pc_policyperiod_updatetime
INNER JOIN v_pcx_imglocation_ext imgloc
on flood.IMGLOCATION= imgloc.FIXEDID and flood.BRANCHID = imgloc.BRANCHID
AND COALESCE(flood.EFFECTIVEDATE, POLPER.PERIODSTART) >= COALESCE(imgloc.EFFECTIVEDATE, POLPER.PERIODSTART)
AND COALESCE(flood.EFFECTIVEDATE, POLPER.PERIODSTART) <  COALESCE(imgloc.EXPIRATIONDATE, POLPER.PERIODEND)
and flood.publicid=polper.pcx_floodinfo_ext_publicid
and flood.updatetime=polper.pcx_floodinfo_ext_updatetime
inner join v_pctl_policyperiodstatus status
ON polper.status = status.ID
and not ( status.typecode = 'Bound' and job.closedate is null)
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_hazardresult_ext floodres
Cross Join Events_Max_Updatetime mb  On floodres.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) floodres 
on flood.FLOODRESULT = floodres.id
left join v_pctl_job jbt
ON job.Subtype = jbt.id
WHERE status.typecode = 'Bound' or (status.typecode <> 'Bound' and not (polper.temporaryclonestatus <> 1 and jbt.typecode = 'Submission' and status.typecode = 'Quoted'))
)

"""
  return harmz_query.replace("{rawDB}",rawDB).replace("{CVRBL_TYPE_CD_VAL}", CVRBL_TYPE_CD_VAL)