# Databricks notebook source
# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_nm_check_status(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in NM Check Status: \n")
  harmz_query = """ 

select
  concat('NM-',nmstatus.submissionId) as NM_CHECK_STATUS_KEY,
  concat('NM-',nmstatus.submissionId) as NM_SUBMIT_KEY,
  nmstatus.submissionId as SUBMISSION_ID,
  to_timestamp(nmstatus.submittedTime) as SUBMIT_DTS,
  to_timestamp(nmstatus.completedTime) as COMPLETE_DTS,
  case when nmstatus.onlineProcessing ='FALSE' THEN 'N' ELSE 'Y' END as ONLINE_PROCESSING_FL,
  to_timestamp(nmstatus.crawlStartTime) as CRAWL_START_DTS,
  nmstatus.errorMessage as ERROR_MSG,
  nmstatus.crawlSoftStop as CRAWL_SOFT_STOP,
  nmstatus.crawlDataStatusCode as CRAWL_DATA_STATUS_CD,
  nmstatus.companyId as COMPANY_ID,
  nmstatus.segment as SEGMENT_NAME,
  'NM' as SOURCE_SYSTEM,
  nmstatus.timestamp as ETL_ROW_EFF_DTS,
  case when nmstatus.crawlDataStatus ='FALSE' THEN 'N' ELSE 'Y' END as CRAWL_DATA_STATUS_FL,
  nmstatus.timeDifference as TIME_DIFFERENCE,
  nmstatus.classMapping as CLASS_MAPPING,
  nmstatus.trackingId as TRACK_ID,
  nmstatus.crawlSoftCommitDataStatus as CRAWL_SOFT_CMT_DATA_STATUS,
  nmstatus.statusCode as STATUS_CD,
  nmstatus.status as STATUS_DESC,
  'NM' AS PARTITION_VAL,
  COALESCE( case when nmstatus.update ='FALSE' THEN 'N' 
  when nmstatus.update ='TRUE' THEN 'Y'
  ELSE ' ' END) as UPDATE_FL
  from global_temp.nm_status_micro_batch micro_status

inner join 
 
 (select * from 
		(select *,row_number() over (partition by submissionId, timestamp order by timestamp desc) as rn 
         from
         (select nm_status.*
			from {rawDB}.nm_status nm_status  
            
			inner join global_temp.nm_status_micro_batch mb  
            on mb.nm_submissionId = nm_status.submissionId 
			where nm_status.timestamp <= mb.nm_timestamp  
			)
		) where rn = 1) nmstatus

on nmstatus.submissionId = micro_status.nm_submissionId 
  """ 
 
  
  harmz_query = harmz_query.replace("{rawDB}", rawDB)
  print("harmz_query after rawDB replace: "+ harmz_query)
  
  microBatchDF.createOrReplaceGlobalTempView(f"nm_status_micro_batch")
  
  queryDF=spark.sql(harmz_query) 

  print("queryDF:")
  queryDF.show(3)  
  print(queryDF.count())
  
  harmonized_table = f"{harmonizedDB}.{target}"
    
  queryDF.createOrReplaceGlobalTempView("hmquery_nm_status")
  hashDF = addHashColumn_clt("hmquery_nm_status")
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, "NM_CHECK_STATUS_KEY")
  
  auditDF = addAuditColumns_clt(dedupDF, "NM_CHECK_STATUS_KEY")

  surrogateKeyDF = addSurrogateKey_clt(auditDF,harmonized_table) 
  
  defaultMerge_clt(surrogateKeyDF,harmonized_table) 

  print("Job Successfully Completed")
  endtime = datetime.now()
