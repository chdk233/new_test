# Databricks notebook source
# MAGIC %run ../../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

#%run ../../../../../../utils/_utils

# COMMAND ----------

# MAGIC %run ../../../../../harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

# MAGIC %run ../../../_event_library_agreement

# COMMAND ----------

# MAGIC %scala
# MAGIC // configuration to reduce th DBIO file fragments 
# MAGIC spark.conf.set("spark.databricks.io.cache.enabled", "false")

# COMMAND ----------

def agreement_clpc_addnl_intrst(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str):
      print("microBatchDF...in agreement_clpc_addnl_intrst: \n")
      starttime = datetime.now() 
      try:
          if(microBatchDF.count() > 0):
            print("In try -", datetime.now(), "\n")

            micro_batch = "pc_addlinterestdetail_micro_batch"
            print("Micro_Batch Name ******* :-" ,micro_batch)
            microBatchDF.createOrReplaceGlobalTempView(micro_batch)
            im_lob_cd ="IM"
            cop_lob_cd ="COP"
            source_system = "GWPC"
            partition_val = "GWPC-IM"
            TaskGroupId = f'{param_str.split("#")[7]}'
            taskGroup = getTaskGroup(TaskGroupId)
            source_table = taskGroup["source_table"]
          
            keycol = 'ADDL_INTRST_KEY'
            key = 'ADDL_INTRST_KEY,END_EFF_DT'
            scdkey = 'ADDL_INTRST_KEY,ETL_ROW_EFF_DTS,END_EFF_DT'
            harmonized_table = harmonizedDB +"."+target

            print("********************Before build_addnl_intrst query ******* :-")   
            harmz_query = build_addnl_intrst(micro_batch,rawDB,harmonizedDB,im_lob_cd,cop_lob_cd,source_system)
            print("********************After build_addnl_intrst query ******* :-")                    
            print("********************Before generate_DHF_query ******* :-") 
            harmz_query = generate_DHF_query(harmz_query, scdkey, harmonized_table, micro_batch)
            print("********************After generate Query******* :-") 
            print("********************Executing the harmz_query******* :-")
            df = spark.sql(harmz_query)
            #caching the result of the harmonization query
            print("*********************harmz_query execution is complete******* :-")
            df.persist()

            print("Entering deduphashDF for Target- ",target ," for LOB - ",im_lob_cd,cop_lob_cd," \n")
            deduphashDF = removeDuplicatesMicrobatchByHash_clt(df,  key)
            deduphashDF.persist()
            print("deduphashDF  count for " ,deduphashDF.count(),"\n")
                    
            print("count before scd Merge ", df.count(), datetime.now(), "\n")
            surrogateID = f'{harmonized_table.split(".")[1][3:]}_ID'     
            scdDF = scdMerge_clt_perf(deduphashDF, harmonized_table, scdkey, "PARTITION_VAL", partition_val, surrogateID )
            scdDF.persist()
            print("scdDFCount:",scdDF.count(),datetime.now(),"\n")
            scdDF.show(1)

            print("Entering auditDF for Target- ",target ," for LOB - ",im_lob_cd,cop_lob_cd," \n")
            auditDF = addAuditColumnsRemoveDupsCdcSyncMultistream_clt_pt_perf(scdDF, harmonized_table, key,"PARTITION_VAL",  partition_val)
            auditDF.persist() 
            print("auditDF  count for " , auditDF.count(), " Completed at ", datetime.now(), "\n")

            print("Entering surrogateKeyDF for Target- ",target ," for LOB - ",im_lob_cd,cop_lob_cd, " \n")
            surrogateKeyDF = addSurrogateKey_Non_UDM(auditDF, harmonized_table)
            print("surrogateKeyDF  count for " , surrogateKeyDF.count(), " Completed at ", datetime.now(), "\n")

            #caching the result of the surrogate key function output
            surrogateKeyDF.persist()

            print("Entering defaultMerge for Target- ",target ," for LOB - ",im_lob_cd,cop_lob_cd, " \n")
            defaultMergeCdcMultistream_clt(surrogateKeyDF, harmonized_table, "PARTITION_VAL", partition_val)
            print("defaultMergeCdcMultistream_clt Completed at ", datetime.now(), "\n")
                    
            print("Entering orphanRecords_Clt_pt  for Target- ",target ," for LOB - ",im_lob_cd,cop_lob_cd, " \n")
            orphanRecords_Clt_pt (df,harmonized_table, "PARTITION_VAL",  partition_val, keycol) 
            print("orphanRecords_Clt completed for Target- ",target ," for LOB - ",im_lob_cd,cop_lob_cd, datetime.now(), " \n")
        
          else:
            print("Micro Batch Size is 0, Skipping rest of the functions for Target - " , target,"  and partition-",partition_val,"\n")
      except Exception as err:
            print("In Exception", err) 

      finally:
            print("Job Successfully Completed")
            endtime = datetime.now()
            print(" NoteBook Execution Start Time# ", starttime)
            print(" NoteBook Execution End  Time# " ,endtime)
            print(" NoteBook Run Time# " ,endtime - starttime ) 