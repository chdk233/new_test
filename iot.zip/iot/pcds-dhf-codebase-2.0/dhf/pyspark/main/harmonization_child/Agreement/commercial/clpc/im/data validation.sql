-- Databricks notebook source
-- MAGIC %md
-- MAGIC ###ds_line_cvrbl

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###scroll down to see other table validation queries

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_Line_cvrbl where ETL_ROW_EFF_DTS is null

-- COMMAND ----------

SELECT  LINE_CVRBL_KEY, END_EFF_DT, ETL_ROW_EFF_DTS, COUNT(*)
FROM dhf_harmonize_stromboli.ds_Line_cvrbl
GROUP BY LINE_CVRBL_KEY, END_EFF_DT, ETL_ROW_EFF_DTS
HAVING COUNT(*) > 1

-- COMMAND ----------

select 'ds_Line_cvrbl' as table_name , count(*) as id_dups from ( select LINE_CVRBL_ID , count(*) as dup_count from dhf_harmonize_stromboli.ds_Line_cvrbl group by LINE_CVRBL_ID having count(*) > 1)

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_Line_cvrbl where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'

-- COMMAND ----------

select LINE_CVRBL_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,count(*)
from dhf_harmonize_stromboli.ds_Line_cvrbl
where ETL_CURR_ROW_FL='Y'
group by LINE_CVRBL_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL
having count(*) > 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###DS_EXCL_TERM

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.DS_EXCL_TERM where ETL_ROW_EFF_DTS is null

-- COMMAND ----------

SELECT  EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS, COUNT(*)
FROM dhf_harmonize_stromboli.ds_excl_term
GROUP BY EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS
HAVING COUNT(*) > 1

-- COMMAND ----------

select 'ds_excl_term' as table_name , count(*) as id_dups from ( select EXCL_TERM_ID , count(*) as dup_count from dhf_harmonize_stromboli.ds_excl_term group by EXCL_TERM_ID having count(*) > 1)

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_excl_term where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'

-- COMMAND ----------

select EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,count(*)
from dhf_harmonize_stromboli.ds_excl_term
where ETL_CURR_ROW_FL='Y'
group by EXCL_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL
having count(*) > 1

-- COMMAND ----------

-- MAGIC %md ###DS_IM_BLDG_PROJ

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_im_bldg_proj where ETL_ROW_EFF_DTS is null

-- COMMAND ----------

SELECT  IM_BLDG_PROJ_KEY, END_EFF_DT, ETL_ROW_EFF_DTS, COUNT(*)
FROM dhf_harmonize_stromboli.ds_im_bldg_proj
GROUP BY IM_BLDG_PROJ_KEY, END_EFF_DT, ETL_ROW_EFF_DTS
HAVING COUNT(*) > 1


-- COMMAND ----------

select 'ds_im_bldg_proj' as table_name , count(*) as id_dups from ( select IM_BLDG_PROJ_ID , count(*) as dup_count from dhf_harmonize_stromboli.ds_im_bldg_proj group by IM_BLDG_PROJ_ID having count(*) > 1)


-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_im_bldg_proj where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'


-- COMMAND ----------

select IM_BLDG_PROJ_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,count(*)
from dhf_harmonize_stromboli.ds_im_bldg_proj 
where ETL_CURR_ROW_FL='Y'
group by IM_BLDG_PROJ_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL
having count(*) > 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##DS_TRANSIT

-- COMMAND ----------

SELECT  TRANSIT_KEY, END_EFF_DT, ETL_ROW_EFF_DTS, COUNT(*)
FROM dhf_harmonize_stromboli.ds_transit
GROUP BY TRANSIT_KEY, END_EFF_DT, ETL_ROW_EFF_DTS
HAVING COUNT(*) > 1


-- COMMAND ----------

--select *  from dhf_harmonize_stromboli.ds_transit where ETL_ROW_EFF_DTS is null;
select *  from dhf_harmonize_stromboli.ds_transit where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'


-- COMMAND ----------

select TRANSIT_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,count(*)
from dhf_harmonize_stromboli.ds_transit 
where ETL_CURR_ROW_FL='Y'
group by TRANSIT_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL
having count(*) > 1
