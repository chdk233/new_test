# Databricks notebook source
# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_nm_retreive(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in NM Retrieve: \n")
  harmz_query = """ 
    select
        concat('NM-',nmretrieve.companyId,'-',nmretrieve.submissionId) as NM_RETRIEVE_KEY, 
        concat('NM-',nmretrieve.submissionId) as NM_CHECK_STATUS_KEY, 
        nmretrieve.companyId as COMPANY_ID,
        nmretrieve.submissionId as SUBMISSION_ID,     
        nmretrieve.companyName as COMPANY_NAME,
        nmretrieve.trackingId as TRACK_ID,
        to_timestamp(nmretrieve.submittedTime) as SUBMIT_DTS,
        nmretrieve.submittedby as SUBMIT_BY,
        nmretrieve.companyVersion as COMPANY_VERS_NO,
        nmretrieve.segment as SEGMENT_NAME,
        nmretrieve.classMapping as CLASS_MAPPING,
        'NM' as SOURCE_SYSTEM,
        nmretrieve.companyAddress as COMPANY_ADDRESS,
        nmretrieve.streetAddress as ADDR_LINE,
        nmretrieve.city as CITY_NAME,
        nmretrieve.stateCode as STATE_CD,
        nmretrieve.state as STATE_DESC,
        nmretrieve.zipCode as ZIP_CD,
        nmretrieve.latitude as LATITUDE,
        nmretrieve.longitude as LONGITUDE,
        nmretrieve.geoLocation as GEO_LOCATION,
        nmretrieve.county as COUNTY_NAME,
        nmretrieve.countryCode as COUNTRY_CD,
        nmretrieve.companyStatusDesc as COMPANY_STATUS_DESC,
        nmretrieve.companyStatusSource as COMPANY_STATUS_SOURCE,
        case when nmretrieve.companyStatus = 'FALSE' then 'N' else 'Y' END as COMPANY_STATUS_FL,
        to_timestamp(nmretrieve.timestamp)  as ETL_ROW_EFF_DTS 
        from global_temp.nm_retrieve_micro_batch micro_retrieve
        
        inner join 
 
           (select * from 
                  (select *,row_number() over (partition by companyId,submissionId,timestamp order by timestamp desc) as rn 
                   from
                   (select nm_retrieve.*
                      from {rawDB}.nm_retrieve nm_retrieve  

                      inner join global_temp.nm_retrieve_micro_batch mb  
                       on mb.companyId = nm_retrieve.companyId 
                       and mb.submissionId = nm_retrieve.submissionId 
                      where nm_retrieve.timestamp <= mb.timestamp  
                      )
                  ) where rn = 1)  nmretrieve

          on nmretrieve.companyId = micro_retrieve.companyId 
          and nmretrieve.submissionId = micro_retrieve.submissionId 
  """
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB)       
  print("harm z_query after rawDB replace: "+ harmz_query)
  
  microBatchDF.createOrReplaceGlobalTempView(f"nm_retrieve_micro_batch")  
  queryDF=spark.sql(harmz_query)
    
  print("queryDF:")
  queryDF.show(3)  
  print(queryDF.count())
  
  harmonized_table = f"{harmonizedDB}.{target}"
  
  queryDF.createOrReplaceGlobalTempView("hmquery_nm_retrieve")
  hashDF = addHashColumn_clt("hmquery_nm_retrieve")
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, "NM_RETRIEVE_KEY")
  
  auditDF = addAuditColumns_clt(dedupDF, "NM_RETRIEVE_KEY")
 
  surrogateKeyDF = addSurrogateKey_clt(auditDF,harmonized_table) 
  
  defaultMerge_clt(surrogateKeyDF,harmonized_table)
    
  print("Job Successfully Completed")
  endtime = datetime.now()
