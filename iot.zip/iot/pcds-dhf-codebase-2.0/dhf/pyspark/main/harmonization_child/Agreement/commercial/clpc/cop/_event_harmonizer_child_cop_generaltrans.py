# Databricks notebook source
# MAGIC %run ../../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../../../harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

def merge_general_trans_cop(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in cop merge_general_trans: \n")
  harmonized_table = harmonizedDB +"."+target 
  source_system="GWPC"
  lob_cd="COP"
  partition_val = source_system+"-"+lob_cd
  starttime = datetime.now()
  
  TaskGroupId = f'{param_str.split("#")[7]}'
  taskGroup = getTaskGroup(TaskGroupId ) 
  source_table = taskGroup["source_table"]
  microBatchDF.createOrReplaceGlobalTempView(f"{source_table}_micro_batch")
  
  harmz_query =  """ 
With Events_Max_Updatetime As (Select max(updatetime) as mb_max_updatetime from global_temp.pcx_copcost_ext_micro_batch),
v_pcx_copcost_ext as
(select * from 
        (select *,row_number() over (partition by publicid,updatetime order by updatetime desc ) as rn 
         from
         (select pcx_copcost_ext.*
            from {rawDB}.pcx_copcost_ext          
            inner join global_temp.pcx_copcost_ext_micro_batch   mb  
               on cost_branchid = pcx_copcost_ext.branchid 
            where pcx_copcost_ext.updatetime <= mb.updatetime  
            )
        ) where rn = 1),
 
v_pc_policyperiod as 
   (select * from 
    (select polper.*,cost.publicid as pcx_copcost_ext_publicid,cost.updatetime as pcx_copcost_ext_updatetime,
      row_number() over (partition by cost.publicid,cost.updatetime,cost.BranchID  
      order by (unix_millis(cost.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pcx_copcost_ext cost
      JOIN {rawDB}.pc_policyperiod  polper 
        on cost.BranchID = polper.ID 
        and polper.updatetime <= cost.updatetime  
    ) where rn=1
  union 
   select * from 
    (select polper.*,cost.publicid as pcx_copcost_ext_publicid,cost.updatetime as pcx_copcost_ext_updatetime,
      row_number() over (partition by cost.publicid,polper.updatetime,cost.BranchID  
      order by (unix_millis(polper.updatetime) - unix_millis(cost.updatetime)) asc ) rn 
      from v_pcx_copcost_ext cost
      JOIN {rawDB}.pc_policyperiod  polper 
        on cost.BranchID = polper.ID 
        and cost.updatetime <= polper.updatetime 
    ) where rn=1
),
v_pc_job as 
   (select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn 
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  
    ) where rn=1
  union 
   select * from 
    (select job.*,polper.publicid as pc_policyperiod_publicid,polper.updatetime as pc_policyperiod_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pc_policyperiod  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime 
    ) where rn=1
),

v_pctl_job as (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_job jtype
Cross Join Events_Max_Updatetime mb  On jtype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1),

v_pctl_policyperiodstatus as 
(
    select * from
        (select *,row_number() over (partition by Id order by z_meta_event_timestamp  desc) as rn 
           from {rawDB}.pctl_policyperiodstatus status    
           Cross Join Events_Max_Updatetime mb  
            On status.z_meta_event_timestamp <= mb.mb_max_updatetime
        ) where rn=1
),
 
 v_pcx_coptransaction_ext 
(
  select * from 
    (select trans.*,cost.PublicId as pcx_copcost_ext_PublicId,cost.updatetime as pcx_copcost_ext_updatetime,
      row_number() over (partition by cost.PublicId,cost.updatetime,cost.id  
      order by (unix_millis(cost.updatetime) - unix_millis(trans.updatetime)) asc ) rn 
      from v_pcx_copcost_ext cost
      JOIN {rawDB}.pcx_coptransaction_ext   trans 
        on cost.id = trans.copcost 
        and trans.updatetime <= cost.updatetime  
    ) where rn=1
  union 
    select * from 
    (select trans.*,cost.PublicId as pcx_copcost_ext_PublicId,cost.updatetime as pcx_copcost_ext_updatetime,
      row_number() over (partition by cost.PublicId,trans.updatetime,cost.id 
      order by (unix_millis(trans.updatetime) - unix_millis(cost.updatetime)) asc ) rn 
      from v_pcx_copcost_ext cost
      JOIN {rawDB}.pcx_coptransaction_ext   trans 
        on cost.id = trans.copcost 
        and cost.updatetime <= trans.updatetime 
    ) where rn=1
),

 v_pc_policyperiod_tran as 
   (select * from 
    (select polper.*,Trans.publicid as  pcx_coptransaction_ext_publicid,Trans.updatetime as pcx_coptransaction_ext_updatetime,
      row_number() over (partition by Trans.publicid,Trans.updatetime,Trans.BranchID  
      order by (unix_millis(Trans.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pcx_coptransaction_ext Trans
      JOIN {rawDB}.pc_policyperiod  polper 
        on Trans.BranchID = polper.ID 
        and polper.updatetime <= Trans.updatetime  
    ) where rn=1
  union 
   select * from 
    (select polper.*,Trans.publicid as pcx_coptransaction_ext_publicid,Trans.updatetime as pcx_coptransaction_ext_updatetime,
      row_number() over (partition by Trans.publicid,polper.updatetime,Trans.BranchID  
      order by (unix_millis(polper.updatetime) - unix_millis(Trans.updatetime)) asc ) rn 
      from v_pcx_coptransaction_ext Trans
      JOIN {rawDB}.pc_policyperiod  polper 
        on Trans.BranchID = polper.ID 
        and Trans.updatetime <= polper.updatetime 
    ) where rn=1
 ),
  
v_pc_job_tran as 
(
  select * from 
    (select job.*,polper.publicid as pc_policyperiod_tran_publicid,polper.updatetime as pc_policyperiod_tran_updatetime,
      row_number() over (partition by polper.publicid,polper.updatetime,polper.JobId  
      order by (unix_millis(polper.updatetime) - unix_millis(job.updatetime)) asc ) rn 
      from v_pc_policyperiod_tran  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and job.updatetime <= polper.updatetime  
    ) where rn=1
  union 
    select * from 
    (select job.*,polper.publicid as pc_policyperiod_tran_publicid,polper.updatetime as pc_policyperiod_tran_updatetime,
      row_number() over (partition by polper.publicid,job.updatetime,polper.JobId  
      order by (unix_millis(job.updatetime) - unix_millis(polper.updatetime)) asc ) rn 
      from v_pc_policyperiod_tran  polper
      JOIN {rawDB}.pc_job   job 
        on polper.JobId = job.ID 
        and polper.updatetime <= job.updatetime 
    ) where rn=1
), 

v_pcx_copcommission_ext as 
(
    select * from 
    (select COPCOMM.*,cost.publicid as pcx_copcost_ext_publicid,cost.updatetime as pcx_copcost_ext_updatetime,
      row_number() over (partition by cost.publicid,cost.updatetime,cost.BranchID,cost.fixedid,COPCOMM.effectivedate,COPCOMM.expirationdate   
      order by (unix_millis(cost.updatetime) - unix_millis(COPCOMM.updatetime)) asc ) rn 
      from v_pcx_copcost_ext cost
      JOIN {rawDB}.pcx_copcommission_ext  COPCOMM 
        on cost.BranchID = COPCOMM.BranchID 
        and cost.fixedid = COPCOMM.copcost 
        and COPCOMM.updatetime <= cost.updatetime  
    ) where rn=1
  union 
  select * from 
    (select COPCOMM.*,cost.publicid as pcx_copcost_ext_publicid,cost.updatetime as pcx_copcost_ext_updatetime,
      row_number() over (partition by cost.publicid,COPCOMM.updatetime,cost.BranchID,cost.fixedid,COPCOMM.effectivedate,COPCOMM.expirationdate   
      order by (unix_millis(COPCOMM.updatetime) - unix_millis(cost.updatetime)) asc ) rn 
      from v_pcx_copcost_ext cost
      JOIN {rawDB}.pcx_copcommission_ext  COPCOMM 
        on cost.BranchID = COPCOMM.BranchID 
        and cost.fixedid = COPCOMM.copcost
        and cost.updatetime <= COPCOMM.updatetime 
    ) where rn=1
),
 
HrzmQueryWithLD AS (
Select 
COALESCE(UPPER(CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN 'GWPC' ||'-'  || 'COP' ||'-QT:'|| cost.PublicID
     ELSE 'GWPC' ||'-'  || 'COP' ||'-'|| trans.PublicID END ), 'NOKEY' ) AS GENERAL_TRANS_KEY    
	 
,COALESCE(UPPER('GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (100)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END ), 'NOKEY')  as POL_KEY

,COALESCE(UPPER('GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound'and status.TypeCode <> 'AuditComplete' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (100)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (100)) END  || '-' || 'COPLine-'||CAST(cast(cost.COPLine AS INTEGER) AS varchar(100))), 'NOKEY')  AS POL_LINE_KEY

, UPPER(CASE 
WHEN COST.COPLINECOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'COPLine'|| '-' ||  cast(cast(COST.COPLINECOV AS INTEGER) AS VARCHAR (255))
WHEN COST.COPBUILDINGCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <>  'AuditComplete' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'COPBuilding'|| '-' ||  cast(cast(COST.COPBUILDINGCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.COPJURISDICTIONCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <>  'AuditComplete' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'COPJurisdiction'|| '-' ||  cast(cast(COST.COPJURISDICTIONCOV AS INTEGER) AS VARCHAR (255))
WHEN COST.COPLOCATIONCOV IS NOT NULL THEN  'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <>  'AuditComplete' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE CAST(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END  || '-'||'COPLocation'|| '-' ||  cast(cast(COST.COPLOCATIONCOV AS INTEGER) AS VARCHAR (255))
ELSE 'NOKEY' END )LINE_COVG_KEY
 
,CASE 
	   WHEN COST.COPLINECOV IS NOT NULL THEN 'COPLine'
	   WHEN COST.COPBUILDINGCOV IS NOT NULL THEN 'COPBuilding'
	   WHEN COST.COPJURISDICTIONCOV IS NOT NULL THEN 'COPJurisdiction'
	WHEN COST.COPLOCATIONCOV IS NOT NULL THEN 'COPLocation'	 
    ELSE ' '
	 END  AS CVRBL_TYPE_CD 
 
,'NOKEY' AS LINE_COND_KEY
  

, UPPER (CASE WHEN COALESCE (COST.COPBLDGMANUSCRIPT, COST.COPLINEMANUSCRIPT) IS NOT NULL THEN 'GWPC' || '-' || CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN cast(CAST(polper_orig.PeriodID AS INTEGER) AS VARCHAR (255)) || '-QT:' || polper_orig.publicID  ELSE cast(CAST(polper.PeriodID AS INTEGER) AS VARCHAR (255)) END ||'-' || CAST(CAST(COALESCE (COST.COPBLDGMANUSCRIPT, COST.COPLINEMANUSCRIPT)AS INTEGER)  AS varchar(255)) ELSE 'NOKEY' END  ) AS MANUSCRIPT_KEY 
, 'GWPC' as SOURCE_SYSTEM
, 'COP' as LOB_CD

,COALESCE(CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN polper_orig.UpdateTime ELSE job.CloseDate END, to_timestamp('9999-12-31 00:00:00.000000'))  AS TRANS_PROC_DTS 
,CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <>  'AuditComplete' THEN cast(polper_orig.periodStart AS date) ELSE cast(trans.writtendate as date) END  AS written_DT 
,CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN cast(polper_orig.periodStart AS date) ELSE cast(trans.postedDate as date) END AS posted_DT
,COALESCE(CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN polper_orig.UpdateTime ELSE job_orig.CloseDate END, to_timestamp('9999-12-31 00:00:00.000000')) AS ORIG_TRANS_PROC_DTS

,CAST( COALESCE (polper_orig.EditEffectiveDate, to_timestamp('1900-01-01 00:00:00.000000')) AS date) AS ORIG_END_EFF_DT
,CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN cast(polper_orig.periodStart AS date) ELSE CAST(trans.EffDate AS date) END   AS TRANS_EFF_DT
,CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN cast(polper_orig.periodEnd AS date)   ELSE CAST(trans.ExpDate AS date) END AS TRANS_EXP_DT 
,COALESCE(CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN jtype_orig.TYPECODE ELSE jtype.TYPECODE  END, ' ') AS TRANS_CD    
,COALESCE(costtype.TYPECODE, ' ' ) AS TRANS_TYPE_CD 
,COALESCE(CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN 1 ELSE trans.ID END, 0)  AS TRANS_SEQ                
,' ' AS JURS_CD
,' ' AS STATE_COST_TYPE_CD
,COALESCE(COST.ChargeGroup, ' ') AS CHRG_GROUP_NAME
,COALESCE(charge.TYPECODE, ' ')  AS CHRG_PTRN_CD 
,'ProRataByDays'  AS PRORATION_METHOD_CD
,' ' AS COV_EMP_COST_TYPE_CD
,' ' AS EL_INCR_COST_TYPE_CD
,' ' AS FED_EL_COV_EMP_COST_TYPE_CD
,' ' AS MAR_COV_EMP_COST_TYPE_CD
,' ' AS PREM_LEVEL_TYPE_CD
,COALESCE(rate_amt.typecode, ' ') AS RATE_AMT_TYPE_CD
,' ' AS STAT_CD
,' ' AS ACT_AUDIT_MTHD_CD 
,IFNULL(IF(cost.SubjectToReporting = 0, 'N', 'Y'), 'U') as SUBJECT_TO_RPT_FL
,CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN 'U'
ELSE case when trans.Written = 0 then 'N' else 'Y' end 
END as WRITTEN_FL
,CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN 'U'
ELSE case when trans.Charged = 0 then 'N' else 'Y' end 
END as CHARGED_FL
,CASE WHEN status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' THEN 'U'
ELSE CASE WHEN trans.ToBeAccrued = 0 then 'N' ELSE 'Y' end 
END as TO_BE_ACCRUED_FL
,COALESCE(COST.NUMDAYSINRATEDTERM, 0) AS RATED_TERM_DAYS_CNT
,COALESCE(cost.Basis, 0) AS PREM_BASIS_AMT
,cost.StandardBaseRate AS STD_BASE_RATE
,cost.StandardAdjRate AS STD_ADJ_RATE
,COALESCE(cost.StandardAmount, 0) AS STD_AMT
,COALESCE(cost.StandardTermAmount, 0) AS STD_TERM_AMT
,cost.OverrideBaseRate AS OVERRIDE_BASE_RATE
,cost.OverrideAdjRate AS OVERRIDE_ADJ_RATE
,COALESCE(cost.OverrideAmount,0) AS OVERRIDE_AMT
,COALESCE(cost.OverrideTermAmount, 0) AS OVERRIDE_TERM_AMT
,cost.ActualBaseRate AS ACT_BASE_RATE
,cost.ActualAdjRate AS ACT_ADJ_RATE
,COALESCE(cost.ActualAmount, 0) AS ACT_AMT
,COALESCE(cost.ActualTermAmount, 0) AS ACT_TERM_AMT 
,IFNULL(IF(status.TypeCode <> 'Bound' and status.TypeCode <>  'AuditComplete', NULL, trans.Amount), 0)  AS TRANS_AMT 
,COALESCE(audittype.typecode, ' ') as AUDIT_TYPE_CD
,COALESCE(trans.AmountBilling, 0) as Billing_AMT
,0 AS COMM_CONTRIBUTION_FCTR
,COPCOMM.NETCMISNAMT as NET_COMM_AMT
,COPCOMM.NETCMISNPCT as NET_COMM_PCT     
,COPCOMM.SRVCPLUSCMISNAMT as SRVC_PLUS_COMM_AMT
,0 AS IRPM_ELGBL_PREM_AMT
,0 AS LPDP_ELGBL_PREM_AMT
,0 AS LPDP_FCTR
,0 AS RATE_CAPPING_FCTR
,0 AS TIERING_ELGBL_PREM_AMT
,0 AS TIERING_FCTR
,0 as LAYER_LMT
,' ' as LIAB_TYPE_CD
,' ' as BLDG_MULTI_TYPE_CD
,'N' as AUDITABLE_FL
,IFNULL(IF(TRANS.WRITTEN = '1' AND TRANS.TOBEACCRUED = '0', 'Y', 'N'), 'U') AS PREM_FULLY_EARNED_FL
,COALESCE(tfscosttype.typecode, ' ') AS TFS_COST_TYPE_CD
,COALESCE(linecosttype.typecode, ' ') AS LINE_COST_TYPE_CD
,COALESCE(cost.ClassCode, ' ') AS LINE_CLASS_CD
,COALESCE(ovridesrc.typecode, ' ') as OVERRIDE_SOURCE_CD
,COALESCE(COST.MajorPerilCode, ' ') as MAJOR_PERIL_CD
,current_timestamp as ETL_ADD_DTS
,current_timestamp as ETL_LAST_UPDATE_DTS
,'GWPC-COP' AS PARTITION_VAL
,polper.periodstart as POLPER_PERIODSTART
,polper.periodend as POLPER_PERIODEND
,polper.publicid as POLPER_PUBLICID
,cost.publicid as SRC_COST_PUBLICID
,cost.updatetime  as SRC_UPDATETIME
,cost.fixedid as SRC_COST_FIXEDID
,cost.effectivedate as SRC_COST_EFFECTIVEDATE
,cost.expirationdate as SRC_COST_EXPIRATIONDATE
,polper.updatetime as updatetime_tab1
,job.updatetime as updatetime_tab3
,trans.updatetime as updatetime_tab4
,polper_orig.updatetime as updatetime_tab5
,job_orig.updatetime as updatetime_tab6
,COPCOMM.updatetime as updatetime_tab7
,trans.publicid as SRC_TRAN_PUBLICID
,trans.fixedid as SRC_TRAN_FIXEDID
,trans.effectivedate as SRC_TRAN_EFFECTIVEDATE
,trans.expirationdate as SRC_TRAN_EXPIRATIONDATE
,CASE WHEN TRIM(COALESCE(cost.effectivedate, polper.periodstart)) = TRIM(COALESCE(cost.expirationdate, polper.periodend)) OR (trans_hard_delete.publicid is not null OR cost_hard_delete.publicid is not null) THEN 'Y' ELSE 'N' END 
as QT_DELETE_IND
 
FROM  v_pcx_copcost_ext as cost
INNER JOIN v_pc_policyperiod polper_orig
on cost.BranchID=polper_orig.ID
and cost.publicid=polper_orig.pcx_copcost_ext_publicid
and cost.updatetime=polper_orig.pcx_copcost_ext_updatetime 
 
inner join v_pctl_policyperiodstatus status  ON polper_orig.status = status.ID  
 
INNER JOIN v_pc_job job_orig
ON polper_orig.jobID = job_orig.id
and polper_orig.publicid=job_orig.pc_policyperiod_publicid
and polper_orig.updatetime=job_orig.pc_policyperiod_updatetime 
 
INNER  JOIN v_pctl_job jtype_orig  ON job_orig.subtype = jtype_orig.id
 
LEFT JOIN 
( select trans.* from v_pcx_coptransaction_ext trans  
		inner join v_pc_policyperiod_tran polper2 on trans.BranchID = polper2.id
        and trans.publicid=polper2.pcx_coptransaction_ext_publicid
        and trans.updatetime=polper2.pcx_coptransaction_ext_updatetime 
		inner join v_pctl_policyperiodstatus status on polper2.status = status.id
		where status.typecode = 'Bound' or status.typecode ='AuditComplete'
 ) trans
ON Trans.copcost = cost.ID 
and cost.publicid=trans.pcx_copcost_ext_publicid
and cost.updatetime=trans.pcx_copcost_ext_updatetime
and  (status.typecode = 'Bound' or status.typecode = 'AuditComplete')
 
LEFT JOIN v_pc_policyperiod_tran polper
on trans.BranchID=polper.ID
and trans.publicid=polper.pcx_coptransaction_ext_publicid
and trans.updatetime=polper.pcx_coptransaction_ext_updatetime 
 
LEFT JOIN v_pc_job_tran job
ON polper.jobID = job.id
and polper.publicid=job.pc_policyperiod_tran_publicid
and polper.updatetime=job.pc_policyperiod_tran_updatetime
and not (polper.status = 9 and job.closedate is null)
 
LEFT JOIN v_pctl_job jtype  ON job.subtype = jtype.id 
 
LEFT JOIN v_pcx_copcommission_ext COPCOMM
ON cost.branchid = COPCOMM.branchid 
and cost.fixedid = COPCOMM.copcost 
AND POLPER_ORIG.EDITEFFECTIVEDATE >= COALESCE(COPCOMM.EFFECTIVEDATE, POLPER_ORIG.PERIODSTART) 
AND POLPER_ORIG.EDITEFFECTIVEDATE <  COALESCE(COPCOMM.EXPIRATIONDATE, POLPER_ORIG.PERIODEND)
and cost.publicid=COPCOMM.pcx_copcost_ext_publicid
and cost.updatetime=COPCOMM.pcx_copcost_ext_updatetime 

 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pc_auditinformation auditinfo
Cross Join Events_Max_Updatetime mb  On auditinfo.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) auditinfo 
on job.AuditInformationID = auditinfo.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pc_auditinformation auditinfo_orig
Cross Join Events_Max_Updatetime mb  On auditinfo_orig.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) auditinfo_orig 
on job_orig.AuditInformationID = auditinfo_orig.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_chargepattern charge
Cross Join Events_Max_Updatetime mb  On charge.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) charge 
on cost.ChargePattern = charge.ID
 
join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_copcost_ext costtype
Cross Join Events_Max_Updatetime mb  On costtype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) costtype 
on cost.Subtype = costtype.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_auditscheduletype audittype
Cross Join Events_Max_Updatetime mb  On audittype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) audittype 
on auditinfo.AuditScheduleType = audittype.ID
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_auditscheduletype audittype_orig
Cross Join Events_Max_Updatetime mb  On audittype_orig.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) audittype_orig 
on auditinfo_orig.AuditScheduleType = audittype_orig.ID
    
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_coplinecosttype_ext linecosttype
Cross Join Events_Max_Updatetime mb  On linecosttype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) linecosttype 
on linecosttype.id = cost.COPLineCostType
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_tfscosttype_ext tfscosttype
Cross Join Events_Max_Updatetime mb  On tfscosttype.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) tfscosttype 
on tfscosttype.id = cost.tfscosttype
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_rateamounttype rate_amt
Cross Join Events_Max_Updatetime mb  On rate_amt.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) rate_amt 
on rate_amt.ID = COST.RateAmountType
 
left join (select * from 
(select *,row_number() over (partition by id order by z_meta_event_timestamp  desc) as rn from {rawDB}.pctl_overridesourcetype ovridesrc
Cross Join Events_Max_Updatetime mb  On ovridesrc.z_meta_event_timestamp <= mb.mb_max_updatetime
) where rn=1) ovridesrc 
on COST.OverrideSource = ovridesrc.ID

left join (select distinct publicid from {rawDB}.pcx_copcost_ext where z_meta_operation  ='DELETE') as cost_hard_delete
on cost.publicid = cost_hard_delete.publicid

left join (select distinct publicid  from {rawDB}.pcx_coptransaction_ext where z_meta_operation  ='DELETE') as trans_hard_delete
on trans.publicid = trans_hard_delete.publicid

where status.TypeCode <> 'Bound' and status.TypeCode <> 'AuditComplete' and not (polper_orig.temporaryclonestatus <> 1 and jtype_orig.typecode = 'Submission' and status.typecode = 'Quoted')
OR trans.publicID IS NOT NULL 
)
SELECT * from HrzmQueryWithLD 
"""
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB).replace("{source_system}", source_system).replace("{harmonizedDB}",harmonizedDB) 
  print("harmz_query after rawDB replace: ", harmz_query)
  qryDF = spark.sql(harmz_query)
  
  queryDF = removeLogicalDelete_gt(qryDF)
  queryDF = removeTestAgency_clt(queryDF, rawDB, environment)
  print("queryDF", queryDF.count())
  queryDF.show(3) 
  
  print("removeDuplicates Microbatch start:") 
  dedupMicroBatchDF = removeDuplicatesMicrobatch_clt(queryDF,"GENERAL_TRANS_KEY",    "updatetime_tab1,SRC_UPDATETIME,updatetime_tab3,updatetime_tab4,updatetime_tab5,updatetime_tab6,updatetime_tab7")
  print("dedupMicroBatchDF", dedupMicroBatchDF.count())
  dedupMicroBatchDF.show(3)
  
  print("removeAdditionalColsDF start:")
  removeAdditionalColsDF = removeAdditionalCols_clt(dedupMicroBatchDF, harmonized_table)
  #removeAdditionalColsDF.createOrReplaceGlobalTempView("V")
  removeAdditionalColsDF.show(3)
  #removeAdditionalColsDF.count()
  
  print("surrogateKeyDF start:")
  surrogateKeyDF = addSurrogateKey_Non_UDM(removeAdditionalColsDF,harmonized_table) 
  print("surrogateKeyDF", surrogateKeyDF.count())
  surrogateKeyDF.show(3)
  
  print("merge start :")  
  scdType1Merge_clt(surrogateKeyDF, harmonized_table, "GENERAL_TRANS_KEY", "PARTITION_VAL", partition_val, "GENERAL_TRANS_ID")
 
  print("Job Successfully Completed")
  endtime = datetime.now()
  print(" NoteBook Execution Start Time# ", starttime)
  print(" NoteBook Execution End  Time# " ,endtime)
  print(" NoteBook Run Time# " ,endtime - starttime )
  
