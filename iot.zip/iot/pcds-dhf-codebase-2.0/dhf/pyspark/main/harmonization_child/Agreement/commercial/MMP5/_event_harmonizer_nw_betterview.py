# Databricks notebook source
# DBTITLE 1,Reusable Library Notebook - path can change relative to your child notebook location
# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/_event_harmonizer_library_agreement

# COMMAND ----------

# DBTITLE 1,Implement your Harmonization Logic here
def merge_betterview(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str): 
  print("microBatchDF...in betterview: \n")
  harmonized_table = harmonizedDB +"."+target 
  
  starttime = datetime.now()
  
  TaskGroupId = f'{param_str.split("#")[7]}'
  taskGroup = getTaskGroup(TaskGroupId ) 
  source_table = taskGroup["source_table"]
  microBatchDF.createOrReplaceGlobalTempView(f"{source_table}_micro_batch")
  
  harmz_query = """ 
select
  nw_betterview.Id1 as BV_ID1,
--TO_DATE(nw_betterview.Ordered_Dt) as ORDER_DT,
cast(to_timestamp(nw_betterview.Ordered_Dt,'M/d/y') as date) as ORDER_DT,
nw_betterview.Betterview_Id as BV_SRC_ID,
nw_betterview.Ordered_by as ORDER_BY_NAME,
nw_betterview.Package as PACKAGE_PREFIX_CD,
nw_betterview.Id2 as BV_ID2,
nw_betterview.PolPrefix as POL_PREFIX_CD,
nw_betterview.PolicyNum as POL_NO,
--TO_DATE(nw_betterview.EffectiveDate) as POL_EFF_DT,
--TO_DATE(nw_betterview.ExpirationDate) as POL_EXP_DT,
cast(to_timestamp(nw_betterview.EffectiveDate,'ddMMMyyyy') as  Date) as POL_EFF_DT,
cast(to_timestamp(nw_betterview.ExpirationDate,'ddMMMyyyy') as Date) POL_EXP_DT,
nw_betterview.LocNum as LOC_NO,
nw_betterview.BldgNum as BLDG_NO,
nw_betterview.Address as ADDRESS_NAME,
nw_betterview.State as STATE_CD, 
nw_betterview.City as CITY_NAME,
nw_betterview.Zip as ZIP_CD,
nw_betterview.Visual_Score as ROOF_VISUAL_SCORE,
nw_betterview.Material as ROOF_MATERIAL_DESC,
nw_betterview.Shape as ROOF_SHAPE_DESC,
nw_betterview.Damage as ROOF_DAMAGE_DESC,
nw_betterview.Overhang as ROOF_OVERHANG_DESC,
nw_betterview.Rust as ROOF_RUST_DESC,
nw_betterview.Ponding as ROOF_PONDING_DESC,
nw_betterview.Lat_Received as LATITUDE_RCV,
nw_betterview.Lng_Received as LONGITUDE_RCV,
nw_betterview.Lat_Final as LATITUDE_FNL,
nw_betterview.Lng_Final as LONGITUDE_FNL,
--TO_DATE(nw_betterview.capture_date) as CAPTURE_DT,
--TO_DATE(nw_betterview.Loaded_dt) as LOAD_DT,
cast(to_timestamp(nw_betterview.capture_date,'M/d/y') as date) as CAPTURE_DT,
cast(to_timestamp(nw_betterview.Loaded_dt,'M/d/y') as date) as LOAD_DT,
cast(to_timestamp(nw_betterview.Loaded_dt,'M/d/y')  as date) as ETL_ROW_EFF_DTS
from global_temp.nw_betterview_test_micro_batch micro_nw_betterview
inner join 
(select * from 
(select *,row_number() over (partition by betterview_id, loaded_dt order by loaded_dt desc) as rn 
         from
         (
select nw_betterview.*
			from {rawDB}.nw_betterview nw_betterview
            
			inner join global_temp.nw_betterview_test_micro_batch mb  
            
			on mb.bv_src_id  = nw_betterview.betterview_id
            where nw_betterview.Loaded_dt <= mb.load_dt
			)
		) where rn = 1) nw_betterview
		      
on nw_betterview.betterview_id = micro_nw_betterview.bv_src_id
"""
  
  harmz_query=harmz_query.replace("{rawDB}", rawDB).replace("{harmonizedDB}",harmonizedDB)       
  print("harmz_query after rawDB replace: "+ harmz_query)
  
  #microBatchDF.createOrReplaceGlobalTempView(s"nw_betterview_micro_batch")
  
  queryDF = spark.sql(harmz_query)
  print("queryDF:")
  queryDF.show(3)
  print(queryDF.count())
  #val harmonized_table = s"${harmonizedDB}.${target}"
  
  queryDF.createOrReplaceGlobalTempView("hmquery_nw_betterview")
  hashDF = addHashColumn_clt("hmquery_nw_betterview")
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, "BV_SRC_ID")
   
  
  auditDF = addAuditColumns_clt(dedupDF, "BV_SRC_ID")
  surrogateKeyDF = addSurrogateKey_clt(auditDF,harmonized_table) 
    
  print("merge start :") 
  defaultMerge_clt(surrogateKeyDF,harmonized_table)
                                  
  print("Job Successfully Completed")
  endtime = datetime.now()
  


# COMMAND ----------


