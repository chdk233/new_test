-- Databricks notebook source
-- MAGIC %md
-- MAGIC ds_covg_term

-- COMMAND ----------

--select distinct ETL_ROW_EFF_DTS, count(*)  from dhf_harmonize_stromboli.ds_line_cvrbl group by 1
select *  from dhf_harmonize_stromboli.ds_covg_term where ETL_ROW_EFF_DTS is null

-- COMMAND ----------

SELECT distinct  PARTITION_VAL
FROM dhf_harmonize_stromboli.ds_covg_term
GROUP BY COVG_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,PARTITION_VAL
HAVING COUNT(*) > 1

-- COMMAND ----------



-- COMMAND ----------

select 'ds_covg_term' as table_name , count(*) as id_dups from ( select COVG_TERM_ID , count(*) as dup_count from dhf_harmonize_stromboli.ds_covg_term group by COVG_TERM_ID having count(*) > 1)

-- COMMAND ----------

select *  from dhf_harmonize_stromboli.ds_covg_term where ETL_CURR_ROW_FL = 'N' and ETL_ROW_EXP_DTS like '%9999-12-31%'

-- COMMAND ----------

select distinct PARTITION_VAL
from dhf_harmonize_stromboli.ds_covg_term 
where ETL_CURR_ROW_FL='Y' 
group by COVG_TERM_KEY, END_EFF_DT, ETL_ROW_EFF_DTS,ETL_CURR_ROW_FL,PARTITION_VAL
having count(*) > 1
