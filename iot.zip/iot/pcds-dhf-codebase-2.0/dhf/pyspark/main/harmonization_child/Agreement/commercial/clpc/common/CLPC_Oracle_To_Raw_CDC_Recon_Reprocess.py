# Databricks notebook source
import csv
from pyspark.sql.functions import to_date,lit,upper,current_timestamp,date_format,lit,date_add,current_date
from pyspark.sql.types import datetime,StringType,StructField,TimestampType
import threading
import pyspark.sql.functions as f



# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text( "tablePattern", "*", "tablePattern")
dbutils.widgets.text( "excludePattern", "*", "excludePattern")
dbutils.widgets.text( "rawDB", "*", "rawDB")
tablePattern=dbutils.widgets.get("tablePattern")
excludePattern=dbutils.widgets.get("excludePattern")
rawDB=dbutils.widgets.get("rawDB")


ORACLE_PROPERTIES = {
    'url' : 'jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=ip-10-168-102-83.aws.e1.nwie.net)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=ip-10-168-105-231.aws.e1.nwie.net)(PORT=1521)))(CONNECT_DATA=(UR=A)(SERVICE_NAME=clpc95g.nsc.net)))',
    'driver':  'oracle.jdbc.driver.OracleDriver',
    'CONNECTION_PROPERTY_THIN_NET_ENCRYPTION_LEVEL':'REQUIRED',
    'fetchsize':1000,
	'user':'PCDSETL',
	'password':'Ep9s59fG2MK3h46zZ4_z'
    }

# COMMAND ----------

rawDB="pcds_agreement_raw_clpc"
tablePattern="^PCX_IMGCOST_EXT$|^PCX_IMGTRANSACTION_EXT$|^PCX_COPCOST_EXT$|^PCX_COPTRANSACTION_EXT$|^PCX_COPCOMMISSION_EXT$|^PCX_IMGCOMMISION_EXT$|^PCX_FLOODINFO_EXT$"
excludePattern="PC_[A-Z].*"


# COMMAND ----------

# DBTITLE 1,Override Parameters
overrideFlag="N"
startTime="2022-08-30T00:00:00.000+0000"
endTime="2022-09-18T00:00:00.000+0000"
startTimeOracle="2022-08-30 00:00:00"
endTimeOracle="2022-09-18 00:00:00"

# COMMAND ----------

# DBTITLE 1,Parameters for Daily load
dateParams=spark.sql('select date_add(current_date(),-2) as startDate ,current_date() as endDate ').collect()
# -2 applied here as current_date is in UTC time zone and job is running in UTC-5 @8pm. If it schedule to run after after 12am , change it to -1
startDate=dateParams[0][0]
endDate=dateParams[0][1]
startTimeDefault='{date}T00:00:00.000+0000"'.format(date=startDate)
endTimeDefault='{date}T00:00:00.000+0000'.format(date=endDate)
startTimeOracleDefault='{date} 00:00:00'.format(date=startDate)
endTimeOracleDefault='{date} 00:00:00'.format(date=endDate)

if overrideFlag=="N":
  startTime=startTimeDefault
  endTime=endTimeDefault
  startTimeOracle=startTimeOracleDefault
  endTimeOracle=endTimeOracleDefault

print("Recon Start Time - "+startTimeOracle+" , End Time - "+endTimeOracle)

# COMMAND ----------

def srcTgtReconbyTablePattern(tablePattern:str,excludePattern:str,rawDB:str,startTime:str,endTime:str,startTimeOracle:str,endTimeOracle:str):
  tabListQuery="SELECT TABLE_NAME FROM ALL_TABLES WHERE OWNER='CLPC' and  regexp_like(TABLE_NAME, '{tablePattern}') and not regexp_like(TABLE_NAME, '{excludePattern}') and table_name in (select table_name from all_tab_columns where column_name='UPDATETIME')  order by 1".format(tablePattern=tablePattern,excludePattern=excludePattern)
  print("Table List Query : "+ tabListQuery)
  tabListDF = spark.read.format('jdbc') \
          .options(**ORACLE_PROPERTIES) \
          .option('query', tabListQuery) \
          .load()
  for t in tabListDF.collect():
    try:
      tableName=t[0]
      print("Recon Check for Table - "+ tableName)
      srcQuery="SELECT ID,UPDATETIME FROM CLPC.{tableName} t where updatetime >= to_timestamp('{start_time}','YYYY-MM-DD HH24:MI:SS') \
          and updatetime <= to_timestamp('{end_time}','YYYY-MM-DD HH24:MI:SS')".format(tableName=tableName,start_time=startTimeOracle,end_time=endTimeOracle)

# Data Reading
      sourceTable="{}.{}".format("CLPC",tableName)
      srcDataDF = spark.read.format('jdbc') \
          .options(**ORACLE_PROPERTIES) \
          .option('query', srcQuery) \
          .load()

      # Tgt Recon 
      tgtDataDF=spark.sql("select id,updatetime from {rawDB}.{tableName} where updatetime >= '{start_time}' and updatetime<= '{end_time}' ".format(rawDB=rawDB,tableName=tableName,start_time=startTime,end_time=endTime))
      reprocessDataDF=srcDataDF.subtract(tgtDataDF)
      reprocessRecCount=reprocessDataDF.count()
      reprocessDataDF=reprocessDataDF.withColumn("comparision_type",lit("SRC-TGT"))\
      .withColumn("table_name",lit(tableName))\
      .withColumn("operation_type",lit("CDC"))\
      .withColumn("rec_count",lit(reprocessRecCount))\
      .withColumn("load_date",current_timestamp())
#       display(reprocessDataDF)
      print("Missing Record Count : {reprocessRecCount}".format(reprocessRecCount=reprocessRecCount))
      
      reprocess_table="etl_clpc_raw_reprocess"
      reprocess_table_with_rawDB="{rawDB}.{reprocess_table}".format(rawDB=rawDB, reprocess_table=reprocess_table)
      reprocess_temp_table_name = "temp_{tbl}".format(tbl=reprocess_table)
      reprocessDataDF.createOrReplaceTempView(reprocess_temp_table_name)
      reprocesscols = ','.join(spark.table(reprocess_table_with_rawDB).columns)
      spark.sql("delete from {rawDB}.{reprocess_table} where table_name='{tableName}'".format(rawDB=rawDB,reprocess_table=reprocess_table,tableName=tableName))
      spark.sql("insert into {rawDB}.{reprocess_table} ({reprocesscols}) select {reprocesscols} from {reprocess_temp_table_name}".\
                format(rawDB=rawDB,reprocess_table=reprocess_table,reprocess_temp_table_name=reprocess_temp_table_name,reprocesscols=reprocesscols))
      
      reprocess_ctl_table="etl_clpc_raw_reprocess_load_cntrl"
#       re extacting missing data
      if (reprocessDataDF.count() != 0) :
        print("--Reprocessing missing data in table - {tableName}".format(tableName=tableName))
        ctlTableDF=spark.sql("""select reprocess_start_time,reprocess_end_time from {rawDB}.{reprocess_ctl_table} 
                     where table_name='{tableName}'""".format(rawDB=rawDB,reprocess_ctl_table=reprocess_ctl_table,tableName=tableName))
#         display(ctlTableDF)
        
        if(ctlTableDF.count() == 0 ):
          ctlTableDF=spark.sql("select '{startTime}' as reprocess_start_time, '{endTime}' as reprocess_end_time".format(startTime=startTime,endTime=endTime))
        
        start_time=ctlTableDF.select(f.collect_list('reprocess_start_time')).first()[0][0]
        end_time=ctlTableDF.select(f.collect_list('reprocess_end_time')).first()[0][0]
        
        
        print("reprocess start_ts-{} , end_ts-{}".format(start_time,end_time))
        start_time=startTimeOracle
        end_time=endTimeOracle
        srcReprocessQuery="""SELECT * FROM CLPC.{tableName} t where updatetime >= to_timestamp('{start_time}','YYYY-MM-DD HH24:MI:SS') 
          and updatetime <= to_timestamp('{end_time}','YYYY-MM-DD HH24:MI:SS')""".format(tableName=tableName,start_time=start_time,end_time=end_time)
#         print(srcReprocessQuery)
        srcReprocessDF=spark.read.format('jdbc') \
          .options(**ORACLE_PROPERTIES) \
          .option('query', srcReprocessQuery) \
          .load()
#         display(srcReprocessDF)

#       Special Logic for PC_ADDRESS table
        if tableName == "PC_ADDRESS":
          srcReprocessDF = srcReprocessDF.drop("SPATIALPOINT").withColumn("SPATIALPOINT",lit(""))

        finalDF = srcReprocessDF.join(reprocessDataDF, srcReprocessDF.ID == reprocessDataDF.ID, 'left_semi')
#         .select(srcReprocessDF.*).collect()
#         display(finalDF)
        print(finalDF.count())
        finalDF = finalDF.withColumn("TABLE_NAME",lit(tableName)).withColumn("meta_oracle_cdc_operation",lit("INSERT"))\
                  .withColumn("meta_event_timestamp",current_timestamp()).withColumn("partition_yyyymmdd",date_format(current_timestamp(),'yyyyMMdd'))\
                  .withColumn("meta_oracle_cdc_user",lit(""))\
                  .withColumn("meta_curr_timestamp",lit(""))\
                  .withColumn("meta_queue",lit("0"))\
                  .withColumn("meta_etl_load_timestamp",current_timestamp())\
                  .withColumn("meta_oracle_cdc_timestamp",lit(""))\
                  .withColumn("meta_oracle_cdc_scn",lit(""))\
                  .withColumn("meta_row_id",lit(""))\
                  .withColumn("meta_record_type",lit(""))\
                  .withColumn("meta_di_process",lit(""))\
                  .withColumn("meta_oracle_cdc_sequence_internal",lit(""))\
                  .withColumn("meta_scn",lit(""))\
                  .withColumn("meta_operation_type",lit("REPROCESS"))\
                  .withColumn("meta_oracle_cdc_sequence_oracle",lit(""))\
                  .withColumn("meta_oracle_cdc_rowid",lit(""))\
                  .withColumn("meta_oracle_cdc_precisiontimestamp",lit(""))\
                  .withColumn("meta_oracle_cdc_redovalue",lit(""))\
                  .withColumn("meta_oracle_cdc_undovalue",lit(""))\
                  .withColumn("meta_table_name",lit(""))

#       Special Logic to resolve meta queue data type issue
        if tableName == "PCX_IMGACCNTRECBLDGCOV_EXT" or tableName == "PCX_IMGACCOUNTSRECBLDG_EXT" or tableName == "PCX_IMGACCOUNTSRECCOV_EXT" or tableName=="PCX_IMGVALUABLEPAPER_EXT" or tableName=="PCX_IMGVPSCHDCOVITEMCOV_EXT" :
          finalDF = finalDF.drop("meta_queue").withColumn("meta_queue",lit("0").cast("integer"))
        if tableName == "PC_ACCOUNT" or tableName == "PC_POLICYPERIOD" :
          finalDF = finalDF.withColumn("serviceplusind_ext",lit(""))
      

        
#       Writing Data
        temp_table_name = "temp_{tbl}".format(tbl=tableName)
        targetTable="{rawDB}.{tbl}".format(rawDB=rawDB,tbl=tableName)
        finalDF.createOrReplaceTempView(temp_table_name)
#         finalDF.write.format("delta").mode("overwrite").saveAsTable(temp_table_name)
        cols = ','.join(spark.table(targetTable).columns)
#         print("insert into {targetTable} ({cols}) select {cols} from {temp_table_name}".format(targetTable=targetTable,temp_table_name=temp_table_name,cols=cols))
        print("TESTING")
        spark.sql("insert into {targetTable} ({cols}) select {cols} from {temp_table_name}".format(targetTable=targetTable,temp_table_name=temp_table_name,cols=cols))
        print("Missing records inserted successfully")
      else:
        print("--Recon matched for table {tableName}".format(tableName=tableName))
          
# Source Recon 
#       srcCountQuery="SELECT 'CLPC' as source,'{tableName}' as table_name, 'BULK' as operation_type, count(1) as rec_count,current_timestamp as load_date from CLPC.{tableName}".format(tableName=tableName)
#       srcCountDF=spark.read.format('jdbc') \
#           .options(**ORACLE_PROPERTIES) \
#           .option('query', srcCountQuery) \
#           .load()
# #       display(srcCountDF)
# #       display(dataDF)
#       print("data read completed")
# #       Writing Data
#       temp_table_name = "temp_{tbl}".format(tbl=tableName)
#       targetTable="{rawDB}.{tbl}".format(rawDB=rawDB,tbl=tableName)
#       dataDF.createOrReplaceTempView(temp_table_name)
#       spark.sql("insert into {0} select * from {1}".format(targetTable,temp_table_name))

#       # Tgt Recon 
#       tgtCountDF=spark.sql("select 'RAW' as source, '{tableName}' as table_name, 'BULK' as operation_type,count(1) as rec_count,current_timestamp as load_date  from {targetTable}".format(tableName=tableName,targetTable=targetTable))
#       reconDF=srcCountDF.union(tgtCountDF)
# #       display(tgtCountDF)
      
#       recon_table="etl_clpc_raw_recon"
#       recon_temp_table_name = "temp_{tbl}".format(tbl=recon_table)
#       reconDF.createOrReplaceTempView(recon_temp_table_name)
#       spark.sql("insert into {0}.{1} select * from {2}".format(rawDB, recon_table,recon_temp_table_name))

    except Exception as e:
      print("Error {}".format(t[0]))
      print(e)

                  


# COMMAND ----------

def srcTgtReconbyTablePatternWithoutUpdatetime(tablePattern:str,excludePattern:str,rawDB:str,startTime:str,endTime:str,startTimeOracle:str,endTimeOracle:str):
  tabListQuery="SELECT TABLE_NAME FROM ALL_TABLES WHERE OWNER='CLPC' and  regexp_like(TABLE_NAME, '{tablePattern}') and not regexp_like(TABLE_NAME, '{excludePattern}') and table_name not in (select table_name from all_tab_columns where column_name='UPDATETIME')  order by 1".format(tablePattern=tablePattern,excludePattern=excludePattern)
  print("Table List Query : "+ tabListQuery)
  tabListDF = spark.read.format('jdbc') \
          .options(**ORACLE_PROPERTIES) \
          .option('query', tabListQuery) \
          .load()
  for t in tabListDF.collect():
    try:
      tableName=t[0]
      print(tableName)
      srcQuery="SELECT ID FROM CLPC.{tableName} t ".format(tableName=tableName)

# Data Reading
      sourceTable="{}.{}".format("CLPC",tableName)
      srcDataDF = spark.read.format('jdbc') \
          .options(**ORACLE_PROPERTIES) \
          .option('query', srcQuery) \
          .load()

      # Tgt Recon 
      tgtDataDF=spark.sql("select id from {rawDB}.{tableName}".format(rawDB=rawDB,tableName=tableName))
      reprocessDataDF=srcDataDF.subtract(tgtDataDF)
      reprocessRecCount=reprocessDataDF.count()
      reprocessDataDF=reprocessDataDF.withColumn("comparision_type",lit("SRC-TGT"))\
      .withColumn("table_name",lit(tableName))\
      .withColumn("operation_type",lit("CDC"))\
      .withColumn("rec_count",lit(reprocessRecCount))\
      .withColumn("load_date",current_timestamp())\
      .withColumn("updatetime",current_timestamp())

#       display(reprocessDataDF)
      print("Missing Record Count : {reprocessRecCount}".format(reprocessRecCount=reprocessRecCount))
      
      reprocess_table="etl_clpc_raw_reprocess"
      reprocess_table_with_rawDB="{rawDB}.{reprocess_table}".format(rawDB=rawDB, reprocess_table=reprocess_table)
      reprocess_temp_table_name = "temp_{tbl}".format(tbl=reprocess_table)
      reprocessDataDF.createOrReplaceTempView(reprocess_temp_table_name)
      reprocesscols = ','.join(spark.table(reprocess_table_with_rawDB).columns)
      spark.sql("delete from {rawDB}.{reprocess_table} where table_name='{tableName}'".format(rawDB=rawDB,reprocess_table=reprocess_table,tableName=tableName))
      spark.sql("insert into {rawDB}.{reprocess_table} ({reprocesscols}) select {reprocesscols} from {reprocess_temp_table_name}".\
                format(rawDB=rawDB,reprocess_table=reprocess_table,reprocess_temp_table_name=reprocess_temp_table_name,reprocesscols=reprocesscols))
      
      reprocess_ctl_table="etl_clpc_raw_reprocess_load_cntrl"
#       re extacting missing data
      if (reprocessDataDF.count() != 0) :
        print("--Reprocessing missing data in table - {tableName}".format(tableName=tableName))
        ctlTableDF=spark.sql("""select reprocess_start_time,reprocess_end_time from {rawDB}.{reprocess_ctl_table} 
                     where table_name='{tableName}'""".format(rawDB=rawDB,reprocess_ctl_table=reprocess_ctl_table,tableName=tableName))
#         display(ctlTableDF)
        
        if(ctlTableDF.count() == 0 ):
          ctlTableDF=spark.sql("select '{startTime}' as reprocess_start_time, '{endTime}' as reprocess_end_time".format(startTime=startTime,endTime=endTime))
        
        start_time=ctlTableDF.select(f.collect_list('reprocess_start_time')).first()[0][0]
        end_time=ctlTableDF.select(f.collect_list('reprocess_end_time')).first()[0][0]
        
        
        print("reprocess start_ts-{} , end_ts-{}".format(start_time,end_time))
        start_time=startTimeOracle
        end_time=endTimeOracle
        srcReprocessQuery="""SELECT * FROM CLPC.{tableName} t""".format(tableName=tableName)
        print(srcReprocessQuery)
        srcReprocessDF=spark.read.format('jdbc') \
          .options(**ORACLE_PROPERTIES) \
          .option('query', srcReprocessQuery) \
          .load()
#         display(srcReprocessDF)
        

        finalDF = srcReprocessDF.join(reprocessDataDF, srcReprocessDF.ID == reprocessDataDF.ID, 'left_semi')
#         .select(srcReprocessDF.*).collect()
#         display(finalDF)
        print(finalDF.count())
        finalDF = finalDF.withColumn("TABLE_NAME",lit(tableName)).withColumn("meta_oracle_cdc_operation",lit("INSERT"))\
                  .withColumn("meta_event_timestamp",current_timestamp()).withColumn("partition_yyyymmdd",date_format(current_timestamp(),'yyyyMMdd'))\
                  .withColumn("meta_oracle_cdc_user",lit(""))\
                  .withColumn("meta_curr_timestamp",lit(""))\
                  .withColumn("meta_queue",lit(""))\
                  .withColumn("meta_etl_load_timestamp",current_timestamp())\
                  .withColumn("meta_oracle_cdc_timestamp",lit(""))\
                  .withColumn("meta_oracle_cdc_scn",lit(""))\
                  .withColumn("meta_row_id",lit(""))\
                  .withColumn("meta_record_type",lit(""))\
                  .withColumn("meta_di_process",lit(""))\
                  .withColumn("meta_oracle_cdc_sequence_internal",lit(""))\
                  .withColumn("meta_scn",lit(""))\
                  .withColumn("meta_operation_type",lit("REPROCESS"))\
                  .withColumn("meta_oracle_cdc_sequence_oracle",lit(""))\
                  .withColumn("meta_oracle_cdc_rowid",lit(""))\
                  .withColumn("meta_oracle_cdc_precisiontimestamp",lit(""))\
                  .withColumn("meta_oracle_cdc_redovalue",lit(""))\
                  .withColumn("meta_oracle_cdc_undovalue",lit(""))\
                  .withColumn("meta_table_name",lit(""))
        
#         display(finalDF)
        print("data read completed")
        
#       Writing Data
        temp_table_name = "temp_{tbl}".format(tbl=tableName)
        targetTable="{rawDB}.{tbl}".format(rawDB=rawDB,tbl=tableName)
        finalDF.createOrReplaceTempView(temp_table_name)
        cols = ','.join(spark.table(targetTable).columns)
#         print("insert into {targetTable} ({cols}) select {cols} from {temp_table_name}".format(targetTable=targetTable,temp_table_name=temp_table_name,cols=cols))
        spark.sql("insert into {targetTable} ({cols}) select {cols} from {temp_table_name}".format(targetTable=targetTable,temp_table_name=temp_table_name,cols=cols))
        print("Missing records inserted successfully")
      else:
        print("--Recon matched for table {tableName}".format(tableName=tableName))
          
# Source Recon 
#       srcCountQuery="SELECT 'CLPC' as source,'{tableName}' as table_name, 'BULK' as operation_type, count(1) as rec_count,current_timestamp as load_date from CLPC.{tableName}".format(tableName=tableName)
#       srcCountDF=spark.read.format('jdbc') \
#           .options(**ORACLE_PROPERTIES) \
#           .option('query', srcCountQuery) \
#           .load()
# #       display(srcCountDF)
# #       display(dataDF)
#       print("data read completed")
# #       Writing Data
#       temp_table_name = "temp_{tbl}".format(tbl=tableName)
#       targetTable="{rawDB}.{tbl}".format(rawDB=rawDB,tbl=tableName)
#       dataDF.createOrReplaceTempView(temp_table_name)
#       spark.sql("insert into {0} select * from {1}".format(targetTable,temp_table_name))

#       # Tgt Recon 
#       tgtCountDF=spark.sql("select 'RAW' as source, '{tableName}' as table_name, 'BULK' as operation_type,count(1) as rec_count,current_timestamp as load_date  from {targetTable}".format(tableName=tableName,targetTable=targetTable))
#       reconDF=srcCountDF.union(tgtCountDF)
# #       display(tgtCountDF)
      
#       recon_table="etl_clpc_raw_recon"
#       recon_temp_table_name = "temp_{tbl}".format(tbl=recon_table)
#       reconDF.createOrReplaceTempView(recon_temp_table_name)
#       spark.sql("insert into {0}.{1} select * from {2}".format(rawDB, recon_table,recon_temp_table_name))

    except Exception as e:
      print("Error {}".format(t[0]))
      print(e)

                  


# COMMAND ----------

srcTgtReconbyTablePattern(tablePattern,excludePattern,rawDB,startTime,endTime,startTimeOracle,endTimeOracle)

# COMMAND ----------

srcTgtReconbyTablePatternWithoutUpdatetime(tablePattern,excludePattern,rawDB,startTime,endTime,startTimeOracle,endTimeOracle)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- show create table pcds_agreement_clpc_raw_oxygen_bulk_jdbc.etl_clpc_raw_reprocess;
# MAGIC -- show create table pcds_agreement_harmonized.ds_covg_term;
# MAGIC 
# MAGIC -- CREATE OR REPLACE TABLE `pcds_agreement_clpc_raw_oxygen_bulk_jdbc`.`etl_clpc_raw_reprocess` (
# MAGIC --   `id` DOUBLE,
# MAGIC --   `updatetime` TIMESTAMP,
# MAGIC --   `comparision_type` STRING,
# MAGIC --   `table_name` STRING,
# MAGIC --   `operation_type` STRING,
# MAGIC --   `load_date` TIMESTAMP)
# MAGIC -- USING delta
# MAGIC -- PARTITIONED BY (table_name)
# MAGIC 
# MAGIC -- ;
# MAGIC 
# MAGIC 
# MAGIC -- CREATE OR REPLACE TABLE `pcds_agreement_raw_clpc`.`etl_clpc_raw_reprocess_load_cntrl` (
# MAGIC --   `table_name` STRING,
# MAGIC --   `comparision_type` STRING,
# MAGIC --   `operation_type` STRING,
# MAGIC --    reprocess_start_time TIMESTAMP,
# MAGIC --    reprocess_end_time TIMESTAMP,
# MAGIC --    last_reprocessed_record_count DOUBLE,
# MAGIC --   `load_date` TIMESTAMP
# MAGIC --   )
# MAGIC -- USING delta
# MAGIC -- PARTITIONED BY (table_name)
# MAGIC 
# MAGIC ;

# COMMAND ----------

# %sql
# insert into `pcds_agreement_raw_clpc`.`etl_clpc_raw_reprocess_load_cntrl` select 'PC_INDUSTRYCODE','SRC-TGT','CDC','1900-01-01T12:00:00.0000+0000','1900-01-01T12:00:00.0000+0000',null,null;

# select * From pcds_agreement_raw_clpc.etl_clpc_raw_reprocess_load_cntrl;
