# Databricks notebook source
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../../harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

# MAGIC %run ../../_event_library_agreement

# COMMAND ----------

# MAGIC %scala
# MAGIC // configuration to reduce th DBIO file fragments 
# MAGIC spark.conf.set("spark.databricks.io.cache.enabled", "false")

# COMMAND ----------

def agreement_clpc_si_condition(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str ):
  print("Entered into Entered into si_condition_template")
  starttime = datetime.now()
  microBatchDF.show(3,False)
  parent = ""  
  TaskGroupId = f'{param_str.split("#")[7]}'
  taskGroup = getTaskGroup(TaskGroupId) 
  parent = taskGroup["source_table"] 
  source_table = taskGroup["source_table"] 

  print("EH started for ** parent table ******* :-" ,parent)             
  df_parm  =spark.sql(f""" select cvrbl_type,si_type,child1,source_system,lob_cd from {harmonizedDB}.DS_COVERAGE_XREF where tablename = '{parent}' """)
  df_parm.show(3,False)
  cvrbl_type = df_parm.collect()[0][0]
  si_type = df_parm.collect()[0][1]
  child1 = df_parm.collect()[0][2]
  source_system = df_parm.collect()[0][3]
  lob_cd = df_parm.collect()[0][4]  
  scdkey='SI_KEY,END_EFF_DT,ETL_ROW_EFF_DTS' 
  key = "SI_KEY,END_EFF_DT"     
  partition_val = f"{source_system}-{lob_cd}-{cvrbl_type}{si_type}"
  print("partition_val  : "+ partition_val + "\n  ")
  newmicroBatchDF1 = microBatchDF.filter(f"partition_val='{partition_val}'")
  harmonized_table = harmonizedDB +"."+target
  micro_batch = source_table + "_micro_batch"
  try:
      if newmicroBatchDF1.count() > 0 :
          print("In try -", datetime.now(), "\n")
          print("Micro_Batch Name ******* :-" ,micro_batch)
          
          print("********************Before build term query ******* :-")
          harmz_query = build_si_condition (rawDB, parent, cvrbl_type, child1, source_system, lob_cd, si_type) 
          print("********************After build term query ******* :-") 
          print("********************Before generate Query******* :-") 
          harmz_query = generate_DHF_query(harmz_query, scdkey, harmonized_table, micro_batch) 
          print("********************After generate Query******* :-") 

          newmicroBatchDF1.createOrReplaceGlobalTempView(f"""{parent}_micro_batch_{cvrbl_type}{si_type}""") 
          
          print("********************Executing the harmz_query******* :-")
          print("harmz_query   for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type , harmz_query)
          print(harmz_query)
          df = spark.sql(harmz_query)
          #caching the result of the harmonization query
          print("*********************harmz_query execution is complete******* :-")
          df.persist()
          

          print("Entering deduphashDF for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type)
          deduphashDF = removeDuplicatesMicrobatchByHash_clt(df,  key)
          deduphashDF.persist()
          print("deduphashDF  count for " ,cvrbl_type ,"--" ,deduphashDF.count(),"\n")

          print("count before scd Merge ", df.count(), datetime.now(), "\n")
          surrogateID = f'{harmonized_table.split(".")[1][3:]}_ID'     
          scdDF = scdMerge_clt_perf(deduphashDF, harmonized_table, scdkey, "PARTITION_VAL", partition_val, surrogateID )
          scdDF.persist()
          print("scdDFCount:",scdDF.count(),datetime.now(),"\n")
          scdDF.show(1)

          

          print("Entering auditDF for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type)
          auditDF = addAuditColumnsRemoveDupsCdcSyncMultistream_clt_pt_perf(scdDF, harmonized_table, key,"PARTITION_VAL",  partition_val)
          auditDF.persist() 
          print("auditDF  count for " ,cvrbl_type ,"--" , auditDF.count(), " Completed at ", datetime.now(), "\n")

          print("Entering surrogateKeyDF for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type, " \n")
          surrogateKeyDF = addSurrogateKey_Non_UDM(auditDF, harmonized_table)
          print("surrogateKeyDF  count for " ,cvrbl_type ,"--" , surrogateKeyDF.count(), " Completed at ", datetime.now(), "\n")

          #caching the result of the surrogate key function output
          surrogateKeyDF.persist()

          print("Entering defaultMerge for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type, " \n")
          defaultMergeCdcMultistream_clt(surrogateKeyDF, harmonized_table, "PARTITION_VAL", partition_val)
          print("defaultMergeCdcMultistream_clt  count for " ,cvrbl_type ,"--" ,  " Completed at ", datetime.now(), "\n")

          print("Entering b4 orphanRecords_Clt  - df count for " ,cvrbl_type ,"--" , df.count(),"\n")
          orphanRecords_Clt_pt (df,harmonized_table, "PARTITION_VAL",  partition_val,"SI_KEY") 
          print("orphanRecords_Clt completed for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  cvrbl_type,  datetime.now(), "\n")
          
      else:
          print("Micro Batch Size is 0, Skipping rest of the functions for Target - " , target,"  and coverable_type -",cvrbl_type,"\n")
  except Exception as err:
          print("In Exception", err) 

  finally:
          print("Job Successfully Completed")
          endtime = datetime.now()
          print(" NoteBook Execution Start Time# ", starttime)
          print(" NoteBook Execution End  Time# " ,endtime)
          print(" NoteBook Run Time# " ,endtime - starttime ) 

# COMMAND ----------

