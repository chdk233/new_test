# Databricks notebook source
# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../../harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

# MAGIC %run ../../_event_library_agreement

# COMMAND ----------

# MAGIC %scala
# MAGIC // configuration to reduce th DBIO file fragments 
# MAGIC spark.conf.set("spark.databricks.io.cache.enabled", "false")

# COMMAND ----------

def agreement_clpc_covg_term(microBatchDF, batchId, rawDB, harmonizedDB, target ,param_str):
    print("microBatchDF...in agreement_clpc_covg_term: \n")
    starttime = datetime.now()
    try:
      #microBatchDF.show(3,False) 
      parent = ""
      TaskGroupId = f'{param_str.split("#")[7]}'
      taskGroup = getTaskGroup(TaskGroupId ) 
      parent = taskGroup["source_table"]
      source_table = taskGroup["source_table"]
      print("EH started for ** parent table ******* :-" ,parent)
            
      df_parm  =spark.sql(f""" select distinct cvrbl_type,source_system,lob_cd,src_cvrbl_type from {harmonizedDB}.DS_COVERAGE_XREF where tablename = '{parent}' """) 
      coverable_type= str(df_parm.select(col("cvrbl_type")).collect()[0][0]).strip()
      source_system = str(df_parm.select(col("source_system")).collect()[0][0]).strip()
      lob_cd = str(df_parm.select(col("lob_cd")).collect()[0][0]).strip() 
      src_cvrbl_type = str(df_parm.select(col("src_cvrbl_type")).collect()[0][0]).strip()
            
      harmonized_table = harmonizedDB +"."+target
      keycol = target[3:7]+"_TERM_KEY"
      partition_val =f"{source_system}-{lob_cd}-{coverable_type}"
      key = target[3:7]+"_TERM_KEY,END_EFF_DT"
      scdkey = target[3:7]+"_TERM_KEY,ETL_ROW_EFF_DTS,END_EFF_DT"  
      table =target+"_"+coverable_type
      newmicroBatchDF=microBatchDF.filter(f"PARTITION_VAL='{partition_val}'")
      micro_batch = source_table + "_micro_batch"
      if(newmicroBatchDF.count() > 0):
            print("In try -", datetime.now(), "\n")
            print("Micro_Batch Name ******* :-" ,micro_batch)
            newmicroBatchDF.createOrReplaceGlobalTempView(f"{source_table}_micro_batch")
            
            print("********************Before build term query ******* :-") 
            harmz_query = build_term(rawDB , parent,coverable_type,source_system , lob_cd ,src_cvrbl_type)   
            print("********************After build term query ******* :-")                    
            print("********************Before generate Query ******* :-") 
            harmz_query = generate_DHF_query(harmz_query, scdkey, harmonized_table, micro_batch)
            print("********************After generate Query******* :-") 
            print("********************Executing the harmz_query******* :-")
            df = spark.sql(harmz_query)
            #caching the result of the harmonization query
            print("*********************harmz_query execution is complete******* :-")
            df.persist()

            print("Entering deduphashDF for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  coverable_type)
            deduphashDF = removeDuplicatesMicrobatchByHash_clt(df,  key)
            deduphashDF.persist()
            print("deduphashDF  count for " ,coverable_type ,"--" ,deduphashDF.count(),"\n")
            
            print("count before scd Merge ", df.count(), datetime.now(), "\n")
            surrogateID = f'{harmonized_table.split(".")[1][3:]}_ID'     
            scdDF = scdMerge_clt_perf(deduphashDF, harmonized_table, scdkey, "PARTITION_VAL", partition_val, surrogateID )
            scdDF.persist()
            print("scdDFCount:",scdDF.count(),datetime.now(),"\n")
            scdDF.show(1)

            

            print("Entering auditDF for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  coverable_type)
            auditDF = addAuditColumnsRemoveDupsCdcSyncMultistream_clt_pt_perf(scdDF, harmonized_table, key,"PARTITION_VAL",  partition_val)
            auditDF.persist() 
            print("auditDF  count for " ,coverable_type ,"--" , auditDF.count(), " Completed at ", datetime.now(), "\n")

            print("Entering surrogateKeyDF for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  coverable_type, " \n")
            surrogateKeyDF = addSurrogateKey_Non_UDM(auditDF, harmonized_table)
            print("surrogateKeyDF  count for " ,coverable_type ,"--" , surrogateKeyDF.count(), " Completed at ", datetime.now(), "\n")

            #caching the result of the surrogate key function output
            surrogateKeyDF.persist()

            print("Entering defaultMerge for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  coverable_type, " \n")
            defaultMergeCdcMultistream_clt(surrogateKeyDF, harmonized_table, "PARTITION_VAL", partition_val)
            print("defaultMergeCdcMultistream_clt  count for " ,coverable_type ,"--" ,  " Completed at ", datetime.now(), "\n")
            
            print("Entering orphanRecords_Clt_pt  for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  coverable_type, " \n")
            orphanRecords_Clt_pt (df,harmonized_table, "PARTITION_VAL",  partition_val, keycol) 
            print("orphanRecords_Clt completed for Target- ",target ," for LOB - ",lob_cd," coverable_type - ",  coverable_type,  datetime.now(), "\n")
        
      else :
            print("Micro Batch Size is 0, Skipping rest of the functions for Target - " , target,"  and partition-",partition_val,"\n")
    except Exception as err:
            print("In Exception", err) 

    finally:
            print("Job Successfully Completed")
            endtime = datetime.now()
            print(" NoteBook Execution Start Time# ", starttime)
            print(" NoteBook Execution End  Time# " ,endtime)
            print(" NoteBook Run Time# " ,endtime - starttime ) 