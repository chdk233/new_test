# Databricks notebook source
# MAGIC %run ../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_cc_claim_ph2(microBatchDF, batchId, rawDB, harmonizedDB, target):
  print("\n entering merge_cc_claim_ph2 \n")
  harmonized_table = harmonizedDB +"."+target
  key = "claim_id"

# Add Hash
  microBatchDF.createOrReplaceGlobalTempView("V")
  hashDF = addHashColumn_clt("V")
# Dedup
  dedupDF = removeDuplicates_clt(hashDF, harmonized_table, key)
# Add Audit Columns
  auditDF = addAuditColumns_clt(dedupDF, key)
# Add SurrogateKey
  surrogateKeyDF = addSurrogateKey_clt(auditDF, harmonized_table)
# Merge Type2
  defaultMerge_clt(surrogateKeyDF, harmonized_table)

