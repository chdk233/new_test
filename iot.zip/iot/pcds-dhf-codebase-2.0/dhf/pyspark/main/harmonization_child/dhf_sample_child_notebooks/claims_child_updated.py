# Databricks notebook source
# MAGIC %run ../../harmonization/_event_harmonizer_library

# COMMAND ----------

def merge_cc_claim_updt(microBatchDF, batchId, rawDB, harmonizedDB, target,param):
  print("\n entering merge_cc_claim_ph2 \n")
  harmonized_table = harmonizedDB +"."+target
  key = "CLM_KEY"
  
  #for RDM
  user_properties="RDM:LOSS_CAUSE_CD;Claim Domain,CLOSED_OUTCOME_CD;Claim Domain"
  rdm_config=getUserPropertyValue("RDM",user_properties)
  taskGroupId=getTaskGrp_id(param)      #library func
  
  
# Add Hash
  microBatchDF.createOrReplaceGlobalTempView("V")
  hashDF = addHashColumnXXHash_DHFGeneric("V")
# Dedup
  dedupDF = removeDuplicates_DHFGeneric(hashDF, harmonized_table, key)

# Add Audit Columns
  auditDF = addAuditColumns_DHFGeneric(dedupDF, key)
# Add SurrogateKey
  surrogateKeyDF = addSurrogateKey_DHFGeneric(auditDF, harmonized_table)
  
# RDM Call
  rdm_DF=rdm_function(surrogateKeyDF,rdm_config,target,taskGroupId)
  
# Merge Type2
  defaultMerge_DHFGeneric(rdm_DF, harmonized_table)


# COMMAND ----------


