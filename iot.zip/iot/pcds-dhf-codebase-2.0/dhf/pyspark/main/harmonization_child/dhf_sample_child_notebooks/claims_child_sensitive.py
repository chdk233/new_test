# Databricks notebook source
def merge_cc_claim_encrypted(microBatchDF, batchId, rawDB, harmonizedDB, target,encryptColumns,secretKey,is_encryptdata):
  print("\n entering merge_cc_claim_encrypted \n")
  harmonized_table = harmonizedDB +"."+target
  key = "claim_id"

# Add Hash
  microBatchDF.createOrReplaceGlobalTempView("V")
  hashDF = addHashColumnXXHash_DHFGeneric("V")
# Dedup
  dedupDF =removeDuplicates_DHFGeneric(hashDF, harmonized_table, key)
# Add Audit Columns
  auditDF = addAuditColumns_DHFGeneric(dedupDF, key)
# Add SurrogateKey
  surrogateKeyDF = addSurrogateKey_DHFGeneric(auditDF, harmonized_table)
# Encrypt
  if is_encryptdata:
    encryptedDF =encryptDataframe(surrogateKeyDF,encryptColumns,secretKey)
    defaultMerge_DHFGeneric(encryptedDF, harmonized_table) # Merge Type2
    
  else:
    defaultMerge_DHFGeneric(surrogateKeyDF, harmonized_table) # Merge Type2
    

