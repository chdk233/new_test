# Databricks notebook source
# MAGIC %run ../../harmonization/_event_harmonizer_library

# COMMAND ----------

from datetime import datetime, timedelta,date
from pyspark.sql.functions import col

# COMMAND ----------

def get_update_keys(df, target, merge_keys):
  print('getting updateable keys')
  update_keys = ""
  for key in df.columns:
    if key not in ('ETL_ROW_EFF_DTS','SRC_SYS_CD',f'{target.upper()}_ID') and key not in merge_keys:
      update_keys = update_keys + key + ','
    
  return update_keys[:-1]

def type1_defaultMergePartitionied_DHFGeneric(df, target, merge_key, update_key, partition_val): #sde #2
  df = removeDuplicatesMicrobatch_DHFGeneric(df,merge_key, 'ETL_ROW_EFF_DTS').filter(f"SRC_SYS_CD in ('CMT_PL_SRM','CMT_PL_FDR','CMT_PL_SRMCM','@')")
#   display(df)
  
  print("entering type1_defaultMergePartitionied_DHFGeneric")
  dt = DeltaTable.forName(spark, target)
  match_condition = (" AND ".join(list(map((lambda x: f"(events.{x.strip()}=updates.{x.strip()} OR (events.{x.strip()} is null AND updates.{x.strip()} is null))"),merge_key.split(","))))) + f" AND events.SRC_SYS_CD in ('CMT_PL_SRM','CMT_PL_FDR','CMT_PL_SRMCM','@')"
  print(match_condition)
  set_condition = ",".join(list(map((lambda x: f"{x.strip()}=updates.{x.strip()}"),update_key.split(","))))
  print(set_condition)
  sc = dict(subString.split("=") for subString in set_condition.split(","))
  print(sc)
  dt.alias('events').merge(df.alias('updates'), match_condition).whenMatchedUpdate(set = sc).whenNotMatchedInsertAll().execute()

# COMMAND ----------


def send_mail(topic_arn,subject,message,aws_accountid):
  sts_client = boto3.client("sts",region_name='us-east-1',endpoint_url ='https://sts.us-east-1.amazonaws.com')
  response2 = sts_client.assume_role(RoleArn="arn:aws:iam::"+aws_accountid+":role/pcds-databricks-common-access",RoleSessionName='myDhfsession')
  account_number = sts_client.get_caller_identity()["Account"]
  print(account_number)
  sns_client = boto3.Session(region_name='us-east-1').client("sns",
    aws_access_key_id=response2.get('Credentials').get('AccessKeyId'),
  aws_secret_access_key=response2.get('Credentials').get('SecretAccessKey'),
  aws_session_token=response2.get('Credentials').get('SessionToken'))
  topic_arn=topic_arn
  sns_client.publish(TopicArn = topic_arn, Message = message, Subject = subject)


# COMMAND ----------

def trip_label_update_func(harmonizedDB):
  
  print("In trip label update function")
 
  if ('dev') in harmonizedDB:
    env = 'dev'
  elif ('test') in harmonizedDB:
    env = 'test'
  elif ('prod') in harmonizedDB:
    env = 'prod'
    
  harmonizedDB = ('dhf_iot_harmonized_' + env)
  curatedDB = ('dhf_iot_curated_' + env)
  drive_id_check=spark.sql(f"select a.* from (select * from dhf_iot_cmt_raw_{environment}.trip_labels_daily  where db_load_date = current_date())a left anti join (select * from {harmonizedDB}.trip_summary where SRC_SYS_CD like 'CMT_PL%')b on a.driveid= b.TRIP_SMRY_KEY")
  
  if (drive_id_check.count()>0):
    #send_mail(topic_arn,subject,message,aws_accountid)
    print("drives not found ,mail sent ")
  
  data_check=spark.sql(f"select a.* from (select * from dhf_iot_cmt_raw_{environment}.trip_labels_daily  where db_load_date = current_date())a left anti join (select * from {harmonizedDB}.trip_summary where SRC_SYS_CD like 'CMT_PL%')b on a.driveid= b.TRIP_SMRY_KEY and a.user_label=b.TRNSPRT_MODE_CD")
  
  drives_compare_check=spark.sql(f"select a.* from (select * from dhf_iot_cmt_raw_{environment}.trip_labels_daily  where db_load_date = current_date())a inner join (select * from {harmonizedDB}.trip_summary where SRC_SYS_CD like 'CMT_PL%')b on a.driveid= b.TRIP_SMRY_KEY")
  

  if (data_check.count()>0) and (drives_compare_check.count()>0):
    data_collect=spark.sql(f"select * from dhf_iot_cmt_raw_{environment}.trip_labels_daily where db_load_date = current_date()").collect()
    trip_summary_df = spark.sql(f"select * from {harmonizedDB}.trip_summary where SRC_SYS_CD like 'CMT_PL%'")
    # looping thorough each row of the dataframe
    for row in data_collect:
      trip_data = trip_summary_df.filter(trip_summary_df.TRIP_SMRY_KEY==(row['driveid']))
      if(trip_data.count()>0):
        tds= trip_data.collect()
        print(tds[0].TRNSPRT_MODE_CD)
        if(not tds[0].TRNSPRT_MODE_CD == row['user_label'] ):
          print("updating")
          res = spark.sql(f"UPDATE {harmonizedDB}.trip_summary set  TRNSPRT_MODE_CD = '{row['user_label']}',ETL_LAST_UPDT_DTS = CURRENT_TIMESTAMP() where lower(TRIP_SMRY_KEY) = lower('{row['driveid']}') and SRC_SYS_CD like 'CMT_PL%'")
          print(res)  

# COMMAND ----------

def merge_cmt_pl_fraud_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "EMAIL_ID,DRIVER_KEY,DEVC_KEY,ANMLY_TP_CD,ANMLY_DEVC_TS,ANMLY_SRVR_TS,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')
  
def merge_cmt_pl_heartbeat_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "DRIVER_KEY,CURR_TS,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys) 
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')
  
def merge_cmt_pl_badge_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "EMAIL_ID,DRIVER_KEY,BDG_NM,BDG_PRGRS_NB,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')
  
def merge_cmt_pl_driver_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "EMAIL_ID,FLEET_ID,GROUP_ID,PLCY_NB,DRIVER_KEY,TAG_USER_SRC_IN,TAG_USER_DERV_IN,TEAM_ID,USER_NM,AVG_SCR_QTY,AVG_ACLRTN_SCR_QTY,AVG_BRKE_SCR_QTY,AVG_TURN_SCR_QTY,AVG_SPD_SCR_QTY,AVG_PHN_MTN_SCR_QTY,TOT_DISTNC_KM_QTY,TOT_TRIP_CNT,SCR_INTRV_DRTN_QTY,USER_DRIV_LBL_HNRD_SRC_IN,USER_DRIV_LBL_HNRD_DERV_IN,SCR_TS,FAM_GROUP_CD,PLCY_ST_CD,PRGRM_CD,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')
  

def merge_cmt_pl_user_permissions_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "CUST_NM,DRIVER_KEY,SRC_CUST_KEY,ACCT_ID,USR_NM,EMAIL_ID,MOBL_NB,GROUP_ID,UNQ_GROUP_NM,PLCY_NB,FLT_ID,FLT_NM,TEAM_ID,TEAM_NM,LAST_SHRT_VEHCL_ID,VIN_NB,VHCL_MAKE_NM,VHCL_MODEL_NM,LST_TAG_MAC_ADDR_NM,DEVC_KEY,DEVC_MODL_NM,DEVC_BRND_NM,DEVC_MFRR_NM,OS_NM,OS_VRSN_NM,APP_VRSN_NM,LAST_DRV_TS,DAYS_SINCE_LAST_TRIP_CT,LAST_ACTVTY_TS,RGSTRTN_TS,USER_LOGGED_SRC_IN,USER_LOGGED_DERV_IN,LAST_AUTHRZN_TS,PTNTL_ISSUES_TT,USR_ACCT_EXP_DT,PLCY_ST_CD,PRGRM_CD,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')

def merge_cmt_pl_trip_labels_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,USER_LBL_NM,USER_LBL_TS,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')

def merge_cmt_pl_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')


def merge_cmt_pl_driver_profile_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "DRIVER_KEY,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')




# COMMAND ----------

# CMT realtime trip point in separate notebook: CMT_CL_REALTIME_TRIP_POINT
def merge_cmt_pl_trip_summary_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  currentEDTTimeInHour = spark.sql("select hour(from_utc_timestamp(current_timestamp, 'EST'))").collect()[0][0]
  print(f" \n currentEDTTimeInHour : {currentEDTTimeInHour} ")
  if currentEDTTimeInHour==10:
    trip_label_update_func(harmonizedDB)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')

def merge_cmt_pl_trip_events_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,EVNT_TP_CD,UTC_TS,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')
  
def merge_cmt_pl_GPS_waypts_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,WYPNT_LAT_NB,WYPNT_LNGTD_NB,UTC_TS,AVG_SPD_KMH_RT,MAX_SPD_KMH_RT,SPD_LMT_KMH_QTY,LINK_ID,DSPLY_CD,PRPND_STTS_SRC_IN,SRC_SYS_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_PL')
  

# COMMAND ----------

#scoring
def type1_defaultMergePartitionied_fdr_scoring(df, target, merge_key, update_key): #sde #2
  df = removeDuplicatesMicrobatch_DHFGeneric(df,merge_key, 'ETL_ROW_EFF_DTS')
#   display(df)
  
  print("entering type1_defaultMergePartitionied_DHFGeneric")
  dt = DeltaTable.forName(spark, target)
  match_condition = (" AND ".join(list(map((lambda x: f"(events.{x.strip()}=updates.{x.strip()} OR (events.{x.strip()} is null AND updates.{x.strip()} is null))"),merge_key.split(","))))) 
  print(match_condition)
  set_condition = ",".join(list(map((lambda x: f"{x.strip()}=updates.{x.strip()}"),update_key.split(","))))
  print(set_condition)
  sc = dict(subString.split("=") for subString in set_condition.split(","))
  print(sc)
  dt.alias('events').merge(df.alias('updates'), match_condition).whenMatchedUpdate(set = sc).whenNotMatchedInsertAll().execute()

    
def merge_cmt_pl_trip_driver_score(microBatchDF, batchId, rawDB, harmonizedDB, target):
#   microBatchDF=microBatchDF.filter("MODL_ACRNYM_TT like '%FDR%'")
  merge_keys = "MODL_NM,MODL_VRSN_TT,MODL_ACRNYM_TT,ANLYTC_TP_CD,TRIP_INSTC_ID,TRIP_SMRY_KEY,DATA_CLCTN_ID,DRIVR_KEY,POLICY_KEY,TRIP_CT,EVNT_SRC,DRVNG_DISTNC_QTY,PHN_MTN_CT,HNDHLD_CT,TAP_CT,PHN_HNDLNG_CT,TRNSCTN_TP_CD,MDL_OTPT_TP_CD,MDL_OTPT_SCR_QTY,MDL_OTPT_SCR_TS,WGHT_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_CD,WGHT_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_SCR_QTY,WGHT_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_SCR_TS,HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_CD,HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_SCR_QTY,HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_SCR_TS,PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_SCR_CD,PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_SCR_QTY,PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_SCR_TS,DRVNG_DISTNC_MPH_QTY,TRNSPRT_MODE_CD,TRIP_END_TS,TIME_ZONE_OFFST_NB,USER_LBL_DT,OPRTN_SCR_IN,ADJST_DISTNC_KM_QTY,AVG_ANNL_ADJ_KM,EXPSR_YR,MOVNG_SEC_QTY,LAST_TRIP_DT,LOG_EXPSR_YR,SCR_CALC_DT,SCR_CALC_TS,SCR_QTY,RQ5_QTY,SCR_DAYS_CT,TRNSCTN_ID,prgrm_term_beg_dt_used,prgrm_term_end_dt_used,ENTRP_CUST_NB,LAST_RQST_DT,PLCY_ST_CD,PRGRM_TERM_BEG_DT,PRGRM_TERM_END_DT,PRGRM_STTS_DSC,DATA_CLCTN_STTS_DSC,DEVC_STTS_DT,PRGRM_TP_CD,PGRM_CD,SRC_SYS_CD,SBJT_ID,SBJCT_TP_CD,VNDR_CD,DEVC_ID,DEVC_STTS_CD,INSTL_GRC_END_DT,LOG_ANNL_ADJST_MILES_QTY,RQ5A_QTY,PCTG_TRIP_MSSNG,PRGRM_SCR_MODL_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_fdr_scoring(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys)

# def merge_cmt_pl_nm2_trip_driver_score(microBatchDF, batchId, rawDB, harmonizedDB, target):
#   microBatchDF=microBatchDF.filter("MODL_ACRNYM_TT like '%NM2%'")
#   merge_keys = "ANLYTC_TP_CD,DATA_CLCTN_ID,TRIP_SMRY_KEY,POLICY_KEY,TRIP_INSTC_ID,DRIVR_KEY,ADJST_DISTNC_KM_QTY,MOVNG_SEC_QTY,PCTG_TRIP_MSSNG,RQ5_QTY,TRNSPRT_MODE_CD,TRIP_END_TS,EVNT_SRC,OPRTN_SCR_IN,TRNSCTN_ID,USER_LBL_DT,TIME_ZONE_OFFST_NB,MODL_ACRNYM_TT,MODL_NM,MODL_VRSN_TT,TRNSCTN_TP_CD,DATA_CLCTN_STTS_DSC,DEVC_ID,DEVC_STTS_CD,DEVC_STTS_DT,ENTRP_CUST_NB,INSTL_GRC_END_DT,LAST_RQST_DT,PLCY_ST_CD,PGRM_CD,PRGRM_STTS_DSC,PRGRM_TERM_BEG_DT,PRGRM_TERM_END_DT,PRGRM_TP_CD,SBJT_ID,SBJCT_TP_CD,RQ5A_QTY,LOG_ANNL_ADJST_MILES_QTY,AVG_ANNL_ADJ_KM,EXPSR_YR,LOG_EXPSR_YR,LAST_TRIP_DT,SCR_CALC_TS,TRIP_CT,SCR_QTY,SCR_DAYS_CT,MDL_OTPT_SCR_QTY,MDL_OTPT_SCR_TS,MDL_OTPT_TP_CD,SRC_SYS_CD,VNDR_CD,SCR_CALC_DT"
#   update_keys = get_update_keys(microBatchDF, target, merge_keys)
#   print(f" \n merge keys : {merge_keys} ")
#   print(f" \n update keys : {update_keys} ")
#   type1_defaultMergePartitionied_fdr_scoring(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys,  "NM2")

# COMMAND ----------

# microBatchDF = spark.sql("select * from dhf_iot_harmonized_test.trip_gps_waypoints_chlg limit 10")
# # display(microBatchDF)
# harmonizedDB = 'dhf_iot_harmonized_test'
# target = "trip_gps_waypoints"
# merge_keys = "TRIP_SMRY_KEY,WYPNT_LAT_NB,WYPNT_LNGTD_NB,UTC_TS,AVG_SPD_KMH_RT,MAX_SPD_KMH_RT,SPD_LMT_KMH_QTY,LINK_ID,DSPLY_CD,PRPND_STTS_SRC_IN"
# update_key = get_update_keys(microBatchDF, target, merge_keys)
# print(f" \n merge keys : {merge_keys} ")
# print(f" \n update keys : {update_key} ")
# print()

# type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_key, 'CMT_CL_VF')
