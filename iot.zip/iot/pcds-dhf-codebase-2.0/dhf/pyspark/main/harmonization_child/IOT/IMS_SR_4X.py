# Databricks notebook source
# MAGIC %run ../../harmonization/_event_harmonizer_library

# COMMAND ----------

from datetime import datetime, timedelta,date
    

# COMMAND ----------

def type1_defaultMergePartitionied_tripsummary_IMS_SR_4X_IOT(df, target, merge_key1, merge_key2):
  source_code = 'IMS_SR_4X'
  print("entering type1_defaultMergePartitionied_IMS_IOT")
  
#   merge_start_date= date.today() - timedelta(days=558)
  df_ims=df.where(col("SRC_SYS_CD").like(f"{source_code}"))
  
  print("entering removeduplicates microbatch function \n")
#   partition_cols=merge_key.split(",")
  w = Window.partitionBy(merge_key1,merge_key2).orderBy(col("ETL_ROW_EFF_DTS").desc())
  firsRowDF_ims = df_ims.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print("leaving removeduplicates microbatch function")
  
  
  firsRowDF_ims.createOrReplaceGlobalTempView("History_view_ims")

  spark.sql(f"""merge into {target} target using (select  * from global_temp.History_view_ims) updates on target.{merge_key1} = updates.{merge_key1} and target.{merge_key2} = updates.{merge_key2} and target.SRC_SYS_CD = '{source_code}' and target.load_dt >= add_months(current_date,-18)    when matched then update set * when not matched then insert *""")
    

  
  print("end of type1_defaultMergePartitionied_DHFGeneric function")

# COMMAND ----------

def type1_defaultMergePartitionied_IMS_SR_4X_IOT(df, target, merge_key1, merge_key2):
  source_code = 'IMS_SR_4X'
  print("entering type1_defaultMergePartitionied_IMS_IOT")
  
#   merge_start_date= date.today() - timedelta(days=558)
  df_ims=df.where(col("SRC_SYS_CD").like(f"{source_code}"))
  
  print("entering removeduplicates microbatch function \n")
#   partition_cols=merge_key.split(",")
  w = Window.partitionBy(merge_key1,merge_key2).orderBy(col("ETL_ROW_EFF_DTS").desc())
  firsRowDF_ims = df_ims.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print("leaving removeduplicates microbatch function")
  
  mb_trips_ims=firsRowDF_ims.select("trip_smry_key").distinct()
#   display(mb_trips)
  
  History_trips_ims=spark.sql(f"select tripsummaryid,load_date from dhf_iot_ims_raw_{environment}.tripsummary where load_date >= add_months(load_date,-18)")
  print("done")
  
  History_check_ims=History_trips_ims.join(mb_trips_ims,History_trips_ims["tripsummaryid"]==mb_trips_ims["trip_smry_key"],"inner").select(History_trips_ims["*"])
  
  History_dates_ims=*([row[0] for row in History_check_ims.selectExpr('cast(load_date as string)').distinct().collect()]),'0','1'
  
  firsRowDF_ims.createOrReplaceGlobalTempView("History_view_ims")
  print("history")
  spark.sql(f"""merge into {target} target using (select  * from global_temp.History_view_ims) updates on target.{merge_key1} = updates.{merge_key1} and target.{merge_key2} = updates.{merge_key2} and target.SRC_SYS_CD = '{source_code}' and target.LOAD_DT in {History_dates_ims}   when matched then update set * when not matched then insert *""")
    
 
  print("end of type1_defaultMergePartitionied_DHFGeneric function")

# COMMAND ----------

def merge_ims_sr_4x_trip_point_iot(microBatchDF, batchId, rawDB, harmonizedDB, target):
  print("\n entering merge_cc_claim_ph2 \n")
  
  harmonized_table = harmonizedDB +"."+target
  
  type1_defaultMergePartitionied_IMS_SR_4X_IOT(microBatchDF,harmonized_table,"TRIP_SMRY_KEY","UTC_TS")

# COMMAND ----------

def merge_ims_sr_4x_trip_summary_iot(microBatchDF, batchId, rawDB, harmonizedDB, target):
  print("\n entering merge_cc_claim_ph2 \n")
  
  harmonized_table = harmonizedDB +"."+target
  
  type1_defaultMergePartitionied_tripsummary_IMS_SR_4X_IOT(microBatchDF,harmonized_table,"TRIP_SMRY_KEY","SRC_SYS_CD")
