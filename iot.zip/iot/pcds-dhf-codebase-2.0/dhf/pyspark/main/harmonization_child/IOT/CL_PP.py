# Databricks notebook source
# MAGIC %run ../../harmonization/_event_harmonizer_library

# COMMAND ----------

from datetime import datetime, timedelta,date
from pyspark.sql.functions import col

# COMMAND ----------

def get_update_keys(df, target, merge_keys):
  print('getting updateable keys')
  update_keys = ""
  for key in df.columns:
    if key not in ('ETL_ROW_EFF_DTS','SRC_SYS_CD',f'{target.upper()}_ID') and key not in merge_keys:
      update_keys = update_keys + key + ','
    
  return update_keys[:-1]

def type1_defaultMergePartitionied_DHFGeneric(df, target, merge_key, update_key, partition_val): #sde #2
  df = removeDuplicatesMicrobatch_DHFGeneric(df,merge_key, 'ETL_ROW_EFF_DTS').where(col(f"SRC_SYS_CD")==f"{partition_val}")
#   display(df)
  
  print("entering type1_defaultMergePartitionied_DHFGeneric")
  dt = DeltaTable.forName(spark, target)
  match_condition = (" AND ".join(list(map((lambda x: f"(events.{x.strip()}=updates.{x.strip()} OR (events.{x.strip()} is null AND updates.{x.strip()} is null))"),merge_key.split(","))))) + f" AND events.SRC_SYS_CD = '{partition_val}'"
  print(match_condition)
  set_condition = ",".join(list(map((lambda x: f"{x.strip()}=updates.{x.strip()}"),update_key.split(","))))
  print(set_condition)
  sc = dict(subString.split("=") for subString in set_condition.split(","))
  print(sc)
  dt.alias('events').merge(df.alias('updates'), match_condition).whenMatchedUpdate(set = sc).whenNotMatchedInsertAll().execute()

# COMMAND ----------

def merge_azuga_cl_pp_breadcrumb_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,VNDR_GROUP_KEY,DRIVR_KEY,EVNT_TS,EVNT_TP,LAT_NB,LNGTD_NB,STRT_ADDR"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_aggregate_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,RPRTD_TRIP_DT"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_master_acct_report(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_driver_listing_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,DRIVR_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_vehicle_listing_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,VNDR_CAR_KEY,VEH_NM,ENRLD_VIN_NB,LAST_ODMTR_QTY,DRIVR_KEY,DEVC_SRL_NB,DEVC_STTS_CD,RPRTD_VRSN_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys) 
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_diagnostics_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,DRIVR_KEY,VNDR_CAR_KEY,VNDR_GROUP_KEY,EVNT_TS,OBDII_CD,JBUS_SPN_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_events_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,DRIVR_KEY,VNDR_CAR_KEY,VNDR_GROUP_KEY,EVNT_TS,LAT_NB,LNGTD_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys) 
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,DRIVR_KEY,VNDR_CAR_KEY,VNDR_GROUP_KEY,TRIP_SMRY_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_vehicle_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_COMPNY_ID,PLCY_NB,VNDR_CAR_KEY,VNDR_GROUP_KEY,TRIP_DT"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')
  
def merge_azuga_cl_pp_hf_trip_summary(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,DEVC_SRL_NB,TRIP_END_EPCH_TS,TRIP_START_EPCH_TS"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')

def merge_azuga_cl_pp_hf_trip_point(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,DEVC_SRL_NB,TRIP_RECRD_EPOCH_TS"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'AZUGA_CL_PP')

# COMMAND ----------

def merge_zubie_cl_pp_trip_summary_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'ZUBIE_CL_PP')
  
def merge_zubie_cl_pp_xref_acct_devc_car_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "FLEET_ID,VNDR_ACCT_KEY,DEVC_KEY,DVC_ACCT_STTS,VNDR_CAR_KEY,SUBSCRPTN_END_DT,DSCNT_STTS,DETECTED_VIN,ENRLD_VIN,VEH_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'ZUBIE_CL_PP')
  
def merge_zubie_cl_pp_driving_events_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,EVNT_TP_CD,UTC_TS,LAT_NB,LNGTD_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'ZUBIE_CL_PP')
  
def merge_zubie_cl_pp_device_events_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "DEVC_KEY,EVNT_TP_CD,UTC_TS,LAT_NB,LNGTD_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'ZUBIE_CL_PP')
  
def merge_zubie_cl_pp_compliancekpi_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "ACCT_NM,VNDR_ACCT_ID,DEVC_SHP_DT,DEVC_SHP_QTY,DEVC_ACTV_QTY,SCHDL_RPT_QTY,DVC_INSTL_QTY,DVC_TRNSMT_QTY,MLG_QTY,VNDR_CMPNY_ID"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'ZUBIE_CL_PP')
  
def merge_zubie_cl_pp_programkpi_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "VNDR_ACCT_ID,DEVC_SRL_NB,DEVC_SHP_DT,DEVC_FRST_DT,DEVC_LAST_DT,INSTL_DAYS_CT,MILE_CT,TRIP_CT,HARD_BRK_CT,SPD_CT,HARD_BRK_CT_PER_100,SPD_CT_PER_100,ACLRTN_CT,ACLRTN_CT_PER_100,VNDR_CMPNY_ID"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'ZUBIE_CL_PP')
  
def merge_zubie_cl_pp_trip_point_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,UTC_TS"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'ZUBIE_CL_PP')

# COMMAND ----------

def merge_cmt_cl_pp_fraud_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "EMAIL_ID,DRIVER_KEY,DEVC_KEY,ANMLY_TP_CD,ANMLY_DEVC_TS,ANMLY_SRVR_TS"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')
  
def merge_cmt_cl_pp_heartbeat_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "DRIVER_KEY,CURR_TS"
  update_keys = get_update_keys(microBatchDF, target, merge_keys) 
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')
  
def merge_cmt_cl_pp_badge_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "EMAIL_ID,DRIVER_KEY,BDG_NM,BDG_PRGRS_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')
  
def merge_cmt_cl_pp_driver_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "EMAIL_ID,FLEET_ID,GROUP_ID,PLCY_NB,DRIVER_KEY,TAG_USER_SRC_IN,TAG_USER_DERV_IN,TEAM_ID,USER_NM,AVG_SCR_QTY,AVG_ACLRTN_SCR_QTY,AVG_BRKE_SCR_QTY,AVG_TURN_SCR_QTY,AVG_SPD_SCR_QTY,AVG_PHN_MTN_SCR_QTY,TOT_DISTNC_KM_QTY,TOT_TRIP_CNT,SCR_INTRV_DRTN_QTY,USER_DRIV_LBL_HNRD_SRC_IN,USER_DRIV_LBL_HNRD_DERV_IN,SCR_TS,FAM_GROUP_CD,PLCY_ST_CD,PRGRM_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')
  
def merge_cmt_cl_pp_team_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "FLT_ID,FLT_TM_ID,FLT_TM_NM,AVG_SCR,AVG_SCR_ACLRTN,AVG_SCR_BRK,AVG_SCR_TRN,AVG_SCR_SPDNG,AVG_SCR_PHN_MTN,DRVNG_DISTNC_KM_QTY,TOT_TRIP_QTY,SCRG_INTRVL_QTY,HNRG_USER_DRV_LBL_SRC_IN,SCRG_DT"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_user_permissions_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "CUST_NM,DRIVER_KEY,SRC_CUST_KEY,ACCT_ID,USR_NM,EMAIL_ID,MOBL_NB,GROUP_ID,UNQ_GROUP_NM,PLCY_NB,FLT_ID,FLT_NM,TEAM_ID,TEAM_NM,LAST_SHRT_VEHCL_ID,VIN_NB,VHCL_MAKE_NM,VHCL_MODEL_NM,LST_TAG_MAC_ADDR_NM,DEVC_KEY,DEVC_MODL_NM,DEVC_BRND_NM,DEVC_MFRR_NM,OS_NM,OS_VRSN_NM,APP_VRSN_NM,LAST_DRV_TS,DAYS_SINCE_LAST_TRIP_CT,LAST_ACTVTY_TS,RGSTRTN_TS,USER_LOGGED_SRC_IN,USER_LOGGED_DERV_IN,LAST_AUTHRZN_TS,PTNTL_ISSUES_TT,USR_ACCT_EXP_DT,PLCY_ST_CD,PRGRM_CD"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_trip_labels_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,USER_LBL_NM,USER_LBL_TS"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_vehicle_tag_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "SHRT_VEH_ID"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_driver_profile_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "DRIVER_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_tag_link_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TAG_MAC_ADDR_NM,DRVR_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_tag_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TAG_MAC_ADDR_NM,TAG_TRIP_NB"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_portal_user_activity_report_daily(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "USER_ACTVTY_DTS,USER_NM,USER_ROLE,PAGE_VISTD_NM"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

# COMMAND ----------

# CMT realtime trip point in separate notebook: CMT_CL_REALTIME_TRIP_POINT
def merge_cmt_cl_pp_trip_summary_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')

def merge_cmt_cl_pp_trip_events_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,EVNT_TP_CD,UTC_TS"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')
  
def merge_cmt_cl_pp_GPS_waypts_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target):
  merge_keys = "TRIP_SMRY_KEY,WYPNT_LAT_NB,WYPNT_LNGTD_NB,UTC_TS,AVG_SPD_KMH_RT,MAX_SPD_KMH_RT,SPD_LMT_KMH_QTY,LINK_ID,DSPLY_CD,PRPND_STTS_SRC_IN"
  update_keys = get_update_keys(microBatchDF, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")
  type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_keys, 'CMT_CL_VF')
  

# COMMAND ----------

# microBatchDF = spark.sql("select * from dhf_iot_harmonized_test.trip_gps_waypoints_chlg limit 10")
# # display(microBatchDF)
# harmonizedDB = 'dhf_iot_harmonized_test'
# target = "trip_gps_waypoints"
# merge_keys = "TRIP_SMRY_KEY,WYPNT_LAT_NB,WYPNT_LNGTD_NB,UTC_TS,AVG_SPD_KMH_RT,MAX_SPD_KMH_RT,SPD_LMT_KMH_QTY,LINK_ID,DSPLY_CD,PRPND_STTS_SRC_IN"
# update_key = get_update_keys(microBatchDF, target, merge_keys)
# print(f" \n merge keys : {merge_keys} ")
# print(f" \n update keys : {update_key} ")
# print()

# type1_defaultMergePartitionied_DHFGeneric(microBatchDF, f"{harmonizedDB}.{target}", merge_keys, update_key, 'CMT_CL_VF')
