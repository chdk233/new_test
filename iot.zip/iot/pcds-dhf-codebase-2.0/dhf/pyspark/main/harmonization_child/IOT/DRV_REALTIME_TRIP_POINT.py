# Databricks notebook source
# MAGIC %run ../../harmonization/_event_harmonizer_library

# COMMAND ----------

from datetime import datetime, timedelta,date
    

# COMMAND ----------

def type1_defaultMergePartitionied_IOT(df, target, merge_key1, merge_key2):
  
  print("entering type1_defaultMergePartitionied_IOT")
  source_code = 'DRV_IQ_PL'
  df=df.where(col("SRC_SYS_CD").like(f"{source_code}"))
  
  print("entering removeduplicates microbatch function \n")
  w = Window.partitionBy(merge_key1,merge_key2).orderBy(col("ETL_ROW_EFF_DTS").desc())
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print("leaving removeduplicates microbatch function")
  
  mb_trips=firsRowDF.select("trip_smry_key").distinct()
  
  History_trips=spark.sql(f"select driveid,load_dt from dhf_iot_drv_raw_{environment}.trip_summary_realtime where  load_dt >= add_months(load_dt,-3)")
  print("done")
  
  History_check=History_trips.join(mb_trips,History_trips["driveid"]==mb_trips["trip_smry_key"],"inner").select(History_trips["*"])
  History_dates=*([row[0] for row in History_check.selectExpr('cast(load_dt as string)').distinct().collect()]),'0','1'
  print(History_dates)
  firsRowDF.createOrReplaceGlobalTempView("History_view")
  # counts=df.count()
  # print(counts)
  # df.write.format("delta").mode("append").saveAsTable(f"{target}")

  print("history")
  spark.sql(f"""merge into {target} target using (select  * from global_temp.History_view) updates on target.{merge_key1} = updates.{merge_key1} and target.{merge_key2} = updates.{merge_key2} and target.SRC_SYS_CD like '{source_code}' and target.LOAD_DT in {History_dates}   when matched then update set * when not matched then insert *""")
    

  
  print("end of type1_defaultMergePartitionied_DHFGeneric function")

# COMMAND ----------

def merge_trip_point_iot(microBatchDF, batchId, rawDB, harmonizedDB, target):
  print("\n entering merge_drv_trip_point \n")
  
  harmonized_table = harmonizedDB +"."+target
  
  type1_defaultMergePartitionied_IOT(microBatchDF,harmonized_table,"TRIP_SMRY_KEY","UTC_TS")
  
  
  
