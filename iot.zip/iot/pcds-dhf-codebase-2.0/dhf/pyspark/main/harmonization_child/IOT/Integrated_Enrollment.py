# Databricks notebook source
print("calling the integrated_enrollement child notebook")

# COMMAND ----------

### obtains all enrollments from target for a given input vin which are not present in the microBatch and union them with input data to be processed as one data set
### Scenario: input from ODS only for a given vin which has existing records in target from PE
###           needed to determine most recent enrollment field
def get_existing_records_per_vin(harmonizedDB, target_table):
  return  spark.sql(f"""select tot.* from (select distinct
  trg.*,
  'target' as INPT_SRC
from
  (
    select
      distinct VIN_NB,
      DATA_CLCTN_ID,
      PRGRM_INSTC_ID,
      DEVC_ID,
      CRNT_ENRLMNT_FLG,
      ENRLMNT_STTS,
      ENRLMNT_EFCTV_DT,
      ENRLMNT_STRT_DT,
      ENRLMNT_END_DT,
      POLICY_KEY,
      POLICY_KEY_ID,
      PLCY_ST_CD,
      SRC_SYS_CD,
      LOAD_HR_TS,
      LOAD_DT
    from
      {harmonizedDB}.{target_table}
  ) trg
  inner join (
    select
      VIN_NB,
      DATA_CLCTN_ID,
      PRGRM_INSTC_ID,
      SRC_SYS_CD
    from
      global_temp.microBatchViewName
  ) mb on trg.VIN_NB = mb.VIN_NB) tot left join (select
      VIN_NB,
      DATA_CLCTN_ID,
      PRGRM_INSTC_ID,
      SRC_SYS_CD
    from
      global_temp.microBatchViewName) mb on tot.VIN_NB = mb.VIN_NB and tot.DATA_CLCTN_ID = mb.DATA_CLCTN_ID or tot.PRGRM_INSTC_ID = mb.PRGRM_INSTC_ID
  where mb.VIN_NB is null
  union
  select
    DISTINCT VIN_NB,
    DATA_CLCTN_ID,
    PRGRM_INSTC_ID,
    DEVC_ID,
    CRNT_ENRLMNT_FLG,
    ENRLMNT_STTS,
    ENRLMNT_EFCTV_DT,
    ENRLMNT_STRT_DT,
    ENRLMNT_END_DT,
    POLICY_KEY,
    POLICY_KEY_ID,
    PLCY_ST_CD,
    SRC_SYS_CD,
    LOAD_HR_TS,
    LOAD_DT,
    'microbatch' as INPT_SRC
  from
    global_temp.microBatchViewName""")

# COMMAND ----------

def determine_crnt_enrlmnt_across_pe_ods():
  return spark.sql(f"""select
  distinct current_timestamp() as ETL_ROW_EFF_DTS,
  current_timestamp() as ETL_LAST_UPDT_DTS,
  ieAll.VIN_NB,
  ieAll.DATA_CLCTN_ID,
  ieAll.PRGRM_INSTC_ID,
  ieAll.DEVC_ID,
  case
    when (
      crntEnrl.CRNT_ENRLMNT = ieAll.DATA_CLCTN_ID
      or crntEnrl.CRNT_ENRLMNT = ieAll.PRGRM_INSTC_ID
    )
    and crntEnrl.CRNT_ENRLMNT_SRC_SYS_CD = ieAll.SRC_SYS_CD then 'Y'
    else 'N'
  end as CRNT_ENRLMNT_FLG,
  ieAll.ENRLMNT_STTS,
  ieAll.ENRLMNT_EFCTV_DT,
  ieAll.ENRLMNT_STRT_DT,
  ieAll.ENRLMNT_END_DT,
  ieAll.PLCY_ST_CD,
  ieAll.POLICY_KEY,
  ieAll.POLICY_KEY_ID,
  ieAll.SRC_SYS_CD,
  ieAll.LOAD_HR_TS,
  ieAll.LOAD_DT
from
  new_IE ieAll
  left join (
    select
      distinct coalesce(pe.VIN_NB, ods.VIN_NB) as VIN_NB,
      case
        when pe.ENRLMNT_EFCTV_DT > ods.ENRLMNT_EFCTV_DT
        or ods.VIN_NB is null
        or pe.DATA_CLCTN_ID = ods.PRGRM_INSTC_ID then pe.DATA_CLCTN_ID
        when pe.ENRLMNT_EFCTV_DT < ods.ENRLMNT_EFCTV_DT
        or pe.VIN_NB is null then ods.PRGRM_INSTC_ID
        when pe.ENRLMNT_EFCTV_DT = ods.ENRLMNT_EFCTV_DT then case
          when pe.ENRLMNT_STRT_DT >= ods.ENRLMNT_STRT_DT then pe.DATA_CLCTN_ID
          else ods.PRGRM_INSTC_ID
        end
      end as CRNT_ENRLMNT,
      case
        when pe.ENRLMNT_EFCTV_DT > ods.ENRLMNT_EFCTV_DT
        or ods.VIN_NB is null
        or pe.DATA_CLCTN_ID = ods.PRGRM_INSTC_ID then pe.SRC_SYS_CD
        when pe.ENRLMNT_EFCTV_DT < ods.ENRLMNT_EFCTV_DT
        or pe.VIN_NB is null then ods.SRC_SYS_CD
        when pe.ENRLMNT_EFCTV_DT = ods.ENRLMNT_EFCTV_DT then case
          when pe.ENRLMNT_STRT_DT >= ods.ENRLMNT_STRT_DT then pe.SRC_SYS_CD
          else ods.SRC_SYS_CD
        end
      end as CRNT_ENRLMNT_SRC_SYS_CD
    from
      (
        select
          distinct VIN_NB,
          SRC_SYS_CD,
          PRGRM_INSTC_ID,
          ENRLMNT_EFCTV_DT,
          ENRLMNT_STRT_DT,
          CRNT_ENRLMNT_FLG
        from
          ods_table
        where
          CRNT_ENRLMNT_FLG = 'Y'
      ) ods full
      outer join (
        select
          distinct VIN_NB,
          SRC_SYS_CD,
          DATA_CLCTN_ID,
          ENRLMNT_EFCTV_DT,
          ENRLMNT_STRT_DT,
          CRNT_ENRLMNT_FLG
        from
          program_enrollment
        where
          CRNT_ENRLMNT_FLG = 'Y'
      ) pe on ods.VIN_NB = pe.VIN_NB
      and ods.CRNT_ENRLMNT_FLG = pe.CRNT_ENRLMNT_FLG
  ) crntEnrl on ieAll.VIN_NB = crntEnrl.VIN_NB
  and (
    ieAll.DATA_CLCTN_ID = crntEnrl.CRNT_ENRLMNT
    or ieAll.PRGRM_INSTC_ID = crntEnrl.CRNT_ENRLMNT
  )
where
  crntEnrl.CRNT_ENRLMNT is null
  or (
    crntEnrl.CRNT_ENRLMNT is not null
    and crntEnrl.CRNT_ENRLMNT_SRC_SYS_CD = ieAll.SRC_SYS_CD
  )""")

# COMMAND ----------

def  integrated_enrollment_function(microBatchDF, batchId, harmonizedDB,target_table):
  
  print("In integrated_enrollment_function")
  
  microBatchDF.createOrReplaceGlobalTempView("microBatchViewName")

  get_existing_records_per_vin(harmonizedDB, target_table).createOrReplaceGlobalTempView("microBatchViewName")

 
  # separate data by source tables from microBatch
  program_enrollment_df = spark.sql(f"select distinct VIN_NB,DATA_CLCTN_ID,null as PRGRM_INSTC_ID,DEVC_ID,CRNT_ENRLMNT_FLG,ENRLMNT_STTS,ENRLMNT_EFCTV_DT,ENRLMNT_STRT_DT,ENRLMNT_END_DT,POLICY_KEY,POLICY_KEY_ID,PLCY_ST_CD,SRC_SYS_CD,LOAD_HR_TS,LOAD_DT,INPT_SRC from global_temp.microBatchViewName where SRC_SYS_CD != 'ODS'").dropDuplicates(["VIN_NB","DATA_CLCTN_ID","PRGRM_INSTC_ID","POLICY_KEY","POLICY_KEY_ID","SRC_SYS_CD","ENRLMNT_STTS","CRNT_ENRLMNT_FLG","DEVC_ID","ENRLMNT_EFCTV_DT","ENRLMNT_STRT_DT","ENRLMNT_END_DT","PLCY_ST_CD","LOAD_HR_TS","LOAD_DT","INPT_SRC"])

  program_enrollment_df.createOrReplaceTempView('program_enrollment')

  ods_df = spark.sql(f"select distinct VIN_NB,null as DATA_CLCTN_ID,PRGRM_INSTC_ID,DEVC_ID,CRNT_ENRLMNT_FLG,ENRLMNT_STTS,ENRLMNT_EFCTV_DT,ENRLMNT_STRT_DT,ENRLMNT_END_DT,POLICY_KEY,POLICY_KEY_ID,PLCY_ST_CD,SRC_SYS_CD,LOAD_HR_TS,LOAD_DT,INPT_SRC from global_temp.microBatchViewName where SRC_SYS_CD = 'ODS'")

  ods_df.createOrReplaceTempView('ods_table')

  # remove enrollments from ODS which are also in PE (assuming all of these will be from SRP replatform)
  dups_df = spark.sql(f"select ods.* from program_enrollment pe inner join ods_table ods on ods.VIN_NB = pe.VIN_NB and ods.PRGRM_INSTC_ID = pe.DATA_CLCTN_ID")

  ods_new = ods_df.subtract(dups_df).dropDuplicates(["VIN_NB","DATA_CLCTN_ID","PRGRM_INSTC_ID","POLICY_KEY","POLICY_KEY_ID","SRC_SYS_CD","ENRLMNT_STTS","CRNT_ENRLMNT_FLG","DEVC_ID","ENRLMNT_EFCTV_DT","ENRLMNT_STRT_DT","ENRLMNT_END_DT","PLCY_ST_CD","LOAD_HR_TS","LOAD_DT","INPT_SRC"])

  ods_new.createOrReplaceTempView('ods_table')

  # put data back together 
  ods_new.union(program_enrollment_df).createOrReplaceTempView('new_IE')

  determine_crnt_enrlmnt_across_pe_ods().createOrReplaceTempView('new_IE2')


  spark.sql(f"""merge into {harmonizedDB}.{target_table} target using (
    select
      cast(
        row_number() over(
          order by
            NULL
        ) + 1 + coalesce(
          (
            select
              max(INTEGRATED_ENROLLMENT_ID)
            from
              {harmonizedDB}.{target_table}
          ),
          0
        ) as BIGINT
      ) as INTEGRATED_ENROLLMENT_ID,
      *
    from
      new_IE2
  ) updates on target.VIN_NB = updates.VIN_NB
  and ((
    (target.PRGRM_INSTC_ID = updates.PRGRM_INSTC_ID)
    or (
      target.PRGRM_INSTC_ID is null
      and updates.PRGRM_INSTC_ID is null
    )
  )
  and (
    (
      target.DATA_CLCTN_ID is null
      and updates.DATA_CLCTN_ID is null
    )
    or (target.DATA_CLCTN_ID = updates.DATA_CLCTN_ID)
  ) or target.DATA_CLCTN_ID = updates.PRGRM_INSTC_ID or target.PRGRM_INSTC_ID = updates.DATA_CLCTN_ID)
  when  matched and target.PRGRM_INSTC_ID = updates.DATA_CLCTN_ID then
  update
  set
    target.PRGRM_INSTC_ID = null,
    target.DATA_CLCTN_ID = updates.DATA_CLCTN_ID,
    target.CRNT_ENRLMNT_FLG = updates.CRNT_ENRLMNT_FLG,
    target.POLICY_KEY = updates.POLICY_KEY,
    target.POLICY_KEY_ID = updates.POLICY_KEY_ID,
    target.DEVC_ID = updates.DEVC_ID,
    target.ENRLMNT_EFCTV_DT = updates.ENRLMNT_EFCTV_DT,
    target.ENRLMNT_STRT_DT = updates.ENRLMNT_STRT_DT,
    target.ENRLMNT_END_DT = updates.ENRLMNT_END_DT,
    target.PLCY_ST_CD = updates.PLCY_ST_CD,
    target.SRC_SYS_CD = updates.SRC_SYS_CD,
    target.LOAD_DT = updates.LOAD_DT,
    target.LOAD_HR_TS = updates.LOAD_HR_TS,
    target.ETL_LAST_UPDT_DTS = current_timestamp()
  when matched and target.DATA_CLCTN_ID = updates.PRGRM_INSTC_ID then update set target.ETL_LAST_UPDT_DTS = current_timestamp()
  when matched
  and target.CRNT_ENRLMNT_FLG != updates.CRNT_ENRLMNT_FLG
  or target.ENRLMNT_STTS != updates.ENRLMNT_STTS then
  update
  set
    target.ETL_LAST_UPDT_DTS = current_timestamp(),
    target.ENRLMNT_STTS_CHNG_DT = current_date(),
    target.POLICY_KEY = updates.POLICY_KEY,
    target.POLICY_KEY_ID = updates.POLICY_KEY_ID,
    target.DEVC_ID = updates.DEVC_ID,
    target.ENRLMNT_STTS = updates.ENRLMNT_STTS,
    target.CRNT_ENRLMNT_FLG = updates.CRNT_ENRLMNT_FLG,
    target.PLCY_ST_CD = updates.PLCY_ST_CD,
    target.ENRLMNT_EFCTV_DT = updates.ENRLMNT_EFCTV_DT,
    target.ENRLMNT_STRT_DT = updates.ENRLMNT_STRT_DT,
    target.ENRLMNT_END_DT = updates.ENRLMNT_END_DT,
    target.SRC_SYS_CD = updates.SRC_SYS_CD
    when matched then
  update
  set
    target.POLICY_KEY = updates.POLICY_KEY,
    target.POLICY_KEY_ID = updates.POLICY_KEY_ID,
    target.DEVC_ID = updates.DEVC_ID,
    target.ENRLMNT_EFCTV_DT = updates.ENRLMNT_EFCTV_DT,
    target.ENRLMNT_STRT_DT = updates.ENRLMNT_STRT_DT,
    target.ENRLMNT_END_DT = updates.ENRLMNT_END_DT,
    target.PLCY_ST_CD = updates.PLCY_ST_CD,
    target.SRC_SYS_CD = updates.SRC_SYS_CD,
    target.LOAD_DT = updates.LOAD_DT,
    target.LOAD_HR_TS = updates.LOAD_HR_TS,
    target.ETL_LAST_UPDT_DTS = current_timestamp()
    when not matched then
  insert
    (
      INTEGRATED_ENROLLMENT_ID,
      CRNT_ENRLMNT_FLG,
      DATA_CLCTN_ID,
      DEVC_ID,
      ENRLMNT_EFCTV_DT,
      ENRLMNT_STRT_DT,
      ENRLMNT_END_DT,
      ENRLMNT_STTS,
      PRGRM_INSTC_ID,
      PLCY_ST_CD,
      POLICY_KEY,
      POLICY_KEY_ID,
      SRC_SYS_CD,
      VIN_NB,
      LOAD_DT,
      LOAD_HR_TS,
      ETL_ROW_EFF_DTS,
      ETL_LAST_UPDT_DTS,
      ENRLMNT_STTS_CHNG_DT
    )
  VALUES
    (
      updates.INTEGRATED_ENROLLMENT_ID,
      updates.CRNT_ENRLMNT_FLG,
      updates.DATA_CLCTN_ID,
      updates.DEVC_ID,
      updates.ENRLMNT_EFCTV_DT,
      updates.ENRLMNT_STRT_DT,
      updates.ENRLMNT_END_DT,
      updates.ENRLMNT_STTS,
      updates.PRGRM_INSTC_ID,
      updates.PLCY_ST_CD,
      updates.POLICY_KEY,
      updates.POLICY_KEY_ID,
      updates.SRC_SYS_CD,
      updates.VIN_NB,
      updates.LOAD_DT,
      updates.LOAD_HR_TS,
      updates.ETL_ROW_EFF_DTS,
      updates.ETL_LAST_UPDT_DTS,
      current_date()
    )""")
