# Databricks notebook source
# MAGIC %run ../../harmonization/_event_harmonizer_library

# COMMAND ----------

from datetime import datetime, timedelta,date
from pyspark.sql.functions import col

# COMMAND ----------

def type1_defaultMergePartitionied_RAZOR_REALTIME_IOT(df, target, merge_key1, merge_key2 , merge_key3):
  source_code = 'RAZOR_CL_PP'
  print("entering type1_defaultMergePartitionied_RAZOR_REALTIME_IOT")
  
#   merge_start_date= date.today() - timedelta(days=558)
  df_RAZOR=df.where(col("SRC_SYS_CD").like(f"{source_code}"))
  
  print("entering removeduplicates microbatch function \n")
#   partition_cols=merge_key.split(",")
  w = Window.partitionBy(merge_key1,merge_key2,merge_key3).orderBy(col("ETL_ROW_EFF_DTS").desc())
  firstRowDF_RAZOR = df_RAZOR.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print("leaving removeduplicates microbatch function")
  
  mb_trips_RAZOR=firstRowDF_RAZOR.select("trip_smry_key").distinct()
#   display(mb_trips)
  
  History_trips_RAZOR=spark.sql(f"select TripId,load_dt from dhf_iot_razor_raw_{environment}.trip_summary_realtime where load_dt >= add_months(load_dt,-18)")
  print("done")
  
  History_check_RAZOR=History_trips_RAZOR.join(mb_trips_RAZOR,History_trips_RAZOR["TripId"]==mb_trips_RAZOR["trip_smry_key"],"inner").select(History_trips_RAZOR["*"])
  
  History_dates_RAZOR=*([row[0] for row in History_check_RAZOR.selectExpr('cast(load_dt as string)').distinct().collect()]),'0','1'
  print(History_dates_RAZOR)

  firstRowDF_RAZOR.createOrReplaceGlobalTempView("History_view_RAZOR")
#   display(History_check)
  
#   History_df=firsRowDF.join(History_check,firsRowDF["trip_smry_key"]==History_check["tripsummaryid"],"inner").select(firsRowDF["*"])
#   History_df.createOrReplaceGlobalTempView("History_view")
#   display(History_df)
  
#   non_History_df=firsRowDF.join(History_check,firsRowDF["trip_smry_key"]==History_check["tripsummaryid"],"anti").select(firsRowDF["*"])
#   non_History_df.createOrReplaceGlobalTempView("Non_History_view")
#   display(non_History_df)
  
#   if History_df.count():
  print("history")
  
  spark.sql(f"""merge into {target} target using (select  * from global_temp.History_view_RAZOR) updates on target.{merge_key1} = updates.{merge_key1} and target.{merge_key2} = updates.{merge_key2} and target.{merge_key3} = updates.{merge_key3} and target.SRC_SYS_CD = '{source_code}' and target.LOAD_DT in {History_dates_RAZOR}   when matched then update set * when not matched then insert *""")
    
#   if non_History_df.count():
#     print("non_history")
#     spark.sql(f"""merge into {target} target using (select distinct * from global_temp.Non_History_view) updates on target.{merge_key1} = updates.{merge_key1} and target.{merge_key2} = updates.{merge_key2} and target.SRC_SYS_CD = 'IMS_SM_5X' and target.LOAD_DT >= DATE(updates.LOAD_DT)-1 when matched then update set * when not matched then insert *""")
  
#   match_condition = " AND ".join(list(map((lambda x: f"trg.{x.strip()}=src.{x.strip()}"),merge_key.split(",")))) + f" AND trg.SRC_SYS_CD='IMS_SM_5X'" + f" AND trg.load_dt >= '{merge_start_date}'"
  
#   delta_table=DeltaTable.forName(spark, target)
#   delta_table.alias("trg").merge(firsRowDF.alias("src"),match_condition).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
  
  print("end of type1_defaultMergePartitionied_DHFGeneric function")

# COMMAND ----------

def razor_realtime_trip_point_iot(microBatchDF, batchId, rawDB, harmonizedDB, target):
  print("\n entering razor_realtime_trip_point_iot \n")
  
  harmonized_table = harmonizedDB +"."+target
  
  type1_defaultMergePartitionied_RAZOR_REALTIME_IOT(microBatchDF,harmonized_table,"TRIP_SMRY_KEY","UTC_TS","IGNTN_EVNT_CD")
