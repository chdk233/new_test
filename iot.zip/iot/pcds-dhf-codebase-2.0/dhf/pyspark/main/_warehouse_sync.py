# Databricks notebook source
from pyspark.context import SparkContext
from pyspark.sql import DataFrame
from pyspark.sql import functions
from pyspark.sql import types
import pyspark.sql
from datetime import datetime
from pyspark.sql.streaming import DataStreamWriter
from pyspark.dbutils import DBUtils
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import *


#spark._jvm.net.snowflake.spark.snowflake.SnowflakeConnectorUtils.enablePushdownSession(spark._jvm.org.apache.spark.sql.SparkSession.builder().getOrCreate())
#snowflake_source_name = 'net.snowflake.spark.snowflake'
#print(snowflake_source_name)

def pyRunQuery(options, query):
  spark._jvm.net.snowflake.spark.snowflake.Utils.runQuery(options, query)

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text( "groupId", "1", "GroupID")
dbutils.widgets.text( "environment", "dev", "environment") 
dbutils.widgets.text( "metricsLogTable", "", "metricsLogTable")

groupId=int(str(dbutils.widgets.get("groupId")))
environment=str(dbutils.widgets.get("environment"))
metricsLogTable=str(dbutils.widgets.get("metricsLogTable"))

print("GroupId in notebook is : " ,groupId)
print("environment in notebook is : " ,environment) 
print("metricsLogTable in notebook is : ",metricsLogTable)
readtablefromdate=""

# COMMAND ----------

# MAGIC %run ../utils/_utils

# COMMAND ----------

# DBTITLE 1,Global Variables for External Orchestration #QM
failed_tasks_list = []
task_queryid_dict = {}

# COMMAND ----------


warehouseGroup = getGroup(groupId)
runType        = warehouseGroup["run_type"]
job_type       = warehouseGroup["job_type"]

# COMMAND ----------

class DeltaHandlerClass:
    def __init__(self,sf_sync_key,sf_vwarehouse_warehouse_sync,sf_database_warehouse_sync, sf_schemaname_warehouse_sync,sf_tablename_warehouse_sync,sourceDB,source,target,sfUser,sfPassword,sfURL,taskId,job_type,job_name,run_type, minThreshold, maxThreshold, sfType1Merge, sfType1OrderCol, maxBytesPerTrigger, email_list,user_properties,servicenow_property,is_decryptdata,decryptColumns,secretKey):
      self.sf_sync_key = sf_sync_key
      self.sf_vwarehouse_warehouse_sync = sf_vwarehouse_warehouse_sync
      self.sf_database_warehouse_sync = sf_database_warehouse_sync
      self. sf_schemaname_warehouse_sync = sf_schemaname_warehouse_sync
      self.sf_tablename_warehouse_sync = sf_tablename_warehouse_sync
      self.sourceDB = sourceDB
      self.source = source
      self.target = target
      self.sfUser = sfUser
      self.sfPassword = sfPassword
      self.sfURL = sfURL
      self.taskId = taskId
      self.job_type = job_type
      self.job_name = job_name
      self.run_type = run_type
      self.minThreshold = minThreshold
      self.maxThreshold = maxThreshold
      self.sfType1Merge = sfType1Merge
      self.sfType1OrderCol = sfType1OrderCol
      self.maxBytesPerTrigger = maxBytesPerTrigger
      self.email_list = email_list
      self.user_properties = user_properties
      self.servicenow_property = servicenow_property
      self.is_decryptdata=is_decryptdata
      self.decryptColumns=decryptColumns
      self.secretKey=secretKey
  
        
    def handleMicroBatch(self,microBatchDF,batchId):
      sf_sync_key = self.sf_sync_key
      sf_vwarehouse_warehouse_sync = self.sf_vwarehouse_warehouse_sync
      sf_database_warehouse_sync = self.sf_database_warehouse_sync
      sf_schemaname_warehouse_sync = self.sf_schemaname_warehouse_sync
      sf_tablename_warehouse_sync = self.sf_tablename_warehouse_sync
      sourceDB = self.sourceDB
      source = self.source
      target = self.target
      sfUser = self.sfUser
      sfPassword = self.sfPassword
      sfURL = self.sfURL
      taskId = self.taskId
      job_type = self.job_type
      job_name = self.job_name
      run_type = self.run_type
      minThreshold = self.minThreshold
      maxThreshold = self.maxThreshold
      sfType1Merge = self.sfType1Merge
      sfType1OrderCol = self.sfType1OrderCol
      maxBytesPerTrigger = self.maxBytesPerTrigger
      email_list = self.email_list
      user_properties = self.user_properties
      servicenow_property = self.servicenow_property
      is_decryptdata = self.is_decryptdata
      decryptColumns = self.decryptColumns
      secretKey = self.secretKey

      ##added for snowprop
      servicenow_property = servicenow_property if servicenow_property is None else servicenow_property.strip()
      if servicenow_property:
        snow_property = servicenow_property
      else:
        snow_property = user_properties
      ##added for snowprop
      
      options = {"sfURL":sfURL,"sfUser":sfUser,"sfPassword":sfPassword,"sfDatabase":sf_database_warehouse_sync,"sfSchema":sf_schemaname_warehouse_sync,"sfWarehouse":sf_vwarehouse_warehouse_sync}
      try:
        start = datetime.now()
        min_Threshold = minThreshold
        max_Threshold = maxThreshold
        batchSize = microBatchDF.count()
        print(f"batchSize :{batchSize} for {sf_tablename_warehouse_sync}, batchId {batchId}")
        print(f"microBatchDF...in microbatch handler: \n")
        
        microBatchDF.show()
        if(batchSize>=1):
            if is_decryptdata:
              microBatchDF=decryptDataframe(microBatchDF,decryptColumns,secretKey) #decrypt if needed
            allCols=microBatchDF.columns
            allCols=[x.lower() for x in allCols]
            sf_key = sf_sync_key if (sf_sync_key != "") else f"{source}_ID"
            if(len(sf_key.strip()) == 0):
              failMsf = f"Error: No snowflake sync key is specified. Either your harmonized table should have a column called {source}_ID, or you should provide a 'sf_sync_key' from configuration. Exiting microbatch handler for {sf_tablename_warehouse_sync}, batchId {batchId}" 
              raise Exception(failMsf)
            else:
              finalDF = microBatchDF
              if sfType1Merge:
                cols = sf_key.split(",")
                if(True if ((sfType1OrderCol==None) or (len(sfType1OrderCol) == 0)) else False):
                  w =  Window.partitionBy(*cols).orderBy(col("_commit_version").desc())
                  finalDF = microBatchDF.filter((col("_change_type") == "insert") | (col('_change_type') == "update_postimage")).withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum").drop("_change_type").drop("_commit_version").drop("_commit_timestamp")
                else:
                  cols = sf_key.split(",")
                  w =  Window.partitionBy(*cols).orderBy(col(f"{sfType1OrderCol}").desc()) #modified the order by column for type1
                  finalDF = microBatchDF.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
              finalDF.show()
              allCols=finalDF.columns
              allCols=[i.lower().strip() for i in allCols]
              targetAlias = "tgt"
              updatesAlias = "stg"

              #added lines to form join conditions from sf_key
              sfCols= sf_key.split(',')
              sfCols=[i.lower().strip() for i in sfCols]
              join_sf_key_val=''
              for vl in sfCols:
                join_sf_key_val=join_sf_key_val+" AND "+targetAlias+"."+vl+  "=" + updatesAlias+"."+vl
              join_sf_key=join_sf_key_val[5:]
              print(f"Column used for Snowflake Sync Merge is: {sf_key}")
              updateCols_val=''
              insertValues_val=''
              for vl in allCols:
                updateCols_val=updateCols_val+", "+targetAlias+"."+vl+  "=" + updatesAlias+"."+vl
                insertValues_val=insertValues_val+", "+ updatesAlias+"."+vl
              updateCols=updateCols_val[2:]
              insertValues=insertValues_val[2:]
              print(f"stg_{sf_tablename_warehouse_sync}")
              finalDF.write.format("snowflake").options(**options).option("dbtable", f"stg_{sf_tablename_warehouse_sync}").mode("overwrite").save()
                #modified the ON condition
              mergeQuery = f'''MERGE INTO {sf_tablename_warehouse_sync} tgt USING stg_{sf_tablename_warehouse_sync} stg ON {join_sf_key} WHEN MATCHED THEN UPDATE SET {updateCols} WHEN NOT MATCHED THEN INSERT ({",".join(allCols)}) VALUES ({insertValues})'''

              print(f"mergeQuery: {mergeQuery}")
              pyRunQuery(options,mergeQuery)
              print("merge completed")
        else:
          print(f"NO DATA in microbatch for  {sf_tablename_warehouse_sync}, batchId {batchId}")
          
        totalTimeBatchMin  = int((datetime.now()-start).total_seconds()/60)
        print(f"Total batch time for {sf_tablename_warehouse_sync}, batchId {batchId} is: {totalTimeBatchMin} min")
        warehousePersistLog([[str(groupId), str(jobId), job_type, run_type, runId, batchId, batchSize, str(totalTimeBatchMin), str(start), taskId, source, target, clusterId]], metricsLogTable) 
        sendToSplunk(str(groupId), jobId, job_name, "WAREHOUSE_SYNC", run_type, runId, batchId, batchSize, str(start),str(totalTimeBatchMin) ,0,taskId, source, target, clusterId,"Success")
        if(totalTimeBatchMin > minThreshold):
            if(totalTimeBatchMin > maxThreshold):
              print("Max Threshold Breached. Generating snow ticket and Sending Email..")
              errorHandler("maxThreshold",job_name,groupId,jobId,job_type,runId,batchId,max_Threshold,min_Threshold,str(totalTimeBatchMin),0,taskId,"NA", email_list,snow_property,metricsLogTable)
            else:
              print("Min Threshold hold breached. sending email...")
              errorHandler("minThreshold",job_name,groupId,jobId,job_type,runId,batchId,max_Threshold,min_Threshold,str(totalTimeBatchMin),0,taskId,"NA", email_list,snow_property,metricsLogTable)
                
      except Exception as e :
        failed_tasks_list.append(taskId)  #jobOrch
        persistLog_external([[taskId,"WAREHOUSE_SYNC",runId,"Failed",datetime.now().date(),datetime.now()]], metricsLogTable) #jobOrch 
        print(f"MERGE FAILED for Warehouse table: {target}, batchId {batchId}" , e)
        sendToSplunk(str(groupId), jobId, job_name, "WAREHOUSE_SYNC", run_type, runId, batchId, 0, str(datetime.now()), "0", 0, taskId, source, target, clusterId, "Failed")
        errorHandler("exception",job_name,groupId,jobId,job_type,runId, batchId,0,0,"0",0,taskId,str(e).replace("\n", " "), email_list,snow_property,metricsLogTable)
        raise Exception(f'MERGE FAILED for target: {target} for batchId {batchId}',e)

# COMMAND ----------

# DBTITLE 1,DBTITLE 1,Define streaming main method
def startWarehouseSyncStreamingMain( groupId, runType, job_type, environment):
  global task_queryid_dict
  warehouseTaskList     = getWarehouseTaskList(groupId)
  if not warehouseTaskList:
    raise Exception(f"No GroupID found for the given group_id {groupId}. Please check the warehouse task config table")
  for warehouse in warehouseTaskList:
    print(f"warehouse is **{warehouse}**")
    property_values = getConfig(warehouse["data_domain_id"])
    secret_scope = getPropertyValue("secret_scope", property_values)
    secret_sf_user = getPropertyValue("secret_sf_user", property_values)
    secret_sf_password = getPropertyValue("secret_sf_password", property_values)
    sfURL = getPropertyValue("sf_url", property_values)
    sfUser = dbutils.secrets.get(scope = secret_scope, key = secret_sf_user)
    sfPassword = dbutils.secrets.get(scope = secret_scope, key = secret_sf_password)
    
    taskId         =  warehouse["id"]
    source           = warehouse["source_table"]
    target           = warehouse["sf_table"]
    minThreshold     = warehouse["min_threshold"]
    maxThreshold     = warehouse["max_threshold"]     
    
    sf_sync_key                  = warehouse["sf_key"].replace(" ", "") if warehouse["sf_key"] else ""
    sf_vwarehouse_warehouse_sync = warehouse["sf_warehouse"].replace(" ", "")
    sf_database_warehouse_sync   = warehouse["sf_database"].replace(" ", "")
    sf_schemaname_warehouse_sync = warehouse["sf_schema"].replace(" ", "")
    sf_tablename_warehouse_sync  = warehouse["sf_table"].replace(" ", "")
    sourceDB                     = warehouse["source_db"].replace(" ", "")
    
    is_decryptdata               = warehouse["decrypt_data"]#sensitive columns-decrypt
    secretKey                    = getSecretKey(warehouse["secret_key_details"])
    if is_decryptdata:
      decryptColumns               = warehouse["decrypt_columns"]
      if (secretKey==None or (decryptColumns==None or len(decryptColumns)==0) ):
        raise Exception("Decrypt data flag is enabled but Secret Key details or list of columns that needs to be decrypted are not provided ")
    
#     job_name                     = "DEV_DHF_WAREHOUSE"
    sfType1Merge = warehouse["sfmerge_type_1"]
    sfType1OrderCol =  warehouse["sftype_1_order_by_column"] if warehouse["sftype_1_order_by_column"]==None  else warehouse["sftype_1_order_by_column"].strip()
    maxBytesPerTrigger = warehouse["max_bytes_per_trigger"]
    email_list = warehouse["email_list"] 
    user_properties = warehouse["user_properties"]
    servicenow_property = warehouse["servicenow_property"]
    replay_flag=warehouse["replay"]
    
    print(f"sfURL is **{sfURL}**")
    print(f"sfUser is **{sfUser}**")
    print(f"sf_sync_key is **{sf_sync_key}**")
    print(f"sf_vwarehouse_warehouse_sync is **{sf_vwarehouse_warehouse_sync}**")
    print(f"sf_database_warehouse_sync is **{sf_database_warehouse_sync}**")
    print(f"sf_schemaname_warehouse_sync is **{sf_schemaname_warehouse_sync}**")
    print(f"sf_tablename_warehouse_sync is **{sf_tablename_warehouse_sync}**")
    print(f"sourceDB is : {sourceDB}")
    checkpoint_dir = getCheckpoint(warehouse['data_domain_id'])  #CheckpointManagement
    if checkpoint_dir[-1] == "/": #CheckpointManagement
      checkpoint_dir = checkpoint_dir[:-1] #CheckpointManagement
    checkPoint = checkpoint_dir  + "/warehousesync/" + str(taskId) + "/" + source + "/cp001" #CheckpointManagement
    print(f"checkPoint is {checkPoint}")
    deltahandler = DeltaHandlerClass(sf_sync_key,sf_vwarehouse_warehouse_sync,sf_database_warehouse_sync, sf_schemaname_warehouse_sync, sf_tablename_warehouse_sync, sourceDB, source, target, sfUser, sfPassword, sfURL, taskId, job_type, job_name, runType,minThreshold,maxThreshold,sfType1Merge,sfType1OrderCol,maxBytesPerTrigger,email_list,user_properties,servicenow_property,is_decryptdata,warehouse["decrypt_columns"],secretKey)
    readStream = spark.readStream.option("ignoreChanges", True).option("maxBytesPerTrigger", maxBytesPerTrigger)

    if (sfType1Merge and (True if ((sfType1OrderCol==None) or (len(sfType1OrderCol) == 0)) else False)):
      readStream = readStream.option("readChangeFeed", "true")
    if(replay_flag==True):
      replay_columns=warehouse["replaydatecolumn"]
      if(not(replay_columns)):
        e=f"You have enabled Replay Flag to True for the task {taskId} but you haven't provided value in UI \n!!!!! Please provide value UI!!!!!"

        ##added for snowprop
        servicenow_property = servicenow_property if servicenow_property is None else servicenow_property.strip()
        if servicenow_property:
          snow_property = servicenow_property
        else:
          snow_property = user_properties
        ##added for snowprop

        errorHandler("exception",job_name,groupId,jobId,job_type,runId, 0,0,0,"0",0,taskId,str(e).replace("\n", " "), email_list,snow_property,metricsLogTable)
        raise Exception(f"You have enabled Replay Flag to True for the task {taskId} but you haven't provided ReplayDateColumn value in UI")
      else:
        streamingDF = replay_warehouse_sync(replay_columns,warehouse,maxBytesPerTrigger,checkpoint_dir)
    else:
      streamingDF = readStream.format("delta").table(f"{sourceDB}.{source}") 

    if (not(readtablefromdate == None or len(readtablefromdate)==0)):
      print("in empty readtablefromdate")
      streamingDF = streamingDF.filter(col("updatetime") >= readtablefromdate)

    streamQuery = streamingDF.writeStream.foreachBatch(deltahandler.handleMicroBatch).option("checkpointLocation", checkPoint).option("queryName", source+"_"+str(taskId))

    if (runType == "AVAILABLE_NOW"):
      streamQuery = streamQuery.trigger(availableNow=True).option("maxBytesPerTrigger", maxBytesPerTrigger)

    q = streamQuery.start()
    task_queryid_dict[taskId] = q.id #jobOrch
    
  if(runType == "AVAILABLE_NOW"): #this entire block is for #jobOrch
    print("--- entering query monitor logic ---")
    taskList_log = [_["id"] for _ in warehouseTaskList if _["id"] not in failed_tasks_list]
    print(f"taskGroupList_log: {taskList_log}") #done

    while(len(taskList_log) != 0):

      for task in list(taskList_log):
        if (task_queryid_dict[task] not in [_.id for _ in spark.streams.active]) and (task not in failed_tasks_list):
          persistLog_external([[task,"WAREHOUSE_SYNC",runId,"Success",datetime.now().date(),datetime.now()]], metricsLogTable) #jobOrch
          print(f"{task} is added as success in log table, same will be removed from current loop")
          taskList_log.remove(task)
        elif task in failed_tasks_list:
          print(f"taskgroup{task} was added to failed list, failure log will be pushed to log table, taskgroup will be removed from current loop")
          taskList_log.remove(task)


# COMMAND ----------

startWarehouseSyncStreamingMain(groupId,runType,job_type,environment)

# COMMAND ----------


