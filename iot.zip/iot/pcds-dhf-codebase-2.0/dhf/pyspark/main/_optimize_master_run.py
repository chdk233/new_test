# Databricks notebook source
import pyspark.sql 
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import *
import io
import re
import json
from itertools import groupby
import pytz
from operator import itemgetter
import io
import zipfile
import pandas as pd
from pyspark.sql.types import *
import json
import boto3
import time
import ast
from datetime import datetime
import time
from pyspark.sql import functions as f
from pyspark.sql.session import SparkSession
from pyspark.sql import DataFrame
from dataclasses import dataclass

# COMMAND ----------

dbutils.widgets.removeAll()
# dbutils.widgets.dropdown("environment", "dev", Seq("dev", "test","prod"), "environment")
dbutils.widgets.text( "group_id", "", "group_id")

# val environment=dbutils.widgets.get("environment").toString
groupId=str(dbutils.widgets.get("group_id")).strip()

dbutils.widgets.text( "domainName", "", "domain_name")
domainName = str(dbutils.widgets.get("domainName")).strip()
print(domainName)

# COMMAND ----------

browserHostName = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()).get('tags', {}).get('browserHostName', None) 
environment =""

if("-dev-" in browserHostName):
  environment="dev"
  print("environment is set to : " + environment)  
elif("-test-" in browserHostName):
  environment="test"
  print("environment is set to : " + environment)
elif("-prod-" in browserHostName):
  environment="prod"
  print("environment is set to : " + environment)

# COMMAND ----------

# MAGIC %run ../utils/_utils

# COMMAND ----------

jobExists= False
jobid=0
currentNotebook = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()).get('extraContext', {}).get('notebook_path', None)
notebookPath=currentNotebook.replace("_optimize_master_run","_event_optimization")
clusterId= json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()).get('tags', {}).get('clusterId', None)
assumeRole = ""
iamRole = ""
passed_jobs_list, failed_jobs_list = [],[]
groupIdDict = getGroup(groupId)
domain_level_user_properties = groupIdDict['domain_userproperty']

awsInstProfile = getUserPropertyValue('insta_profile',domain_level_user_properties) #Instance profile
print("Passed AWS Instance Profile:", awsInstProfile)

if awsInstProfile != None and len(awsInstProfile.strip()) != 0:
  iamRole = awsInstProfile
  assumeRole = "arn:aws:iam::786994105833:role/pcds-databricks-common-access" #we need to check in future for the value
  
  jobLogTable = f"dhf_logs_dh_{domainName}_{environment}.dhf_delta_optimize_metrics_log"
  jobStatusLog= f"dhf_logs_dh_{domainName}_{environment}.dhf_delta_optimize_job_creation_log"
else:
  jobLogTable = f"dhf_logs_{environment}.dhf_delta_optimize_metrics_log"
  jobStatusLog= f"dhf_logs_{environment}.dhf_delta_optimize_job_creation_log"

  if(environment == "dev"):
    iamRole = "arn:aws:iam::786994105833:instance-profile/pcds-hrmonzpoc-devdw01-trustingrole"  
    assumeRole = "arn:aws:iam::786994105833:role/pcds-databricks-common-access"
  elif(environment == "test"):
    iamRole = "arn:aws:iam::168341759447:instance-profile/pcds-hrmonzpoc-testdw01-trustingrole"
    assumeRole = "arn:aws:iam::168341759447:role/pcds-databricks-common-access" 
  elif(environment == "prod"):
    iamRole = "arn:aws:iam::785562577411:instance-profile/pcds-hrmonzpoc-proddw01-trustingrole"
    assumeRole = "arn:aws:iam::785562577411:role/pcds-databricks-common-access" 

# COMMAND ----------

log_schema=StructType([StructField("job_id",LongType(),True),StructField("group_id",LongType(),True),StructField("job_name",StringType(),True), StructField("run_id",LongType(),True), StructField("start_time",StringType(),True), StructField("end_time",StringType(),True),StructField("status",StringType(),True)])

def persistLog(jobMetrics,logTable):
  df = spark.createDataFrame(jobMetrics,log_schema).coalesce(1)
  df.write.format("delta").mode("append").saveAsTable(f"{logTable}")


# COMMAND ----------

def validateJobId(jobid,group_id):
  global jobExists
  print(f"In validateJobId function")
  resp = requests.get(f'{dbhost}/api/2.1/jobs/get?job_id={jobid}',headers={'Authorization' : f'Bearer {token}','X-Databricks-Org-Id' : f'{workspaceID}'})
  if("INVALID_PARAMETER_VALUE" in resp):
    msg=f"""Invalid job ID in dhf_delta_optimize_job_log table for groupId: {group_id}. Please correct/delete the job ID in job_creation_log table and resubmit"""
    print(msg)
    raise Exception(msg)
  else:
    print(f"Job id is valid for groupId: {group_id}")
    jobExists= True
    

# COMMAND ----------

def checkIfRunningOrPendingStatus(jobid,group_id):  
  print(f"In checkIfRunningOrPendingStatus function")
  runningStateArray = [_ for _ in set([_['state']['life_cycle_state'] for _ in (requests.get(f'{dbhost}/api/2.0/jobs/runs/list?job_id={jobid}',headers={'Authorization' : f'Bearer {token}','X-Databricks-Org-Id' : f'{workspaceID}'})).json()['runs'] if _['state']['life_cycle_state'] in ('RUNNING','PENDING')])]
  
  if len(runningStateArray) >= 1:
    print(f"group_id: {group_id} :: Job associated is already in either RUNNING or PENDING status")
    return True
  
  else:
    print(f"group_id: {group_id} :: The job is NOT in RUNNING or PENDING state. Run-now will be invoked")
    return False

# COMMAND ----------

def fetchOptimizeConfigGroupId():
  print(F"In fetchOptimizeConfigTables function")
  whereCond =  f"WHERE active and job_type=\'DELTA_OPTIMIZATION\' "+f" and Id IN ({groupId}) " if(groupId)  else "WHERE active and job_type=\'DELTA_OPTIMIZATION\' "
  pushdown_query = f"(SELECT distinct(Id),name  FROM job_group_new_msapps {whereCond} ) t "
  print(pushdown_query)
  df=spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  groupList=list(map(lambda row:row.asDict(),df.collect()))
  print(groupList)
  return groupList

# COMMAND ----------

def isEmptyList(tableGroupIdList):
  if(len(tableGroupIdList)==0):
    print("table group Id list is empty: ")
    return False
  else:
    return True

# COMMAND ----------

def createJobAndRun(groupId, jobName):
  global jobExists         
  groupIdObj = getGroup(groupId)
  print("getGroupId function call completed")
  numWorkers = getPropertyValue("numWorkers", groupIdObj["cluster_config"])  
  sparkVersion = getPropertyValue("sparkVersion", groupIdObj["cluster_config"]) 

  print(f"numWorkers is {numWorkers}")
  print(f"sparkVersion is {sparkVersion}")
  print(f"notebookPath is {notebookPath}")
           
  currentDate = str(datetime.now().strftime('%Y-%m-%d'))
  print(f"currentDate is {currentDate}")
  pushdown_query_for_job = f""" SELECT job_id FROM  {jobStatusLog} WHERE group_id={groupId} limit 1 """
  
  jobidArray = spark.sql(pushdown_query_for_job).collect() 
  if(len(jobidArray) == 1):
    print(f"Job ID exists for group Id {groupId}")
    jobid=jobidArray[0][0]
    validateJobId(jobid,groupId)
  else:
    jobExists=False
    jobid=0
    print(f"GroupId: {groupId} :: Job ID does not exist. New job will be created")
    
  runningOrPendingStatus=checkIfRunningOrPendingStatus(jobid,groupId) if(jobExists) else False
  try:
    if(jobExists and not(runningOrPendingStatus)):
      print("Im here1")
      jsonForExistingJobid = {
                     "job_id": f"{jobid}"
                  }
      runid = (requests.post(f'{dbhost}/api/2.0/jobs/run-now',headers={'Authorization' : f'Bearer {token}','X-Databricks-Org-Id' : f'{workspaceID}'},json=jsonForExistingJobid)).json()['run_id'] 

      UTC = pytz.utc
      datetime_utc = datetime.now(UTC)
      startTime = str(datetime_utc.strftime("%a %b %d %I:%M:%S %Z %Y"))
      data=[[int(jobid),int(groupId),jobName,int(runid),startTime,"","Running"]]
      logDF=spark.createDataFrame(data,log_schema)
      logDF.coalesce(1).write.format("delta").mode("append").saveAsTable(jobStatusLog)
      print(f"runid is {runid} for jobid {jobid} : jobName: {jobName}")

    elif(not(jobExists)):
      print(f"Creating new job -- {jobName} ")
      jsonForNewJobApi = {
                "name": f"{jobName}",
                "new_cluster": {
                        "spark_version": f"{sparkVersion}",
                        "node_type_id": "i3.xlarge",
                        "driver_node_type_id": "i3.xlarge",
                        "num_workers": f"{numWorkers}",
                        "aws_attributes": {
                                "first_on_demand": 1,
                                "availability": "SPOT_WITH_FALLBACK",
                                "zone_id": "auto",
                                "instance_profile_arn": f"{iamRole}",
                                "spot_bid_price_percent": 100,
                                "ebs_volume_type": "GENERAL_PURPOSE_SSD",
                                "ebs_volume_count": 3,
                                "ebs_volume_size": 100                 
                        },

                        "init_scripts": [],
                        "custom_tags": {
                                 "APRMID" : "8475",
                                 "ResourceOwner" : "dhfsid@nationwide.com",
                                 "Created" : f"{currentDate}",
                                 "Patch" : "False", 
                                 "PowerOnInstanceAt" : "False",
                                 "ShutDownInstanceAt" : "False",
                                 "DisbursementCode" : "303500001",
                                 "SecurityException" : "n/a",
                                 "ResourceName" : "DHF Job Optimization Cluster",
                                 "DataClassification" : "public",
                                 "Project" : "Data Harmonization Framework",
                                 "Alert" : "False",
                                 "Team" : "PnC Data Platform"
                        },
                        "cluster_log_conf": {
                           "dbfs": {
                                "destination": "dbfs:/cluster-logs"
                          }
                        },                          
                        "spark_env_vars": {
                                "AWS_STS_REGIONAL_ENDPOINTS": "\\\"regional\\\""
                        }
                 },

                 "notebook_task": {
                        "base_parameters": {
                                          "groupId": f"{groupId}",
                                          "jobName": f"{jobName}",
                                          "environment": f"{environment}",
                                          "jobLogTable": f"{jobLogTable}",
                                          "jobStatusLog": f"{jobStatusLog}",           
                                          "environment": f"{environment}"
                                          },
                        "notebook_path": f"{notebookPath}"
                 }, 

                 "email_notifications": {
                        "on_start": [],
                        "on_success": [],
                        "on_failure": []
                 },          
                 "max_retries": 1

                }
      print(f"jsonForNewJobApi is {jsonForNewJobApi}")  
      api_out = (requests.post(f'{dbhost}/api/2.0/jobs/create',headers={'Authorization' : f'Bearer {token}','X-Databricks-Org-Id' : f'{workspaceID}'},json=jsonForNewJobApi)).json()
      print(f"Jobs API Output: ")
      print(api_out)
      if (not("error_code" in api_out)):
        newJobId = api_out['job_id']
        print(f"JobId {newJobId} created for  jobName: {jobName}")
        jsonForRunNow = {
                         "job_id": f"{newJobId}"
                        }
        jsonForPermissionApi = {  
                                           "access_control_list": [
                                                {
                                                    "group_name":"PCDS_Admin",
                                                    "permission_level":"CAN_MANAGE"
                                                },
                                                {
                                                    "group_name":"PCDS_Arch",
                                                    "permission_level":"CAN_VIEW"
                                                },
                                                {
                                                    "group_name":f"PCDS_{environment}",
                                                    "permission_level":"CAN_MANAGE"
                                                }
                                             ]
                                          }
        requests.patch(f'{dbhost}/api/2.0/permissions/jobs/{newJobId}',headers={'Authorization' : f'Bearer {token}','X-Databricks-Org-Id' : f'{workspaceID}'},json=jsonForPermissionApi)
        runid = (requests.post(f'{dbhost}/api/2.0/jobs/run-now',headers={'Authorization' : f'Bearer {token}','X-Databricks-Org-Id' : f'{workspaceID}'},json=jsonForRunNow)).json()['run_id']
        UTC = pytz.utc
        datetime_utc = datetime.now(UTC)
        startTime = str(datetime_utc.strftime("%a %b %d %I:%M:%S %Z %Y"))
        data=[[int(newJobId),int(groupId),jobName,int(runid),startTime,"","Running"]]
        logDF=spark.createDataFrame(data,log_schema)
        logDF.coalesce(1).write.format("delta").mode("append").saveAsTable(jobStatusLog)
        print(f"runid is {runid} for jobid {newJobId} : jobName: {jobName}")
        passed_jobs_list.append(f"jobName: {jobName},  job_response: {api_out}")
      else:
        msg=f"""Error while creating job for jobName: {jobName}"""
        print(msg + api_out)  
        failed_jobs_list.append(f"jobName: {jobName},  job_response: {api_out}")
  except Exception as e:
    print(f"Error in invoking job api for jobName - {jobName}: " , e) 
    raise Exception(f"Error in invoking job api for jobName {jobName} :  {e}")

# COMMAND ----------

def masterMain(environment):
  currentDate = str(datetime.now().strftime('%Y-%m-%d'))
  tableGroupIdList = fetchOptimizeConfigGroupId()
  print(f"groupIdList is {tableGroupIdList}")
  if len(tableGroupIdList) > 0:
    for groupList in tableGroupIdList:
      try:
        createJobAndRun(groupList['id'],f"{environment}_DHF_DO_{groupList['name']}_{groupList['id']}".upper())
      except Exception as e:   
        print(f"Error while creating job for group_id : {e}")
        raise Exception(f"Error while creating job for group_id :{e}")
  else:
    print("There is no group id available in config table")


# COMMAND ----------

masterMain(environment)

# COMMAND ----------

print("passed_jobs_list::",passed_jobs_list)
print("failed_jobs_list::",failed_jobs_list)
