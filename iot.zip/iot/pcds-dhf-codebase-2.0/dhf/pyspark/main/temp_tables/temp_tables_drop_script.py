# Databricks notebook source
dbutils.widgets.removeAll()
dbutils.widgets.text( "temp_group_id", "", "1. Temp_Tables_Job_temp_group_id")
dbutils.widgets.text("environment", "dev", "environment")
dbutils.widgets.text("metricsLogTable", "", "metricsLogTable")
dbutils.widgets.text("domain_email_dl", "", "domain_email_dl")

temp_group_id=str(dbutils.widgets.get("temp_group_id")).strip()
environment = dbutils.widgets.get("environment")
metricsLogTable = dbutils.widgets.get("metricsLogTable")
domain_email_dl = dbutils.widgets.get("domain_email_dl")

print("temp_group_id:",temp_group_id)
print("environment in notebook is : " + environment)
print("metricsLogTable in notebook is : " + metricsLogTable)
print("domain_email_dl in notebook is : " + domain_email_dl)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Including Utils Notebook

# COMMAND ----------

# MAGIC %run ../../utils/_utils

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fetching job properties

# COMMAND ----------

context=json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
job_id=context.get('tags', {}).get('jobId', 0) 
run_id_obj = context.get('currentRunId', {})
run_id = run_id_obj.get('id', None) if run_id_obj else None 
cluster_id=context.get('tags', {}).get('clusterId', None)
workspace_id=json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()).get('tags', {}).get('orgId', None)
job_url = f"https://nationwide-pcds-{environment}-virginia.cloud.databricks.com/?o={workspace_id}#job/{job_id}"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop Temp Tables

# COMMAND ----------

def drop_temp_tables(temp_task,metricsLogTable):
  return_list = []
  for src_table in [_.strip() for _ in temp_task["source_table_names"].split(',')]:

    try:

      print(f'attempting to drop table: {temp_task["temp_database_name"]}.{src_table}')
      spark.sql(f'drop table {temp_task["temp_database_name"]}.{src_table}')
      print(f'{temp_task["temp_database_name"]}.{src_table} is dropped')
      persistLog_temp([[temp_task['temp_group_id'],temp_task['id'],f'{temp_task["temp_database_name"]}.{src_table}','DROP_Table',job_id,run_id,"Success",datetime.now().date(),datetime.now()]],metricsLogTable)
      return_list.append({
        'temp_table' : f'{temp_task["temp_database_name"]}.{src_table}',
        'temp_db' : f'{temp_task["temp_database_name"]}',
      'status' : True,
      'error' : ''
      })
    
  
    except Exception as e:
      persistLog_temp([[temp_task['temp_group_id'],temp_task['id'],f'{temp_task["temp_database_name"]}.{src_table}','DROP_Table',job_id,run_id,"Failed",datetime.now().date(),datetime.now()]],metricsLogTable)
      return_list.append({
        'temp_table' : f'{temp_task["temp_database_name"]}.{src_table}',
        'temp_db' : f'{temp_task["temp_database_name"]}',
      'status' : False,
      'error' : str(e)
      })

  return return_list

  

# COMMAND ----------

# MAGIC %md
# MAGIC ###Drop Temp DB

# COMMAND ----------

def drop_temp_db(temp_database_name,metricsLogTable):
  return_list = []
  try:

      print(f'attempting to drop DB:  {temp_database_name}')
      spark.sql(f'drop database if exists {temp_database_name} cascade')
      print(f'{temp_database_name} is dropped')
      persistLog_temp([[temp_task['temp_group_id'],temp_task['id'],f'{temp_task["temp_database_name"]}','DROP_DB',job_id,run_id,"Success",datetime.now().date(),datetime.now()]],metricsLogTable)
      return_list.append({
        'temp_table' : '',
        'temp_db' : f'{temp_task["temp_database_name"]}',
      'status' : True,
      'error' : ''
      })
    
  
  except Exception as e:
      persistLog_temp([[temp_task['temp_group_id'],temp_task['id'],f'{temp_task["temp_database_name"]}','DROP_DB',job_id,run_id,"Failed",datetime.now().date(),datetime.now()]],metricsLogTable)
      return_list.append({
        'temp_table' : '',
        'temp_db' : f'{temp_task["temp_database_name"]}',
      'status' : False,
      'error' : str(e)
      })

  return return_list



# COMMAND ----------

# MAGIC %md
# MAGIC ## Drop Main Calls

# COMMAND ----------

# def drop_main(temp_group_id,metricsLogTable):
#   temp_tasks_list = get_temp_tasks_list(temp_group_id)
#   drop_status_list = []
#   for temp_task in temp_tasks_list:
#     if temp_task['drop_temp_database']:
#       drop_status = drop_temp_db(temp_task['temp_database_name'],metricsLogTable)
#     else:
#       drop_status =  drop_temp_tables(temp_task,metricsLogTable)
#     drop_status_list.append(drop_status)
#     print(drop_status_list)
  
#   return drop_status_list

# COMMAND ----------

# MAGIC %md
# MAGIC ## Emailing

# COMMAND ----------

def form_email_and_send(result_df,domain_email_dl,temp_group_id,temp_task_id):

  subject= f"DHF Temp Tables Cleanup Status Group Id: {temp_group_id},Task Id: {temp_task_id}"
  body = "<html><head><style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}td, th {border: 1px solid #dddddd;text-align: left;padding: 8px;}tr:nth-child(even) {background-color: #dadadd;}</style></head><body><p> Good Day! </p><p>Please find below the DHF Temp Tables Cleanup Status: </p>"
  table = "<table><tr bgcolor=Aquamarine><th>temp_table</th><th>temp_db</th><th>drop_status</th><th>error</th></tr>"
  str_table = body+table
  for row in result_df.collect():
    temp_table = str(row["temp_table"])
    temp_db = str(row["temp_db"])
    drop_status = str(row["status"])
    error = str(row["error"])
    str_rw = "<tr><td>"+ temp_table + "</td><td>"+temp_db + "</td><td>"+ drop_status + "</td><td>" + error + "</td>" + "</tr>"
    str_table = str_table + str_rw
  str_table = str_table + "</table>" + "<p>For more details please click the below jobId, which will be deleted immediately if its status was successful</p><table style=width:22%><tr><td bgcolor=Aquamarine>Job Id</td><td><a href=" +job_url+ ">" + str(job_id)+ "</td></tr></table>" +"<p>NOTE : PLEASE DO NOT REPLY. This email is generated by an automated system.For any issues or concern related to this job, connect to DHF Team</p><p>Warm Regards,<br>DHF Team</p></html>"


  email_from = 'do-not-reply@nationwide.com'
  email_to = domain_email_dl
  email_subject = f"{environment}".upper()+" - " +subject
  email_body = str_table

  sendEmail(email_to, email_from,email_subject, email_body)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Flow starts here

# COMMAND ----------

temp_tasks_list = get_temp_tasks_list(temp_group_id)
for temp_task in temp_tasks_list:
  try:
      
    if temp_task['drop_temp_database']:
      drop_status_list = drop_temp_db(temp_task['temp_database_name'],metricsLogTable)
    else:
      drop_status_list =  drop_temp_tables(temp_task,metricsLogTable)

    form_email_and_send(spark.createDataFrame(drop_status_list),domain_email_dl,temp_group_id,temp_task['id'])
    # persistLog_temp_cleanup([[temp_group_id,job_id,run_id,"Success",datetime.now().date(),datetime.now()]])

  except Exception as e:
    print("temp_group_id",temp_group_id)
    form_email_and_send(spark.createDataFrame([{
        'temp_table' : f'NA',
        'temp_db': f'{temp_task["temp_database_name"]}',
      'status' : False,
      'error' : str(e)
      }]),domain_email_dl,temp_group_id,temp_task['id'])
    # persistLog_temp_cleanup([[temp_group_id,job_id,run_id,"Failed",datetime.now().date(),datetime.now()]])
    raise Exception("Failing the job as logic arrives at exception block", e)

# COMMAND ----------

job_json = {
     "job_id": job_id
     }

spark.sql(f"delete from dhf_logs_dev.e2h_job_creation_log where group_id={temp_group_id}")
resp=(requests.post(f'{dbhost}/api/2.1/jobs/delete',headers={'Authorization' : f'Bearer {token}','X-Databricks-Org-Id' : f'{workspaceID}'},json=job_json))

# COMMAND ----------

# MAGIC %sql
# MAGIC -- create database bhuvna_temp_target_db

# COMMAND ----------


