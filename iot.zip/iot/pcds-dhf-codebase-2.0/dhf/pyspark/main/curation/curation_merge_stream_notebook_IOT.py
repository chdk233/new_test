# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string
import dateutil

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/outbound_score_elements

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/daily_score_extract

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/trip_detail

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/device_status_functions

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/ca_annual_mileage_scoring

# COMMAND ----------

#%run ../curation_child/IOT/daily_mileage

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/device_summary

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/scrub/flows/ScrubberFlow

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/program_summary

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/ods_trip_digest

# COMMAND ----------

def doCuration(microBatchDF, batchId, harmonizedDB, curateDB, target_table,harmonized_table,merge_key,encryptColumns,secretKey,is_encryptdata):
  print("curateDB and targetDB are",curateDB,target_table)
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "outbound_score_elements":
    outbound_score_elements(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
    
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "extracts_dailyscoring":
    daily_score_extract(microBatchDF, batchId, harmonizedDB, curateDB, target_table)

  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "trip_detail":
    make_trip_detail(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
    
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "device_status":
    make_device_status(microBatchDF, batchId, harmonizedDB, curateDB, target_table)

  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "daily_mileage":
    daily_mileage(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
    
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "ca_annual_mileage_scoring":
    ca_annual_mileage(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
  
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "device_summary":
    device_summary(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
	
  if curateDB == f"dhf_iot_harmonized_{environment}" and target_table == "trip_detail_seconds":
    make_trip_detail_second(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
    
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "program_summary":
    make_program_summary(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
    
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "trip_digest":
    make_trip_digest(microBatchDF, batchId, harmonizedDB, curateDB, target_table)

# COMMAND ----------

# MAGIC %run ../curation/curation_merge_stream_master

# COMMAND ----------

startCurationStreamingMain(groupId,completed_streams) 
