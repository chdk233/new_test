# Databricks notebook source
# MAGIC %md
# MAGIC - Runs all tables for one Group ID
# MAGIC - Al l tables writing to one Curation Table go into same TaskGroup
# MAGIC - Task Group Level configurations:
# MAGIC -  job_type: CURATION 
# MAGIC -  run_type: ROUND_THE_CLOCK / AVAILABLE_NOW   -- This notebook ONLY runs ROUND_THE_CLOCK TaskGroups
# MAGIC -  isNotebook: True/False

# COMMAND ----------

# DBTITLE 1,Import libraries

import pyspark.sql
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import *
import datetime
import io
import re
import json
from itertools import groupby
from operator import itemgetter
import io
import zipfile
import pandas as pd
from pyspark.sql.types import *
import datetime #4
import json
import boto3
import time
import ast
from datetime import datetime as dt
import time
from pyspark.sql import functions as f
from pyspark.sql.session import SparkSession
from pyspark.sql import DataFrame
from dataclasses import dataclass
from pyspark.sql.functions import window
from pyspark.sql import *

# COMMAND ----------

# DBTITLE 1,Set spark conf
spark.conf.set("spark.sql.streaming.stopActiveRunOnRestart", True)
spark.conf.set("spark.sql.broadcastTimeout", 600)

# COMMAND ----------

# DBTITLE 1,Get arguments from widgets
dbutils.widgets.removeAll()
dbutils.widgets.text("groupId", "1", "GroupID")
dbutils.widgets.text("environment", "dev", "environment")
dbutils.widgets.text("metricsLogTable", "", "metricsLogTable")

groupId = int(dbutils.widgets.get("groupId"))
environment = dbutils.widgets.get("environment")
metricsLogTable = dbutils.widgets.get("metricsLogTable")

print("groupId in notebook is : ",groupId)
print("environment in notebook is : ", environment)
print("metricsLogTable in notebook is : ", metricsLogTable)

# COMMAND ----------

# DBTITLE 1,Run utils notebook
# MAGIC %run ../../utils/_utils

# COMMAND ----------

# DBTITLE 1,Global Variables for External Orchestration #QM
failed_taskgroups_list = []
taskgroup_queryid_dict = {}

# COMMAND ----------

class curateHandlerClass:
  def __init__(self,curatedTable,key,taskGroupId,jobType,runType,taskGroup,harmonizedDB,curatedDB,sourceTable):
    self.curatedTable = curatedTable
    self.key = key
    self.taskGroupId = taskGroupId
    self.jobType = jobType
    self.runType = runType
    self.taskGroup = taskGroup
    self.harmonizedDB = harmonizedDB
    self.curatedDB = curatedDB
    self.sourceTable = sourceTable
    
  def handleMicroBatch(microBatchDF, batchId):
    try:
      curatedTable = self.curatedTable
      key = self.key
      taskGroupId = self.taskGroupId
      jobType = self.jobType
      runType = self.runType
      taskGroup = self.taskGroup
      harmonizedDB = self.harmonizedDB
      curatedDB = self.curatedDB
      sourceTable = self.sourceTable
      start = dt.now()
      start_time = time.time()
      batchSize = microBatchDF.count()
      print(f"In delta handler f4")
      print(f"In delta handler for curatedTable: {curatedTable}, taskGroupId: {taskGroupId}, batchSize: {batchSize}, batchId:{batchId}")
      minThreshold = taskGroup['min_threshold']
      maxThreshold = taskGroup['max_threshold']
    
      ##added for snowprop
      servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
      if servicenow_property:
        snow_property = servicenow_property
      else:
        snow_property = taskGroup['user_properties']
      ##added for snowprop

      if batchSize>0:
        end_time = time.time()
        totalBatchTimeInMins = int((end_time-start_time)/60)
        
        persistLog([[str(groupId),jobId,str(jobType + "-Merge"),runType, runId, batchId, batchSize,str(totalBatchTimeInMins),str(start),taskGroupId, 0, "", curatedTable, clusterId]], metricsLogTable)
        #send to splunk
        sendToSplunk(str(groupId), jobId, job_name, str(jobType +"-Merge"), runType, runId, batchId, batchSize,str(start), str(totalBatchTimeInMins),  taskGroupId, 0, changelogTable, curatedTable, clusterId,"Success")
        
        #run inline optimize if it is the right period        
        print("run inline optimize if it is the right period")   
        if(taskGroup['inline_optimize_enabled']):
          optimizeDeltaTable(taskGroup)
    
        #check batch timing and send an email if it breaches min threshold and create a ticket if it breaches max threshold
        if(totalBatchTimeInMins > minThreshold):
          if(totalBatchTimeInMins > maxThreshold):
            print("Max Threshold Breached.Generating snow ticket and Sending Email..")
            errorHandler("maxThreshold",job_name,groupId,jobId,jobType,runId,batchId,maxThreshold,minThreshold,                                                        str(totalBatchTimeInMins),taskGroupId,0,"NA",taskGroup['email_list'],snow_property,metricsLogTable)
          else:
            print("Min Threshold hold breached. sending email...") 
            errorHandler("minThreshold",job_name,groupId,jobId,jobType,runId, batchId,maxThreshold,minThreshold,str(totalBatchTimeInMins),taskGroupId,0,"NA",taskGroup["email_list"],snow_property,metricsLogTable)
            
        else:
          print(f"batchId {batchId} for curation completed withing threshold limit.Total batch time - " ,totalBatchTimeInMins)
          
    except Exception as e:
      failed_taskgroups_list.append(taskGroupId)  #jobOrch
      persistLog_external([[taskGroupId,jobType,runId,"Failed",dt.now().date(),dt.now()]], metricsLogTable) #jobOrch
      
      print(f"MERGE FAILED for Curated table: {curatedTable}, batchId {batchId}.{e}")
      sendToSplunk(str(groupId), jobId, job_name, str(jobType +"-Merge"), runType, runId, batchId, batchSize,str(start), str(totalBatchTimeInMins),  taskGroupId, 0, changelogTable, curatedTable, clusterId,"Failed")
      #create snow ticket and send email
      errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroupId,0,str(e).replace("\n", " "),taskGroup['email_list'],snow_property,metricsLogTable)
      
      # ----- For External Job Orchestration --- #
      makingTaskGroupInactive(taskGroupId)
      print("active field successfully set to false for task group id",taskGroupId)
      error_msg="TaskGroup Id "+str(taskGroupId)+" is made inactive. To make it active again please follow the steps. \n Step-1 Go to DHF UI search the task group make it inactive and save the config. \n Step-2 Again go to DHF UI, search the task group and change it to active and save the config."
      errorHandler("inactive_task_group", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroupId,0,str(e).replace("\n", " "),taskGroup["email_list"],snow_property,metricsLogTable)
      raise Exception(f'MERGE FAILED for  target: {curatedTable} for batchId {batchId}',e)      
      

# COMMAND ----------

def startCurateMergeStream(taskGroup):
  global taskgroup_queryid_dict #jobOrch
  taskGroupId = taskGroup['id'] #jobOrch
  
  target_table = taskGroup['target_db'] + "." + taskGroup['target_table']
  maxBytesPerTrigger = taskGroup['max_bytes_per_trigger']
#   Type1_evntharm = taskGroup['merge_type'].lower()
#   orderby_evntharm = taskGroup['order_by_column']
  changelogTable = target_table + "_chlg"
  changelogPrefix=""

  if(not( taskGroup['user_properties']==None  or len(taskGroup['user_properties'])==0  ) ):
    changelogPrefix    = getUserPropertyValue("changelogPrefix", taskGroup['user_properties'])
    changelogTableSchema    =getUserPropertyValue("changelogTableSchema", taskGroup['user_properties'])
      
    if (not( changelogPrefix==None  or len(changelogPrefix)==0  ) ):
      changelogPrefix="_"+changelogPrefix
      changelogTable=target_table +changelogPrefix + "_chlg"
    else:
      changelogPrefix=""

    if (changelogTableSchema!=None  and len(changelogTableSchema)>=1 and  len(changelogPrefix)==0):
      changelogTable = changelogTableSchema+"." + taskGroup['target_table']+"_chlg"
    elif(changelogTableSchema!=None and len(changelogTableSchema)>=1 and len(changelogPrefix)>=1):
      changelogTable = changelogTableSchema+"." + taskGroup['target_table']+changelogPrefix+"_chlg"   
      
  print(target_table,maxBytesPerTrigger,changelogTable)
  
  checkpoint_dir = getCheckpoint(taskGroup['task_group_newdomain_source_id']) #CheckpointManagement
  
  if checkpoint_dir[-1] == "/": #CheckpointManagement
    checkpoint_dir = checkpoint_dir[:-1] #CheckpointManagement

  print("base checkPoint_dir",checkpoint_dir) #CheckpointManagement
  
  checkPoint = checkpoint_dir + "/eventcuration/" + str(taskGroup['id']) + "/" + taskGroup['target_table'] + changelogPrefix + "_chlg" + "/cp001" #CheckpointManagement
  print(f"checkPoint is {checkPoint}")
  try:
    readStream = spark.readStream.option("ignoreChanges", True)
#     if (Type1_evntharm=="type1" and ((orderby_evntharm==None) or (len(orderby_evntharm)==0))):
#       readStream = readStream.option("readChangeFeed", True)
    streamingDF = readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).format("delta").table(changelogTable)
    
    curateHandler = curateHandlerClass(target_table,taskGroup['merge_keys'],taskGroup['id'],taskGroup['job_type'],taskGroup['run_type'],taskGroup,taskGroup['source_db'],taskGroup['target_db'],taskGroup['source_table'])
    streamQuery = streamingDF.writeStream.foreachBatch(curateHandler.handleMicroBatch).option("checkpointLocation", checkPoint).option("queryName", "curate " + target_table + "_" + str(taskGroup['id']))
    
    if (taskGroup['run_type'] == ("AVAILABLE_NOW")):
      streamQuery = streamQuery.trigger(availableNow=True).option("maxBytesPerTrigger", maxBytesPerTrigger)
    q = streamQuery.start()
    taskgroup_queryid_dict[taskGroupId] = q.id #jobOrch
    
  except Exception as e:
    failed_taskgroups_list.append(taskGroupId)  #jobOrch
    persistLog_external([[taskGroupId,taskGroup['job_type'],runId,"Failed",dt.now().date(),dt.now()]], metricsLogTable) #jobOrch
    
    print(f"Merge Stream failed for Curated table: {changelogTable} {e}")

    #post log info to splunk
    sendToSplunk(str(groupId), jobId, job_name, taskGroup['job_type'] + "-Merge", taskGroup['run_type'], runId, -1, 0,str(dt.now()), "0",  taskGroup['id'], 0, changelogTable, taskGroup['target_table'], clusterId,"Failed")

    ##added for snowprop
    servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
    if servicenow_property:
      snow_property = servicenow_property
    else:
      snow_property = taskGroup['user_properties']
    ##added for snowprop
    
    #create snow ticket and send email
    errorHandler("exception", job_name,groupId,jobId,taskGroup['job_type'],runId, -1,0,0,"0",taskGroup['id'],0,str(e).replace("\n", " "),taskGroup['email_list'],snow_property,metricsLogTable)
    

# COMMAND ----------

def startMergeStreamsForBatch(taskGroupList):
  print("\n in start merge")
  canExitLoop = False
  startedTaskGroupList = [] #creating empty task list to avoid running the merge stream again after its completions
  while(not(canExitLoop)):
    canExitLoop = True
    for taskGroup in taskGroupList:
      activeStreamList = [_.name for _ in spark.streams.active]
      taskGroupStreamList = [_ for _ in set(f"{_['source_table']}_{taskGroup['id']}" for _ in getTask(int(taskGroup['id']), taskGroup['job_type']))]
      
      print(f"\n activeStreamList: {activeStreamList} \n taskGroupStreamList: {taskGroupStreamList}")
      if any(_ in taskGroupStreamList for _ in activeStreamList):  #if query streams are still active for all Task Groups
        canExitLoop = False
        
      else:
        if (not(int(taskGroup['id']) in startedTaskGroupList)):
          startCurateMergeStream(taskGroup)
          startedTaskGroupList.append(int(taskGroup['id']))  #appending taskgroup after MergeStream to avoid running the merge stream again
          print(f"\n Appending TASK GROUP to the toCheckTaskGroupList --- {startedTaskGroupList}")
        else:
          print(f"Merge stream either running or completed for this Task Group: {taskGroup['id']}")
          
      if (not(canExitLoop)):
        print("\n Waiting in Merge Stream Loop . . . \n")
        time.sleep(30)
        

# COMMAND ----------

class DeltaHandlerClass:
  def __init__(self,task,curatedTable,jobType,runType,email_list,user_properties,servicenow_property,changelogTable):
    self.task = task
    self.curatedTable = curatedTable
    self.jobType = jobType
    self.runType = runType
    self.email_list = email_list
    self.user_properties = user_properties
    self.servicenow_property = servicenow_property 
    self.changelogTable = changelogTable
     
  def handleMicroBatch(self,microBatchDF,batchId):
    try:
      print("Entering EG handler...")
      task = self.task
      curatedTable = self.curatedTable
      jobType = self.jobType
      runType = self.runType
      email_list = self.email_list
      user_properties = self.user_properties
      servicenow_property = self.servicenow_property 
      changelogTable = self.changelogTable
      start = dt.now()
      start_time = time.time()
      batchSize = microBatchDF.count()
      if batchSize >= 1:
        print(f"Entering EG handler generation changelogTable: {changelogTable}, BatchId: {batchId}, Batchsize: {batchSize}, TaskId: {task['id']}, SourceTable: {task['source_table']}")
        microBatchDF.createOrReplaceGlobalTempView(f'{task["source_table"]}')
        if(task["sql_query"].startswith('/Repos')):
          task_query = task_query_dict[task["id"]]
          print(f'query for the task {task["id"]} is : {task_query}')
          queryDF = spark.sql((task_query).replace("{sourceDB}", task["source_db"]))
        else:
          queryDF = spark.sql((task["sql_query"]).replace("{sourceDB}", task["source_db"]))
        queryDF.write.mode("append").format("delta").saveAsTable(changelogTable)
        end_time = time.time()
        totalBatchTimeInMins = int((end_time-start_time)/60)
       
        persistLog([[str(groupId),jobId,jobType,runType, runId, batchId, batchSize,str(totalBatchTimeInMins),str(start),task['task_group_id'], task['id'], task['source_table'], curatedTable, clusterId]], metricsLogTable)
        
          #Send log info to splunk
        sendToSplunk(str(groupId), jobId, job_name, jobType, runType, runId, batchId, batchSize,  str(start),str(totalBatchTimeInMins), task['task_group_id'], task['id'], task['source_table'], changelogTable, clusterId,"Success")
    
      else:
        print(f"NO DATA in microbatch for source table {task['source_table']}, batchId {batchId}")
        
    except Exception as e:
      print(f"APPEND FAILED for raw table: {task['source_table']}, batchId {batchId}, FAILING the entire job. {e}")
        #Send log info to splunk
      sendToSplunk(str(groupId), jobId, job_name, jobType, runType, runId, batchId, 0,  str(dt.now()),"0", task['task_group_id'], task['id'], task['source_table'], changelogTable, clusterId,"Failed")

      ##added for snowprop
      servicenow_property = servicenow_property if servicenow_property is None else servicenow_property.strip()
      if servicenow_property:
        snow_property = servicenow_property
      else:
        snow_property = user_properties
      ##added for snowprop

      errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",task['task_group_id'],task['id'],str(e).replace("\n", " "),email_list,snow_property,metricsLogTable)
#       raise Exception(f"APPEND FAILED for raw table: {task['source_table']}, batchId {batchId}, FAILING the entire job. {e}")

# COMMAND ----------

def startGenerationStreamingMain():
  group = getGroup(groupId)
  taskGroupList = getCurationTaskGroupList(groupId)
  global task_query_dict
  task_query_dict = {}
  
  threshold_time_dict = {"HOURLY":15,"DAILY":180,"WEEKLY":1440,"MONTHLY":7220,"YEARLY":14400,"NONE":0}
  threshold_time = threshold_time_dict[group["schedule"]]
  
  for taskGroup in taskGroupList:
    taskGroupId = int(taskGroup['id'])
    target_table = taskGroup['target_db'] + "." + taskGroup['target_table']
    taskList = getTask(taskGroupId, group['job_type'])
    Type1_evntgen = taskGroup['merge_type'].lower() 
    orderby_evntgen = taskGroup['order_by_column']
    maxBytesPerTrigger = taskGroup['max_bytes_per_trigger']
    changeLogSchema =taskGroup['change_log_schema'] # ChangeLog Table schema # schema drift
    changelogTable = target_table + "_chlg"
    changelogPrefix=""    
    replay_flag=taskGroup["replay"]
    
    secretKey=getSecretKey(taskGroup['secret_key_details'])
    if taskGroup['decrypt_data']:
      decryptColumns=taskGroup['decrypt_columns'] #sensitive columns-decrypt
      if (secretKey==None or (decryptColumns==None or len(decryptColumns)==0) ):
        raise Exception("Decrypt data flag is enabled but Secret Key details or list of columns that needs to be decrypted are not provided ")
    if taskGroup['encrypt_data']:
      encryptColumns=taskGroup['encrypt_columns'] #sensitive columns-encrypt
      if (secretKey==None or (encryptColumns==None or len(encryptColumns)==0) ):
        raise Exception("Encrypt data flag is enabled but Secret Key details or list of columns that needs to be encrypted are not provided ") 

    if(not( taskGroup['user_properties']==None  or len(taskGroup['user_properties'])==0  ) ):
      changelogPrefix    =getUserPropertyValue("changelogPrefix", taskGroup['user_properties'])
      changelogTableSchema    =getUserPropertyValue("changelogTableSchema", taskGroup['user_properties'])

      if (not( changelogPrefix==None  or len(changelogPrefix)==0  ) ):
        changelogPrefix="_"+changelogPrefix
        changelogTable=target_table +changelogPrefix + "_chlg"
      else:
        changelogPrefix=""        
      if (changelogTableSchema!=None  and len(changelogTableSchema)>=1 and  len(changelogPrefix)==0):
        changelogTable = changelogTableSchema+"." + taskGroup['target_table']+"_chlg"
      elif(changelogTableSchema!=None and len(changelogTableSchema)>=1 and len(changelogPrefix)>=1):
        changelogTable = changelogTableSchema+"." + taskGroup['target_table']+changelogPrefix+"_chlg"   
      

    checkpoint_dir = getCheckpoint(taskGroup['task_group_newdomain_source_id']) 
    if checkpoint_dir[-1] == "/": 
      checkpoint_dir = checkpoint_dir[:-1] 
    print("base checkPoint_dir",checkpoint_dir) 
    
    if(replay_flag == True):
      print("Replay Flag set to Ture")
      checkPoint_del=checkpoint_dir +"/"+"eventgeneration_curation"+"/"+str(taskGroupId)+"/"
      dbutils.fs.rm(checkPoint_del,True)
      print(f"Since Repaly Flag is enabled checkPoint {checkPoint_del} is deleted")
    
    if (len(taskList)==0):
      raise (f"No task found for the given task_group_id {taskGroupId}. Please check the task config table")
    else:
      #To handle schema drift
      tableExists = spark.catalog._jcatalog.tableExists(f"{changelogTable}")
      if not(tableExists):
        createTableQuery = f'CREATE TABLE IF NOT EXISTS {changelogTable} ({changeLogSchema.replace("#",",")})'
        print(" Change log table does not exists.create statement:-- \n" +createTableQuery)
        spark.sql(f"{createTableQuery}")
        print(f"Change log table created... {changelogTable}")
      else:
        print(f"change log table exists... {changelogTable} ..checking for schema drift")
        changeLogSchemaList=changeLogSchema.split("#")
        newChlgCols =list(map(lambda x :x.strip().split(" ")[0],changeLogSchemaList))
        showColQuery=f"SHOW COLUMNS IN {changelogTable}"
        chlgCols=spark.sql(showColQuery).select('col_name').rdd.map(lambda x :x[0]).collect()
        print("Existing  ChangeLog Table - columns  :",chlgCols)
        print("Schema Given by user -Columns :",newChlgCols)
        difference=[col for col in newChlgCols + chlgCols if col not in newChlgCols or col not in chlgCols]

        if len(difference)>0:
          print("Identified schema drift...")
          
          if (len(chlgCols)< len(newChlgCols)):
            print("new column found.... ")
            newColList=[]
            for col in difference:
              newColList=newColList+[newCol for newCol in changeLogSchemaList if newCol.startswith(col+" ")]
            newCols= ",".join(newColList)  
            alterQuery = f'ALTER TABLE {changelogTable} ADD COLUMNS({newCols})'
            spark.sql(alterQuery)
            print("Alter Query Executed...New columns added")
            
          else:
            print("Found deleted columns...")
            spark.sql(f'DROP TABLE IF EXISTS {changelogTable}')
            spark.sql(f'CREATE TABLE IF NOT EXISTS {changelogTable} ({changeLogSchema.replace("#",",")})')
            print("ChangeLog Table dropped and created again using new Schema")
            dbutils.fs.rm(f"{checkpoint_dir}/eventcuration/{str(taskGroupId)}/{changelogTable}/",True)
            print("Removed existing Curation checkpoint..")

        else :
          print("No schema drift...")
      
      for task in taskList:
        checkPoint = checkpoint_dir +"/"+"eventgeneration_curation"+"/"+str(taskGroupId)+"/"+task['source_table']+"/"+"cp001"#CheckpointManagement
        print("checkPoint is ",checkPoint)
        if(task["sql_query"].startswith('/Repos')):
          notebook_args = {}
          for table,fields in {"group": group, "taskGroup": taskGroup, "task": task}.items():
            for field,value in fields.items():
              if field != 'user_properties':
                notebook_args[f'{table}__{field}'] = value
              else:
                value = value if value is not None and ':' in value else ":"
                for up_key,up_val in [hash_splitted_val.split(":") for hash_splitted_val in value.split("#")]:
                  notebook_args[f'{table}__{field}__{up_key}'] = up_val


          query_in_notebook = dbutils.notebook.run(f"{task['sql_query']}",0,notebook_args)
          # query_in_notebook = dbutils.notebook.run(f"{task['sql_query']}",0)
          
          task_query_dict[task['id']] = query_in_notebook
        else:
          print("Sql query notebook Path is not provided in the sql_query field")
        deltaHandler = DeltaHandlerClass(task,target_table,group['job_type'],group['run_type'],taskGroup['email_list'],taskGroup['user_properties'],taskGroup['servicenow_property'],changelogTable)
        
        try:
          readStream = spark.readStream.option("ignoreChanges", "true") 

          if (Type1_evntgen=="type1" and (orderby_evntgen==None or len(orderby_evntgen)==0)):
            readStream = readStream.option("readChangeFeed", "true")
          if(replay_flag==True):
            replay_columns=task["replaydatecolumn"]
            streamingDF=replay_hramonization_curation(replay_columns,task,maxBytesPerTrigger)
          else:
            streamingDF = readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).format("delta").table(f"{task['source_db']}.{task['source_table']}")
          if (not(task['read_table_from_date'] is None or len(task['read_table_from_date'])==0)):
            print("in ! empty readtablefromdate")
            streamingDF = streamingDF.filter(col("updatetime") >= task['read_table_from_date']) 
          
          streamQuery = streamingDF.writeStream.foreachBatch(deltaHandler.handleMicroBatch).option("checkpointLocation", checkPoint).option("queryName", str(task['source_table'])+"_"+str(taskGroupId))
            
          if (taskGroup['run_type'] == "AVAILABLE_NOW"): 
            streamQuery = streamQuery.trigger(availableNow=True).option("maxBytesPerTrigger", maxBytesPerTrigger)
          
          streamQuery.start()
        
        except Exception as e:
          print(f"Stream FAILED for raw table: {task['source_table']}.{e}")
          #To send log info to splunk
          sendToSplunk(str(groupId), jobId, job_name, group['job_type'], group['run_type'], runId, -1, 0,  str(datetime.now()),"0", task['task_group_id'], task['id'], task['source_table'], changelogTable, clusterId,"Failed") 

          ##added for snowprop
          servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
          if servicenow_property:
            snow_property = servicenow_property
          else:
            snow_property = taskGroup['user_properties']
          ##added for snowprop

          #create snow ticket and send email
          errorHandler("exception", job_name,groupId,jobId,group['job_type'],runId, -1,0,0,"0",task['task_group_id'],task['id'],str(e).replace("\n", " "),taskGroup['email_list'],snow_property,metricsLogTable)
          
          raise Exception(f"Stream FAILED for raw table: {task['source_table']}. {e}")
          
      if (taskGroup['run_type'] == "ROUND_THE_CLOCK" and not(taskGroup['is_custom_notebook'])): 
        startCurateMergeStream(taskGroup)
        
  if group['is_custom_notebook']:#sid changes
#     baseFilePath = f"/Repos/dhfsid@nationwide.com/pcds-dhf-{environment}-2.0/dhf/pyspark/main/"
#     substr = "main/"
#     handler_path=group['handler_path']
#     appendPath = handler_path[handler_path.index(substr)+len(substr)-1:]
    notebookHandlerPath = group['handler_path'] #if(f"{environment}" == "dev") else baseFilePath + appendPath

    print(f"NotebookPath is {notebookHandlerPath}")
    if(taskGroup['run_type'] == 'ROUND_THE_CLOCK'):
      dbutils.notebook.run(path = notebookHandlerPath, arguments={"groupId":str(groupId),"environment":environment,"checkpoint_dir":checkpoint_dir,"metricsLogTable":metricsLogTable,"ExJ_runId":str(runId) if runId is not None else ""}, timeout_seconds=0) 
#added new parameter for metricsLogTable
   
    elif(taskGroup['run_type'] == 'AVAILABLE_NOW'):
      loop_start_time=datetime.now()
      canExitLoop=False
      completed_streamList=set()
      while not (canExitLoop):
        canExitLoop = True
        for taskGroup in taskGroupList:
          activeStreamList = [_.name for _ in spark.streams.active]
          taskGroupStreamList = [_ for _ in set(f"{_['source_table']}_{taskGroup['id']}" for _ in getTask(int(taskGroup['id']), taskGroup['job_type']))] 
          print(f"\n activeStreamList: {activeStreamList} \n taskGroupStreamList: {taskGroupStreamList}")
          if any(_ in taskGroupStreamList for _ in activeStreamList):
            canExitLoop = False
          else:
            completed_streamList.add(str(taskGroup['id']))
            print(f"\n Appended TASK GROUP {taskGroup['id']} to the to completed_streamList")
        loop_end_time=datetime.now()
        total_loop_time=int((loop_end_time-loop_start_time).total_seconds()/60)
        if(total_loop_time>=threshold_time):
          canExitLoop=True
        else:
          canExitLoop = False
          time.sleep(30)
      completed_streams=','.join(completed_streamList)
      print("completed streams are",completed_streams)
      
      if(len(completed_streamList)>0):
        dbutils.notebook.run(path = notebookHandlerPath, arguments={"groupId":str(groupId),"completed_streams":completed_streams,"environment":environment,"checkpoint_dir":checkpoint_dir,"metricsLogTable":metricsLogTable,"ExJ_runId":str(runId) if runId is not None else ""}, timeout_seconds=0)
      else:
         print("Curation is not completed for all the task groups") 
  
  elif(group['run_type'] == "AVAILABLE_NOW"):
    startMergeStreamsForBatch(taskGroupList)  
    
    
  if(group['run_type'] == "AVAILABLE_NOW") and not(group['is_custom_notebook']): #this entire block is for #jobOrch
    print("--- entering query monitor logic ---")
    taskGroupList_log = [_["id"] for _ in taskGroupList if _["id"] not in failed_taskgroups_list]
    print(f"taskGroupList_log: {taskGroupList_log}") #done
    
    while(len(taskGroupList_log) != 0):

      for taskGroup in list(taskGroupList_log):
        if (taskgroup_queryid_dict[taskGroup] not in [_.id for _ in spark.streams.active]) and (taskGroup not in failed_taskgroups_list):
          persistLog_external([[taskGroup,group['job_type'],runId,"Success",dt.now().date(),dt.now()]], metricsLogTable) #jobOrch
          print(f"{taskGroup} is added as success in log table, same will be removed from current loop")
          taskGroupList_log.remove(taskGroup)
        elif taskGroup in failed_taskgroups_list:
          print(f"taskgroup{taskGroup} was added to failed list, failure log will be pushed to log table, taskgroup will be removed from current loop")
          taskGroupList_log.remove(taskGroup)

# COMMAND ----------

startGenerationStreamingMain()
