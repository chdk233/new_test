# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string
import dateutil

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("completed_streams are :",completed_streams)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/daily_scoring

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/trip_detail

# COMMAND ----------

# MAGIC %run ../curation_child/IOT/device_status_functions

# COMMAND ----------

# MAGIC %run ../curation_child/dhf_sample_child_notebooks/claims_child_sensitive

# COMMAND ----------

# MAGIC %run ../curation_child/claims_child

# COMMAND ----------

def doCuration(microBatchDF, batchId, harmonizedDB, curateDB, target_table,harmonized_table,merge_key,encryptColumns,secretKey,is_encryptdata):
  print("curateDB and targetDB are",curateDB,target_table)
  if curateDB == "dhf_iot_curated_dev" and target_table == "outbound_score_elements":
    daily_scoring(microBatchDF, batchId, harmonizedDB, curateDB, target_table)

  if curateDB == "dhf_iot_curated_dev" and target_table == "trip_detail":
    make_trip_detail(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
    
  if curateDB == "dhf_iot_curated_dev" and target_table == "device_status":
    make_device_status(microBatchDF, batchId, harmonizedDB, curateDB, target_table)
    
  if curateDB =="sk249_config" and (target_table =="cc_claim_target_sensitive_curated" or target_table =="cc_claim_type1_cur"):
    test_curation_child_sensitive(microBatchDF, batchId, harmonizedDB, curateDB, target_table,encryptColumns,secretKey,is_encryptdata)

  if curateDB =="sk249_config" and (target_table =="base_claim_small_curated_avn2"):
    test_curation_child(microBatchDF, batchId, harmonizedDB, curateDB, target_table)

# COMMAND ----------

# MAGIC %run ../curation/curation_merge_stream_master

# COMMAND ----------

startCurationStreamingMain(groupId,completed_streams) 
