# Databricks notebook source
# MAGIC %run ../../utils/_utils

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql import *
from pyspark.sql.window import * 
from pyspark.sql.streaming import *
from pyspark import *
import string
import time
import pyspark.streaming 
from pyspark.streaming import *


# COMMAND ----------

spark.conf.set("spark.sql.streaming.stopActiveRunOnRestart", True)
spark.conf.set("spark.sql.legacy.parquet.datetimeRebaseModeInWrite","CORRECTED")

# COMMAND ----------

# DBTITLE 1,Global Variables for External Orchestration #QM
failed_taskgroups_list = []
taskgroup_queryid_dict = {}

# COMMAND ----------

class curateHandlerClass:
  def __init__(self,taskGroup, groupId, runType, jobType):
    self.taskGroup=taskGroup
    self.groupId=groupId
    self.runType=runType
    self.jobType=jobType
  
  def handleMicroBatch(self,microBatchDF, batchId):
    try:
      taskGroup=self.taskGroup
      groupId=self.groupId
      runType=self.runType
      jobType=self.jobType
      start = datetime.now()
#       metricsLogTable = "dhf2_config.curation_metrics" # commmented for metrics table
      minThreshold = taskGroup["min_threshold"]
      maxThreshold = taskGroup["max_threshold"]
      print("in delta handler \n")
      batchSize = microBatchDF.count()
      print(f'batchSize {batchSize}, target: {taskGroup["target_table"]} groupId {groupId}')
      #decrypt
      is_decryptdata=taskGroup["decrypt_data"]
      decryptColumns=taskGroup["decrypt_columns"] 
      secretKey=getSecretKey(taskGroup["secret_key_details"])

      ##added for snowprop
      servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
      if servicenow_property:
        snow_property = servicenow_property
      else:
        snow_property = taskGroup['user_properties']
      ##added for snowprop

      if is_decryptdata:
        microBatchDF=decryptDataframe(microBatchDF,decryptColumns,secretKey) # decrypt columns, if needed before curation logic
      #Encrypt
      is_encryptdata=taskGroup["encrypt_data"]
      encryptColumns=taskGroup["encrypt_columns"] 
      doCuration(microBatchDF, batchId, taskGroup["source_db"], taskGroup["target_db"], taskGroup["target_table"],taskGroup["source_table"],taskGroup['merge_keys'],encryptColumns,secretKey,is_encryptdata)
      totalBatchTimeInMins=int((datetime.now()-start).total_seconds()/60)
      print(f'Total batch time for target: {taskGroup["target_table"]}, batchId {batchId} is: {totalBatchTimeInMins} min')
      
      persistLog([[str(groupId), jobId, str(jobType + "-Merge-Notebook"), runType, runId, batchId, batchSize, str(totalBatchTimeInMins), str(start), taskGroup["id"], 0, "", taskGroup["target_table"], clusterId]], metricsLogTable)
         
      #post log info to splunk
      sendToSplunk(str(groupId), jobId, job_name, str(jobType + "-Merge-Notebook"), runType, runId, batchId, batchSize,str(start), str(totalBatchTimeInMins),  taskGroup["id"], 0, taskGroup["target_table"]+"_chlg", taskGroup["target_table"], clusterId,"Success")
                      
      #run inline optimize if it is the right period
      print("run inline optimize if it is the right period")
      if(taskGroup["inline_optimize_enabled"]):
        optimizeDeltaTable(taskGroup)
                          
      #check batch timing and send an email if it breaches min threshold and create a ticket if it breaches max threshold
      if(totalBatchTimeInMins > minThreshold):
        if(totalBatchTimeInMins > maxThreshold):
          print("Max Threshold Breached.Generating snow ticket and Sending Email..")
          errorHandler("maxThreshold",job_name,groupId,jobId,jobType,runId,batchId,maxThreshold,minThreshold,                           str(totalBatchTimeInMins),taskGroup["id"],0,"NA",taskGroup["email_list"],snow_property,metricsLogTable)
        else:
          print("Min Threshold hold breached. sending email...") #email notebook
          errorHandler("minThreshold",job_name,groupId,jobId,jobType,runId,batchId,maxThreshold,minThreshold,str(totalBatchTimeInMins),   taskGroup["id"],0,"NA",taskGroup["email_list"],snow_property,metricsLogTable)                                
                  
      else:
        print(f"batchId {batchId} for Curation completed withing threshold limit.Total batch time - ",totalBatchTimeInMins)
    except Exception as e:
      failed_taskgroups_list.append(taskGroup["id"])  #jobOrch
      persistLog_external([[taskGroup["id"],jobType,ExJ_runId,"Failed",datetime.now().date(),datetime.now()]], metricsLogTable) #jobOrch
      
      print(f'MERGE FAILED for  target: {taskGroup["target_table"]} for batchId {batchId}')
    #post log info to splunk
      sendToSplunk(str(groupId), jobId, job_name, jobType + "-Merge-Notebook", runType, runId, batchId, 0, str(datetime.now()), "0",taskGroup["id"], 0, taskGroup["target_table"]+"_chlg", taskGroup["target_table"], clusterId,"Failed")
           
      errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroup["id"],0,str(e),taskGroup["email_list"],snow_property,metricsLogTable)
      makingTaskGroupInactive(taskGroup["id"])
      print("active field successfully set to false for task group id",taskGroup["id"])
      error_msg="TaskGroup Id "+str(taskGroup["id"])+" is made inactive. To make it active again please follow the steps. \n Step-1 Go to DHF UI search the task group make it inactive and save the config. \n Step-2 Again go to DHF UI, search the task group and change it to active and save the config."
      errorHandler("inactive_task_group", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroup["id"],0,error_msg,taskGroup["email_list"],snow_property,metricsLogTable)
      raise Exception(f'MERGE FAILED for  target: {taskGroup["target_table"]} for batchId {batchId}',e)

# COMMAND ----------

def startCurateMergeStream(taskGroup):
  global taskgroup_queryid_dict #jobOrch
  taskGroupId = taskGroup['id'] #jobOrch
  
  print("\n entering startMergeStreams \n")
  target_table = taskGroup["target_db"] + "." + taskGroup["target_table"]
  maxBytesPerTrigger = taskGroup["max_bytes_per_trigger"]
  runType = taskGroup["run_type"]
  changelogTable = target_table + "_chlg"
  changelogPrefix=""
  
  if(not( taskGroup['user_properties']==None  or len(taskGroup['user_properties'])==0  ) ):
    changelogPrefix    =getUserPropertyValue("changelogPrefix", taskGroup['user_properties'])
    changelogTableSchema    =getUserPropertyValue("changelogTableSchema", taskGroup['user_properties'])
      
    if (not( changelogPrefix==None  or len(changelogPrefix)==0  ) ):
      changelogPrefix="_"+changelogPrefix
      changelogTable=target_table +changelogPrefix + "_chlg"
    else:
      changelogPrefix=""
    
    if (changelogTableSchema!=None  and len(changelogTableSchema)>=1 and  len(changelogPrefix)==0):
      changelogTable = changelogTableSchema+"." + taskGroup['target_table']+"_chlg"
    elif(changelogTableSchema!=None and len(changelogTableSchema)>=1 and len(changelogPrefix)>=1):
      changelogTable = changelogTableSchema+"." + taskGroup['target_table']+changelogPrefix+"_chlg" 
  
  checkPoint = checkpoint_dir + "/eventcuration/" + str(taskGroup['id']) + "/" + taskGroup['target_table'] + changelogPrefix +  "_chlg" + "/cp001"
  print("checkPoint is " + checkPoint)
  
  try:
    streamingDF = spark.readStream.format("delta").option("ignoreChanges", True).option("maxBytesPerTrigger", maxBytesPerTrigger).table(f'{changelogTable}')
    
    curateHandler = curateHandlerClass(taskGroup, taskGroup["job_group_id"], runType, taskGroup["job_type"])
    streamingDF = streamingDF.drop("_change_type").drop("_commit_version").drop("_commit_timestamp")#newly added for type1
    
    if (runType.upper()=="AVAILABLE_NOW"):
      q = streamingDF.writeStream.trigger(availableNow=True).option("maxBytesPerTrigger", maxBytesPerTrigger).option("queryName","curate " + target_table +"_"+ str(taskGroup['id'])).option("checkpointLocation",checkPoint).foreachBatch(curateHandler.handleMicroBatch).start()
    else:
      q = streamingDF.writeStream.option("queryName","curate " +target_table +"_"+ str(taskGroup['id'])).option("checkpointLocation",checkPoint).   foreachBatch(curateHandler.handleMicroBatch).start()
    taskgroup_queryid_dict[taskGroupId] = q.id #jobOrch
    
  except Exception as e:
    failed_taskgroups_list.append(taskGroupId)  #jobOrch
    persistLog_external([[taskGroupId,taskGroup['job_type'],ExJ_runId,"Failed",datetime.now().date(),datetime.now()]], metricsLogTable) #jobOrch
    
    print(f"Merge Stream failed for Curation table: {changelogTable}" ,e)
    #post log info to splunk
    sendToSplunk(str(taskGroup["job_group_id"]), jobId, job_name, taskGroup["job_type"] +"-Merge-Notebook", taskGroup["run_type"], runId, -1, 0, str(datetime.now()), "0", taskGroup["id"], 0, changelogTable, taskGroup["target_table"], clusterId,"Failed")
   
    ##added for snowprop
    servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
    if servicenow_property:
      snow_property = servicenow_property
    else:
      snow_property = taskGroup['user_properties']
    ##added for snowprop

    #create snow ticket and send email
    errorHandler("exception", job_name,taskGroup["job_group_id"],jobId,taskGroup["job_type"],runId, -1,0,0,"0",taskGroup["id"],0,str(e).replace("\n", " "),taskGroup['email_list'],snow_property,metricsLogTable)
    
    raise Exception(f"Merge Stream failed for Curated table: {changelogTable}", e)

# COMMAND ----------

def startCurationStreamingMain(groupId,completed_streams):
  print("\n entering startCurationStreamingMain \n")

  group = getGroup(groupId)
  taskGroupList = getCurationTaskGroupList(groupId)

  if ((group["run_type"]).upper() == "ROUND_THE_CLOCK"):
    for taskGroup in taskGroupList:
      startCurateMergeStream(taskGroup)
      
  elif (group["run_type"].upper() == "AVAILABLE_NOW"):
    completed_streams_list=list(map(int, completed_streams.split(",")))
    for taskGroup in taskGroupList:
      if(taskGroup["id"] in completed_streams_list):
           startCurateMergeStream(taskGroup)
      else:
        error_message="For TaskGroup ID "+str(taskGroup["id"])+" Curation is not completed for crossing Threshold time"
        batchId=1

        ##added for snowprop
        servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
        if servicenow_property:
          snow_property = servicenow_property
        else:
          snow_property = taskGroup['user_properties']
          ##added for snowprop

        errorHandler("failed_processing_taskgroup", job_name,groupId,jobId,taskGroup["job_type"],runId,batchId,0,0,"0",taskGroup["id"],0,str(error_message),taskGroup["email_list"],snow_property,metricsLogTable)
      
  if(group['run_type'] == "AVAILABLE_NOW"): #this entire block is for #jobOrch
    print("--- entering query monitor logic ---")
    taskGroupList_log = [_["id"] for _ in taskGroupList if _["id"] not in failed_taskgroups_list]
    print(f"taskGroupList_log: {taskGroupList_log}") #done
    while(len(taskGroupList_log) != 0):
#       print(f"taskGroupList_log inside while loop: {taskGroupList_log}")

      for taskGroup in list(taskGroupList_log):
        if (taskgroup_queryid_dict[taskGroup] not in [_.id for _ in spark.streams.active]) and (taskGroup not in failed_taskgroups_list):
          persistLog_external([[taskGroup,group['job_type'],ExJ_runId,"Success",datetime.now().date(),datetime.now()]], metricsLogTable) #jobOrch
          print(f"{taskGroup} is added as success in log table, same will be removed from current loop")
          taskGroupList_log.remove(taskGroup)
        elif taskGroup in failed_taskgroups_list:
          print(f"taskgroup{taskGroup} was added to failed list, failure log will be pushed to log table, taskgroup will be removed from current loop")
          taskGroupList_log.remove(taskGroup) 
