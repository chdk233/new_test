# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string
import dateutil

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../curation_child/IOT/SmartHome_Device_Status

# COMMAND ----------

def doCuration(microBatchDF, batchId, harmonizedDB, curateDB, target_table,harmonized_table,merge_key,encryptColumns,secretKey,is_encryptdata):
  print("curateDB and targetDB are",curateDB,target_table)
  if curateDB == f"dhf_iot_curated_{environment}" and target_table == "smarthome_device_status":
    merge_sh_devc_sts(microBatchDF, batchId, harmonizedDB, curateDB, target_table)

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../curation/curation_merge_stream_master

# COMMAND ----------

startCurationStreamingMain(groupId,completed_streams) 
