# Databricks notebook source
import time

# COMMAND ----------

# target_raw_db=dbutils.widgets.get("target_raw_db")
# stage_db=dbutils.widgets.get("stage_db")
# tables=dbutils.widgets.get("tables")
# table_list=tables.split(",")
# print("target_raw_db : "+target_raw_db)
# print("stage_db : "+stage_db)
# print("table_list : ",tables)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Merge data from stage to main Database

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.databricks.delta.schema.autoMerge.enabled=true;

# COMMAND ----------

def get_tables(database):
  df=spark.sql(f"show tables in {database}")
  tables=df.select('tableName').collect()
  table_list=[]
  for table in tables:
    table_list.append(table[0])
  return table_list
def get_partitions(column,table,db):
  partitions=spark.sql(f"select  {column} from {db}.{table} where {column}=(select max({column}) from {db}.{table} )").first()
  partitions_list=[]
  for p in partitions:
    partitions_list.append(p)
  return partitions_list
def get_table_count(db,table):
  count=spark.sql(f"select count(*) from  {db}.{table}").first()[0]
  return count

# COMMAND ----------

def merge_process(stage_db,target_raw_db,table):
  print("table_list",table)
  table_list=[]
  table_list.append(str(table))
#   table_list=list((table_list).split(','))  
  
  stage_db_tables=get_tables(stage_db)
  raw_db_tables=get_tables(target_raw_db)
  for stage_table in table_list:

    if (stage_table not in raw_db_tables):
      print("stage_table",stage_table)
      spark.sql(f'create or replace table {target_raw_db}.{stage_table} PARTITIONED BY (meta_load_timestamp) as select * from {stage_db}.{stage_table} limit 0')

    
    partition_col="meta_load_timestamp"
    partitions=get_partitions(partition_col,stage_table,stage_db)
    print("partions =",partitions)
    print("no of partitions = ",len(partitions))
    
    for p in partitions:
      df_stage=spark.sql(f"select * from {stage_db}.{stage_table} where {partition_col}={p}")
      df_stage.createOrReplaceTempView("stage_partition_view")
      
      count_before_merge=get_table_count(target_raw_db,stage_table)
      print(f"count in {target_raw_db}.{stage_table} before merge = {count_before_merge}") 
      print("merge process starting for partition ",p)
      start_time = time.time()
      
      merg=f"merge into {target_raw_db}.{stage_table} as trgt using stage_partition_view as src on trgt.hash_field=src.hash_field when not matched then insert * "
      q_merg=spark.sql(merg)
      
      print(f"{target_raw_db}.{stage_table} Merge took {time.time() - start_time} seconds")

      count_after_merge=get_table_count(target_raw_db,stage_table)
      print(f"merge process comleted  for partition {p} and count in {target_raw_db}.{stage_table} after merge is {count_after_merge}")
      spark.sql("drop table   stage_partition_view")



# COMMAND ----------

# st_db="pcds_party_hrworkday_stage_dummy"
# tables=get_tables(st_db)
# print(tables)
# tgt_db="pcds_party_hrworkday_raw_dummy"
# merge_process(st_db,tgt_db,tables)


# COMMAND ----------


