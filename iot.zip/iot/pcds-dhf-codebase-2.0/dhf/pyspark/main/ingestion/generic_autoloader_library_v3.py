# Databricks notebook source
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import *
import datetime
import io
import re
import json
from itertools import groupby
from operator import itemgetter
import zipfile
import pandas as pd
from pyspark.sql.types import *
import datetime
import json
import boto3
import time
import ast
from datetime import datetime as dt
from pyspark.sql import functions as f
from pyspark.sql.session import SparkSession
from pyspark.sql import DataFrame
from pyspark.sql.functions import md5, concat_ws
from pyspark.sql import types as T
import pyspark.sql.functions as F

# COMMAND ----------

    
# def get_configs(config_table_name,job_cd):
#   sqlstring = f"select * from {config_table_name} where job_cd in({job_cd})"
#   dfconfig = spark.sql(sqlstring)
#   return dfconfig
def get_configs(job_cd):
  sqlstring = f""" (select * from ingestion_task  where job_cd in({job_cd}) )t"""
  dfconfig=spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', sqlstring).load()  
  return dfconfig

def job_cd_config_check(dataframe,job_code):
  error_job_cd_list=[]
  error_value_list=[]
  error_message=''
  for job_cd in job_code.split(','):
    if dataframe.filter(col("job_cd")==job_cd.strip(" ")).count() ==0: 
      error_job_cd_list.append(job_cd)
      continue
    if dataframe.filter((col("job_cd")==job_cd.strip(" ")) & (col("config_name")=="file_name")).count()!=1:
      error_value_list.append(job_cd)
  if len(error_job_cd_list) !=0:
    error_message=f"Please add the records in the config table for the job_cd {','.join(error_job_cd_list)}"
  if len(error_value_list) !=0:
    error_message+=f" Please add the required records in the config table for the job_cd {','.join(error_value_list)}"
  if len(error_job_cd_list) !=0 or len(error_value_list) !=0 :
      raise Exception(f"{error_message}")
      
def GenericAutoloaderInputSTream(
     sourcepath: str,
     Trigger:str,
     fileformat: str,
     maxFiletrigger: int,
     GlobFilter: str = None,
     recursive: bool = True,
     queueURL: str = None,
     region: str = "us-east-1",
     notifications: bool = True,
     inclFiles: bool = False,
     valoptions: bool = True,
  
) -> DataFrame:
    
      dfFileStream = spark.readStream.format("cloudFiles")\
      .option( "pathGlobFilter", GlobFilter)\
      .option( "recursiveFileLookup", recursive)\
      .option( "cloudFiles.format", fileformat)\
      .option( "cloudFiles.maxFilesPerTrigger", maxFiletrigger)\
      .option( "cloudFiles.queueUrl",queueURL)\
      .option( "cloudFiles.region", region)\
      .option("cloudFiles.useNotifications", notifications)\
      .option( "cloudFiles.includeExistingFiles", inclFiles)\
      .option( "cloudFiles.validateOptions", valoptions)\
      .load(sourcepath).drop("content")
      return dfFileStream
    
    
def GenericAutoloaderOutputSTream(read_stream,check_point_location,micro_batch):
  if Trigger=="True":
    read_stream\
    .writeStream\
    .trigger(once=True)\
    .queryName("read_stream")\
    .option("checkpointLocation",check_point_location)\
    .foreachBatch(micro_batch)\
    .start()
  else:
    read_stream\
    .writeStream\
    .queryName("read_stream")\
    .option("checkpointLocation",check_point_location)\
    .foreachBatch(micro_batch)\
    .start()

# COMMAND ----------

#json function for flatenning
def flatten_json_file(df):
    complex_fields = dict([
        (field.name, field.dataType) 
        for field in df.schema.fields 
        if isinstance(field.dataType, T.ArrayType) or isinstance(field.dataType, T.StructType)
    ])
    columns_to_be_renamed = []
    while len(complex_fields) != 0:
        col_name = list(complex_fields.keys())[0]
        generated_column_name = list(complex_fields.keys())[0] + "_"
        columns_to_be_renamed.append(generated_column_name)
        if isinstance(complex_fields[col_name], T.StructType):
            expanded = [F.col(col_name + '.' + k).alias(col_name + '_' + k) 
                        for k in [ n.name for n in  complex_fields[col_name]]
                       ]   
            df = df.select("*", *expanded).drop(col_name)
        elif isinstance(complex_fields[col_name], T.ArrayType): 
            df = df.withColumn(col_name, F.explode(col_name))
        complex_fields = dict([
            (field.name, field.dataType)
            for field in df.schema.fields
            if isinstance(field.dataType, T.ArrayType) or isinstance(field.dataType, T.StructType)
        ]) 
#     columns_to_be_renamed.sort(key=len, reverse=True)
#     print(columns_to_be_renamed)
#     for df_col_name in df.columns:
#       for values in columns_to_be_renamed:
#         df = df.withColumnRenamed(df_col_name, df_col_name.replace(values,""))  
    return df

# COMMAND ----------

#Function to remove special characters from string columns of a dataframe

def removeSpecialCharacters(df):
  print("inside rmSpecialCharacter function")
  for col in df.columns:
    if df.schema[col].dataType==StringType():
      df=df.withColumn(col,regexp_replace(trim(regexp_replace(col, "[^\\x20-\\x7e\\xDF\\xE4\\xF6\\xFC\\xC4\\xD6\\xDC]", "")), " [ ]+", " ",))
  print("end of rmSpecialCharacter function")
  return df


# COMMAND ----------

#Function to get target record count from raw table for current load

def getTgtRecCount(rawtable, metafilename):
  print("inside checkTgtReCount function")
  print(metafilename)
  tgtreccount=spark.sql(f"select count(*) from {rawtable} where meta_file_name=='{metafilename}'").collect()[0][0]
  print("end of checkTgtReCount function")
  return tgtreccount


# COMMAND ----------

class ErrorCC:
   def __init__(self,batchid, batchstarttime,audittype, sns_arn,error_notification,load_date,load_hour):
      self.batch_id=batchid
      self.batch_start_time=batchstarttime
      self.audit_type=audittype
      self.sns_arn=sns_arn
      self.error_notification=error_notification
      self.load_date=load_date
      self.load_hour=load_hour
      
def logToErrorTable(invalidDF,job_code,error_config_name,errorcc):
    config_record=job_configDF.filter((col("job_cd")==job_code.split(',')[-1]) & (lower(col("config_name"))==error_config_name)).first()
    error_table_name=config_record['config_value']
    invalidDF.write.format("delta").mode("append").option("mergeSchema", "true").partitionBy("LOAD_DATE").saveAsTable(f"{database_name}.{error_table_name}")
    if errorcc.error_notification=='Yes':
      run_time=datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
      job_name=invalidDF.first()['job_name']
      error_count=invalidDF.count()  
      
#Schema check for fixed with files
def schema_check(config_df,job_code,errorcc):
  job_code_list=job_code.split(',')
  print(job_code_list)
  error_list=[]
  for job_cd in job_code_list:
    job_name=config_df.filter(col("job_cd")==job_cd).first()['job_name']
    file_type=config_df.filter((col("job_cd")==job_cd)&(col("config_name")=="file_type")).first()['config_value']
    file_name=config_df.filter((col("job_cd")==job_cd)&(col("config_name")=="file_name")).first()['config_value']
    #if not(file_name.startswith("EOB") or file_name.startswith("nw_HarlMedChk")):
    if file_type.lower()=='fixed_width':
      print(file_type)
      fw_df=config_df.filter((col("job_cd")==job_cd) & (lower(col("config_name"))=="fixed_width_schema"))
      if(fw_df.count()==1):
        fw_schema=fw_df.first()['config_value']
      else: 
         fw_schema=""
      if fw_schema.strip(" ")=="":
          error_list.append((job_cd,job_name,"fixed width Schema Not Found"))
      if len(error_list) >0:
            rdd=spark.sparkContext.parallelize(error_list)
            error_DF=spark.createDataFrame(rdd).toDF("job_cd","job_name","Error_Cause")\
            .withColumn("BATCH_ID",lit(errorcc.batch_id))\
            .withColumn("BATCH_START_TIME",lit(errorcc.batch_start_time))\
            .withColumn("LOAD_DATE",lit(errorcc.load_date))\
            .withColumn("LOAD_HOUR",lit(errorcc.load_hour))\
            .withColumn("FILE_NAME",lit(""))\
            .withColumn("ERROR_COUNT",lit(1))\
            .selectExpr("cast(BATCH_ID as long) BATCH_ID","BATCH_START_TIME","job_cd","job_name","FILE_NAME","cast(ERROR_COUNT as long) ERROR_COUNT","Error_Cause","LOAD_DATE","LOAD_HOUR")
            logToErrorTable(error_DF,job_code,'error_table',errorcc) 
#Column names transformations           
def col_transformations(col_name):
  col_name_strip=col_name.strip()
  col_name_strip = " ".join(col_name_strip.split())
  col_lower=col_name_strip.lower()
  col_replace_space=col_lower.replace(" ","_")
  col_replace_underscore=col_replace_space.replace("__","_")
  col_replace_hyphen=col_replace_underscore.replace("-","_")
  col_replace_special_character=col_replace_hyphen.rstrip("?")
  return col_replace_special_character

#Send notification
def push_notification(sns_arn,failure_message,job_cd,subject): #Added by Anchal on 26th April 2022
  sts_client = boto3.client("sts")
  sns_client = boto3.Session(region_name='us-east-1').client("sns")
  topic_arn=sns_arn
#   message=f"Hi,\nThe Autoloader processing for source system with job code {job_cd}\n {failure_message}"
  sns_client.publish(
            TopicArn = topic_arn,
            Message = failure_message,
            Subject = subject)
#             Subject = f"Autoloader message for job code {job_cd}")
  print(f"mail sent ")

def column_check(dataframe,database_name,table,job_cd): #Added by Anchal on 26th April 2022
  l1 = dataframe.columns
  l1.sort()
  try:
    df1 = spark.sql(f"select * from {database_name}.{table} limit 1")
    l2 = df1.columns
    l2.sort()
    if(l1==l2):
      print("Schema has no change")
    else:
      push_notification(SNSArn,f"Hi,\n There is a column change in {table} having job code {job_cd}. The file has been processed with column change",job_cd, f"Column Change In Source File For Job Code {job_cd}")
  except:
    print(f"Table {table} not present in target database {database_name}")

#Loading data to raw_table      
def raw_table_load(dataframe,config_df,job_code,raw_table):
  print("done")
  print("raw-table ",raw_table)
  try:
    partition=config_df.filter((col("job_cd")==job_code) & (lower(col("config_name"))==f"partition_raw_{raw_table.split('.')[-1]}")).first()["config_value"]
  except:
    partition=''
  try:
    database_name=job_configDF.filter((col("job_cd")==job_code)&(col("config_name")=="database_name")).first()["config_value"]
  except:
    database_name=''
  if database_name!='':
    partition=config_df.filter((col("job_cd")==job_code) & (lower(col("config_name"))==f"partition_raw_{raw_table.split('_')[0]}")).first()["config_value"]
    column_check(dataframe,database_name,raw_table,job_code) #Added by Anchal on 26th April 2022
    dataframe.write.format("delta").partitionBy(partition).option("mergeSchema", "true").mode("append").saveAsTable(f"{database_name}.{raw_table}")
    print(f"loaded {dataframe.count()} records into the {raw_table} raw table")
  elif partition:
    table= raw_table.split(".")[-1] #Added by Anchal on 26th April 2022
    db=raw_table.split(".")[0] #Added by Anchal on 26th April 2022
    column_check(dataframe,db,table,job_code) #Added by Anchal on 26th April 2022
    dataframe.write.format("delta").partitionBy(partition).option("mergeSchema", "true").mode("append").saveAsTable(f"{raw_table}")
    print(f"loaded {dataframe.count()} records into the raw table {raw_table}")
  else:
    table= raw_table.split(".")[-1] #Added by Anchal on 26th April 2022
    db=raw_table.split(".")[0] #Added by Anchal on 26th April 2022
    column_check(dataframe,db,table,job_code) #Added by Anchal on 26th April 2022
    dataframe.write.format("delta").option("mergeSchema", "false").mode("append").saveAsTable(f"{raw_table}") 
    print(f"loaded {dataframe.count()} records into the raw table {raw_table}")
   #merge logic
  try:
    merge_check=config_df.filter((col("job_cd")==job_code)&(col("config_name")=="merge_check")).first()['config_value']
    print("in merge")
    if merge_check.lower()=="true":
      if database_name!='':
          stage_db=database_name
          tgt_table=raw_table
      else:
          stage_db=raw_table.split(".")[0]
          tgt_table=raw_table.split(".")[-1]
      merge_tgt_db=config_df.filter((col("job_cd")==job_code)&(col("config_name")=="merge_tgt_db")).first()['config_value']
      merge_process(stage_db,merge_tgt_db,tgt_table)
  except:
    print("source system not included for merge ")
  #recon notebook 
  #source name as job parameter or cfg parameter
  meta_file_name=dataframe.select("meta_file_name").first()[0]
  try:
    recon_check=config_df.filter((col("job_cd")==job_code)&(col("config_name")=="recon_check")).first()['config_value']
    file_type=config_df.filter((col("job_cd")==job_code)&(col("config_name")=="file_type")).first()['config_value']
    print(file_type)
    if(recon_check.lower()=="true" and file_type !="splitting"):
      try:
        print("Recon process started for job code",job_code)
        reconcillation(SNSArn,job_code,config_df,meta_file_name)
      except:
        print("Recon process failed for job code",job_code)
  except:
    print("source system not included for recon ")

  
def add_hash_col(df):
  df = df.withColumn("hash_field", md5(concat_ws("", *df.columns)))
  return df


def handleMicroBatch(microbatchDF,batch_id):
  try:
    print(f"Running autoloader at {str(datetime.now())}")
    
    batchSize = microbatchDF.count()
    
    print('batchSize: ',batchSize)
    count_error_message=f"Record count between source file and data loaded in target raw table doesn't match."
    if(batchSize>0):
      batch_start_time=str(datetime.now())
      #load_timestamp  = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
      load_date=datetime.now().strftime('%Y-%m-%d')
      load_hour=str(datetime.now().strftime('%H'))+'00'
      file_path_list = [filename["path"] for filename in microbatchDF.select("path").collect()]
      print("file_path_list: "+str(file_path_list))
      job_cd_list=JobCode.split(',')
      print(job_cd_list)
      for job_cd in job_cd_list:
          file_name=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="file_name")).first()['config_value']
          file_type=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="file_type")).first()['config_value']
          file_source_name= job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="recon_source_name")).first()['config_value']
          print(file_name,file_type,file_source_name,job_cd)
          file_path_str = " |".join(file_path_list) # Added by Anchal and Rani on 26th April 2022
          if str(file_name[:-1]).lower() in str(file_path_str).lower(): # Added by Anchal and Rani on 26th April 2022
            if(file_type.lower()=='delimeter' or file_type.lower()=='delimiter'):
              print("Inside delimiter files") 
              file_delimiter=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="file_delimeter")).first()['config_value']
              header=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="header")).first()['config_value']
              for file_path in file_path_list:
                load_timestamp  = datetime.now().strftime('%Y%m%d%H%M%S')
                print("printing file path",file_path)
                print("Source file name: ",file_path.split('/')[-1])
                source_file_format=str(file_path.split('/')[-1]).split('.')[-1]
                print("Source file format: ",source_file_format)
                config_file_format=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="file_format")).first()['config_value']
                fileformat_error_message=f" Format of the source file received as {source_file_format} doesn't match with format defined in config as {config_file_format}"
                if(source_file_format!=config_file_format):
                  print("File format check failed.")
                  raise Exception(f"{fileformat_error_message}") 
                else:
                  print("Format of source file and file_format defined in config table matches.")
                if(file_name[:-1] in file_path):
                  print(file_name[:-1])
                  if file_source_name=="Anaplan":
                    if(header.lower()=="true"):
                      newdf=spark.read.format('csv').option("header",True).option("inferSchema",False).option("delimiter",file_delimiter).option("escape", '"').load(file_path)       
                      if job_cd=='1000' or job_cd=='1001':
                        search_string=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="recon_search_string")).first()['config_value']
                        replace_string=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="recon_replace_string")).first()['config_value']
                        ctl_file_path=file_path.replace(search_string,replace_string)
                        ctl_df=spark.read.format('csv').option("header",True).option("delimiter",file_delimiter).load(ctl_file_path)
                        as_of_date=ctl_df.select("As of Date").first()[0]
                        newdf=newdf.withColumn("as_of_date",lit(as_of_date))
                    if(header.lower()=="false"):
                      newdf=spark.read.format('csv').option("header",False).option("inferSchema",False).option("delimiter",file_delimiter).option("escape", '"').load(file_path)
                      fheader=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="header_value")).first()['config_value']
                      fheader=fheader.split(file_delimiter)
                      for i,j in zip(newdf.columns,fheader):  
                        newdf=newdf.withColumnRenamed((i),j)
                      print(newdf)
                      #new lines of code added for CAB 1/11/2023 203-211
                  elif file_source_name=="CAB" and job_cd=='7016':
                    if(header.lower()=="true"):
                      newdf=spark.read.format('csv').option("header",True).option("inferSchema",False).option("quote",'').option("delimiter",file_delimiter).load(file_path)
                    if(header.lower()=="false"):
                      newdf=spark.read.format('csv').option("header",True).option("inferSchema",False).option("quote",'').option("delimiter",file_delimiter).load(file_path)
                      fheader=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="header_value")).first()['config_value']
                      fheader=fheader.split(file_delimiter)
                      for i,j in zip(newdf.columns,fheader):
                        newdf=newdf.withColumnRenamed((i),j)
#                       print(newdf)
                  else:
                    if(header.lower()=="true"):
                      newdf=spark.read.format('csv').option("header",True).option("inferSchema",False).option("delimiter",file_delimiter).load(file_path)       
                    if(header.lower()=="false"):
                      newdf=spark.read.format('csv').option("header",False).option("inferSchema",False).option("delimiter",file_delimiter).load(file_path)
                      fheader=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="header_value")).first()['config_value']
                      fheader=fheader.split(file_delimiter)
                      for i,j in zip(newdf.columns,fheader):  
                        newdf=newdf.withColumnRenamed((i),j)
                      print(newdf)
                  for col_name in newdf.columns:
                    new_col_name=col_transformations(col_name)
                    newdf=newdf.withColumnRenamed(col_name, new_col_name)
                  meta_file_name=file_path.split("/")[-1]
                  unique_key_cols=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="unique_key")).first()['config_value']
                  unique_key_cols_list = unique_key_cols.split(",")
                  print(unique_key_cols_list)
                  if newdf.count() > newdf.dropDuplicates(unique_key_cols_list).count():
                    print(f"Below is duplicate data found on {unique_key_cols} in file:")
                    newdf.groupBy(unique_key_cols_list).count().where('count>1').show()
                    raise ValueError(f"Data has duplicates in cols {unique_key_cols}.")
                  else:
                    print(f"No duplicate data found in cols {unique_key_cols}.")
                  raw_table=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="raw_table")).first()['config_value']
                  srcreccount=newdf.count()  
                  print("Source record count: ",srcreccount)
                  newdf=removeSpecialCharacters(newdf)
                  newdf=add_hash_col(newdf)
                  raw_table_load(newdf.withColumn("meta_load_timestamp",lit(load_timestamp)).withColumn("meta_file_name",                                               lit(meta_file_name)),job_configDF,job_cd,raw_table)
                  print("Table loaded successfully")
                  tgtreccount=getTgtRecCount(raw_table,meta_file_name)
                  print("Target raw table record count: ",tgtreccount)
                  if srcreccount!=tgtreccount:
                    raise Exception(f"{count_error_message}") 
                  else:
                    print("Record count between source file and data loaded in target raw table matches.")
            #fixed with files  
            if(file_type=='fixed_width'):
              for file_path in file_path_list:
                  load_timestamp  = datetime.now().strftime('%Y%m%d%H%M%S')
                  source_file_format=str(file_path.split('/')[-1]).split('.')[-1]
                  print("Source file format: ",source_file_format)
                  config_file_format=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="file_format")).first()['config_value']
                  fileformat_error_message=f" Format of the source file received as {source_file_format} doesn't match with format defined in config as {config_file_format}"
                  if(source_file_format!=config_file_format):
                    print("File format check failed.")
                    raise Exception(f"{fileformat_error_message}") 
                  else:
                    print("Format of source file and file_format defined in config table matches.")
                  if(file_name[:-1] in file_path):
                    aisDF = spark.read.format("text").load(file_path)
                    fixed_width_col_defs=eval(job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="fixed_width_schema")).first()['config_value'])
                    for key in fixed_width_col_defs:
                      aisDF = aisDF.withColumn(key, aisDF.value.substr(fixed_width_col_defs[key][0], fixed_width_col_defs[key][1]))
                    for col_name in aisDF.columns:
                      new_col_name=col_transformations(col_name)
                      aisDF=aisDF.withColumnRenamed(col_name, new_col_name)
                    meta_file_name=file_path.split("/")[-1]
                    unique_key_cols=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="unique_key")).first()['config_value']
                    unique_key_cols_list = unique_key_cols.split(",")
                    print(unique_key_cols_list)
                    if aisDF.count() > aisDF.dropDuplicates(unique_key_cols_list).count():
                      print(f"Below is duplicate data found on {unique_key_cols} in file:")
                      aisDF.groupBy(unique_key_cols_list).count().where('count>1').show()
                      raise ValueError(f"Data has duplicates in cols {unique_key_cols}.")
                    else:
                      print(f"No duplicate data found in cols {unique_key_cols}.")
                    raw_table=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="raw_table")).first()['config_value']
                    srcreccount=aisDF.count()  
                    print("Source record count: ",srcreccount)
                    aisDF=removeSpecialCharacters(aisDF)
                    aisDF=add_hash_col(aisDF)
                    raw_table_load(aisDF.withColumn("meta_load_timestamp",lit(load_timestamp)).withColumn("meta_file_name" ,lit(meta_file_name)).drop("value"),job_configDF,job_cd,raw_table) 
                    tgtreccount=getTgtRecCount(raw_table,meta_file_name)
                    print("Target raw table record count: ",tgtreccount)
                    if srcreccount!=tgtreccount:
                      raise Exception(f"{count_error_message}")
                    else:
                      print("Record count between source file and data loaded in target raw table matches.") 
              #splitting width files based on position
            if(file_type=="splitting"):
              for file_path in file_path_list:
                load_timestamp  = datetime.now().strftime('%Y%m%d%H%M%S')
                source_file_format=str(file_path.split('/')[-1]).split('.')[-1]
                print("Source file format:",source_file_format)
                config_file_format=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="file_format")).first()['config_value']
                fileformat_error_message=f" Format of the source file received as {source_file_format} doesn't match with format defined in config as {config_file_format}"
                if(source_file_format!=config_file_format):
                  print("File format check failed.")
                  raise Exception(f"{fileformat_error_message}")
                else:
                  print("Format of source file and file_format defined in config table matches.")
                if(file_name[:-1] in file_path):
                  df=spark.read.format("text").load(file_path)
                  lower_limit=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="lower_limit")).first()["config_value"]
                  upper_limit=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="upper_limit")).first()["config_value"]
                  df = df.withColumn('Record_Qualifier',df.value.substr(int(upper_limit),int(lower_limit))).orderBy('Record_Qualifier')
  #                 display(df)
                  table_dict=eval(job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="table_dict")).first()["config_value"])
                  table_list=list(table_dict.keys())
                  for table in table_list:
                    print("table name ",table)
                    value_record=table_dict.get(table)
                    print("value_record: ",value_record)
  #                   df=df.repartition(256)
                    df_final = df.filter(col("Record_Qualifier")==value_record)
                    df_final.createOrReplaceTempView("TEMP_TABLE")  
                    schema=eval(job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")==table)).first()["config_value"])
                    create_row_statement=""
                    for colinfo in schema:
                      new_col_name=col_transformations(colinfo[0])
                      if len(create_row_statement) < 2:
                        create_row_statement="Record_Qualifier,substring(value , " +str(colinfo[1])+"," + str(colinfo[2])  + ") as " + new_col_name
                      else:
                        create_row_statement = create_row_statement + ",substring(value , " +str(colinfo[1])+"," +str(colinfo[2]) + ") as " + new_col_name
                    prep_sql_statement = f"SELECT {create_row_statement} FROM TEMP_TABLE"
                    df_final = spark.sql(prep_sql_statement)
                    df_final.persist()
#                     display(df_final)
                    meta_file_name=file_path.split("/")[-1]
                    unique_key_cols=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="unique_key")).first()['config_value']
                    unique_key_cols_list = unique_key_cols.split(",")
                    print(unique_key_cols_list)
                    if df_final.count() > df_final.dropDuplicates(unique_key_cols_list).count():
                      print(f"Below is duplicate data found on {unique_key_cols} in file:")
                      df_final.groupBy(unique_key_cols_list).count().where('count>1').show()
                      raise ValueError(f"Data has duplicates in cols {unique_key_cols}.")
                    else:
                      print(f"No duplicate data found in cols {unique_key_cols}.")
                    srcreccount=df_final.count()  
                    print("Source record count: ",srcreccount)
                    if(df_final.count()>0):
                      df_final=removeSpecialCharacters(df_final)
                      df_final=add_hash_col(df_final)
                      print(df_final.rdd.getNumPartitions())
                      raw_table_load(df_final.withColumn("meta_load_timestamp",lit(load_timestamp)).withColumn("meta_file_name" ,lit(meta_file_name)).drop("value","Record_Qualifier"),job_configDF,job_cd,table)
                      tgtreccount=getTgtRecCount(table,meta_file_name)
                      print("Target raw table count: ",tgtreccount)
                      if srcreccount!=tgtreccount:
                        raise Exception(f"{count_error_message}") 
                      else:
                        print("Record count between source file and data loaded in target raw table matches.")
                    df_final.unpersist()
                  try:
                    recon_check=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="recon_check")).first()['config_value']
                    if(recon_check.lower()=="true"):
                      try:
                          print("Recon process started for job code",job_cd)
                          reconcillation(SNSArn,job_cd,job_configDF,meta_file_name)
                      except:
                          print("Recon process failed for job code",job_cd)
                  except:
                    print("source system not included for recon")
            if(file_type.lower() == "json"):
              for file_path in file_path_list:
                if(file_name[:-1] in file_path):
                  load_timestamp  = datetime.now().strftime('%Y%m%d%H%M%S')
                  json_schema = job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="schema")).first()['config_value']
                  json_schema = eval(json_schema)
                  df_json = spark.read.format('json').schema(json_schema).load(file_path)
                  flattened_json_file = flatten_json_file(df_json)
                  unique_key_cols=job_configDF.filter((col("job_cd")==job_cd) & (col("config_name")=="unique_key")).first()['config_value']
                  unique_key_cols_list = unique_key_cols.split(",")
                  print(unique_key_cols_list)
                  if flattened_json_file.count() > flattened_json_file.dropDuplicates(unique_key_cols_list).count():
                    print(f"Below is duplicate data found on {unique_key_cols} in file:")
                    flattened_json_file.groupBy(unique_key_cols_list).count().where('count>1').show()
                    raise ValueError(f"Data has duplicates in cols {unique_key_cols}.")
                  else:
                    print(f"No duplicate data found in cols {unique_key_cols}.")
                  raw_table=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="raw_table")).first()['config_value']
                  try:
                    partition_col = job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="partition_col")).first()['config_value']
                  except:
                    partition_col= ''
                  if(len(partition_col)>0):
                    flattened_json_file.write.format('delta').partitionBy(partition_col).mode('append').saveAsTable(raw_table)
                  else:
                    flattened_json_file.write.format('delta').mode('append').saveAsTable(raw_table)
#raw_table_load(job_configDF.withColumn("meta_load_timestamp",lit(load_timestamp)).withColumn("meta_file_name" ,lit(meta_file_name)).drop("value"),job_configDF,job_cd,raw_table) 
          else:
            current_date = datetime.now().strftime('%Y%m%d') #Added by Anchal on 05th May 2022
            file_name1=file_name[:-1]
            try:
              recon_table=job_configDF.filter((col("job_cd")==job_cd)&(col("config_name")=="recon_table")).first()['config_value'] #Added by Anchal on 05th May 2022
              df= spark.sql(f"select source, meta_load_timestamp,meta_file_name from {recon_table} where source= '{file_source_name}' and left(meta_load_timestamp,8) = {current_date} and meta_file_name like '{file_name1}%' order by meta_load_timestamp desc") #Added by Anchal on 05th May 2022
              count=df.count()
            except:
              print("no recoon table for src system")
              count=0
            if count==0:
              push_notification(SNSArn,f"Hi,\n The autoloader process for source system with {job_cd} has been failed. \n Reason:No Files present in S3 bucket for {file_name1}.",job_cd, f"Autoloader Message For Job Code {job_cd}") # Added by Anchal and Rani  on 26th April 2022
            else:
              print("file already processed")
    

  except:
    raise Exception("error occured")

# COMMAND ----------


