# Databricks notebook source
import datetime

# COMMAND ----------

dbutils.widgets.removeAll()
# dbutils.widgets.text("ConfigTableName", defaultValue="")
# dbutils.widgets.text("MaxFilesPerTrigger", defaultValue="")
# dbutils.widgets.text("AutoloaderGlobFilter", defaultValue="")
# dbutils.widgets.text("CloudFilesQueueUrl", defaultValue="")
# dbutils.widgets.text("SourceS3Loc", defaultValue="")
# dbutils.widgets.text("CheckPointLocation", defaultValue="")
# dbutils.widgets.text("SNSArn", defaultValue="")
# JobCode=dbutils.widgets.get("JobCode")
# ConfigTableName=dbutils.widgets.get("ConfigTableName")
# MaxFilesPerTrigger=dbutils.widgets.get("MaxFilesPerTrigger")
# AutoloaderGlobFilter=dbutils.widgets.get("AutoloaderGlobFilter")
# CloudFilesQueueUrl=dbutils.widgets.get("CloudFilesQueueUrl")
# SourceS3Loc=dbutils.widgets.get("SourceS3Loc")
# CheckPointLocation=dbutils.widgets.get("CheckPointLocation")
# SNSArn=dbutils.widgets.get("SNSArn")
# dbutils.widgets.text("Trigger", defaultValue="")
# Trigger=dbutils.widgets.get("Trigger")


# COMMAND ----------

groupId = int(dbutils.widgets.get("groupId"))
environment = dbutils.widgets.get("environment")

print("groupId is :",groupId)
print("environment",environment)

# COMMAND ----------

# MAGIC %run "./Reconciliation_v3"

# COMMAND ----------

# MAGIC %run "./merge_notebook"

# COMMAND ----------

# MAGIC %run "./generic_autoloader_library_v3"

# COMMAND ----------

# MAGIC %run ../../utils/_utils

# COMMAND ----------

taskGroupList = getingestionTaskGroupList(groupId)

# COMMAND ----------

taskGroupList_1 = taskGroupList[0]
taskGroupId = taskGroupList_1['id']
MaxFilesPerTrigger=taskGroupList_1['max_files_per_trigger']
AutoloaderGlobFilter=taskGroupList_1['auto_loader_glob_filter']
CloudFilesQueueUrl=taskGroupList_1['cloud_files_queue_url']
SourceS3Loc=taskGroupList_1['source_s3_loc']
CheckPointLocation=taskGroupList_1['check_point_location']
SNSArn=taskGroupList_1['sns_arn']
Trigger=taskGroupList_1['trigger']
print("taskGroupId :",taskGroupId, "\n","CloudFilesQueueUrl :",CloudFilesQueueUrl,"\n","SourceS3Loc :",SourceS3Loc,"\n","CheckPointLocation :",CheckPointLocation,"\n","Trigger",Trigger)                                   

# COMMAND ----------

JobCode = getingestionJobCodes(taskGroupId)
print(JobCode)

# COMMAND ----------

if(JobCode):
  job_configDF=get_configs(JobCode)
  display(job_configDF)
  job_cd_config_check(job_configDF,JobCode)
  batch_start_time=str(datetime.now())
  load_date=datetime.now().strftime('%Y-%m-%d')
  load_hour=str(datetime.now().strftime('%H'))+'00'
  schema_check(job_configDF,JobCode,ErrorCC(0,batch_start_time,'Schema Check',SNSArn,'No',load_date,load_hour))
else:
  raise Exception(f'no job codes are active in task level for the task group {taskGroupId}')

# COMMAND ----------

#Autoloader Read Stream
read_stream_files=GenericAutoloaderInputSTream(
     sourcepath=SourceS3Loc,
     fileformat="binaryFile",
     maxFiletrigger=MaxFilesPerTrigger,
     GlobFilter=AutoloaderGlobFilter,
     recursive = True,
     queueURL=CloudFilesQueueUrl,
     region = "us-east-1",
     notifications= True,
     inclFiles= False,
     valoptions = True,
     Trigger=True
)
GenericAutoloaderOutputSTream(read_stream_files,CheckPointLocation,handleMicroBatch)
