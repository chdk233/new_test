# Databricks notebook source
import datetime
from datetime import timedelta
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
import re

schema = StructType([
  StructField('source', StringType(), True),
  StructField('source_row_count', IntegerType(), True),
  StructField('target_row_count', IntegerType(), True),
  StructField('database_name', StringType(), True),
  StructField('table_name', StringType(), True),
  StructField('control_file_name', StringType(), True),
  StructField('meta_file_name', StringType(), True),
  StructField('reconciliation_status', StringType(), True),
  StructField('message', StringType(), True),
  StructField('meta_load_timestamp', StringType(), True),
  ])

# COMMAND ----------

def getConfigDetails(job_cd,job_configDF,metafilename):
  file_type=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_file_type")).first()['config_value']
  file_path=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_source_file_path")).first()['config_value']
  source_name=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_source_name")).first()['config_value']
  recon_table=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_table")).first()['config_value']
  search_string=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_search_string")).first()['config_value']
  replace_string=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_replace_string")).first()['config_value']
  ctlfilename = metafilename.replace(search_string,replace_string)
  filename = file_path+ctlfilename
  return file_type,file_path,source_name,recon_table,ctlfilename,filename

# COMMAND ----------

def push_notification_recon(sns_arn,failure_message,job_cd,source_name):
  sts_client = boto3.client("sts")
  sns_client = boto3.Session(region_name='us-east-1').client("sns")
  topic_arn=sns_arn
  message=f"Hi,\nThe Reconciliation for source system {source_name} with  job code {job_cd} failed.\nReason {failure_message}"
  sns_client.publish(
            TopicArn = topic_arn,
            Message = message,
            Subject = f"Recon failure for  {job_cd}")
  print(f"mail sent ")

# COMMAND ----------

def getTargetRecordCount(job_cd, job_configDF, meta_file_name):
    try:
      target_table=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="raw_table")).first()['config_value']
      target_count=spark.sql(f'select count(*) from {target_table} where meta_file_name="{meta_file_name}"').first()[0]
      tablename=target_table.split(".")[-1]
      database_name=target_table.split(".")[-2]
    except:
      table_dict=eval(job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="table_dict")).first()["config_value"])
      table_list=list(table_dict.keys())
      database_name= job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="database_name")).first()["config_value"]
      target_count=0
      tablename = {}
      for table in table_list:
        try:
          target_row_count = spark.sql(f'select count(*) from {database_name}.{table} where meta_file_name ="{meta_file_name}"').first()[0]
          target_count=target_count+target_row_count
          if target_row_count != 0:
            tablename.update({table:target_row_count})
        except:
          print("table not created yet")
    return target_count,tablename,database_name

# COMMAND ----------

def reconciliationCheck(sns_arn,job_cd,source_name,source_row_count,target_row_count):
  if (source_row_count==target_row_count):
    reconciliation_status="Success"
    message="Source record count and target  records count is same."
  elif (source_row_count<target_row_count):
    reconciliation_status="Failed"
    message="Source record count is less than target  records count."
    push_notification_recon(sns_arn,message,job_cd,source_name)
  elif (source_row_count>target_row_count):
    reconciliation_status="Failed"
    message="Source record count is greater than target  records count."
    push_notification_recon(sns_arn,message,job_cd,source_name)
  return reconciliation_status,message;

# COMMAND ----------

def writeReconciliationToAuditTable(source,source_row_count, target_row_count, database_name, table_name, source_file_name, meta_file_name, reconciliation_status,message,recon_table):
  meta_load_timestamp=load_timestamp  = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
  df = spark.createDataFrame([(source,source_row_count, target_row_count, database_name, table_name, source_file_name, meta_file_name, reconciliation_status, message,meta_load_timestamp)], schema) 
  df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{recon_table}")
  print("recon process completed")
  print("Recon table ",recon_table)
#   display(df)

# COMMAND ----------

def get_configs(config_table_name,job_cd):
  sqlstring = f"select * from {config_table_name} where JOB_CD in({job_cd})"
  dfconfig = spark.sql(sqlstring)
  return dfconfig

# COMMAND ----------

def reconcillation(SNSArn,job_code,job_configDF,metafilename):
  job_code_list=job_code.split(",")
  print(job_code_list)
  if (len(job_code_list)>0):
    for job_cd in job_code_list:
      try:
        ctrl_file_flag=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_control_file_flag")).first()['config_value']
        if ctrl_file_flag.lower()=='yes':
          file_type,file_path,source_name,recon_table,ctlfilename,filename = getConfigDetails(job_cd,job_configDF,metafilename)
          if(file_type.lower()=='delimeter' or file_type.lower()=='delimiter'):
            header=job_configDF.filter((col("JOB_CD")==job_cd) & (col("config_name")=="recon_file_header")).first()['config_value']
            delimiter=job_configDF.filter((col("JOB_CD")==job_cd) & (col("config_name")=="recon_file_delimeter")).first()['config_value']
            pos=eval(job_configDF.filter((col("JOB_CD")==job_cd) & (col("config_name")=="recon_count_col_pos")).first()['config_value'])
            
            if (header.lower()=="true"):#recon_header
              df = spark.read.format("csv").option("delimiter",delimiter).option("header",True).load(filename).withColumn("source_file_name",input_file_name())
            else:
              df = spark.read.format("csv").option("delimiter",delimiter).option("header",False).load(filename).withColumn("source_file_name",input_file_name())
            source_row_count=int(re.findall(r'\d+',df.select(col(df.columns[pos])).first()[0])[0])

          elif(file_type=='fixed_width'):
            df = spark.read.format("text").load(filename).withColumn("source_file_name",input_file_name())
            pos=eval(job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_count_col_pos")).first()['config_value'])
            for key in pos:
              df = df.withColumn(key, df.value.substr(pos[key][0], pos[key][1]))
            source_row_count=int(df.select(col(df.columns[2])).first()[0])
          else:
            print("control file is niether delimited or fixed width")
            
          try:
            meta_file_names_from_Audit=spark.sql(f'select meta_file_name from {recon_table} where source ="{source_name}" and meta_file_name="{metafilename}"').first()[0]
            print("file present in audit table or table doesnt exist in audit table")
          except:              
            target_row_count,tablename,database_name = getTargetRecordCount(job_cd, job_configDF, metafilename)
            reconciliation_status,message = reconciliationCheck(SNSArn,job_code,source_name,source_row_count,target_row_count)
            writeReconciliationToAuditTable(source_name,source_row_count, target_row_count, database_name,tablename, ctlfilename, metafilename,reconciliation_status,message,recon_table)

        else:
          ctlfilename=''
          file_path=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_source_file_path")).first()['config_value']
          filename = file_path+metafilename
          file_type=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="file_type")).first()['config_value']
          if(file_type.lower()=='delimeter' or file_type.lower()=='delimiter'):
            header=job_configDF.filter((col("JOB_CD")==job_cd) & (col("config_name")=="header")).first()['config_value']
            delimiter=job_configDF.filter((col("JOB_CD")==job_cd) & (col("config_name")=="file_delimeter")).first()['config_value']
            if (header.lower()=="true"):
              df = spark.read.format("csv").option("delimiter",delimiter).option("header",True).load(filename).\
              withColumn("source_file_name",input_file_name())
            else:
              df = spark.read.format("csv").option("delimiter",delimiter).option("header",False).load(filename).withColumn("source_file_name",input_file_name())
          else:
            df=spark.read.format("text").load(filename).withColumn("source_file_name",input_file_name())
          source_row_count = df.count()
          source_name=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_source_name")).first()['config_value']
          recon_table=job_configDF.filter((col("JOB_CD")==job_cd)&(col("config_name")=="recon_table")).first()['config_value']
          target_row_count,tablename,database_name = getTargetRecordCount(job_cd, job_configDF, metafilename)
          reconciliation_status,message = reconciliationCheck(SNSArn,job_code,source_name,source_row_count,target_row_count)
          writeReconciliationToAuditTable(source_name,source_row_count, target_row_count, database_name,tablename, ctlfilename, metafilename,reconciliation_status,message,recon_table)
      except:
        print("Table , file or view not found in delta or s3 location ")

# COMMAND ----------


