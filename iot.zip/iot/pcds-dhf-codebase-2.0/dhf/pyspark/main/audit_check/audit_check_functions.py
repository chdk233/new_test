# Databricks notebook source
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.window import *
import time
from datetime import datetime 
from pyspark.sql.types import *
import json
from datetime import date
from datetime import timedelta
import pytz
UTC = pytz.utc

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("groupId","","group_id") 
dbutils.widgets.text("environment","","environment")
dbutils.widgets.text("logDb","","log_db_name")
dbutils.widgets.text("jobStatusLog","","Job_Status_Log")
groupId=int(dbutils.widgets.get("groupId"))
environment=str(dbutils.widgets.get("environment"))
logDb=str(dbutils.widgets.get("logDb"))
jobStatusLog=str(dbutils.widgets.get("jobStatusLog"))

print("groupId in notebook is : ",groupId)
print("environment in notebook is : " , environment)
print("logDb in notebook is : ",logDb)
print("jobStatusLog in notebook is : ",jobStatusLog)

# COMMAND ----------

# MAGIC %run ../../utils/_utils

# COMMAND ----------

context_str = dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
context = json.loads(context_str)
job_id = int(context.get('tags', {}).get('jobId', '0')) 
run_id_obj = context.get('currentRunId', {})
run_id = int(run_id_obj.get('id', '0') if run_id_obj else '0')

JobLogTable = StructType([ \
    StructField("job_type",StringType(),True), \
    StructField("log_output",StringType(),True), \
    StructField("job_id",LongType(),True), \
    StructField("table_name", StringType(), True), \
    StructField("run_id", LongType(), True), \
    StructField("date_time", StringType(), True) ,\
    StructField("group_id", LongType(), True)
  ])


# COMMAND ----------

def getTableList(groupId):
  pushdown_query = f"""( SELECT *  FROM audit_config_new_msapps where active and job_group_id={groupId}  ) t """                  #modified
  print(pushdown_query)
  tablelist_df=spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  
  tablelist=list(map(lambda row:row.asDict(),tablelist_df.collect()))              
  print(tablelist)
  return(tablelist)

# COMMAND ----------

def persistLog(jobMetrics, logTable) :
  df = spark.createDataFrame(jobMetrics,JobLogTable).coalesce(1)
  df.write.format("delta").mode("append").saveAsTable(f"{logDb}.{logTable}")

# COMMAND ----------

def surrogateCheck(groupId,config,domain_email_dl,email_from):
  print("We are in the surrogate Audit checks")
  surrogateColumn = config['surrogate_column_name'] 
  databaseName = config['target_database'] 
  targetTable = config['target_table'] 
  targettb  = f"{databaseName}.{targetTable}"
  logTable = config['log_table_name'] 
  job_type = config['type'] 
  date_time = time.asctime(time.localtime(time.time()))
  print(f"The surrogate audit checks infos of, surrogateColumn:{surrogateColumn} table:{targettb} job_type: {job_type}")
  
  if (surrogateColumn==None or len(surrogateColumn)==0):
    raise Exception(f"You missed to provide surrogateColumn value in UI config.")
    
  query_sql = spark.sql(f'select {surrogateColumn},count(*) as count from {databaseName}.{targetTable} group by {surrogateColumn} having count > 1')
  
  if query_sql.first()==None:
    print("No Duplicates found in Surrogate Check for the table:",targettb)
  else:
    print("Duplicates found in Surrogate Check for the table:",targettb)
    query_output = json.dumps(list(map(lambda row:row.asDict(),query_sql.collect())))
    jobMetrics = [[job_type, query_output, job_id, targetTable, run_id, date_time, groupId]]
    persistLog(jobMetrics, logTable)
    print("The logs of surrogate duplicates are captured in the log table:",logTable)
    
    mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from);

# COMMAND ----------

def rowCount(groupId,config,domain_email_dl,email_from):
  print("We are in the rowCount Audit checks")
  databaseName = config['target_database'] 
  targetTable = config['target_table'] 
  targettb  = f"{databaseName}.{targetTable}"
  logTable = config['log_table_name']
  job_type = config['type']
  sqlQuery = config['source_query']
  tgtQuery = config['target_query']   #modified
  print("The given sqlQuery:",sqlQuery)
  threshold = config['threshold_value'] 
  date_time = time.asctime(time.localtime(time.time()))
  
  if (sqlQuery==None or threshold==None or tgtQuery==None):
    raise Exception(f"You missed to provide sqlQuery or threshold value or targetQuery in UI config.")
    

  sourceSqlQueryCount = spark.sql(sqlQuery).count() #need to check on sql query "count(*) or "*"
  #targetTableCount = spark.sql(f'select * from {databaseName}.{targetTable}').count()
  targetTableCount = spark.sql(tgtQuery).count()                                                        #modified
  print(f"The count of the source:{sourceSqlQueryCount}, The count of the target:{targetTableCount}")
  countDiff = sourceSqlQueryCount - targetTableCount
  print(f"The count difference between source and target: {countDiff}")
  #varianceCalc = abs(sourceSqlQueryCount - targetTableCount)/100                                       #modified
  varianceCalc = (sourceSqlQueryCount - targetTableCount)/100                                       #modified
  if varianceCalc <=0:
    varianceCalc = -(varianceCalc)
  print(f"The calculated variance difference between source and target: {varianceCalc}")                 #modified
  print(f"The given Threshold value:{threshold}")
   
  if varianceCalc > threshold:                                                                          #modified
    query_output = '[{'f'"Variance_difference": {varianceCalc},"threshold_provided": {threshold}''}]'    #modified
    jobMetrics = [[job_type, query_output , job_id, targetTable, run_id, date_time, groupId]]
    persistLog(jobMetrics,logTable) 
    print("The logs of the count diff are captured in the log table:",logTable)
    
    mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from)
  else:
    print("The row count between the source and target are getting matched")

# COMMAND ----------

def aggregation(groupId,config,domain_email_dl,email_from):
  print("We are inside the aggregation Audit checks")
  tgtDbName = config['target_database'] 
  targetTable = config['target_table'] 
  targetTb  = f"{tgtDbName}.{targetTable}"
  logTable = config['log_table_name']
  job_type = config['type']
  srcQuery = config['source_query']
  tgtQuery = config['target_query']
  print("The given source sqlQuery:",srcQuery)
  print("The given target sqlQuery:",tgtQuery)
  threshold = config['threshold_value'] 
  date_time = time.asctime(time.localtime(time.time()))
  
  if (srcQuery==None  or tgtQuery==None):
    raise Exception(f"You missed to provide Source sqlQuery or Target sqlQuery in UI config.")
    

  sourceDf = spark.sql(srcQuery) 
  targetDf = spark.sql(tgtQuery)
  
  print("The source aggregation... ") 
  sourceDf.show()
  print("The target aggregation... ") 
  targetDf.show()
  
  wsrc  = Window.orderBy(*sourceDf.columns)
  srcDF = sourceDf.withColumn("row_id", row_number().over(wsrc))
  wtgt  = Window.orderBy(*targetDf.columns)
  tgtDF = targetDf.withColumn("row_id", row_number().over(wtgt))
  
  conditions_ = [when(srcDF[c]!=tgtDF[c], c).otherwise("") for c in srcDF.columns if c != 'row_id']
  select_expr =[
                col("row_id"), 
                *[tgtDF[c] for c in tgtDF.columns if c != 'row_id'], 
                array_remove(array(*conditions_), "").alias("mismatch_columns")]
  resDf = srcDF.join(tgtDF, "row_id").select(*select_expr)
  resDf.show()
  aggCols = resDf.first()['mismatch_columns']
  print("Validation result for the aggregationCheck..",aggCols)

  if not aggCols:
    print("Success, the aggregationCheck for the columns between source and target are matching")
  else:
    print("Failed..the aggregationCheck for the columns between source and target are not matching ")
    print("the mismatched columns..",*aggCols)
    jobMetrics = [[job_type, str(aggCols) , job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
    persistLog(jobMetrics,logTable) 
    print("The logs of the mismatched columns are captured in the log table:",logTable)
          
    mailbodycreation(job_type, str(aggCols), job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type

# COMMAND ----------

def mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from):
  subject= f"DHF AUDIT CHECK LOGS GROUP ID {groupId}"
  body = "<html><head><style>table {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}td, th {border: 1px solid #dddddd;text-align: left;padding: 8px;}tr:nth-child(even) {background-color: #dddddd;}</style></head><body><p> Good Day! </p><p>Please find below the DHF Audit Check results: </p>"
  strTable = "<table><tr bgcolor=Aquamarine><th>job_type</th><th>query_output</th><th>job_id</th><th>targetTable</th><th>run_id</th><th>date_time</th><th>groupId</th></tr>"
  strTable = body+strTable
  job_type = str(job_type)
  query_output = str(query_output)
  job_id = str(job_id)
  targetTable = str(targetTable)
  run_id = str(run_id)
  date_time = str(date_time)
  groupId = str(groupId).split('/')[-1]
  strRW = "<tr><td>"+ job_type + "</td><td>"+ query_output + "</td><td>"+ job_id + "</td><td>" + targetTable + "</td><td>" + run_id + "</td><td>"+date_time + "</td><td>" + groupId +"</td>" + "</tr>"
  strTable = strTable+strRW
  strTable = strTable + "</table>" 
  
  do_not_reply_txt = f"<br><br><br>NOTE : PLEASE DO NOT REPLY. This email is generated by an automated system.For any issues or concern related to Audit Check please look into log table '{logDb}.{logTable}' or connect to DHF Team <br><br>Warm Regards,<br>DHF Team"
  mail_body = strTable
  sendEmail(domain_email_dl , email_from, f'DHF AUDIT CHECK LOGS', mail_body+do_not_reply_txt) 

# COMMAND ----------

def fileSizeCheck(s3bucketname,filelocation,file_name,config,domain_email_dl,email_from):
  print("Inside fileSizeCheck function")
  targetTable = config['target_table']
  logTable = config['log_table_name'] 
  job_type = config['type']
  minfilesize = config['min_file_size'] 
  maxfilesize = config['max_file_size']
  date_time = time.asctime(time.localtime(time.time()))
  s3 = boto3.resource('s3')
  my_bucket = s3.Bucket(s3bucketname)
  filelist=[]
  for object_summary in my_bucket.objects.filter(Prefix=filelocation):
    if file_name in object_summary.key:
      filelist.append(object_summary.key)
      print(filelist)
      while len(filelist)>0:
        objname=' '.join(filelist).split(' ')[0]
        filesize = my_bucket.Object(objname).content_length
        print(filesize)
        if filesize<minfilesize or filesize>maxfilesize or filesize==0 or (filesize>=minfilesize and filesize<=maxfilesize):
          if filesize==0:
            print("Empty(0 byte) File received. Please review the file. File Name is "+str(objname)+".")
            query_output = '[{'f'"Empty(0 byte) File received. Please review the file. File Name is {objname}."''}]' 
            jobMetrics = [[job_type, query_output , job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
            persistLog(jobMetrics,logTable) 
            print("The logs of the file size check is captured in the log table:",logTable)
          
            mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type
          elif filesize<minfilesize:
            print("File size is less than the defined minimum file size of "+str(minfilesize)+". File name is "+str(objname)+".")
            query_output = '[{'f'"File size is less than the defined minimum file size of {minfilesize}. File Name is {objname}."''}]' 
            jobMetrics = [[job_type, query_output , job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
            persistLog(jobMetrics,logTable) 
            print("The logs of the file size check is captured in the log table:",logTable)
          
            mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type
          elif filesize>maxfilesize:
            print("File size is greater than the defined maximum file size of "+str(maxfilesize)+". File name is "+str(objname)+".")
            query_output = '[{'f'"File size is greater than the defined maximum file size of {maxfilesize}. File Name is {objname}."''}]' 
            jobMetrics = [[job_type, query_output , job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
            persistLog(jobMetrics,logTable) 
            print("The logs of the file size check is captured in the log table:",logTable)
          
            mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type
          else:
            print("File size is within defined minimum and maximum file size of "+str(minfilesize)+" and "+str(maxfilesize)+". File Name is "+str(objname)+".")
        filelist.remove(objname)

# COMMAND ----------

def fileSizeAuditCheck(groupid,config,domain_email_dl,email_from):
  print("Inside fileSizeAuditCheck")
  srcs3file = config['src_s3_file_path']
  minfilesize = config['min_file_size'] 
  maxfilesize = config['max_file_size']
  if (srcs3file==None or len(srcs3file)==0 or minfilesize==None or maxfilesize==None):
    raise Exception(f"You missed to provide 'source s3 file path' or 'minimum file size' or 'maximum file size' value in UI config.")
  s3bucketname=srcs3file.split('/',3)[2]
  filelocation='/'.join(srcs3file.split('/', 3)[3:])
  filepath=filelocation.rsplit('/', 1)[0]
  file_name=filelocation.rsplit('/', 1)[1]
  fileSizeCheck(s3bucketname,filelocation,file_name,config,domain_email_dl,email_from)

# COMMAND ----------

def recordThresholdAuditCheck(rawtable,loadDateColName,loadDateFormat,config,domain_email_dl,email_from):
  logTable = config['log_table_name'] 
  record_threshold_per = config['threshold_value']
  job_type = config['type']
  targetTable = config['target_table']
  today = date.today()
  firstday_of_month = today.replace(day=1)
  previous_month = (firstday_of_month - timedelta(days=1)).strftime("%m")
  print("previous_month: "+previous_month)

  currentyear = date.today().strftime('%Y')
  print("current_year: "+currentyear)
  previousyear = (datetime.today() - timedelta(days = 365)).strftime('%Y')
  print("previous_year: "+ previousyear)
  if ('-' in loadDateFormat):
    todaysdate=datetime.today().strftime('%Y-%m-%d')
    yesterdaydate = (datetime.today() - timedelta(days = 1)).strftime('%Y-%m-%d')
    previous_mon=currentyear+'-'+previous_month
    load_date_format='yyyy-MM-dd'
  else:
    todaysdate=datetime.today().strftime('%Y%m%d')
    yesterdaydate = (datetime.today() - timedelta(days = 1)).strftime('%Y%m%d')
    previous_mon=currentyear+previous_month
    load_date_format='yyyyMMdd'
  date_time = time.asctime(time.localtime(time.time()))
  print("today's date: "+todaysdate)
  print("yesterdaydate: "+yesterdaydate)
  print("last month & Year: "+previous_mon)

  dailycount=spark.sql(f"select count(*) from {rawtable} where  contains({loadDateColName},{todaysdate})").collect()[0][0]
  yesterdaycount=spark.sql(f"select count(*) from {rawtable} where  contains({loadDateColName},{yesterdaydate})").collect()[0][0]
  if (dailycount==None):
    dailycount=0
  if (yesterdaycount==None):
    yesterdaycount=0
      
  print(dailycount)
  print(yesterdaycount)
  daily_average_threshold_max=int(yesterdaycount+yesterdaycount*record_threshold_per/100)
  daily_average_threshold_min=int(yesterdaycount-yesterdaycount*record_threshold_per/100)

  if(dailycount>daily_average_threshold_max) or (dailycount<daily_average_threshold_min):
    print("Daily Record Count Threshold Check Failed. Expected count is between "+str(daily_average_threshold_min)+" and "+str(daily_average_threshold_max)+". Record count is "+str(dailycount)+" for table "+str(rawtable)+".")
    query_output = '[{'f'"Daily Record Count Threshold Check Failed. Expected count is between {daily_average_threshold_min} and {daily_average_threshold_max}. Record count is {dailycount} for table {rawtable}."''}]' 
    jobMetrics = [[job_type, query_output , job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
    persistLog(jobMetrics,logTable) 
    print("The logs of the Daily Record Count Threshold Check is captured in the log table:",logTable)
    mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type
  else:
    print("Daily Record Threshold Check Passed. Expected count is between "+str(daily_average_threshold_min)+" and "+str(daily_average_threshold_max)+". Record count is "+str(dailycount)+" for table "+str(rawtable)+".")

  monthlyavgcount=spark.sql(f"select avg(count) from (select date_format(to_date({loadDateColName},'{loadDateFormat}'),'{load_date_format}') as load_date, count(*) as count from {rawtable} group by load_date having load_date like '{previous_mon}%')").collect()[0][0]

  if (monthlyavgcount==None):
    monthlyavgcount=0
  print("monthlyavgcount: "+str(monthlyavgcount))
  mon_average_threshold_max=int(monthlyavgcount+monthlyavgcount*record_threshold_per/100)
  print("monthly_average_threshold_max: "+str(mon_average_threshold_max))
  mon_average_threshold_min=int(monthlyavgcount-monthlyavgcount*record_threshold_per/100)
  print("monthly_average_threshold_min: "+str(mon_average_threshold_min))
  if(dailycount>mon_average_threshold_max) or (dailycount<mon_average_threshold_min):
    print("Monthly Record Threshold Check Failed. Expected count is between "+str(mon_average_threshold_min)+" and "+str(mon_average_threshold_max)+". Record count is "+str(dailycount)+" for table "+str(rawtable)+".")
    query_output = '[{'f'"Monthly Record Threshold Check Failed. Expected count is between {mon_average_threshold_min} and {mon_average_threshold_max}. Record count is {dailycount} for table {rawtable}."''}]' 
    print(query_output)
    jobMetrics = [[job_type, query_output , job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
    persistLog(jobMetrics,logTable) 
    print("The logs of the Monthly Record Count Threshold Check is captured in the log table:",logTable)
    mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type
  else:
    print("Monthly Record Threshold Check Passed. Expected count is between "+str(mon_average_threshold_min)+" and "+str(mon_average_threshold_max)+". Record count is "+str(dailycount)+" for table "+str(rawtable)+".")

  yearlyavgcount=spark.sql(f"select avg(count) from (select date_format(to_date({loadDateColName},'{loadDateFormat}'),'{load_date_format}') as load_date, count(*) as count from {rawtable} group by load_date having load_date like '{previousyear}%')").collect()[0][0]
  
  if (yearlyavgcount==None):
    yearlyavgcount=0
  print("yearlyavgcount: "+str(yearlyavgcount))

  yearly_average_threshold_max=int(yearlyavgcount+yearlyavgcount*record_threshold_per/100)
  print("yearly_average_threshold_max: "+str(yearly_average_threshold_max))
  yearly_average_threshold_min=int(yearlyavgcount-yearlyavgcount*record_threshold_per/100)
  print("yearly_average_threshold_min: "+str(yearly_average_threshold_min))
  if(dailycount>yearly_average_threshold_max) or (dailycount<yearly_average_threshold_min):
    print("Yearly Record Threshold Check Failed. Expected count is between "+str(yearly_average_threshold_min)+" and "+str(yearly_average_threshold_max)+". Record count is "+str(dailycount)+" for table "+str(rawtable)+".")
    query_output = '[{'f'"Yearly Record Threshold Check Failed. Expected count is between {yearly_average_threshold_min} and {yearly_average_threshold_max}. Record count is {dailycount} for table {rawtable}."''}]' 
    jobMetrics = [[job_type, query_output , job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
    persistLog(jobMetrics,logTable) 
    print("The logs of the Yearly Record Count Threshold Check is captured in the log table:",logTable)
    mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type
  else:
    print("Yearly Record Threshold Check Passed. Expected count is between "+str(yearly_average_threshold_min)+" and "+str(yearly_average_threshold_max)+". Record count is "+str(dailycount)+" for table "+str(rawtable)+".")

# COMMAND ----------


def recordThreshholdCheck(groupid,config,domain_email_dl,email_from):
  print("Inside recordThreshholdCheck")
  targetDb = config['target_database']
  targetTable = config['target_table']
  loadDateColName = config['load_date_col_name'] 
  loadDateFormat = config['load_date_format']
  record_threshold_per = config['threshold_value']
  if (targetDb==None or len(targetDb)==0 or targetTable==None or len(targetTable)==0 or loadDateColName==None or len(loadDateColName)==0 or loadDateFormat==None or len(loadDateColName)==0 or record_threshold_per==None):
    raise Exception(f"You missed to provide 'target database' or 'target table' or 'load date column name' or 'load date format' or 'threshhold value' value in UI config.")
  raw_table=targetDb+'.'+targetTable
  print(raw_table)
  recordThresholdAuditCheck(raw_table,loadDateColName,loadDateFormat,config,domain_email_dl,email_from)
     

# COMMAND ----------

def slaCheck(groupId,config,domain_email_dl,email_from):
  print("slaCheck")
  tgtDbName = config['target_database'] 
  targetTable = config['target_table'] 
  targetTb  = f"{tgtDbName}.{targetTable}"
  logTable = config['log_table_name']
  job_type = config['type']
  loadDateColName = config['load_date_col_name'] 
  loadDateFormat = config['load_date_format']

  if (tgtDbName==None or len(tgtDbName)==0 or targetTable==None or len(targetTable)==0 or loadDateColName==None or len(loadDateColName)==0 or loadDateFormat==None or len(loadDateColName)==0):
    raise Exception(f"You missed to provide 'target database' or 'target table' or 'load date column name' or 'load date format' value in UI config.")

  date_time = time.asctime(time.localtime(time.time()))

  today = date.today()
  batchdate=today.strftime(loadDateFormat)
  print(batchdate)
  count=spark.sql(f"select count(*) from {targetTb} where {loadDateColName} like '{batchdate}%'").collect()[0][0]
  
  if count!=0:
    print(f"Data is loaded in {targetTb} table on {batchdate} within SLA.")
  else:
    print(f"Data is not loaded in {targetTb} table on {batchdate} within SLA.")
    query_output = '[{'f'"Data is not loaded in {targetTb} table on {batchdate} within SLA."''}]' 
    jobMetrics = [[job_type, query_output, job_id, targetTable, run_id, date_time, groupId]] #check parameters and its type
    persistLog(jobMetrics,logTable) 
    print("The logs of SLA check are captured in the log table:",logTable)
    mailbodycreation(job_type, query_output, job_id, targetTable, run_id, date_time, groupId,logDb,logTable,domain_email_dl,email_from) #check parameters and its type

# COMMAND ----------

def startAuditMain(groupId):
  groupIdDict = getGroup(groupId) 
  domain_level_user_properties = groupIdDict['domain_userproperty'] #"domain_email_dl:kums247@nationwide.com"#groupIdDict['domain_userproperty'] 
  domain_email_dl = getUserPropertyValue('domain_email_dl',domain_level_user_properties)
  email_from = 'do-not-reply@nationwide.com'
  print("---email---", domain_email_dl, email_from)
  
  try:
    autditCheckList= getTableList(groupId)

    #   configtableList= getTableList(groupId)
    print("Looping the auditchecklist...")
    for audit in autditCheckList:
      if(audit['type'] == "surrogatekey"):
        surrogateCheck(groupId,audit,domain_email_dl,email_from)
      elif(audit['type'] == "rowcount"):
        rowCount(groupId,audit,domain_email_dl,email_from)
      elif(audit['type'] == "aggregation"):
        aggregation(groupId,audit,domain_email_dl,email_from)
      elif(audit['type'] == "filesizecheck"):
        fileSizeAuditCheck(groupId,audit,domain_email_dl,email_from)
      elif(audit['type'] == "recordthreshholdcheck"):
        recordThreshholdCheck(groupId,audit,domain_email_dl,email_from)
      elif(audit['type'] == "slacheck"):
        slaCheck(groupId,audit,domain_email_dl,email_from)
      
      
    endTime = time.asctime(time.localtime(time.time()))
    spark.sql(f"update {jobStatusLog} set status='Completed',end_time='{endTime}' where job_id={job_id} and group_id={groupId} and run_id={run_id}")
  except Exception as e:
    do_not_reply_txt = "<br><br><br><br>NOTE : PLEASE DO NOT REPLY. This email is generated by an automated system. For any issues or concern related to Framework, connect to DHF Team. <br>DHF Team"
    mail_body = f"AUDIT CHECK FAILED for group id: {groupId}. Find the below  error:<br> {e}"
    print(mail_body) 
    sendEmail(domain_email_dl , email_from, f'DHF AUDIT CHECK FAILED', mail_body+do_not_reply_txt) 
    

# COMMAND ----------

#function call
startAuditMain(groupId)
