# Databricks notebook source
# MAGIC %md
# MAGIC - Runs all tables for one Group ID
# MAGIC - Al l tables writing to one Harmonize Table go into same TaskGroup
# MAGIC - Task Group Level configurations:
# MAGIC -  job_type: HARMONIZATION - no separat EVENT_GENERATION or EVENT_HARMONIZATION
# MAGIC -  run_type: ROUND_THE_CLOCK / AVAILABLE_NOW   -- This notebook ONLY runs ROUND_THE_CLOCK TaskGroups
# MAGIC -  isNotebook: True/False

# COMMAND ----------

# DBTITLE 1,Import Statements
import pyspark.sql 
from pyspark.sql import Row
from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import *
import datetime
from datetime import datetime
import io
import re
import json
from itertools import groupby
from operator import itemgetter
import io
import zipfile
import pandas as pd
from pyspark.sql.types import *
import datetime 
import json
import boto3
import time
import ast
from datetime import datetime as dt
import time
from pyspark.sql import functions as f #2
from pyspark.sql.session import SparkSession
from pyspark.sql import DataFrame
from dataclasses import dataclass
from pyspark.sql.functions import window 
from pyspark.sql import *

# COMMAND ----------

# DBTITLE 1,Default Databricks Configurations
spark.conf.set("spark.sql.streaming.stopActiveRunOnRestart", True)
spark.conf.set("spark.sql.broadcastTimeout", 600)

# COMMAND ----------

# DBTITLE 1,Get arguments from widgets
dbutils.widgets.removeAll()
dbutils.widgets.text("groupId", "1", "GroupID")
dbutils.widgets.text("environment", "dev", "environment")
dbutils.widgets.text("metricsLogTable", "", "metricsLogTable")

groupId = int(dbutils.widgets.get("groupId"))
environment = dbutils.widgets.get("environment")
metricsLogTable = dbutils.widgets.get("metricsLogTable")

print("groupId in notebook is : ",groupId)
print("environment in notebook is : " + environment)
print("metricsLogTable in notebook is : " + metricsLogTable)

# COMMAND ----------

# DBTITLE 1,Run utils notebook
# MAGIC %run ../../utils/_utils

# COMMAND ----------

# MAGIC %run ../harmonization/_event_harmonizer_library

# COMMAND ----------

# DBTITLE 1,Global Variables for External Orchestration #QM
failed_taskgroups_list = []
taskgroup_queryid_dict = {}

# COMMAND ----------

class HarmonizeHandlerClass:  
  def __init__(self,harmonizedTable,key,taskGroupId,jobType,runType,taskGroup,changelogTable):
    self.harmonizedTable = harmonizedTable
    self.key = key
    self.taskGroupId = taskGroupId
    self.jobType = jobType
    self.runType = runType
    self.taskGroup = taskGroup
    self.changelogTable=changelogTable
  
  def handleMicroBatch(self,microBatchDF, batchId):
    try:
      harmonizedTable = self.harmonizedTable
      key = self.key
      taskGroupId = self.taskGroupId
      jobType = self.jobType
      runType = self.runType
      taskGroup = self.taskGroup
      changelogTable=self.changelogTable
      view_name = f"V_{taskGroupId}"
      print(view_name)
      
      start = dt.now()
      start_time = time.time()
      print("In Harmonize handler f4")
      batchSize = microBatchDF.count()
      print(f"In Harmonize handler for harmonizedTable: {harmonizedTable}, changelogTable: {changelogTable} taskGroupId: {taskGroupId}, batchSize: {batchSize}, batchId:{batchId}")
      minThreshold = taskGroup['min_threshold']
      maxThreshold = taskGroup['max_threshold']
      user_properties = taskGroup['user_properties']  
      udm_value = getUserPropertyValue("UDM",user_properties)
      print("udm_value",udm_value)
      
      ##added for snowprop
      servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
      if servicenow_property:
        snow_property = servicenow_property
      else:
        snow_property = taskGroup['user_properties']
      ##added for snowprop

      hash_user_prop = getUserPropertyValue("hash_col",user_properties)
      hash_col = hash_user_prop.upper() if hash_user_prop is not None else hash_user_prop
      target_hash = ''
      if hash_col in ["ROW_HASH","MD5_HASH"]:
        target_hash = harmonizedTable + f"#{hash_col}"
        viewname_hash = view_name + f"#{hash_col}"
      else:
        target_hash = harmonizedTable + "#MD5_HASH"
        viewname_hash = view_name + "#MD5_HASH"
        hash_col = "MD5_HASH"
        
      patch_user_prop = getUserPropertyValue("patch_col",user_properties)
      patch_col = patch_user_prop.upper() if patch_user_prop is not None else patch_user_prop
      target_hash_patch = ''
      key_patch = ''
      if patch_col in ["ETL_LAST_UPDT_TS","ETL_PATCH_TS"]:
        target_hash_patch = target_hash + f"#{patch_col}"
        key_patch = key + f'#{patch_col}'
      else:
        target_hash_patch = target_hash + "#ETL_LAST_UPDT_TS"
        key_patch = key + "#ETL_LAST_UPDT_TS"
        
      
      #RDM params intialization---->
      RDM_UI_config=""
      target_table_name=harmonizedTable.split(".")[1]
      if(not( taskGroup['user_properties']==None  or len(taskGroup['user_properties'])==0  ) ):
        RDM_UI_config = getUserPropertyValue("RDM", taskGroup['user_properties'])
        print("In merge handler: ",RDM_UI_config)
      #RDM_UI_config=taskGroup['reference_data_config']
      
      if (udm_value==None  or len(udm_value)==0):
        udm_value=""
      else:
        udm_value=udm_value.strip().lower()

      rmspecialcharacter_value = getUserPropertyValue("rmSpecialCharacter",user_properties) ##splcharac removal
      print("rmspecialcharacter_value",rmspecialcharacter_value)
      if (rmspecialcharacter_value==None  or len(rmspecialcharacter_value)==0):
        rmspecialcharacter_value=""
      else:
        rmspecialcharacter_value=rmspecialcharacter_value.strip().lower()


      if batchSize>0:
        encryptColumns=taskGroup['encrypt_columns'] #sensitive columns-encrypt
        secretKey=getSecretKey(taskGroup['secret_key_details'])
        is_encryptdata=taskGroup['encrypt_data']
        if is_encryptdata:
          microBatchDF=decryptDataframe(microBatchDF,encryptColumns,secretKey)#decrypt before applying harm logic if changelog is encrypted

        if(rmspecialcharacter_value=='yes'):                      ##splcharac removal
          exclusionDF=removeSpecialCharacters(microBatchDF)
        else:
          exclusionDF = microBatchDF

        #exclusionDF = microBatchDF
        ispreHarmQuery = taskGroup['pre_harmonization_query'] 
        if(not((ispreHarmQuery==None) or (len(ispreHarmQuery)==0))):   
          exclusionDF = pre_harm_exclusion(exclusionDF, ispreHarmQuery, taskGroup['source_db'], environment,view_name)
          exclusionDF = removeAdditionalCols_DHFGeneric(exclusionDF, target_hash)
          

        exclusionDF.createOrReplaceGlobalTempView(view_name)

        #addHash
        hashDF = addHashColumnXXHash_DHFGeneric_UDM(viewname_hash) if(udm_value == "yes") else addHashColumnXXHash_DHFGeneric(viewname_hash)
        #dedup
        Type1 = taskGroup['merge_type'].lower()
        ishashColumn = taskGroup['is_hash_column']
        is_surrogatekey= taskGroup['is_surrogate_key']
        partition_col = getUserPropertyValue('partition_col',user_properties)  #partitioningUpdate
        partition_val = getUserPropertyValue('partition_val',user_properties)  #partitioningUpdate
        print(f"partition_col,: {partition_col}")
        keygen = taskGroup['key_gen_config'] if taskGroup['key_gen_config'] == None  else taskGroup['key_gen_config'].strip()
        print("key_gen_config :",keygen)
        
        if (Type1=="type1"):
          dedupDF = hashDF
          orderby = taskGroup['order_by_column']
          if((orderby==None) or (len(orderby)==0)):  
            partition_cols=key.split(",")
            w = Window.partitionBy(*partition_cols).orderBy(col("_commit_version").desc()) #toDo
            dedupDF = hashDF.filter(((col("_change_type")) == "insert") | (col("_change_type") == "update_postimage")).withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum").drop("_change_type").drop("_commit_version")
            if(keygen):
              anchorDF=add_anchor(hashDF,keygen)
              dedupDF = removeDuplicatesMicrobatch_DHFGeneric(anchorDF, key, "_commit_timestamp")
            else:
              dedupDF = removeDuplicatesMicrobatch_DHFGeneric(dedupDF, key, "_commit_timestamp")
            dedupDF=dedupDF.drop("_commit_timestamp")
          else:
            partition_cols=key.split(",")
            orderyby_cols=orderby.split(",")
            w = Window.partitionBy(*partition_cols).orderBy(*[desc(c) for c in orderyby_cols])
            dedupDF = dedupDF.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
            if(keygen):
              anchorDF=add_anchor(hashDF,keygen)
              dedupDF = removeDuplicatesMicrobatch_DHFGeneric(anchorDF, key, orderby)
            else:
              dedupDF = removeDuplicatesMicrobatch_DHFGeneric(dedupDF, key, orderby)
          
          dedupDF.show(3,False)
          
          noHashDF = dedupDF.drop(f"{hash_col}") if (not(ishashColumn)) else dedupDF #eltChange
          if is_surrogatekey:
            surrogateKeyDF = addSurrogateKey_DHFGeneric(noHashDF, harmonizedTable)
            # surrogateKeyDF = surrogateKeyDF if hash_col is "MD5_HASH" else surrogateKeyDF.withColumnRenamed('MD5_HASH',hash_col) #dropping hash col then y
            #placing 1
            
            #RDM
            if(not((RDM_UI_config==None) or (len(RDM_UI_config)==0))):
              surrogateKeyDF = rdm_function(surrogateKeyDF,RDM_UI_config,target_table_name,taskGroupId)
            
            # -----------------------------type1 if--------------------------------------------- #
            if is_encryptdata: 
              encryptedDF = encryptDataframe(surrogateKeyDF,encryptColumns,secretKey)#encrypt
              if(partition_col is  not None  and partition_val is not None):
                print("partition_col, partition_val are provided in user_parameters")
                type1_defaultMergePartitionied_DHFGeneric(encryptedDF, harmonizedTable, key, partition_col, partition_val)
              else:
                if partition_col is None and partition_val is None:
                  print("partition_col, partition_val are NOT provided in user_parameters")
                elif partition_col is None:
                  print("partition_col is NOT provided in user_parameters")
                else:
                  print("partition_val is NOT provided in user_parameters")
                type1_defaultMerge_DHFGeneric(encryptedDF, harmonizedTable, key)
                
            else:
              if(partition_col is  not None  and partition_val is not None):
                print("partition_col, partition_val are provided in user_parameters")
                type1_defaultMergePartitionied_DHFGeneric(surrogateKeyDF, harmonizedTable, key, partition_col, partition_val)
              else:
                if partition_col is None and partition_val is None:
                  print("partition_col, partition_val are NOT provided in user_parameters")
                elif partition_col is None:
                  print("partition_col is NOT provided in user_parameters")
                else:
                  print("partition_val is NOT provided in user_parameters")
                type1_defaultMerge_DHFGeneric(surrogateKeyDF, harmonizedTable, key)
              
          # ----------------------------type1 else---------------------------------------------- #
          else:
            # noHashDF = noHashDF if hash_col is "MD5_HASH" else noHashDF.withColumnRenamed('MD5_HASH',hash_col)
            #placing 2
            
            #RDM
            if(not((RDM_UI_config==None) or (len(RDM_UI_config)==0))):
              noHashDF=rdm_function(noHashDF,RDM_UI_config,target_table_name,taskGroupId)
            
            if is_encryptdata: 
              encryptedDF=encryptDataframe(noHashDF,encryptColumns,secretKey)#encrypt
              if(partition_col is  not None  and partition_val is not None):
                print("partition_col, partition_val are provided in user_parameters")
                type1_defaultMergePartitionied_DHFGeneric(encryptedDF, harmonizedTable, key, partition_col, partition_val)
              else:
                if partition_col is None and partition_val is None:
                  print("partition_col, partition_val are NOT provided in user_parameters")
                elif partition_col is None:
                  print("partition_col is NOT provided in user_parameters")
                else:
                  print("partition_val is NOT provided in user_parameters")
                type1_defaultMerge_DHFGeneric(encryptedDF, harmonizedTable, key)
                
            else:
              if(partition_col is  not None  and partition_val is not None):
                print("partition_col, partition_val are provided in user_parameters")
                type1_defaultMergePartitionied_DHFGeneric(noHashDF, harmonizedTable, key, partition_col, partition_val)
              else:
                if partition_col is None and partition_val is None:
                  print("partition_col, partition_val are NOT provided in user_parameters")
                elif partition_col is None:
                  print("partition_col is NOT provided in user_parameters")
                else:
                  print("partition_val is NOT provided in user_parameters")
                type1_defaultMerge_DHFGeneric(noHashDF, harmonizedTable, key)
            # -------------------------------------------------------------------------- #

        else:
          if(keygen):
            anchorDF=add_anchor(hashDF,keygen)   
            if(partition_col != None  and partition_val != None):
              dedupDF = removeDuplicatesPartitionied_DHFGeneric_UDM(anchorDF, target_hash, key, partition_col, partition_val) if(udm_value == "yes") else removeDuplicatesPartitionied_DHFGeneric(anchorDF, target_hash, key, partition_col, partition_val)
            else:
              dedupDF = removeDuplicates_DHFGeneric_UDM(anchorDF, target_hash, key) if(udm_value == "yes") else removeDuplicates_DHFGeneric(anchorDF, target_hash, key)
          else:
            if(partition_col != None  and partition_val != None):
              dedupDF = removeDuplicatesPartitionied_DHFGeneric_UDM(hashDF, target_hash, key, partition_col, partition_val) if(udm_value == "yes") else removeDuplicatesPartitionied_DHFGeneric(hashDF, target_hash, key, partition_col, partition_val)
            else:
              dedupDF = removeDuplicates_DHFGeneric_UDM(hashDF, target_hash, key) if(udm_value == "yes") else removeDuplicates_DHFGeneric(hashDF, target_hash, key)
          #Add Audit Columns
          dedupDF.show()
          auditDF = addAuditColumns_DHFGeneric_UDM(dedupDF, key_patch) if(udm_value == "yes") else addAuditColumns_DHFGeneric(dedupDF, key)
          #Add SurrogateKey
          surrogateKeyDF = addSurrogateKey_DHFGeneric(auditDF, harmonizedTable)
          # surrogateKeyDF = surrogateKeyDF if hash_col is "MD5_HASH" else surrogateKeyDF.withColumnRenamed('MD5_HASH',hash_col)
          #placing 3
          
          #RDM
          if(not((RDM_UI_config==None) or (len(RDM_UI_config)==0))):
            surrogateKeyDF=rdm_function(surrogateKeyDF,RDM_UI_config,target_table_name,taskGroupId)
            
          #Merge Type2
          # ------------------------------type 2-------------------------------------------- #
          if is_encryptdata:
            encryptedDF =encryptDataframe(surrogateKeyDF,encryptColumns,secretKey) #Encrypt
            if(partition_col is  not None  and partition_val is not None):
              print("partition_col, partition_val are provided in user_parameters")
              if(udm_value == "yes"):
                defaultMergePartitionied_DHFGeneric_UDM(encryptedDF, target_hash_patch, partition_col, partition_val)  
              else:
                defaultMergePartitionied_DHFGeneric(encryptedDF, target_hash, partition_col, partition_val)

            else:
              if partition_col is None and partition_val is None:
                print("partition_col, partition_val are NOT provided in user_parameters")
              elif partition_col is None:
                print("partition_col is NOT provided in user_parameters")
              else:
                print("partition_val are NOT provided in user_parameters")
                
              defaultMergeDF = defaultMerge_DHFGeneric_UDM(encryptedDF, target_hash_patch) if(udm_value == "yes") else defaultMerge_DHFGeneric(encryptedDF, target_hash)
                
          else:
            if(partition_col is  not None  and partition_val is not None):
              print("partition_col, partition_val are provided in user_parameters")
              if(udm_value == "yes"):
                defaultMergePartitionied_DHFGeneric_UDM(surrogateKeyDF, target_hash_patch, partition_col, partition_val)  
              else:
                defaultMergePartitionied_DHFGeneric(surrogateKeyDF, target_hash, partition_col, partition_val)

            else:
              if partition_col is None and partition_val is None:
                print("partition_col, partition_val are NOT provided in user_parameters")
              elif partition_col is None:
                print("partition_col is NOT provided in user_parameters")
              else:
                print("partition_val are NOT provided in user_parameters")
            
              defaultMergeDF = defaultMerge_DHFGeneric_UDM(surrogateKeyDF, target_hash_patch) if(udm_value == "yes") else defaultMerge_DHFGeneric(surrogateKeyDF, target_hash)
          # ------------------------------type 2-------------------------------------------- #
          

        end_time = time.time()
        totalBatchTimeInMins = int((end_time-start_time)/60)
   
        persistLog([[str(groupId),jobId,str(jobType+"-Merge"),runType, runId, batchId, batchSize,str(totalBatchTimeInMins),str(start),taskGroupId, 0, "", harmonizedTable, clusterId]],metricsLogTable) 
    
        #send to splunk
        sendToSplunk(str(groupId), jobId, job_name, str(jobType +"-Merge"), runType, runId, batchId, batchSize,str(start), str(totalBatchTimeInMins),  taskGroupId, 0, changelogTable, harmonizedTable, clusterId,"Success")
        print("run inline optimize if it is the right period")

        if(taskGroup['inline_optimize_enabled']):
          optimizeDeltaTable(taskGroup)
         
        if(totalBatchTimeInMins > minThreshold):
          if(totalBatchTimeInMins > maxThreshold): 
            print("Max Threshold Breached.Generating snow ticket and Sending Email..")
            errorHandler("maxThreshold",job_name,groupId,jobId,jobType,runId,batchId,maxThreshold,minThreshold,                                                        str(totalBatchTimeInMins),taskGroupId,0,"NA",taskGroup['email_list'],snow_property,metricsLogTable)
          else:
            print("Min Threshold hold breached. sending email...")
            errorHandler("minThreshold",job_name,groupId,jobId,jobType,runId, batchId,maxThreshold,minThreshold,str(totalBatchTimeInMins),taskGroupId,0,"NA",taskGroup["email_list"],snow_property,metricsLogTable)
            
        else:
          print(f"batchId {batchId} for harmonization completed withing threshold limit. Total batch time - " ,totalBatchTimeInMins)

    except Exception as e:
      failed_taskgroups_list.append(taskGroupId)  #jobOrch
      persistLog_external([[taskGroupId,jobType,runId,"Failed",dt.now().date(),dt.now()]], metricsLogTable) #jobOrch
      print(f"MERGE FAILED for Harmonize table: {harmonizedTable}, batchId {batchId}. {e}")

      sendToSplunk(str(groupId), jobId, job_name, jobType + "-Merge", runType, runId, batchId, 0,str(dt.now()), "0",  taskGroupId, 0, changelogTable, harmonizedTable, clusterId,"Failed")
      
      errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroupId,0,str(e).replace("\n", " "),taskGroup['email_list'],snow_property,metricsLogTable)
      
      # ----- For External Job Orchestration --- #
      makingTaskGroupInactive(taskGroupId)
      print("active field successfully set to false for task group id",taskGroup["id"])
      error_msg="TaskGroup Id "+str(taskGroupId)+" is made inactive"
      errorHandler("inactive_task_group", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",taskGroupId,0,error_msg,taskGroup["email_list"],snow_property,metricsLogTable)
      raise Exception(f'MERGE FAILED for  target: {harmonizedTable} for batchId {batchId}',e)      
    

# COMMAND ----------

def startHarmonizeMergeStream(taskGroup):
  global taskgroup_queryid_dict #jobOrch
  taskGroupId = taskGroup['id'] #jobOrch
  
  target_table = taskGroup['target_db'] + "." + taskGroup['target_table']
  maxBytesPerTrigger = taskGroup['max_bytes_per_trigger']
  Type1_evntharm = taskGroup['merge_type'].lower() # TODO: from config
  orderby_evntharm = taskGroup['order_by_column']
  changelogTable = target_table + "_chlg"
  changelogPrefix=""
  
  if(not( taskGroup['user_properties']==None  or len(taskGroup['user_properties'])==0  ) ):
    changelogPrefix    =getUserPropertyValue("changelogPrefix", taskGroup['user_properties'])
    changelogTableSchema    =getUserPropertyValue("changelogTableSchema", taskGroup['user_properties'])
      
    if (not( changelogPrefix==None  or len(changelogPrefix)==0  ) ):
      changelogPrefix="_"+changelogPrefix
      changelogTable=target_table +changelogPrefix + "_chlg"
    else:
      changelogPrefix=""

    if (changelogTableSchema!=None  and len(changelogTableSchema)>=1 and  len(changelogPrefix)==0):
      changelogTable = changelogTableSchema+"." + taskGroup['target_table']+"_chlg"
    elif(changelogTableSchema!=None and len(changelogTableSchema)>=1 and len(changelogPrefix)>=1):
      changelogTable = changelogTableSchema+"." + taskGroup['target_table']+changelogPrefix+"_chlg" 
      
  print(target_table,maxBytesPerTrigger,Type1_evntharm,orderby_evntharm,changelogTable)
  
  checkpoint_dir = getCheckpoint(taskGroup['task_group_newdomain_source_id']) #CheckpointManagement
  if checkpoint_dir[-1] == "/": #CheckpointManagement
    checkpoint_dir = checkpoint_dir[:-1] #CheckpointManagement
  print("base checkPoint_dir",checkpoint_dir) #CheckpointManagement
  
  checkPoint = checkpoint_dir + "/eventharmonization/" + str(taskGroup['id']) + "/" + taskGroup['target_table']+changelogPrefix+ "_chlg/"+ "cp001"
  print(f"checkPoint is {checkPoint}")
  try:
    readStream = spark.readStream.option("ignoreChanges", True)
    
    #if (Type1_evntharm=="type1" and ((orderby_evntharm==None) or (len(orderby_evntharm)==0))):
      #readStream = readStream.option("readChangeFeed", "true")
    streamingDF = readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).format("delta").table(changelogTable)

    harmonizeHandler = HarmonizeHandlerClass(target_table,taskGroup['merge_keys'],taskGroup['id'],taskGroup['job_type'],taskGroup['run_type'],taskGroup,changelogTable)
    streamQuery = streamingDF.writeStream.foreachBatch(harmonizeHandler.handleMicroBatch).option("checkpointLocation", checkPoint).option("queryName", "harmoize " + target_table +"_"+ str(taskGroup['id']))
    if (taskGroup['run_type'] == ("AVAILABLE_NOW")):
      streamQuery = streamQuery.trigger(availableNow=True).option("maxBytesPerTrigger", maxBytesPerTrigger)
    q = streamQuery.start()
    taskgroup_queryid_dict[taskGroupId] = q.id #jobOrch


  except Exception as e:
    failed_taskgroups_list.append(taskGroupId)  #jobOrch
    persistLog_external([[taskGroupId,taskGroup['job_type'],runId,"Failed",dt.now().date(),dt.now()]], metricsLogTable) #jobOrch
    
    print(f"Merge Stream failed for Harmonize table: {changelogTable} {e}")
     
    #post log info to splunk
    sendToSplunk(str(groupId), jobId, job_name, taskGroup['job_type'] + "-Merge", taskGroup['run_type'], runId, -1, 0,str(dt.now()), "0",  taskGroup['id'], 0,  changelogTable, taskGroup['target_table'], clusterId,"Failed")
    
    #create snow ticket and send email

    ##added for snowprop
    servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
    if servicenow_property:
      snow_property = servicenow_property
    else:
      snow_property = taskGroup['user_properties']

    ##added for snowprop

    errorHandler("exception", job_name,groupId,jobId,taskGroup['job_type'],runId, -1,0,0,"0",taskGroup['id'],0,str(e).replace("\n", " "),taskGroup['email_list'],snow_property,metricsLogTable)
                           

# COMMAND ----------

def startMergeStreamsForBatch(taskGroupList):
  print("\n in start merge")
  canExitLoop = False
  startedTaskGroupList = [] #creating empty task list to avoid running the merge stream again after its completions
  while(not(canExitLoop)):
    canExitLoop = True
    for taskGroup in taskGroupList:
      activeStreamList = [_.name for _ in spark.streams.active]
      taskGroupStreamList = [_ for _ in set(f"{_['source_table']}_{taskGroup['id']}" for _ in getTask(int(taskGroup['id']), taskGroup['job_type']))] 
      print(f"\n activeStreamList: {activeStreamList} \n taskGroupStreamList: {taskGroupStreamList}")
      
      if any(_ in taskGroupStreamList for _ in activeStreamList):
        canExitLoop = False
      
      else:
        print(f"\n Starting Merge Stream for Task Group: {taskGroup['id']}, Harmonize Table: {taskGroup['target_db']}.{taskGroup['target_table']} \n")
        if (not(int(taskGroup['id']) in startedTaskGroupList)):
          startHarmonizeMergeStream(taskGroup)
          startedTaskGroupList.append(int(taskGroup['id']))  #appending taskgroup after MergeStream to avoid running the merge stream again
          print(f"\n Appending TASK GROUP to the toCheckTaskGroupList --- {startedTaskGroupList}")
        else:
          print(f"Merge stream either running or completed for this Task Group: {taskGroup['id']}")
        

      if (not(canExitLoop)):
        time.sleep(60)
        print("\n Waiting in Merge Stream Loop . . . \n")


# COMMAND ----------

class DeltaHandlerClass:
  def __init__(self,task,harmonizedTable,jobType,runType,email_list,user_properties,servicenow_property,changelogTable,is_encryptdata,encryptColumns,secretKeyDetails):
    self.task = task
    self.harmonizedTable = harmonizedTable
    self.jobType = jobType
    self.runType = runType
    self.email_list = email_list
    self.user_properties = user_properties
    self.servicenow_property = servicenow_property #to_be_upd
    self.changelogTable=changelogTable
    self.is_encryptdata=is_encryptdata # encrypt
    self.encryptColumns=encryptColumns
    self.secretKeyDetails=secretKeyDetails
  
  def handleMicroBatch(self,microBatchDF,batchId):
    try:
      print("Entering EG handler...")
      task = self.task
      harmonizedTable = self.harmonizedTable
      jobType = self.jobType
      runType = self.runType
      email_list = self.email_list
      user_properties = self.user_properties
      servicenow_property = self.servicenow_property #to_be_upd
      changelogTable=self.changelogTable
      is_encryptdata=self.is_encryptdata  # encrypt
      encryptColumns=self.encryptColumns
      secretKeyDetails=self.secretKeyDetails
      secretKey=getSecretKey(secretKeyDetails)
      
      start = dt.now()
      start_time = time.time()
      batchSize = microBatchDF.count()
          
      if batchSize >= 1:
        print(f"Entering EG handler generation changelogTable: {changelogTable}, BatchId: {batchId}, Batchsize: {batchSize}, TaskId: {task['id']}, SourceTable: {task['source_table']}")
        microBatchDF.createOrReplaceGlobalTempView(f'{task["source_table"]}')
        if(task["sql_query"].startswith('/Repos')):
          task_query = task_query_dict[task["id"]]
          print(f'query for the task {task["id"]} is : {task_query}')
          queryDF = spark.sql((task_query).replace("{sourceDB}", task["source_db"]))
        else:
          queryDF = spark.sql((task["sql_query"]).replace("{sourceDB}", task["source_db"])) 
        if is_encryptdata:
          encryptDF=encryptDataframe(queryDF,encryptColumns,secretKey)  #encrypt 
          encryptDF.write.mode("append").format("delta").saveAsTable(changelogTable)
        else:
          queryDF.write.mode("append").format("delta").saveAsTable(changelogTable)
          
        end_time = time.time()
        totalBatchTimeInMins = int((end_time-start_time)/60)

        persistLog([[str(groupId),jobId,jobType,runType, runId, batchId, batchSize,str(totalBatchTimeInMins),str(start),task['task_group_id'], task['id'], task['source_table'], harmonizedTable, clusterId]],metricsLogTable) 

        #Send log info to splunk
        sendToSplunk(str(groupId), jobId, job_name, jobType, runType, runId, batchId, batchSize,  str(start),str(totalBatchTimeInMins), task['task_group_id'], task['id'], task['source_table'], changelogTable, clusterId,"Success")
        print("end of EG")

      else:
        print(f"NO DATA in microbatch for source table {task['source_table']}, batchId {batchId}")

    except Exception as e:
    
      print(f"APPEND FAILED for raw table: {task['source_table']}, batchId {batchId}, FAILING the entire job. {e}")
          
      sendToSplunk(str(groupId), jobId, job_name, jobType, runType, runId, batchId, 0,  str(dt.now()),"0", task['task_group_id'], task['id'], task['source_table'], changelogTable, clusterId,"Failed")
      
      ##added for snowprop
      servicenow_property = servicenow_property if servicenow_property is None else servicenow_property.strip()
      if servicenow_property:
        snow_property = servicenow_property
      else:
        snow_property = user_properties
      ##added for snowprop
      
      errorHandler("exception", job_name,groupId,jobId,jobType,runId, batchId,0,0,"0",task['task_group_id'],task['id'],str(e).replace("\n", " "),email_list,snow_property,metricsLogTable)  
#       raise Exception(f"APPEND FAILED for raw table: {task['source_table']}, batchId {batchId}, FAILING the entire job. {e}")


# COMMAND ----------

def startGenerationStreamingMain():
  group = getGroup(groupId)
  taskGroupList = getTaskGroupList(groupId)
  threshold_time_dict = {"HOURLY":15,"DAILY":180,"WEEKLY":1440,"MONTHLY":7220,"YEARLY":14400,"NONE":0}
  threshold_time = threshold_time_dict[group["schedule"]]
  global task_query_dict
  task_query_dict = {}

  for taskGroup in taskGroupList:
    taskGroupId = int(taskGroup['id'])
    target_table = taskGroup['target_db'] + "." + taskGroup['target_table']
    taskList = getTask(taskGroupId, group['job_type'])
    Type1_evntgen = taskGroup['merge_type'].lower() #TODO: from config
    orderby_evntgen = taskGroup['order_by_column']
    maxBytesPerTrigger = taskGroup['max_bytes_per_trigger']
    changeLogSchema =taskGroup['change_log_schema'] # ChangeLog Table schema # schema drift
    changelogTable = target_table + "_chlg"
    changelogPrefix=""
    replay_flag=taskGroup["replay"]
    
    if taskGroup['encrypt_data']:
      encryptColumns=taskGroup['encrypt_columns'] #sensitive columns-encrypt
      secretKey=getSecretKey(taskGroup['secret_key_details'])
      
      if (secretKey==None or (encryptColumns==None or len(encryptColumns)==0) ):
        raise Exception("Encrypt data flag is enabled but Secret Key details or list of columns that needs to be encrypted are not provided ")
    
    if(not( taskGroup['user_properties']==None  or len(taskGroup['user_properties'])==0  ) ):
      changelogPrefix    =getUserPropertyValue("changelogPrefix", taskGroup['user_properties'])
      changelogTableSchema    =getUserPropertyValue("changelogTableSchema", taskGroup['user_properties'])
      
      if (not( changelogPrefix==None  or len(changelogPrefix)==0  ) ):
        changelogPrefix="_"+changelogPrefix
        changelogTable=target_table +changelogPrefix + "_chlg"
      else:
        changelogPrefix=""
    #CheckpointManagement
      if (changelogTableSchema!=None  and len(changelogTableSchema)>=1 and  len(changelogPrefix)==0):
        changelogTable = changelogTableSchema+"." + taskGroup['target_table']+"_chlg"
      elif(changelogTableSchema!=None and len(changelogTableSchema)>=1 and len(changelogPrefix)>=1):
        changelogTable = changelogTableSchema+"." + taskGroup['target_table']+changelogPrefix+"_chlg" 


    checkpoint_dir =  getCheckpoint(taskGroup['task_group_newdomain_source_id']) 
    
    if checkpoint_dir[-1] == "/": 
      checkpoint_dir = checkpoint_dir[:-1] 
    print("base checkPoint_dir",checkpoint_dir) 
    
    if(replay_flag == True):
      print("Replay Flag set to true")
      checkPoint_del=checkpoint_dir +"/"+"eventgeneration"+"/"+str(taskGroupId)+"/"
      dbutils.fs.rm(checkPoint_del,True)
      print(f"Since Repaly Flag is enabled checkPoint {checkPoint_del} is deleted")
  
    
    if (len(taskList)==0):
      raise Exception(f"No task found for the given task_group_id {taskGroupId}. Please check the task config table")
      
    else:
      #To handle schema drift
      tableExists = spark.catalog._jcatalog.tableExists(f"{changelogTable}")
      if not(tableExists):
        createTableQuery = f'CREATE TABLE IF NOT EXISTS {changelogTable} ({changeLogSchema.replace("#",",")})'
        print(" Change log table does not exists.create statement:-- \n" +createTableQuery)
        spark.sql(f"{createTableQuery}")
        print(f"Change log table created... {changelogTable}")
      else:
        print(f"change log table exists... {changelogTable} ..checking for schema drift")
        changeLogSchemaList=changeLogSchema.split("#")
        newChlgCols =list(map(lambda x :x.strip().split(" ")[0],changeLogSchemaList))
        showColQuery=f"SHOW COLUMNS IN {changelogTable}"
        chlgCols=spark.sql(showColQuery).select('col_name').rdd.map(lambda x :x[0]).collect()
        print("Existing  ChangeLog Table - columns  :",chlgCols)
        print("Schema Given by user -Columns :",newChlgCols)
        difference=[col for col in newChlgCols + chlgCols if col not in newChlgCols or col not in chlgCols]

        if len(difference)>0:
          print("Identified schema drift...")
          
          if (len(chlgCols)< len(newChlgCols)):
            print("new column found.... ")
            newColList=[]
            for col in difference:
              newColList=newColList+[newCol for newCol in changeLogSchemaList if newCol.startswith(col+" ")]
            newCols= ",".join(newColList)  
            alterQuery = f'ALTER TABLE {changelogTable} ADD COLUMNS({newCols})'
            spark.sql(alterQuery)
            print("Alter Query Executed...New columns added")
            
          else:
            print("Found deleted columns...")
            spark.sql(f'DROP TABLE IF EXISTS {changelogTable}')
            spark.sql(f'CREATE TABLE IF NOT EXISTS {changelogTable} ({changeLogSchema.replace("#",",")})')
            print("ChangeLog Table dropped and created again using new Schema")
            dbutils.fs.rm(f"{checkpoint_dir}/eventharmonization/{str(taskGroupId)}/{taskGroup['target_table']}{changelogPrefix}_chlg/",True)
            print("Removed  existing Harmonization checkpoint..")

        else :
          print("No schema drift...")
      
      for task in taskList:
        checkPoint=checkpoint_dir +"/"+"eventgeneration"+"/"+str(taskGroupId)+"/"+task['source_table']+"/"+"cp001"
        print("checkPoint is " + checkPoint)
        #added to get path
        if(task["sql_query"].startswith('/Repos')):
          notebook_args = {}
          for table,fields in {"group": group, "taskGroup": taskGroup, "task": task}.items():
            for field,value in fields.items():
              if field != 'user_properties':
                notebook_args[f'{table}__{field}'] = value
              else:
                value = value if value is not None and ':' in value else ":"
                for up_key,up_val in [hash_splitted_val.split(":") for hash_splitted_val in value.split("#")]:
                  notebook_args[f'{table}__{field}__{up_key}'] = up_val


          query_in_notebook = dbutils.notebook.run(f"{task['sql_query']}",0,notebook_args)
         
          task_query_dict[task['id']] = query_in_notebook
          
        else:
          print("Sql query notebook Path is not provided in the sql_query field")
        deltaHandler = DeltaHandlerClass(task,target_table,group['job_type'],group['run_type'],taskGroup['email_list'],taskGroup['user_properties'],taskGroup['servicenow_property'],changelogTable,taskGroup['encrypt_data'],taskGroup['encrypt_columns'],taskGroup['secret_key_details']) #to_be_upd
        try:
          readStream = spark.readStream.option("ignoreChanges", "true") 

          if (Type1_evntgen=="type1" and (orderby_evntgen==None or len(orderby_evntgen)==0)):
            readStream = readStream.option("readChangeFeed", "true")
          if(replay_flag==True):
              replay_columns=task["replaydatecolumn"]
              streamingDF=replay_hramonization_curation(replay_columns,task,maxBytesPerTrigger)
          else:
              streamingDF = readStream.option("maxBytesPerTrigger", maxBytesPerTrigger).format("delta").table(f"{task['source_db']}.{task['source_table']}")

          if (not(task['read_table_from_date'] is None or len(task['read_table_from_date'])==0)): 
            print("in ! empty readtablefromdate")
            streamingDF = streamingDF.filter(col("updatetime") >= task['read_table_from_date']) 
          streamQuery = streamingDF.writeStream.foreachBatch(deltaHandler.handleMicroBatch).option("checkpointLocation", checkPoint).option("queryName", str(task['source_table'])+"_"+str(taskGroupId))          

          if (taskGroup['run_type'] == "AVAILABLE_NOW"): 
            streamQuery = streamQuery.trigger(availableNow=True).option("maxBytesPerTrigger", maxBytesPerTrigger)
            
          streamQuery.start()
         
        except Exception as e:
          print(f"Stream FAILED for raw table: {task['source_table']}. {e}")

          #To send log info to splunk
          sendToSplunk(str(groupId), jobId, job_name, group['job_type'], group['run_type'], runId, -1, 0,  str(datetime.now()),"0", task['task_group_id'], task['id'], task['source_table'], changelogTable, clusterId,"Failed") 
          
          #create snow ticket and send email
          ##added for snowprop
          servicenow_property = taskGroup['servicenow_property'] if taskGroup['servicenow_property'] is None else taskGroup['servicenow_property'].strip()
          if servicenow_property:
            snow_property = servicenow_property
          else:
            snow_property = taskGroup['user_properties']
          ##added for snowprop

          errorHandler("exception", job_name,groupId,jobId,group['job_type'],runId, -1,0,0,"0",task['task_group_id'],task['id'],str(e).replace("\n", " "),taskGroup['email_list'],snow_property,metricsLogTable)
          
          #raise Exception(f"Stream FAILED for raw table: {task['source_table']}. {e}")
          
      if (taskGroup['run_type'] == 'ROUND_THE_CLOCK' and not(taskGroup['is_custom_notebook'])):
        startHarmonizeMergeStream(taskGroup)
      

  if group['is_custom_notebook']:#sid changes
#     baseFilePath = f"/Repos/dhfsid@nationwide.com/pcds-dhf-{environment}-2.0/dhf/pyspark/main/"
#     substr = "main/"
#     handler_path=group['handler_path']
#     appendPath = handler_path[handler_path.index(substr)+len(substr)-1:] 
    notebookHandlerPath = group['handler_path'] #if(f"{environment}" == "dev") else baseFilePath + appendPath
    print(f"NotebookPath is {notebookHandlerPath}")
    if(taskGroup['run_type'] == 'ROUND_THE_CLOCK'):
      dbutils.notebook.run(path = notebookHandlerPath, arguments={"groupId":str(groupId),"environment":environment,"checkpoint_dir":checkpoint_dir,"metricsLogTable":metricsLogTable,"ExJ_runId":str(runId) if runId is not None else ""}, timeout_seconds=0) 

   
    elif(taskGroup['run_type'] == 'AVAILABLE_NOW'):
      loop_start_time=datetime.now()
      canExitLoop=False
      completed_streamList=set()
      while not (canExitLoop):
        canExitLoop = True
        for taskGroup in taskGroupList:
          activeStreamList = [_.name for _ in spark.streams.active]
          taskGroupStreamList = [_ for _ in set(f"{_['source_table']}_{taskGroup['id']}" for _ in getTask(int(taskGroup['id']), taskGroup['job_type']))] 
          print(f"\n activeStreamList: {activeStreamList} \n taskGroupStreamList: {taskGroupStreamList}")
          if any(_ in taskGroupStreamList for _ in activeStreamList):
            canExitLoop = False
          else:
            completed_streamList.add(str(taskGroup['id']))
            print(f"\n Appended TASK GROUP {taskGroup['id']} to the to completed_streamList")
        loop_end_time=datetime.now()
        total_loop_time=int((loop_end_time-loop_start_time).total_seconds()/60)
        if(total_loop_time>=threshold_time):
          canExitLoop=True
        else:
          canExitLoop = False
          time.sleep(300)
      completed_streams=','.join(completed_streamList)
      print("completed streams are",completed_streams)
      
      if(len(completed_streamList)>0):
        dbutils.notebook.run(path = notebookHandlerPath, arguments={"groupId":str(groupId),"completed_streams":completed_streams,"environment":environment,"checkpoint_dir":checkpoint_dir,"metricsLogTable":metricsLogTable,"ExJ_runId":str(runId) if runId is not None else ""}, timeout_seconds=0)
      else:
         print("Harmonization is not completed for all the task groups")
    
  elif(group['run_type'] == "AVAILABLE_NOW"):
    startMergeStreamsForBatch(taskGroupList)
           
  if(group['run_type'] == "AVAILABLE_NOW") and not(group['is_custom_notebook']): #this entire block is for #jobOrch
    print("--- entering query monitor logic ---")
    taskGroupList_log = [_["id"] for _ in taskGroupList if _["id"] not in failed_taskgroups_list]
    print(f"taskGroupList_log: {taskGroupList_log}") #done
    
    while(len(taskGroupList_log) != 0):

      for taskGroup in list(taskGroupList_log):
        if (taskgroup_queryid_dict[taskGroup] not in [_.id for _ in spark.streams.active]) and (taskGroup not in failed_taskgroups_list):
          persistLog_external([[taskGroup,group['job_type'],runId,"Success",dt.now().date(),dt.now()]], metricsLogTable) #jobOrch
          print(f"{taskGroup} is added as success in log table, same will be removed from current loop")
          taskGroupList_log.remove(taskGroup)
        elif taskGroup in failed_taskgroups_list:
          print(f"taskgroup{taskGroup} was added to failed list, failure log will be pushed to log table, taskgroup will be removed from current loop")
          taskGroupList_log.remove(taskGroup)

# COMMAND ----------

startGenerationStreamingMain()

# COMMAND ----------



# COMMAND ----------


