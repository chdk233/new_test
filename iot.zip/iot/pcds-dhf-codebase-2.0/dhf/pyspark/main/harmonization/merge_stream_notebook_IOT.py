# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("completed_streams are :",completed_streams)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../utils/_utils

# COMMAND ----------

# MAGIC %run ../harmonization_child/IOT/SM_TRIP_POINT

# COMMAND ----------

# MAGIC %run ../harmonization_child/IOT/Integrated_Enrollment

# COMMAND ----------

def doHarmonize(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str,encryptColumns,secretKey,is_encryptdata):
  print("harmonizedDB and targetTable are",harmonizedDB,target)
  if harmonizedDB == "dhf_iot_harmonized_prod" and target == "trip_point":
    merge_trip_point_iot(microBatchDF, batchId, rawDB, harmonizedDB, target)
    
  if harmonizedDB == "dhf_iot_harmonized_prod" and target == "integrated_enrollment":
    integrated_enrollment_function(microBatchDF, batchId, harmonizedDB, target)
    

# COMMAND ----------

# MAGIC %run ../harmonization/merge_stream_master

# COMMAND ----------

startHarmonizerStreamingMain(groupId,completed_streams)
