# Databricks notebook source
# MAGIC %run ../harmonization/_event_harmonizer_library

# COMMAND ----------

def addSurrogateKey_Non_UDM(addSurrogateKey_clt_df, target):
  print("entering addSurrogateKey_DHFGeneric function")
  dataframe_cols=addSurrogateKey_clt_df.columns 
  surrogatekey_column_name = f'{target.split(".")[1][3:]}_ID'
  addSurrogateKey_clt_df=addSurrogateKey_clt_df.withColumn(surrogatekey_column_name, xxhash64(concat_ws(',',*dataframe_cols)))  
  print("end of addSurrogateKey_DHFGeneric function")
  return addSurrogateKey_clt_df


# COMMAND ----------

def removeLogicalDelete_clt_new (df,taskgrp):
  HARMZ_QUERY = "Harmz_Query_"+taskgrp
  print(" Inside removeLogicalDelete_clt_new Temp view name - ", HARMZ_QUERY)
  df.createOrReplaceGlobalTempView(HARMZ_QUERY)
  LogicalDelete = f"""SELECT * FROM GLOBAL_TEMP.{HARMZ_QUERY} WHERE SRC_PUBLICID NOT IN (SELECT SRC_PUBLICID FROM (SELECT T1.SRC_PUBLICID, T1.SRC_FIXEDID,CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED ,CASE WHEN MAX( CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) <> trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END ) OVER ( PARTITION BY T1.SRC_BRANCHID, T1.SRC_FIXEDID ) = 0 THEN 1 ELSE 0 END AS BRANCH_PRUNED ,RANK() OVER ( PARTITION BY T1.SRC_FIXEDID, T1.SRC_BRANCHID, trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) ORDER BY T1.SRC_UPDATETIME DESC, T1.SRC_CREATETIME DESC, T1.SRC_PUBLICID DESC ) AS JUST_ONE_PRUNE FROM (select distinct SRC_FIXEDID, SRC_BRANCHID, SRC_EFFECTIVEDATE, POLPER_PERIODSTART,SRC_EXPIRATIONDATE,POLPER_PERIODEND,SRC_PUBLICID,SRC_UPDATETIME,SRC_CREATETIME FROM GLOBAL_TEMP.{HARMZ_QUERY}) T1) WHERE IS_DELETED = 1 AND NOT (BRANCH_PRUNED = 1 AND JUST_ONE_PRUNE = 1))"""
  LDdf = spark.sql(LogicalDelete)
  return LDdf

def removeTestAgency_clt_new (df, rawDB, environment,taskgrp):
  if(environment.upper() == "PROD"):
    Harmz_Query = "Harmz_Query_"+taskgrp
    df.createOrReplaceGlobalTempView(Harmz_Query)
    print(" Inside removeTestAgency_clt_new Temp view name - ", Harmz_Query)
    Exclusion = f"select * from global_temp.{Harmz_Query} where NOT EXISTS (select '1' from ( SELECT DISTINCT polper.publicID FROM {rawDB}.PC_PolicyPeriod polper INNER JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID INNER JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id WHERE grp.Agencynum_ext IN ( select Distinct Agencynum_ext from {rawDB}.pc_group where trim(int(substr(pc_group.Agencynum_ext,4))) >= 29800 and trim(int(substr(pc_group.Agencynum_ext,4))) <= 29999 OR Agencynum_ext = '00019999') OR polper.PolicyNumber IN ('ACP BP013200000000','ACP BP013200000761')) temp  where temp.PUBLICID=POLPER_PUBLICID)"
    FinalDF = spark.sql(Exclusion)
    return FinalDF
  else:
    return df


# COMMAND ----------

def orphanRecordsQTOverlap_clt (df,harmonized_table ,partition_col ,partition_val ,key_column):
  stage_table = harmonized_table.split(".")[1] +'_'+ partition_val.replace("-","_")
  print("temp stage table name ", stage_table )
  df.show(1,False)
  df.createOrReplaceGlobalTempView(stage_table)
  
 
  update_nonbound_query1 = f"""MERGE INTO {harmonized_table} TGT USING 
(SELECT {partition_col},POL_KEY,key_column,UPDT_ROW_EXP_DTS,ETL_ROW_EFF_DTS FROM 
(SELECT {partition_col},POL_KEY,UPDT_ROW_EXP_DTS,key_column,ETL_ROW_EFF_DTS,ROW_NUMBER() OVER ( PARTITION BY POL_KEY,key_column,ETL_ROW_EFF_DTS ORDER BY UPDT_ROW_EXP_DTS DESC ) AS TIE_BREAKER 
FROM ( SELECT {partition_col},POL_KEY,key_column,ETL_ROW_EFF_DTS,ETL_ROW_EXP_DTS,COALESCE(LAG(ETL_ROW_EFF_DTS) OVER ( PARTITION BY POL_KEY,key_column ORDER BY ETL_ROW_EFF_DTS DESC), ETL_ROW_EXP_DTS) UPDT_ROW_EXP_DTS
FROM (SELECT DISTINCT TABLE1.{partition_col},TABLE1.POL_KEY,TABLE1.{key_column} as key_column,TABLE1.ETL_ROW_EFF_DTS,TABLE1.ETL_ROW_EXP_DTS,TABLE1.END_EFF_DT,TABLE1.END_EXP_DT 
FROM {harmonized_table} TABLE1 INNER JOIN {harmonized_table} TABLE2 ON TABLE1.POL_KEY = TABLE2.POL_KEY 
AND TABLE1.{key_column} = TABLE2.{key_column} AND TABLE1.END_EFF_DT < TABLE2.END_EXP_DT AND TABLE1.END_EXP_DT > TABLE2.END_EFF_DT AND TABLE1.END_EFF_DT <> TABLE2.END_EXP_DT AND (TABLE1.END_EFF_DT <> TABLE2.END_EFF_DT OR TABLE1.END_EXP_DT <> TABLE2.END_EXP_DT) AND TABLE1.ETL_ROW_EFF_DTS < TABLE2.ETL_ROW_EXP_DTS AND TABLE1.ETL_ROW_EXP_DTS > TABLE2.ETL_ROW_EFF_DTS and TABLE1.POL_KEY LIKE '%QT%' and TABLE1.{partition_col}=TABLE2.{partition_col} AND TABLE1.{partition_col}='{partition_val}'AND TABLE2.{partition_col}='{partition_val}') TMP ) WHERE ETL_ROW_EXP_DTS <> UPDT_ROW_EXP_DTS ) TMP2 
WHERE TIE_BREAKER = 1) UPDT ON (TGT.POL_KEY = UPDT.POL_KEY AND TGT.{key_column} = UPDT.key_column AND TGT.ETL_ROW_EFF_DTS = UPDT.ETL_ROW_EFF_DTS AND TGT.{partition_col}='{partition_val}' AND UPDT.{partition_col}='{partition_val}') 
WHEN MATCHED THEN UPDATE SET TGT.ETL_ROW_EXP_DTS = UPDT.UPDT_ROW_EXP_DTS,TGT.ETL_CURR_ROW_FL = 'N';"""
#   return update_nonbound_query1
  
  
  time.sleep(120)
  print("In orphanRecords_Clt ,sleep time 120 sec for update 2 for  ",partition_val," \n")
  df.show(1,False)
  spark.sql(update_nonbound_query1) 

# COMMAND ----------

def hash_col_generator_clt(target):
  surrogateID = (target[target.index(".")+4:]+"_ID").upper()
  
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","MD5_HASH","surrogatekey","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS"]
  hash_exclude_cols+= [surrogateID]
  
  allCols = spark.sql(f"select * from  {target}").columns
  #suffix = "_ID"
  #hash_cols=[i for i in allCols if not i.endswith(suffix)]
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  hash_cols = ','.join(hash_cols)
  create_hash=f' , LATEST_DATA AS (SELECT   {hash_cols} , ETL_ROW_EFF_DTS, xxhash64( {hash_cols})  as MD5_HASH from LATEST_DATA_OPZ where rn=1) select * from LATEST_DATA  '
  return create_hash

# COMMAND ----------

#Added new function for performance - 4/24/2023
def generate_DHF_query(harmz_query, scdkey, harmonized_table, micro_batch):
    logical_delete = """, logical_delete as (SELECT * FROM HRZ_Query WHERE SRC_PUBLICID NOT IN (SELECT SRC_PUBLICID FROM (SELECT T1.SRC_PUBLICID, T1.SRC_FIXEDID,CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED ,CASE WHEN MAX( CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) <> trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END ) OVER ( PARTITION BY T1.SRC_BRANCHID, T1.SRC_FIXEDID ) = 0 THEN 1 ELSE 0 END AS BRANCH_PRUNED ,RANK() OVER ( PARTITION BY T1.SRC_FIXEDID, T1.SRC_BRANCHID, trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) ORDER BY T1.SRC_UPDATETIME DESC, T1.SRC_CREATETIME DESC, T1.SRC_PUBLICID DESC ) AS JUST_ONE_PRUNE FROM (select distinct SRC_FIXEDID, SRC_BRANCHID, SRC_EFFECTIVEDATE, POLPER_PERIODSTART,SRC_EXPIRATIONDATE,POLPER_PERIODEND,SRC_PUBLICID,SRC_UPDATETIME,SRC_CREATETIME FROM HRZ_Query) T1) WHERE IS_DELETED = 1 AND NOT (BRANCH_PRUNED = 1 AND JUST_ONE_PRUNE = 1)))"""
  
  
    remove_duplicate_microbatch = """, LATEST_DATA_OPZ as
          (select 
		logical_delete.*, 
		row_number() over(partition by {scdkey} order by updatetime_tab1 desc,updatetime_tab2 desc, updatetime_tab3 desc) as rn 
	from logical_delete)"""  
  
    create_hash = hash_col_generator_clt(harmonized_table)

    harmz_query = harmz_query.replace('select * from HRZ_Query',' ').replace('{micro_batch}',micro_batch)
    harmz_query = f"{harmz_query} {logical_delete} {remove_duplicate_microbatch} {create_hash}"
    harmz_query = harmz_query.replace('{scdkey}',scdkey)
    return harmz_query

# COMMAND ----------

#Added new function for performance - 4/24/2023
def scdMerge_clt_perf(queryDF, harmonized_table, scdkey, partitionKey, partitionValue, surrogateId ):
  join_keys = scdkey.split(",")
  keyCol1 =join_keys[0]
  keyCol2 =join_keys[1]
  keyCol3 =join_keys[2] 
# Target Dataframe with Matching records
  targetDF=spark.sql(f"select * from {harmonized_table}")
  print("targetDF",targetDF.count())
  print("queryDF",queryDF.count())
  queryDF=queryDF.alias("events")  
  SrcTgtDF = queryDF.join(targetDF, (queryDF[f'{keyCol1}'] ==  targetDF[f'{keyCol1}'])  &   (queryDF[f'{keyCol2}'] == targetDF[f'{keyCol2}'])  &  (queryDF[f'{keyCol3}'] == targetDF[f'{keyCol3}'])  & 
  (targetDF[f'{partitionKey}'] ==  f'{partitionValue}')).select("events.*")
  FinalDF = queryDF.exceptAll(SrcTgtDF)
  print("SrcTgtDF", SrcTgtDF.count())
  print("FinalDF",FinalDF.count())
  return FinalDF

# COMMAND ----------

def addAuditColumnsRemoveDupsCdcSyncMultistream_clt_pt_perf(df, target, targetKey, partition_col, partition_val):
  join_keys = targetKey.split(",")
  keyCol1 =join_keys[0]
  keyCol2 =join_keys[1]
  print("keyCol1",keyCol1)
  print("keyCol2",keyCol2)
  newDF = df 
  print("newDF",newDF.printSchema() )
  tgtDF=spark.sql(f"select * from {target}").filter(col("PARTITION_VAL") == partition_val)
  print("selecting the common records between source and target: ")
  tgtDF.printSchema()
  SrcTargetDF = tgtDF.alias("targetDF").join(newDF.alias("srcDF"), targetKey.split(","), "leftsemi").select(*newDF.columns, col("targetDF.ETL_CURR_ROW_FL").alias("tgt_etl_curr_row_fl"))
  SrcTargetDF.show(3, False)
  print(targetKey)
  #tgtOrphanDF = SrcTargetDF.select("COVG_TERM_KEY", "END_EFF_DT","ETL_ROW_EFF_DTS", "tgt_etl_curr_row_fl").dropDuplicates(). \
  #tgtOrphanDF = SrcTargetDF.select("COVG_TERM_KEY", "END_EFF_DT", "tgt_etl_curr_row_fl").dropDuplicates(). \
  tgtOrphanDF = SrcTargetDF.select(f'{keyCol1}',f'{keyCol2}', "tgt_etl_curr_row_fl").dropDuplicates(). \
                    withColumn("curr_row_fl_y", when(col("tgt_etl_curr_row_fl") == "Y", lit(1)).otherwise(lit(0))).  \
                    withColumn("curr_row_fl_n", when(col("tgt_etl_curr_row_fl") == "N", lit(1)).otherwise(lit(0))).  \
                          groupBy(targetKey.split(",")).  \
                            agg(sum("curr_row_fl_y").alias("count_y"), \
                                sum("curr_row_fl_n").alias("count_n")). \
                                  filter((col("count_n") > 0) & (col("count_y") == 0))
  
  
  SrcTargetDF = SrcTargetDF.drop("tgt_etl_curr_row_fl")
 
  #doing the union of source and target
  print("Union of source and target")
  unionAllTempdf = newDF.withColumn("isTarget", lit(0)).union(SrcTargetDF.withColumn("isTarget", lit(1)))
  #  val unionTempdf = unionAllTempdf.drop("isTarget")
  #  unionTempdf.show(3, false)
  
  print("Drop Duplicates in unionTempdf: ")
  nonDupUnionDf = unionAllTempdf.dropDuplicates(["MD5_HASH","ETL_ROW_EFF_DTS"])
  #  nonDupUnionDf.show(3, false)
  
  # future dated record
  w3 = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("isTarget").desc())
  df2 = nonDupUnionDf.withColumn("dupe",  col("MD5_HASH") == lag("MD5_HASH", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull()) | (col("isTarget") == '1'))
  
#   // OOS record
#   //val w4 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col("ETL_ROW_EFF_DTS").desc,col("isTarget").desc)
#   // val df3 = df2.withColumn("dupe",  $"MD5_HASH" === lag($"MD5_HASH", 1).over(w4)).where(($"dupe" === false || $"dupe".isNull ||	$"isTarget" === '1')  )  
  df311 = df2.drop("isTarget","dupe")
  
  w = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFF_DTS"))
  auditDF = df311.withColumn("ETL_ROW_EXP_DTS", lead("ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when(col("ETL_ROW_EXP_DTS") == "9999-12-31", "Y").otherwise("N"))
  
  print("After adding Audit date columns")
  auditDF.show(10,False)
  # removing the orphan rows
  
#   if not (tgtOrphanDF.isEmpty):
#     nonOrphanDF = auditDF.join(tgtOrphanDF, targetKey.split(","), "leftanti")
#     return nonOrphanDF
#   else:
#     return auditDF

  nonOrphanDF = auditDF.join(tgtOrphanDF, targetKey.split(","), "leftanti")
  return nonOrphanDF

# COMMAND ----------

def orphanRecords_Clt_pt (df,harmonized_table ,partition_col ,partition_val ,key_column):
  df.filter(f"'{partition_col}' == '{partition_val}'").createOrReplaceGlobalTempView("stage_table")
  update_bound_query1 = f"""MERGE INTO {harmonized_table} TGT USING 
(SELECT {partition_col},pol_key,key_column,END_EFF_DT, LATEST_BY_POLICY as exp_dts FROM (SELECT {partition_col},pol_key, END_EFF_DT, {key_column} as key_column,ETL_ROW_EFF_DTS,
MAX(etl_row_eff_dts) OVER ( PARTITION BY pol_key, {key_column}, END_EFF_DT ) AS LATEST_BY_GRAIN, 
MAX(etl_row_eff_dts) OVER ( PARTITION BY pol_key ) AS LATEST_BY_POLICY 
FROM global_temp.stage_table 
WHERE POL_KEY NOT LIKE '%QT%' AND {partition_col}='{partition_val}') 
WHERE LATEST_BY_GRAIN < LATEST_BY_POLICY GROUP BY {partition_col},pol_key, key_column ,exp_dts, END_EFF_DT) UPDT 
ON TGT.pol_key = UPDT.pol_key and 
TGT.{key_column} = UPDT.key_column 
AND TGT.END_EFF_DT = UPDT.END_EFF_DT 
AND TGT.etl_curr_row_fl = 'Y'  
AND TGT.END_EFF_DT <> TGT.END_EXP_DT
AND TGT.{partition_col}='{partition_val}'
AND UPDT.{partition_col}='{partition_val}'
WHEN MATCHED THEN UPDATE SET TGT.etl_row_exp_dts = UPDT.exp_dts, TGT.etl_curr_row_fl = 'N',TGT.ETL_LAST_UPDATE_DTS = TO_TIMESTAMP(CURRENT_TIMESTAMP());"""

# --   update_nonbound_query1 = f"""MERGE INTO {harmonized_table} TGT USING 
# -- (SELECT {partition_col},POL_KEY,key_column,UPDT_ROW_EXP_DTS,ETL_ROW_EFF_DTS FROM 
# -- (SELECT {partition_col},POL_KEY,UPDT_ROW_EXP_DTS,key_column,ETL_ROW_EFF_DTS,ROW_NUMBER() OVER ( PARTITION BY POL_KEY,key_column,ETL_ROW_EFF_DTS ORDER BY UPDT_ROW_EXP_DTS DESC ) AS TIE_BREAKER 
# -- FROM ( SELECT {partition_col},POL_KEY,key_column,ETL_ROW_EFF_DTS,ETL_ROW_EXP_DTS,COALESCE(LAG(ETL_ROW_EFF_DTS) OVER ( PARTITION BY POL_KEY,key_column ORDER BY ETL_ROW_EFF_DTS DESC), ETL_ROW_EXP_DTS) UPDT_ROW_EXP_DTS
# -- FROM (SELECT DISTINCT TABLE1.{partition_col},TABLE1.POL_KEY,TABLE1.{key_column} as key_column,TABLE1.ETL_ROW_EFF_DTS,TABLE1.ETL_ROW_EXP_DTS,TABLE1.END_EFF_DT,TABLE1.END_EXP_DT 
# -- FROM {harmonized_table} TABLE1 INNER JOIN {harmonized_table} TABLE2 ON TABLE1.POL_KEY = TABLE2.POL_KEY 
# -- AND TABLE1.{key_column} = TABLE2.{key_column} AND TABLE1.END_EFF_DT < TABLE2.END_EXP_DT AND TABLE1.END_EXP_DT > TABLE2.END_EFF_DT AND TABLE1.END_EFF_DT <> TABLE2.END_EXP_DT AND (TABLE1.END_EFF_DT <> TABLE2.END_EFF_DT OR TABLE1.END_EXP_DT <> TABLE2.END_EXP_DT) AND TABLE1.ETL_ROW_EFF_DTS < TABLE2.ETL_ROW_EXP_DTS AND TABLE1.ETL_ROW_EXP_DTS > TABLE2.ETL_ROW_EFF_DTS and TABLE1.POL_KEY LIKE '%QT%' and TABLE1.{partition_col}=TABLE2.{partition_col} AND TABLE1.{partition_col}='{partition_val}'AND TABLE2.{partition_col}='{partition_val}') TMP ) WHERE ETL_ROW_EXP_DTS <> UPDT_ROW_EXP_DTS ) TMP2 
# -- WHERE TIE_BREAKER = 1) UPDT ON (TGT.POL_KEY = UPDT.POL_KEY AND TGT.{key_column} = UPDT.key_column AND TGT.ETL_ROW_EFF_DTS = UPDT.ETL_ROW_EFF_DTS AND TGT.{partition_col}='{partition_val}' AND UPDT.{partition_col}='{partition_val}') 
# -- WHEN MATCHED THEN UPDATE SET TGT.ETL_ROW_EXP_DTS = UPDT.UPDT_ROW_EXP_DTS,TGT.ETL_CURR_ROW_FL = 'N';"""

  update_nonbound_query1 = f"""WITH source_target AS (
  select distinct tgt.{partition_col}, tgt.POL_KEY, tgt.{key_column} as key_column, tgt.ETL_ROW_EFF_DTS, tgt.ETL_ROW_EXP_DTS, tgt.END_EFF_DT, tgt.END_EXP_DT
    from {harmonized_table} tgt INNER JOIN global_temp.stage_table src
      on tgt.POL_KEY = src.POL_KEY
     and tgt.{key_column} = src.{key_column}
     and tgt.POL_KEY LIKE '%QT%'
     and tgt.{partition_col} = src.{partition_col}
)
MERGE INTO {harmonized_table} TGT USING (
  SELECT {partition_col}, POL_KEY, key_column, UPDT_ROW_EXP_DTS, ETL_ROW_EFF_DTS
  FROM
    (SELECT {partition_col}, POL_KEY, UPDT_ROW_EXP_DTS, key_column, ETL_ROW_EFF_DTS, ROW_NUMBER() OVER (PARTITION BY POL_KEY, key_column, ETL_ROW_EFF_DTS ORDER BY UPDT_ROW_EXP_DTS DESC ) AS TIE_BREAKER
      FROM
        (SELECT {partition_col}, POL_KEY, key_column, ETL_ROW_EFF_DTS, ETL_ROW_EXP_DTS,
            COALESCE(LAG(ETL_ROW_EFF_DTS) OVER (PARTITION BY POL_KEY, key_column ORDER BY ETL_ROW_EFF_DTS DESC),ETL_ROW_EXP_DTS ) UPDT_ROW_EXP_DTS
          FROM
            (SELECT /*DISTINCT*/ TABLE1.{partition_col}, TABLE1.POL_KEY, TABLE1.key_column as key_column, TABLE1.ETL_ROW_EFF_DTS,TABLE1.ETL_ROW_EXP_DTS, TABLE1.END_EFF_DT, TABLE1.END_EXP_DT
              FROM source_target TABLE1 INNER JOIN source_target TABLE2
                 ON TABLE1.POL_KEY = TABLE2.POL_KEY
                AND TABLE1.key_column = TABLE2.key_column
                AND TABLE1.END_EFF_DT < TABLE2.END_EXP_DT
                AND TABLE1.END_EXP_DT > TABLE2.END_EFF_DT
                AND TABLE1.END_EFF_DT <> TABLE2.END_EXP_DT
                AND (TABLE1.END_EFF_DT <> TABLE2.END_EFF_DT OR TABLE1.END_EXP_DT <> TABLE2.END_EXP_DT)
                AND TABLE1.ETL_ROW_EFF_DTS < TABLE2.ETL_ROW_EXP_DTS
                AND TABLE1.ETL_ROW_EXP_DTS > TABLE2.ETL_ROW_EFF_DTS
                -- and TABLE1.POL_KEY LIKE '%QT%'
                -- and TABLE1.{partition_col} = TABLE2.{partition_col}
                -- AND TABLE1.{partition_col} = '{partition_val}'
                -- AND TABLE2.{partition_col} = '{partition_val}'
            ) TMP
        )
      WHERE ETL_ROW_EXP_DTS <> UPDT_ROW_EXP_DTS
    ) TMP2
  WHERE TIE_BREAKER = 1
) UPDT 
ON 
(
  TGT.POL_KEY = UPDT.POL_KEY
  AND TGT.{key_column} = UPDT.key_column
  AND TGT.ETL_ROW_EFF_DTS = UPDT.ETL_ROW_EFF_DTS
  AND TGT.{partition_col} = '{partition_val}'
  AND UPDT.{partition_col} = '{partition_val}'
)
WHEN MATCHED THEN
UPDATE
SET
  TGT.ETL_ROW_EXP_DTS = UPDT.UPDT_ROW_EXP_DTS,
  TGT.ETL_CURR_ROW_FL = 'N';"""
  
  spark.sql(update_bound_query1) 
  print("completed first query - ",datetime.now())
  spark.sql(update_nonbound_query1)