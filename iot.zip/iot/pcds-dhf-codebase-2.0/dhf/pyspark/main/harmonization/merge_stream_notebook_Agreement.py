# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "test")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("completed_streams are :",completed_streams)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../utils/_utils

# COMMAND ----------

# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/common/_event_harmonizer_child_common_policy_skinny

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/_event_harmonizer_line_coverable_template

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/_event_harmonizer_line_coverable_template

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/_event_harmonizer_si_condition_template

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/_event_harmonizer_si_condition_template

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/_event_harmonizer_si_coverable_template

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/_event_harmonizer_si_coverable_template

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/_event_harmonizer_si_exclusion_template

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/_event_harmonizer_si_exclusion_template

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/im/_event_harmonizer_child_im_generaltrans

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/im/_event_harmonizer_child_im_generaltrans

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/cop/_event_harmonizer_child_cop_generaltrans

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/cop/_event_harmonizer_child_cop_generaltrans

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/common/_event_harmonizer_additional_interest

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/common/_event_harmonizer_additional_interest

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/_event_harmonizer_pol_ans_template

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/_event_harmonizer_pol_ans_template

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/_event_harmonizer_term_template

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/_event_harmonizer_term_template

# COMMAND ----------

#%run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization_child/Agreement/commercial/clpc/cop/_event_harmonizer_dfcncy

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/clpc/cop/_event_harmonizer_dfcncy

# COMMAND ----------

def doHarmonize(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str,encryptColumns,secretKey,is_encryptdata):
  print("harmonizedDB and targetDB are",harmonizedDB,target)
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_LINE_CVRBL_VIJAY" ):
      agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)  
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_line_cvrbl" ):
      agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "ds_im_bldg_proj" ):
      agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "ds_pol_ans" ):
      agreement_clpc_pol_ans(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "ds_transit" ):
      agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "ds_jurs" ):
      agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
      
  ################## ADDNL INTRST ##################### 
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_POLICY_SKNY_R5" ):
    print("Calling agreement_clpc_policy_skinny")
    agreement_clpc_policy_skinny(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)    
      
     
  
  ################## ADDNL INTRST #####################
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_addl_intrst"):
    agreement_clpc_addnl_intrst(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
    
  ################## COP PROPERTY DFNCY #####################
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_prpty_dfncy"):
    agreement_clpc_cop_dfncy(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
    
   ################## COP CRIME DFNCY #####################
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_crime_dfncy"):
    agreement_clpc_cop_dfncy(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
    
   ################## COP SPOIL DFNCY #####################
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_spoil_dfncy"):
    agreement_clpc_cop_dfncy(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
  
  ################## COVG TERM #####################
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_covg_term"):
    agreement_clpc_covg_term(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
    
     ################## EXCL TERM #####################
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_excl_term"):
    agreement_clpc_covg_term(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
    
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_excl_term_IMGInstlFltr"):
    agreement_clpc_covg_term(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
    
   ################## COND TERM #####################
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_cond_term"):
    print("entered here.......")
    agreement_clpc_covg_term(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
  
  
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_motor_cargo" ):
    print('ds_motor_cargo entered')
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
  
  if harmonizedDB == "pcds_agreement_harmonized" and target == "ds_line_mod":
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
    
  if harmonizedDB == "pcds_agreement_harmonized" and target == "ds_line_blgd":
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
    
  if harmonizedDB == "pcds_agreement_harmonized" and target == "ds_line_bldg":
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
  
  if harmonizedDB == "pcds_agreement_harmonized" and target == "ds_line_loc":
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
    
  if harmonizedDB == "pcds_agreement_harmonized" and target == "ds_pol_line":
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
    
  if harmonizedDB == "pcds_agreement_harmonized" and target == "ds_mod_rf":
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
      
#   if harmonizedDB == "dhf_harmonize_stromboli" and target == "ds_general_trans":
#      merge_general_trans(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
 
    ############################## general Trans ##################################
  
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "ds_general_trans" ):
      TaskGroupId = f'{param_str.split("#")[7]}'
      taskGroup = getTaskGroup(TaskGroupId ) 
      source_table = taskGroup["source_table"]
      if 'pcx_imgcost_ext' in source_table:
        print("Processing ..... agreement im general transaction....")
        merge_general_trans(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
      elif 'pcx_copcost_ext' in source_table: 
        print("Processing ..... agreement cop general transaction....")
        merge_general_trans_cop(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
          
      
  
  if harmonizedDB == "pg_hrm" and target == "cc_claim_part_python_an_sql_qm":
    merge_cc_claim_ph(microBatchDF, batchId, rawDB, harmonizedDB, target)
    
  if harmonizedDB == "pg_hrm" and target == "cc_claim_test_python_rtc_nb_3":
    merge_cc_claim_ph2(microBatchDF, batchId, rawDB, harmonizedDB, target)
    
  if harmonizedDB == "pg_hrm" and target == "cc_claim_test_python_rtc_nb_4":
    merge_cc_claim_ph3(microBatchDF, batchId, rawDB, harmonizedDB, target)
    
  if harmonizedDB == "pg_hrm" and target == "cc_claim_harmonized":
    merge_cc_claim_ph_multitable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)#Added newly for Multi table write
    
  if harmonizedDB == "pg_hrm" and target =="cc_claim_target_sensitive":
    merge_cc_claim_encrypted(microBatchDF, batchId, rawDB, harmonizedDB, target,encryptColumns,secretKey,is_encryptdata) #with encryption
    
  if harmonizedDB == "pg_hrm" and target =="claim":
    merge_cc_claim_updt(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str) #with RDM
  #################################  COVG_TERM_DETAIL ################################## 
  
#   if (harmonizedDB == "dhf_harmonize_stromboli" and target == "DS_COVG_TERM" ):
#     print("Calling ..... agreement_clpc_covg_term ....")
#     agreement_clpc_covg_term(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)  
    
  ################################# SI entities ################################## 
    
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_si" ):
      TaskGroupId = f'{param_str.split("#")[7]}'
      taskGroup = getTaskGroup(TaskGroupId ) 
      source_table = taskGroup["source_table"]
      if 'exclitem_ext' in source_table:
        print("Calling ..... agreement_clpc_SI_Exclusion_coverable....")
        agreement_clpc_si_excl(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str) 
      elif 'covitem_ext' in source_table: 
        print("Calling ..... agreement_clpc_SI_coverable....")
        agreement_clpc_si_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
      elif 'cvitem_ext' in source_table: 
        print("Calling ..... agreement_clpc_SI_coverable....")
        agreement_clpc_si_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
      elif 'covschitem' in source_table:
        print("Calling ..... agreement_clpc_SI_coverable....")
        agreement_clpc_si_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
      elif 'conditem_ext' in source_table:
        print("Calling ..... agreement_clpc_SI_condition....")
        agreement_clpc_si_condition(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
    
  #---------------------------------------FLOOD_INFO-------------------------------------------------
  if (harmonizedDB.strip().lower() == "pcds_agreement_harmonized" and target.strip().lower() == "ds_flood_info"):
    agreement_clpc_line_coverable(microBatchDF, batchId, rawDB, harmonizedDB, target, param_str)
  
                              

# COMMAND ----------

# MAGIC %run ../harmonization/merge_stream_master

# COMMAND ----------

startHarmonizerStreamingMain(groupId,completed_streams)
