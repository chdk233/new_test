# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "test")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("completed_streams are :",completed_streams)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../utils/_utils

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/nm/_event_harmonizer_nm_retrieve

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/nm/_event_harmonizer_nm_status

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/nm/_event_harmonizer_nm_company_risk_ans

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/nm/_event_harmonizer_nm_company_class

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/nm/_event_harmonizer_nm_submit

# COMMAND ----------

# MAGIC %run ../harmonization_child/Agreement/commercial/nm/_event_harmonizer_nm_class_source

# COMMAND ----------

def doHarmonize(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str,encryptColumns,secretKey,is_encryptdata):
  print("harmonizedDB and targetDB are",harmonizedDB,target)
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_NM_RETRIEVE" ):
      print("Calling ..... DS_NM_RETRIEVE....")
      merge_nm_retreive(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)  

  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_NM_SUBMIT" ):
      print("Calling ..... DS_NM_SUBMIT....")
      merge_nm_submit(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)  

  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_NM_CHECK_STATUS" ):
      print("Calling ..... DS_NM_CHECK_STATUS....")
      merge_nm_check_status(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)  

  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_NM_COMPANY_CLASS" ):
      print("Calling ..... DS_NM_COMPANY_CLASS....")
      merge_nm_company_class(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)  

  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_NM_COMPANY_RISK_ANS" ):
      print("Calling ..... DS_NM_COMPANY_RISK_ANS....")
      merge_nm_company_risk_ans(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)
      
  if (harmonizedDB == "pcds_agreement_harmonized" and target == "DS_NM_CLASS_SOURCE" ):
      print("Calling ..... DS_NM_CLASS_SOURCE....")
      merge_nm_class_source(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str)        


# COMMAND ----------

# MAGIC %run ../harmonization/merge_stream_master

# COMMAND ----------

startHarmonizerStreamingMain(groupId,completed_streams)
