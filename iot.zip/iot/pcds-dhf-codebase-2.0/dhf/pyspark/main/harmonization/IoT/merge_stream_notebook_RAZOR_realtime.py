# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))


print("groupId in notebook is : ", groupId)
print("completed_streams are :",completed_streams)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../../utils/_utils

# COMMAND ----------

# MAGIC %run ../../harmonization_child/IOT/RAZOR_REALTIME_TRIP_POINT

# COMMAND ----------

def doHarmonize(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str,encryptColumns,secretKey,is_encryptdata):
  print("harmonizedDB",harmonizedDB)
  print("rawDB",rawDB)
  print("target",target)
  
  print("harmonizedDB and target Table are",harmonizedDB,target)
  if rawDB == f"dhf_iot_razor_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_point":
    razor_realtime_trip_point_iot(microBatchDF, batchId, rawDB, harmonizedDB, target)
    

# COMMAND ----------

# MAGIC %run ../merge_stream_master

# COMMAND ----------

startHarmonizerStreamingMain(groupId,completed_streams)
