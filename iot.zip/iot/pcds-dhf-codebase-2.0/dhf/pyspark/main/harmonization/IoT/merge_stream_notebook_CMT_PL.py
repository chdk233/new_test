# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))

print("groupId in notebook is : ", groupId)
print("completed_streams are :",completed_streams)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../../utils/_utils

# COMMAND ----------

# MAGIC %run ../../harmonization_child/IOT/CMT_PL_REALTIME_TRIP_POINT

# COMMAND ----------

# MAGIC %run ../../harmonization_child/IOT/CMT_PL

# COMMAND ----------

def doHarmonize(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str,encryptColumns,secretKey,is_encryptdata):
  print("harmonizedDB and targetTable are",harmonizedDB,target)
  if harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_summary":
    merge_cmt_pl_trip_summary_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_point":
    merge_trip_point_iot(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_event":
    merge_cmt_pl_trip_events_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_gps_waypoints":
    merge_cmt_pl_GPS_waypts_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "fraud_daily":
    merge_cmt_pl_fraud_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "heartbeat_daily":
    merge_cmt_pl_heartbeat_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "badge_daily":
    merge_cmt_pl_badge_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "driver_summary_daily":
    merge_cmt_pl_driver_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "user_permissions_daily":
    merge_cmt_pl_user_permissions_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_labels_daily":
    merge_cmt_pl_trip_labels_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_summary_daily":
    merge_cmt_pl_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "driver_profile_daily":
    merge_cmt_pl_driver_profile_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_raw_score_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_driver_score":
    merge_cmt_pl_trip_driver_score(microBatchDF, batchId, rawDB, harmonizedDB, target)
  
    

# COMMAND ----------

# MAGIC %run ../../harmonization/merge_stream_master

# COMMAND ----------

startHarmonizerStreamingMain(groupId,completed_streams)
