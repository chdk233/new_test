# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

dbutils.widgets.text(name = "groupId",defaultValue = "")
groupId = dbutils.widgets.get('groupId')

dbutils.widgets.text(name = "completed_streams",defaultValue = "")
completed_streams = dbutils.widgets.get('completed_streams')

dbutils.widgets.text(name = "environment",defaultValue = "dev")
environment = dbutils.widgets.get('environment')

dbutils.widgets.text(name = "checkpoint_dir",defaultValue = "")
checkpoint_dir = dbutils.widgets.get('checkpoint_dir')

dbutils.widgets.text(name = "metricsLogTable",defaultValue = "")
metricsLogTable = dbutils.widgets.get('metricsLogTable')#added new for metrics table

dbutils.widgets.text(name = "ExJ_runId",defaultValue = "")
ExJ_runId = None if dbutils.widgets.get('ExJ_runId')=="" else int(dbutils.widgets.get('ExJ_runId'))


print("groupId in notebook is : ", groupId)
print("completed_streams are :",completed_streams)
print("environment in notebook is : ", environment)
print("checkpoint_dir in notebook is : ", checkpoint_dir)
print("metricsLogTable in notebook is : ", metricsLogTable)
print("ExJ_runId in notebook is: ",ExJ_runId)

# COMMAND ----------

# MAGIC %run ../../../utils/_utils

# COMMAND ----------

# MAGIC %run ../../harmonization_child/IOT/CL_PP

# COMMAND ----------

def doHarmonize(microBatchDF, batchId, rawDB, harmonizedDB, target,param_str,encryptColumns,secretKey,is_encryptdata):
  print("harmonizedDB and targetTable are",harmonizedDB,target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "breadcrumb_daily":
    merge_azuga_cl_pp_breadcrumb_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "aggregate_daily":
    merge_azuga_cl_pp_aggregate_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "master_acct_report":
    merge_azuga_cl_pp_master_acct_report(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "driver_listing_daily":
    merge_azuga_cl_pp_driver_listing_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "vehicle_listing_daily":
    merge_azuga_cl_pp_vehicle_listing_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "diagnostics_daily":
    merge_azuga_cl_pp_diagnostics_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "events_daily":
    merge_azuga_cl_pp_events_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "azuga_trip_summary_daily":
    merge_azuga_cl_pp_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "vehicle_summary_daily":
    merge_azuga_cl_pp_vehicle_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "azuga_hf_trip_summary":
    merge_azuga_cl_pp_hf_trip_summary(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_azuga_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target.lower() == "azuga_hf_trip_point":
    merge_azuga_cl_pp_hf_trip_point(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_zubie_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_summary":
    merge_zubie_cl_pp_trip_summary_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_zubie_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "xref_account_device_car":
    merge_zubie_cl_pp_xref_acct_devc_car_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_zubie_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_event":
    merge_zubie_cl_pp_driving_events_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_zubie_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "non_trip_event":
    merge_zubie_cl_pp_device_events_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_zubie_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "compliancekpi":
    merge_zubie_cl_pp_compliancekpi_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_zubie_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "programkpi":
    merge_zubie_cl_pp_programkpi_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_zubie_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_point":
    merge_zubie_cl_pp_trip_point_weekly(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "fraud_daily":
    merge_cmt_cl_pp_fraud_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "heartbeat_daily":
    merge_cmt_cl_pp_heartbeat_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "badge_daily":
    merge_cmt_cl_pp_badge_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "driver_summary_daily":
    merge_cmt_cl_pp_driver_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "team_summary_daily":
    merge_cmt_cl_pp_team_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "user_permissions_daily":
    merge_cmt_cl_pp_user_permissions_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_labels_daily":
    merge_cmt_cl_pp_trip_labels_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_summary_daily":
    merge_cmt_cl_pp_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "vehicle_tag_summary_daily":
    merge_cmt_cl_pp_vehicle_tag_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "driver_profile_daily":
    merge_cmt_cl_pp_driver_profile_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "tag_link_daily":
    merge_cmt_cl_pp_tag_link_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "tag_trip_summary_daily":
    merge_cmt_cl_pp_tag_trip_summary_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "portal_user_activity_report_daily":
    merge_cmt_cl_pp_portal_user_activity_report_daily(microBatchDF, batchId, rawDB, harmonizedDB, target)
  ### CMT realtime
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_summary":
    merge_cmt_cl_pp_trip_summary_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_event": 
    merge_cmt_cl_pp_trip_events_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target)
  if rawDB == f"dhf_iot_cmt_cl_raw_{environment}" and harmonizedDB == f"dhf_iot_harmonized_{environment}" and target == "trip_gps_waypoints":
    merge_cmt_cl_pp_GPS_waypts_realtime(microBatchDF, batchId, rawDB, harmonizedDB, target)

# COMMAND ----------

# MAGIC %run ../../harmonization/merge_stream_master

# COMMAND ----------

startHarmonizerStreamingMain(groupId,completed_streams)
