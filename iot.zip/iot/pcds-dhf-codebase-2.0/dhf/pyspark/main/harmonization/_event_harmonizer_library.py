# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.window import *
from pyspark import SparkContext
from pyspark import SQLContext
from delta.tables import *
from pyspark.sql.types import *
from functools import reduce
import time

# COMMAND ----------

# Agreement Related functions
def removeTestAgency_clt (df, rawDB, environment):
  if(environment.upper() == "PROD"):
    df.createOrReplaceGlobalTempView("Harmz_Query")
    Exclusion = f"select * from global_temp.Harmz_Query where NOT EXISTS (select '1' from ( SELECT DISTINCT polper.publicID FROM {rawDB}.PC_PolicyPeriod polper INNER JOIN {rawDB}.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID INNER JOIN {rawDB}.pc_group grp ON prodcode.branchID = grp.id WHERE grp.Agencynum_ext IN ( select Distinct Agencynum_ext from {rawDB}.pc_group where trim(int(substr(pc_group.Agencynum_ext,4))) >= 29800 and trim(int(substr(pc_group.Agencynum_ext,4))) <= 29999 OR Agencynum_ext = '00019999') OR polper.PolicyNumber IN ('ACP BP013200000000','ACP BP013200000761')) temp  where temp.PUBLICID=POLPER_PUBLICID)"
    FinalDF = spark.sql(Exclusion)
    return FinalDF
  else:
    return df

def addSurrogateID_clt(df,target):  
  maxSK = spark.table(f"{target}").count()
  surrogateID= target[target.index(".")+4:]+"_ID"
  w  = Window.orderBy(col("ETL_ROW_EFF_DTS"))
  df1 = df.withColumn(surrogateID, row_number().over(w) + maxSK)    
  tempView_name = target.split(".")[1]
  print('Temp view name ===>',tempView_name)
  df1.createOrReplaceGlobalTempView(tempView_name)
  df2 = spark.sql(f"select *,XXHASH64({surrogateID},PARTITION_VAL) as {surrogateID}_New from global_temp.{tempView_name} ")
  df3 = df2.drop(f"{surrogateID}").withColumnRenamed(f"{surrogateID}_New",f"{surrogateID}")  
  return df3


def getSurrogateIDCol_clt(target):
  surrogateID= target[target.index(".")+4:]+"_ID"
  return surrogateID

def getSurrogateIDReturnCol_clt(df, target, surrogate):
  maxSK = spark.table(f"{target}").count()
  surrogateID= surrogate
  return surrogateID

def addSurrogateID(df,target,surrogate):
  maxSK = spark.table(f"{target}").count()
  surrogateID= surrogate
  w = Window.orderBy("ETL_ROW_EFF_DTS")
  df1 = df.withColumn(surrogateID, row_number().over(w) + maxSK)
  df1.createOrReplaceGlobalTempView("surrogateKeyData")
  df2 = spark.sql(f"select *,XXHASH64({surrogateID},PARTITION_VAL) as {surrogateID}_New from global_temp.surrogateKeyData")
  df3 = df2.drop(f"{surrogateID}").withColumnRenamed(f"{surrogateID}_New",f"{surrogateID}")
  return df3
  
def addHashColumnXXHash_clt(viewname):
  allCols = spark.sql(f"select * from global_temp.{viewname}").columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","MD5_HASH","surrogatekey","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS"]
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  print("hash_exclude_cols: ", hash_exclude_cols)
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)
  cols=','.join(hash_cols)
  qry=f"select *,XXHASH64({cols}) as MD5_HASH from global_temp.{viewname}"
  print("hash_query: ", qry) 
  hash_df = spark.sql(qry)
  return hash_df



def removeDuplicatesMultistream_clt(df, target, targetKey, partitionKey, partitionValue):
  print("in removeduplicates function2 \n")

  join_keys=targetKey.split(",")
  w = Window.partitionBy(*join_keys).orderBy(col("ETL_ROW_EFF_DTS"))
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print(firsRowDF.columns)

  targetDF = spark.sql(f"select * from {target} where {partitionKey} = '{partitionValue}' and ETL_CURR_ROW_FL = 'Y'")#//DeltaTable.forName(spark, target).toDF
  joinExprs=''
  for i in join_keys:
    joinExprs1=f"firsRowDF['{i}'] == targetDF['{i}']"
    joinExprs=joinExprs+ " & "+ joinExprs1
  joinExprs=joinExprs[2:len(joinExprs)]
  keyCol1 =join_keys[0]
  keyCol2 =join_keys[1]
  
  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = targetDF.join(firsRowDF,  (firsRowDF[f'{keyCol1}'] == targetDF[f'{keyCol1}']) & (firsRowDF[f'{keyCol2}'] == targetDF[f'{keyCol2}'])).filter(col("targetDF.ETL_CURR_ROW_FL") == 'Y').select("targetDF.*").select(firsRowDF.columns)
  
   #//val latestInTargetDF = firsRowDF.join(targetDF.as("targetDF"), joinExprs && s"targetDF.${partitionKey}" == partitionValue, "right").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select($"targetDF.*").select(firsRowDF.schema.fieldNames.toList.map(col): _*)
   #//     val latestInTargetDF = targetDF.as("targetDF").join(firsRowDF, joinExprs && s"targetDF.${partitionKey}" == partitionValue, "leftsemi").filter($"targetDF.ETL_CURR_ROW_FL" === 'Y').select(firsRowDF.schema.fieldNames.toList.map(col): _*)
  print("\n latestInTargetDF cols")
  print(latestInTargetDF.columns)
  df=df.alias("df")

  outOfSeqDF = latestInTargetDF.join(df, (df[f'{keyCol1}'] == latestInTargetDF[f'{keyCol1}']) & (df[f'{keyCol2}'] == latestInTargetDF[f'{keyCol2}']), "right").filter( ((col("df.ETL_ROW_EFF_DTS")) > (latestInTargetDF['ETL_ROW_EFF_DTS'])) & (latestInTargetDF[f'{keyCol1}'].isNotNull()) | (latestInTargetDF[f'{keyCol1}'].isNull()) ).select("df.*").select(df.columns)

   
  #add target latest rows to microbatch
  df2 = outOfSeqDF.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
  df2.show(3,False)

  #//remove consecutive duplicates, choose first
  partition_cols=targetKey.split(",")
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("isTarget").desc())
  df3 = df2.withColumn("dupe",  col("MD5_HASH") == lag("MD5_HASH", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe")

   #If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 =  Window.partitionBy(*partition_cols)
  df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
  df4.show(3,False)
  return df4


#This function to remove duplictes based on Key column combination in a micrbatch based on the specified order by clause
def removeDuplicatesMicrobatch_clt(df, partitionKeys, orderbyCols):
  print("in removeduplicates microbatch function \n")
  partition_cols=partitionKeys.split(",")
  orderyby_cols=orderbyCols.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(*[desc(c) for c in orderyby_cols])
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  return firsRowDF

#This function to remove duplictes based on Key column combination based on the specified order by clause
def removeDuplicates(df, partitionKeys, orderbyCols, order):                                                  
  print("in removeduplicates function \n")
  partition_cols = partitionKeys.split(",")
  orderyby_cols = orderbyCols.split(",")                                                
  if (order.lower() == "desc"):
    w = Window.partitionBy(*partition_cols).orderBy(*[desc(c) for c in orderyby_cols])
    firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
    return firsRowDF
  else:
    w = Window.partitionBy(partition_cols).orderBy(orderyby_cols)
    firsRowDF = df.withColumn("rownum", row_number.over(w)).where(col("rownum") == 1).drop("rownum")
    return firsRowDF

def addAuditColumns_clt(df, targetKey):
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  auditDF = df.withColumn("ETL_ROW_EXP_DTS", lead("ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when(col("ETL_ROW_EXP_DTS") == "9999-12-31", "Y").otherwise("N"))
  return auditDF

  

  

# // This function is same as above function, but uses SQL suntax to do the window function instead of scala. Needs to be tested for composite key before being used.
# // def addAuditColumns_clt(viewname: String, targetKey: String) = {       
# //     val auditDF = spark.sql(s"""SELECT *,
# //             LEAD(ETL_ROW_EFF_DTS,1,"9999") OVER (PARTITION BY $targetKey ORDER BY ETL_ROW_EFF_DTS ASC) as ETL_ROW_EXP_DTS, 'N' as ETL_CURR_ROW_FL  , current_timestamp() as ETL_ADD_DTS, current_timestamp() as ETL_LAST_UPDATE_DTS
# //             FROM global_temp.${viewname}""").withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999", "Y").otherwise("N"))        
# //   auditDF
# // }

def defaultMergeMultistream_clt (df, target, partition_col, partition_val):
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(df.alias("updates"), f"events.MD5_HASH = updates.MD5_HASH AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL" : "'N'","ETL_LAST_UPDATE_DTS" : "current_timestamp()"}).whenNotMatchedInsertAll().execute()
  


# //def removeLogicalDelete_clt (df: DataFrame): DataFrame = {
# //df.createOrReplaceGlobalTempView("Harmz_Query")

# //var LogicalDelete = """select * from global_temp.Harmz_Query where (COALESCE(SRC_EFFECTIVEDATE, POLPER_PERIODSTART ) <> //COALESCE(SRC_EXPIRATIONDATE, POLPER_PERIODEND) OR NOT EXISTS (SELECT 1 FROM global_temp.Harmz_Query TBL2 WHERE SRC_BRANCHID = TBL2.SRC_BRANCHID AND   SRC_FIXEDID  = TBL2.SRC_FIXEDID AND (COALESCE(TBL2.SRC_EFFECTIVEDATE, POLPER_PERIODSTART) <>COALESCE(TBL2.SRC_EXPIRATIONDATE, POLPER_PERIODEND))))""" 
#  // var LDdf = spark.sql(LogicalDelete) 
#   //return LDdf 
# //}

def removeLogicalDelete_clt (df):
  df.createOrReplaceGlobalTempView("Harmz_Query")
  LogicalDelete = """SELECT * FROM GLOBAL_TEMP.HARMZ_QUERY WHERE SRC_PUBLICID NOT IN (SELECT SRC_PUBLICID FROM (SELECT T1.SRC_PUBLICID, T1.SRC_FIXEDID,CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED ,CASE WHEN MAX( CASE WHEN trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) <> trim(COALESCE(T1.SRC_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END ) OVER ( PARTITION BY T1.SRC_BRANCHID, T1.SRC_FIXEDID ) = 0 THEN 1 ELSE 0 END AS BRANCH_PRUNED ,RANK() OVER ( PARTITION BY T1.SRC_FIXEDID, T1.SRC_BRANCHID, trim(COALESCE(T1.SRC_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) ORDER BY T1.SRC_UPDATETIME DESC, T1.SRC_CREATETIME DESC, T1.SRC_PUBLICID DESC ) AS JUST_ONE_PRUNE FROM (select distinct SRC_FIXEDID, SRC_BRANCHID, SRC_EFFECTIVEDATE, POLPER_PERIODSTART,SRC_EXPIRATIONDATE,POLPER_PERIODEND,SRC_PUBLICID,SRC_UPDATETIME,SRC_CREATETIME FROM GLOBAL_TEMP.HARMZ_QUERY) T1) WHERE IS_DELETED = 1 AND NOT (BRANCH_PRUNED = 1 AND JUST_ONE_PRUNE = 1))"""
  LDdf = spark.sql(LogicalDelete)
  return LDdf


def removeLogicalDelete_gt (df):
  df.createOrReplaceGlobalTempView("Harmz_Query")
  LogicalDeleteCost = """SELECT * FROM GLOBAL_TEMP.HARMZ_QUERY WHERE SRC_COST_PUBLICID NOT IN (SELECT SRC_COST_PUBLICID FROM (SELECT T1.SRC_COST_PUBLICID, T1.SRC_COST_FIXEDID, CASE WHEN TRIM(COALESCE(T1.SRC_COST_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = TRIM(COALESCE(T1.SRC_COST_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED FROM GLOBAL_TEMP.HARMZ_QUERY T1 WHERE POL_KEY LIKE '%QT%' ) WHERE IS_DELETED = 1)"""
    
  df.createOrReplaceGlobalTempView("LogicalDeleteCost")
  LogicalDeleteTran = """SELECT * FROM GLOBAL_TEMP.LogicalDeleteCost WHERE SRC_TRAN_PUBLICID NOT IN (SELECT SRC_TRAN_PUBLICID FROM (SELECT T1.SRC_TRAN_PUBLICID, T1.SRC_TRAN_FIXEDID, CASE WHEN TRIM(COALESCE(T1.SRC_TRAN_EFFECTIVEDATE, T1.POLPER_PERIODSTART)) = TRIM(COALESCE(T1.SRC_TRAN_EXPIRATIONDATE, T1.POLPER_PERIODEND)) THEN 1 ELSE 0 END AS IS_DELETED  FROM GLOBAL_TEMP.LogicalDeleteCost T1 WHERE POL_KEY NOT LIKE '%QT%' ) WHERE IS_DELETED = 1)"""
  LDdf = spark.sql(LogicalDeleteTran)
  return LDdf


def orphanRecords_Clt (df,harmonized_table ,partition_col ,partition_val ,key_column):
  df.createOrReplaceGlobalTempView("stage_table")
  update_bound_query1 = f"""MERGE INTO {harmonized_table} TGT USING 
(SELECT {partition_col},pol_key,key_column,END_EFF_DT, LATEST_BY_POLICY as exp_dts FROM (SELECT {partition_col},pol_key, END_EFF_DT, {key_column} as key_column,ETL_ROW_EFF_DTS,
MAX(etl_row_eff_dts) OVER ( PARTITION BY pol_key, {key_column}, END_EFF_DT ) AS LATEST_BY_GRAIN, 
MAX(etl_row_eff_dts) OVER ( PARTITION BY pol_key ) AS LATEST_BY_POLICY 
FROM global_temp.stage_table 
WHERE POL_KEY NOT LIKE '%QT%' AND {partition_col}='{partition_val}') 
WHERE LATEST_BY_GRAIN < LATEST_BY_POLICY GROUP BY {partition_col},pol_key, key_column ,exp_dts, END_EFF_DT) UPDT 
ON TGT.pol_key = UPDT.pol_key and 
TGT.{key_column} = UPDT.key_column 
AND TGT.END_EFF_DT = UPDT.END_EFF_DT 
AND TGT.etl_curr_row_fl = 'Y'  
AND TGT.END_EFF_DT <> TGT.END_EXP_DT
AND TGT.{partition_col}='{partition_val}'
AND UPDT.{partition_col}='{partition_val}'
WHEN MATCHED THEN UPDATE SET TGT.etl_row_exp_dts = UPDT.exp_dts, TGT.etl_curr_row_fl = 'N',TGT.ETL_LAST_UPDATE_DTS = TO_TIMESTAMP(CURRENT_TIMESTAMP());"""

  update_nonbound_query1 = f"""MERGE INTO {harmonized_table} TGT USING 
(SELECT {partition_col},POL_KEY,key_column,UPDT_ROW_EXP_DTS,ETL_ROW_EFF_DTS FROM 
(SELECT {partition_col},POL_KEY,UPDT_ROW_EXP_DTS,key_column,ETL_ROW_EFF_DTS,ROW_NUMBER() OVER ( PARTITION BY POL_KEY,key_column,ETL_ROW_EFF_DTS ORDER BY UPDT_ROW_EXP_DTS DESC ) AS TIE_BREAKER 
FROM ( SELECT {partition_col},POL_KEY,key_column,ETL_ROW_EFF_DTS,ETL_ROW_EXP_DTS,COALESCE(LAG(ETL_ROW_EFF_DTS) OVER ( PARTITION BY POL_KEY,key_column ORDER BY ETL_ROW_EFF_DTS DESC), ETL_ROW_EXP_DTS) UPDT_ROW_EXP_DTS
FROM (SELECT DISTINCT TABLE1.{partition_col},TABLE1.POL_KEY,TABLE1.{key_column} as key_column,TABLE1.ETL_ROW_EFF_DTS,TABLE1.ETL_ROW_EXP_DTS,TABLE1.END_EFF_DT,TABLE1.END_EXP_DT 
FROM {harmonized_table} TABLE1 INNER JOIN {harmonized_table} TABLE2 ON TABLE1.POL_KEY = TABLE2.POL_KEY 
AND TABLE1.{key_column} = TABLE2.{key_column} AND TABLE1.END_EFF_DT < TABLE2.END_EXP_DT AND TABLE1.END_EXP_DT > TABLE2.END_EFF_DT AND TABLE1.END_EFF_DT <> TABLE2.END_EXP_DT AND (TABLE1.END_EFF_DT <> TABLE2.END_EFF_DT OR TABLE1.END_EXP_DT <> TABLE2.END_EXP_DT) AND TABLE1.ETL_ROW_EFF_DTS < TABLE2.ETL_ROW_EXP_DTS AND TABLE1.ETL_ROW_EXP_DTS > TABLE2.ETL_ROW_EFF_DTS and TABLE1.POL_KEY LIKE '%QT%' and TABLE1.{partition_col}=TABLE2.{partition_col} AND TABLE1.{partition_col}='{partition_val}'AND TABLE2.{partition_col}='{partition_val}') TMP ) WHERE ETL_ROW_EXP_DTS <> UPDT_ROW_EXP_DTS ) TMP2 
WHERE TIE_BREAKER = 1) UPDT ON (TGT.POL_KEY = UPDT.POL_KEY AND TGT.{key_column} = UPDT.key_column AND TGT.ETL_ROW_EFF_DTS = UPDT.ETL_ROW_EFF_DTS AND TGT.{partition_col}='{partition_val}' AND UPDT.{partition_col}='{partition_val}') 
WHEN MATCHED THEN UPDATE SET TGT.ETL_ROW_EXP_DTS = UPDT.UPDT_ROW_EXP_DTS,TGT.ETL_CURR_ROW_FL = 'N';"""

  spark.sql(update_bound_query1) 
  spark.sql(update_nonbound_query1) 



#function to remove additional columns present in Harmonize query
def removeAdditionalCols_clt (df, target ):
  print("in AdditionalColstoRemove function \n")
  dfCols = df.columns
  dfCols=[x.lower() for x in dfCols]
  targetCols = spark.table(f"{target}").columns
  targetCols=[x.lower() for x in targetCols]
  AdditionalColsToRemove=[i for i in dfCols if i not in targetCols]
  print("Additional Columns list: \n")
  print(AdditionalColsToRemove)
  queryDF =df.drop(*AdditionalColsToRemove)
  return queryDF


def removeDuplicatesMicrobatchByHash_clt(df, targetKey ):
  print("in removeDuplicatesMicrobatch By Hash \n")

  #remove consecutive duplicates, choose first
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(partition_cols).orderBy(col("ETL_ROW_EFF_DTS").asc())
  df1 = df.withColumn("dupe",  col("MD5_HASH") == lag("MD5_HASH", 1).over(w)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe")
  df1.show(3,False)
  return df1


def scdMerge_clt(queryDF, harmonized_table, key, partitionKey, partitionValue, surrogateId ):
  join_keys = key.split(",")
  keyCol1 =join_keys[0]
  keyCol2 =join_keys[1]
  keyCol3 =join_keys[2] 
  

#Target Dataframe with Matching records
  updates=spark.sql(f"select * from {harmonized_table}")
  updates=updates.alias("updates")
  targetDF  =  queryDF.join(updates , (queryDF[f'{keyCol1}'] ==  updates[f'{keyCol1}'])  &  (queryDF[f'{keyCol2}'] == updates[f'{keyCol2}'])  &  (queryDF[f'{keyCol3}'] == updates[f'{keyCol3}'])  & (updates[f'{partitionKey}'] == f'{partitionValue}')).select("updates.*")
  
  
#DataFrame for Type1 records with same MD5_HASH value from Source Microbtach Dataframe
  queryDF=queryDF.alias("events")
  SrcTgtDF = queryDF.join(targetDF, (queryDF[f'{keyCol1}'] ==  targetDF[f'{keyCol1}'])  &   (queryDF[f'{keyCol2}'] == targetDF[f'{keyCol2}'])  &  (queryDF[f'{keyCol3}'] == targetDF[f'{keyCol3}'])  &  (targetDF[f'{partitionKey}'] == f'{partitionValue}') & (queryDF["MD5_HASH"] == targetDF["MD5_HASH"])).select("events.*")
  

 #// DataFrame for Type1 records with different MD5_HASH value & Non-Type1 from Source Microbtach Dataframe
  queryDF1 = queryDF.exceptAll(SrcTgtDF)                       

 #DataFrame with SrcMD5Hash <> TgtMD5Hash , Replaced Src with Tgt columns (ETL_ROW_EXP_DTS & ETL_ADD_DTS) to comply with databricks merge statement
  queryDF1=queryDF1.alias("events")
  targetDF=targetDF.alias("targetDF")                      
  SrcTgtDF1 = queryDF1.join(targetDF, (queryDF1[f'{keyCol1}'] ==  targetDF[f'{keyCol1}'])  &  (queryDF1[f'{keyCol2}'] == targetDF[f'{keyCol2}'])  &  (queryDF1[f'{keyCol3}'] == targetDF[f'{keyCol3}'])  &  (targetDF[f'{partitionKey}'] == f'{partitionValue}')  & (queryDF1["MD5_HASH"] != updates["MD5_HASH"])).select("events.*",col("targetDF.ETL_ROW_EXP_DTS").alias("Tgt_Exp"),col("targetDF.ETL_ADD_DTS").alias("Tgt_Ead"), col(f'targetDF.{surrogateId}').alias("Tgt_ID"),col("targetDF.ETL_CURR_ROW_FL").alias("Tgt_Curr_Row_Fl"))
                          

  SrcTgtDF2 = SrcTgtDF1.withColumnRenamed("Tgt_Ead","ETL_ADD_DTS").withColumnRenamed("Tgt_Exp","ETL_ROW_EXP_DTS").withColumnRenamed("Tgt_ID",f'{surrogateId}').withColumnRenamed("Tgt_Curr_Row_Fl","ETL_CURR_ROW_FL").withColumn("ETL_LAST_UPDATE_DTS", current_timestamp())

# Merging Source DF with Tgt if any updates on existing data 
  #descr= spark.sql(f"describe table extended {harmonized_table}")
  #location=descr.filter(col("col_name")=="Location").select("data_type").first()[0]
  delta_table=DeltaTable.forName(spark, harmonized_table)
  delta_table.alias("t").merge(SrcTgtDF2.alias("s"),f"t.{keyCol1} = s.{keyCol1} AND t.{keyCol2} = s.{keyCol2} AND t.{keyCol3} = s.{keyCol3} AND t.{partitionKey} = '{partitionValue}' AND t.MD5_HASH != s.MD5_HASH").whenMatchedUpdateAll().execute()
  
  
  
 
 #Reverting back to actual Dataframe by dropping additional columns
  
  ReturnDF =  SrcTgtDF1.drop("Tgt_Exp","Tgt_Ead","Tgt_ID","Tgt_Curr_Row_Fl")

#Returning the left over Dataframe which will be used for further processing/Functions. This is Non Type1 Dataframe
  FinalDF = queryDF1.exceptAll(ReturnDF)
  return FinalDF


#// this logic is created for IM Fact
                             
def scdType1Merge_clt(queryDF, curated_table, key ,partitionKey, partitionValue, surrogateId):
   #// New records for insert flow
  updates=spark.sql(f"select * from {curated_table}")
  updates=updates.alias("updates")                           
  queryDF=queryDF.alias("events")                          
  SrcTgtDF1 = queryDF.join(updates, (queryDF[f'{key}'] ==  updates[f'{key}'])  &  (updates[f'{partitionKey}'] == f'{partitionValue}'),"left" ).select("events.*",col("events.ETL_ADD_DTS").alias("Src_Ead"),col(f"events.{surrogateId}").alias("Src_ID"), col(f"updates.{surrogateId}").alias("Tgt_ID")).filter(col("Tgt_ID").isNull())                          
                             

#Existing data set for update flow                         
  SrcTgtDF2 = queryDF.join(updates, (queryDF[f'{key}'] ==  updates[f'{key}'])  &  (updates[f'{partitionKey}'] == f'{partitionValue}')).select("events.*",col("updates.ETL_ADD_DTS").alias("Tgt_Ead"),col(f"updates.{surrogateId}").alias("Tgt_ID"))
                         

  SrcTgtDF3 = SrcTgtDF2.drop("ETL_ADD_DTS",surrogateId).withColumnRenamed("Tgt_Ead","ETL_ADD_DTS").withColumnRenamed("Tgt_ID",surrogateId)
  SrcTgtDF4 = SrcTgtDF1.drop("ETL_ADD_DTS",surrogateId,"Tgt_ID").withColumnRenamed("Src_Ead","ETL_ADD_DTS").withColumnRenamed("Src_ID",surrogateId)
  SrcTgtDF1.show(3,False)
  SrcTgtDF2.show(3,False)
  SrcTgtDF3.show(3,False)
  SrcTgtDF4.show(3,False)

  
#Union of above 2 Dataframes
  queryDF1 = SrcTgtDF4.union(SrcTgtDF3)
  delta_table=DeltaTable.forName(spark, curated_table)
  delta_table.alias("t").merge(queryDF1.alias("s"),f"t.{key} = s.{key} AND t.{partitionKey} = '{partitionValue}'").whenNotMatchedInsertAll().whenMatchedUpdateAll().execute()
                          

# this logic is to create harmonize stage table - truncate and load 
def createHarmonizeStage_clt(harmonized_table_stg, viewname):
  print("Stage Table build start: " , harmonized_table_stg)
  cols = spark.table(harmonized_table_stg).columns
  cols =",".join(cols)
  #colss=tuple(cols)
  spark.sql(f"delete from {harmonized_table_stg}")
  query = f"insert into {harmonized_table_stg} ({cols}) select {cols} from global_temp.{viewname}"
  print("Stage Insert query: " , query)
  spark.sql(query)
  qryDF2= spark.sql(f"select * from {harmonized_table_stg} ")
  qryDF2.show(3,False)
  return qryDF2


# COMMAND ----------

#Library Functions used in Agreement Domain - DHF 1.0
#Non CLT Projects, NM, Betterview

def addSurrogateKey_clt(addSurrogateKey_clt_df, target ):
  maxSK = spark.table(f"{target}").count() 
  w  = Window.orderBy(col("ETL_ROW_EFF_DTS"))
  addSurrogateKey_clt_df=addSurrogateKey_clt_df.withColumn("surrogatekey", row_number().over(w) + maxSK)  
  return addSurrogateKey_clt_df
  
def removeDuplicates_clt(df, target, targetKey):
  print("in removeduplicates function2 \n")
  partition_cols=targetKey.split(",")
  print(partition_cols)
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print(firsRowDF.columns)
  firsRowDF.show()

 
  targetDF=spark.sql(f"select * from {target}")
  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = firsRowDF.join(targetDF, targetKey.split(","), "right").filter(col("targetDF.ETL_CURR_ROW_FL") == 'Y').select("targetDF.*").select(firsRowDF.columns)  
  print(latestInTargetDF.columns)
 
  # add target latest rows to microbatch
  df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
  # remove consecutive duplicates, choose first 
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("isTarget").desc())
  df3 = df2.withColumn("dupe",  col("row_hashed") == lag("row_hashed", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe")
  #If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 =  Window.partitionBy(*partition_cols).orderBy(*partition_cols)
  df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
  df4.show()
  return df4    

  
def defaultMerge_clt (df, target):
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(df.alias("updates"),"events.row_hashed = updates.row_hashed AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS":"updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL":"'N'","ETL_LAST_UPDATE_DTS":"current_timestamp"}).whenNotMatchedInsertAll().execute()
  
  
  

def addHashColumn_clt(viewname):
  allCols = spark.sql(f"select * from global_temp.{viewname}").columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS"]
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  print("hash_exclude_cols: ", hash_exclude_cols)
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)  
  cols=','.join(hash_cols)
  qry=f""" select *,hash({cols}) as row_hashed from global_temp.{viewname} """ 
  print("hash_query: ", qry) 
  hash_added_df=spark.sql(qry)
  return hash_added_df



# COMMAND ----------

# Function - DHF 1.0 release - June 25th

def getSurrogateKey(viewname, target):
  maxSK = spark.table(f"f{target}").count()
  qry=f"""select row_number() over(order by NULL) + {maxSK} as surrogatekey,* from global_temp.{viewname} """ 
  surg_df = spark.sql(qry) 
  return surg_df


def getHash(viewname, hash_cols):
  cols=','.join(hash_cols)
  qry=f""" select *,hash({cols}) as row_hashed from global_temp.{viewname} """  
  hashdf = spark.sql(qry)
  return hashdf


def addHashAndSurrogateCols(viewname, target):
  surrogateKeyDF=getSurrogateKey(viewname, target)
  surrogateKeyDF.createOrReplaceGlobalTempView(viewname)
  
  allCols = surrogateKeyDF.columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS"]
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  println("hash_exclude_cols: ", hash_exclude_cols)
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)
  hashedDF=getHash(viewname, hash_cols)  
  return hashedDF


def addAuditColumns(viewname, targetKey):
  auditDF = spark.sql(f"""SELECT *,
            LEAD(ETL_ROW_EFF_DTS,1,"9999") OVER (PARTITION BY {targetKey} ORDER BY ETL_ROW_EFF_DTS ASC) as ETL_ROW_EXP_DTS, 'N' as ETL_CURR_ROW_FL, current_timestamp() as ETL_ADD_DTS, current_timestamp() as ETL_LAST_UPDATE_DTS  
            FROM global_temp.{viewname}""").withColumn("ETL_CURR_ROW_FL", when(col("ETL_ROW_EXP_DTS") == "9999", "Y").otherwise("N"))     
   
  return auditDF



def defaultMerge(auditDF, target,  targetKey):
  
 #remove duplicates comparing to Target   
  #val dedupedAuditDF = auditDF.as("df1").join(DeltaTable.forName(spark, target).toDF.as("targetDF"), $"df1.row_hashed" === $"targetDF.row_hashed", "left").withColumn("isDupe", when($"targetDF.ETL_CURR_ROW_FL" === 'Y', "YES").otherwise("NO")).filter($"isDupe" === "NO").select("df1.*")
  
  dedupedAuditDF = auditDF
  
   #Get earliest record from microbatch for a key. This is used to expire target row.
  w = Window.partitionBy(col(targetKey)).orderBy(col("ETL_ROW_EFF_DTS").desc())
  dedupDF = dedupedAuditDF.withColumn("rownum", row_number.over(w)).where(col("rownum") == 1).drop("rownum")  
  print("dedupDF - updates:")
  dedupDF.show(3,False)
    
  #Expire old record in Target
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(dedupDF.alias("updates"), f"events.{targetKey} = updates.{targetKey} AND events.row_hashed != updates.row_hashed").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EFF_DTS","ETL_CURR_ROW_FL" : "'N'","ETL_LAST_UPDATE_DTS" :"current_timestamp()"}).whenNotMatchedInsertAll().execute()
  
  
  # Write new records to Target
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(dedupedAuditDF.alias("updates2"),"events2.row_hashed = updates2.row_hashed").whenNotMatchedInsertAll().execute()



def defaultMerge_new(auditDF, target,  targetKey):
  #remove duplicates comparing to Target
  targetDF=spark.sql(f"select * from {target}")
  auditDF=auditDF.alias("auditDF")
  dupesDF = auditDF.join(targetDF, (auditDF.row_hashed == targetDF.row_hashed) & (targetDF.ETL_CURR_ROW_FL == 'Y')).select("auditDF.*") 
  dedupedAuditDF = auditDF.exceptAll(dupesDF)
  print("dedupedAuditDF - updates:")
  dedupedAuditDF.show(3,False) 
  #  //Get earliest record from microbatch for a key. This is used to expire target row.
  w = Window.partitionBy(col("targetKey")).orderBy(col("ETL_ROW_EFF_DTS").desc())
  dedupDF = dedupedAuditDF.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")  
  print("dedupDF - updates:")
  dedupDF.show(3,False)
    
  # Expire old record in Target
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(dedupDF.alias("updates"),f"events.{targetKey} = updates.{targetKey} AND events.ETL_CURR_ROW_FL = 'Y' AND events.row_hashed != updates.row_hashed").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EFF_DTS","ETL_CURR_ROW_FL" : "'N'","ETL_LAST_UPDATE_DTS" :"current_timestamp()"}).execute()
  dedupedAuditDF.write.format("delta").mode("append").saveAsTable(target)




# COMMAND ----------

#Library Functions used in Claims Domain - Claimless
def defaultMerge_claims(auditDF, target,  targetKey, hashCol):
  #//remove duplicates comparing to Target
  targetDF=spark.sql(f"select * from {target}")
  auditDF=auditDF.alias("auditDF")
  dupesDF = auditDF.join(targetDF, (auditDF[f'{hashCol}'] == targetDF[f'{hashCol}']) & (targetDF["ETL_CURR_ROW_FL"] == 'Y')).select("auditDF.*")
  dedupedAuditDF = auditDF.exceptAll(dupesDF)
  print("dedupedAuditDF - updates:")
  dedupedAuditDF.show(3,False) 

  #//Get earliest record from microbatch for a key. This is used to expire target row.
  w = Window.partitionBy(col(targetKey)).orderBy(col("ETL_ROW_EFF_DTS").desc())
  dedupDF = dedupedAuditDF.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")  
  print("dedupDF - updates:")
  dedupDF.show(3,False)
    
  # Expire old record in Target  
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(dedupDF.alias("updates"),f"events.{targetKey} = updates.{targetKey} AND events.ETL_CURR_ROW_FL = 'Y' AND events.{hashCol} != updates.{hashCol}").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EFF_DTS","ETL_CURR_ROW_FL" : "'N'","ETL_LAST_UPDATE_DTS" : "current_timestamp()"}).execute() 
  #// Insert all updates and new records
  dedupedAuditDF.write.format("delta").mode("append").saveAsTable(target)

  
def scd1Merge_claims(auditDF, target,  targetKey, hashCol):
  targetCols=spark.table(f"{target}").columns
  delta_table=DeltaTable.forName(spark, target)
  updateColMap={}
  for i in targetCols:
    updateColMap[f"{i}"]=f"updates.{i}"

  qry=f'''delta_table.alias("events").merge(auditDF.alias("updates"),events.{targetKey} = updates.{targetKey}).whenMatchedUpdate(set={updateColMap}).whenNotMatchedInsertAll().execute()'''
  qry

def removeDuplicates_claims(df,target,targetKey,hashCol, scdType=2):
  print("in removeduplicates function2 \n")
  windowOrder = "ETL_ROW_EFF_DTS"
  if (scdType == 1):
    windowOrder = "ETL_PROC_DTS"

  df2 = df
  if (scdType == 2):
    partition_cols=targetKey.split(",")
    w = Window.partitionBy(*partition_cols).orderBy(col(f"{windowOrder}"))
    firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")   
    firsRowDF.alias("firsRowDF")                                               
    print(firsRowDF.columns) 
    targetDF=spark.sql(f"select * from {target}")
    targetDF=targetDF.alias('targetDF')
    latestInTargetDF = firsRowDF.join(targetDF, targetKey.split(","), "right").filter("targetDF.ETL_CURR_ROW_FL" =='Y').select("targetDF.*").select(firsRowDF.columns)  
    print("\n latestInTargetDF cols")
    print(latestInTargetDF.columns)  

      #add target latest rows to microbatch
    df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
    df2.show(3,False)
  else:
    df2 = df.withColumn("isTarget", lit(1))
    
    #remove consecutive duplicates, choose first
    partition_cols=targetKey.split(",")                                            
    w3 = Window.partitionBy(*partition_cols).orderBy(col(windowOrder).asc(),col("isTarget").desc())
    df3 = df2.withColumn("dupe",  col("hashCol") == lag("hashCol", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe") 
  
    #If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
    w2 =  Window.partitionBy(*partition_cols)
    df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
    df4.show(3,False)
    return df4    


def addHashColumn_claims(viewname):
  allCols = spark.table(f"{viewname}").columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols =["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS"]
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  print("hash_exclude_cols: ", hash_exclude_cols)                                               
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)  
  cols=tuple(hash_cols)
  qry=f"select *,sha2(concat({cols}), 256) as row_hashed from global_temp.{viewname}" 
  hashdf = spark.sql(qry)
  return hashdf



# COMMAND ----------

#Library Functions used in Claims Domain - Claims HV
# Claims-HV functions

def addAuditColumns_claims_HV(df4, targetKey):#= { ////////////////df to df4
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  auditDF = df4.withColumn("ETL_ROW_EXP_DTS", lead("ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when(col("ETL_ROW_EXP_DTS") == "9999-12-31", "Y").otherwise("N")) #////////////////df to df4
  return auditDF


# // This function is same as above function, but uses SQL suntax to do the window function instead of scala. Needs to be tested for composite key before being used.
# // def addAuditColumns_clt(viewname: String, targetKey: String) = {
# // val auditDF = spark.sql(s"""SELECT *,
# // LEAD(ETL_ROW_EFF_DTS,1,"9999") OVER (PARTITION BY $targetKey ORDER BY ETL_ROW_EFF_DTS ASC) as ETL_ROW_EXP_DTS, 'N' as ETL_CURR_ROW_FL , current_timestamp() as ETL_ADD_DTS, current_timestamp() as ETL_LAST_UPDATE_DTS
# // FROM global_temp.${viewname}""").withColumn("ETL_CURR_ROW_FL", when($"ETL_ROW_EXP_DTS" === "9999", "Y").otherwise("N"))
# // auditDF
# // }// Claim Related functions


#Updated Method to avoid duplicate ID generation
def addSurrogateKey_claims_HV(auditDF, target, target_surrogateid):
  maxSK = spark.sql(f"Select max({target_surrogateid}) as max_id from {target}").collect()[0][0]
  w  = Window.orderBy(col("ETL_ROW_EFF_DTS"))
  surrDF = auditDF.withColumn(target_surrogateid, row_number().over(w) + maxSK)
  return surrDF


#Added new method to avoid Hash Collision
def addHashColumn_claims_HV(viewname, harmonized_table_surrogateid):
  allCols = spark.sql(f"select * from global_temp.{viewname}").columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey","MD5_HASH",harmonized_table_surrogateid,"ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS"]
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  print("hash_exclude_cols: ", hash_exclude_cols)
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)
  cols=','.join(hash_cols)
  qry=f""" select *,XXHASH64({cols}) as MD5_HASH from global_temp.{viewname} """
  hashDF = spark.sql(qry)
  return hashDF 

def removeDuplicatesMultistream_claims_HV(hashDF, target, targetKey, partitionKey, partitionValue):# = { #//////////////df to hashDF
  print("in removeduplicates function2 \n")
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  firsRowDF = hashDF.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum") #//////////////df to hashDF
  print(firsRowDF.columns)
  targetDF = spark.sql(f"select * from {target} where {partitionKey} = '{partitionValue}'")#//DeltaTable.forName(spark, target).toDF\
  join_keys = targetKey.split(",")
  joinExprs=''
  for i in join_keys:
    joinExprs1=f"firsRowDF['{i}'] == targetDF['{i}']"
    joinExprs=joinExprs+ " & "+ joinExprs1
    joinExprs=joinExprs[2:len(joinExprs)]

  keyCol1 =join_keys[0]
  keyCol2 =join_keys[1]


  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = targetDF.join(firsRowDF, (targetDF[f'{keyCol1}'] == firsRowDF[f'{keyCol1}']) & (firsRowDF[f'{keyCol2}'] == targetDF[f'{keyCol2}'])).filter(col("targetDF.ETL_CURR_ROW_FL") == 'Y').select("targetDF.*").select(firsRowDF.columns)

  print("\n latestInTargetDF cols")
  print(latestInTargetDF.columns)

  #add target latest rows to microbatch
  df2 = hashDF.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1))) #//////////////df to hashDF

  #remove consecutive duplicates, choose first
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("MD5_HASH").asc(),col("isTarget").desc())
  df3 = df2.withColumn("dupe", col("MD5_HASH") == lag("MD5_HASH", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe")

  #If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 = Window.partitionBy(*partition_cols)
  df4 = df3.withColumn("count", count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1) & (col("count") == 1))).drop("count").drop("isTarget")
  return df4

def defaultMergeMultistream_claims_HV (surrDF, target, partition_col, partition_val ):
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(surrDF.alias("updates"),f"events.MD5_HASH = updates.MD5_HASH AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL" : "'N'","ETL_LAST_UPDATE_DTS" :"current_timestamp()"}).whenNotMatchedInsertAll().execute()


#Loss_Tran Specific Methods

def addAuditColumns_claims_HV_LossTran(df4, targetKey): 
#Generates current_timestamp as a value for ETL_ADD_DTS & ETL_LAST_UPDATE_DTS fields
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_PROC_DTS"))
  auditDF = df4.withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp())
  return auditDF

def addAuditColumns_claims_HV_LossTran(df4, targetKey) :
  #Generates current_timestamp as a value for ETL_ADD_DTS & ETL_LAST_UPDATE_DTS fields
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(partition_cols).orderBy(col("ETL_PROC_DTS"))
  auditDF = df4.withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp())
  return auditDF

def addSurrogateKey_claims_HV_LossTran(auditDF, target, target_surrogateid):
  #//Generates sequential number as a value for LOSS_TRAN_ID field
  maxSK = spark.sql(f"Select max({target_surrogateid}) as max_id from {target}").collect()[0][0]
  w = Window.orderBy(col("ETL_PROC_DTS"))
  surrDF = auditDF.withColumn(target_surrogateid, row_number().over(w) + maxSK) 
  return surrDF

def defaultMergeMultistream_claims_HV_LossTran(surrDF, target, partition_col, partition_val):
#//Checks if LOSS_TRNSC_KEY value already exists in harmonized table, if not inserts the records
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(surrDF.alias("updates"),f"events.LOSS_TRNSC_KEY = updates.LOSS_TRNSC_KEY AND events.{partition_col} = '{partition_val}'").whenNotMatchedInsertAll().execute()
  

# COMMAND ----------

#CDC and ORPHAN Functions
#added function for the CDC Out of Sync

def mergeOutOfSync (df, target):
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(df.alias("updates"),"events.MD5_HASH = updates.MD5_HASH AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL" : "updates.ETL_CURR_ROW_FL", "ETL_LAST_UPDATE_DTS" : "current_timestamp()"}).whenNotMatchedInsertAll().execute()

#this function to capture the missing records and doing date chaining

def addAuditColumnsOutOfSync(df, target, targetKey):
  firsRowDF = df
  print(firsRowDF.columns)
  tgtDF = spark.sql(f'select * from {target}')
  tgtDF.createOrReplaceGlobalTempView("temptarget")
  
  print("selecting the common records between source and target: ")
  SrcTargetDF = tgtDF.join(df, targetKey.split(","), "leftsemi").select(firsRowDF.columns)
  SrcTargetDF.show(3, False)
  
  #doing the union of source and target
  print("Union of source and target")
  unionAllTempdf = df.withColumn("isTarget", lit(0)).union(SrcTargetDF.withColumn("isTarget", lit(1)))
  unionTempdf = unionAllTempdf.drop("isTarget")
  unionTempdf.show(3, False)
  
  print("Drop Duplicates in unionTempdf: ")
  nonDupUnionDf = unionTempdf.dropDuplicates(["MD5_HASH","ETL_ROW_EFF_DTS"]) 
  nonDupUnionDf.show(3, False)
   
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))

  auditDF = nonDupUnionDf.withColumn("ETL_ROW_EXP_DTS", lead("ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when(col("ETL_ROW_EXP_DTS") == "9999-12-31", "Y").otherwise("N"))
  
  print("After adding Audit date columns")
  auditDF.show(2,False)
  return auditDF


#to find and take the Orphan record
def getOrphanFromTable(target, targetKey):
  tgtDF = spark.sql(f"select * from {target}")
  targetKeyCol = targetKey.split(",")
  activeDF = tgtDF.filter(tgtDF["etl_curr_row_fl"] == 'Y').select(*targetKeyCol)
  uniqueDF = tgtDF.select(*targetKeyCol).distinct()
  tgtOrphanDF = uniqueDF.join(activeDF, targetKey.split(","), "leftanti").withColumn("ETL_CURR_ROW_FL", lit("Y") ) 
     
  tgtOrphanDF.show(3,False)
  return tgtOrphanDF


#//Removing the entire Orphan rows before merging with Target

def removeFullOrphanKey(auditDf, orphanDf, targetKey):
  nonOrphanDF = auditDf.join(orphanDf, targetKey.split(","), "leftanti")
  nonOrphanDF.show(3,False)
  return nonOrphanDF


#Removing only the Orphan rows updated as 'Y' before merging with Target

def removeOrphanKey(auditDf, orphanDf, targetKey):
  targetKeyWithFL = targetKey + ",ETL_CURR_ROW_FL"
  nonOrphanDF = auditDf.join(orphanDf, targetKeyWithFL.split(",") , "leftanti")
  nonOrphanDF.show(3,False)
  return nonOrphanDF


# COMMAND ----------

def addHashColumn_clt_old(viewname):
  allCols = spark.sql(f"select * from global_temp.{viewname}").columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","row_hashed","surrogatekey","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS"]
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  print("hash_exclude_cols: ", hash_exclude_cols)
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)  
  cols=','.join(hash_cols)
  hash_added_dfqry=f"select *,hash({cols}) as row_hashed from global_temp.{viewname}"
  hash_added_df=spark.sql(hash_added_dfqry)
  return hash_added_df 


def removeDuplicates_clt_old(df, target, targetKey):
  print("in removeduplicates function2 \n")
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print(firsRowDF.columns)
  

   
  targetDF=spark.sql(f"select * from {target}")
  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = firsRowDF.join(targetDF, targetKey.split(","), "right").filter(col("targetDF.ETL_CURR_ROW_FL") == 'Y').select("targetDF.*").select(firsRowDF.columns)  
  print("\n latestInTargetDF cols")
  print(latestInTargetDF.columns)  
 
  #add target latest rows to microbatch
  df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
  #remove consecutive duplicates, choose first 
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("isTarget").desc(),col("row_hashed").asc())
  df3 = df2.withColumn("dupe",  col("row_hashed") == lag("row_hashed", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe") 
#If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 =  Window.partitionBy(*partition_cols).orderBy(*partition_cols)
  df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
  return df4  

# COMMAND ----------

#Type-1 
#default Default Merge Function  
  
def type1_defaultMerge (surrDF, target, merge_key): #sde #1
  print("entering type1_defaultMerge function")
  match_condition = " AND ".join(list(map((lambda x: f"events.{x.strip()}=updates.{x.strip()}"),merge_key.split(","))))
  print("match_condition: ",match_condition)
  insert_values={}
  dataframe_cols=surrDF.columns
  target_cols=spark.table(f"{target}").columns
  if(len(target_cols)>len(dataframe_cols)):
    print("number of columns in microbatch DF are less than number of columns in your target table")
    for col in dataframe_cols:
      insert_values[f'{col}']=f"updates.{col}"
      
    extra_cols = {key:val for key,val in not_null_cols_defaults(target).items() if key not in insert_values}
    insert_values_nncols = {**insert_values, **extra_cols}
    print("insert_values_including_not_null_ncols",insert_values_nncols)
    
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),match_condition).whenMatchedUpdate(set=insert_values_nncols).whenNotMatchedInsert(values=insert_values_nncols).execute()
    
    print("end of type1_defaultMerge function")
  
  else:
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),match_condition).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("end of type1_defaultMerge function")
  
def addSurrogateKey_clt_type1(df, target, orderby):
  maxSK = spark.table(f"{target}").count()
  w  = Window.orderBy(f"{orderby}")
  df1 = df.withColumn("surrogatekey", row_number().over(w) + maxSK)
  return df1


# COMMAND ----------

#//exclusion function 

# def pre_harm_exclusion(microBatchDF, pre_harm_logic_query, rawDB, environment, view_name):
#   if(environment.upper() == "PROD"):
#     microBatchDF.createOrReplaceGlobalTempView(f"Harmz_Query_{view_name}")

#     #//var Exclusion = f"""select * from global_temp.Harmz_Query where NOT EXISTS (select '1' from ( SELECT DISTINCT polper.publicID FROM $rawDB.PC_PolicyPeriod polper INNER JOIN $rawDB.pc_producercode prodcode on polper.ProducerCodeOfRecordID = prodcode.ID INNER JOIN $rawDB.pc_group grp ON prodcode.branchID = grp.id WHERE grp.Agencynum_ext IN ( select Distinct Agencynum_ext from $rawDB.pc_group where trim(int(substr(pc_group.Agencynum_ext,4))) >= 29800 and trim(int(substr(pc_group.Agencynum_ext,4))) <= 29999 OR Agencynum_ext = '00019999') OR polper.PolicyNumber IN ('ACP BP013200000000','ACP BP013200000761')) temp  where temp.PUBLICID=POLPER_PUBLICID) //"""
#     FinalDF = spark.sql(pre_harm_logic_query)
#     return FinalDF 
#   else:
#     return microBatchDF


# COMMAND ----------

def addSurrogateID_gt(df, target, datevalue):
  maxSK=spark.table(f"{target}").count()
  surrogateID=target[target.index(".")+4:]+"_ID"
  w = Window.orderBy(f"{datevalue}")
  df1 = df.withColumn(surrogateID, row_number().over(w) + maxSK)
  df1.createOrReplaceGlobalTempView("surrogateKeyData")
  df2 = spark.sql(f"select *,XXHASH64({surrogateID},PARTITION_VAL) as {surrogateID}_New from global_temp.surrogateKeyData")
  df3=df2.drop(f"{surrogateID}").withColumnRenamed(f"{surrogateID}_New",f"{surrogateID}")
  return df3

# COMMAND ----------

# DBTITLE 1,DHF Generic Functions for SQL Approach
#Defaults for Not Null Columns
def not_null_cols_defaults(table):
  default_val_dict = {
    'INT':'0',
    'TINYINT':'0',
    'SMALLINT':'0',
    'BIGINT':'0',
    'DOUBLE':'0.00',
    'FLOAT':'0.0',
    'STRING':"' '",
    'TIMESTAMP': "'3500-12-31 00:00:00.000000'",
    'DATE': "'3500-12-31'",
    'DEFAULT' : "default"
  }
  df = spark.sql(f"show create table {table}").collect()
  final_str = df[0][0].strip().replace('`','')
  all_cols_list = final_str[final_str.index("(")+1:final_str.index("USING")].split(",\n")
  print(f"all_cols_list",all_cols_list)
  
  not_null_cols_list = [_.strip() for _ in all_cols_list if "NOT NULL" in _]
  print(f"not_null_cols_list:",not_null_cols_list)
  
  non_decimal_col_list = [_ for _ in not_null_cols_list if "DECIMAL" not in _]
  decimal_col_list = [_ for _ in not_null_cols_list if "DECIMAL" in _]
  decimal_dict = {_.split(" ")[0]:str(spark.sql(f'select cast(0 as {_.split(" ")[1]})').collect()[0][0]) for _ in decimal_col_list}
  
  cols_defaults_dict = {_.strip().split(" ")[0]:_.strip().split(" ")[1] for _ in non_decimal_col_list}
  print(f"not null cols defaults details: {cols_defaults_dict}")
  
  final_cols_defaults_dict = {**{_:default_val_dict[cols_defaults_dict[_]] for _ in cols_defaults_dict if cols_defaults_dict[_] in default_val_dict},**decimal_dict, **{_:default_val_dict['DEFAULT'] for _ in cols_defaults_dict if cols_defaults_dict[_] not in default_val_dict}}

  return final_cols_defaults_dict

# ----------------------------------------------------------------------------------------------------------------------------------------------------#
#hash function
def addHashColumnXXHash_DHFGeneric(viewname_hash):
  print("entering addHashColumnXXHash_DHFGeneric function")
  viewname = viewname_hash.split("#")[0]
  hash_col = viewname_hash.split("#")[1] if (len(viewname_hash.split("#")[1].strip() if "#" in viewname_hash else "") !=0) else "MD5_HASH"
  
  allCols = spark.sql(f"select * from global_temp.{viewname}").columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","ROW_HASH","MD5_HASH","surrogatekey","ETL_ROW_EFF_DTS","ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL","ETL_ADD_DTS","ETL_LAST_UPDATE_DTS","ETL_ROW_CMPLTN_IN"]    #patch #whynot UDM cols?
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  print("hash_exclude_cols: ", hash_exclude_cols)
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)
  cols=','.join(hash_cols)
  qry=f"select *,XXHASH64({cols}) as {hash_col} from global_temp.{viewname}"
  print("hash_query: ", qry) 
  hash_df = spark.sql(qry)
  print("end of addHashColumnXXHash_DHFGeneric function")
  return hash_df

def addHashColumnXXHash_DHFGeneric_UDM(viewname_hash):
  print("entering addHashColumnXXHash_DHFGeneric UDM function")
  viewname = viewname_hash.split("#")[0]
  hash_col = viewname_hash.split("#")[1] if (len(viewname_hash.split("#")[1].strip() if "#" in viewname_hash else "") !=0) else "MD5_HASH"
  allCols = spark.sql(f"select * from global_temp.{viewname}").columns
  allCols=[x.lower() for x in allCols]
  print("allCols: ", allCols)
  hash_exclude_cols = ["_topic_","_partition_","_kafkaoffset_","_kafkatimestamp_","ROW_HASH","MD5_HASH","surrogatekey","ETL_ROW_EFCTV_TS","ETL_ROW_EXPRTN_TS","ETL_CURR_ROW_IN","ETL_ADD_TS","ETL_LAST_UPDT_TS","ETL_PATCH_TS","ETL_ROW_CMPLTN_IN"]
  hash_exclude_cols=[x.lower() for x in hash_exclude_cols]
  print("hash_exclude_cols: ", hash_exclude_cols)
  hash_cols=[i for i in allCols if i not in hash_exclude_cols]
  print("hash_cols: ", hash_cols)
  cols=','.join(hash_cols)
  qry=f"select *,XXHASH64({cols}) as {hash_col} from global_temp.{viewname}"
  print("hash_query: ", qry) 
  hash_df = spark.sql(qry)
  print("end of addHashColumnXXHash_DHFGeneric UDM function")
  return hash_df
# -------------------------------------------------------------------------------------------------------------------------------------------------- #
#exclusion function 
def pre_harm_exclusion(microBatchDF, pre_harm_logic_query, rawDB, environment,view_name):
  print("entering pre_harm_exclusion function")
  if(environment.upper() == "PROD"):
    microBatchDF.createOrReplaceGlobalTempView(f"Harmz_Query_{view_name}")
    FinalDF = spark.sql(pre_harm_logic_query)
    print("end of pre_harm_exclusion function")
    return FinalDF 
  else:
    print("end of pre_harm_exclusion function")
    return microBatchDF

# -------------------------------------------------------------------------------------------------------------------------------------------------- #

#function to remove additional columns present in Harmonize query
def removeAdditionalCols_DHFGeneric(df, target_hash):
  target = target_hash.split("#")[0]
  hash_col = target_hash.split("#")[1] if (len(target_hash.split("#")[1].strip() if "#" in target_hash else "") !=0) else "MD5_HASH"
  print("entering AdditionalColstoRemove function \n")
  dfCols = df.columns
  dfCols=[x.lower() for x in dfCols]
  targetCols = spark.table(f"{target}").columns
  targetCols = [x.lower() for x in targetCols]
  AdditionalColsToRemove = [i for i in dfCols if i not in targetCols]
  print("Additional Columns list: \n")
  print(AdditionalColsToRemove)
  queryDF = df.drop(*AdditionalColsToRemove)
  print("leaving AdditionalColstoRemove function \n")
  return queryDF

# -------------------------------------------------------------------------------------------------------------------------------------------------- #

#This function to remove duplictes based on Key column combination in a micrbatch based on the specified order by clause
def removeDuplicatesMicrobatch_DHFGeneric(df, partitionKeys, orderbyCols):
  print("entering removeduplicates microbatch function \n")
  partition_cols=partitionKeys.split(",")
  orderyby_cols=orderbyCols.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(*[desc(c) for c in orderyby_cols])
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print("leaving removeduplicates microbatch function")
  return firsRowDF

# -------------------------------------------------------------------------------------------------------------------------------------------------- #

#Type-1 
  
def type1_defaultMerge_DHFGeneric (surrDF, target, merge_key): #sde #1
  print("entering type1_defaultMerge function")
  match_condition = " AND ".join(list(map((lambda x: f"events.{x.strip()}=updates.{x.strip()}"),merge_key.split(","))))
  print("match_condition: ",match_condition)
  insert_values={}
  dataframe_cols=surrDF.columns
  target_cols=spark.table(f"{target}").columns
  if(len(target_cols)>len(dataframe_cols)):
    print("number of columns in microbatch DF are less than number of columns in your target table")
    for col in dataframe_cols:
      insert_values[f'{col}']=f"updates.{col}"
      
    insert_values_upper = {key.upper():value for key,value in insert_values.items()}
    extra_cols = {key:val for key,val in not_null_cols_defaults(target).items() if key not in insert_values_upper}
    insert_values_nncols = {**insert_values, **extra_cols}
    print("insert_values_including_not_null_ncols",insert_values_nncols)
    
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),match_condition).whenMatchedUpdate(set=insert_values_nncols).whenNotMatchedInsert(values=insert_values_nncols).execute()
    
    print("end of type1_defaultMerge function")
  
  else:
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),match_condition).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("end of type1_defaultMerge function")
    
  
  
def type1_defaultMergePartitionied_DHFGeneric(df, target, merge_key,partition_col,partition_val): #sde #2
  print("entering type1_defaultMergePartitionied_DHFGeneric")
  df=df.where(col(f"{partition_col}")==f"{partition_val}")
  match_condition = " AND ".join(list(map((lambda x: f"events.{x.strip()}=updates.{x.strip()}"),merge_key.split(",")))) + f" AND events.{partition_col}='{partition_val}'"
  insert_values={}
  dataframe_cols=df.columns
  target_cols=spark.table(f"{target}").columns
  if(len(target_cols)>len(dataframe_cols)):
    print("number of columns in microbatch DF are less than number of columns in your target table")
    for column in dataframe_cols:
      insert_values[f'{column}']=f"updates.{column}"
      
    insert_values_upper = {key.upper():value for key,value in insert_values.items()}
    extra_cols = {key:val for key,val in not_null_cols_defaults(target).items() if key not in insert_values_upper}
    insert_values_nncols = {**insert_values, **extra_cols}
    print("insert_values_including_not_null_ncols",insert_values_nncols)
    
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(df.alias("updates"),match_condition).whenMatchedUpdate(set=insert_values_nncols).whenNotMatchedInsert(values=insert_values_nncols).execute()
    print("end of type1_defaultMergePartitionied_DHFGeneric function")
  
  else:
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(df.alias("updates"),match_condition).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("end of type1_defaultMergePartitionied_DHFGeneric function")

                 # ------------------------------------------------------------- #
  
def addSurrogateKey_DHFGeneric_type1(df, target, orderby):
  print("entering addSurrogateKey_DHFGeneric_type1 function")
  maxSK = spark.table(f"{target}").count()
  w  = Window.orderBy(f"{orderby}")
  surrogatekey_column_name = f'{target.split(".")[1]}_ID'
  df1 = df.withColumn(surrogatekey_column_name, row_number().over(w) + maxSK)
  df1.show()
  print("end of addSurrogateKey_DHFGeneric_type1 function")
  return df1

def addSurrogateKey_DHFGeneric_type1_old(df, target, orderby):
  print("entering addSurrogateKey_DHFGeneric_type1_old function")
  maxSK = spark.table(f"{target}").count()
  w  = Window.orderBy(f"{orderby}")
  df1 = df.withColumn("surrogatekey", row_number().over(w) + maxSK)
  print("end of addSurrogateKey_DHFGeneric_type1_old function")
  return df1

# -------------------------------------------------------------------------------------------------------------------------------------------------- #

def removeDuplicates_DHFGeneric(df, target_hash, targetKey):
  print("entering removeDuplicates_DHFGeneric function2 \n")
  target = target_hash.split("#")[0]
  hash_col = target_hash.split("#")[1] if (len(target_hash.split("#")[1].strip() if "#" in target_hash else "") !=0) else "MD5_HASH"

  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print(firsRowDF.columns)
  targetDF=spark.sql(f"select * from {target}")
  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = firsRowDF.join(targetDF, targetKey.split(","), "right").filter(col("targetDF.ETL_CURR_ROW_FL") == 'Y').select("targetDF.*").select(firsRowDF.columns)  
  print("\n latestInTargetDF cols")
  print(latestInTargetDF.columns)  
 
  #add target latest rows to microbatch
  df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
  #remove consecutive duplicates, choose first 
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("isTarget").desc(),col(f"{hash_col}").asc())
  df3 = df2.withColumn("dupe",  col(f"{hash_col}") == lag(f"{hash_col}", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe") 
#If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 =  Window.partitionBy(*partition_cols).orderBy(*partition_cols)
  df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
  print("end of removeDuplicates_DHFGeneric function")
  return df4  

def removeDuplicates_DHFGeneric_UDM(df, target_hash, targetKey):

  print("entering removeDuplicates_DHFGeneric UDM function \n")
  target = target_hash.split("#")[0]
  hash_col = target_hash.split("#")[1] if (len(target_hash.split("#")[1].strip() if "#" in target_hash else "") !=0) else "MD5_HASH"
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFCTV_TS"))
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print(firsRowDF.columns)
  targetDF=spark.sql(f"select * from {target}")
  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = firsRowDF.join(targetDF, targetKey.split(","), "right").filter(col("targetDF.ETL_CURR_ROW_IN") == 'Y').select("targetDF.*").select(firsRowDF.columns)  
  print("\n latestInTargetDF cols")
  print(latestInTargetDF.columns)  
 
  #add target latest rows to microbatch
  df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
  #remove consecutive duplicates, choose first 
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFCTV_TS").asc(),col("isTarget").desc(),col(f"{hash_col}").asc())
  df3 = df2.withColumn("dupe",  col(f"{hash_col}") == lag(f"{hash_col}", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe") 
#If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 =  Window.partitionBy(*partition_cols).orderBy(*partition_cols)
  df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
  print("end of removeDuplicates_DHFGeneric UDM function")
  return df4  
# -------------------------------------------------------------------------------------------------------------------------------------------------- #

def addAuditColumns_DHFGeneric(df, targetKey):
  print("entering addAuditColumns_DHFGeneric function")
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  auditDF = df.withColumn("ETL_ROW_EXP_DTS", lead("ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when(col("ETL_ROW_EXP_DTS") == "9999-12-31", "Y").otherwise("N"))
  print("end of addAuditColumns_DHFGeneric function")
  return auditDF

def addAuditColumns_DHFGeneric_UDM(df, targetKey_patch):
  print("entering addAuditColumns_DHFGeneric UDM function")
  targetKey = targetKey_patch.split("#")[0]
  partition_cols=targetKey.split(",")
  patch_col = targetKey_patch.split("#")[1] if (len(targetKey_patch.split("#")[1].strip() if "#" in targetKey_patch else "") !=0) else "ETL_LAST_UPDT_TS"
  
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFCTV_TS"))
  auditDF = df.withColumn("ETL_ROW_EXPRTN_TS", lead("ETL_ROW_EFCTV_TS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_IN", lit("N")).withColumn("ETL_ADD_TS", current_timestamp()).withColumn(f"{patch_col}", lit('1001-01-01 00:00:00.000000').cast('timestamp')).withColumn("ETL_CURR_ROW_IN", when(col("ETL_ROW_EXPRTN_TS") == "9999-12-31", "Y").otherwise("N"))
  print("end of addAuditColumns_DHFGeneric UDM function")
  return auditDF 
# -------------------------------------------------------------------------------------------------------------------------------------------------- #

def addSurrogateKey_DHFGeneric_rownum(addSurrogateKey_clt_df, target ):
  print("entering addSurrogateKey_DHFGeneric_rownum function")
  maxSK = spark.table(f"{target}").count() 
  w  = Window.orderBy(col("ETL_ROW_EFF_DTS"))
  surrogatekey_column_name = f'{target.split(".")[1]}_ID'
  addSurrogateKey_clt_df=addSurrogateKey_clt_df.withColumn(surrogatekey_column_name, row_number().over(w) + maxSK)  
  addSurrogateKey_clt_df.show()
  print("end of addSurrogateKey_DHFGeneric_rownum function")
  return addSurrogateKey_clt_df

def addSurrogateKey_DHFGeneric(addSurrogateKey_clt_df, target):
  print("entering addSurrogateKey_DHFGeneric function")
  dataframe_cols=addSurrogateKey_clt_df.columns 
  surrogatekey_column_name = f'{target.split(".")[1]}_ID'
  addSurrogateKey_clt_df=addSurrogateKey_clt_df.withColumn(surrogatekey_column_name, xxhash64(concat_ws(',',*dataframe_cols)))  
  print("end of addSurrogateKey_DHFGeneric function")
  return addSurrogateKey_clt_df  

def addSurrogateKey_DHFGeneric_UDM(addSurrogateKey_clt_df, target ):
  print("entering addSurrogateKey_DHFGeneric UDM function")
  maxSK = spark.table(f"{target}").count() 
  w  = Window.orderBy(col("ETL_ROW_EFCTV_TS"))
  surrogatekey_column_name = f'{target.split(".")[1]}_ID'
  addSurrogateKey_clt_df=addSurrogateKey_clt_df.withColumn(surrogatekey_column_name, row_number().over(w) + maxSK)  
  addSurrogateKey_clt_df.show()
  print("end of addSurrogateKey_DHFGeneric UDM function")
  return addSurrogateKey_clt_df

def addSurrogateKey_DHFGeneric_old(addSurrogateKey_clt_df, target ):
  print("entering addSurrogateKey_DHFGeneric_old function")
  maxSK = spark.table(f"{target}").count() 
  w  = Window.orderBy(col("ETL_ROW_EFF_DTS"))
  addSurrogateKey_clt_df=addSurrogateKey_clt_df.withColumn("surrogatekey", row_number().over(w) + maxSK)  
  print("end of addAuditColumns_DHFGeneric_old function")
  return addSurrogateKey_clt_df

# -------------------------------------------------------------------------------------------------------------------------------------------------- #

def defaultMerge_DHFGeneric(df, target_hash):
  print("entering defaultMerge_DHFGeneric")
  target = target_hash.split("#")[0]
  hash_col = target_hash.split("#")[1] if (len(target_hash.split("#")[1].strip() if "#" in target_hash else "") !=0) else "MD5_HASH"
  insert_values={}
  dataframe_cols=df.columns
  target_cols=spark.table(f"{target}").columns
  
  if(len(target_cols)>len(dataframe_cols)):
    
    print("number of columns in microbatch DF are less than number of columns in your target table")
    for col in dataframe_cols:
      insert_values[f'{col}']=f"updates.{col}"
    insert_values_upper = {key.upper():value for key,value in insert_values.items()}
    extra_cols = {key:val for key,val in not_null_cols_defaults(target).items() if key not in insert_values_upper}
    insert_values_nncols = {**insert_values, **extra_cols}
    print("insert_values_including_not_null_ncols",insert_values_nncols)

    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(df.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS":"updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL":"'N'","ETL_LAST_UPDATE_DTS":"current_timestamp"}).whenNotMatchedInsert(values=insert_values_nncols).execute()
  else:
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(df.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS":"updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL":"'N'","ETL_LAST_UPDATE_DTS":"current_timestamp"}).whenNotMatchedInsertAll().execute()
  print("end of defaultMerge_DHFGeneric")
  
  
def defaultMerge_DHFGeneric_UDM(df, target_hash_patch): #sde #4
  print("entering defaultMerge_DHFGeneric UDM function")
  target = target_hash_patch.split("#")[0]
  hash_col = target_hash_patch.split("#")[1] if (len(target_hash_patch.split("#")[1].strip() if "#" in target_hash_patch else "") !=0) else "MD5_HASH"
  patch_col = target_hash_patch.split("#")[2] if (len(target_hash_patch.split("#")[2].strip() if "#" in target_hash_patch and len(target_hash_patch.split("#"))>2 else "") !=0) else "ETL_LAST_UPDT_TS"
  
  insert_values={}
  dataframe_cols=df.columns
  target_cols=spark.table(f"{target}").columns
  if(len(target_cols)>len(dataframe_cols)):
    print("number of columns in microbatch DF are less than number of columns in your target table")
    for col in dataframe_cols:
      insert_values[f'{col}']=f"updates.{col}"
    
    insert_values_upper = {key.upper():value for key,value in insert_values.items()}
    extra_cols = {key:val for key,val in not_null_cols_defaults(target).items() if key not in insert_values_upper}
    insert_values_nncols = {**insert_values, **extra_cols}
    print("insert_values_including_not_null_ncols",insert_values_nncols)
    
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(df.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFCTV_TS = updates.ETL_ROW_EFCTV_TS").whenMatchedUpdate(set = {"ETL_ROW_EXPRTN_TS":"updates.ETL_ROW_EXPRTN_TS","ETL_CURR_ROW_IN":"'N'",f"{patch_col}":"'1001-01-01 00:00:00.000000'"}).whenNotMatchedInsert(values=insert_values_nncols).execute()
  else:
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(df.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFCTV_TS = updates.ETL_ROW_EFCTV_TS").whenMatchedUpdate(set = {"ETL_ROW_EXPRTN_TS":"updates.ETL_ROW_EXPRTN_TS","ETL_CURR_ROW_IN":"'N'",f"{patch_col}":"'1001-01-01 00:00:00.000000'"}).whenNotMatchedInsertAll().execute()
  print("end of defaultMerge_DHFGeneric UDM function")  
  
# -------------------------------------------------------------------------------------------------------------------------------------------------- #

def defaultMergePartitionied_DHFGeneric(surrDF, target_hash, partition_col, partition_val ):  #sde #5
  print("entering defaultMergePartitionied_DHFGeneric")
  target = target_hash.split("#")[0]
  hash_col = target_hash.split("#")[1] if (len(target_hash.split("#")[1].strip() if "#" in target_hash else "") !=0) else "MD5_HASH"
  insert_values={}
  dataframe_cols=surrDF.columns
  target_cols=spark.table(f"{target}").columns
  if(len(target_cols)>len(dataframe_cols)):
    print("number of columns in microbatch DF are less than number of columns in your target table")
    for col in dataframe_cols:
      insert_values[f'{col}']=f"updates.{col}"
    insert_values_upper = {key.upper():value for key,value in insert_values.items()}
    extra_cols = {key:val for key,val in not_null_cols_defaults(target).items() if key not in insert_values_upper}
    insert_values_nncols = {**insert_values, **extra_cols}
    print("insert_values_including_not_null_ncols",insert_values_nncols)

    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL" : "'N'","ETL_LAST_UPDATE_DTS" :"current_timestamp()"}).whenNotMatchedInsert(values=insert_values_nncols
).execute()
  else:
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS" : "updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL" : "'N'","ETL_LAST_UPDATE_DTS" :"current_timestamp()"}).whenNotMatchedInsertAll().execute()
  print("end of defaultMergePartitionied_DHFGeneric")


def defaultMergePartitionied_DHFGeneric_UDM(surrDF, target_hash_patch, partition_col, partition_val ):  #sde #6
  print("entering defaultMergePartitionied_DHFGeneric UDM")
  target = target_hash_patch.split("#")[0]
  hash_col = target_hash_patch.split("#")[1] if (len(target_hash_patch.split("#")[1].strip() if "#" in target_hash_patch else "") !=0) else "MD5_HASH"
  patch_col = target_hash_patch.split("#")[2] if (len(target_hash_patch.split("#")[2].strip() if "#" in target_hash_patch and len(target_hash_patch.split("#"))>2 else "") !=0) else "ETL_LAST_UPDT_TS"
  insert_values={}
  dataframe_cols=surrDF.columns
  target_cols=spark.table(f"{target}").columns
  if(len(target_cols)>len(dataframe_cols)):
    print("number of columns in microbatch DF are less than number of columns in your target table")
    for col in dataframe_cols:
      insert_values[f'{col}']=f"updates.{col}"
      
    insert_values_upper = {key.upper():value for key,value in insert_values.items()}
    extra_cols = {key:val for key,val in not_null_cols_defaults(target).items() if key not in insert_values_upper}
    insert_values_nncols = {**insert_values, **extra_cols}
    print("insert_values_including_not_null_ncols",insert_values_nncols)
      
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFCTV_TS = updates.ETL_ROW_EFCTV_TS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXPRTN_TS" : "updates.ETL_ROW_EXPRTN_TS","ETL_CURR_ROW_IN" : "'N'",f"{patch_col}" :"'1001-01-01 00:00:00.000000'"}).whenNotMatchedInsert(values=insert_values_nncols).execute()
  else:
    delta_table=DeltaTable.forName(spark, target)
    delta_table.alias("events").merge(surrDF.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFCTV_TS = updates.ETL_ROW_EFCTV_TS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXPRTN_TS" : "updates.ETL_ROW_EXPRTN_TS","ETL_CURR_ROW_IN" : "'N'",f"{patch_col}" :"'1001-01-01 00:00:00.000000'"}).whenNotMatchedInsertAll().execute()
  print("end of defaultMergePartitionied_DHFGeneric UDM")  


# COMMAND ----------

def addAuditColumnsRemoveDupsCdcSyncMultistream_clt(df, target, targetKey, partition_col, partition_val):
  firsRowDF = df  
  #newDF = df.withColumn("MD5_HASH",col("MD5_HASH").cast(IntegerType))
  newDF = df 
  print(firsRowDF.columns)
  
  #tgtDF = DeltaTable.forName(spark, target).toDF
  tgtDF=spark.sql(f"select * from {target}").filter(col("PARTITION_VAL") == partition_val)
  
  partition_val = partition_val.replace("-","_")
  tempView_name = target.split(".")[1] +'_'+ partition_val
  print('Temp view name---',tempView_name)
  tgtDF.createOrReplaceGlobalTempView(tempView_name)
  
  #identifying the orphan records
  orphanQuery = """ select distinct {targetKey} from global_temp.{temptarget} where ({targetKey}) not in (select {targetKey} from global_temp.{temptarget} where etl_curr_row_fl='Y' )"""
  #to do need to take care of the composite key
  orphanQuery=orphanQuery.replace("{targetKey}", targetKey).replace("{temptarget}", tempView_name)       
  print("orpQuery after targetKey replace: ", orphanQuery)
  
  
  tgtOrphanDF = spark.sql(orphanQuery)
  #tgtOrphanDF.show(False)
  
  print("selecting the common records between source and target: ")
  SrcTargetDF = tgtDF.alias("targetDF").join(newDF.alias("srcDF"), targetKey.split(","), "leftsemi").select(firsRowDF.columns)
  #SrcTargetDF.show(3, False)
  
  #doing the union of source and target
  print("Union of source and target")
  unionAllTempdf = newDF.withColumn("isTarget", lit(0)).union(SrcTargetDF.withColumn("isTarget", lit(1)))
  #  val unionTempdf = unionAllTempdf.drop("isTarget")
  #  unionTempdf.show(3, false)
  
  print("Drop Duplicates in unionTempdf: ")
  nonDupUnionDf = unionAllTempdf.dropDuplicates(["MD5_HASH","ETL_ROW_EFF_DTS"])
  #  nonDupUnionDf.show(3, false)
  
  # future dated record
  w3 = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("isTarget").desc())
  df2 = nonDupUnionDf.withColumn("dupe",  col("MD5_HASH") == lag("MD5_HASH", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull()) | (col("isTarget") == '1'))
  
#   // OOS record
#   //val w4 = Window.partitionBy(targetKey.split(",").map(colName => col(colName)): _*).orderBy(col("ETL_ROW_EFF_DTS").desc,col("isTarget").desc)
#   // val df3 = df2.withColumn("dupe",  $"MD5_HASH" === lag($"MD5_HASH", 1).over(w4)).where(($"dupe" === false || $"dupe".isNull ||	$"isTarget" === '1')  )
  
  df311 = df2.drop("isTarget","dupe")
  
  w = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFF_DTS"))
  auditDF = df311.withColumn("ETL_ROW_EXP_DTS", lead("ETL_ROW_EFF_DTS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_FL", lit("N")).withColumn("ETL_ADD_DTS", current_timestamp()).withColumn("ETL_LAST_UPDATE_DTS", current_timestamp()).withColumn("ETL_CURR_ROW_FL", when(col("ETL_ROW_EXP_DTS") == "9999-12-31", "Y").otherwise("N"))
  
  print("After adding Audit date columns")
  auditDF.show(2,False)
  # removing the orphan rows
  nonOrphanDF = auditDF.join(tgtOrphanDF, targetKey.split(","), "leftanti")
  return nonOrphanDF

# COMMAND ----------

def defaultMergeCdcMultistream_clt(df,target,partition_col,partition_val):
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(df.alias("updates"),f"events.MD5_HASH = updates.MD5_HASH AND events.ETL_ROW_EFF_DTS = updates.ETL_ROW_EFF_DTS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXP_DTS":"updates.ETL_ROW_EXP_DTS","ETL_CURR_ROW_FL":"updates.ETL_CURR_ROW_FL","ETL_LAST_UPDATE_DTS":"current_timestamp()"}).whenNotMatchedInsertAll().execute()


# COMMAND ----------

# Function to remove special characters from string columns
def removeSpecialCharacters(df):
  print("inside rmSpecialCharacter function")
  for col in df.columns:
    if df.schema[col].dataType==StringType():
      df=df.withColumn(col,regexp_replace(trim(regexp_replace(col, "[^\\x20-\\x7e\\xDF\\xE4\\xF6\\xFC\\xC4\\xD6\\xDC]", "")), " [ ]+", " ",))
  print("end of rmSpecialCharacter function")
  return df


# COMMAND ----------

# DBTITLE 1,Key Generation Function
#key_gen format  =  anchor:Surrogate_key#Foreign:policy_key,abc_key
def add_anchor(anchor_df_new,key_gen):
  print("Entering add_anchor Function")
  key_gen=key_gen.lower()
  key_values=key_gen.split("#")
  for i in key_values:
    key=i.split(":")[0]
    values=i.split(":")[1].split(",")
    if(key=='anchor'):
      for col_name in values:
        new_col_name=col_name.upper()+"_ID"
        anchor_df_new=anchor_df_new.select("*",xxhash64(f'{col_name}').alias(f"{new_col_name}"))
    else:
       for col_name in values:
        new_col_name=col_name.upper()+"_ID"
        anchor_df_new=anchor_df_new.select("*",xxhash64(f'{col_name}').alias(f"{new_col_name}")).drop(f'{col_name}')
  print("End of add_anchor Function")
  return anchor_df_new

# COMMAND ----------

def removeDuplicatesPartitionied_DHFGeneric(df, target_hash, targetKey, partition_col, partition_val):

  print("entering removeDuplicatesPartitionied_DHFGeneric function \n")
  target = target_hash.split("#")[0]
  hash_col = target_hash.split("#")[1] if (len(target_hash.split("#")[1].strip() if "#" in target_hash else "") !=0) else "MD5_HASH"
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS"))
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print(firsRowDF.columns)
  targetDF=spark.sql(f"select * from {target} where {partition_col} = '{partition_val}'")
  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = firsRowDF.join(targetDF, targetKey.split(","), "right").filter(col("targetDF.ETL_CURR_ROW_FL") == 'Y').select("targetDF.*").select(firsRowDF.columns)  
  print("\n latestInTargetDF cols")
  print(latestInTargetDF.columns)  
 
  #add target latest rows to microbatch
  df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
  #remove consecutive duplicates, choose first 
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFF_DTS").asc(),col("isTarget").desc(),col(f"{hash_col}").asc())
  df3 = df2.withColumn("dupe",  col(f"{hash_col}") == lag(f"{hash_col}", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe") 
#If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 =  Window.partitionBy(*partition_cols).orderBy(*partition_cols)
  df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
  print("end of removeDuplicatesPartitionied_DHFGeneric function")
  return df4 


def removeDuplicatesPartitionied_DHFGeneric_UDM(df, target_hash, targetKey, partition_col, partition_val):

  print("entering removeDuplicatesPartitionied_DHFGeneric_UDM function \n")
  target = target_hash.split("#")[0]
  hash_col = target_hash.split("#")[1] if (len(target_hash.split("#")[1].strip() if "#" in target_hash else "") !=0) else "MD5_HASH" 
  partition_cols=targetKey.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFCTV_TS"))
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print(firsRowDF.columns)
  targetDF=spark.sql(f"select * from {target} where {partition_col} = '{partition_val}'")
  targetDF=targetDF.alias("targetDF")
  latestInTargetDF = firsRowDF.join(targetDF, targetKey.split(","), "right").filter(col("targetDF.ETL_CURR_ROW_IN") == 'Y').select("targetDF.*").select(firsRowDF.columns)  
  print("\n latestInTargetDF cols")
  print(latestInTargetDF.columns)  
 
  #add target latest rows to microbatch
  df2 = df.withColumn("isTarget", lit(0)).union(latestInTargetDF.withColumn("isTarget", lit(1)))
  #remove consecutive duplicates, choose first 
  w3 = Window.partitionBy(*partition_cols).orderBy(col("ETL_ROW_EFCTV_TS").asc(),col("isTarget").desc(),col(f"{hash_col}").asc())
  df3 = df2.withColumn("dupe",  col(f"{hash_col}") == lag(f"{hash_col}", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull())).drop("dupe") 
#If there is only 1 row for a key, its a Target's duplicate with no other new rows. Ignore it.
  w2 =  Window.partitionBy(*partition_cols).orderBy(*partition_cols)
  df4 = df3.withColumn("count",  count("*").over(w2)).where((col("count") != 1) | ((col("isTarget") != 1)  & (col("count") == 1))).drop("count").drop("isTarget")
  print("end of removeDuplicatesPartitionied_DHFGeneric_UDM function")
  return df4 

# COMMAND ----------

# DBTITLE 1,RDM
# for Notebook approach - to get Takgroup Id to be provided in RDM function call
def getTaskGrp_id(parameter_string):
  task_group_id=parameter_string.split("#")[7]
  return str(task_group_id)
  
# get the RDM UI  details
def getUserPropertyValue(param,phrase):
  
  if phrase is not None and isinstance(phrase, str):
    splitted_param = phrase.split("#")
    required_param_pair = [param_pair for param_pair in splitted_param if param in param_pair]

    if len(required_param_pair) != 0:
      return required_param_pair[0].split(":")[1]
    else:
      return None
  
  else:
    return None

# Reference data Management for ETL Pipeline
def rdm_function(df,RDM_columns,target_table,taskgrp_id):
  print("In RDM Function")
  RDM_start_time = time.time()
  taskgrp_id=str(taskgrp_id)
  df_view="RDM_VIEW_"+ taskgrp_id
  df.createOrReplaceGlobalTempView(df_view)
  case_statement=''
  join_condition=''
  translation_id_column_lst = []
  target_table=target_table.upper()

  df_alias = target_table[0:3]+'_'+taskgrp_id
  view_name='pc_rfrnc_data.rdm_view'
  for values in RDM_columns.split(","):
    code_colums_full=values.split(";")
    code_column = code_colums_full[0].strip()
    domain=code_colums_full[1].strip()
    alias=code_column.replace("_","")
    new_colum_name=code_column[:-2]+'TP' #new_colum_name=code_column.replace("CD","TP")
    source_name_column = code_colums_full[2] if (len(code_colums_full)==3 or len(code_colums_full)==4) else None ##added for SRC_NM
    translation_id_column = code_colums_full[3] if (len(code_colums_full)==4) else None
    case_cond=f"CASE WHEN {df_alias}.{code_column} IS NULL THEN 0 WHEN TRIM({df_alias}.{code_column}) = '' THEN 2 ELSE COALESCE(REF_{alias}.TRGT_TP,-2) END AS {new_colum_name}, "
    case_statement = case_statement+case_cond
    join_cond_srcname='' ##added for SRC_NM
    
    if(source_name_column != None and source_name_column[-2:].upper()=='NM'): ##added for SRC_NM
      join_cond_srcname = f" AND upper(trim(REF_{alias}.SRC_NM)) = upper({df_alias}.{source_name_column})"  ##added for SRC_NM

    if(translation_id_column == None):

      if code_column=="SRC_SYS_CD":
        join=f" LEFT OUTER JOIN {view_name} REF_{alias} ON trim(REF_{alias}.VAL_CD) = trim({df_alias}.{code_column}) AND upper(REF_{alias}.TRGT_ATTR_NM) = upper('{new_colum_name}') AND upper(REF_{alias}.TRGT_SBJT_AREA_DS) = upper('{domain}')"
      else:
        join=f" LEFT OUTER JOIN {view_name} REF_{alias} ON REF_{alias}.SRC_SYS_CD = {df_alias}.SRC_SYS_CD AND  trim(REF_{alias}.VAL_CD) = trim({df_alias}.{code_column}) AND upper(REF_{alias}.TRGT_TBL_NM) = upper('{target_table}') AND upper(REF_{alias}.TRGT_ATTR_NM) = upper('{new_colum_name}') AND upper(REF_{alias}.TRGT_SBJT_AREA_DS) = upper('{domain}')"

    else:

      if code_column=="SRC_SYS_CD":
        translation_id_column_lst.append(translation_id_column)
        join=f" LEFT OUTER JOIN {view_name} REF_{alias} ON trim(REF_{alias}.VAL_CD) = trim({df_alias}.{code_column}) AND upper(REF_{alias}.TRGT_ATTR_NM) = upper('{new_colum_name}') AND upper(REF_{alias}.TRGT_SBJT_AREA_DS) = upper('{domain}') AND REF_{alias}.TRANSLATION_RULE_REFERENCE_ID = {df_alias}.{translation_id_column}"
      else:
        translation_id_column_lst.append(translation_id_column)
        join=f" LEFT OUTER JOIN {view_name} REF_{alias} ON REF_{alias}.SRC_SYS_CD = {df_alias}.SRC_SYS_CD AND  trim(REF_{alias}.VAL_CD) = trim({df_alias}.{code_column}) AND upper(REF_{alias}.TRGT_TBL_NM) = upper('{target_table}') AND upper(REF_{alias}.TRGT_ATTR_NM) = upper('{new_colum_name}') AND REF_{alias}.TRANSLATION_RULE_REFERENCE_ID = {df_alias}.{translation_id_column} AND upper(REF_{alias}.TRGT_SBJT_AREA_DS) = upper('{domain}')"

    join_condition=join_condition+join+join_cond_srcname

  print("translation columns are :" ,translation_id_column_lst)
  
  df_view="RDM_VIEW_"+target_table
  df.createOrReplaceGlobalTempView(df_view)
  req_columns = df.columns
  req_columns.remove('SRC_SYS_CD')
  columns=','.join(req_columns)
  query=f'select {df_alias}.SRC_SYS_CD,{columns},'+case_statement[:-2]+f" from global_temp.{df_view} {df_alias}"+join_condition
  outputDF=spark.sql(query)
  
  trans_col=""
  for col in translation_id_column_lst:
    outputDF=outputDF.drop(col) 
  if('RDM_MULTI'.lower() in RDM_columns.lower()):
    rdm_multi_drop_cols = [dfCols for dfCols in outputDF.columns if 'rdm_multi' in dfCols.lower() and 'cd' in dfCols.lower()]
    outputDF = outputDF.drop(*rdm_multi_drop_cols)
    rdm_multi_tp_cols = [dfCols for dfCols in outputDF.columns if 'rdm_multi' in dfCols.lower() and 'tp' in dfCols.lower()]
    new_rm_rdm_multi = [tpcols.lower().replace('rdm_multi_','') for tpcols in rdm_multi_tp_cols]
    new_rm_rdm_multi = [xcols.upper() for xcols in new_rm_rdm_multi]
    outputDF = reduce(lambda df, idx: df.withColumnRenamed(rdm_multi_tp_cols[idx], new_rm_rdm_multi[idx]), list(range(len(rdm_multi_tp_cols))), outputDF)

  RDM_end_time = time.time()
  RDMTimeInMins = int((RDM_end_time-RDM_start_time)/60)
  print("RDM Function took(in mins) :",RDMTimeInMins)
  print("End of RDM Function")   
  return outputDF

# COMMAND ----------

#agreement date chaining on effective date and expiration date
def eff_exp_date_chaining_aggr(df, targetKey):
  datechainDF = df
  w = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFCTV_TS"))
  datechainDF = datechainDF.withColumn("ETL_UPDATE_TS", lead("ETL_ADD_TS", 1, "9999-12-31").over(w))
  w1 = Window.partitionBy(targetKey.split(",")).orderBy(col("EFCTV_DT"))
  datechainDF = datechainDF.withColumn("EXPRTN_DT", lead("EFCTV_DT", 1, "9999-12-31").over(w1))
  return datechainDF 

#Merge function for agreement date chaining on effective date and expiration date
def defaultMerge_double_date_chaining_aggr(df,target,partition_col,partition_val,patch_col,hash_col):
  delta_table=DeltaTable.forName(spark, target)
  delta_table.alias("events").merge(df.alias("updates"),f"events.{hash_col} = updates.{hash_col} AND events.ETL_ROW_EFCTV_TS = updates.ETL_ROW_EFCTV_TS AND events.{partition_col} = '{partition_val}'").whenMatchedUpdate(set = {"ETL_ROW_EXPRTN_TS":"updates.ETL_ROW_EXPRTN_TS","ETL_CURR_ROW_IN":"updates.ETL_CURR_ROW_IN",f"{patch_col}":f"updates.{patch_col}","EXPRTN_DT":"updates.EXPRTN_DT"}).whenNotMatchedInsertAll().execute()

# COMMAND ----------

def addDoubleAuditColumnsRemoveDupsCdcSyncMultistream_clt(df, target, targetKey, partition_col, partition_val, hash_col, patch_col):
  firsRowDF = df
  newDF = df
  IDF = df
  IDF = IDF.withColumn('dummy_ETL_ROW_EFCTV_TS',lit(col('ETL_ROW_EFCTV_TS')))
  print(firsRowDF.columns)
  tgtDF=spark.sql(f"select * from {target} where ETL_CURR_ROW_IN='Y' or ETL_HST_ROW_IN='Y'")
  print("selecting the common records between source and target: ")
  SrcTargetDF = tgtDF.alias("targetDF").join(newDF.alias("srcDF"), targetKey.split(","), "leftsemi").select(firsRowDF.columns)
  #doing the union of source and target
  print("Union of source and target")
  unionAllTempdf = newDF.withColumn("isTarget", lit(0)).union(SrcTargetDF.withColumn("isTarget", lit(1)))
  print("Duplicates in the unionAllTempdf dataframe from source and target")
  #display(unionAllTempdf)
  print("Drop Duplicates in unionTempdf: ")
  nonDupUnionDf = unionAllTempdf.dropDuplicates([f"{hash_col}","ETL_ROW_EFCTV_TS"])
  # future dated record
  w3 = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFCTV_TS").asc(),col("isTarget").desc())
  df2 = nonDupUnionDf.withColumn("dupe",  col(f"{hash_col}") == lag(f"{hash_col}", 1).over(w3)).where((col("dupe") == False) | (col("dupe").isNull()) | (col("isTarget") == '1'))
  df311 = df2.drop('dupe','isTarget')
  
  ##Date chaining for ETL_ROW_EFCTV_TS and ETL_ROW_EXPRTN_TS
  w = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFCTV_TS"))
  IEDF = df311.withColumn("ETL_ROW_EXPRTN_TS", lead("ETL_ROW_EFCTV_TS", 1, "9999-12-31").over(w)).withColumn("ETL_CURR_ROW_IN", lit("N")).withColumn("ETL_ADD_TS", current_timestamp()).withColumn(f"{patch_col}", current_timestamp()).withColumn("ETL_CURR_ROW_IN", when(col("ETL_ROW_EXPRTN_TS") == "9999-12-31", "Y").otherwise("N")).withColumn('ETL_HST_ROW_IN',when(df311.RCRD_TYPE_DS.contains("DateChain"),lit('N')).otherwise(lit('Y')))
  IEDF = IEDF.withColumn("ENDRSMNT_EXPRTN_DT", lit("9999-12-31")).withColumn("EXPRTN_DT", lit("9999-12-31"))
  IEDF = IEDF.alias("IEDF_alias")
  IDF = IDF.alias('IDF_alias')

  targetKey_list = targetKey.split(",")
  out_of_seq_join_condition = ''
  for i in targetKey_list:
    out_of_seq_join_condition = out_of_seq_join_condition+f'(IDF["{i}"] == IEDF["{i}"]) & '
  out_of_seq_join_condition = out_of_seq_join_condition[:-2]  
  out_of_seq_join_condition = out_of_seq_join_condition+" & (col('IDF_alias.ETL_ROW_EFCTV_TS') > col('IEDF_alias.ETL_ROW_EFCTV_TS'))"+" & (col('IEDF_alias.EFCTV_DT') > col('IDF_alias.EFCTV_DT'))"
  out_of_seq_join_condition = "("+out_of_seq_join_condition+')'
  out_of_seq_join_condition = eval(out_of_seq_join_condition)
  regenrationDF1 = IEDF.join(IDF, out_of_seq_join_condition).select("IEDF_alias.*","IDF_alias.Dummy_ETL_ROW_EFCTV_TS")
  regenrationDF1 = regenrationDF1.withColumn('RCRD_TYPE_DS',when(regenrationDF1.RCRD_TYPE_DS.contains("DateChain"),lit(col('RCRD_TYPE_DS'))).otherwise(concat(col('RCRD_TYPE_DS'),lit('-DateChain')))).withColumn("ETL_ROW_EXPRTN_TS", lit("9999-12-31")).withColumn('ETL_HST_ROW_IN',lit('N')).withColumn('ETL_CURR_ROW_IN',lit('N'))

  join_condition = ''
  for i in targetKey_list:
      join_condition = join_condition+f'(IDF["{i}"] == IEDF["{i}"]) & '
  join_condition = join_condition[:-2]
  join_condition = join_condition+" & (col('IDF_alias.ETL_ROW_EFCTV_TS') > col('IEDF_alias.ETL_ROW_EFCTV_TS'))"+" & (col('IEDF_alias.EFCTV_DT') <= col('IDF_alias.EFCTV_DT'))"
  join_condition = "("+join_condition+')'
  join_condition=eval(join_condition)
  regenrationDF2 = IEDF.join(IDF, join_condition).select("IEDF_alias.*","IDF_alias.Dummy_ETL_ROW_EFCTV_TS")
  regenrationDF2 = regenrationDF2.withColumn('RCRD_TYPE_DS',when(regenrationDF2.RCRD_TYPE_DS.contains("DateChain"),lit(col('RCRD_TYPE_DS'))).otherwise(concat(col('RCRD_TYPE_DS'),lit('-DateChain')))).withColumn("ETL_ROW_EXPRTN_TS", lit("9999-12-31")).withColumn('ETL_HST_ROW_IN',lit('N')).withColumn('ETL_CURR_ROW_IN',lit('N'))  
  partition_cols= targetKey.split(",")
  partition_cols.append('Dummy_ETL_ROW_EFCTV_TS')
  w1 = Window.partitionBy(partition_cols).orderBy(col("EFCTV_DT").desc(),col("ETL_ROW_EFCTV_TS").desc(),col("Dummy_ETL_ROW_EFCTV_TS").asc())
  regenrationDF2 = regenrationDF2.withColumn('row_num',row_number().over(w1)).filter(col('row_num') == 1).drop('row_num')
  
  regenrationDF = regenrationDF1.unionByName(regenrationDF2)
  regenrationDF = regenrationDF.withColumn('ETL_ROW_EFCTV_TS',lit(col('dummy_ETL_ROW_EFCTV_TS')))
  regenrationDF = regenrationDF.select(IEDF.columns)
  final_df = IEDF.unionByName(regenrationDF)
  
  partition_cols.remove('Dummy_ETL_ROW_EFCTV_TS')
  partition_cols.append('ETL_ROW_EFCTV_TS')
  final_df = final_df.withColumn('regen_indicator',when(final_df.RCRD_TYPE_DS.contains("DateChain"),lit(1)).otherwise(lit(0)))
  w4 = Window.partitionBy(partition_cols).orderBy(col("EFCTV_DT").asc(),col('regen_indicator').desc())
  final_df = final_df.withColumn("EXPRTN_DT", lead("EFCTV_DT", 1, "9999-12-31").over(w4))
  my_new_df = final_df
  w5 = Window.partitionBy(partition_cols).orderBy(col("ENDRSMNT_EFCTV_DT").asc())
  my_new_df = my_new_df.withColumn("DUMMY_EFCTV_DT", lead("ENDRSMNT_EFCTV_DT",1).over(w5))
  my_new_df = my_new_df.withColumn("ENDRSMNT_EXPRTN_DT",when(col('ENDRSMNT_EFCTV_DT') == col('DUMMY_EFCTV_DT'),lit("9999-12-31")).otherwise(lit(col('DUMMY_EFCTV_DT')))).drop("DUMMY_EFCTV_DT")
  my_new_df =my_new_df.withColumn('ENDRSMNT_EXPRTN_DT' ,when(col('ENDRSMNT_EXPRTN_DT').isNotNull(),lit(col('ENDRSMNT_EXPRTN_DT'))).otherwise(lit('9999-12-31'))).drop('regen_indicator')
  w6 = Window.partitionBy(targetKey.split(",")).orderBy(col("ETL_ROW_EFCTV_TS").desc())
  my_new_df = my_new_df.withColumn("ETL_CURR_ROW_IN", when(((col("EXPRTN_DT") >= "9999-12-31") & (col('ETL_ROW_EXPRTN_TS') >= "9999-12-31") & (col('ETL_ROW_EFCTV_TS') == max(col('ETL_ROW_EFCTV_TS')).over(w6))), "Y").otherwise("N"))
  return my_new_df
  
