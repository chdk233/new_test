# Databricks notebook source
from pyspark import SparkContext
from pyspark import SQLContext
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.window import *
import time
from datetime import datetime as dt
from pyspark.sql.types import *
import concurrent.futures
import pytz
import json
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from datetime import timedelta
totalWorkerCores = sc.defaultParallelism
UTC = pytz.utc

# COMMAND ----------

spark.conf.set("spark.databricks.delta.optimize.zorder.checkStatsCollection.enabled", False)
# spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled",False)
parallelthreads= totalWorkerCores 
print("Total Worker Cores - " ,totalWorkerCores)
print("Number Of Parallel thread - " ,parallelthreads)

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("jobName", "Test", "Job_Name") 
dbutils.widgets.text("groupId", "1", "Group_Id")
dbutils.widgets.text("jobLogTable","","Job_Log_Table")
dbutils.widgets.text("jobStatusLog","","Job_Status_Log")
dbutils.widgets.text("environment", "dev", "environment")
jobName=str(dbutils.widgets.get("jobName")).upper()
groupId=int(dbutils.widgets.get("groupId"))
jobLogTable=str(dbutils.widgets.get("jobLogTable"))
jobStatusLog=str(dbutils.widgets.get("jobStatusLog"))
environment =str(dbutils.widgets.get("environment"))

print("JobName in notebook is : ",jobName)
print("groupId in notebook is : ",groupId)
print("Log table in notebook is : ",jobLogTable)
print("jobStatusLog in notebook is : ",jobStatusLog)
print("environment in notebook is : " , environment)


# COMMAND ----------

# MAGIC %run ../utils/_utils

# COMMAND ----------

context_str = dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
context = json.loads(context_str)
job_id = int(context.get('tags', {}).get('jobId', '0')) 
run_id_obj = context.get('currentRunId', {})
run_id = int(run_id_obj.get('id', '0') if run_id_obj else '0')

JobLogPerTable = StructType([ \
    StructField("job_id",LongType(),True), \
    StructField("group_id",LongType(),True), \
    StructField("job_name",StringType(),True), \
    StructField("run_id", LongType(), True), \
    StructField("process_name", StringType(), True), \
    StructField("tablename", StringType(), True), \
    StructField("start_time", StringType(), True) ,\
    StructField("end_time", StringType(), True), \
    StructField("status", StringType(), True), \
    StructField("error_msg", StringType(), True) 
  ])

def persistLog(jobMetrics, logTable) :
  df = spark.createDataFrame(jobMetrics,JobLogPerTable).coalesce(1)
  df.write.format("delta").mode("append").saveAsTable(f"{logTable}")

# COMMAND ----------

TableGroup = StructType([ \
    StructField("data_domain",StringType(),True), \
    StructField("database_name",StringType(),True), \
    StructField("table_name",StringType(),True), \
    StructField("job_group_id", LongType(), True), \
    StructField("partition_col", StringType(), True), \
    StructField("z_orderby_column", StringType(), True), \
    StructField("active", BooleanType(), True) ,\
    StructField("size_of_table", StringType(), True), \
    StructField("retain_hours_vacuum", StringType(), True)
  ])

# COMMAND ----------

def getTableList(groupId):
  pushdown_query = f"""( SELECT *  FROM delta_optimize_config_new_msapps where active and job_group_id={groupId}  ) t """
  print(pushdown_query)
  tablelist_df=spark.read.format('jdbc').options(**sqlConnectionProperties).option('dbtable', pushdown_query).load()
  
  tablelist=list(map(lambda row:row.asDict(),tablelist_df.collect()))              
  print(tablelist)
  return(tablelist)

# COMMAND ----------

def doOptimize(config):
  print('dooptimize function')
  optimize_table = config['database_name'] +"." + config['table_name']
  print('optimize_table:',optimize_table)
  zordercol = config['z_orderby_column']
  
  zOrderColumn = ",".join([i.strip().upper() for i in zordercol.split(",")])
  print('zOrderColumn:',zOrderColumn)
  partitionCol = config['partition_col']
  if(len(partitionCol.strip()) >0):
    partitionCol = partitionCol.split(",")
    partitionCol = [str(i).strip() for i in partitionCol]
  else:
    partitionCol = []
  
  print('partitionCol:',partitionCol)
  print('len of partitionCol:',len(partitionCol))
  print(f"{time.time()}: Optimize job is starting")
  currentTimeStart = time.time()
  print('currentTimeStart',currentTimeStart)
  startTime = time.asctime(time.localtime(time.time()))
  print('startTime',startTime)
  partitiondate = (date.today() - timedelta(days=1)).strftime("%Y%m%d")
  year=(date.today() - timedelta(days=1)).year
  month=(date.today() - timedelta(days=1)).month
  day=(date.today() - timedelta(days=1)).day
  zOrderPredicate = ""

  try:
    if(not( zOrderColumn == None  or len(zOrderColumn) == 0  ) ):
      zOrderPredicate = f"ZORDER BY {zOrderColumn}"
      
    if(len(partitionCol) == 1):
      print("inside OPTIMIZE1")
      optimizeresult= spark.sql(f"OPTIMIZE {optimize_table} where {partitionCol[0]} = {partitiondate} {zOrderPredicate}")
    elif(len(partitionCol) == 2): 
      print("inside OPTIMIZE2")
      optimizeresult=spark.sql(f"OPTIMIZE {optimize_table} where {partitionCol[0]} = {year} and {partitionCol[1]} = {month} {zOrderPredicate}")
    elif(len(partitionCol)==3):
      print("inside OPTIMIZE3")
      optimizeresult=spark.sql(f"OPTIMIZE {optimize_table} where {partitionCol[0]} = {year} and {partitionCol[1]} = {month} and {partitionCol[2]} = {day} {zOrderPredicate}")
    else:
      print("inside else OPTIMIZE")
      optimizeresult= spark.sql(f"OPTIMIZE {optimize_table} {zOrderPredicate} ")
      print("----Printing the optimization result----")
      display(optimizeresult)
      optimizeresult.show(truncate=False)
      
    currentTimeEnd=time.time()
    endTime = time.asctime(time.localtime(time.time()))
    JobLogPerTable=[[job_id, int(groupId), jobName, runId, "Optimization/zordering", optimize_table, str(startTime), str(endTime), "Completed","NA"]]
    persistLog(JobLogPerTable, jobLogTable)
    print(f"{currentTimeEnd}: Optimize completed for {optimize_table}.")
    
  except Exception as e:
    print("Optimize Failed",{e})
    JobLogPerTable=[[job_id, int(groupId), jobName, runId, "Optimization/zordering", optimize_table, str(startTime), str(startTime), "Failed",str({e})]]
    persistLog(JobLogPerTable, jobLogTable)
    raise Exception(f"Optimize failed table",{e})

  if(config['retain_hours_vacuum'] != None):
    doVacuum(config)
  else:
    print("Vacuum cannot will not be performed since retention period is empty")

# COMMAND ----------

def doVacuum(config):
  vacuum_table = config['database_name'] +"." + config['table_name']
  retain_hrs = config['retain_hours_vacuum']
  print("retain_hrs",retain_hrs)
  currentTimeStart = time.time()
  startTime = time.asctime(time.localtime(time.time()))
  print(f"{currentTimeStart}: Vacuum job is starting")

  try:
    print("Vacuuming")
    vacuumresult=spark.sql(f"VACUUM {vacuum_table} RETAIN {retain_hrs} HOURS") 
    currentTimeEnd=time.time()
    endTime = time.asctime(time.localtime(time.time()))
    JobLogPerTable=[[job_id, int(groupId), jobName, runId, "Vacuum", vacuum_table, str(startTime), str(endTime), "Completed","NA"]]
    persistLog(JobLogPerTable, jobLogTable)
    print(f"{currentTimeEnd}: Vacuum completed for {vacuum_table}.")
  except Exception as e:
    print("Performing Vacuum Failed", {e})
    JobLogPerTable=[[job_id, int(groupId), jobName, runId, "Vacuum", vacuum_table, str(startTime), str(startTime), "Failed",str({e})]]
    persistLog(JobLogPerTable, jobLogTable)
    

# COMMAND ----------

def startOptimizeMain(jobname, groupId):
  currentTimeStart = time.time()
  startTime = time.asctime(time.localtime(time.time()))
  optimizeconfigtableList= getTableList(groupId)
  
  with ThreadPoolExecutor(max_workers= parallelthreads) as executor:
    tasksupport = executor.map(doOptimize,optimizeconfigtableList)
  
  currentTimeEnd=time.time()
  endTime = time.asctime(time.localtime(time.time()))
  spark.sql(f"update {jobStatusLog} set status='Completed',end_time='{endTime}' where job_id={job_id} and group_id={groupId} and run_id={runId}")
  print("optimization job completed :Start_time - ",startTime," :End_time - ",endTime)

# COMMAND ----------

# Calling the main function
startOptimizeMain(jobName,groupId)
