# Databricks notebook source
print("calling the python child notebook")

# COMMAND ----------

def test_curation_child(microBatchDF, batchId, harmonizedDB, curateDB, target_table):
  print("\n entering test_curation_child \n")
  curate_table = curateDB +"."+target_table
  print("---curate table--",curate_table)
  print("---curateDB----",curateDB)

  microBatchDF.createOrReplaceGlobalTempView("V")
  
  display(spark.sql("select * from global_temp.V"))

  microBatchDF.write.mode("append").format("delta").saveAsTable(f"{curate_table}")
 
