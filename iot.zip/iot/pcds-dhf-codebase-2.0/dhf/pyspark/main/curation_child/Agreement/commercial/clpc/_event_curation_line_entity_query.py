# Databricks notebook source
def build_ds_line_covg(harmonizedDB,partition_val,table,lob):
  curation_query = """
  select 
 LINE_COVG_KEY
, POL_KEY
, POL_LINE_KEY
, COVG_KEY
, CVRBL_KEY
, CVRBL_TYPE_CD
, PARTITION_VAL 
, END_EFF_DT
, END_EXP_DT
, ETL_ROW_EFF_DTS
, LOB_CD
, SOURCE_SYSTEM 
FROM (
SELECT 
 LINE_COVG_KEY
, POL_KEY
, POL_LINE_KEY
, COVG_KEY
, CVRBL_KEY
, CVRBL_TYPE_CD
, PARTITION_VAL 
, END_EFF_DT
, END_EXP_DT
, ETL_ROW_EFF_DTS
, LOB_CD
, SOURCE_SYSTEM 
,ROW_NUMBER() OVER ( PARTITION BY LINE_COVG_KEY, END_EFF_DT, ETL_ROW_EFF_DTS ORDER BY CASE WHEN END_EFF_DT <> END_EXP_DT THEN 1 ELSE 0 END DESC ) AS delete_precedence
FROM 
(
select DISTINCT
  DS_COVG_TERM.LINE_COVG_KEY
, DS_COVG_TERM.POL_KEY
, DS_COVG_TERM.POL_LINE_KEY
, DS_COVG_TERM.SOURCE_SYSTEM || '-' ||Upper(DS_COVG_TERM.COVG_CD) as COVG_KEY
, DS_COVG_TERM.CVRBL_KEY
, DS_COVG_TERM.CVRBL_TYPE_CD
, '{partition_val}' AS PARTITION_VAL 
, DS_COVG_TERM.END_EFF_DT
, DS_COVG_TERM.END_EXP_DT
, DS_COVG_TERM.ETL_ROW_EFF_DTS
, DS_COVG_TERM.LOB_CD
, DS_COVG_TERM.SOURCE_SYSTEM 
FROM global_temp.{table}_micro_batch mb
inner join {harmonizedDB}.DS_COVG_TERM DS_COVG_TERM
on ds_covg_term.covg_term_key = mb.covg_term_key
and DS_COVG_TERM.etl_last_update_dts = mb.etl_last_update_dts
WHERE LOB_CD = '{lob}' 
Order by POL_KEY, ETL_ROW_EFF_DTS ASC
) temp
) COVG
where delete_precedence = 1
"""
  return curation_query.replace("{harmonizedDB}",harmonizedDB).replace("{partition_val}", partition_val).replace("{table}", table).replace("{lob}", lob) 

# COMMAND ----------

def build_ds_line_cond(harmonizedDB,partition_val,table,lob):
  curation_query = """
  select 
 LINE_COND_KEY
, POL_KEY
, POL_LINE_KEY
, COND_KEY
, CVRBL_KEY
, CVRBL_TYPE_CD
, PARTITION_VAL 
, END_EFF_DT
, END_EXP_DT
, ETL_ROW_EFF_DTS
, LOB_CD
, SOURCE_SYSTEM 
FROM (
SELECT 
 LINE_COND_KEY
, POL_KEY
, POL_LINE_KEY
, COND_KEY
, CVRBL_KEY
, CVRBL_TYPE_CD
, PARTITION_VAL 
, END_EFF_DT
, END_EXP_DT
, ETL_ROW_EFF_DTS
, LOB_CD
, SOURCE_SYSTEM 
,ROW_NUMBER() OVER ( PARTITION BY LINE_COND_KEY, END_EFF_DT, ETL_ROW_EFF_DTS ORDER BY CASE WHEN END_EFF_DT <> END_EXP_DT THEN 1 ELSE 0 END DESC ) AS delete_precedence
FROM 
(
select DISTINCT
  DS_COND_TERM.LINE_COND_KEY
, DS_COND_TERM.POL_KEY
, DS_COND_TERM.POL_LINE_KEY
, DS_COND_TERM.SOURCE_SYSTEM || '-' ||Upper(DS_COND_TERM.COND_CD) as COND_KEY
, DS_COND_TERM.CVRBL_KEY
, DS_COND_TERM.CVRBL_TYPE_CD
, '{partition_val}' AS PARTITION_VAL 
, DS_COND_TERM.END_EFF_DT
, DS_COND_TERM.END_EXP_DT
, DS_COND_TERM.ETL_ROW_EFF_DTS
, DS_COND_TERM.LOB_CD
, DS_COND_TERM.SOURCE_SYSTEM 
FROM global_temp.{table}_micro_batch mb
inner join {harmonizedDB}.DS_COND_TERM DS_COND_TERM
on ds_cond_term.cond_term_key = mb.cond_term_key
and ds_cond_term.etl_last_update_dts <= mb.etl_last_update_dts
WHERE DS_COND_TERM.LOB_CD = '{lob}' 
Order by POL_KEY, ETL_ROW_EFF_DTS ASC
) temp
) COND
where delete_precedence = 1
"""
  return curation_query.replace("{harmonizedDB}",harmonizedDB).replace("{partition_val}", partition_val).replace("{table}", table).replace("{lob}",lob)  

# COMMAND ----------

def build_ds_line_excl(harmonizedDB,partition_val,table,lob):
  curation_query = """
  select 
 LINE_EXCL_KEY
, POL_KEY
, POL_LINE_KEY
, EXCL_KEY
, CVRBL_KEY
, CVRBL_TYPE_CD
, PARTITION_VAL 
, END_EFF_DT
, END_EXP_DT
, ETL_ROW_EFF_DTS
, LOB_CD
, SOURCE_SYSTEM 
FROM (
SELECT 
 LINE_EXCL_KEY
, POL_KEY
, POL_LINE_KEY
, EXCL_KEY
, CVRBL_KEY
, CVRBL_TYPE_CD
, PARTITION_VAL 
, END_EFF_DT
, END_EXP_DT
, ETL_ROW_EFF_DTS
, LOB_CD
, SOURCE_SYSTEM 
, ROW_NUMBER() OVER ( PARTITION BY LINE_EXCL_KEY, END_EFF_DT, ETL_ROW_EFF_DTS ORDER BY CASE WHEN END_EFF_DT <> END_EXP_DT THEN 1 ELSE 0 END DESC ) AS delete_precedence
FROM 
(
select DISTINCT
 DS_EXCL_TERM.LINE_EXCL_KEY
,DS_EXCL_TERM.POL_KEY
,DS_EXCL_TERM.POL_LINE_KEY
,DS_EXCL_TERM.SOURCE_SYSTEM || '-' ||Upper(DS_EXCL_TERM.EXCL_CD) as EXCL_KEY
,DS_EXCL_TERM.CVRBL_KEY
,DS_EXCL_TERM.CVRBL_TYPE_CD
,'{partition_val}' AS PARTITION_VAL 
,DS_EXCL_TERM.END_EFF_DT
,DS_EXCL_TERM.END_EXP_DT
,DS_EXCL_TERM.ETL_ROW_EFF_DTS
,DS_EXCL_TERM.LOB_CD
,DS_EXCL_TERM.SOURCE_SYSTEM 
FROM  global_temp.{table}_micro_batch mb
inner join {harmonizedDB}.DS_EXCL_TERM DS_EXCL_TERM
on ds_EXCL_term.EXCL_term_key = mb.EXCL_term_key
and DS_EXCL_TERM.etl_last_update_dts = mb.etl_last_update_dts
WHERE DS_EXCL_TERM.LOB_CD = '{lob}' 
Order by POL_KEY, ETL_ROW_EFF_DTS ASC
) temp
) EXCL
where delete_precedence = 1
"""
  return curation_query.replace("{harmonizedDB}",harmonizedDB).replace("{partition_val}",partition_val).replace("{table}", table).replace("{lob}",lob) 
