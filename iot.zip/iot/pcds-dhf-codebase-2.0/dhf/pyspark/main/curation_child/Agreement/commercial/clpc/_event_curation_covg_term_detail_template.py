# Databricks notebook source
from pyspark.sql import functions
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
import pandas as pd
import string

# COMMAND ----------

# MAGIC %run ../../../../harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %run ../../../../curation_child/Agreement/_event_library_agreement

# COMMAND ----------

def covg_term_detail_load(microBatchDF, batchId, harmonizedDB, curatedDB, target, cvrbl_type_cd):
   
    starttime = datetime.now()
    ########### view details ############
    micro_batch_view = "microBatchView_" + cvrbl_type_cd
    incr_covg_term_view = "incr_covg_term_" + cvrbl_type_cd
    
    #RUN CURATION QUERY  
    detail_table = f"{curatedDB}.{target}"         
    newmicroBatchDF = microBatchDF.filter(f"CVRBL_TYPE_CD='{cvrbl_type_cd}'")

    if newmicroBatchDF.count()>0 :
        print(f"EC started for {detail_table} and cvrbl_type_cd = {cvrbl_type_cd}")
        newmicroBatchDF.createOrReplaceGlobalTempView(incr_covg_term_view)          
        df_parm = spark.sql(f"""select SourceSystem,LOB,KeyColumnName from {harmonizedDB}.transpose_xref where lower(TARGET) = lower('{target}')  LIMIT 1 """)
        source_system = (df_parm.select(col("SourceSystem")).collect()[0][0]).strip()
        lob_cd = (df_parm.select(col("LOB")).collect()[0][0]).strip()
        Key_col = (df_parm.select(col("KeyColumnName")).collect()[0][0]).strip()
        #df_parm.show(1)

        print("Source System :",source_system,"\n LOB :",lob_cd,"\n Key_col:", Key_col)              
        partition_val = f"{source_system}-{lob_cd}-{cvrbl_type_cd}"
        print("Partition val : ",partition_val," and target:",target)  
        print(f"Calling build_covg_term_detail method for cvrbl_type_cd {cvrbl_type_cd}")
        
        covg_term_detail_query = build_covg_term_detail(harmonizedDB,curatedDB,target,cvrbl_type_cd,lob_cd,source_system,Key_col,incr_covg_term_view)
        print("Curation query for partition_val "+partition_val+" and target "+target+ "\n")   
        print(covg_term_detail_query)
        
        print("Reading data from source table for partition_val :",partition_val," and target:",target)        
        qryDF = spark.sql(covg_term_detail_query)  
        #print("qryDF  count for " ,partition_val ,"--" , qryDF.count(),"\n")
        #qryDF.show(1,False)
        
        print("Removing additional columns from the dataframe for partition_val :",partition_val," and target:",target)        
        queryDF = removeAdditionalCols_clt(qryDF, detail_table ) 
        
        #queryDF.createOrReplaceGlobalTempView("V")
        queryDF.createOrReplaceGlobalTempView(f"v_{lob_cd}_{target}_{cvrbl_type_cd}")
        
        print("Adding Hash Columns for partition_val:", partition_val," and target:",target)
        hashDF = addHashColumnXXHash_clt(f"v_{lob_cd}_{target}_{cvrbl_type_cd}")
        #print("hashDF  count for " ,partition_val ,"--" , hashDF.count(),"\n")
        #hashDF.show(1,False)
         
          
        print("Removing duplicates by Hash from the dataframe for partition_val:",partition_val," and target:",target)
        deduphashDF = removeDuplicatesMicrobatchByHash_clt(hashDF, f"{Key_col},END_EFF_DT" )
        
        print("SCD method is getting called for partition_val:", partition_val," and target:",target)
        surrogateID = getSurrogateIDCol_clt(detail_table)
        scdDF = scdMerge_clt(deduphashDF, detail_table, f"{Key_col},END_EFF_DT,ETL_ROW_EFF_DTS","PARTITION_VAL", partition_val, surrogateID)
        #scdDF.show(1,False) 
        
        print("Adding audit columns for partition_val:", partition_val," and target:",target)
        auditDF =  addAuditColumnsRemoveDupsCdcSyncMultistream_clt(scdDF, detail_table, f"{Key_col},END_EFF_DT","PARTITION_VAL",  partition_val) 
        
        print("Entering the addSurrogateKey_Non_UDM for partition_val:",partition_val," and target:",target)
        surrogateKeyDF = addSurrogateKey_Non_UDM(auditDF, detail_table)
        
        print("Entering defaultMergeCdcMultistream_clt method for partition_val:",partition_val," and target:",target)
        defaultMergeCdcMultistream_clt(surrogateKeyDF, detail_table, "PARTITION_VAL", partition_val)

        print(f"EC completed for {target} and partition_val = {partition_val}")
        endtime = datetime.now()
        print(" NoteBook Execution Start Time# ", starttime)
        print(" NoteBook Execution End  Time# " ,endtime)
        print(" NoteBook Run Time# " ,endtime - starttime )  
    else:
        print("Micro Batch Size is 0, Skipping rest of the functions for Target - " , target,"  and cvrbl_type_cd -",cvrbl_type_cd,"\n")
