# Databricks notebook source
# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/curation_child/Agreement/commercial/clpc/_event_curation_line_entity_query

# COMMAND ----------

# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization/_event_harmonizer_library_agreement

# COMMAND ----------

# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization/_event_harmonizer_library

# COMMAND ----------

# MAGIC %scala
# MAGIC // configuration to reduce th DBIO file fragments 
# MAGIC spark.conf.set("spark.databricks.io.cache.enabled", "false")

# COMMAND ----------

def merge_clpc_line_entity(microBatchDF, batchId,  harmonizedDB, curateDB, target_table, source_table, pval, lob): 
  
      starttime = datetime.now()
      print("EC started for ** source table ******* :-" ,source_table ,"  and for partition-",pval,"\n")
  
      df=spark.sql(f"select * from {harmonizedDB}.AGGREMENT_GWPC_IMCOP_KEY_XREF  where TABLE_NAME = '{target_table}'   AND source_table = '{source_table}' ") 
      df.show()
      curated_table = curateDB +"."+target_table
      keycol =df.collect()[0][1]
      end_eff_dt =df.collect()[0][2]
      etl_row_eff_dts =df.collect()[0][3]
      #partition_val =df.collect()[0][4] 
     # lob = df.collect()[0][5]    
      source_table = df.collect()[0][6]   
     # coverable_type = df.collect()[0][7]   
      key = f"{keycol},{end_eff_dt}" 
      scdkey = f"{keycol},{end_eff_dt},{etl_row_eff_dts}"   
      partition_val = pval.replace("-","_").lower()
      table =target_table+"_"+partition_val
      
      newmicroBatchDF = microBatchDF.filter(f"PARTITION_VAL='{pval}'")
      
      print("\n *EC processing for Target - ",target_table," for partition-",pval,"\n")
      if(newmicroBatchDF.count() > 0):
        print("\n *EC Started for target *",target_table,"partition-",pval," microbatch count:",newmicroBatchDF.count() ,"\n")
 
      microBatchDF.createOrReplaceGlobalTempView(f"{table}_micro_batch")
      #microBatchDF.createOrReplaceGlobalTempView("microBatchView")
  
      curation_query =  globals()['build_' + target_table](harmonizedDB,pval,table,lob)
      #print("curation_query after harmonizedDB replace: ", curation_query)
      print("curation_query after harmonizedDB replace for Target- ",target_table ," for LOB - ",lob," partition_val - ",  pval , curation_query)
      qryDF=spark.sql(f"{curation_query}")
      print("*********************curation_query execution is complete******* :-")
      qryDF.persist()
  
      qryDF.createOrReplaceGlobalTempView("V")
    
      print("Entering hashdf for Target- ",target_table ," for LOB - ",lob)
      hashDF = addHashColumnXXHash_clt("V")
      print("hashDF", hashDF.count())
      hashDF.persist()
        
      print("removeDuplicates by hash before SCD type 1:")
      deduphashDF = removeDuplicatesMicrobatchByHash_clt(hashDF, key)
      print("deduphashDF", deduphashDF.count())
      #deduphashDF.write.format("delta").mode("overwrite").saveAsTable("pcds_agreement_harmonized.ds_line_covg_temp")
      
      print("SCD Type1 start:")  
      surrogateID = getSurrogateIDCol_clt(curated_table)
      scdDF = scdMerge_clt(deduphashDF, curated_table, scdkey, "PARTITION_VAL", pval , surrogateID )
      scdDF.persist()
      print("scdDFCount:",scdDF.count(),datetime.now(),"\n")
      scdDF.show(1)
            
      print("Entering auditDF for Target- ",target_table ," for LOB - ",lob)
      auditDF = addAuditColumnsRemoveDupsCdcSyncMultistream_clt_pt_perf(scdDF, curated_table, key,"PARTITION_VAL",  pval) 
      print("auditDF", auditDF.count())
      auditDF.persist()
          
      print("SurrogateKey - start:") 
      surrogateKeyDF = addSurrogateKey_Non_UDM(auditDF,curated_table) 
      print("surrogateKeyDF", surrogateKeyDF.count())

      #caching the result of the surrogate key function output
      surrogateKeyDF.persist()

      print("Entering defaultMerge for Target- ",target_table ," for LOB - ",lob)
      defaultMergeCdcMultistream_clt(surrogateKeyDF, curated_table, "PARTITION_VAL", pval)
    
      print("Entering orphanRecords_Clt for Target- ",target_table ," for LOB - ",lob)
      orphanRecordsQTOverlap_clt (hashDF,curated_table, "PARTITION_VAL",  pval,keycol) 
      print("  orphanRecords_Clt completed for Target- ",target_table ," for LOB - ",lob," partition_val - ",  pval, " \n")
      print("\n *** EC  END for Target- ",target_table ," for LOB - ",lob," partition_val - ",  pval, " \n")
      
      endtime = datetime.now()
      print(" NoteBook Execution Start Time# ", starttime)
      print(" NoteBook Execution End  Time# " ,endtime)
      print(" NoteBook Run Time# " ,endtime - starttime )  
    

  