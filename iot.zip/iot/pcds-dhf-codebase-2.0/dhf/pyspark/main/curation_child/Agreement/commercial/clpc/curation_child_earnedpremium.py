# Databricks notebook source
# MAGIC %run /Repos/dhfsid@nationwide.com/pcds-dhf-prod-2.0/dhf/pyspark/main/harmonization/_event_harmonizer_library

# COMMAND ----------

print("calling the python child notebook")

# COMMAND ----------

def build_earnedprem(microBatchDF, batchId, harmonizedDB, curateDB, target_table):
  print("\n entering earnedprem_curation_child \n")
  curate_table = curateDB +"."+target_table
  print("---curate table--",curate_table)
  #print("---curateDB----",curateDB)
  starttime = datetime.now()
 
  microBatchDF.createOrReplaceGlobalTempView("microBatchView")
  display(spark.sql("select * from global_temp.microBatchView"))

  curation_query = """ 
with v_fact_prem_tran as
  (select * from 
        (select *,row_number() over (partition by FACT_PREM_TRANS_KEY order by TRANS_PROC_DTS desc ) as rn 
         from
         (select ds_fact_prem_tran.*
            from  {curateDB}.ds_fact_prem_tran ds_fact_prem_tran       
            inner join global_temp.microBatchView mb  
              ON ds_fact_prem_tran.FACT_PREM_TRANS_KEY = mb.FACT_PREM_TRANS_KEY
              where ds_fact_prem_tran.etl_last_update_dts <= mb.etl_last_update_dts
          )
        ) where rn = 1),
Curation_Query as (   
WITH PREM_TRAN as (
SELECT 
       T.FACT_PREM_TRANS_KEY AS EARNED_TRANS_KEY,
       T.SOURCE_SYSTEM,
       T.POL_KEY,
       T.LOC_KEY,
       T.COVG_KEY,
       T.LINE_COVG_KEY,
       'D' as REC_TYPE_KEY,
       T.AGCY_KEY,
       T.AGNT_KEY,
       T.POL_LINE_KEY,
       T.GARAGE_SRVC_LOC_KEY,
       T.VEH_GARAGE_LOC_KEY,
       T.VEH_KEY,
       T.TFS_GARAGE_SRVC_LOC_KEY,
       T.LINE_MANUSCRIPT_KEY,
       T.VEH_MANUSCRIPT_KEY,
       T.BLDG_KEY,
       T.LINE_BLDG_KEY,
       T.LINE_LOC_KEY,
       T.BOP_CLASS_KEY,
       T.COV_EMP_KEY,
       T.JURS_KEY,
       T.WAIVER_SUBRO_KEY,
       T.CL_CD_KEY,
       T.CL_CD_BASIS_KEY,
       T.BI_KEY,
       T.PP_KEY,
       T.SPCL_CL_KEY,
       T.SPCL_CL_BI_KEY,
       T.OCC_CL_KEY,
       T.UL_POL_KEY,
       T.UL_COVG_KEY,
       T.EXPSR_KEY,
       T.FCLTV_REINS_KEY,
       T.STRUCT_KEY,
       T.RESD_KEY,
       T.CVRBL_TYPE_CD,
       POL.POL_NO,      
       T.TRANS_CD,
       T.TRANS_PROC_DTS,
       T.ORIG_TRANS_PROC_DTS,
       T.ORIG_END_EFF_DT,
       T.TRANS_EFF_DT,
       T.TRANS_EXP_DT,
       CASE WHEN T.RPT_PREM_AMT = 0 THEN 'N' ELSE 'Y' END AS RPT_FL,
       CASE WHEN T.AUDIT_PREM_AMT = 0 THEN 'N' ELSE 'Y' END AS AUDIT_FL,
       T.AUDITABLE_FL,
       T.WRITTEN_PREM_AMT,
       T.INFORCE_PREM_AMT,
       T.EST_PREM_AMT,
       T.RPT_PREM_AMT,
       T.AUDIT_PREM_AMT,      
       T.ACCTG_MO_ID,
       ' ' AS ACT_AUDIT_MTHD_CD,
       T.LOB_CD,
       T.ETL_ADD_DTS,
       T.ETL_LAST_UPDATE_DTS,
       'GWPC' AS  PARTITION_VAL     
FROM v_fact_prem_tran T

JOIN (SELECT DISTINCT POL_NO, POL_KEY FROM {harmonizedDB}.DS_POLICY_SKNY_R5 pol
WHERE UPPER(POL.POL_PERIOD_STATUS_CD) = 'BOUND') POL
ON t.POL_KEY = TRIM(pol.POL_KEY)

--JOIN {harmonizedDB}.DS_POLICY_SKNY_R5 pol
--ON T.POL_KEY = TRIM(pol.POL_KEY)
--AND pol.ETL_CURR_ROW_FL = 'Y'
--AND UPPER(POL.POL_PERIOD_STATUS_CD) = 'BOUND'
--AND POL.POL_KEY NOT LIKE '%QT%'
)

, ETL_NUMBERS as (
  select 0 as No 
  UNION 
  select 1 as No 
  UNION 
  select 2 as No 
  UNION 
  select 3 as No 
  UNION 
  select 4 as No 
  UNION 
  select 5 as No 
  UNION 
  select 6 as No 
  UNION 
  select 7 as No 
  UNION 
  select 8 as No 
  UNION 
  select 9 as No 
  UNION 
  select 10 as No 
  UNION 
  select 11 as No 
  UNION 
  select 12 as No 
  UNION
  select 13 as No 
  UNION
  select 14 as No 
  UNION
  select 15 as No 
  UNION
  select 16 as No 
  UNION
  select 17 as No 
  UNION
  select 18 as No 
  UNION
  select 19 as No 
  UNION
  select 20 as No 
)

, ETL_USER_EARNING as (select 'RULE_24THS' as EARNING_RULE ,
                              '31-JAN-15' as BEGIN_DT
                       )
, TMP_BP_EP_1 AS (
    SELECT 
         T.EARNED_TRANS_KEY, T.TRANS_CD, months_between(LAST_DAY(T.TRANS_EXP_DT), LAST_DAY(T.TRANS_EFF_DT)) AS EFF_PRD_CNT
            --DATEDIFF(MONTH,LAST_DAY(T.TRANS_EFF_DT), LAST_DAY(T.TRANS_EXP_DT)) AS EFF_PRD_CNT
    FROM PREM_TRAN T
   WHERE 	T.TRANS_EXP_DT > (SELECT to_date(BEGIN_DT, 'dd-MMM-y') FROM ETL_USER_EARNING)
    AND T.WRITTEN_PREM_AMT + T.EST_PREM_AMT + T.AUDIT_PREM_AMT  <> 0
    )
       
, TMP_BP_EP_2 as (
  SELECT 
         T.EARNED_TRANS_KEY,  DATEDIFF(TRANS_EXP_DT , TRANS_EFF_DT) AS WRITTEN_EXPSR_DAY_CNT,
         --(TRANS_EXP_DT - TRANS_EFF_DT) AS WRITTEN_EXPSR_DAY_CNT,
         --> Number of accounting periods in the transaction
         X.EFF_PRD_CNT,
         cast(EXTRACT(YEAR FROM ADD_MONTHS(TRANS_EFF_DT, N.NO))||SUBSTR('0' || EXTRACT(MONTH FROM ADD_MONTHS(TRANS_EFF_DT, N.NO)), -2) as int) AS EFF_PRD_ID,
         --> Accounting period sequence number (1 thru n accounting periods)
         N.NO + 1 AS SEQ_NO,
         ---> Calculating the base earn amount 
                 
     CASE WHEN EFF_PRD_CNT = 0 THEN 
            (WRITTEN_PREM_AMT/2) 
            ELSE 
             WRITTEN_PREM_AMT/(EFF_PRD_CNT*2) END as base_amt,
          
         CASE WHEN ACCTG_MO_ID > cast(EXTRACT(YEAR FROM ADD_MONTHS(TRANS_EFF_DT, N.NO))||SUBSTR('0' || EXTRACT(MONTH FROM ADD_MONTHS(TRANS_EFF_DT, N.NO)), -2) as int)
              THEN ACCTG_MO_ID
              ELSE cast(EXTRACT(YEAR FROM ADD_MONTHS(TRANS_EFF_DT, N.NO))||SUBSTR('0' || EXTRACT(MONTH FROM ADD_MONTHS(TRANS_EFF_DT, N.NO)), -2) as int)
         END AS EARNING_PRD_ID,
         SOURCE_SYSTEM,
         POL_KEY,
         LOC_KEY,
         COVG_KEY,
         LINE_COVG_KEY,
         REC_TYPE_KEY,
         AGCY_KEY,
         AGNT_KEY,
         POL_LINE_KEY,
         GARAGE_SRVC_LOC_KEY,
         VEH_GARAGE_LOC_KEY,
         VEH_KEY,
         TFS_GARAGE_SRVC_LOC_KEY,
         LINE_MANUSCRIPT_KEY,
         VEH_MANUSCRIPT_KEY,
         BLDG_KEY,
         LINE_BLDG_KEY,
         LINE_LOC_KEY,
         BOP_CLASS_KEY,
         COV_EMP_KEY,
         JURS_KEY,
         WAIVER_SUBRO_KEY,
         CL_CD_KEY,
         CL_CD_BASIS_KEY,
         BI_KEY,
         PP_KEY,
         SPCL_CL_KEY,
         SPCL_CL_BI_KEY,
         OCC_CL_KEY,
         UL_POL_KEY,
         UL_COVG_KEY,
         EXPSR_KEY,
         FCLTV_REINS_KEY,
         STRUCT_KEY,
         RESD_KEY,
         CVRBL_TYPE_CD,
         POL_NO,      
         T.TRANS_CD,
         TRANS_PROC_DTS,
         ORIG_TRANS_PROC_DTS,
         ORIG_END_EFF_DT,
         TRANS_EFF_DT,
         TRANS_EXP_DT,
         RPT_FL,
         AUDIT_FL,
         AUDITABLE_FL,
         WRITTEN_PREM_AMT,
         INFORCE_PREM_AMT,
         EST_PREM_AMT,
         RPT_PREM_AMT,
         AUDIT_PREM_AMT,      
         ACCTG_MO_ID,
         ACT_AUDIT_MTHD_CD,
         LOB_CD,
		 ETL_ADD_DTS,
         ETL_LAST_UPDATE_DTS,
         PARTITION_VAL
    FROM  TMP_BP_EP_1  X 
    JOIN PREM_TRAN T ON T.EARNED_TRANS_KEY = X.EARNED_TRANS_KEY 
    --> Project each non "audit" transaction for each month the transaction is effective or the accounting period for "audit" transactions
    JOIN ETL_NUMBERS N ON ((UPPER(X.TRANS_CD) <> 'AUDIT'  AND N.NO <= X.EFF_PRD_CNT)
                            OR
                           (UPPER(X.TRANS_CD) = 'AUDIT'  AND N.NO <= X.EFF_PRD_CNT)
                          )
    JOIN (select ACCT_MTH_ID from {harmonizedDB}.BUSINESS_CALENDAR Group by ACCT_MTH_ID) MO 
       ON MO.ACCT_MTH_ID = cast(EXTRACT(YEAR FROM ADD_MONTHS(TRANS_EFF_DT, N.NO))||SUBSTR('0' || EXTRACT(MONTH FROM ADD_MONTHS(TRANS_EFF_DT, N.NO)), -2) as int)
   -- WHERE T.TRANS_EXP_DT > (SELECT BEGIN_DT FROM ETL_USER_EARNING)
   where T.TRANS_EXP_DT   > (SELECT to_date(BEGIN_DT, 'dd-MMM-y') FROM ETL_USER_EARNING)
      AND ((UPPER(T.TRANS_CD) <> 'AUDIT' AND (T.WRITTEN_PREM_AMT + T.EST_PREM_AMT <> 0))   OR  (UPPER(T.TRANS_CD) = 'AUDIT') )
 )

 , T AS (
           SELECT 
               EARNED_TRANS_KEY,
               SOURCE_SYSTEM,
               POL_KEY,
               LOC_KEY,
               COVG_KEY,
               LINE_COVG_KEY,
               REC_TYPE_KEY,
               AGCY_KEY,
               AGNT_KEY,
               POL_LINE_KEY,
               GARAGE_SRVC_LOC_KEY,
               VEH_GARAGE_LOC_KEY,
               VEH_KEY,
               TFS_GARAGE_SRVC_LOC_KEY,
               LINE_MANUSCRIPT_KEY,
               VEH_MANUSCRIPT_KEY,
               BLDG_KEY,
               LINE_BLDG_KEY,
               LINE_LOC_KEY,
               BOP_CLASS_KEY,
               COV_EMP_KEY,
               JURS_KEY,
               WAIVER_SUBRO_KEY,
               CL_CD_KEY,
               CL_CD_BASIS_KEY,
               BI_KEY,
               PP_KEY,
               SPCL_CL_KEY,
               SPCL_CL_BI_KEY,
               OCC_CL_KEY,
               UL_POL_KEY,
               UL_COVG_KEY,
               EXPSR_KEY,
               FCLTV_REINS_KEY,
               STRUCT_KEY,
               RESD_KEY,
               CVRBL_TYPE_CD,
               POL_NO,      
               TRANS_CD,
               TRANS_PROC_DTS,
               ORIG_TRANS_PROC_DTS,
               ORIG_END_EFF_DT,
               TRANS_EFF_DT,
               TRANS_EXP_DT,
               RPT_FL,
               AUDIT_FL,
               AUDITABLE_FL,
               WRITTEN_PREM_AMT,
               INFORCE_PREM_AMT,
               EST_PREM_AMT,
               RPT_PREM_AMT,
               AUDIT_PREM_AMT,      
               ACCTG_MO_ID,
               ACT_AUDIT_MTHD_CD,
               LOB_CD,
               EARNING_PRD_ID,        
               EFF_PRD_ID ,           
               SEQ_NO,
               BASE_AMT,
               WRITTEN_EXPSR_DAY_CNT,
              CAST(CASE (select EARNING_RULE from ETL_USER_EARNING)  WHEN 'RULE_24THS' THEN                 
                       CASE WHEN T.EFF_PRD_CNT < 1 THEN 0.0 -- Premium is fully earned 
                            WHEN T.AUDIT_PREM_AMT + T.RPT_PREM_AMT = 0
                                  THEN (CASE T.SEQ_NO
                                                     WHEN 1 THEN ((T.EFF_PRD_CNT * 2) - 1) --> First
                                                     WHEN T.EFF_PRD_CNT + 1 THEN 0 --> Last
                                                     ELSE (T.EFF_PRD_CNT * 2) - (T.SEQ_NO * 2) + 1
                                          END) * cast( SUBSTR((T.base_amt::string), 1,   
                                                                 INSTR((T.base_amt::string),'.')+2
                                                               ) 
                                                   as decimal(18,2))
                           ELSE 0.00
                       END
              END AS DECIMAL(18,2)) as UNEARNED_PREM_AMT ,    
        ETL_ADD_DTS,
        ETL_LAST_UPDATE_DTS,
        PARTITION_VAL

      FROM TMP_BP_EP_2 T
  )
  
, DS_EARNED_PREM_TRAN AS (
    SELECT 
               EARNED_TRANS_KEY,
               SOURCE_SYSTEM,
               POL_KEY,
               LOC_KEY,
               COVG_KEY,
               LINE_COVG_KEY,
               REC_TYPE_KEY,
               AGCY_KEY,
               AGNT_KEY,
               POL_LINE_KEY,
               GARAGE_SRVC_LOC_KEY,
               VEH_GARAGE_LOC_KEY,
               VEH_KEY,
               TFS_GARAGE_SRVC_LOC_KEY,
               LINE_MANUSCRIPT_KEY,
               VEH_MANUSCRIPT_KEY,
               BLDG_KEY,
               LINE_BLDG_KEY,
               LINE_LOC_KEY,
               BOP_CLASS_KEY,
               COV_EMP_KEY,
               JURS_KEY,
               WAIVER_SUBRO_KEY,
               CL_CD_KEY,
               CL_CD_BASIS_KEY,
               BI_KEY,
               PP_KEY,
               SPCL_CL_KEY,
               SPCL_CL_BI_KEY,
               OCC_CL_KEY,
               UL_POL_KEY,
               UL_COVG_KEY,
               EXPSR_KEY,
               FCLTV_REINS_KEY,
               STRUCT_KEY,
               RESD_KEY,
               CVRBL_TYPE_CD,
               POL_NO,      
               TRANS_CD,
               TRANS_PROC_DTS,
               ORIG_TRANS_PROC_DTS,
               ORIG_END_EFF_DT,
               TRANS_EFF_DT,
               TRANS_EXP_DT,
               RPT_FL,
               AUDIT_FL,
               AUDITABLE_FL,
               WRITTEN_PREM_AMT,
               INFORCE_PREM_AMT,
               EST_PREM_AMT,
               RPT_PREM_AMT,
               AUDIT_PREM_AMT,      
               ACCTG_MO_ID,
               ACT_AUDIT_MTHD_CD,
               LOB_CD,
               EARNING_PRD_ID,
               EFF_PRD_ID, 
               SEQ_NO, 
               CAST((COALESCE(LAG(UNEARNED_PREM_AMT) OVER (PARTITION BY EARNED_TRANS_KEY ORDER BY SEQ_NO), WRITTEN_PREM_AMT)) - UNEARNED_PREM_AMT AS DECIMAL(18,2))  AS EARNED_PREM_AMT,
               CAST(UNEARNED_PREM_AMT AS DECIMAL(18,2)),     
               WRITTEN_EXPSR_DAY_CNT,
               ETL_ADD_DTS,
               ETL_LAST_UPDATE_DTS,
               PARTITION_VAL

      FROM T
  )
 
 SELECT 
    EARNED_TRANS_KEY 
   ,SOURCE_SYSTEM 
   ,POL_KEY 
   ,LOC_KEY 
   ,COVG_KEY 
   ,LINE_COVG_KEY 
   ,REC_TYPE_KEY 
   ,AGCY_KEY 
   ,AGNT_KEY 
   ,POL_LINE_KEY 
   ,GARAGE_SRVC_LOC_KEY 
   ,VEH_GARAGE_LOC_KEY 
   ,VEH_KEY 
   ,TFS_GARAGE_SRVC_LOC_KEY  
   ,LINE_MANUSCRIPT_KEY 
   ,VEH_MANUSCRIPT_KEY 
   ,BLDG_KEY 
   ,LINE_BLDG_KEY 
   ,LINE_LOC_KEY 
   ,BOP_CLASS_KEY 
   ,COV_EMP_KEY 
   ,JURS_KEY 
   ,WAIVER_SUBRO_KEY 
   ,CL_CD_KEY 
   ,CL_CD_BASIS_KEY 
   ,BI_KEY 
   ,PP_KEY 
   ,SPCL_CL_KEY 
   ,SPCL_CL_BI_KEY 
   ,OCC_CL_KEY 
   ,UL_POL_KEY 
   ,UL_COVG_KEY 
   ,EXPSR_KEY 
   ,FCLTV_REINS_KEY 
   ,STRUCT_KEY 
   ,RESD_KEY 
   ,CVRBL_TYPE_CD 
   ,POL_NO 
   ,TRANS_CD 
   ,TRANS_PROC_DTS 
   ,ORIG_TRANS_PROC_DTS 
   ,ORIG_END_EFF_DT 
   ,TRANS_EFF_DT 
   ,TRANS_EXP_DT 
   ,EARNING_PRD_ID 
   ,EFF_PRD_ID 
   ,SEQ_NO 
   ,RPT_FL 
   ,AUDIT_FL 
   ,WRITTEN_PREM_AMT 
   ,INFORCE_PREM_AMT 
   ,EST_PREM_AMT 
   ,EARNED_PREM_AMT 
   ,UNEARNED_PREM_AMT 
   ,WRITTEN_EXPSR_DAY_CNT 
   ,ETL_ADD_DTS
   ,ETL_LAST_UPDATE_DTS
   ,LOB_CD 
   ,PARTITION_VAL
    FROM DS_EARNED_PREM_TRAN 
    WHERE SOURCE_SYSTEM = 'GWPC'
   )
select * from Curation_Query
"""
  curation_query = curation_query.replace("{harmonizedDB}",harmonizedDB).replace("{curateDB}", curateDB)
  print("curation_query after harmonizedDB AND curateDB replace: ", curation_query)
  queryDF = spark.sql(curation_query)
  queryDF.show(3)
 
  delta_table=DeltaTable.forName(spark, curate_table)
  delta_table.alias("events").merge(queryDF.alias("updates"),"events.EARNED_TRANS_KEY = updates.EARNED_TRANS_KEY  AND events.EFF_PRD_ID = updates.EFF_PRD_ID  and events.PARTITION_VAL = updates.PARTITION_VAL").whenNotMatchedInsertAll().whenMatchedUpdateAll().execute()
  
  print("END OF FLOW")
  endtime = datetime.now()
  print(" NoteBook Execution Start Time# ", starttime)
  print(" NoteBook Execution End  Time# " ,endtime)
  print(" NoteBook Run Time# " ,endtime - starttime )  
