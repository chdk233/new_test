# Databricks notebook source
from pyspark.sql.functions import *
from delta.tables import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %run ./teradata_configs

# COMMAND ----------

def get_update_keys(df, target, merge_keys):
  print('getting updateable keys')
  update_keys = ""
  for key in df.columns:
    if key not in ('ETL_ROW_EFF_DTS','SRC_SYS_CD',f'{target.upper()}_ID') and key not in merge_keys:
      update_keys = update_keys + key + ','
    
  return update_keys[:-1]

# COMMAND ----------

def removeDuplicatesMicrobatch_DHFGeneric(df, partitionKeys, orderbyCols):
  print("entering removeduplicates microbatch function \n")
  partition_cols=partitionKeys.split(",")
  orderyby_cols=orderbyCols.split(",")
  w = Window.partitionBy(*partition_cols).orderBy(*[desc(c) for c in orderyby_cols])
  firsRowDF = df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
  print("leaving removeduplicates microbatch function")
  return firsRowDF

# COMMAND ----------

def type1_defaultMergePartitionied_DHFGeneric(df, target, merge_key, update_key): 
  df = removeDuplicatesMicrobatch_DHFGeneric(df,merge_key, 'ETL_ROW_EFF_DTS')
  
  print("entering type1_defaultMergePartitionied_DHFGeneric")
  dt = DeltaTable.forName(spark, target)
  match_condition = (" AND ".join(list(map((lambda x: f"(events.{x.strip()}=updates.{x.strip()} OR (events.{x.strip()} is null AND updates.{x.strip()} is null))"),merge_key.split(",")))))
  print(match_condition)
  set_condition = ",".join(list(map((lambda x: f"{x.strip()}=updates.{x.strip()}"),update_key.split(","))))
  print(set_condition)
  sc = dict(subString.split("=") for subString in set_condition.split(","))
  print(sc)
  dt.alias('events').merge(df.alias('updates'), match_condition).whenMatchedUpdate(set = sc).whenNotMatchedInsertAll().execute()

# COMMAND ----------

def teradata_table_load(sql):
  table1 = spark.read.format("jdbc")\
  .option("driver", driver)\
  .option("url", url)\
  .option("dbtable", '({sql}) as src'.format(sql=sql))\
  .option("user", user1)\
  .option("password", password1)\
  .load()
  return table1

# COMMAND ----------

def sh_incremental_df(df,target):
  print("entering incremental date chain function")
  df.createOrReplaceGlobalTempView("micro_batch")

  microbatch_df=spark.sql(f"""select
      cast(row_number() over(order by NULL) +1+ coalesce((select max(SMARTHOME_DEVICE_STATUS_ID) from {target}),0) as BIGINT) as SMARTHOME_DEVICE_STATUS_ID,
      m.deviceId as DEVICE_ID	,
      m.policyNumber as POLICY_KEY,
      coalesce(XXHASH64(cast(m.policyNumber as string)), XXHASH64('NOKEY')) as POLICY_KEY_ID,
      policyState as PLCY_RT_ST_CD,	
      cast(enrollmentEffectiveDate as date) as ENRLMNT_EFF_DT	,
      deviceDiscountType as DEVICE_DSCNT_TP,
      cast(devc_fst_dt as date) as DEVC_FIRST_STTS_DT,
      cast(deviceStatusDate as date) as DEVC_LST_STTS_DT,
      case when checkOutType='PAID' and vendorName='Notion' then m.dataCollectionId 
          end PARTNER_MEMBER_ID	,
      case when checkOutType='FREE' and vendorName='Notion'then m.dataCollectionId
          when  vendorName='LeakBot'then m.dataCollectionId 
          end DATA_COLLECTION_ID,
    --   cast(active_dt as date) as ACTVTN_DT,
      case when deviceStatus='ACTIVE' then cast(deviceStatusDate as date) end ACTVTN_DT,
      case when deviceStatus='ACTIVE' then '1' else '0' end ACTV_STTS_IN,
      deviceStatus as DEVC_STTS_CD,
      deviceCategory as DEVC_CATEGORY,
      policyType as PLCY_DESC_TYPE,
      topic as CONTEXT_TOPIC,
      id as CONTEXT_ID,
      source as CONTEXT_SOURCE,
      time as CONTEXT_TIME,
      type as CONTEXT_TYPE,
      enrollmentId as PRGRM_ENROLLMENT_ID,
      vendorName as SRC_SYS_CD,
      db_load_date as LOAD_DT,
      db_load_time as LOAD_HR_TS,
      current_timestamp() as ETL_ROW_EFF_DTS,
      current_timestamp() as ETL_LAST_UPDT_DTS
   from global_temp.micro_batch m 
    left join (select deviceId,policyNumber,dataCollectionId,min(deviceStatusDate) as devc_fst_dt from global_temp.micro_batch group by 
                 deviceId,policyNumber,dataCollectionId) mb_date 
    on  m.deviceId=mb_date.deviceId and m.policyNumber=mb_date.policyNumber and m.dataCollectionId=mb_date.dataCollectionId where m.deviceid is not null
    """)
  print("leaving incremental date chain function")
  return microbatch_df
  



# COMMAND ----------

def transformed_df(target):
  print("entering transform function")
  final_df = spark.sql(f"""
                    select 
                    A.SMARTHOME_DEVICE_STATUS_ID,
                    A.DEVICE_ID	,
                    A.POLICY_KEY,
                    A.POLICY_KEY_ID,
                    A.PLCY_RT_ST_CD,	
                    A.ENRLMNT_EFF_DT	,
                    A.DEVICE_DSCNT_TP	,
                    case when DEVC_FIRST_STTS_DT_hist is not null and DEVC_FIRST_STTS_DT_hist<=DEVC_FIRST_STTS_DT then DEVC_FIRST_STTS_DT_hist 
                                else DEVC_FIRST_STTS_DT
                        end DEVC_FIRST_STTS_DT,
                    A.DEVC_LST_STTS_DT,
                    A.PARTNER_MEMBER_ID	,
                    A.DATA_COLLECTION_ID,
                    A.ACTVTN_DT,
                    A.ACTV_STTS_IN,
                    A.DEVC_STTS_CD ,
                    cast(P.Live_status as bigint) as LIVE_STATUS_IN,
                    cast(P.load_dt as date) as LIVE_LOAD_DT,
                    A.DEVC_CATEGORY,
                    A.PLCY_DESC_TYPE,
                    A.CONTEXT_TOPIC,
                    A.CONTEXT_ID,
                    A.CONTEXT_SOURCE,
                    A.CONTEXT_TIME,
                    A.CONTEXT_TYPE,
                    A.PRGRM_ENROLLMENT_ID,
                    A.SRC_SYS_CD,
                    A.LOAD_DT,
                    A.LOAD_HR_TS,
                    A.ETL_ROW_EFF_DTS,
                    A.ETL_LAST_UPDT_DTS,
                    B.quote_user_id as QT_USER_ID,
                    B.quote_source_idfr as QT_SRC_IDFR,
                    B.policy_type_001 as PLCY_TP,
                    C.PDCR_OFFC_NAME_L102 as PRDCR_OFFC,
                    C.PDCR_TYPE_L102 as PRDCR_TP,
                    D.POL_Term_01 as PLCY_TERM,
                    E.PROT_DEV_DISC_AMT_11 as PROTCTV_DEVC_DISC_AMT,
                    E.HOME_CAR_DISC_AMT_11 as HOME_CAR_DISC_AMT,
                    F.AcquisitionChannel_Ds as ACQUISITION_CHANNEL_CD,
                    F.ServiceChannel_ds as SERVICING_CHANNEL_CD,
                    F.NewRenewal_Flag as MEMBER_TYPE
                    from
                    global_temp.sh_enrollment A
                    left join (select a.*,b.last_active_date from (Select DEVICE_ID,POLICY_KEY,PARTNER_MEMBER_ID,DATA_COLLECTION_ID,min(DEVC_FIRST_STTS_DT) as  DEVC_FIRST_STTS_DT_hist from {target} group by DEVICE_ID,POLICY_KEY,PARTNER_MEMBER_ID,DATA_COLLECTION_ID)a
                              left join (Select 
                              DEVICE_ID,POLICY_KEY,PARTNER_MEMBER_ID,DATA_COLLECTION_ID,max(DEVC_LST_STTS_DT) as last_active_date from {target} where ACTV_STTS_IN='ACTIVE' group by DEVICE_ID,POLICY_KEY,PARTNER_MEMBER_ID,DATA_COLLECTION_ID )b 
                              on a.DEVICE_ID=b.DEVICE_ID and a.POLICY_KEY=b.POLICY_KEY and (a.PARTNER_MEMBER_ID=b.PARTNER_MEMBER_ID or (a.PARTNER_MEMBER_ID is null and b.PARTNER_MEMBER_ID is null)) and (a.DATA_COLLECTION_ID=b.DATA_COLLECTION_ID or (a.DATA_COLLECTION_ID is null and b.DATA_COLLECTION_ID is null))) N 
                        on A.DEVICE_ID=N.DEVICE_ID AND A.POLICY_KEY=N.POLICY_KEY and (A.PARTNER_MEMBER_ID=N.PARTNER_MEMBER_ID or (A.PARTNER_MEMBER_ID is null and N.PARTNER_MEMBER_ID is null)) and (A.DATA_COLLECTION_ID=N.DATA_COLLECTION_ID or (A.DATA_COLLECTION_ID is null and N.DATA_COLLECTION_ID is null))
                    left join global_temp.ntn_sh_systems_live_weekly_temp P on A.DATA_COLLECTION_ID=P.partner_member_id or A.PARTNER_MEMBER_ID=P.partner_member_id
                    left join global_temp.PROP_NFCCNTL1_CTRL_SEG_REC_1 B on trim(A.POLICY_KEY) = trim(B.QUOTE_POL_NUM)
                    left join global_temp.PROP_PRDCR_PRODUCER_SEG C on trim(A.POLICY_KEY) = trim(C.QUOTE_POL_NUM)
                    left join global_temp.PROP_NFCBASIC_BASIC_INFO_REC D on trim(A.POLICY_KEY) = trim(D.QUOTE_POL_NUM)
                    left join global_temp.PROP_NFCLOCO3_LOCATION_2_COV E on trim(A.POLICY_KEY) = trim(E.QUOTE_POL_NUM)
                    left join global_temp.E_PRODUCT_VW F on trim(A.POLICY_KEY) = trim(F.fullpolicy_nb)
                    """)
  print("leaving transform function")
  return final_df

# COMMAND ----------

def merge_sh_devc_sts(microBatchDF, batchId, harmonizedDB, curatedDB, target):
  print("entering merge function")
  merge_keys = "DEVICE_ID,POLICY_KEY,POLICY_KEY_ID,PLCY_RT_ST_CD,ENRLMNT_EFF_DT,DEVICE_DSCNT_TP,DEVC_FIRST_STTS_DT,DEVC_LST_STTS_DT,PARTNER_MEMBER_ID,DATA_COLLECTION_ID,ACTVTN_DT,ACTV_STTS_IN,DEVC_STTS_CD,LIVE_STATUS_IN,LIVE_LOAD_DT,SRC_SYS_CD,QT_SRC_IDFR,PLCY_TP,PRDCR_OFFC,PRDCR_TP,PLCY_TERM,PROTCTV_DEVC_DISC_AMT,HOME_CAR_DISC_AMT,ACQUISITION_CHANNEL_CD,SERVICING_CHANNEL_CD,MEMBER_TYPE,DEVC_CATEGORY,PLCY_DESC_TYPE,CONTEXT_TOPIC,CONTEXT_ID,CONTEXT_SOURCE,CONTEXT_TIME,CONTEXT_TYPE,PRGRM_ENROLLMENT_ID"
  
  
  ntn_sh_systems_live_weekly = spark.sql(f"""
                  select partner_member_id,Live_status,load_dt
                  from (
                  select partner_member_id,Live_status,load_dt,
                  row_number() over (partition by partner_member_id,Live_status order by load_dt desc) as rownum
                  from dhf_iot_notion_raw_{environment}.systems_live
                  ) 
                  where rownum=1
                  """)
  
  sh_incremental_df(microBatchDF,f"{curatedDB}.{target}").createOrReplaceGlobalTempView("sh_enrollment")
  ntn_sh_systems_live_weekly.createOrReplaceGlobalTempView("ntn_sh_systems_live_weekly_temp")
  teradata_table_load(PROP_NFCCNTL1_CTRL_SEG_REC_1_sql).createOrReplaceGlobalTempView("PROP_NFCCNTL1_CTRL_SEG_REC_1")
  teradata_table_load(PROP_PRDCR_PRODUCER_SEG_sql).createOrReplaceGlobalTempView("PROP_PRDCR_PRODUCER_SEG")
  teradata_table_load(PROP_NFCBASIC_BASIC_INFO_REC_sql).createOrReplaceGlobalTempView("PROP_NFCBASIC_BASIC_INFO_REC")
  teradata_table_load(PROP_NFCLOCO3_LOCATION_2_COV_sql).createOrReplaceGlobalTempView("PROP_NFCLOCO3_LOCATION_2_COV")
  teradata_table_load(E_PRODUCT_VW_sql).createOrReplaceGlobalTempView("E_PRODUCT_VW")

  devc_sts_df=transformed_df(f"{curatedDB}.{target}")
  update_keys = get_update_keys(devc_sts_df, target, merge_keys)
  print(f" \n merge keys : {merge_keys} ")
  print(f" \n update keys : {update_keys} ")


  # return devc_sts_df
  type1_defaultMergePartitionied_DHFGeneric(devc_sts_df, f"{curatedDB}.{target}", merge_keys, update_keys)
