# Databricks notebook source
print("calling the python child notebook 2")
spark.conf.set('spark.sql.legacy.timeParserPolicy','LEGACY')

# COMMAND ----------

def smartmiles_ims_wk_program_summary(harmonizedDB, curateDB):
  wk_program_summary_df=spark.sql(f"""SELECT
td.enrld_vin_nb
,cast(ods.prgrm_instc_id as BIGINT) as prgrm_instc_id
,ods.data_clctn_id
,'tp' AS pe_cd
,td.PE_STRT_LCL_TS as pe_strt_ts
,td.PE_END_LCL_TS as pe_end_ts
,1 as trip_ct
,td.mile_ct
,td.km_ct
,td.fast_aclrtn_ct
,td.hard_brke_ct
--,td.drvng_sc_ct
,CASE WHEN ods.plcy_st_cd = 'CA' THEN 0 ELSE td.drvng_sc_ct END AS drvng_sc_ct
--,td.idle_sc_ct
,CASE WHEN ods.plcy_st_cd = 'CA' THEN 0 ELSE td.idle_sc_ct END AS idle_sc_ct
,td.night_time_drvng_sc_ct
--,td.idle_time_ratio
,CASE WHEN ods.plcy_st_cd = 'CA' THEN '0' ELSE td.idle_time_ratio END AS idle_time_ratio
,td.trip_sc_json_tt
,td.src_sys_cd
,coalesce(ods.POLICY_KEY, 'NOKEY') as POLICY_KEY
,coalesce(ods.POLICY_KEY_ID, xxhash64('NOKEY')) as POLICY_KEY_ID
FROM {curateDB}.trip_detail td
INNER JOIN
(
	SELECT enrld_vin_nb
	FROM  {trip_detail_micro_batch}
    where trim(src_sys_cd) IN {sm_ims_src_cd}
	GROUP BY enrld_vin_nb
) wtd
ON trim(td.enrld_vin_nb) = trim(wtd.enrld_vin_nb)
INNER JOIN (select * from {harmonizedDB.replace('curated','harmonized')}.integrated_enrollment where CRNT_ENRLMNT_FLG = 'Y' and ENRLMNT_STTS = 'Active') ods
on trim(td.enrld_vin_nb) = trim(ods.VIN_NB) and trim(td.src_sys_cd) IN {sm_ims_src_cd} and td.load_dt>='{date_filter_18_mo_ago}'
WHERE td.PE_STRT_LCL_TS >= ods.ENRLMNT_STRT_DT
AND td.PE_STRT_LCL_TS < ods.ENRLMNT_END_DT
--AND ods.ENRLMNT_STRT_DT >= '{date_filter_18_mo_ago}'
""")

  return wk_program_summary_df


# COMMAND ----------


def smartmiles_ims_wk_program_summary_cal(harmonizedDB, curateDB):
  smartmiles_ims_wk_program_summary(harmonizedDB, curateDB).createOrReplaceTempView("smartmiles_ims_wk_program_summary")
  wk_program_summary_cal_df=spark.sql(f"""select * from smartmiles_ims_wk_program_summary union all
SELECT
enrld_vin_nb
,prgrm_instc_id
,data_clctn_id
,'d' AS pe_cd
,CAST(CONCAT(SUBSTR(pe_strt_ts,0,10),' 00:00:00') AS TIMESTAMP) AS pe_strt_ts
,CAST(CONCAT(SUBSTR(pe_strt_ts,0,10),' 23:59:59') AS TIMESTAMP) AS pe_end_ts
,SUM(trip_ct) AS trip_ct
,SUM(mile_ct) AS mile_ct
,SUM(km_ct) AS km_ct
,SUM(fast_aclrtn_ct)AS fast_aclrtn_ct
,SUM(hard_brke_ct)  AS hard_brke_ct
,SUM(drvng_sc_ct) AS drvng_sc_ct
,SUM(idle_sc_ct) AS idle_sc_ct
,SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct
,IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS idle_time_ratio
,' ' AS trip_sc_json_tt
,src_sys_cd
,POLICY_KEY
,POLICY_KEY_ID
FROM smartmiles_ims_wk_program_summary
GROUP BY CAST(CONCAT(SUBSTR(pe_strt_ts,0,10),' 00:00:00') AS TIMESTAMP)
		,CAST(CONCAT(SUBSTR(pe_strt_ts,0,10),' 23:59:59') AS TIMESTAMP)
		,pe_cd
		,enrld_vin_nb
        ,prgrm_instc_id
        ,data_clctn_id
		,src_sys_cd
        ,POLICY_KEY
        ,POLICY_KEY_ID
UNION ALL

SELECT
enrld_vin_nb
,prgrm_instc_id
,data_clctn_id
,'w' as pe_cd
,CASE CAST(date_format(pe_strt_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(substr(pe_strt_ts,0,10),' 00:00:00') AS TIMESTAMP)
ELSE CAST(CONCAT(date_sub(substr(pe_strt_ts,0,10),CAST(date_format(pe_strt_ts,'u') as int)),' 00:00:00') AS TIMESTAMP) END AS period_start_ts_Week
,CASE CAST(date_format(pe_strt_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(date_add(substr(pe_strt_ts,0,10),6),' 23:59:59.0') AS TIMESTAMP)
ELSE CAST(CONCAT(date_add(substr(pe_strt_ts,0,10),6-CAST(date_format(pe_strt_ts,'u') as int)),' 23:59:59') AS TIMESTAMP) END AS period_end_ts_Week
,SUM(trip_ct) AS trip_ct
,SUM(mile_ct) AS mile_ct
,SUM(km_ct) AS km_ct
,SUM(fast_aclrtn_ct)AS fast_aclrtn_ct
,SUM(hard_brke_ct)  AS hard_brke_ct
,SUM(drvng_sc_ct) AS drvng_sc_ct
,SUM(idle_sc_ct) AS idle_sc_ct
,SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct
,IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS idle_time_ratio
,' ' AS trip_sc_json_tt
,src_sys_cd
,POLICY_KEY
,POLICY_KEY_ID
FROM smartmiles_ims_wk_program_summary
GROUP BY CASE CAST(date_format(pe_strt_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(substr(pe_strt_ts,0,10),' 00:00:00') AS TIMESTAMP)
ELSE CAST(CONCAT(date_sub(substr(pe_strt_ts,0,10),CAST(date_format(pe_strt_ts,'u') as int)),' 00:00:00') AS TIMESTAMP)  END
,CASE CAST(date_format(pe_strt_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(date_add(substr(pe_strt_ts,0,10),6),' 23:59:59.0') AS TIMESTAMP)
ELSE CAST(CONCAT(date_add(substr(pe_strt_ts,0,10),6-CAST(date_format(pe_strt_ts,'u') as int)),' 23:59:59') AS TIMESTAMP) END
,pe_cd
,enrld_vin_nb
,prgrm_instc_id
,data_clctn_id
,src_sys_cd
,POLICY_KEY
,POLICY_KEY_ID

UNION ALL

SELECT
enrld_vin_nb
,prgrm_instc_id
,data_clctn_id
,'m' AS  pe_cd
,CAST(CONCAT(SUBSTR(pe_strt_ts,0,7),'-01 00:00:00') AS TIMESTAMP) AS pe_strt_ts
,CAST(CONCAT(LAST_DAY(pe_strt_ts),' 23:59:59') AS TIMESTAMP) AS pe_end_ts
,SUM(trip_ct) AS trip_ct
,SUM(mile_ct) AS mile_ct
,SUM(km_ct) AS km_ct
,SUM(fast_aclrtn_ct)AS fast_aclrtn_ct
,SUM(hard_brke_ct)  AS hard_brke_ct
,SUM(drvng_sc_ct) AS drvng_sc_ct
,SUM(idle_sc_ct) AS idle_sc_ct
,SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct
,IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS  idle_time_ratio
,' '  AS trip_sc_json_tt
,src_sys_cd
,POLICY_KEY
,POLICY_KEY_ID
FROM smartmiles_ims_wk_program_summary
GROUP BY CAST(CONCAT(SUBSTR(pe_strt_ts,0,7),'-01 00:00:00') AS TIMESTAMP)
         ,CAST(CONCAT(LAST_DAY(pe_strt_ts),' 23:59:59') AS TIMESTAMP)
         ,pe_cd
         ,enrld_vin_nb
         ,prgrm_instc_id,data_clctn_id
         ,src_sys_cd
         ,POLICY_KEY
         ,POLICY_KEY_ID

UNION ALL

SELECT
enrld_vin_nb
,prgrm_instc_id
,data_clctn_id
,'t' AS  pe_cd
,CAST('1970-01-01 00:00:00.0' AS TIMESTAMP) AS pe_strt_ts
,CAST('2999-12-31 00:00:00.0' AS TIMESTAMP) AS pe_end_ts
,SUM(trip_ct) AS trip_ct
,SUM(mile_ct) AS mile_ct
,SUM(km_ct) AS km_ct
,SUM(fast_aclrtn_ct)AS fast_aclrtn_ct
,SUM(hard_brke_ct)  AS hard_brke_ct
,SUM(drvng_sc_ct) AS drvng_sc_ct
,SUM(idle_sc_ct) AS idle_sc_ct
,SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct
,IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS  idle_time_ratio
,' '  AS trip_sc_json_tt
,src_sys_cd
,POLICY_KEY
,POLICY_KEY_ID
FROM smartmiles_ims_wk_program_summary
GROUP BY CAST('1970-01-01 00:00:00.0' AS TIMESTAMP)
	    ,CAST('2999-12-31 00:00:00.0' AS TIMESTAMP)
	    ,pe_cd
	    ,enrld_vin_nb
        ,prgrm_instc_id,data_clctn_id
	    ,src_sys_cd
        ,POLICY_KEY
        ,POLICY_KEY_ID
""")
  wk_program_summary_cal_df.createOrReplaceTempView("smartmiles_ims_wk_program_summary_cal")
  return spark.sql(f"""select a.*,'new' as type_of_data from smartmiles_ims_wk_program_summary_cal a union all SELECT
  ps.enrld_vin_nb
  ,ps.prgrm_instc_id
  ,ps.data_clctn_id
  ,ps.pe_cd
  ,ps.pe_strt_ts
  ,ps.pe_end_ts
  ,ps.trip_ct
  ,ps.mile_ct
  ,ps.km_ct
  ,ps.fast_aclrtn_ct
  ,ps.hard_brke_ct
  ,ps.drvng_sc_ct
  ,ps.idle_sc_ct
  ,ps.night_time_drvng_sc_ct
  ,ps.idle_time_ratio
  ,ps.trip_rprt_json_tt as trip_sc_json_tt
  ,ps.src_sys_cd
  ,coalesce(ps.POLICY_KEY, 'NOKEY') as POLICY_KEY
  ,coalesce(ps.POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
  ,'old' as type_of_data
FROM {curateDB}.program_summary ps
left outer join smartmiles_ims_wk_program_summary_cal  wps
on trim(ps.enrld_vin_nb) = trim(wps.enrld_vin_nb)
where wps.enrld_vin_nb is null
--and trim(ps.pe_cd) in ('w','tp','d')
and trim(ps.src_sys_cd) IN {sm_ims_src_cd}
and ps.data_clctn_id is not null
and ps.pe_strt_ts >= '{date_filter_2_wks_from_sun}'
""")

# COMMAND ----------

#Smartride
def smartride_wk_delta_data(source_cd,harmonizedDB, curateDB):
  wk_trip_details_piid_df=spark.sql(f"""SELECT
enrld_vin_nb,
prgrm_instc_id,
data_clctn_id,
ENRLMNT_STRT_DT as prgrm_term_beg_dt,
ENRLMNT_END_DT as prgrm_term_end_dt,
plcy_st_cd,
src_sys_cd
,POLICY_KEY
,POLICY_KEY_ID
from (
    select
    wtd.enrld_vin_nb,
    cast(prgrm_instc_id as BIGINT) prgrm_instc_id,
    data_clctn_id,
    ENRLMNT_STRT_DT,
    ENRLMNT_END_DT,
    ROW_NUMBER() over (partition by wtd.enrld_vin_nb order by ENRLMNT_STRT_DT desc) as row_nb,
    plcy_st_cd
    ,wtd.src_sys_cd
    ,coalesce(ods.POLICY_KEY, 'NOKEY') as POLICY_KEY
    ,coalesce(ods.POLICY_KEY_ID, xxhash64('NOKEY')) as POLICY_KEY_ID
    from (select * from {harmonizedDB.replace('curated','harmonized')}.integrated_enrollment where CRNT_ENRLMNT_FLG = 'Y' and ENRLMNT_STTS = 'Active') ods
    join (select * from {trip_detail_micro_batch} where src_sys_cd in {source_cd}) wtd
    on trim(wtd.enrld_vin_nb) = trim(ods.vin_nb)
    where ENRLMNT_STRT_DT >= '{date_filter_18_mo_ago}'
    group by
    wtd.enrld_vin_nb,
    prgrm_instc_id,
    data_clctn_id,
    --enrlmnt_dt,
    ENRLMNT_STRT_DT,
    ENRLMNT_END_DT,
    plcy_st_cd,
    wtd.src_sys_cd,
    ods.POLICY_KEY,
    ods.POLICY_KEY_ID
    ) query
where row_nb = 1""")
  wk_trip_details_piid_df.write.format("delta").mode("overwrite").saveAsTable(f"{curateDB}.wk_program_summary")
  spark.read.table(f"{curateDB}.wk_program_summary").createOrReplaceTempView("smartride_wk_trip_details_piid")
#   wk_trip_details_piid_df.createOrReplaceTempView("smartride_wk_trip_details_piid")
  wk_delta_data_df=spark.sql(f"""SELECT wk.enrld_vin_nb,
CAST(wk.prgrm_instc_id AS BIGINT) AS prgrm_instc_id
,data_clctn_id
,PE_STRT_LCL_TS as pe_strt_ts
,PE_END_LCL_TS as pe_end_ts
,1 as trip_ct
,mile_ct AS mile_ct
,km_ct As km_ct
,night_time_drvng_sc_ct AS night_time_drvng_sc_ct
,fast_aclrtn_ct AS fast_aclrtn_ct
,hard_brke_ct AS hard_brke_ct
--,idle_sc_ct
--,drvng_sc_ct
--,IDLE_TIME_RATIO
,CASE WHEN wk.plcy_st_cd = 'CA' THEN 0 ELSE idle_sc_ct END AS idle_sc_ct
,CASE WHEN wk.plcy_st_cd = 'CA' THEN 0 ELSE drvng_sc_ct END AS drvng_sc_ct
,CASE WHEN wk.plcy_st_cd = 'CA' THEN 0 ELSE IDLE_TIME_RATIO END AS IDLE_TIME_RATIO
--,TRIP_NB
,CAST('tp' AS VARCHAR(20)) as PERIOD_TYPE_trip
,CAST('d' AS VARCHAR(20)) AS PERIOD_TYPE_day
,CAST(CONCAT(substr(PE_STRT_LCL_TS,0,10),' 00:00:00') AS TIMESTAMP) AS PERIODSTART_TS_day
,CAST(CONCAT(substr(PE_STRT_LCL_TS,0,10),' 23:59:59') AS TIMESTAMP) AS PERIODEND_TS_day
,CAST('w' AS VARCHAR(20)) AS PERIOD_TYPE_week
,CASE CAST(date_format(PE_STRT_LCL_TS,'u') as int) WHEN 7 THEN CAST(CONCAT(substr(PE_STRT_LCL_TS,0,10),' 00:00:00') AS TIMESTAMP) 
ELSE CAST(CONCAT(date_sub(substr(PE_STRT_LCL_TS,0,10),CAST(date_format(PE_STRT_LCL_TS,'u') as int)),' 00:00:00') AS TIMESTAMP) END AS PERIODSTART_TS_week
,CASE CAST(date_format(PE_STRT_LCL_TS,'u') as int) WHEN 7 THEN CAST(CONCAT(date_add(substr(PE_STRT_LCL_TS,0,10),6),' 23:59:59.0') AS TIMESTAMP) 
ELSE CAST(CONCAT(date_add(substr(PE_STRT_LCL_TS,0,10),6-CAST(date_format(PE_STRT_LCL_TS,'u') as int)),' 23:59:59') AS TIMESTAMP) END AS PERIODEND_TS_week             
,CAST('m' AS VARCHAR(20)) AS PERIOD_TYPE_month
,CAST(CONCAT(substr(PE_STRT_LCL_TS,0,7),'-01 00:00:00') AS TIMESTAMP) AS PERIODSTART_TS_month
,CAST(CONCAT(LAST_DAY(PE_STRT_LCL_TS),' 23:59:59') AS TIMESTAMP) AS PERIODEND_TS_month
,CAST('t' AS VARCHAR(20)) AS PERIOD_TYPE_total
,CAST('1970-01-01 00:00:00.0' as TIMESTAMP)AS PERIODSTART_TS_total
,CAST('2999-12-31 00:00:00.0' as TIMESTAMP)AS PERIODEND_TS_total
,trip_sc_json_tt,
wk.src_sys_cd
,wk.POLICY_KEY
,wk.POLICY_KEY_ID
FROM smartride_wk_trip_details_piid  wk
INNER JOIN {curateDB}.trip_detail td
on 
trim(td.enrld_vin_nb) = trim(wk.enrld_vin_nb) and td.load_dt>='{date_filter_18_mo_ago}' and trim(td.src_sys_cd) in {source_cd} 
where td.PE_STRT_LCL_TS between wk.prgrm_term_beg_dt and wk.prgrm_term_end_dt 
--and td.batch >= '{batch_filter_18_mo_ago}'
""")
  return wk_delta_data_df

# COMMAND ----------

def smartride_wk_sre_summary_delta(source_cd,harmonizedDB, curateDB):
  smartride_wk_delta_data(source_cd,harmonizedDB, curateDB).createOrReplaceTempView("smartride_wk_delta_data")
  wk_sre_summary_delta_df=spark.sql(f"""Select enrld_vin_nb, prgrm_instc_id , data_clctn_id, pe_strt_ts ,pe_end_ts, trip_ct ,mile_ct ,km_ct ,night_time_drvng_sc_ct ,fast_aclrtn_ct ,hard_brke_ct ,idle_sc_ct ,drvng_sc_ct ,idle_time_ratio ,trip_sc_json_tt ,pe_cd,src_sys_cd ,POLICY_KEY,POLICY_KEY_ID
from (
SELECT enrld_vin_nb,prgrm_instc_id, data_clctn_id, pe_strt_ts AS pe_strt_ts, pe_end_ts AS pe_end_ts, trip_ct, mile_ct, km_ct, CAST(night_time_drvng_sc_ct AS INT) AS night_time_drvng_sc_ct, CAST(fast_aclrtn_ct AS INT) AS fast_aclrtn_ct,CAST(hard_brke_ct AS INT) AS hard_brke_ct, CAST(idle_sc_ct AS INT) AS idle_sc_ct,CAST(drvng_sc_ct AS INT) AS drvng_sc_ct, CAST(idle_time_ratio AS DOUBLE) AS idle_time_ratio ,trip_sc_json_tt ,	period_type_trip AS  pe_cd,src_sys_cd ,POLICY_KEY,POLICY_KEY_ID from smartride_wk_delta_data 
UNION ALL 
SELECT enrld_vin_nb,prgrm_instc_id, data_clctn_id,periodstart_ts_day AS pe_strt_ts, periodend_ts_day AS pe_end_ts, SUM(trip_ct)AS trip_ct, SUM(mile_ct) AS mile_ct, SUM(km_ct) AS km_ct, SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct, SUM(fast_aclrtn_ct)AS fast_aclrtn_ct ,SUM(hard_brke_ct)  AS hard_brke_ct,		SUM(idle_sc_ct) AS idle_sc_ct,SUM(drvng_sc_ct) AS drvng_sc_ct, IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS  idle_time_ratio , CAST(' ' AS VARCHAR(32768))  AS trip_sc_json_tt,period_type_day AS  pe_cd,src_sys_cd,POLICY_KEY,POLICY_KEY_ID from smartride_wk_delta_data GROUP	BY  enrld_vin_nb,prgrm_instc_id, data_clctn_id,period_type_day,periodstart_ts_day,periodend_ts_day,src_sys_cd,POLICY_KEY,POLICY_KEY_ID 
UNION ALL 
SELECT enrld_vin_nb,prgrm_instc_id, data_clctn_id,periodstart_ts_week AS pe_strt_ts, periodend_ts_week AS pe_end_ts, SUM(trip_ct)AS trip_ct ,SUM(mile_ct) AS mile_ct, SUM(km_ct) AS km_ct, SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct, SUM(fast_aclrtn_ct)AS fast_aclrtn_ct,SUM(hard_brke_ct)  AS hard_brke_ct , SUM(idle_sc_ct) AS idle_sc_ct,SUM(drvng_sc_ct) AS drvng_sc_ct, IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS  idle_time_ratio , CAST(' ' AS VARCHAR(32768))  AS trip_sc_json_tt,period_type_week AS  pe_cd,src_sys_cd,POLICY_KEY,POLICY_KEY_ID from smartride_wk_delta_data GROUP	BY enrld_vin_nb, prgrm_instc_id, data_clctn_id,period_type_week,periodstart_ts_week,periodend_ts_week ,src_sys_cd,POLICY_KEY,POLICY_KEY_ID
UNION ALL 
SELECT enrld_vin_nb,prgrm_instc_id,data_clctn_id,periodstart_ts_month AS pe_strt_ts, periodend_ts_month AS pe_end_ts, SUM(trip_ct)AS trip_ct, SUM(mile_ct) AS mile_ct, SUM(km_ct) AS km_ct, SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct, SUM(fast_aclrtn_ct)AS fast_aclrtn_ct ,SUM(hard_brke_ct)  AS hard_brke_ct, SUM(idle_sc_ct) AS idle_sc_ct,SUM(drvng_sc_ct) AS drvng_sc_ct, IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS  idle_time_ratio , CAST(' ' AS VARCHAR(32768))  AS trip_sc_json_tt ,period_type_month AS  pe_cd,src_sys_cd,POLICY_KEY,POLICY_KEY_ID from smartride_wk_delta_data GROUP	BY  enrld_vin_nb,prgrm_instc_id,data_clctn_id,period_type_month,periodstart_ts_month,periodend_ts_month,src_sys_cd ,POLICY_KEY,POLICY_KEY_ID
UNION ALL 
SELECT enrld_vin_nb,prgrm_instc_id,data_clctn_id,periodstart_ts_total AS pe_strt_ts, periodend_ts_total AS pe_end_ts, SUM(trip_ct)AS trip_ct, SUM(mile_ct) AS mile_ct, SUM(km_ct) AS km_ct, SUM(night_time_drvng_sc_ct) AS night_time_drvng_sc_ct,SUM(fast_aclrtn_ct)AS fast_aclrtn_ct,SUM(hard_brke_ct)  AS hard_brke_ct, SUM(idle_sc_ct) AS idle_sc_ct,SUM(drvng_sc_ct) AS drvng_sc_ct, IF(SUM(drvng_sc_ct) = 0,0,SUM(idle_sc_ct)/SUM(drvng_sc_ct)) AS  idle_time_ratio, CAST(' ' AS VARCHAR(32768))  AS trip_sc_json_tt,period_type_total AS  pe_cd,src_sys_cd ,POLICY_KEY,POLICY_KEY_ID from smartride_wk_delta_data GROUP BY enrld_vin_nb,prgrm_instc_id,data_clctn_id,period_type_total,periodstart_ts_total,periodend_ts_total,src_sys_cd,POLICY_KEY,POLICY_KEY_ID
) temp""")
  return wk_sre_summary_delta_df

# COMMAND ----------

def smartride_wk_hive_sre_summary(source_cd,harmonizedDB, curateDB):
  smartride_wk_sre_summary_delta(source_cd,harmonizedDB, curateDB).createOrReplaceTempView("smartride_wk_sre_summary_delta")
  wk_hive_sre_summary_df=spark.sql(f"""SELECT HSS.enrld_vin_nb,
HSS.prgrm_instc_id
,HSS.data_clctn_id
,HSS.pe_cd
,HSS.pe_strt_ts
,HSS.pe_end_ts
,HSS.trip_ct
,HSS.mile_ct
,HSS.km_ct
,HSS.night_time_drvng_sc_ct
,HSS.fast_aclrtn_ct
,HSS.hard_brke_ct
,HSS.idle_sc_ct
,HSS.drvng_sc_ct
,HSS.IDLE_TIME_RATIO
,HSS.trip_rprt_json_tt as trip_sc_json_tt 
--,'{source_cd}' as src_sys_cd 
,HSS.src_sys_cd as src_sys_cd ,'new' as type_of_data
,coalesce(HSS.POLICY_KEY, 'NOKEY') as POLICY_KEY
,coalesce(HSS.POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
FROM {curateDB}.program_summary HSS
LEFT OUTER JOIN  smartride_wk_sre_summary_delta WSSD
ON trim(WSSD.prgrm_instc_id) = trim(HSS.prgrm_instc_id)
WHERE trim(HSS.src_sys_cd) in {source_cd} 
AND WSSD.prgrm_instc_id IS NULL 
--AND trim(HSS.pe_cd) in ('w', 'd','tp')
AND HSS.pe_strt_ts >= '{date_filter_2_wks_from_sun}' --need to uncomment
union all
SELECT enrld_vin_nb,
CAST(prgrm_instc_id AS BIGINT) AS prgrm_instc_id
,CAST(data_clctn_id AS STRING) as data_clctn_id
,CAST(pe_cd AS VARCHAR(30)) AS pe_cd
,CAST(pe_strt_ts AS TIMESTAMP) AS pe_strt_ts
,CAST(pe_end_ts AS TIMESTAMP) AS pe_end_ts
,CAST(trip_ct AS INT) AS trip_ct
,CAST(mile_ct AS DECIMAL(35,15)) AS mile_ct
,CAST(km_ct AS DECIMAL(35,15)) AS km_ct
,CAST(night_time_drvng_sc_ct AS INT) AS night_time_drvng_sc_ct
,CAST(fast_aclrtn_ct AS INT) AS fast_aclrtn_ct
,CAST(hard_brke_ct AS INT ) AS hard_brke_ct
,CAST(idle_sc_ct as INT) as idle_sc_ct
,CAST(drvng_sc_ct as INT) as drvng_sc_ct
,CAST(IDLE_TIME_RATIO as DECIMAL(35,15)) as IDLE_TIME_RATIO,trip_sc_json_tt
,src_sys_cd,'new' as type_of_data
,coalesce(POLICY_KEY, 'NOKEY') as POLICY_KEY
,coalesce(POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID FROM smartride_wk_sre_summary_delta
--WHERE pe_cd in ('w', 'd','tp') AND
--pe_strt_ts >= '{date_filter_2_wks_from_sun}'; 
""")
  return wk_hive_sre_summary_df

# COMMAND ----------

def s3_file_delete(s3_client,s3_intermediate_bucket,s3_intermediate_prefix,hbase_delete_ld_dt_list):
  try:
    paginator = s3_client.get_paginator('list_objects_v2')
    for ld_dt in hbase_delete_ld_dt_list:
      for result in paginator.paginate(Bucket=s3_intermediate_bucket,Prefix=s3_intermediate_prefix+f"load_dt={ld_dt['load_dt']}/"):
        for file in result['Contents']:
          s3_client.delete_object(
          Bucket=s3_intermediate_bucket,
          Key=file['Key']
      )
          print(f"deleted {file['Key']}")
  except Exception as e:
    exception_type, exception_object, exception_traceback = sys.exc_info()
    print(f"Function s3_file_delete - error {str(exception_object)} occured at line number {exception_traceback.tb_lineno}.")
    raise Exception(e)
    
def athena_execution(aws_account_number,Query,athena_result_path):
  try:
    import time
    import boto3
    sts_client = boto3.client('sts',region_name='us-east-1',endpoint_url ='https://sts.us-east-1.amazonaws.com')
    response2 = sts_client.assume_role(RoleArn=f'arn:aws:iam::{aws_account_number}:role/pcds-databricks-common-access',RoleSessionName='myDhfsession')
    athena_client = boto3.client('athena',aws_access_key_id=response2.get('Credentials').get('AccessKeyId'),
                          aws_secret_access_key=response2.get('Credentials').get('SecretAccessKey'),
                          aws_session_token=response2.get('Credentials').get('SessionToken'),region_name='us-east-1')
    state = 'RUNNING'
    athena_response = athena_client.start_query_execution(
              QueryString =Query ,
              QueryExecutionContext = {'Database': 'telematics_work_db'},
              ResultConfiguration = {'OutputLocation': athena_result_path })
    while (state in ['RUNNING','QUEUED']):
      data = athena_client.get_query_execution(QueryExecutionId=athena_response['QueryExecutionId'])
      state = data['QueryExecution']['Status']['State']
      status = data['QueryExecution']['Status']
      if state == 'FAILED':
        print(f"{Query} load got failed with error {status}")
      elif state =='SUCCEEDED':
        print(f"athena load got succeeded.")
      else:
        time.sleep(5)
    return data['QueryExecution']['ResultConfiguration']['OutputLocation']
  except Exception as e:
    exception_type, exception_object, exception_traceback = sys.exc_info()
    print(f"Function athena_execution - error {str(exception_object)} occured at line number {exception_traceback.tb_lineno}.")
    raise Exception(e)

def s3_delete_files_process(aws_account_number,athena_result_path,hbase_athena_table,hbase_athena_table_location):
  try:
      import boto3
      sts_client = boto3.client('sts',region_name='us-east-1',endpoint_url ='https://sts.us-east-1.amazonaws.com')
      response2 = sts_client.assume_role(RoleArn=f'arn:aws:iam::{aws_account_number}:role/pcds-databricks-common-access',RoleSessionName='myDhfsession')
      s3_client = boto3.client('s3',aws_access_key_id=response2.get('Credentials').get('AccessKeyId'),
                              aws_secret_access_key=response2.get('Credentials').get('SecretAccessKey'),
                              aws_session_token=response2.get('Credentials').get('SessionToken'),region_name='us-east-1')
      athena_client = boto3.client('athena',aws_access_key_id=response2.get('Credentials').get('AccessKeyId'),
                          aws_secret_access_key=response2.get('Credentials').get('SecretAccessKey'),
                          aws_session_token=response2.get('Credentials').get('SessionToken'),region_name='us-east-1')
      ld_dt_Query=f"select distinct load_dt from {hbase_athena_table} where load_dt<(select date_add('day',0,cast(max(end_ts) as date)) from telematics_staging_db.program_summary_dsd_hbase_event)"
      s3_intermediate_bucket=hbase_athena_table_location.split('/')[2]
      s3_intermediate_prefix='warehouse/telematics_staging_db/program_summary_dsd_intmd/'
      hbase_ld_dt_file=athena_execution(aws_account_number,ld_dt_Query,athena_result_path)
      hbase_delete_ld_dt_list=spark.read.option('header',True).csv(hbase_ld_dt_file).collect()
      if len(hbase_delete_ld_dt_list)>0:
        drop_query=f"drop table {hbase_athena_table};"
        athena_execution(aws_account_number,drop_query,athena_result_path)
        s3_file_delete(s3_client,s3_intermediate_bucket,s3_intermediate_prefix,hbase_delete_ld_dt_list)
#         hbase_ld_dt_file=athena_execution(aws_account_number,ld_dt_Query,athena_result_path)
        ddl_query=f"CREATE external TABLE {hbase_athena_table} (   program_summary_id bigint,   pe_cd string,   prgrm_instc_id bigint,   data_clctn_id string,   enrld_vin_nb string,   pe_strt_ts timestamp,   pe_end_ts timestamp,   trip_ct int,   mile_ct decimal(35,15),   km_ct decimal(35,15),   fast_aclrtn_ct int,   hard_brke_ct int,   drvng_sc_ct int,   idle_sc_ct int,   night_time_drvng_sc_ct int,   idle_time_ratio decimal(35,15),   trip_rprt_json_tt string,etl_row_eff_dts timestamp,   etl_last_updt_dts timestamp)   PARTITIONED BY (load_dt date,src_sys_cd string,load_hr_ts timestamp,batch bigint) STORED AS PARQUET LOCATION '{hbase_athena_table_location}';"
        repair_query=f"msck repair table {hbase_athena_table}"
        athena_execution(aws_account_number,ddl_query,athena_result_path)
        athena_execution(aws_account_number,repair_query,athena_result_path)
      else:
        print(f"no files to delete in table {hbase_athena_table}")
  except Exception as e:
    exception_type, exception_object, exception_traceback = sys.exc_info()
    print(f"Function s3_delete_files_process - error {str(exception_object)} occured at line number {exception_traceback.tb_lineno}.")
    raise Exception(e)

# COMMAND ----------

# spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
#     .option("replaceWhere", "source_cd=='IMS-SM'").partitionBy("source_cd")
from pyspark.sql.window import Window
from pyspark.sql.functions import *
import dateutil


def make_program_summary(microBatchDF, batchId, harmonizedDB, curateDB, target_table):
  #packages
  import datetime as dt_time
  import boto3
  import time
  from delta.tables import DeltaTable
#   print(f"program summary load started at {dt_time.datetime.now()}")
  
  
  #variables
  environment=''
  if '_dev' in curateDB.lower():
    aws_account_number='786994105833'
    environment='dev'
  elif '_test' in curateDB.lower():
    aws_account_number='168341759447'
    environment='test'
  elif '_prod' in curateDB.lower():
    aws_account_number='785562577411'
    environment='prod'
    
  program_summary_path=f"s3://pcds-databricks-common-{aws_account_number}/iot/delta/curated/{curateDB}/PROGRAM_SUMMARY/"
  databricks_athena_table=f"telematics_staging_db.program_summary_dsd"
  hbase_athena_table=f"telematics_staging_db.program_summary_dsd_intmd"
  hbase_athena_table_location=f"s3://dw-telematics-{environment}/warehouse/telematics_staging_db/program_summary_dsd_intmd"
  databricks_athena_table_path=f"s3://pcds-databricks-common-{aws_account_number}/iot/delta/curated/{curateDB}/PROGRAM_SUMMARY/_symlink_format_manifest"
  print(program_summary_path)
  athena_result_path=f's3://dw-telematics-{environment}/warehouse/athena-query-results/program_summary_dsd/'
  
  print("\n entering test_curation_child \n")
  microBatchDF.createOrReplaceGlobalTempView("microBatchViewName")
  global trip_detail_micro_batch,date_filter_2_wks_from_sun,date_filter_18_mo_ago,batch_filter_18_mo_ago,sm_ims_src_cd,sr_octo_src_cd,sr_ims_src_cd
  curate_table = curateDB +"."+target_table
  print("---curate table--",curate_table)
  print("---curateDB----",curateDB)  
  current_dt=dt_time.datetime.now()
  print(f"Current Date is : {current_dt}")
  week_day=current_dt.weekday()
  if week_day ==6:
    date_delta=dt_time.timedelta(14)  
  else:
    date_delta=dt_time.timedelta(week_day+1+14)
  print(f'date_filter_2_wks_from_sun is : {(current_dt-date_delta).strftime("%Y-%m-%d")}')
  trip_detail_micro_batch="global_temp.microBatchViewName"
  date_filter_2_wks_from_sun=(current_dt-date_delta).strftime("%Y-%m-%d")
  print(f"date_filter_2_wks_from_sun : {date_filter_2_wks_from_sun}")
  date_filter_18_mo_ago=(current_dt-dateutil.relativedelta.relativedelta(months=18)).strftime("%Y-%m-%d")
  print(f"date_filter_18_mo_ago : {date_filter_18_mo_ago}")
  batch_filter_18_mo_ago=(current_dt-dateutil.relativedelta.relativedelta(months=18)).strftime("%Y%m%d")+'0000'
  # '202008210000'
  print(f"batch_filter_18_mo_ago : {batch_filter_18_mo_ago}")
  sm_ims_src_cd=f"('IMS_SM_5X', 'FMC_SM')"
  sr_src_cd=f"('IMS_SR_4X','IMS_SR_5X','TIMS_SR','FMC_SR','OCTO_SR')"
#   sr_octo_src_cd=f"('OCTO_SR')"
#   sr_ims_src_cd=f"('IMS_SR_4X','IMS_SR_5X','TIMS_SR','FMC_SR')"
  
  #execution
  smls_program_summary_df=smartmiles_ims_wk_program_summary_cal(harmonizedDB, curateDB)
  sr_program_summary_df=smartride_wk_hive_sre_summary(sr_src_cd,harmonizedDB, curateDB)
#   sr_octo_program_summary_df=smartride_wk_hive_sre_summary(sr_octo_src_cd,harmonizedDB, curateDB)
#   sr_ims_program_summary_df=smartride_wk_hive_sre_summary(sr_ims_src_cd,harmonizedDB, curateDB)
  print(f"smartride program summary load started at {dt_time.datetime.now()}")
  sr_finalDF=sr_program_summary_df.selectExpr('enrld_vin_nb'
  ,'prgrm_instc_id'
  ,'data_clctn_id'
  ,'pe_cd'
  ,'pe_strt_ts'
  ,'pe_end_ts'
  ,'trip_ct'
  ,'mile_ct'
  ,'km_ct'
  ,'fast_aclrtn_ct'
  ,'hard_brke_ct'
  ,'drvng_sc_ct'
  ,'idle_sc_ct'
  ,'night_time_drvng_sc_ct'
  ,'idle_time_ratio'
  ,'trip_sc_json_tt as trip_rprt_json_tt'
  ,'src_sys_cd','type_of_data'
  ,'POLICY_KEY'
  ,'POLICY_KEY_ID').withColumn('PROGRAM_SUMMARY_ID',lit('1').cast('BIGINT'))\
  .withColumn('LOAD_DT',current_date())\
  .withColumn('LOAD_HR_TS',current_timestamp())\
  .withColumn('ETL_ROW_EFF_DTS',current_timestamp())\
  .withColumn('ETL_LAST_UPDT_DTS',current_timestamp())\
  .withColumn('PROGRAM',lit('Smartride'))
#   .write.format("delta").mode("overwrite").saveAsTable(f"{curateDB}.wk_sr_program_summary")
  sr_finalDF.write.format("delta").mode("overwrite").option("replaceWhere", "PROGRAM=='Smartride'").partitionBy("PROGRAM").saveAsTable(f"{curate_table}")
  print(f"smartride program summary load completed at {dt_time.datetime.now()}")
  print(f"smartmiles program summary load started at {dt_time.datetime.now()}")
  sr_max_seq_id=spark.sql(f"select coalesce(max(PROGRAM_SUMMARY_ID),0) sr_seq_id from {curate_table}").collect()[0]['sr_seq_id']
  sm_finalDF=smls_program_summary_df.selectExpr('enrld_vin_nb'
  ,'prgrm_instc_id'                                                      
  ,'data_clctn_id'
  ,'pe_cd'
  ,'pe_strt_ts'
  ,'pe_end_ts'
  ,'cast(trip_ct as INT)'
  ,'mile_ct'
  ,'km_ct'
  ,'cast(fast_aclrtn_ct as INT)'
  ,'cast(hard_brke_ct as INT)'
  ,'cast(drvng_sc_ct as INT)'
  ,'cast(idle_sc_ct as INT)'
  ,'cast(night_time_drvng_sc_ct as INT)'
  ,'cast(idle_time_ratio as DECIMAL(35,15))'
  ,'trip_sc_json_tt as trip_rprt_json_tt'
  ,'src_sys_cd','type_of_data'
  ,'POLICY_KEY'
  ,'POLICY_KEY_ID').withColumn('PROGRAM_SUMMARY_ID',lit('1').cast('BIGINT'))\
  .withColumn('LOAD_DT',current_date())\
  .withColumn('LOAD_HR_TS',current_timestamp())\
  .withColumn('ETL_ROW_EFF_DTS',current_timestamp())\
  .withColumn('ETL_LAST_UPDT_DTS',current_timestamp())\
  .withColumn('PROGRAM',lit('Smartmiles'))
  sm_finalDF.write.format("delta").mode("overwrite").option("replaceWhere", "PROGRAM=='Smartmiles'").partitionBy("PROGRAM").saveAsTable(f"{curate_table}")
#   .write.format("delta").mode("overwrite").saveAsTable(f"{curateDB}.wk_sm_program_summary")
  print(f"smartmiles program summary load completed at {dt_time.datetime.now()}")
  batch_row=spark.sql(f"select coalesce(max(batch),0)+1 batch from {curateDB}.program_summary_dsd_intmd").collect()
  batch=batch_row[0]['batch']
  if int(dt_time.datetime.now().strftime('%H')) >= 1 and int(dt_time.datetime.now().strftime('%H')) < 8:
    s3_delete_files_process(aws_account_number,athena_result_path,hbase_athena_table,hbase_athena_table_location)
  program_summary_dsd_intmd_df=spark.read.table(f"{curate_table}")
  program_summary_dsd_intmd_df.filter('type_of_data="new"').withColumn('batch',lit(batch)).withColumn('LOAD_HR_TS',current_timestamp()+expr("INTERVAL 45 minutes")).select('program_summary_id' ,'pe_cd' ,'prgrm_instc_id' ,'data_clctn_id' ,'enrld_vin_nb' ,'pe_strt_ts' ,'pe_end_ts' ,'trip_ct' ,'mile_ct' ,'km_ct' ,'fast_aclrtn_ct' ,'hard_brke_ct' ,'drvng_sc_ct' ,'idle_sc_ct' ,'night_time_drvng_sc_ct' ,'idle_time_ratio' ,'trip_rprt_json_tt' ,'etl_row_eff_dts' ,'etl_last_updt_dts'  ,'load_dt','src_sys_cd','load_hr_ts','batch')\
  .write.format("parquet").partitionBy('load_dt','src_sys_cd','load_hr_ts','batch').mode("append").saveAsTable(f"{curateDB}.program_summary_dsd_intmd")
  spark.sql(f'refresh table {curateDB}.program_summary_dsd_intmd')
#   deltaTable = DeltaTable.forPath(spark,program_summary_path)
#   deltaTable.generate("symlink_format_manifest")
  sts_client = boto3.client('sts',region_name='us-east-1',endpoint_url ='https://sts.us-east-1.amazonaws.com')
  insert_repair_query=f"msck repair table {hbase_athena_table};"
  athena_execution(aws_account_number,insert_repair_query,athena_result_path)
  print(f"program summary load completed at {dt_time.datetime.now()}")
  

# COMMAND ----------

# microBatchDF = spark.sql("select * from dhf_iot_curated_dev.program_summary_chlg")

# COMMAND ----------


# make_program_summary(microBatchDF, 0, '', 'dhf_iot_curated_dev', 'program_summary')
