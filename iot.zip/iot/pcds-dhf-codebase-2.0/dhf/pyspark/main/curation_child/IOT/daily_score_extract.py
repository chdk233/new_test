# Databricks notebook source
dbutils.widgets.text(name = "environment",defaultValue = "test")
environment = dbutils.widgets.get('environment')

# COMMAND ----------



# COMMAND ----------

def put_remote_file_ftp(**arguments):
  import pysftp
  ftp_name           = arguments.get('ftp_name','')
  record_length      = arguments.get('record_length','')
  ftp_host           = arguments.get('ftp_host')
  ftp_user           = arguments.get('ftp_user')
  ftp_pass           = arguments.get('ftp_pass')
  remote_file_path   = arguments.get('remote_file_path')
  remote_file_name   = arguments.get('remote_file_name')
  src_file_path_name = arguments.get('src_file_path_name')
  cnopts = pysftp.CnOpts()
  cnopts.hostkeys = None
  print(ftp_host)
  sftp=pysftp.Connection(ftp_host,username=ftp_user, password=ftp_pass, private_key=".ppk", cnopts=cnopts)
  try:
    sftp.cwd(remote_file_path)
    print('Remote Directory  Exists')
  except Exception as e:
    print('Remote Directory Not Exists')
    sftp.close()
    raise Exception(e)
  try:
    remote_file=remote_file_path+'/'+remote_file_name.strip(' ')
    print(remote_file)
    print(src_file_path_name)
    if ftp_name.strip(' ').lower()=='mainframe':
      sftp.listdir(f"/+recfm=fb,lrecl={record_length},mode=text,replace/")
      sftp.put(src_file_path_name,remote_file ,confirm=False, preserve_mtime=False)
    else:
      sftp.put(src_file_path_name,remote_file ,confirm=True, preserve_mtime=False)
  except Exception as e:
    sftp.close()
    raise Exception(e)
  sftp.close()
  

# COMMAND ----------

def send_to_ftp(myPath):
  sc = spark.sparkContext
#   myPath = f's3://pcds-databricks-common-786994105833/iot/extracts/daily-scoring/mainframe'
  javaPath = sc._jvm.java.net.URI.create(myPath)
  hadoopPath = sc._jvm.org.apache.hadoop.fs.Path(myPath)
  hadoopFileSystem = sc._jvm.org.apache.hadoop.fs.FileSystem.get(javaPath, sc._jvm.org.apache.hadoop.conf.Configuration())
  iterator = hadoopFileSystem.listFiles(hadoopPath, True)

  
  extract_file = ''
  while iterator.hasNext():
    #s3_keys.append(iterator.next().getPath().getName())
    temp = iterator.next().getPath().getName()
    if(temp.startswith('part')):
      extract_file = temp
  print(extract_file)  

  ftp_arguments={  'ftp_name':'mainframe',
     'record_length':400,
    'ftp_host' : "GM1.ENT.NWIE.NET",
    'ftp_user' : "DWCIDFTP",
    'ftp_pass' : "FGRTVDR7",
  'remote_file_path':'//DWCI.SRP',
  'remote_file_name':'SCRVNDVB.DWBI',
  'src_file_path_name':f'/dbfs/mnt/pcds-iot-extracts-{environment}/daily-scoring/mainframe/{extract_file}'}  

  put_remote_file_ftp(**ftp_arguments)

# COMMAND ----------

  
def daily_score_extract(microBatchDF, batchId, harmonizedDB, curateDB, target_table):
  
  microBatchDF.createOrReplaceGlobalTempView("microBatch")
  
  final_df = spark.sql(f"""SELECT distinct CONCAT(
RPAD(TRIM(IF(tb1.DEVC_KEY IS NULL,' ', CAST(cast(tb1.DEVC_KEY as bigint) AS VARCHAR(25)))),25,' ')
,'                    '
,RPAD(TRIM(IF(tb1.ENRLD_VIN_NB IS NULL,' ', CAST(tb1.ENRLD_VIN_NB AS VARCHAR(17)))),17,' ')
,LPAD(TRIM(IF(tb1.PRGRM_INSTC_ID IS NULL,' ', CAST(tb1.PRGRM_INSTC_ID AS VARCHAR(36)))),36,'0')
,RPAD(REGEXP_REPLACE(IF(tb1.MODL_OTPT_TS IS NULL,' ', CAST(tb1.MODL_OTPT_TS AS VARCHAR(10))),'-',''),8,' ')
,RPAD(REGEXP_REPLACE(IF(tb1.SCR_STRT_DT IS NULL,' ', CAST(tb1.SCR_STRT_DT AS VARCHAR(10))),'-',''),8,' ')
,RPAD(REGEXP_REPLACE(IF(tb1.SCR_END_DT IS NULL,' ', CAST(tb1.SCR_END_DT AS VARCHAR(10))),'-',''),8,' ')
,LPAD(CAST(IF(tb1.SCR_DAYS_CT IS NULL,0,CAST(tb1.SCR_DAYS_CT AS INT)) AS VARCHAR(5)),3,'0')
,RPAD(TRIM(CAST(tb1.score_model_1 AS VARCHAR(4))),4,' ')
,LPAD(TRIM(CAST(tb1.PURE_SCR_1_QTY AS VARCHAR(3))),3,'0')
,LPAD(TRIM(IF((CASE when (tb1.INSTL_PCTG < 95) then 998 when (tb1.PLSBL_DRIV_PCTG < 97 or tb1.PLSBL_DRIV_PCTG is null ) then 997 else (case when (tb1.PURE_SCR_1_QTY < 1) then 1 when (tb1.PURE_SCR_1_QTY > 995) then 995 else tb1.PURE_SCR_1_QTY end) end) IS NULL,' ', CAST((CASE when (tb1.INSTL_PCTG < 95) then 998 when (tb1.PLSBL_DRIV_PCTG < 97 or tb1.PLSBL_DRIV_PCTG is null ) then 997 else (case when (tb1.PURE_SCR_1_QTY < 1) then 1 when (tb1.PURE_SCR_1_QTY > 995) then 995 else tb1.PURE_SCR_1_QTY end) end) AS VARCHAR(3)))),3,'0')
,'          '
,RPAD(TRIM(CAST(tb1.score_model_2 AS VARCHAR(4))),4,' ')
,LPAD(TRIM(IF(tb1.PURE_SCR_2_QTY IS NULL,' ', CAST(tb1.PURE_SCR_2_QTY AS VARCHAR(3)))),3,'0')
,LPAD(TRIM(IF((CASE when (tb1.INSTL_PCTG < 95) then 998 when (tb1.PLSBL_DRIV_PCTG < 97 or tb1.PLSBL_DRIV_PCTG is null ) then 997 else (case when (tb1.PURE_SCR_2_QTY < 1) then 1 when (tb1.PURE_SCR_2_QTY > 995) then 995 else tb1.PURE_SCR_2_QTY end) end) IS NULL,' ', CAST((CASE when (tb1.INSTL_PCTG < 95) then 998 when (tb1.PLSBL_DRIV_PCTG < 97 or tb1.PLSBL_DRIV_PCTG is null ) then 997 else (case when (tb1.PURE_SCR_2_QTY < 1) then 1 when (tb1.PURE_SCR_2_QTY > 995) then 995 else tb1.PURE_SCR_2_QTY end) end) AS VARCHAR(3)))),3,'0')
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,LPAD(CAST(IF(tb1.DSCNCTD_TIME_PCTG IS NULL,0,CAST(tb1.DSCNCTD_TIME_PCTG*100 AS INT)) AS VARCHAR(5)),5,'0')
,LPAD(TRIM(IF(tb1.ANNL_MILG_QTY IS NULL,' ', CAST(tb1.ANNL_MILG_QTY AS VARCHAR(6)))),6,'0')
,RPAD(TRIM(IF(tb1.CNCT_DSCNCT_CT IS NULL,' ', CAST(tb1.CNCT_DSCNCT_CT AS VARCHAR(7)))),7,' ')
,CONCAT(CONCAT(CONCAT(CONCAT (LPAD(TRIM(IF(tb1.UNINSTL_DAYS_CT IS NULL,' ', CAST(CAST(tb1.UNINSTL_DAYS_CT/86400 AS INT) AS VARCHAR(3)))),3,'0') , ':'),
LPAD(TRIM(IF(tb1.UNINSTL_DAYS_CT IS NULL,' ', CAST(CAST((tb1.UNINSTL_DAYS_CT%86400)/3600 AS INT) AS VARCHAR(3)))),2,'0') , ':'),
LPAD(TRIM(IF(tb1.UNINSTL_DAYS_CT IS NULL,' ', CAST(CAST(((tb1.UNINSTL_DAYS_CT%86400)%3600)/60 AS INT)AS VARCHAR(3)))),2,'0') , ':'),
LPAD(TRIM(IF(tb1.UNINSTL_DAYS_CT IS NULL,' ', CAST(((tb1.UNINSTL_DAYS_CT%86400)%3600)%60 AS VARCHAR(3)))),2,'0'))
,'                                             ')
FROM 
(
Select 
outbound_score_elements_id,
DEVC_KEY,
ENRLD_VIN_NB,
case when SRC_SYS_CD LIKE ('%SM%') THEN DATA_CLCTN_ID
     when SRC_SYS_CD LIKE ('%SR%') THEN PRGRM_INSTC_ID
   END AS PRGRM_INSTC_ID,
MODL_OTPT_TS,
SCR_STRT_DT,
SCR_END_DT,
SCR_DAYS_CT,
'ND1' As score_model_1,
CASE WHEN MODL_ACRNYM_TT='ND1' THEN MODL_OTPT_QTY ELSE 0 END AS PURE_SCR_1_QTY,
'SM1' As score_model_2,
CASE WHEN MODL_ACRNYM_TT2='SM1' THEN MODL_OTPT_QTY2 ELSE 0 END AS PURE_SCR_2_QTY,
cast(DSCNCTD_TIME_PCTG as double),
cast(ANNL_MILG_QTY as double) as ANNL_MILG_QTY,
CNCT_DSCNCT_CT,
UNINSTL_DAYS_CT,
cast(INSTL_PCTG as double) as INSTL_PCTG,
cast(PLSBL_DRIV_PCTG as double) as PLSBL_DRIV_PCTG,
LOAD_DT
from (select distinct a.*,b.MODL_ACRNYM_TT as MODL_ACRNYM_TT2,b.MODL_OTPT_QTY as MODL_OTPT_QTY2 from (select *,row_number() over (partition by ENRLD_VIN_NB,SRC_SYS_CD,MODL_NM,MODL_ACRNYM_TT order by MAX_PE_END_TS desc) as row_nb from (select ib.* from {curateDB}.inbound_score_elements ib inner join {curateDB}.outbound_score_elements ob on ib.outbound_score_elements_id = ob.outbound_score_elements_id  and to_date(ob.LOAD_DT,'yyyyMMdd') = DATE(CURRENT_DATE)-1) )  a inner join {curateDB}.inbound_score_elements b on a.enrld_vin_nb=b.enrld_vin_nb  and a.outbound_score_elements_id=b.outbound_score_elements_id and a.MODL_ACRNYM_TT="ND1" AND b.MODL_ACRNYM_TT="SM1" where row_nb=1)) tb1 """).drop("row_nb")

  
  currentdate = date.today()
  print(f"Current Date is : {currentdate}")
  if ('dev') in curateDB:
    path = 's3://pcds-databricks-common-786994105833/iot/extracts/daily-scoring'
  elif ('test') in curateDB:
    path = 's3://pcds-databricks-common-168341759447/iot/extracts/daily-scoring'
  elif ('prod') in curateDB:
    path = 's3://pcds-databricks-common-785562577411/iot/extracts/daily-scoring'

  df_extract = final_df.select(concat(*final_df.columns).alias('data'))
  df_extract.coalesce(1).write.format("text").option("header", "false").mode("overwrite").save(f"{path}/mainframe")
  df_extract.coalesce(1).write.format("text").option("header", "false").mode("append").save(f"{path}/load_date={currentdate}")
  
  df_extract.withColumn('LOAD_DT',current_date()).write.format("delta").mode("append").saveAsTable(f"{curateDB}.extracts_dailyscoring")
  
  send_to_ftp(path + '/mainframe')
  
  
  




