# Databricks notebook source
dbutils.widgets.text(name = "environment",defaultValue = "test")
environment = dbutils.widgets.get('environment')

# COMMAND ----------

#pip install pysftp

# COMMAND ----------


def put_remote_file_ftp(**arguments):
  import pysftp
  ftp_name           = arguments.get('ftp_name','')
  record_length      = arguments.get('record_length','')
  ftp_host           = arguments.get('ftp_host')
  ftp_user           = arguments.get('ftp_user')
  ftp_pass           = arguments.get('ftp_pass')
  remote_file_path   = arguments.get('remote_file_path')
  remote_file_name   = arguments.get('remote_file_name')
  src_file_path_name = arguments.get('src_file_path_name')
  cnopts = pysftp.CnOpts()
  cnopts.hostkeys = None
  print(ftp_host)
  sftp=pysftp.Connection(ftp_host,username=ftp_user, password=ftp_pass, private_key=".ppk", cnopts=cnopts)
  try:
    sftp.cwd(remote_file_path)
    print('Remote Directory  Exists')
  except Exception as e:
    print('Remote Directory Not Exists')
    sftp.close()
    raise Exception(e)
  try:
    remote_file=remote_file_path+'/'+remote_file_name.strip(' ')
    print(remote_file)
    print(src_file_path_name)
    if ftp_name.strip(' ').lower()=='mainframe':
      sftp.listdir(f"/+recfm=fb,lrecl={record_length},mode=text,replace/")
      sftp.put(src_file_path_name,remote_file ,confirm=False, preserve_mtime=False)
    else:
      sftp.put(src_file_path_name,remote_file ,confirm=True, preserve_mtime=False)
  except Exception as e:
    sftp.close()
    raise Exception(e)
  sftp.close()


# COMMAND ----------

def smartmiles_wk_daily(harmonizedDB,curatedDB):
  smartmiles_wk_hive_sre_daily = spark.sql(f"""SELECT 
         wdv.PRGRM_INSTC_ID,
         wdv.DATA_CLCTN_ID,
         wtd.ENRLD_VIN_NB,
         wtd.DEVC_KEY as DEVC_ID,
         wdv.PLCY_ST_CD,
         wdv.ENRLMNT_STRT_DT,
         wdv.ENRLMNT_END_DT,
         max(wtd.LOAD_DT) as LOAD_DT,
         max(wtd.LOAD_HR_TS) as LOAD_HR_TS,
         wtd.SRC_SYS_CD,
         CAST(cast(wtd.PE_STRT_TS as date)  AS VARCHAR(10)) AS trip_date,
         SUM(wtd.MILE_CT) AS miles,   
         SUM(wtd.KM_CT) as KM_CT,
         SUM(wtd.ADJST_MILE_CT) AS adjusted_miles,
         SUM(wtd.PLSBL_MILE_CT) AS plausible_miles,
         SUM(wtd.IDLE_SC_CT) AS IDLE_SC_CT,
         SUM(wtd.PLSBL_IDLE_SC_CT) AS PLSBL_IDLE_SC_CT,
         SUM(wtd.DRVNG_SC_CT) AS DRVNG_SC_CT,
         SUM(wtd.PLSBL_DRIV_SC_CT) AS PLSBL_DRIV_SC_CT,
         COALESCE(wdv.POLICY_KEY, 'NOKEY') AS POLICY_KEY,
         COALESCE(wdv.POLICY_KEY_ID, XXHASH64('NOKEY')) AS POLICY_KEY_ID
  FROM {curatedDB}.trip_detail wtd
  JOIN (select * from {harmonizedDB}.integrated_enrollment where CRNT_ENRLMNT_FLG = 'Y' and ENRLMNT_STTS = 'Active')  wdv
  ON trim(wtd.ENRLD_VIN_NB) = trim(wdv.VIN_NB) and date(wdv.ENRLMNT_STRT_DT) >= add_months(current_date,-18)
  AND wtd.PE_STRT_TS >= wdv.ENRLMNT_STRT_DT and wtd.PE_STRT_TS < wdv.ENRLMNT_END_DT
  WHERE wdv.PLCY_ST_CD = 'CA'
  GROUP  BY wdv.PRGRM_INSTC_ID,
            wdv.DATA_CLCTN_ID,
            wtd.ENRLD_VIN_NB,
            wdv.PLCY_ST_CD,
            wtd.DEVC_KEY,
            wdv.ENRLMNT_END_DT,
            wdv.ENRLMNT_STRT_DT,
             wtd.SRC_SYS_CD,
            CAST(cast(wtd.PE_STRT_TS as date)  AS VARCHAR(10)),
            wdv.POLICY_KEY,
            wdv.POLICY_KEY_ID
      """)
  return smartmiles_wk_hive_sre_daily


# COMMAND ----------

def smartmiles_wk_device_active_days(harmonizedDB, curatedDB):
  smartmiles_wk_device_active_days_df = spark.sql(f"""
  SELECT T1.PRGRM_INSTC_ID,
       T1.DATA_CLCTN_ID,
       T1.DEVC_ID,
       T1.ENRLD_VIN_NB,
       Date_add(Cast(T1.DEVC_STTS_FRST_TS AS DATE), Cast(d.day_id AS INT)) AS trip_dt,
       T1.DEVC_STTS_FRST_TS,
       T1.DEVC_STTS_LAST_TS,
       T1.LIFETM_DAYS_CT,
       T1.CNCTD_DAYS_CT,
       T1.DEVC_CNCTD_PCT,
       T1.DEVC_DSCNCTD_PCT,
       T1.PLCY_ST_CD,
       coalesce(T1.POLICY_KEY, 'NOKEY') as POLICY_KEY,
       coalesce(T1.POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
   FROM
   (
     SELECT ds.PRGRM_INSTC_ID
    ,ds.DATA_CLCTN_ID
    ,cdv.DEVC_ID
    ,ds.ENRLD_VIN_NB
    ,ds.DEVC_STTS_FRST_TS
    ,ds.DEVC_STTS_LAST_TS
    ,ds.LIFETM_DAYS_CT
    ,ds.CNCTD_DAYS_CT
    ,ds.DEVC_CNCTD_PCT
    ,ds.DEVC_DSCNCTD_PCT
    ,cdv.PLCY_ST_CD
    ,cdv.POLICY_KEY
    ,cdv.POLICY_KEY_ID
      FROM  {curatedDB}.device_summary   ds
             INNER JOIN (select * from {harmonizedDB}.integrated_enrollment where CRNT_ENRLMNT_FLG = 'Y' and ENRLMNT_STTS = 'Active')  cdv
                     ON trim(ds.ENRLD_VIN_NB) = trim(cdv.VIN_NB) and date(cdv.ENRLMNT_STRT_DT) >= add_months(current_date,-18)
                     AND	ds.DEVC_STTS_FRST_TS >= cdv.ENRLMNT_STRT_DT 
                     AND	ds.DEVC_STTS_FRST_TS < cdv.ENRLMNT_END_DT 
                     
   )T1
  JOIN {curatedDB}.days d
  WHERE d.day_id <= T1.LIFETM_DAYS_CT""")
  
  return smartmiles_wk_device_active_days_df

# COMMAND ----------

def filter_union():
  df = spark.sql(f""" select * from smartmiles_wk_daily_temp where date(ENRLMNT_STRT_DT) >= add_months(current_date,-18)  and SRC_SYS_CD like '%SR%'
  union
  select * from smartmiles_wk_daily_temp where SRC_SYS_CD like '%SM%' """)
  return df

# COMMAND ----------

def s2():
  s2 = spark.sql(f"""SELECT
s1.PRGRM_INSTC_ID,
s1.DATA_CLCTN_ID,
s1.DEVC_ID,
s1.ENRLD_VIN_NB,
s1.Distance_kms,
s1.DEVC_STTS_FRST_TS,
s1.DEVC_STTS_LAST_TS,
s1.LIFETM_DAYS_CT,
s1.CNCTD_DAYS_CT,
s1.DEVC_CNCTD_PCT,
s1.DEVC_DSCNCTD_PCT,
s1.PLSBL_IDLE_SC_CT,
s1.PLSBL_DRIV_SC_CT,
s1.IDLE_SC_CT,
s1.DRVNG_SC_CT,
s1.RankDistance,
s1.Obs_Ct,
s1.LOAD_DT,
s1.LOAD_HR_TS,
s1.SRC_SYS_CD,
CAST((s1.RankDistance / s1.Obs_Ct ) AS DECIMAL ) AS PctRank,
s1.PLCY_ST_CD,
POLICY_KEY,
POLICY_KEY_ID
FROM
(
SELECT
dad.PRGRM_INSTC_ID,
dad.DATA_CLCTN_ID,
hsd.DEVC_ID ,
dad.ENRLD_VIN_NB,
CASE WHEN (KM_CT IS NULL) THEN 0.00 ELSE KM_CT END AS Distance_kms,
DEVC_STTS_FRST_TS,
DEVC_STTS_LAST_TS,
LIFETM_DAYS_CT,
(CNCTD_DAYS_CT + 1) AS CNCTD_DAYS_CT,
DEVC_CNCTD_PCT,
DEVC_DSCNCTD_PCT,
hsd.LOAD_DT,
hsd.LOAD_HR_TS,
hsd.SRC_SYS_CD,
CASE WHEN (IDLE_SC_CT IS NULL) THEN CAST(0 AS BIGINT) ELSE IDLE_SC_CT END AS IDLE_SC_CT,
CASE WHEN (PLSBL_IDLE_SC_CT IS NULL) THEN CAST(0 AS BIGINT) ELSE PLSBL_IDLE_SC_CT END AS PLSBL_IDLE_SC_CT,
CASE WHEN (DRVNG_SC_CT IS NULL) THEN CAST(0 AS BIGINT) ELSE DRVNG_SC_CT END AS DRVNG_SC_CT,
CASE WHEN (PLSBL_DRIV_SC_CT IS NULL) THEN CAST(0 AS BIGINT) ELSE PLSBL_DRIV_SC_CT END AS PLSBL_DRIV_SC_CT,
ROW_NUMBER() OVER(PARTITION BY coalesce(dad.DATA_CLCTN_ID, dad.PRGRM_INSTC_ID), hsd.DEVC_ID, dad.ENRLD_VIN_NB ORDER BY KM_CT) AS RankDistance,
COUNT(*) OVER(PARTITION BY coalesce(dad.DATA_CLCTN_ID, dad.PRGRM_INSTC_ID), hsd.DEVC_ID, dad.ENRLD_VIN_NB) AS Obs_Ct,
dad.PLCY_ST_CD,
dad.POLICY_KEY,
dad.POLICY_KEY_ID
FROM smartmiles_wk_device_active_days dad
JOIN smartmiles_wk_daily_filter hsd
ON trim(dad.ENRLD_VIN_NB) = trim(hsd.ENRLD_VIN_NB)
AND dad.Trip_Dt = hsd.trip_date
) s1
""") 
  return s2

# COMMAND ----------

def smartmiles_wk_annual_mileage():
  df = spark.sql(f"""SELECT
 S4.PRGRM_INSTC_ID
,S4.DATA_CLCTN_ID
,S4.DEVC_ID
,s4.ENRLD_VIN_NB
,S4.PLCY_ST_CD
,S4.DEVC_STTS_FRST_TS
,S4.DEVC_STTS_LAST_TS
,S4.CNCTD_DAYS_CT
,S4.DEVC_CNCTD_PCT
,S4.DEVC_DSCNCTD_PCT
,S4.PLSBL_SPD_PCT
,S4.Tier1_10Avg
,S4.Tier11_30Avg
,S4.Tier31_70Avg
,S4.Tier71_90Avg
,S4.Tier91_100Avg,
S4.LOAD_DT,
S4.LOAD_HR_TS,
S4.SRC_SYS_CD
,((365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) ) /1.609344) AS EstimatedMileage
,FLOOR((365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) )) AS EstimatedKilometers
,CASE WHEN (S4.DEVC_DSCNCTD_PCT > 5 OR S4.PLSBL_SPD_PCT < 97) THEN 'N' ELSE 'Y' END AS RATE_IN
,CAST (from_unixtime(unix_timestamp()) AS date) AS load_date
,POLICY_KEY
,POLICY_KEY_ID
FROM
(
SELECT
 S3.PRGRM_INSTC_ID
,S3.DATA_CLCTN_ID
,S3.DEVC_ID
,s3.ENRLD_VIN_NB
,S3.DEVC_STTS_FRST_TS
,S3.DEVC_STTS_LAST_TS
,S3.CNCTD_DAYS_CT
,S3.DEVC_CNCTD_PCT
,S3.DEVC_DSCNCTD_PCT
,S3.PLSBL_SPD_PCT,
S3.LOAD_DT,
S3.LOAD_HR_TS,
S3.SRC_SYS_CD
,CASE WHEN S3.Tier00_10Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier1_10Dist / S3.Tier00_10Obs_Ct) AS DECIMAL) END AS Tier1_10Avg
,CASE WHEN S3.Tier11_30Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier11_30Dist / S3.Tier11_30Obs_Ct) AS DECIMAL) END AS Tier11_30Avg
,CASE WHEN S3.Tier31_70Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier31_70Dist / S3.Tier31_70Obs_Ct) AS DECIMAL) END AS Tier31_70Avg
,CASE WHEN S3.Tier71_90Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL)  ELSE CAST((S3.Tier71_90Dist / S3.Tier71_90Obs_Ct) AS DECIMAL) END AS Tier71_90Avg
,CASE WHEN S3.Tier91_100Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier91_100Dist / S3.Tier91_100Obs_Ct) AS DECIMAL) END AS Tier91_100Avg
--,EstimatedKilometers/1.609344 AS EstimatedMileage
,s3.PLCY_ST_CD
,s3.POLICY_KEY
,s3.POLICY_KEY_ID
FROM
(
SELECT
 s2.PRGRM_INSTC_ID
,s2.DATA_CLCTN_ID
--,s2.DEVC_ID
,cast(regexp_replace(s2.devc_id,'^0*','') as string) DEVC_ID
,s2.ENRLD_VIN_NB
,s2.DEVC_STTS_FRST_TS
,s2.DEVC_STTS_LAST_TS
,s2.CNCTD_DAYS_CT
,s2.DEVC_CNCTD_PCT
,s2.DEVC_DSCNCTD_PCT,
max(s2.LOAD_DT) LOAD_DT,
max(s2.LOAD_HR_TS) LOAD_HR_TS,
s2.SRC_SYS_CD
,CASE WHEN (SUM(s2.IDLE_SC_CT) + SUM(s2.DRVNG_SC_CT)) = 0 THEN 0.00
     ELSE (((SUM(s2.PLSBL_IDLE_SC_CT)  + SUM(s2.PLSBL_DRIV_SC_CT))/(SUM(s2.IDLE_SC_CT) + SUM(s2.DRVNG_SC_CT))) * 100)
     END AS PLSBL_SPD_PCT
,SUM(CASE WHEN S2.PctRank < 0.10 THEN 1.00 ELSE 0.00 END)   AS Tier00_10Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.10 AND S2.PctRank < 0.30 THEN 1.00 ELSE 0.00 END)  AS Tier11_30Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.30  AND S2.PctRank < 0.70 THEN 1.00 ELSE 0.00 END)  AS Tier31_70Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.70 AND S2.PctRank < 0.90 THEN 1.00 ELSE 0.00 END)  AS Tier71_90Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.90  THEN 1.00 ELSE 0.00 END)  AS Tier91_100Obs_Ct
,SUM(CASE WHEN S2.PctRank < 0.10 THEN S2.Distance_kms ELSE 0.00 END)  AS Tier1_10Dist
,SUM(CASE WHEN S2.PctRank >= 0.10 AND S2.PctRank < 0.30 THEN S2.Distance_kms ELSE 0.00 END)  AS  Tier11_30Dist
,SUM(CASE WHEN S2.PctRank >= 0.30  AND S2.PctRank < 0.70 THEN S2.Distance_kms ELSE 0.00 END) AS  Tier31_70Dist
,SUM(CASE WHEN  S2.PctRank >= 0.70 AND S2.PctRank < 0.90 THEN S2.Distance_kms ELSE 0.00 END) AS  Tier71_90Dist
,SUM(CASE WHEN S2.PctRank >= 0.90 THEN S2.Distance_kms ELSE 0.00 END)  AS Tier91_100Dist
,s2.PLCY_ST_CD
,s2.POLICY_KEY
,s2.POLICY_KEY_ID
FROM s2
GROUP BY
s2.PRGRM_INSTC_ID
,s2.DATA_CLCTN_ID
--,s2.DEVC_ID
,cast(regexp_replace(s2.devc_id,'^0*','') as string)
,s2.ENRLD_VIN_NB
,s2.DEVC_STTS_FRST_TS
,s2.DEVC_STTS_LAST_TS
,s2.CNCTD_DAYS_CT
,s2.DEVC_CNCTD_PCT
,s2.DEVC_DSCNCTD_PCT
,s2.PLCY_ST_CD
,s2.SRC_SYS_CD
,s2.POLICY_KEY
,s2.POLICY_KEY_ID
)S3
)S4
""")
  return df

# COMMAND ----------

def smartmiles_wk_ca_annual_mileage_score():
  df =  spark.sql(f"""SELECT
 PRGRM_INSTC_ID
,DATA_CLCTN_ID
,PLCY_ST_CD as PLCY_RT_ST_CD
,CNCTD_DAYS_CT as CNCTD_DY_CT
,DEVC_CNCTD_PCT
,DEVC_DSCNCTD_PCT
,cast(PLSBL_SPD_PCT as decimal(35,15))
,Tier1_10Avg as `TIER_1-10_AVG_CT`
,Tier11_30Avg as `TIER_11-30_AVG_CT`
,Tier31_70Avg as `TIER_31-70_AVG_CT`
,Tier71_90Avg as `TIER_71-90_AVG_CT`
,Tier91_100Avg as `TIER_91-100_AVG_CT`,
LOAD_DT,
LOAD_HR_TS,
SRC_SYS_CD,
DEVC_STTS_FRST_TS as DEVC_FRST_TS,
DEVC_STTS_LAST_TS as DEVC_LAST_TS,
LPAD(TRIM(CAST( DEVC_ID AS VARCHAR(19))),20,' ') AS DEVC_KEY
,'                    ' AS PLCY_NB
,ENRLD_VIN_NB ,load_date AS SCR_DT
,(CAST(DEVC_STTS_FRST_TS AS date)) AS TRIP_STRT_DT
,(CAST(DEVC_STTS_LAST_TS AS date)) AS TRIP_END_DT
,(cast(CNCTD_DAYS_CT AS int)) AS SCR_DAYS_CT
,cast(concat(lpad(floor(CAST (DEVC_DSCNCTD_PCT AS decimal(5,2))),2,' '),'.',rpad(int((abs(CAST (DEVC_DSCNCTD_PCT AS decimal(5,2))) - floor(abs(CAST (DEVC_DSCNCTD_PCT AS decimal(5,2)))))*100),2,'0')) as decimal(35,15)) AS DSCNCTD_PCT
,cast(CASE WHEN DEVC_DSCNCTD_PCT > 5 AND floor(PLSBL_SPD_PCT) < 97 THEN '998'
     WHEN DEVC_DSCNCTD_PCT > 5 THEN '998'
     WHEN DEVC_DSCNCTD_PCT < 5 AND floor(PLSBL_SPD_PCT) < 97  THEN '997'
     ELSE ' -1'  END as INT) AS SCR_2_QTY
,cast(estimatedkilometers as decimal(35,15)) AS ESTMT_KM_DISTNC_CT,
cast(EstimatedMileage as decimal(35,15)) as ESTMT_MILES_DISTNC_CT
,coalesce(POLICY_KEY, 'NOKEY') as POLICY_KEY
,coalesce(POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
FROM smartmiles_wk_annual_mileage_temp
""")
  return df

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import *
  
def ca_annual_mileage(microBatchDF, batchId, harmonizedDB, curatedDB, target_table):
#   microBatchDF.createOrReplaceGlobalTempView("microBatchViewName")
  
  if ('dev') in harmonizedDB:
    env = 'dev'
  elif ('test') in harmonizedDB:
    env = 'test'
  elif ('prod') in harmonizedDB:
    env = 'prod'
  
  harmonizedDB = ('dhf_iot_harmonized_' + env)
  csvPath = '/dbfs/mnt/pcds-iot-extracts-' + env

  smartmiles_wk_daily(harmonizedDB,curatedDB).createOrReplaceTempView("smartmiles_wk_daily_temp")
  
  smartmiles_wk_device_active_days(harmonizedDB, curatedDB).createOrReplaceTempView("smartmiles_wk_device_active_days")
  

  filter_union().createOrReplaceTempView("smartmiles_wk_daily_filter")
  
  s2().createOrReplaceTempView("s2")
   
  smartmiles_wk_annual_mileage().createOrReplaceTempView("smartmiles_wk_annual_mileage_temp")

  final_df = smartmiles_wk_ca_annual_mileage_score()
  smartmiles_wk_ca_annual_mileage_score().createOrReplaceTempView("smartmiles_wk_annual_mileage_score_temp")
  extract_df=spark.sql("""SELECT distinct CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(DEVC_KEY,PLCY_NB),ENRLD_VIN_NB),RPAD(REGEXP_REPLACE(IF(SCR_DT IS NULL,' ', CAST(SCR_DT AS VARCHAR(10))),'-',''),8,' ')),RPAD(REGEXP_REPLACE(IF(TRIP_STRT_DT IS NULL,' ', CAST(TRIP_STRT_DT AS VARCHAR(10))),'-',''),8,' ')),RPAD(REGEXP_REPLACE(IF(TRIP_END_DT IS NULL,' ', CAST(TRIP_END_DT AS VARCHAR(10))),'-',''),8,' ')),LPAD(cast(SCR_DAYS_CT AS varchar(3)),3,' ')),concat(lpad(floor(CAST (DEVC_DSCNCTD_PCT AS decimal(5,2))),2,' '),'.',rpad(int((abs(CAST (DEVC_DSCNCTD_PCT AS decimal(5,2))) - floor(abs(CAST (DEVC_DSCNCTD_PCT AS decimal(5,2)))))*100),2,'0'))),' -1'),(CASE WHEN DEVC_DSCNCTD_PCT > 5 AND floor(PLSBL_SPD_PCT) < 97 THEN '998'
     WHEN DEVC_DSCNCTD_PCT > 5 THEN '998'
     WHEN DEVC_DSCNCTD_PCT < 5 AND floor(PLSBL_SPD_PCT) < 97  THEN '997'
     ELSE ' -1'  END)),' -1'),' -1'),' -1'),' -1'),' -1'),' -1'),' -1'),' -1'),LPAD(CAST(cast(ESTMT_KM_DISTNC_CT as int) AS varchar(6)),6,' ')),RPAD('',128,' ')) AS value 
FROM smartmiles_wk_annual_mileage_score_temp""")
  extract_df.withColumn('LOAD_DT',current_date()).write.format("delta").mode("append").saveAsTable(f"{curatedDB}.ca_annual_mileage_scoring_extract_file")
  
  annual_mileage_df = final_df.withColumn('CA_ANNUAL_MILG_SCR_ID',row_number().over(Window.orderBy(lit('0'))).cast('BIGINT'))\
    .withColumn('ETL_ROW_EFF_DTS',current_timestamp())\
    .withColumn('ETL_LAST_UPDT_DTS',current_timestamp())
  
#   annual_mileage_df.write.format("delta").mode("append").saveAsTable(f"{curatedDB}.{target_table}")
  annual_mileage_df.createOrReplaceGlobalTempView("new_annual_mileage")
  print(annual_mileage_df.columns)
  spark.sql(f"merge into {curatedDB}.{target_table} target using (select distinct * from global_temp.new_annual_mileage) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.DEVC_KEY = updates.DEVC_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.PRGRM_INSTC_ID = updates.PRGRM_INSTC_ID and target.DATA_CLCTN_ID = updates.DATA_CLCTN_ID and target.SCR_DT = updates.SCR_DT when matched then update set * when not matched then insert *")
  
  pandas_df = extract_df.select('*').toPandas()
  pandas_df.to_csv(csvPath + '/annual-mileage/annual_mileage.dat', header = False, index = False)
  ftp_arguments={  'ftp_name':'mainframe',
   'record_length':253,
  'ftp_host' : "GM1.ENT.NWIE.NET",
  'ftp_user' : "DWCIDFTP",
  'ftp_pass' : "FDVIQ3HT",
'remote_file_path':'//DWCI.SRP',
'remote_file_name':'SCRVNDVB.DW',
'src_file_path_name':f'/dbfs/mnt/pcds-iot-extracts-{environment}/annual-mileage/annual_mileage.dat'}
  
  if (extract_df.count() == 0):
    print("Badge file not available")
    raise Exception ("no Data available to send to the SRP team")
  else:
    print("data send")
    put_remote_file_ftp(**ftp_arguments)
  

  
  

# COMMAND ----------

# ca_annual_mileage(None, 0, 'harmonizedDB', 'dhf_iot_curated_dev', 'ca_annual_mileage_scoring')

# COMMAND ----------


