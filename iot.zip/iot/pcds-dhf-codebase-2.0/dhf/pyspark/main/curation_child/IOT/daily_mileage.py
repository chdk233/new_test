# Databricks notebook source
import datetime
import dateutil
cur_date = datetime.datetime.now().date()  #parametrized date format: 'YYYY-MM-DD', default current date: datetime.datetime.now().date()
load_date = '2022-05-11'

# COMMAND ----------

def cal_daily_mil_batch_nb(curatedDB):
  df = spark.sql(f"""SELECT
	inner_hr.ENRLD_VIN_NB
	,SUBSTR(inner_hr.PE_STRT_TS, 0,10) AS Trip_Dt
	,MIN(CNCTD_STTS_FLAG) AS connected_status_in
    ,inner_hr.SRC_SYS_CD

	FROM global_temp.microBatchViewName inner_hr 

	INNER JOIN {curatedDB}.device_status inner_ds
	ON TRIM(inner_hr.ENRLD_VIN_NB) = TRIM(inner_ds.ENRLD_VIN_NB)

	WHERE
	SUBSTR(inner_hr.PE_STRT_TS, 0,10) BETWEEN date(inner_ds.STTS_EFCTV_TS) AND date(inner_ds.STTS_EXPRTN_TS)
	AND inner_hr.SRC_SYS_CD like 'IMS_SM%'
	GROUP BY inner_hr.ENRLD_VIN_NB, SUBSTR(inner_hr.PE_STRT_TS, 0,10), inner_hr.SRC_SYS_CD
    """)
  return df

# COMMAND ----------

def smartmiles_WK_Daily_Mileage(curatedDB):
  smartmiles_WK_Daily_Mileage_df = spark.sql(f"""
SELECT
ds.SRC_SYS_CD,
hr.ENRLD_VIN_NB,
hr.DEVC_KEY,
hr.PE_STRT_TS
,SUM(hr.MILE_CT) AS MILE_CT
,0 AS DEVC_UNAVLBL_FL
,CASE connected_status_in
	WHEN 1 THEN 0
	WHEN 0 THEN 1
	ELSE -1
END AS DSCNCTD_STTS_FL
,SUBSTR(hr.PE_STRT_TS, 0,10) AS Trip_Dt,
hr.LOAD_DT,
hr.LOAD_HR_TS
FROM global_temp.microBatchViewName hr

INNER JOIN cal_daily_mil_batch_nb ds

ON  TRIM(hr.ENRLD_VIN_NB) = TRIM(ds.ENRLD_VIN_NB)
AND SUBSTR(hr.PE_STRT_TS, 0,10) = ds.Trip_Dt


GROUP BY ds.SRC_SYS_CD, hr.ENRLD_VIN_NB, hr.DEVC_KEY, hr.PE_STRT_TS,1
	,CASE connected_status_in
		WHEN 1 THEN 0
		WHEN 0 THEN 1
		ELSE -1
	END
	,SUBSTR(hr.PE_STRT_TS, 0,10), hr.LOAD_DT, hr.LOAD_HR_TS
    """)
  return smartmiles_WK_Daily_Mileage_df

# COMMAND ----------

df = spark.sql(f"""select 
distinct 
case when pe.SRC_SYS_CD is not null and ods.SRC_SYS_CD is not null
  then concat(pe.SRC_SYS_CD, ods.SRC_SYS_CD)
  else coalesce(pe.SRC_SYS_CD, ods.SRC_SYS_CD)
end as SRC_SYS_CD,
ods.PRGRM_INSTC_ID,
pe.DATA_CLCTN_ID,
coalesce(pe.VIN_NB,ods.ENRLD_VIN_NB) as ENRLD_VIN_NB,
coalesce( pe.PRGRM_TERM_BEG_DT, ods.ACTV_STRT_DT) as ACTV_STRT_DT,
coalesce(pe.PRGRM_TERM_END_DT, ods.ACTV_END_DT) as ACTV_END_DT,
coalesce(pe.PLCY_ST_CD, ods.PLCY_RT_ST_CD) as PLCY_RT_ST_CD,
coalesce(pe.DEVC_ID, ods.DEVC_ID_NB, 'NOKEY') as DEVC_ID_NB
from (
  (select 
    'ODS' as SRC_SYS_CD,
    PRGRM_INSTC_ID, 
    trim(ENRLD_VIN_NB) as ENRLD_VIN_NB, 
    ACTV_STRT_DT, 
    ACTV_END_DT, 
    PLCY_RT_ST_CD, 
    DEVC_ID_NB
    from dhf_iot_harmonized_test.ods_table
    where VHCL_STTS_CD = 'E'
    and ACTV_END_DT = '3500-1-1'
  ) ods
  full outer join 
  (select 
     'PE' as SRC_SYS_CD,
     DATA_CLCTN_ID,
     trim(VIN_NB) as VIN_NB,
     PRGRM_TERM_BEG_DT,
     PRGRM_TERM_END_DT,
     PLCY_ST_CD,
     DEVC_ID
     from dhf_iot_harmonized_test.program_enrollment
     where DATA_CLCTN_STTS = 'Active' and PRGRM_STTS_CD = 'Active'
  ) pe 
  on trim(ods.ENRLD_VIN_NB) = trim(pe.VIN_NB)
)""")
df.createOrReplaceGlobalTempView('ods_enrollment')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dhf_iot_harmonized_test.ods_table where TRIM(ENRLD_VIN_NB) in (select ENRLD_VIN_NB from global_temp.ods_enrollment where DATA_CLCTN_ID is not null and PRGRM_INSTC_ID is not null) and VHCL_STTS_CD = 'E' and ACTV_END_DT = '3500-01-01' order by ENRLD_VIN_NB

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dhf_iot_harmonized_test.program_enrollment where TRIM(VIN_NB) in (select ENRLD_VIN_NB from global_temp.ods_enrollment where DATA_CLCTN_ID is not null and PRGRM_INSTC_ID is not null) and DATA_CLCTN_STTS = 'Active' and PRGRM_STTS_CD = 'Active' order by VIN_NB

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.ods_enrollment where DATA_CLCTN_ID is not null and PRGRM_INSTC_ID is not null

# COMMAND ----------

def cal_smartmiles_WK_Daily_Mileage(harmonizedDB, curatedDB):
  df = spark.sql(f"""
SELECT
ods.ENRLD_VIN_NB AS ENRLD_VIN_NB
,cast(0 as bigint) AS MILE_CT
,CASE
    WHEN ds.last_device_activity_ts <> date_sub(date('{cur_date}'),1) and te.ENRLD_VIN_NB is null THEN 1
    WHEN ds.last_device_activity_ts = date_sub(date('{cur_date}'),1) or te.ENRLD_VIN_NB is not null THEN 0
    ELSE -1
END AS DEVC_UNAVLBL_FL --if there was a trip/heartbeat within the day then 0, else 1
,CASE connected_status_in
		WHEN 1 THEN 0
		WHEN 0 THEN 1
		ELSE -1
END AS DSCNCTD_STTS_FL --if device was disconnected within the day then 1, else 0
,date_sub(date('{cur_date}'),1) AS Trip_Dt
, wk.SRC_SYS_CD,
wk.LOAD_DT,
wk.LOAD_HR_TS

FROM {harmonizedDB}.ODS_TABLE ods

LEFT OUTER JOIN smartmiles_WK_Daily_Mileage wk
ON trim(wk.ENRLD_VIN_NB) = trim(ods.ENRLD_VIN_NB)
AND trip_dt = date_sub(date('{cur_date}'),1)
  AND wk.PE_STRT_TS >= ods.ACTV_STRT_DT and wk.PE_STRT_TS < ods.ACTV_END_DT
  AND trim(ods.VHCL_STTS_CD) = 'E'
  AND ods.ACTV_END_DT = '3500-01-01'
--look in trip event to see if VIN had a heartbeat within the day
LEFT OUTER JOIN
(
    select veh_key as ENRLD_VIN_NB
    from {harmonizedDB}.non_trip_event
    where EVNT_TP_CD = 'HEARTBEAT'
    and date_sub(date('{cur_date}'),1) = date(UTC_TS)
    and SRC_SYS_CD like 'IMS_SM%'
    group by ENRLD_VIN_NB
) te
on trim(te.ENRLD_VIN_NB) = trim(ods.ENRLD_VIN_NB)
 

INNER JOIN
	(
	SELECT
		ENRLD_VIN_NB
		,MIN(CNCTD_STTS_FLAG) AS connected_status_in
		,MAX(date(LAST_DEVC_ACTVTY_TS)) AS last_device_activity_ts
	FROM {curatedDB}.device_status
	WHERE date_sub(date('{cur_date}'), 1) BETWEEN date(STTS_EFCTV_TS) AND date(STTS_EXPRTN_TS)
	GROUP BY ENRLD_VIN_NB
	) ds

ON trim(ods.ENRLD_VIN_NB) =trim(ds.ENRLD_VIN_NB)

WHERE wk.ENRLD_VIN_NB IS NULL
AND ods.DEVC_ID_NB <> crc32(trim(ods.ENRLD_VIN_NB))
""")
  return df

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import *
  
def daily_mileage(microBatchDF, batchId, harmonizedDB, curatedDB, target_table):
  
  if ('dev') in harmonizedDB:
    environment = 'dev'
  elif ('test') in harmonizedDB:
    environment = 'test'
  elif ('prod') in harmonizedDB:
    environment = 'prod'
  
  harmonizedDB = 'dhf_iot_harmonized_'+ environment
  csvPath = '/dbfs/mnt/pcds-iot-extracts-' + environment
  
  microBatchDF.createOrReplaceGlobalTempView("microBatchViewName")
  cal_daily_mil_batch_nb(curatedDB).createOrReplaceTempView("cal_daily_mil_batch_nb")
  
  smartmiles_WK_Daily_Mileage(curatedDB).createOrReplaceTempView("smartmiles_WK_Daily_Mileage")

  final_df= cal_smartmiles_WK_Daily_Mileage(harmonizedDB, curatedDB)
  
  
#   daily_mileage_df = final_df.fillna({'SRC_SYS_CD':'IMS_SM_5x'})

  ### if "SRC_SYS_CD" is null, replace it with "IMS_SM_5x"
  final_df =final_df.withColumn("SRC_SYS_CD", when(col("SRC_SYS_CD").isNull() ,'IMS_SM_5x').otherwise(col("SRC_SYS_CD")))
  final_df=final_df.withColumn("LOAD_DT", when(col("LOAD_DT").isNull() ,current_date()).otherwise(col("LOAD_DT")))
  daily_mileage_df=final_df.withColumn("LOAD_HR_TS", when(col("LOAD_HR_TS").isNull() ,current_timestamp()).otherwise(col("LOAD_HR_TS")))
  
  daily_mileage_df = daily_mileage_df.withColumn('DAILY_MILEAGE_ID',row_number().over(Window.orderBy(lit('0'))).cast('BIGINT'))\
    .withColumn('ETL_ROW_EFF_DTS',current_timestamp())\
    .withColumn('ETL_LAST_UPDT_DTS',current_timestamp())
  
  
  print("Adding data into table..")
#   daily_mileage_df.write.format("delta").mode("append").saveAsTable(f"{curatedDB}.{target_table}")
  daily_mileage_df.createOrReplaceGlobalTempView('new_daily_mileage')
  spark.sql(f"merge into {curatedDB}.{target_table} target using (select distinct * from global_temp.new_daily_mileage) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.LOAD_DT = updates.LOAD_DT and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.TRIP_DT = updates.TRIP_DT when not matched then insert *")
  print("Success")
  daily_mileage_df = daily_mileage_df[['ENRLD_VIN_NB','MILE_CT', 'DEVC_UNAVLBL_FL','DSCNCTD_STTS_FL','Trip_Dt', 'LOAD_DT']]
  
  pandas_df = daily_mileage_df.toPandas()
  try:
    pandas_df.to_csv(csvPath + '/daily-mileage/daily_mileage.dat', header = False, index = False)
  except Exception as error:
    print(csvPath + '/daily-mileage/daily_mileage.dat'," - Path doesn't exist")
    print(error)
  
  
