# Databricks notebook source
from datetime import datetime, timedelta
from pyspark.sql.types import StructType,StructField, TimestampType, DecimalType, StringType, IntegerType, DateType, LongType
import json
from decimal import Decimal
from pytz import timezone
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number, col
import builtins

td_schema = StructType([StructField('TRIP_DETAIL_ID', LongType(), False),
                        StructField('POLICY_KEY', StringType(), True),
                        StructField('ENRLD_VIN_NB', StringType(), False),
                        StructField('DEVC_KEY', StringType(), False),
                        StructField('ETL_ROW_EFF_DTS', TimestampType(), False),
                        StructField('ETL_LAST_UPDT_DTS', TimestampType(), True),
                        StructField('SRC_SYS_CD', StringType(), False),
                        StructField('PE_STRT_TS', TimestampType(), False), 
                        StructField('PE_END_TS', TimestampType(), True),
                        StructField('PE_STRT_LCL_TS', TimestampType(), False),
                        StructField('PE_END_LCL_TS', TimestampType(), True),
                        StructField('MILE_CT', DecimalType(18,10), True), 
                        StructField('ADJST_MILE_CT', DecimalType(15,10), True),
                        StructField('PLSBL_MILE_CT', DecimalType(15,10), True), 
                        StructField('KM_CT', DecimalType(18,10), True), 
                        StructField('NIGHT_TIME_DRVNG_SC_CT', IntegerType(), True),                        
                        StructField('FAST_ACLRTN_CT', IntegerType(), True),
                        StructField('HARD_BRKE_CT', IntegerType(), True),
                        StructField('DRVNG_SC_CT', IntegerType(), True),
                        StructField('IDLE_SC_CT', IntegerType(), True),
                        StructField('STOP_SC_CT', IntegerType(), True),
                        StructField('PLSBL_DRIV_SC_CT', IntegerType(), True),
                        StructField('PLSBL_IDLE_SC_CT', LongType(), True),
                        StructField('IDLE_TIME_RATIO', DecimalType(20,15), True),
                        StructField('TRIP_SC_JSON_TT', StringType(), True), 
                        StructField('TRIP_SMRY_KEY', StringType(), False),
                        StructField('TIME_INTRV_1_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_2_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_3_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_4_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_5_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_6_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_7_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_8_SCR_QTY', DecimalType(15,6), True),
                        StructField('LOAD_DT', DateType(), False),
                        StructField('LOAD_HR_TS', TimestampType(), False)
                       ])
tz = timezone('US/Eastern')
MI_TO_KM = Decimal(1.609334)
MAR = 3
SAT = 5
SUN = 6
NOV = 11

# COMMAND ----------

def do_adjusted(i1, i2, i3, i4, i5, i6, i7, i8):
  return ((i1 * Decimal(2.7)) + (i2) + (i3 * Decimal(1.1)) + (i4 * Decimal(1.6)) + (i5 * Decimal(1.1)) + (i6 * Decimal(1.2)) + (i7 * Decimal(1.4)) + (i8 * Decimal(1.3)))

def convert_day(weekday):
  if weekday == 0:
    return 2
  elif weekday == 1:
    return 3
  elif weekday == 2:
    return 4
  elif weekday == 3:
    return 5
  elif weekday == 4:
    return 6
  elif weekday == 5:
    return 7
  elif weekday == 6:
    return 1
  
    
def do_daylight_savings(period_ts, dark_hours, light_hours, mult_factor):
  #dayofweek 1=SUN 7=SAT
  #.weekday()  0=MON 6=SUN
  year = period_ts.year
  if datetime(year, MAR, 1).weekday() == SUN:
    start_day = 8
  else:
    start_day = 8 - convert_day(datetime(year, MAR, 1).weekday())
    
  if datetime(year, NOV, 1).weekday() == SUN:
    end_day = 1
  else:
    end_day = 8 - convert_day(datetime(year, NOV, 1).weekday())
    
  if datetime(year, MAR, start_day, 2) < period_ts and period_ts < datetime(year, NOV, end_day, 2):
    return light_hours * mult_factor #1
  else:
    return dark_hours * mult_factor #0
     
      


# COMMAND ----------

def create_trip_detail_record_mapPartition(partitionData):
  print("\n ...Inside trip detail record function... \n")
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_data=[]
  for trip_id in data_by_trip:
    trip_data=data_by_trip[trip_id]
    trip_len = len(trip_data)
    interval1 = Decimal(0)
    interval2 = Decimal(0)
    interval3 = Decimal(0)
    interval4 = Decimal(0)
    interval5 = Decimal(0)
    interval6 = Decimal(0)
    interval7 = Decimal(0)
    interval8 = Decimal(0)
    interval1_mi = Decimal(0)
    interval2_mi = Decimal(0)
    interval3_mi = Decimal(0)
    interval4_mi = Decimal(0)
    interval5_mi = Decimal(0)
    interval6_mi = Decimal(0)
    interval7_mi = Decimal(0)
    interval8_mi = Decimal(0)
    cdk = 'NOKEY'
    i = 0
    mile_cn = 0
    adjusted_mile = 0
    adjusted_mile_cn = 0
    kilo_cn = 0
    night_cn = 0
    fast_acc = 0
    hard_brake = 0
    drive_sec = 0
    idle_second_cn = 0
    stop_cn = 0
    plaus_sec_cn = 0
    plaus_drive_sec_cn = 0
    plausible_mile_cn = 0
    plaus_idle_sec_cn = 0
    idle_second_pc = 0
    fast_acc_lst = []
    hard_brake_lst = []
    mph_lst = []
    stop_cn_lst = []
    lat_long = []
    for row in trip_data:
      trip_detail_id=row['generated_trip_id']
      if i == 0:
        vin = row['ENRLD_VIN_NB']
        cdk = row['POLICY_KEY']
        ts_key = row['TRIP_SMRY_KEY']
        start_offset_ts = row['PSTN_OFFST_TS']
        period_start_local_dst = row['PSTN_OFFST_TS'] + timedelta(hours=do_daylight_savings(row['PSTN_OFFST_TS'], 0, 1, 1))
        period_start_utc = row['PSTN_TS']
        source = row['SRC_SYS_CD']
        device_key = row['DEVC_KEY']
        load_date = row['LOAD_DT']
        load_hr = row['LOAD_HR_TS']
      if i == trip_len - 1:
        end_offset_ts = row['PSTN_OFFST_TS']
        period_end_local_dst = row['PSTN_OFFST_TS'] + timedelta(hours=do_daylight_savings(row['PSTN_OFFST_TS'], 0, 1, 1))
        period_end_utc = row['PSTN_TS']

      if row['PSTN_OFFST_TS'].weekday() == SAT or row['PSTN_OFFST_TS'].weekday() == SUN:
        if datetime.strptime("00:00:00", "%H:%M:%S").time() <= row['PSTN_OFFST_TS'].time() and row['PSTN_OFFST_TS'].time() < datetime.strptime("05:00:00", "%H:%M:%S").time():
          interval1 = interval1 + row['DISTNC_KPH']
          interval1_mi = interval1_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval1_mi
        elif datetime.strptime("05:00:00", "%H:%M:%S").time() <= row['PSTN_OFFST_TS'].time() and row['PSTN_OFFST_TS'].time() < datetime.strptime("19:00:00", "%H:%M:%S").time():
          interval2 = interval2 + row['DISTNC_KPH']
          interval2_mi = interval2_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval2_mi
        else:
          interval3 = interval3 + row['DISTNC_KPH']
          interval3_mi = interval3_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval3_mi
      else:
        if datetime.strptime("00:00:00", "%H:%M:%S").time() <= row['PSTN_OFFST_TS'].time() and row['PSTN_OFFST_TS'].time() < datetime.strptime("05:00:00", "%H:%M:%S").time():
          interval4 = interval4 + row['DISTNC_KPH']
          interval4_mi = interval4_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval4_mi
        elif datetime.strptime("05:00:00", "%H:%M:%S").time() <= row['PSTN_OFFST_TS'].time() and row['PSTN_OFFST_TS'].time() < datetime.strptime("09:00:00", "%H:%M:%S").time():
          interval5 = interval5 + row['DISTNC_KPH']
          interval5_mi = interval5_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval5_mi
        elif datetime.strptime("09:00:00", "%H:%M:%S").time() <= row['PSTN_OFFST_TS'].time() and row['PSTN_OFFST_TS'].time() < datetime.strptime("16:00:00", "%H:%M:%S").time():
          interval6 = interval6 + row['DISTNC_KPH']
          interval6_mi = interval6_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval6_mi
        elif datetime.strptime("16:00:00", "%H:%M:%S").time() <= row['PSTN_OFFST_TS'].time() and row['PSTN_OFFST_TS'].time() < datetime.strptime("19:00:00", "%H:%M:%S").time():
          interval7 = interval7 + row['DISTNC_KPH']
          interval7_mi = interval7_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval7_mi
        else:
          interval8 = interval8 + row['DISTNC_KPH']
          interval8_mi = interval8_mi + row['DISTNC_MPH'] if row['PLSBL_SC_CNT'] == 1 else interval8_mi

      mile_cn = mile_cn + row['DISTNC_MPH']
      kilo_cn = kilo_cn + row['DISTNC_KPH']
      night_cn = night_cn + row['NIGHT_TIME_DRVNG_SEC_CNT']
      drive_sec = drive_sec + row['DRVNG_SC_CNT']
      plaus_sec_cn = plaus_sec_cn + row['PLSBL_SC_CNT']
      mph_lst.append(int(builtins.round(row['SPD_MPH_RT'])))

      if row['FAST_ACLRTN_EVNT_COUNTR'] == 1:
        fast_acc = fast_acc + row['FAST_ACLRTN_EVNT_COUNTR']
        fast_acc_lst.append(i)
      if row['HARD_BRKE_COUNTR'] == 1:
        hard_brake = hard_brake + row['HARD_BRKE_COUNTR']
        hard_brake_lst.append(i)
      if row['DRVNG_SC_CNT'] == 1 and row['IDLE_SC_CNT'] == 1:
        idle_second_cn = idle_second_cn + 1
      if row['STOP_SC_CNT'] == 1:
        stop_cn = stop_cn + row['STOP_SC_CNT']
        stop_cn_lst.append(i)
      if row['PLSBL_SC_CNT'] == 1:
        plausible_mile_cn = plausible_mile_cn + row['DISTNC_MPH']
        plaus_drive_sec_cn = plaus_drive_sec_cn + row['DRVNG_SC_CNT']
        if row['DRVNG_SC_CNT'] ==1 and row['IDLE_SC_CNT'] == 1:
          plaus_idle_sec_cn = plaus_idle_sec_cn + 1

      if row['LAT_NB'] != None and row['LNGTD_NB'] != None:
        lat_long.append([float(row['LAT_NB']), float(row['LNGTD_NB'])])
      elif row['LAT_NB'] == None and row['LNGTD_NB'] != None:
        lat_long.append([None, float(row['LNGTD_NB'])])
      elif row['LAT_NB'] != None and row['LNGTD_NB'] == None:
        lat_long.append([float(row['LAT_NB']), None])
      else:
        lat_long.append(None)
      i = i + 1

    if drive_sec != 0:
      idle_second_pc = idle_second_cn / drive_sec

    adjusted_mile_cn = do_adjusted(interval1_mi, interval2_mi, interval3_mi, interval4_mi, interval5_mi, interval6_mi, interval7_mi, interval8_mi)
      
    if ('SM') in source:
      trip_report = {
        'start': str(int((start_offset_ts + timedelta(seconds=do_daylight_savings(start_offset_ts, 4, 5, 3600))).timestamp())),
        'end': str(int((end_offset_ts  + timedelta(seconds=do_daylight_savings(end_offset_ts, 4, 5, 3600))).timestamp())),
        'mph': mph_lst,
        'latlong': lat_long,
        'acceleration': fast_acc_lst if fast_acc > 0 else [],
        'braking': hard_brake_lst if hard_brake > 0 else [],
        'stop': stop_cn_lst if stop_cn > 0 else [],
        'scale': 1
      }
    else:
      trip_report = {
        'start': str(int((start_offset_ts + timedelta(seconds=do_daylight_savings(start_offset_ts, 4, 5, 3600))).timestamp())),
        'end': str(int((end_offset_ts + timedelta(seconds=do_daylight_savings(end_offset_ts, 4, 5, 3600))).timestamp())),
        'mph': mph_lst,
        'latlong': lat_long,
        'acceleration': fast_acc_lst if fast_acc > 0 else [],
        'braking': hard_brake_lst if hard_brake > 0 else [],
        'scale': 1
      }

  #     now = datetime.now(tz)
    now = datetime.now()
    
    print("\n ...returning trip detail record... \n")

    return_data.append([trip_detail_id, cdk, vin, device_key, now, now, source, period_start_utc, period_end_utc, period_start_local_dst, period_end_local_dst, Decimal(mile_cn), Decimal(adjusted_mile_cn), Decimal(plausible_mile_cn), kilo_cn, night_cn, fast_acc, hard_brake, drive_sec, idle_second_cn, stop_cn, plaus_drive_sec_cn, plaus_idle_sec_cn, Decimal(idle_second_pc), json.dumps(trip_report), ts_key, Decimal(interval1), Decimal(interval2), Decimal(interval3), Decimal(interval4), Decimal(interval5), Decimal(interval6), Decimal(interval7), Decimal(interval8), load_date, load_hr])
  return iter(return_data)

def make_trip_detail(microBatchDF, batchId, harmonizedDB, curatedDB, target_table):
  from datetime import datetime, timedelta
  from pyspark.sql.types import StructType,StructField, TimestampType, DecimalType, StringType, IntegerType, DateType, LongType
  import json
  from decimal import Decimal
  from pytz import timezone
  from pyspark.sql.window import Window
  from pyspark.sql.functions import row_number, col
  import builtins
  td_schema = StructType([StructField('TRIP_DETAIL_ID', LongType(), False),
                        StructField('POLICY_KEY', StringType(), True),
                        StructField('ENRLD_VIN_NB', StringType(), False),
                        StructField('DEVC_KEY', StringType(), False),
                        StructField('ETL_ROW_EFF_DTS', TimestampType(), False),
                        StructField('ETL_LAST_UPDT_DTS', TimestampType(), True),
                        StructField('SRC_SYS_CD', StringType(), False),
                        StructField('PE_STRT_TS', TimestampType(), False), 
                        StructField('PE_END_TS', TimestampType(), True),
                        StructField('PE_STRT_LCL_TS', TimestampType(), False),
                        StructField('PE_END_LCL_TS', TimestampType(), True),
                        StructField('MILE_CT', DecimalType(18,10), True), 
                        StructField('ADJST_MILE_CT', DecimalType(15,10), True),
                        StructField('PLSBL_MILE_CT', DecimalType(15,10), True), 
                        StructField('KM_CT', DecimalType(18,10), True), 
                        StructField('NIGHT_TIME_DRVNG_SC_CT', IntegerType(), True),                        
                        StructField('FAST_ACLRTN_CT', IntegerType(), True),
                        StructField('HARD_BRKE_CT', IntegerType(), True),
                        StructField('DRVNG_SC_CT', IntegerType(), True),
                        StructField('IDLE_SC_CT', IntegerType(), True),
                        StructField('STOP_SC_CT', IntegerType(), True),
                        StructField('PLSBL_DRIV_SC_CT', IntegerType(), True),
                        StructField('PLSBL_IDLE_SC_CT', LongType(), True),
                        StructField('IDLE_TIME_RATIO', DecimalType(20,15), True),
                        StructField('TRIP_SC_JSON_TT', StringType(), True), 
                        StructField('TRIP_SMRY_KEY', StringType(), False),
                        StructField('TIME_INTRV_1_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_2_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_3_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_4_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_5_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_6_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_7_SCR_QTY', DecimalType(15,6), True),
                        StructField('TIME_INTRV_8_SCR_QTY', DecimalType(15,6), True),
                        StructField('LOAD_DT', DateType(), False),
                        StructField('LOAD_HR_TS', TimestampType(), False)])
  tz = timezone('US/Eastern')
  MI_TO_KM = Decimal(1.609334)
  MAR = 3
  DAYLIGHT_HOURS = 1
  DARK_HOURS = 0
  SAT = 5
  SUN = 6
  NOV = 11
  print("\n....Inside make_trip_detail function.... \n")
  curated_table = curatedDB+"."+target_table
  microBatchDF.createOrReplaceGlobalTempView('microBatchViewName')
  MB_dates=*([row[0] for row in spark.sql("select distinct cast(load_dt as string) from global_temp.microBatchViewName").collect()]),'0','1'
  trip_detail_len = spark.sql(f"select coalesce(max(TRIP_DETAIL_ID), 0) as max_trip_detail_id from {curated_table}").collect()[0]['max_trip_detail_id']
  df_old = spark.sql(f"select distinct *, {trip_detail_len}+dense_rank(TRIP_SMRY_KEY) over(order by TRIP_SMRY_KEY) as generated_trip_id from (select distinct a.TRIP_DETAIL_SECONDS_ID, a.POLICY_KEY, a.POLICY_KEY_ID, a.ENRLD_VIN_NB, a.ETL_LAST_UPDT_DTS, a.ETL_ROW_EFF_DTS, a.PSTN_TS, a.PSTN_OFFST_TS, a.TIME_ZONE_OFFST_NUM, a.SPD_MPH_RT, a.SPD_KPH_RT, a.ENGIN_RPM_RT, a.DISTNC_MPH, a.DISTNC_KPH, a.FAST_ACLRTN_EVNT_COUNTR, a.HARD_BRKE_COUNTR, a.DRVNG_SC_CNT, a.IDLE_SC_CNT, a.STOP_SC_CNT, a.NIGHT_TIME_DRVNG_SEC_CNT, a.PLSBL_SC_CNT, a.CNTRD_NUM, a.SCRBD_FLD_DESC, a.LAT_NB, a.LNGTD_NB, a.TRIP_SMRY_KEY, a.DEVC_KEY, a.ORGNL_SPD_RT, a.ORGNL_RPM_RT, a.MSSNG_TOO_MANY_SEC_FLAG, a.LOAD_DT, a.SRC_SYS_CD, a.LOAD_HR_TS from  dhf_iot_harmonized_{environment}.trip_detail_seconds a inner join (select distinct TRIP_SMRY_KEY ,LOAD_DT, SRC_SYS_CD, LOAD_HR_TS from global_temp.microBatchViewName) b on a.TRIP_SMRY_KEY=b.TRIP_SMRY_KEY and a.LOAD_DT=b.LOAD_DT and a.SRC_SYS_CD=b.SRC_SYS_CD and a.LOAD_HR_TS=b.LOAD_HR_TS and a.load_dt in {MB_dates}) where MSSNG_TOO_MANY_SEC_FLAG != 1").sort(col('TRIP_SMRY_KEY').asc(), col('PSTN_TS').asc())
  wi = Window.partitionBy("TRIP_SMRY_KEY","ENRLD_VIN_NB","PSTN_TS","SRC_SYS_CD").orderBy(col("LOAD_HR_TS").desc())
  df =df_old.withColumn("rownumber", row_number().over(wi)).where(col("rownumber") == 1).drop("rownumber")
  trip_summary_keys = df.select('TRIP_SMRY_KEY').distinct().count()
  print(f"processing {trip_summary_keys} trips")
  
  if trip_summary_keys == 0:
    pass
  else:
    partitioned_df = df.repartition(trip_summary_keys, "generated_trip_id").sortWithinPartitions('ENRLD_VIN_NB','PSTN_OFFST_TS')
    td_rdd = partitioned_df.rdd.mapPartitions(create_trip_detail_record_mapPartition, preservesPartitioning=True)
    final_df=spark.createDataFrame(data=td_rdd, schema=td_schema)
    w = Window.partitionBy("TRIP_SMRY_KEY","ENRLD_VIN_NB").orderBy(col("LOAD_HR_TS").desc())
    firsRowDF =final_df.withColumn("rownum", row_number().over(w)).where(col("rownum") == 1).drop("rownum")
    firsRowDF.createOrReplaceGlobalTempView('new_trip_detail')
    spark.sql(f"merge into {curated_table} target using (select distinct *, XXHASH64(POLICY_KEY) as POLICY_KEY_ID from global_temp.new_trip_detail) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.TRIP_SMRY_KEY = updates.TRIP_SMRY_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD when matched then update set * when not matched then insert *")


# COMMAND ----------

def unit_test_trip_detail(tds):
  trip_detail_exist = spark.sql("select * from dhf_iot_curated_dev.trip_detail")
  trip_detail_len = trip_detail_exist.count()
  trip_summary_keys = tds.select('TRIP_SMRY_KEY').distinct().collect()
  td_records = []
  i = 0
  for ts_key in trip_summary_keys:
    trip = tds.filter((tds.TRIP_SMRY_KEY == ts_key['TRIP_SMRY_KEY']) & (tds.MSSNG_TOO_MANY_SEC_FLAG != 1)).orderBy('ENRLD_VIN_NB','PSTN_OFFST_TS')
    if trip.count()==0:
      pass
    else:
      td = create_trip_detail_record(trip)
      td[0] = trip_detail_len + (i+1)
      td_records.append(td)
    i+=1
  if len(td_records) > 0:
    trip_detail = spark.createDataFrame(data=td_records, schema=td_schema)
    return trip_detail


# COMMAND ----------


