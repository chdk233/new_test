# Databricks notebook source
# DBTITLE 1,Device Summary
### reference: https://github.nwie.net/Nationwide/srdp-perl/blob/aws-master/lib/sql/SmartMiles/5599_Device_Summary.sql

def get_data_from_deviceStatus(env, curatedDB):
  
  df =  spark.sql(f"""SELECT distinct
  dc.*,
  CASE
    WHEN CNCTD_STTS_FLAG = 1 THEN (
      UNIX_TIMESTAMP(STTS_END_TS) + 1 - UNIX_TIMESTAMP(STTS_EFCTV_TS)
    )
    ELSE CAST (0 AS bigint)
  END AS install_time,
  CASE
    WHEN CNCTD_STTS_FLAG = 0 THEN CASE
      WHEN LAST_DEVC_ACTVTY_TS = first_value(LAST_DEVC_ACTVTY_TS) over (
        partition BY coalesce(DATA_CLCTN_ID, PRGRM_INSTC_ID)
        ORDER BY
          STTS_END_TS DESC rows unbounded preceding
      )
      AND DEVC_UNAVLBL_FLAG = 1
      AND CNCTD_STTS_FLAG <> 0 THEN (
        UNIX_TIMESTAMP(LAST_DEVC_ACTVTY_TS) - UNIX_TIMESTAMP(STTS_EFCTV_TS)
      )
      ELSE (
        UNIX_TIMESTAMP(STTS_END_TS) + 1 - UNIX_TIMESTAMP(STTS_EFCTV_TS)
      )
    END
    ELSE CAST (0 AS bigint)
  END AS uninstall_time,
  first_value(DEVC_UNAVLBL_FLAG) over (
    partition BY coalesce(DATA_CLCTN_ID, PRGRM_INSTC_ID)
    ORDER BY
      STTS_END_TS DESC rows unbounded preceding
  ) AS final_loststatus_flg,
  first_value(LAST_DEVC_ACTVTY_TS) over (
    partition BY coalesce(DATA_CLCTN_ID, PRGRM_INSTC_ID)
    ORDER BY
      STTS_END_TS DESC rows unbounded preceding
  ) AS max_LAST_DEVC_ACTVTY_TS,
  first_value(CNCTD_STTS_FLAG) over (
    partition BY coalesce(DATA_CLCTN_ID, PRGRM_INSTC_ID)
    ORDER BY
      STTS_END_TS DESC rows unbounded preceding
  ) AS MAX_status,
  dc.LOAD_DT,
  ie.POLICY_KEY as ie_pk,
  ie.POLICY_KEY_ID as ie_pk_id
from
  (
    select
      *,CASE
        WHEN date(STTS_EXPRTN_TS) = '9999-01-01' THEN current_timestamp()
        ELSE STTS_EXPRTN_TS
      END as STTS_END_TS
    from
      {curatedDB}.device_status
  ) dc
  inner join (
    select
      distinct ENRLD_VIN_NB as vin,
      PRGRM_INSTC_ID as prgm_id,
      DATA_CLCTN_ID as dt_cln_id,
      DEVC_KEY as devc_nbr,
      SRC_SYS_CD as source
    from
      global_temp.microBatchViewName
  ) mb on dc.ENRLD_VIN_NB = mb.vin
  and dc.SRC_SYS_CD = mb.source
  and dc.DEVC_KEY = mb.devc_nbr
  inner join (
    select
      DATA_CLCTN_ID as dci,
      VIN_NB,
      PRGRM_INSTC_ID as piid,
      CAST(CAST(DEVC_ID AS BIGINT) AS STRING) as DEVC_ID,
      coalesce(POLICY_KEY, 'NOKEY') as POLICY_KEY,
      coalesce(POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
    from
      dhf_iot_harmonized_{env}.integrated_enrollment where CRNT_ENRLMNT_FLG = 'Y' and ENRLMNT_STTS = 'Active'
  ) ie on (ie.dci = dc.DATA_CLCTN_ID
  or ie.piid = dc.PRGRM_INSTC_ID)
  and ie.VIN_NB = dc.ENRLD_VIN_NB
  and ie.DEVC_ID = dc.DEVC_KEY
where
  (
    PRGRM_INSTC_ID is not null
    and SRC_SYS_CD not like '%SM%'
  )
  or (
    DATA_CLCTN_ID is not null
    and SRC_SYS_CD like '%SM%'
  )""")
  return df

# COMMAND ----------

def calc_device_summary_fields():
  df_status = spark.sql(f""" SELECT distinct
		PRGRM_INSTC_ID,
        DATA_CLCTN_ID,
		 DEVC_KEY, 
		ENRLD_VIN_NB,
		SUM(DEVC_UNAVLBL_FLAG) AS DEVC_UNAVLBL_CT,
		
		CASE WHEN (MAX(final_loststatus_flg) = 1  AND MAX(MAX_status) <> 0) THEN ((UNIX_TIMESTAMP(MAX(MAX_LAST_DEVC_ACTVTY_TS))- UNIX_TIMESTAMP(MIN(STTS_EFCTV_TS)))+ 8*(24*60*60))
		ELSE (UNIX_TIMESTAMP(MAX(STTS_END_TS))+1-UNIX_TIMESTAMP(MIN(STTS_EFCTV_TS)))  END  AS LIFETM_SC_CT,
		
		(CASE WHEN MAX(final_loststatus_flg) = 1 AND MAX(MAX_status) <> 0 THEN ((UNIX_TIMESTAMP(MAX(MAX_LAST_DEVC_ACTVTY_TS))- UNIX_TIMESTAMP(MIN(STTS_EFCTV_TS)))+ 8*(24*60*60))
		       ELSE (UNIX_TIMESTAMP(MAX(STTS_END_TS))+1-UNIX_TIMESTAMP(MIN(STTS_EFCTV_TS)))  
		END - SUM(uninstall_time)) AS CNCTD_SC_CT,
		
		SUM(uninstall_time) AS DSCNCTD_SC_CT,
		MIN(STTS_EFCTV_TS) DEVC_STTS_FRST_TS,
		MAX(LAST_DEVC_ACTVTY_TS) DEVC_STTS_LAST_TS,
    SUM(CASE WHEN CNCTD_STTS_FLAG =1 THEN 1 ELSE 0 END ) AS CNCTD_STTS_CT,
		(count(*) - SUM(CASE WHEN CNCTD_STTS_FLAG =1 THEN 1 ELSE 0 END)) AS DSCNCTD_STTS_CT,
        max(LOAD_DT) as LOAD_DT, 
        SRC_SYS_CD,
        ie_pk as POLICY_KEY,
        ie_pk_id POLICY_KEY_ID
        FROM deviceStatus group BY  PRGRM_INSTC_ID,DEVC_KEY, DATA_CLCTN_ID, ENRLD_VIN_NB,SRC_SYS_CD, ie_pk, ie_pk_id""")
  return df_status

# COMMAND ----------

def device_summary_dataframe():
  final_df = spark.sql("""SELECT distinct  
 DEVC_KEY, 
 ENRLD_VIN_NB
,PRGRM_INSTC_ID
,DATA_CLCTN_ID
,DEVC_STTS_FRST_TS
,DEVC_STTS_LAST_TS
,LIFETM_SC_CT
,CNCTD_SC_CT
,CNCTD_STTS_CT
,DSCNCTD_STTS_CT
,DSCNCTD_SC_CT,
SRC_SYS_CD
,(ceil(LIFETM_SC_CT/86400)) AS LIFETM_DAYS_CT
,(ceil(CNCTD_SC_CT/86400)) AS CNCTD_DAYS_CT
,cast(DEVC_UNAVLBL_CT AS BIGINT)
,cast((CNCTD_SC_CT/LIFETM_SC_CT)*100 as decimal(35,15)) AS DEVC_CNCTD_PCT
,cast((DSCNCTD_SC_CT/LIFETM_SC_CT)*100 as decimal(35,15)) AS DEVC_DSCNCTD_PCT
,LOAD_DT
, coalesce(POLICY_KEY, 'NOKEY') as POLICY_KEY
, coalesce(POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
from deviceSummary_status""")
  return final_df

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import *

def device_summary(microBatchDF, batchId, harmonizedDB, curatedDB, target_table):
  
  if 'dev' in curatedDB:
    env = 'dev'
  elif 'test' in curatedDB:
    env = 'test'
  elif 'prod' in curatedDB:
    env = 'prod'

  microBatchDF.createOrReplaceGlobalTempView("microBatchViewName")
  get_data_from_deviceStatus(env, curatedDB).createOrReplaceTempView("deviceStatus")
  
  calc_device_summary_fields().createOrReplaceTempView("deviceSummary_status")
  
  final_df = device_summary_dataframe()

  device_summary_df = final_df.withColumn('DEVICE_SUMMARY_ID',row_number().over(Window.orderBy(lit('0'))).cast('BIGINT'))\
    .withColumn('ETL_LAST_UPDT_DTS',current_timestamp())\
    .withColumn('ETL_ROW_EFF_DTS',current_timestamp())
  
#   device_summary_df.write.mode("overwrite").saveAsTable(f"{curatedDB}.{target_table}")
  device_summary_df.createOrReplaceGlobalTempView("device_summary_df")
  
  spark.sql(f"""merge into {curatedDB}.{target_table} tgt using(select * from global_temp.device_summary_df) src  on ((tgt.PRGRM_INSTC_ID = src.PRGRM_INSTC_ID or tgt.DATA_CLCTN_ID = src.DATA_CLCTN_ID) or ((tgt.PRGRM_INSTC_ID is null and src.PRGRM_INSTC_ID is null) and (tgt.DATA_CLCTN_ID is null and src.DATA_CLCTN_ID is null))) and tgt.DEVC_KEY = src.DEVC_KEY and tgt.ENRLD_VIN_NB = src.ENRLD_VIN_NB and tgt.SRC_SYS_CD = src.SRC_SYS_CD when matched then update set * when not matched then insert *""")

# COMMAND ----------

# microBatchDF = spark.sql("select * from default.device_status")
# device_summary(microBatchDF, 0, 'default', 'default', 'device_summary')

# COMMAND ----------


