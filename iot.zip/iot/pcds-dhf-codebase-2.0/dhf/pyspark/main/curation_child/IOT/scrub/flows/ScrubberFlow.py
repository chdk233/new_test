# Databricks notebook source
from pyspark.sql.functions import col, desc, lit, count, when, row_number, isnull, format_string, round, lag, lead, abs, max, first, hour, current_timestamp, current_date, date_format
import pyspark.sql.functions as f
from pyspark.sql import Window, DataFrame
from pyspark.sql.types import StructType, StructField, TimestampType, DecimalType, StringType, IntegerType, DateType, LongType
from pytz import timezone
from decimal import Decimal
from datetime import datetime, timedelta, time, date
from pyspark import Row
import builtins
import math
tz = timezone('US/Eastern')

# COMMAND ----------

# MAGIC %run ../prescrubbers/RemoveFarFutureEndSecond

# COMMAND ----------

# MAGIC %run ../prescrubbers/CreatePreAccelerationScrub

# COMMAND ----------

# MAGIC %run ../scrubbers/SpeedSpikeScrubber

# COMMAND ----------

# MAGIC %run ../scrubbers/AccelerationLagScrubber

# COMMAND ----------

# MAGIC %run ../scrubbers/EventAndCentroidScrubbers

# COMMAND ----------

# MAGIC %run ../postscrubbers/PostAccelerationScrubPlausibleRules

# COMMAND ----------


"""
  1. RemoveFarFutureEndSecond (prescrubber)
  2. CreatePreAccelerationScrub (prescrubber): adds missing seconds, removes null values 
  3. Scrubbers:
    a. SpeedSpike scrubber
    b. AccelerationLag scrubber
    c. RPMCentroid, IdleCentroid, EventScrubber (rpm and event scrubber, idle centroid)
  4. Plausible rules (postscrubber)
  5. TripSecondScrub (postscrubber)
"""
rdd_schema=StructType([StructField('CNTRD_NUM',LongType(),True),
             StructField('ENGIN_RPM_RT',DecimalType(38,18),True),
             StructField('FAST_ACLRTN_EVNT_COUNTR',LongType(),True),
                       StructField('HARD_BRKE_COUNTR',LongType(),True),
                       StructField('IS_LAST_SECOND_SPEED_BUMP',LongType(),True),
                       StructField('MAX_KPH',DecimalType(38,18),True), 
                       StructField('MIN_KPH',DecimalType(38,18),True), 
                       StructField('NIGHT_TIME_DRVNG_SEC_CNT',LongType(),True), 
                       StructField('PLSBL_SC_CNT',LongType(),True), 
                       StructField('PSTN_OFFST_TS',TimestampType(),True), 
                       StructField('PSTN_TS',TimestampType(),True),
                       StructField('SPD_KPH_RT',DecimalType(38,18),True),
                       StructField('SPD_MPH_RT',DecimalType(38,18),True),
                       StructField('SPEED_DECREASES',LongType(),True),
                       StructField('SPEED_INCREASES',LongType(),True),
                       StructField('SRC_SYS_CD',StringType(),True), 
                       StructField('STOP_SC_CNT',LongType(),True), 
                       StructField('TRIP_SMRY_KEY',StringType(),True), 
                       StructField('generated_trip_id',LongType(),True), 
                       StructField('row_number',LongType(),True)])
accelLag_centroid_schema=StructType([StructField('CNTRD_NUM',LongType(),True), 
                                     StructField('DEVC_KEY',StringType(),True), 
                                     StructField('DISTNC_KPH',DecimalType(38,18),True), 
                                     StructField('DISTNC_MPH',DecimalType(38,18),True), 
                                     StructField('DRVNG_SC_CNT',LongType(),True), 
                                     StructField('ENGIN_RPM_RT',DecimalType(38,18),True), 
                                     StructField('ENRLD_VIN_NB',StringType(),True), 
                                     StructField('IDLE_CENTROID_NB',LongType(),True), 
                                     StructField('IDLE_SC_CNT',LongType(),True), 
                                     StructField('IS_DRIVE_TIME',LongType(),True), 
                                     StructField('IS_LAST_SECOND_SPEED_BUMP',LongType(),True), 
                                     StructField('LAT_NB',DecimalType(38,18),True), 
                                     StructField('LNGTD_NB',DecimalType(38,18),True), 
                                     StructField('LOAD_DT',DateType(),True), 
                                     StructField('LOAD_HR_TS',TimestampType(),True), 
                                     StructField('PLCY_RT_ST_CD', StringType(), True),
                                     StructField('POLICY_KEY', StringType(), True),
                                     StructField('POLICY_KEY_ID', LongType(), True),
                                     StructField('MAX_KPH',DecimalType(38,18),True), 
                                     StructField('MAX_KPH_DELTA',DecimalType(38,18),True), 
                                     StructField('MAX_MIN_DELTA',DecimalType(38,18),True), 
                                     StructField('MIN_KPH',DecimalType(38,18),True),
                                     StructField('MIN_KPH_DELTA',DecimalType(38,18),True),
                                     StructField('LAST_SEC_PRIOR_CNTRD', DecimalType(38,18), True),
                                     StructField('MSSNG_TOO_MANY_SEC_FLAG',LongType(),True), 
                                     StructField('ORGNL_RPM_RT',DecimalType(38,18),True), 
                                     StructField('ORGNL_SPD_RT',DecimalType(38,18),True), 
                                     StructField('PSTN_OFFST_TS',TimestampType(),True), 
                                     StructField('PSTN_TS',TimestampType(),True), 
                                     StructField('SCRBD_FLD_DESC',StringType(),True), 
                                     StructField('SPD_KPH_RT',DecimalType(38,18),True), 
                                     StructField('SPD_MPH_RT',DecimalType(38,18),True), 
                                     StructField('SPEED_DECREASES',LongType(),True), 
                                     StructField('SPEED_INCREASES',LongType(),True), 
                                     StructField('SPEED_STEADY',LongType(),True), 
                                     StructField('SRC_SYS_CD',StringType(),True), 
                                     StructField('TIME_ZONE_OFFST_NUM',DecimalType(38,18),True), 
                                     StructField('TRIP_END_TS',TimestampType(),True), 
                                     StructField('TRIP_SMRY_KEY',StringType(),True), 
                                     StructField('TRIP_START_TS',TimestampType(),True), 
                                     StructField('centroid_len',LongType(),True), 
                                     StructField('dataframe_cd',StringType(),True), 
                                     StructField('first_speed',DecimalType(38,18),True)])

# COMMAND ----------

def removeDuplicatesMicrobatch_rdd(partitionedData):
  print(str(datetime.now(tz)) + " entering removeduplicates microbatch function \n")
  data_by_trip = {}
  for row in partitionedData:
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  
  rows = []
  for tripId in data_by_trip:
    df = data_by_trip[tripId]
    i = 0
    for row in df:
      if i == 0:
        tsk = row['TRIP_SMRY_KEY']
        pstn_ts = row['PSTN_TS']
        rows.append(row)
      else:
        if row['TRIP_SMRY_KEY'] == tsk and row['PSTN_TS'] == pstn_ts:
          pass
        else:
          rows.append(row)
          tsk = row['TRIP_SMRY_KEY']
          pstn_ts = row['PSTN_TS']
      i = i + 1
  print(str(datetime.now(tz)) + " leaving removeduplicates microbatch function")
  return iter(rows)
      


# COMMAND ----------

def scrub_functionality(partitionData):
  partitionData1 = removeDuplicatesMicrobatch_rdd(partitionData)
  removeFarFuture_rdd=removeFarFutureEndSecond(partitionData1)
  missingSeconds_rdd=addMissingSeconds4(removeFarFuture_rdd)
  missingRPM_rdd=addMissingRPM3(missingSeconds_rdd)
  missingSpeed_rdd=addMissingSpeed3(missingRPM_rdd)
  speedSpike_rdd=scrubSpeedSpikes(missingSpeed_rdd)
  accelLag_rdd=acceleration_lag_scrubber6(speedSpike_rdd)
  rpmCentroid_rdd = eventCentroidScrub3(accelLag_rdd)
  return rpmCentroid_rdd

def scrub_functionality1(partitionData):
  perSecondPlausible_rdd=callPlausibleRules2(partitionData)
  neighboringCentroid_rdd=callNeighboringCentroidRule2(perSecondPlausible_rdd)
  return neighboringCentroid_rdd

# COMMAND ----------

def make_trip_detail_second(microBatchDF, batchId, harmonizedDB, curateDB, target_table):
  from pyspark.sql.functions import col, desc, lit, count, when, row_number, isnull, format_string, round, lag, lead, abs, max, first, hour, current_timestamp, current_date, date_format
  import pyspark.sql.functions as f
  from pyspark.sql import Window, DataFrame
  from pyspark.sql.types import StructType, StructField, TimestampType, DecimalType, StringType, IntegerType, DateType, LongType
  from pytz import timezone
  from decimal import Decimal
  from datetime import datetime, timedelta, time
  from pyspark import Row
  import builtins
  import math
  tz = timezone('US/Eastern')
  print('start scrub_functionality ' + str(datetime.now(tz)))
  

  microBatchDF.createOrReplaceGlobalTempView('microBatchViewName')
  df = spark.sql(f"select distinct *, dense_rank(TRIP_SMRY_KEY) over(order by TRIP_SMRY_KEY) as generated_trip_id from global_temp.microBatchViewName where ENRLD_VIN_NB is not null order by TRIP_SMRY_KEY, PSTN_TS, LOAD_HR_TS desc")

  distinct_trips = df.select('TRIP_SMRY_KEY').distinct().count()
  if distinct_trips == 0:
    print('0 distinct trips')
  else:
    partitioned_df = df.repartition(distinct_trips, "generated_trip_id").sortWithinPartitions("PSTN_TS")
    print(f"processing {distinct_trips} trips")
    accelLag_centroid_rdd = partitioned_df.rdd.mapPartitions(scrub_functionality, preservesPartitioning=True)
    accelLag_centroid_df=spark.createDataFrame(accelLag_centroid_rdd,schema=accelLag_centroid_schema)
    print('scrub_functionality complete' + str(datetime.now(tz)))
    rpmCentroid_df=accelLag_centroid_df.select("CNTRD_NUM" ,"dataframe_cd" ,"ENGIN_RPM_RT" ,"ENRLD_VIN_NB" ,"IS_LAST_SECOND_SPEED_BUMP" ,"MAX_KPH" ,"MAX_KPH_DELTA" ,"MAX_MIN_DELTA" ,"MIN_KPH" ,"MIN_KPH_DELTA" ,"SPEED_DECREASES" ,"SPEED_INCREASES" ,"SPEED_STEADY" ,"TRIP_END_TS" ,"TRIP_SMRY_KEY" ,"TRIP_START_TS", "LAST_SEC_PRIOR_CNTRD" ).filter(col('dataframe_cd')=='rpmCentroid_df')
    idleTimeCentroid_df=accelLag_centroid_df.select("centroid_len" ,"dataframe_cd" ,"DEVC_KEY" ,"DISTNC_KPH" ,"DISTNC_MPH" ,"DRVNG_SC_CNT" ,"ENGIN_RPM_RT" ,"ENRLD_VIN_NB" ,"first_speed" ,"IDLE_CENTROID_NB" ,"IDLE_SC_CNT" ,"IS_DRIVE_TIME" ,"LAT_NB" ,"LNGTD_NB" ,"LOAD_DT", "LOAD_HR_TS", "MSSNG_TOO_MANY_SEC_FLAG" ,"ORGNL_RPM_RT" ,"ORGNL_SPD_RT" ,"PSTN_OFFST_TS" ,"PSTN_TS" ,"SCRBD_FLD_DESC" ,"SPD_KPH_RT" ,"SPD_MPH_RT" ,"SRC_SYS_CD" ,"TIME_ZONE_OFFST_NUM" ,"TRIP_SMRY_KEY", "PLCY_RT_ST_CD", "POLICY_KEY","POLICY_KEY_ID").filter(col('dataframe_cd')=='idleTimeCentroid_df')
    accelLag_df=accelLag_centroid_df.select("dataframe_cd" ,"DEVC_KEY" ,"DISTNC_KPH" ,"DISTNC_MPH" ,"ENGIN_RPM_RT" ,"ENRLD_VIN_NB" ,"LAT_NB" ,"LNGTD_NB" ,"MSSNG_TOO_MANY_SEC_FLAG" ,"ORGNL_RPM_RT" ,"ORGNL_SPD_RT" ,"PSTN_OFFST_TS" ,"PSTN_TS"  ,"SCRBD_FLD_DESC" ,"SPD_KPH_RT" ,"SPD_MPH_RT" ,"SRC_SYS_CD" ,"TIME_ZONE_OFFST_NUM" ,"TRIP_SMRY_KEY", "PLCY_RT_ST_CD", "POLICY_KEY","POLICY_KEY_ID" ).filter(col('dataframe_cd')=='accelLag_df')
    print('start first join ' + str(datetime.now(tz)))
    rpmCentroid_df.createOrReplaceGlobalTempView('rpmCentroid')
    accelLag_df.createOrReplaceGlobalTempView('accelLag')
    lagRPM_df=spark.sql("select * from global_temp.rpmCentroid rpmCentroid join global_temp.accelLag accelLag on rpmCentroid.TRIP_SMRY_KEY=accelLag.TRIP_SMRY_KEY and accelLag.PSTN_TS>= rpmCentroid.TRIP_START_TS and accelLag.PSTN_TS <= rpmCentroid.TRIP_END_TS").drop(rpmCentroid_df['TRIP_SMRY_KEY']).drop(accelLag_df['ENGIN_RPM_RT'])
    print('first join complete ' + str(datetime.now(tz)))
    rpmCentroid_df1 = lagRPM_df.select("TRIP_SMRY_KEY", "PSTN_TS", "PSTN_OFFST_TS", "SPD_MPH_RT", "SPD_KPH_RT", "ENGIN_RPM_RT", "MIN_KPH", "MAX_KPH", "MIN_KPH_DELTA", "MAX_KPH_DELTA", "MAX_MIN_DELTA", "SPEED_DECREASES", "SPEED_INCREASES", "IS_LAST_SECOND_SPEED_BUMP", "CNTRD_NUM","SRC_SYS_CD", "PLCY_RT_ST_CD", "POLICY_KEY", "POLICY_KEY_ID","SCRBD_FLD_DESC", "LAST_SEC_PRIOR_CNTRD").orderBy(col("PSTN_TS"))
    print('first df organization complete' + str(datetime.now(tz)))
    print('second df organization complete' + str(datetime.now(tz)))
    w=Window.orderBy('TRIP_SMRY_KEY')
    print('start scrub_functionality1 ' + str(datetime.now(tz)))
    rpmCentroid_df2=rpmCentroid_df1.withColumn('generated_trip_id',f.dense_rank().over(w))
    rpmCentroid_partitioned_df = rpmCentroid_df2.repartition(distinct_trips, "generated_trip_id").sortWithinPartitions("PSTN_TS")
    neighboringCentroid_rdd = rpmCentroid_partitioned_df.rdd.mapPartitions(scrub_functionality1, preservesPartitioning=True)
    neighboringCentroid_df=spark.createDataFrame(neighboringCentroid_rdd,schema=rdd_schema) 
    tdsid = spark.sql(f'select coalesce(max(TRIP_DETAIL_SECONDS_ID), 0) as max_tds_id from {harmonizedDB}.{target_table}').collect()[0]['max_tds_id']
    print(tdsid)
    print('start last join ' + str(datetime.now(tz)))
    trip_detail_seconds_rows = idleTimeCentroid_df.join(neighboringCentroid_df, (idleTimeCentroid_df["TRIP_SMRY_KEY"] == neighboringCentroid_df["TRIP_SMRY_KEY"]) & (idleTimeCentroid_df["PSTN_TS"] == neighboringCentroid_df["PSTN_TS"]),"inner").drop(neighboringCentroid_df['PSTN_TS']).drop(neighboringCentroid_df['TRIP_SMRY_KEY']).drop(neighboringCentroid_df['SPD_KPH_RT']).drop(neighboringCentroid_df['ENGIN_RPM_RT']).drop(neighboringCentroid_df['TRIP_SMRY_KEY']).withColumn('ETL_CURR_ROW_EFF', current_timestamp()).withColumn('ETL_LAST_UPDT_DTS', current_timestamp()).withColumn('TRIP_DETAIL_ID', (row_number().over(w) + tdsid)).select(col('TRIP_DETAIL_ID'), idleTimeCentroid_df['ENRLD_VIN_NB'], col('ETL_CURR_ROW_EFF'), col('ETL_LAST_UPDT_DTS'),  idleTimeCentroid_df['PSTN_TS'], idleTimeCentroid_df['PSTN_OFFST_TS'], idleTimeCentroid_df['TIME_ZONE_OFFST_NUM'],idleTimeCentroid_df['SPD_MPH_RT'], idleTimeCentroid_df['SPD_KPH_RT'], idleTimeCentroid_df['ENGIN_RPM_RT'], idleTimeCentroid_df['DISTNC_MPH'], idleTimeCentroid_df['DISTNC_KPH'],  neighboringCentroid_df['FAST_ACLRTN_EVNT_COUNTR'], neighboringCentroid_df['HARD_BRKE_COUNTR'], idleTimeCentroid_df['DRVNG_SC_CNT'], idleTimeCentroid_df['IDLE_SC_CNT'], neighboringCentroid_df['STOP_SC_CNT'], neighboringCentroid_df['NIGHT_TIME_DRVNG_SEC_CNT'], neighboringCentroid_df['PLSBL_SC_CNT'], neighboringCentroid_df['CNTRD_NUM'], idleTimeCentroid_df['SCRBD_FLD_DESC'], idleTimeCentroid_df['LAT_NB'], idleTimeCentroid_df['LNGTD_NB'], idleTimeCentroid_df['TRIP_SMRY_KEY'], idleTimeCentroid_df['DEVC_KEY'],idleTimeCentroid_df['ORGNL_SPD_RT'], idleTimeCentroid_df['ORGNL_RPM_RT'], idleTimeCentroid_df['MSSNG_TOO_MANY_SEC_FLAG'], idleTimeCentroid_df['POLICY_KEY'],idleTimeCentroid_df['POLICY_KEY_ID'], col('LOAD_DT'), idleTimeCentroid_df['SRC_SYS_CD'], col('LOAD_HR_TS')).withColumn('CNTRD_NUM', when(col('MSSNG_TOO_MANY_SEC_FLAG') == 1, lit(-1)).otherwise(col('CNTRD_NUM')))
    trip_detail_seconds_df = trip_detail_seconds_rows.selectExpr('cast(TRIP_DETAIL_ID as long) as TRIP_DETAIL_SECONDS_ID' ,'ENRLD_VIN_NB' ,'ETL_CURR_ROW_EFF as ETL_ROW_EFF_DTS' ,'ETL_LAST_UPDT_DTS' ,'PSTN_TS' ,'PSTN_OFFST_TS' ,'cast(TIME_ZONE_OFFST_NUM as decimal(15,6))' ,'cast(SPD_MPH_RT as decimal(18,10))' ,'cast(SPD_KPH_RT as decimal(18,10))' ,'cast(ENGIN_RPM_RT as decimal(18,5))' ,'cast(DISTNC_MPH as decimal(18,10))' ,'cast(DISTNC_KPH as decimal(18,10))' ,'cast(FAST_ACLRTN_EVNT_COUNTR as int)' ,'cast(HARD_BRKE_COUNTR as int)' ,'cast(DRVNG_SC_CNT as int)' ,'cast(IDLE_SC_CNT as int)' ,'cast(STOP_SC_CNT as int)' ,'cast(NIGHT_TIME_DRVNG_SEC_CNT as int)' ,'cast(PLSBL_SC_CNT as int)' ,'cast(CNTRD_NUM as int)' ,'SCRBD_FLD_DESC' ,'cast(LAT_NB as decimal(24,16))' ,'cast(LNGTD_NB as decimal(24,16))' ,'TRIP_SMRY_KEY' ,'DEVC_KEY' ,'cast(ORGNL_SPD_RT as decimal(18,10))' ,'cast(ORGNL_RPM_RT as decimal(18,5))' ,'cast(MSSNG_TOO_MANY_SEC_FLAG as int)' ,'LOAD_DT' ,'SRC_SYS_CD' ,'LOAD_HR_TS', 'POLICY_KEY', 'POLICY_KEY_ID')
    trip_detail_seconds_df.createOrReplaceGlobalTempView('new_scrubbing')
    
    print('Merging into table: ' + str(datetime.now(tz)))
    spark.sql(f"insert into {harmonizedDB}.{target_table}  select distinct *from global_temp.new_scrubbing ")
    print('scrub_functionality completed : ' + str(datetime.now(tz)))
    return trip_detail_seconds_df

# COMMAND ----------

# microBatchDF = spark.sql("select  * from dhf_iot_harmonized_prod.trip_detail_seconds_chlg order by PSTN_TS limit 10")

# make_trip_detail_second(microBatchDF, 0, 'dhf_iot_harmonized_prod', 'dhf_iot_harmonized_prod', 'trip_detail_seconds')
