# Databricks notebook source
driver = "com.teradata.jdbc.TeraDriver"
url = "jdbc:teradata://nidbc.nwie.net/LOGMECH=LDAP"
user1 = dbutils.secrets.get(scope = "iot_system", key = "td-username")
password1 = dbutils.secrets.get(scope = "iot_system", key = "td-password")

# COMMAND ----------

PROP_NFCCNTL1_CTRL_SEG_REC_1_sql="""
select distinct
QUOTE_POL_NUM,
quote_user_id, 
quote_source_idfr, 
policy_type_001 
from (
select 
QUOTE_POL_NUM,
quote_user_id, 
quote_source_idfr, 
policy_type_001,
rank() over(partition by QUOTE_POL_NUM order by QUOTE_DATE_TIME_STAMP desc) as max_rank 
from stg_dqpc_db.PROP_NFCCNTL1_CTRL_SEG_REC_1 
where QUOTE_POL_NUM<>''
) A 
where max_rank=1
"""

# COMMAND ----------

PROP_PRDCR_PRODUCER_SEG_sql="""
select distinct
QUOTE_POL_NUM,
PDCR_OFFC_NAME_L102, 
PDCR_TYPE_L102 
from (
select 
QUOTE_POL_NUM,
PDCR_OFFC_NAME_L102, 
PDCR_TYPE_L102,
rank() over(partition by QUOTE_POL_NUM order by QUOTE_DATE_TIME_STAMP desc) as max_rank 
from stg_dqpc_db.PROP_PRDCR_PRODUCER_SEG 
where QUOTE_POL_NUM<>''
) A 
where max_rank=1
"""

# COMMAND ----------

PROP_NFCBASIC_BASIC_INFO_REC_sql="""
select distinct
QUOTE_POL_NUM,
POL_Term_01
from (
select 
QUOTE_POL_NUM,
POL_Term_01,
rank() over(partition by QUOTE_POL_NUM order by QUOTE_DATE_TIME_STAMP desc) as max_rank 
from stg_dqpc_db.PROP_NFCBASIC_BASIC_INFO_REC 
where QUOTE_POL_NUM<>''
) A 
where max_rank=1
"""

# COMMAND ----------

PROP_NFCLOCO3_LOCATION_2_COV_sql="""
select distinct
QUOTE_POL_NUM,
PROT_DEV_DISC_AMT_11, 
HOME_CAR_DISC_AMT_11
from (
select 
QUOTE_POL_NUM,
PROT_DEV_DISC_AMT_11, 
HOME_CAR_DISC_AMT_11,
rank() over(partition by QUOTE_POL_NUM order by QUOTE_DATE_TIME_STAMP desc) as max_rank 
from stg_dqpc_db.PROP_NFCLOCO3_LOCATION_2_COV 
where QUOTE_POL_NUM<>''
) A 
where max_rank=1
"""



# COMMAND ----------

E_PRODUCT_VW_sql="""
SELECT 
fullpolicy_nb, 
AcquisitionChannel_Ds, 
sc.DerivedChannel_ds AS ServiceChannel_ds, 
bp.effective_dt, 
CASE when bp.policyterm_ct = 1 then 'New Business' else 'Existing Business' END as NewRenewal_Flag
FROM RPT_FPER_APPS.A1_Basepolicy bp
JOIN	RPT_FPER_APPS.A1_X_LU_AcquisitionChannel	ac
ON 	(bp.PolicyBusinessKey_Id = ac.PolicyBusinessKey_Id)
JOIN	RPT_FPER_APPS.A1_BaseAgent	ba
ON 	(bp.Agent_Id = ba.Agent_Id)
JOIN	RPT_FPER_APPS.A1_X_LU_DerivedChannel	sc
ON 	(ba.ServicingChannel_Tp = sc.DerivedChannel_Tp)
WHERE  bp.Effective_Dt  <= CURRENT_DATE()
and bp.Expiration_Dt > CURRENT_DATE()
and bp.source_cd in ('NPRA', 'NPPS', 'APPS', 'PSAA')
"""
