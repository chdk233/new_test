# Databricks notebook source
import json
from decimal import Decimal
from datetime import datetime, timedelta
from pyspark.sql.types import StructType,StructField, TimestampType, DecimalType, StringType, DateType, LongType, IntegerType

td_schema = StructType([StructField('ENTRP_CUST_NB', StringType(), False),
                       StructField('DATA_CLCTN_ID', StringType(), False),
                       StructField('TRIP_SMRY_KEY', StringType(), False),
                       StructField('TRIP_LBL', StringType(), True),
                       StructField('TRIP_START_TS', TimestampType(), False),
                       StructField('TRIP_START_LAT_NB', DecimalType(18,10), False),
                       StructField('TRIP_START_LNGTD_NB', DecimalType(18,10), False),
                       StructField('TRIP_END_TS', TimestampType(), False),
                       StructField('TRIP_END_LAT_NB', DecimalType(18,10), False),
                       StructField('TRIP_END_LNGTD_NB', DecimalType(18,10), False),
                       StructField('TIME_ZONE_OFFST_NB', StringType(), True),
                       StructField('DRVNG_DISTNC_QTY_KM', DecimalType(15,6), True),
                       StructField('DRVNG_DISTNC_QTY_MILES', DecimalType(15,6), True),
                       StructField('WAYPOINTS_JSON_TT', StringType(), False),
                       StructField('EVENTS_JSON_TT', StringType(), False),
                       StructField('HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_VAL', DecimalType(35,15), False),
                       StructField('HNDHLD_DISTRCTN_RISK_DESC', StringType(), False),
                       StructField('PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_VAL', DecimalType(35,15), False),
                       StructField('PHN_HNDLNG_DISTRCTN_RISK_DESC', StringType(), False),
                       StructField('TRIPEVENTS_CT_JSON_TT', StringType(), False),
                       StructField('ETL_ROW_EFF_DTS', TimestampType(), False),
                       StructField('ETL_LAST_UPDT_DTS', TimestampType(), False),
                       StructField('SRC_SYS_CD', StringType(), False),
                       StructField('LOAD_DT', DateType(), False),
                       StructField('LOAD_HR_TS', TimestampType(), False),
                       StructField('POLICY_KEY', StringType(), True)])
MI_TO_KM = Decimal(1.609334)

# COMMAND ----------

def removeDuplicatesMicrobatchTripDigest_rdd(partitionedData):
  print(" entering removeduplicates microbatch function \n")
  data_by_trip = {}
  for row in partitionedData:
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  
  rows = []
  for tripId in data_by_trip:
    df = data_by_trip[tripId]
    i = 0
    for row in df:
      if i == 0:
        ecn = row['ENTRP_CUST_NB']
        tsk = row['TRNSCTN_ID']
        dci = row['DATA_CLCTN_ID']
        lbl = row['TRIP_LBL']
        rows.append(row)
      else:
        if row['TRNSCTN_ID'] == tsk and row['DATA_CLCTN_ID'] == dci and row['ENTRP_CUST_NB'] == ecn and (row['TRIP_LBL'] == lbl or (row['TRIP_LBL'] is None and lbl is None)) :
          pass
        else:
          rows.append(row)
          tsk = row['TRNSCTN_ID']
          dci = row['DATA_CLCTN_ID']
          lbl = row['TRIP_LBL']
          ecn = row['ENTRP_CUST_NB']
      i = i + 1
  print(" leaving removeduplicates microbatch function")
  return iter(rows)
      


# COMMAND ----------

def assemble_trip_digest(partitionData):
  str_format = "%Y-%m-%dT%H:%M:%S.%fZ"
  data_by_tsk = {}
  for row in partitionData:
    if row['TRIP_SMRY_KEY'] not in data_by_tsk:
      data_by_tsk[row['TRIP_SMRY_KEY']] = []
    data_by_tsk[row['TRIP_SMRY_KEY']].append(row)
    
  trip_digest = []
  for tsk in data_by_tsk:
    i = 0
    event_desc = []
    event_ct = []
    dep = 0
    harsh_brake = 0
    harsh_corn = 0
    harsh_acc = 0
    speeding = 0
    phone_mot = 0
    phone_call = 0
    tapping = 0
    tapping_h = 0
    idle_time = 0
    handheld = 0
    handsfree = 0
    events = "[]"
    offset = None
    ts_ts = datetime(1000,12,31)
    ts_lat = Decimal(0)
    ts_lon = Decimal(0)

    te_ts = datetime(9999,12,31)
    te_lat = Decimal(0)
    te_lon = Decimal(0)

    distnc_km = Decimal(0)
    distnc_mi = Decimal(0)

    waypts = "[]"
    tsk_data = data_by_tsk[tsk]
    for row in tsk_data:
      if i == 0:
        prevRow = row
      else:
        prevRow = currRow
      currRow = row
      tsk = row['TRIP_SMRY_KEY']
      entrp_nb = row['ENTRP_CUST_NB'] 
      dci = row['DATA_CLCTN_ID']
      trip_lbl = row['TRIP_LBL']
      runStart = row['ETL_ROW_EFF_DTS']
      plcy_nb = row['PLCY_NB']
      tid = row['TRNSCTN_ID']
      
      if row['TRIP_SUMMARY_JSON_DATA'] is not None:
        json_string = row['TRIP_SUMMARY_JSON_DATA'] 
        json_obj = json.loads(json_string)

        offset = int(json_obj['utc_offset'].split(':')[0])
        ts_ts = datetime.strptime(json_obj['start']['ts'], str_format)
        ts_lat = Decimal(json_obj['start']['lat'])
        ts_lon = Decimal(json_obj['start']['lon'])

        te_ts = datetime.strptime(json_obj['end']['ts'], str_format)
        te_lat = Decimal(json_obj['end']['lat'])
        te_lon = Decimal(json_obj['end']['lon'])

        distnc_km = Decimal(json_obj['distance_km'])
        distnc_mi = Decimal(distnc_km / MI_TO_KM)

        waypts = str(json_obj['waypoints'])
        
        event_desc = []
        dep = 0
        for event in json_obj['events']:
          if event['event_type'] == 1:
            event['event_type'] = 'Deprecated'
          elif event['event_type'] == 2:
            event['event_type'] = 'Harsh Braking'
          elif event['event_type'] == 3:
            event['event_type'] = 'Harsh Cornering'
          elif event['event_type'] ==4:
            event['event_type'] = 'Harsh Acceleration'
          elif event['event_type'] == 5:
            event['event_type'] = 'Speeding'
          elif event['event_type'] == 6:
            event['event_type'] = 'Phone Motion'
          elif event['event_type'] == 7:
            event['event_type'] = 'Phone Call'
          elif event['event_type'] == 8:
            event['event_type'] = 'Tapping'
          elif event['event_type'] == 9:
            event['event_type'] = 'Idle Time'
          else:
            event['event_type'] = 'Unexpected Event'
          event_desc.append(event)
          events = str(event_desc)
      
      event_ct = str([dict(
        deprecated_ct = row['DEPRECATED_CT'],
        harsh_braking_ct = row['HARSH_BRAKING_CT'],
        harsh_cornering_ct = row['HARSH_CORNERING_CT'],
        harsh_acceleration_ct = row['HARSH_ACCELERATION_CT'],
        speeding_ct = row['SPEEDING_CT'],
        phone_motion_ct = row['PHONE_MOTION_CT'],
        phone_call_ct = row['PHONE_CALL_CT'],
        handheld_ct = row['HANDHELD_CT'],
        handsfree_ct = row['HANDSFREE_CT'],
        phone_tapping_ct = row['TAPPING_CT'],
        phone_tapping_handling_ct = row['PHONE_HANDLING_CT'],
        idle_time_ct = row['IDLE_TIME_CT']
      )])
      
      if trip_lbl is not None and trip_lbl.lower() in ('car', 'driver'):
        hh_desc = row['HNDHLD_DISTRCTN_RISK_DESC'] if row['HNDHLD_DISTRCTN_RISK_DESC'] is not None else 'NOKEY'
        ph_desc = row['PHN_HNDLNG_DISTRCTN_RISK_DESC'] if row['PHN_HNDLNG_DISTRCTN_RISK_DESC'] is not None else 'NOKEY'
      elif trip_lbl is not None and trip_lbl.lower() == 'driver_no_distraction':
        hh_val = row['HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] if row['HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] is not None else Decimal(0)
        hh_desc = 'None'
        ph_val = row['PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] if row['PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] is not None else Decimal(0)
        ph_desc = 'None'
      else:
        hh_val = row['HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] if row['HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] is not None else Decimal(0)
        hh_desc = 'Not Applicable'
        ph_val = row['PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] if row['PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] is not None else Decimal(0)
        ph_desc = 'Not Applicable'

      hh_val = row['HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] if row['HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] is not None else Decimal(0)
      ph_val = row['PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] if row['PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_TP_VAL'] is not None else Decimal(0)
      src = row['SRC_SYS_CD'] if row['SRC_SYS_CD'] is not None else 'NOKEY'
      load_dt = row['LOAD_DT'] if row['LOAD_DT'] is not None else datetime(9999,12,31).date()
      load_hr = row['LOAD_HR_TS'] if row['LOAD_HR_TS'] is not None else datetime(9999,12,31)
      

      if i == 0:
        trip_digest.append([entrp_nb, dci, tsk, trip_lbl, ts_ts, ts_lat, ts_lon, te_ts, te_lat, te_lon, offset, distnc_km, distnc_mi, waypts, events, hh_val, hh_desc, ph_val, ph_desc, event_ct, runStart, runStart, src, load_dt, load_hr, 'NOKEY'])
      else:
        if prevRow['TRIP_LBL'] == currRow['TRIP_LBL'] and prevRow['ENTRP_CUST_NB'] == currRow['ENTRP_CUST_NB'] and prevRow['TRNSCTN_ID'] == prevRow['TRNSCTN_ID'] and prevRow['DATA_CLCTN_ID'] == prevRow['DATA_CLCTN_ID']:
          trip_digest.pop()
          trip_digest.append([entrp_nb, dci, tsk, trip_lbl, ts_ts, ts_lat, ts_lon, te_ts, te_lat, te_lon, offset, distnc_km, distnc_mi, waypts, events, hh_val, hh_desc, ph_val, ph_desc, event_ct, runStart, datetime.now(), src, load_dt, load_hr, 'NOKEY'])
        elif prevRow['ENTRP_CUST_NB'] == currRow['ENTRP_CUST_NB'] and prevRow['TRIP_SMRY_KEY'] == currRow['TRIP_SMRY_KEY'] and  prevRow['DATA_CLCTN_ID'] == currRow['DATA_CLCTN_ID'] and prevRow['TRIP_LBL'] != currRow['TRIP_LBL'] and prevRow['TRNSCTN_ID'] != currRow['TRNSCTN_ID'] and prevRow['TRIP_SUMMARY_JSON_DATA'] is not None:
          prevTD = trip_digest.pop()
          prevTD[3] = currRow['TRIP_LBL']
          prevTD[15] = hh_val 
          prevTD[16] = hh_desc
          prevTD[17] = ph_val
          prevTD[18] = ph_desc
          prevTD[21] = datetime.now()
          trip_digest.append(prevTD)
        elif prevRow['ENTRP_CUST_NB'] == currRow['ENTRP_CUST_NB'] and prevRow['TRIP_SMRY_KEY'] == currRow['TRIP_SMRY_KEY'] and  prevRow['DATA_CLCTN_ID'] == currRow['DATA_CLCTN_ID'] and prevRow['TRIP_LBL'] != currRow['TRIP_LBL'] and prevRow['TRNSCTN_ID'] != currRow['TRNSCTN_ID'] and prevRow['TRIP_SUMMARY_JSON_DATA'] is None:
          prevTD = trip_digest.pop()
          trip_digest.append([entrp_nb, dci, tsk, trip_lbl, ts_ts, ts_lat, ts_lon, te_ts, te_lat, te_lon, offset, distnc_km, distnc_mi, waypts, events, hh_val, hh_desc, ph_val, ph_desc, event_ct, prevTD[20], datetime.now(), src, load_dt, load_hr, 'NOKEY'])
        else:
          trip_digest.append([entrp_nb, dci, tsk, trip_lbl, ts_ts, ts_lat, ts_lon, te_ts, te_lat, te_lon, offset, distnc_km, distnc_mi, waypts, events, hh_val, hh_desc, ph_val, ph_desc, event_ct, runStart, runStart, src, load_dt, load_hr, 'NOKEY'])
  
      i = i + 1

  return iter(trip_digest)

# COMMAND ----------

def create_trip_digest(partitionedData):
  duplessRDD = removeDuplicatesMicrobatchTripDigest_rdd(partitionedData)
  tripDigestRDD = assemble_trip_digest(duplessRDD)
  return tripDigestRDD

# COMMAND ----------

def make_trip_digest(microBatchDF, batchId, harmonizedDB, curatedDB, target_table):
  curated_table = f"{curatedDB}.{target_table}"
  microBatchDF.createOrReplaceGlobalTempView("microBatchDF")
  df = spark.sql(f"select distinct *, dense_rank(TRIP_SMRY_KEY) over(order by TRIP_SMRY_KEY) as generated_trip_id from global_temp.microBatchDF order by TRIP_SMRY_KEY, DATA_CLCTN_ID, ENTRP_CUST_NB, TRNSCTN_ID, LOAD_DT")
  tsk_cnt = df.select('TRIP_SMRY_KEY').distinct().count()
  print(f"processing {tsk_cnt} trips")
  
  if tsk_cnt == 0:
    pass
  else:
    partitioned_df = df.repartition(tsk_cnt, "generated_trip_id").sortWithinPartitions("TRIP_SMRY_KEY", "DATA_CLCTN_ID", "ENTRP_CUST_NB", "TRNSCTN_ID", "LOAD_DT")
    td_rdd = partitioned_df.rdd.mapPartitions(create_trip_digest, preservesPartitioning=True)
    spark.createDataFrame(data=td_rdd, schema=td_schema).createOrReplaceTempView('new_trip_digest')
    spark.sql(f"""merge into {curated_table} trg using (select distinct *,cast(row_number() over (order by NULL) + coalesce((select max(TRIP_DIGEST_ID) from {curated_table}), 0) as BIGINT) as TRIP_DIGEST_ID, XXHASH64('NOKEY') as POLICY_KEY_ID from new_trip_digest ) src on trg.ENTRP_CUST_NB = src.ENTRP_CUST_NB and trg.DATA_CLCTN_ID = src.DATA_CLCTN_ID and trg.TRIP_SMRY_KEY = src.TRIP_SMRY_KEY when matched and trg.TRIP_LBL = src.TRIP_LBL then update set trg.ETL_LAST_UPDT_DTS = src.ETL_LAST_UPDT_DTS when matched and trg.TRIP_LBL != src.TRIP_LBL then update set trg.TRIP_LBL = src.TRIP_LBL, trg.HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_VAL = src.HNDHLD_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_VAL, trg.HNDHLD_DISTRCTN_RISK_DESC = src.HNDHLD_DISTRCTN_RISK_DESC, trg.PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_VAL = src.PHN_HNDLNG_DISTRCTN_CT_PER_HUND_KM_MODL_OTPT_VAL, trg.PHN_HNDLNG_DISTRCTN_RISK_DESC = src.PHN_HNDLNG_DISTRCTN_RISK_DESC, trg.ETL_LAST_UPDT_DTS = src.ETL_LAST_UPDT_DTS when not matched then insert *""")


# COMMAND ----------

# microBatchDF = spark.sql("select * from dhf_iot_curated_test.trip_digest_chlg ")
# make_trip_digest(microBatchDF, 0, 'dhf_iot_harmonized_dev', 'dhf_iot_curated_dev', 'trip_digest')
