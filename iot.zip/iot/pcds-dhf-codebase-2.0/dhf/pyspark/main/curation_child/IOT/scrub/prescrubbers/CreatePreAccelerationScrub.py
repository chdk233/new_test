# Databricks notebook source
# DBTITLE 1,Define Constants 
DEBUG_MISSING_TS_SCRUBBED_POSITION = "AS"
DEBUG_NULL_SPEED_SCRUBBED_POSITION = "NS"
DEBUG_NULL_RPM_SCRUBBED_POSITION = "NR"

# COMMAND ----------

def addMissingSeconds4(partitionData): 
  print('starting missing seconds ' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  list1=[]
  for tripid in data_by_trip:
    df1 = data_by_trip[tripid]
    i=0
    for row in df1:
      tripidscrub = row['TRIP_SMRY_KEY']
      offset = int(row['TIME_ZONE_OFFST_NUM'] / 100) if row['TIME_ZONE_OFFST_NUM'] is not None else 0
      offset_ts = row['PSTN_TS'] + timedelta(hours=offset)
      if i==0:
        prev_row = row
        list1.append({"ENRLD_VIN_NB":row["ENRLD_VIN_NB"],"TRIP_SMRY_KEY":row["TRIP_SMRY_KEY"],"DEVC_KEY":row["DEVC_KEY"],"PSTN_TS":row['PSTN_TS'], "PSTN_OFFST_TS":offset_ts, "TIME_ZONE_OFFST_NUM":row["TIME_ZONE_OFFST_NUM"],"SPD_KPH_RT":row['SPD_KPH_RT'],"ENGIN_RPM_RT":row['ENGIN_RPM_RT'], "SCRBD_FLD_DESC":'', "LAT_NB":row["LAT_NB"],"LNGTD_NB":row["LNGTD_NB"],"SRC_SYS_CD":row["SRC_SYS_CD"] ,"MSSNG_TOO_MANY_SEC_FLAG":row["MSSNG_TOO_MANY_SEC_FLAG"], "LOAD_DT":row["LOAD_DT"], "LOAD_HR_TS":row["LOAD_HR_TS"],"PLCY_RT_ST_CD":row["PLCY_RT_ST_CD"],"POLICY_KEY":row["POLICY_KEY"],"POLICY_KEY_ID":row["POLICY_KEY_ID"]})
      else:
        y=1
        while (row['PSTN_TS']-prev_row['PSTN_TS']).seconds > y:
          added_seconds = timedelta(0, y)
          new_time = prev_row['PSTN_TS'] + added_seconds
          new_offset_ts = new_time + timedelta(hours=offset)
          list1.append({"ENRLD_VIN_NB":row["ENRLD_VIN_NB"],"TRIP_SMRY_KEY":row["TRIP_SMRY_KEY"],"DEVC_KEY":row["DEVC_KEY"],"PSTN_TS":new_time, "PSTN_OFFST_TS":new_offset_ts, "TIME_ZONE_OFFST_NUM":row["TIME_ZONE_OFFST_NUM"],"SPD_KPH_RT":None,"ENGIN_RPM_RT":None, "SCRBD_FLD_DESC":DEBUG_MISSING_TS_SCRUBBED_POSITION, "LAT_NB":prev_row["LAT_NB"],"LNGTD_NB":prev_row["LNGTD_NB"],"SRC_SYS_CD":row["SRC_SYS_CD"] ,"MSSNG_TOO_MANY_SEC_FLAG":row["MSSNG_TOO_MANY_SEC_FLAG"], "LOAD_DT":row["LOAD_DT"], "LOAD_HR_TS":row["LOAD_HR_TS"],"PLCY_RT_ST_CD":row["PLCY_RT_ST_CD"],"POLICY_KEY":row["POLICY_KEY"],"POLICY_KEY_ID":row["POLICY_KEY_ID"]})
          y=y+1
        list1.append({"ENRLD_VIN_NB":row["ENRLD_VIN_NB"],"TRIP_SMRY_KEY":row["TRIP_SMRY_KEY"],"DEVC_KEY":row["DEVC_KEY"],"PSTN_TS":row['PSTN_TS'], "PSTN_OFFST_TS":offset_ts, "TIME_ZONE_OFFST_NUM":row["TIME_ZONE_OFFST_NUM"],"SPD_KPH_RT":row['SPD_KPH_RT'],"ENGIN_RPM_RT":row['ENGIN_RPM_RT'], "SCRBD_FLD_DESC":'', "LAT_NB":row["LAT_NB"],"LNGTD_NB":row["LNGTD_NB"],"SRC_SYS_CD":row["SRC_SYS_CD"] ,"MSSNG_TOO_MANY_SEC_FLAG":row["MSSNG_TOO_MANY_SEC_FLAG"], "LOAD_DT":row["LOAD_DT"], "LOAD_HR_TS":row["LOAD_HR_TS"],"PLCY_RT_ST_CD":row["PLCY_RT_ST_CD"],"POLICY_KEY":row["POLICY_KEY"],"POLICY_KEY_ID":row["POLICY_KEY_ID"]})
      prev_row = row
      
      i=i+1
    print('ending missing seconds ' + str(datetime.now(tz)))
  return iter(list1)

# COMMAND ----------

def addMissingSpeed3(partitionData):
  print('starting missing speed' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_trip=[]
  for tripid in data_by_trip:
    data_by_trip_list = data_by_trip[tripid]
    trip_len = len(data_by_trip_list)
    df1=[]
    for r_num,trip_dict in enumerate(data_by_trip_list):
      trip_dict['row_number']=r_num+1
      trip_dict['ORGNL_SPD_RT']=trip_dict['SPD_KPH_RT']
      if (trip_dict['row_number'] ==1 or trip_dict['row_number'] ==trip_len) and trip_dict['SPD_KPH_RT'] is None:
        trip_dict['SPD_KPH_RT']= Decimal('0')
        trip_dict['SCRBD_FLD_DESC'] = f"{trip_dict['SCRBD_FLD_DESC']}{DEBUG_NULL_SPEED_SCRUBBED_POSITION}"
      if trip_dict['SPD_KPH_RT'] is None:
        trip_dict['SCRBD_FLD_DESC']= f"{trip_dict['SCRBD_FLD_DESC']}{DEBUG_NULL_SPEED_SCRUBBED_POSITION}"
      df1.append(trip_dict)
    i=0
    y=0
    for row in df1:
      if i == 0:
        prev_time = row['PSTN_TS']
        prev_speed = row['SPD_KPH_RT']
        timebeforenull = prev_time
        speedbeforenull = prev_speed
      else:
        current_time = prev_time
        current_speed = prev_speed
        next_time = row["PSTN_TS"]
        next_speed = row["SPD_KPH_RT"]
        prev_time = next_time 
        prev_speed = next_speed
        if next_speed is None and y==0:
          y=y-1
          timebeforenull = current_time
          speedbeforenull = current_speed
          nullstartindex = i
        elif next_speed is None and y < 0:
          y = y-1
        elif next_speed is not None and y < 0:
          y=0
          timeafternull = next_time
          speedafternull = next_speed
          new_speed = Decimal((speedafternull-speedbeforenull)/(timeafternull-timebeforenull).seconds)
          return_list=[]
          for trip_dict in df1:
            if trip_dict['SPD_KPH_RT'] is None and trip_dict['row_number']< i+1:
              spd_kph_rt_t=((trip_dict['row_number']-nullstartindex)*new_speed)+speedbeforenull
              if (spd_kph_rt_t-math.floor(spd_kph_rt_t))>=Decimal(0.5):
                trip_dict['SPD_KPH_RT']=Decimal(math.ceil(((trip_dict['row_number']-nullstartindex)*new_speed)+speedbeforenull))
              else:
                trip_dict['SPD_KPH_RT']=Decimal(builtins.round(((trip_dict['row_number']-nullstartindex)*new_speed)+speedbeforenull))
            return_list.append(trip_dict)
          df1=return_list
        else:
          pass
      i = i + 1
    return_trip.extend(df1)
    print('ending missing speed' + str(datetime.now(tz)))
  return iter(return_trip)

# COMMAND ----------

def addMissingRPM3(partitionData):
  print('adding missing rpms ' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_trip=[]
  for tripid in data_by_trip:
    data_by_trip_list = data_by_trip[tripid]
    trip_len = len(data_by_trip_list)
    df1=[]
    for r_num,trip_dict in enumerate(data_by_trip_list):
      trip_dict['row_number']=r_num+1
      trip_dict['ORGNL_RPM_RT']=trip_dict['ENGIN_RPM_RT']
      if (trip_dict['row_number'] ==1 or trip_dict['row_number'] ==trip_len) and trip_dict['ENGIN_RPM_RT'] is None:
        trip_dict['ENGIN_RPM_RT']= Decimal(0)
        trip_dict['SCRBD_FLD_DESC']= f"{trip_dict['SCRBD_FLD_DESC']}{DEBUG_NULL_RPM_SCRUBBED_POSITION}"
      if trip_dict['ENGIN_RPM_RT'] is None:
        trip_dict['SCRBD_FLD_DESC']= f"{trip_dict['SCRBD_FLD_DESC']}{DEBUG_NULL_RPM_SCRUBBED_POSITION}"
      df1.append(trip_dict)
    i=0
    y=0
    for row in df1:
      if i == 0:
        prev_time = row['PSTN_TS']
        prev_rpm = row['ENGIN_RPM_RT']
        timebeforenull = prev_time
        rpmbeforenull = prev_rpm
      else:
        current_time = prev_time
        current_rpm = prev_rpm
        next_time = row["PSTN_TS"]
        next_rpm = row["ENGIN_RPM_RT"]
        prev_time = next_time 
        prev_rpm = next_rpm
        if next_rpm is None and y==0:
          y=y-1
          timebeforenull = current_time
          rpmbeforenull = current_rpm
          nullstartindex = i
        elif next_rpm is None and y < 0:
          y = y-1
        elif next_rpm is not None and y < 0:
          y=0
          timeafternull = next_time
          rpmafternull = next_rpm
          new_rpm=Decimal((rpmafternull-rpmbeforenull)/(timeafternull-timebeforenull).seconds)
          return_list=[]
          for trip_dict in df1:
            if trip_dict['ENGIN_RPM_RT'] is None and trip_dict['row_number']< i+1:
              engin_rpm_rt_t = (((trip_dict['row_number']-nullstartindex)*new_rpm)+rpmbeforenull) / 10
              if (engin_rpm_rt_t-math.floor(engin_rpm_rt_t)) >= Decimal(0.5):
                trip_dict['ENGIN_RPM_RT'] = Decimal(math.ceil((((trip_dict['row_number']-nullstartindex)*new_rpm)+rpmbeforenull) / 10) * 10)
              else:
                trip_dict['ENGIN_RPM_RT']=Decimal(builtins.round((((trip_dict['row_number']-nullstartindex)*new_rpm)+rpmbeforenull) / 10) * 10)
            return_list.append(trip_dict)
          df1=return_list
        else:
          pass
      i = i + 1
    return_trip.extend(df1)
    print('done adding rpm' + str(datetime.now(tz)))
  return iter(return_trip)

