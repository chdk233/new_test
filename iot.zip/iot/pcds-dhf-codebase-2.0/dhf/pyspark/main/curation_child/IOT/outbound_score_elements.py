# Databricks notebook source
print("calling the python outbound_score_elements child notebook")

# COMMAND ----------

from datetime import datetime
import dateutil

# COMMAND ----------

def smartmiles_score_df(harmonizedDB,curateDB):
  smartmiles_df=spark.sql(f"""SELECT
b.PRGRM_INSTC_ID
,a.SRC_SYS_CD
,device.DEVC_KEY
,a.ENRLD_VIN_NB
,cast(max(a.PE_END_TS) as string) as MAX_PE_END_TS
,sum(DRVNG_SC_CT) as DRVNG_SC_CT
,sum(FAST_ACLRTN_CT) AS FAST_ACLRTN_CT
,sum(HARD_BRKE_CT) AS HARD_BRKE_CT
,sum(PLSBL_MILE_CT) AS PLSBL_MILE_CT
,sum(ADJST_MILE_CT) AS ADJST_MILE_CT
,sum(PLSBL_DRIV_SC_CT) AS PLSBL_DRIV_SC_CT
,sum(PLSBL_IDLE_SC_CT) AS PLSBL_IDLE_SC_CT
,(sum(PLSBL_DRIV_SC_CT) - sum(PLSBL_IDLE_SC_CT)) AS no_idle_time
,CASE WHEN sum(DRVNG_SC_CT)= 0 THEN 0.0 ELSE CAST (round((sum(PLSBL_DRIV_SC_CT)/sum(DRVNG_SC_CT)) * 100,2) AS double) END  AS plausible_percentage
,b.PLCY_ST_CD
,coalesce(b.POLICY_KEY, 'NOKEY') as POLICY_KEY
,coalesce(b.POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
,least(cast((sum(ADJST_MILE_CT*1.60934)/sum(MILE_CT*1.60934)) as double),1.5) as weighted_time_of_day
,greatest(0.000000001,least(2.0,cast(sum(STOP_SC_CT)/sum(MILE_CT*1.60934) as decimal(35,15)))) as STOPS_PER_KM_RT
,greatest(0.000000001,least(2.0,cast(sum(HARD_BRKE_CT)/sum(MILE_CT*1.60934) as decimal(35,15)))) as BRAKES_PER_KM_RT
,max(a.LOAD_HR_TS) AS LOAD_HR_TS
,max(a.LOAD_DT) AS LOAD_DT
from  ( 
	select	* 
	from	{curateDB}.trip_detail trips 
	inner join (select distinct enrld_vin_nb as mb_vin_nb,src_sys_cd as source from global_temp.microBatch) micro_batch 
		on trips.enrld_vin_nb = micro_batch.mb_vin_nb and trips.src_sys_cd=micro_batch.source) a

inner join
(
    select
    VIN_NB,
    PRGRM_INSTC_ID,
    ENRLMNT_STRT_DT,
    ENRLMNT_END_DT,
    PLCY_ST_CD,
    coalesce(POLICY_KEY, 'NOKEY') as POLICY_KEY,
    coalesce(POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
    from {harmonizedDB}.integrated_enrollment where CRNT_ENRLMNT_FLG = 'Y' and ENRLMNT_STTS = 'Active'
) b
on a.ENRLD_VIN_NB = trim(b.VIN_NB)
inner join 
{curateDB}.device_summary device
ON device.ENRLD_VIN_NB = a.ENRLD_VIN_NB 
    
where  trim(b.PLCY_ST_CD) <> 'CA'
AND device.DATA_CLCTN_ID IS NOT NULL
and a.PE_STRT_TS between b.ENRLMNT_STRT_DT and b.ENRLMNT_END_DT
and a.PE_STRT_TS  BETWEEN device.DEVC_STTS_FRST_TS AND device.DEVC_STTS_LAST_TS
AND a.SRC_SYS_CD like '%SM%'
group by b.PRGRM_INSTC_ID,a.SRC_SYS_CD,device.DEVC_KEY,a.ENRLD_VIN_NB,b.PLCY_ST_CD,b.POLICY_KEY,b.POLICY_KEY_ID""")
  return smartmiles_df
  

# COMMAND ----------

def smartride_score_df(harmonizedDB,curateDB):
  current_date = datetime.now()
  print(f"Current Date is : {current_date}")
  date_filter_18_mo_ago = (current_date-dateutil.relativedelta.relativedelta(months=18)).strftime("%Y-%m-%d")
  print(f"date_filter_18_mo_ago : {date_filter_18_mo_ago}")
  smartride_df=spark.sql(f"""SELECT
b.PRGRM_INSTC_ID
,a.SRC_SYS_CD
,cast(device.devc_key as bigint) as DEVC_KEY
,a.ENRLD_VIN_NB
,cast(max(a.PE_END_TS) as string) as MAX_PE_END_TS
,sum(DRVNG_SC_CT) as DRVNG_SC_CT
,sum(FAST_ACLRTN_CT) AS FAST_ACLRTN_CT
,sum(HARD_BRKE_CT) AS HARD_BRKE_CT
,sum(PLSBL_MILE_CT) AS PLSBL_MILE_CT
,sum(ADJST_MILE_CT) AS ADJST_MILE_CT
,sum(PLSBL_DRIV_SC_CT) AS PLSBL_DRIV_SC_CT
,sum(PLSBL_IDLE_SC_CT) AS PLSBL_IDLE_SC_CT
,(sum(PLSBL_DRIV_SC_CT) - sum(PLSBL_IDLE_SC_CT)) AS no_idle_time
,CASE WHEN sum(DRVNG_SC_CT)= 0 THEN 0.0 ELSE CAST (round((sum(PLSBL_DRIV_SC_CT)/sum(DRVNG_SC_CT)) * 100,2) AS double) END  AS plausible_percentage
,b.PLCY_ST_CD
,coalesce(b.POLICY_KEY, 'NOKEY') as POLICY_KEY
,coalesce(b.POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
,least(cast((sum(ADJST_MILE_CT*1.60934)/sum(MILE_CT*1.60934)) as double),1.5) as weighted_time_of_day
,greatest(0.000000001,least(2.0,cast(sum(STOP_SC_CT)/sum(MILE_CT*1.60934) as decimal(35,15)))) as STOPS_PER_KM_RT
,greatest(0.000000001,least(2.0,cast(sum(HARD_BRKE_CT)/sum(MILE_CT*1.60934) as decimal(35,15)))) as BRAKES_PER_KM_RT
,max(a.LOAD_HR_TS) AS LOAD_HR_TS
,max(a.LOAD_DT) AS LOAD_DT
from  ( 
	select	* 
	from	{curateDB}.trip_detail trips 
	inner join (select distinct enrld_vin_nb as mb_vin_nb,src_sys_cd as source from global_temp.microBatch) micro_batch 
		on trips.enrld_vin_nb = micro_batch.mb_vin_nb and trips.src_sys_cd=micro_batch.source) a

inner join
(
    select
    VIN_NB,
    PRGRM_INSTC_ID,
    ENRLMNT_STRT_DT,
    ENRLMNT_END_DT,
    PLCY_ST_CD,
    coalesce(POLICY_KEY, 'NOKEY') as POLICY_KEY,
    coalesce(POLICY_KEY_ID, XXHASH64('NOKEY')) as POLICY_KEY_ID
    from {harmonizedDB}.integrated_enrollment where CRNT_ENRLMNT_FLG = 'Y' and ENRLMNT_STTS = 'Active' and ENRLMNT_STRT_DT >= '{date_filter_18_mo_ago}'
) b
on a.ENRLD_VIN_NB = trim(b.VIN_NB)
inner join 
{curateDB}.device_summary device
ON device.ENRLD_VIN_NB = a.ENRLD_VIN_NB 
    
where trim( b.PLCY_ST_CD) <> 'CA'
and a.PE_STRT_TS between b.ENRLMNT_STRT_DT and b.ENRLMNT_END_DT
and device.PRGRM_INSTC_ID IS NOT NULL
and a.PE_STRT_TS  BETWEEN device.DEVC_STTS_FRST_TS AND device.DEVC_STTS_LAST_TS
AND a.SRC_SYS_CD in ('IMS_SR_4X','IMS_SR_5X','FMC_SR','TIMS_SR')
group by b.PRGRM_INSTC_ID,a.SRC_SYS_CD,cast(device.devc_key as bigint),a.ENRLD_VIN_NB,b.PLCY_ST_CD,b.POLICY_KEY,b.POLICY_KEY_ID""")
  return smartride_df

# COMMAND ----------

def final_score(view,curateDB):
  combined_df=spark.sql(f""" 
select distinct	cast(device.DEVC_KEY as string) as DEVC_KEY, device.ENRLD_VIN_NB as ENRLD_VIN_NB,
		cast(device.PRGRM_INSTC_ID as bigint) as PRGRM_INSTC_ID, device.DATA_CLCTN_ID as DATA_CLCTN_ID, trip.SRC_SYS_CD as SRC_SYS_CD,
		 MAX_PE_END_TS, cast(current_timestamp() as string) as TRANSACTION_TS,
		cast(device.DEVC_STTS_FRST_TS as string) as SCR_STRT_DT, cast(device.DEVC_STTS_LAST_TS as string) as SCR_END_DT,
		cast(device.LIFETM_DAYS_CT as int) as SCR_DAYS_CT, cast(device.CNCTD_DAYS_CT as BIGINT) as DAYS_INSTL_CT,
		cast(
		case 
			when ADJST_MILE_CT is Null then 0.0 
			else ADJST_MILE_CT 
		end as decimal(35,15)) as ADJST_MILES_QTY, cast(
		case 
			when PLSBL_MILE_CT is null then 0.0 
			else PLSBL_MILE_CT 
		end as decimal(35,15)) as SCRBD_MILES_QTY, cast(
		case 
			when ADJST_MILE_CT is Null then 0.0 
			else ADJST_MILE_CT end/CNCTD_DAYS_CT as decimal(35,15)) as AVG_DISTNC_QTY,
		cast (
		case 
			when CNCTD_DAYS_CT = 0 then 0.0 
			when ( 
		case 
			when HARD_BRKE_CT is null then 0 
			else cast(HARD_BRKE_CT as INT) end /CNCTD_DAYS_CT)> 7.0 then 7.0 
			else (
		case 
			when HARD_BRKE_CT is null then 0 
			else cast(HARD_BRKE_CT as INT) end/CNCTD_DAYS_CT) 
		end as decimal(35,15)) as HARD_BRK_PCTG_DISC_VAL, cast (
		case 
			when CNCTD_DAYS_CT = 0 then 0.0 
			when (
		case 
			when FAST_ACLRTN_CT is null then 0 
			else cast(FAST_ACLRTN_CT as int) end/CNCTD_DAYS_CT)> 4.0 then 4.0 
			else (
		case 
			when FAST_ACLRTN_CT is null then 0 
			else cast(FAST_ACLRTN_CT as int) end/CNCTD_DAYS_CT) 
		end as decimal(35,15)) as FAST_ACLRTN_PCTG_DISC_VAL, cast(
		case 
			when (PLSBL_IDLE_SC_CT is null 
	or (PLSBL_DRIV_SC_CT - PLSBL_IDLE_SC_CT) is null) then 0.0 
			else (PLSBL_IDLE_SC_CT/(PLSBL_IDLE_SC_CT+(PLSBL_DRIV_SC_CT - PLSBL_IDLE_SC_CT))) 
		end as decimal(35,15)) as IDLE_TIME_PCTG,cast(device.DEVC_CNCTD_PCT as decimal(35,15)) as INSTL_PCTG,
		cast(
		case 
			when (
		case 
			when DRVNG_SC_CT= 0 then 0.0 
			else cast (round((PLSBL_DRIV_SC_CT/DRVNG_SC_CT) * 100,2) as double) end) is null then 100.00 
			else (
		case 
			when DRVNG_SC_CT= 0 then 0.0 
			else cast (round((PLSBL_DRIV_SC_CT/DRVNG_SC_CT) * 100,2) as double) end) 
		end as decimal(35,15)) as PLSBL_DRIV_PCTG, cast(weighted_time_of_day as decimal(35,15)) as WGHT_TIME_OF_DY_RT,
		 STOPS_PER_KM_RT,
		BRAKES_PER_KM_RT,
		cast(device.DEVC_DSCNCTD_PCT as decimal(35,15)) as DSCNCTD_TIME_PCTG,
		cast(
		case 
			when (CNCTD_DAYS_CT is null 
	or CNCTD_DAYS_CT = 0.0) then 0.0 
			else (((
		case 
			when PLSBL_MILE_CT is null then 0.0 
			else PLSBL_MILE_CT end)/CNCTD_DAYS_CT) * 365) 
		end as decimal(35,15)) as ANNL_MILG_QTY, concat(concat(LPAD(trim(cast(if (device.CNCTD_STTS_CT is null,' ',device.CNCTD_STTS_CT) as varchar(3))),3,'000'),'_'),LPAD(trim(cast(if (device.DSCNCTD_STTS_CT is null,' ',device.DSCNCTD_STTS_CT) as varchar(3))),3,'000'))  as CNCT_DSCNCT_CT, cast(device.DSCNCTD_SC_CT as BIGINT) as UNINSTL_DAYS_CT,
		trip.LOAD_DT as LOAD_DT, trip.LOAD_HR_TS,trip.POLICY_KEY,trip.POLICY_KEY_ID  
from	{view} trip 
INNER JOIN {curateDB}.device_summary device
	ON device.ENRLD_VIN_NB = trip.ENRLD_VIN_NB and device.src_sys_cd = trip.src_sys_cd
""")
  return combined_df

# COMMAND ----------

def outbound_score_elements(microBatchDF, batchId, harmonizedDB, curateDB, target_table):
  print("\n entering test_curation_child \n")
  curate_table = curateDB +"."+target_table
  print("---curate table--",curate_table)
  print("---curateDB----",curateDB)

  
#   microBatchDF.createOrReplaceGlobalTempView("microBatch")
  
  missing_vins=spark.sql(f"select distinct ENRLD_VIN_NB,src_sys_cd from (select ENRLD_VIN_NB,src_sys_cd,max(PE_END_TS) as pe_end_ts from {curateDB}.trip_detail where   load_dt>=current_date-5 group by ENRLD_VIN_NB,src_sys_cd) a left join (select  ENRLD_VIN_NB as vin,src_sys_cd as src ,max(MAX_PE_END_TS) as MAX_PE_END_TS from {curateDB}.outbound_score_elements where load_dt>=current_date-5 group by ENRLD_VIN_NB,src_sys_cd) b on a.ENRLD_VIN_NB=b.vin and a.src_sys_cd=b.src where (a.pe_end_ts!=b.MAX_PE_END_TS or b.MAX_PE_END_TS is null)")
  
  microBatchDF.select("ENRLD_VIN_NB","src_sys_cd").union(missing_vins).distinct().createOrReplaceGlobalTempView("microBatch")
  #display(spark.sql("select * from global_temp.microBatch")) 

  current_date = datetime.now()
  print(f"Current Date is : {current_date}")
  date_filter_18_mo_ago = (current_date-dateutil.relativedelta.relativedelta(months=18)).strftime("%Y-%m-%d")
  print(f"date_filter_18_mo_ago : {date_filter_18_mo_ago}")

  if ('dev') in harmonizedDB:
    env = 'dev'
  elif ('test') in harmonizedDB:
    env = 'test'
  elif ('prod') in harmonizedDB:
    env = 'prod'
    
  harmonizedDB = ('dhf_iot_harmonized_' + env)
  
  smartmiles_score_df(harmonizedDB,curateDB).createOrReplaceTempView("smartmiles_view")
  final_score("smartmiles_view",curateDB).createOrReplaceGlobalTempView("smartmilesdf")
  smartmiles_df=spark.sql(f"""select *,row_number() over (partition by DATA_CLCTN_ID,SRC_SYS_CD,devc_key,ENRLD_VIN_NB,MAX_PE_END_TS order by MAX_PE_END_TS desc) as rownb from (select a.* from global_temp.smartmilesdf a  left join (select  ENRLD_VIN_NB as vin,src_sys_cd as src ,max(MAX_PE_END_TS) as PE_END_TS from {curateDB}.outbound_score_elements  where src_sys_cd like '%SM%' group by ENRLD_VIN_NB,src_sys_cd) b on a.ENRLD_VIN_NB=b.vin and a.src_sys_cd=b.src where (a.MAX_PE_END_TS!=b.PE_END_TS or b.PE_END_TS is null))""").filter("rownb=1").drop("rownb")

  
  smartride_score_df(harmonizedDB,curateDB).createOrReplaceTempView("smartride_view")
  final_score("smartride_view",curateDB).createOrReplaceGlobalTempView("smartridedf")
  smartride_df=spark.sql(f"""select *,row_number() over (partition by PRGRM_INSTC_ID,SRC_SYS_CD,devc_key,ENRLD_VIN_NB,MAX_PE_END_TS order by MAX_PE_END_TS desc) as rownb from (select a.* from global_temp.smartridedf a  left join (select  ENRLD_VIN_NB as vin,src_sys_cd as src ,max(MAX_PE_END_TS) as PE_END_TS from {curateDB}.outbound_score_elements where src_sys_cd like '%SR%'  group by ENRLD_VIN_NB,src_sys_cd) b on a.ENRLD_VIN_NB=b.vin and a.src_sys_cd=b.src where (a.MAX_PE_END_TS!=b.PE_END_TS or b.PE_END_TS is null))""").filter("rownb=1").drop("rownb")
	
  print("After sql -------------------------------")
  print("\n count of smartmiles: ",smartmiles_df.count())
  if(smartmiles_df.count()):
    maxSK = spark.table(f"{curate_table}").count()
    w  = Window.orderBy("devc_key","ENRLD_VIN_NB","MAX_PE_END_TS","TRANSACTION_TS")
    SM_df1 = smartmiles_df.withColumn("OUTBOUND_SCORE_ELEMENTS_ID", (row_number().over(w)+ maxSK).cast(LongType()))
    print("writing to table ",curate_table)
#     SM_df1.write.format("delta").mode("append").partitionBy("LOAD_DT","LOAD_HR_TS").saveAsTable(f"{curate_table}")
#     SM_df1.createOrReplaceGlobalTempView('new_sm_outbound_elements')
#     spark.sql(f"merge into {curate_table} target using (select distinct * from global_temp.new_sm_outbound_elements) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.DEVC_KEY = updates.DEVC_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.DATA_CLCTN_ID = updates.DATA_CLCTN_ID and target.TRANSACTION_TS = updates.TRANSACTION_TS and target.MAX_PE_END_TS = updates.MAX_PE_END_TS when not matched then insert *")
  
    finalDF_SM = SM_df1.withColumn("key",col("ENRLD_VIN_NB")).withColumn("PRGRM_INSTC_ID",lit(0)).withColumn("AggregateTrips",expr("to_json(struct(OUTBOUND_SCORE_ELEMENTS_ID ,DEVC_KEY ,ENRLD_VIN_NB ,PRGRM_INSTC_ID , DATA_CLCTN_ID, SRC_SYS_CD ,TRANSACTION_TS ,MAX_PE_END_TS ,SCR_STRT_DT ,SCR_END_DT ,SCR_DAYS_CT ,DAYS_INSTL_CT ,ADJST_MILES_QTY ,SCRBD_MILES_QTY ,AVG_DISTNC_QTY,HARD_BRK_PCTG_DISC_VAL ,FAST_ACLRTN_PCTG_DISC_VAL ,IDLE_TIME_PCTG ,INSTL_PCTG ,PLSBL_DRIV_PCTG ,WGHT_TIME_OF_DY_RT ,STOPS_PER_KM_RT ,BRAKES_PER_KM_RT ,DSCNCTD_TIME_PCTG,ANNL_MILG_QTY ,CNCT_DSCNCT_CT ,UNINSTL_DAYS_CT))")).withColumn("value",expr("to_json(struct(AggregateTrips))")).selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
  

    if ('test') in harmonizedDB:
      finalDF_SM.write.format("kafka").option("kafka.bootstrap.servers", "event-streaming-pt-kb.aws.e1.nwie.net:9092").option("kafka.security.protocol","SSL").option("kafka.ssl.truststore.location", "/dbfs/FileStore/iottelematics/smsr/iot_test_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.truststore.password", "iot_test_smsr_aggtrips_to_mf_producer").option("kafka.ssl.keystore.location", "/dbfs/FileStore/iottelematics/smsr/iot_test_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.keystore.password", "iot_test_smsr_aggtrips_to_mf_producer").option("kafka.ssl.key.password", "iot_test_smsr_aggtrips_to_mf_producer").option("topic", "system.policy-management.iot-aggregate-trips.v1.test").save()
      SM_df1.createOrReplaceGlobalTempView('new_sm_outbound_elements')
      spark.sql(f"merge into {curate_table} target using (select distinct * from global_temp.new_sm_outbound_elements) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.DEVC_KEY = updates.DEVC_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.DATA_CLCTN_ID = updates.DATA_CLCTN_ID and target.TRANSACTION_TS = updates.TRANSACTION_TS and target.MAX_PE_END_TS = updates.MAX_PE_END_TS when not matched then insert *")
    
    if ('prod') in harmonizedDB:
      finalDF_SM.write.format("kafka").option("kafka.bootstrap.servers", "event-streaming-kb.aws.e1.nwie.net:9092").option("kafka.security.protocol","SSL").option("kafka.ssl.truststore.location", "/dbfs/FileStore/iottelematics/smsr/iot_prod_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.truststore.password", "iot_prod_smsr_aggtrips_to_mf_producer").option("kafka.ssl.keystore.location", "/dbfs/FileStore/iottelematics/smsr/iot_prod_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.keystore.password", "iot_prod_smsr_aggtrips_to_mf_producer").option("kafka.ssl.key.password", "iot_prod_smsr_aggtrips_to_mf_producer").option("topic", "system.policy-management.iot-aggregate-trips.v1").save()
      SM_df1.createOrReplaceGlobalTempView('new_sm_outbound_elements')
      spark.sql(f"merge into {curate_table} target using (select distinct * from global_temp.new_sm_outbound_elements) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.DEVC_KEY = updates.DEVC_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.DATA_CLCTN_ID = updates.DATA_CLCTN_ID and target.TRANSACTION_TS = updates.TRANSACTION_TS and target.MAX_PE_END_TS = updates.MAX_PE_END_TS when not matched then insert *")
  
  print("\n count of smartride: ",smartride_df.count())
  if(smartride_df.count()):
    maxSK = spark.table(f"{curate_table}").count()
    w  = Window.orderBy("devc_key","ENRLD_VIN_NB","MAX_PE_END_TS","TRANSACTION_TS")
    SR_df1 = smartride_df.withColumn("OUTBOUND_SCORE_ELEMENTS_ID", (row_number().over(w)+ maxSK).cast(LongType()))
    
#     SR_df1.write.format("delta").mode("append").partitionBy("LOAD_DT","LOAD_HR_TS").saveAsTable(f"{curate_table}")
#     SR_df1.createOrReplaceGlobalTempView('new_sr_outbound_elements')
#     spark.sql(f"merge into {curate_table} target using (select distinct * from global_temp.new_sr_outbound_elements) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.DEVC_KEY = updates.DEVC_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.PRGRM_INSTC_ID = updates.PRGRM_INSTC_ID and target.TRANSACTION_TS = updates.TRANSACTION_TS and target.MAX_PE_END_TS = updates.MAX_PE_END_TS when not matched then insert *")

    finalDF_SR = SR_df1.withColumn("key",col("ENRLD_VIN_NB")).withColumn("AggregateTrips",expr("to_json(struct(OUTBOUND_SCORE_ELEMENTS_ID ,DEVC_KEY ,ENRLD_VIN_NB ,PRGRM_INSTC_ID , DATA_CLCTN_ID, SRC_SYS_CD ,TRANSACTION_TS ,MAX_PE_END_TS ,SCR_STRT_DT ,SCR_END_DT ,SCR_DAYS_CT ,DAYS_INSTL_CT ,ADJST_MILES_QTY ,SCRBD_MILES_QTY ,AVG_DISTNC_QTY,HARD_BRK_PCTG_DISC_VAL ,FAST_ACLRTN_PCTG_DISC_VAL ,IDLE_TIME_PCTG ,INSTL_PCTG ,PLSBL_DRIV_PCTG ,WGHT_TIME_OF_DY_RT ,STOPS_PER_KM_RT ,BRAKES_PER_KM_RT ,DSCNCTD_TIME_PCTG,ANNL_MILG_QTY ,CNCT_DSCNCT_CT ,UNINSTL_DAYS_CT))")).withColumn("value",expr("to_json(struct(AggregateTrips))")).selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")

    if ('test') in harmonizedDB:
      finalDF_SR.write.format("kafka").option("kafka.bootstrap.servers", "event-streaming-pt-kb.aws.e1.nwie.net:9092").option("kafka.security.protocol","SSL").option("kafka.ssl.truststore.location", "/dbfs/FileStore/iottelematics/smsr/iot_test_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.truststore.password", "iot_test_smsr_aggtrips_to_mf_producer").option("kafka.ssl.keystore.location", "/dbfs/FileStore/iottelematics/smsr/iot_test_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.keystore.password", "iot_test_smsr_aggtrips_to_mf_producer").option("kafka.ssl.key.password", "iot_test_smsr_aggtrips_to_mf_producer").option("topic", "system.policy-management.iot-aggregate-trips.v1.test").save()
      SR_df1.createOrReplaceGlobalTempView('new_sr_outbound_elements')
      spark.sql(f"merge into {curate_table} target using (select distinct * from global_temp.new_sr_outbound_elements) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.DEVC_KEY = updates.DEVC_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.PRGRM_INSTC_ID = updates.PRGRM_INSTC_ID and target.TRANSACTION_TS = updates.TRANSACTION_TS and target.MAX_PE_END_TS = updates.MAX_PE_END_TS when not matched then insert *")
    
    if ('prod') in harmonizedDB:
      finalDF_SR.write.format("kafka").option("kafka.bootstrap.servers", "event-streaming-kb.aws.e1.nwie.net:9092").option("kafka.security.protocol","SSL").option("kafka.ssl.truststore.location", "/dbfs/FileStore/iottelematics/smsr/iot_prod_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.truststore.password", "iot_prod_smsr_aggtrips_to_mf_producer").option("kafka.ssl.keystore.location", "/dbfs/FileStore/iottelematics/smsr/iot_prod_smsr_aggtrips_to_mf_producer.jks").option("kafka.ssl.keystore.password", "iot_prod_smsr_aggtrips_to_mf_producer").option("kafka.ssl.key.password", "iot_prod_smsr_aggtrips_to_mf_producer").option("topic", "system.policy-management.iot-aggregate-trips.v1").save()
      SR_df1.createOrReplaceGlobalTempView('new_sr_outbound_elements')
      spark.sql(f"merge into {curate_table} target using (select distinct * from global_temp.new_sr_outbound_elements) updates on target.ENRLD_VIN_NB = updates.ENRLD_VIN_NB and target.DEVC_KEY = updates.DEVC_KEY and target.SRC_SYS_CD = updates.SRC_SYS_CD and target.PRGRM_INSTC_ID = updates.PRGRM_INSTC_ID and target.TRANSACTION_TS = updates.TRANSACTION_TS and target.MAX_PE_END_TS = updates.MAX_PE_END_TS when not matched then insert *")




