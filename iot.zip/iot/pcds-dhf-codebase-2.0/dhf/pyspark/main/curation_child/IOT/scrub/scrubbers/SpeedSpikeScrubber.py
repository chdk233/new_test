# Databricks notebook source
# MAGIC %python
# MAGIC 
# MAGIC SPIKE_THRESHOLD_1 = 20.0
# MAGIC SPIKE_THRESHOLD_2 = 5.0
# MAGIC SPIKE_THRESHOLD_3 = 1.0 
# MAGIC DEBUG_SPEED_SPIKE_SCRUBBED_POSITION = "SS"

# COMMAND ----------

def satisfiesRule1(prevSpeed, speed, nextSpeed, trustedIndex):
  print('applying rule 1' +str(datetime.now(tz)))
  if trustedIndex < 2:
    return False
  if nextSpeed != None and builtins.abs(nextSpeed-prevSpeed) <= SPIKE_THRESHOLD_2:
    if builtins.abs(speed-prevSpeed) >= SPIKE_THRESHOLD_1:
      if builtins.abs(speed -nextSpeed) >= SPIKE_THRESHOLD_1:
        return True
  return False

# COMMAND ----------

def applyRule2(trip_data, spikes1, speeds_to_scrub, times_of_spikes, trip_len):
  print('applying rule 2' + str(datetime.now(tz)))
#   windowSpec = Window.partitionBy("TRIP_SMRY_KEY").orderBy("PSTN_TS")
  spikes = []
  rows = []
  totalSpikes = len(spikes1)
  spike_flags = [0] * trip_len
  replacement_speeds = []
  speeds_for_scrubbing = []
  times_for_scrubbing = []
  if totalSpikes == 0:
    pass
  elif totalSpikes == 1:
    spikes.append(spikes1[0])
    speeds_for_scrubbing.append(speeds_to_scrub[0])
    times_for_scrubbing.append(times_of_spikes[0])
  else:
    for i in range(totalSpikes):
      if i == 0:
        if (spikes1[i + 1] - spikes1[i]) > 2:
          spikes.append(spikes1[i])
          speeds_for_scrubbing.append(speeds_to_scrub[i])
          times_for_scrubbing.append(times_of_spikes[i])
      elif i == totalSpikes -1:
        if (spikes1[i] - spikes1[i -1]) > 2:
          spikes.append(spikes1[i])
          speeds_for_scrubbing.append(speeds_to_scrub[i])
          times_for_scrubbing.append(times_of_spikes[i])
      else:
        if (spikes1[i] - spikes1[i - 1]) > 2 and (spikes1[i + 1] - spikes1[i]) > 2:
          spikes.append(spikes1[i])
          speeds_for_scrubbing.append(speeds_to_scrub[i])
          times_for_scrubbing.append(times_of_spikes[i])

  if totalSpikes > 0:
    trip_data_row_num=[]
    for r_num,trip_dict in enumerate(trip_data):
      trip_dict['row_number']=r_num+1
      trip_data_row_num.append(trip_dict)
    len_trip=len(trip_data)
    trip_data1=[]
    for r_num,trip_dict in enumerate(trip_data_row_num):
#       if trip_dict['SPD_KPH_RT'] in speeds_for_scrubbing:
      if trip_dict['PSTN_TS'] in times_for_scrubbing:
        trip_dict['SCRBD_FLD_DESC']= f"{trip_dict['SCRBD_FLD_DESC']}{DEBUG_SPEED_SPIKE_SCRUBBED_POSITION}"
      for trip_dict1 in trip_data_row_num:
        if r_num ==0:
          lag_SPD_KPH_RT=None
        elif trip_dict1['row_number'] == r_num:
          lag_SPD_KPH_RT=trip_dict1['SPD_KPH_RT']
        if r_num+1==len_trip:
          lead_SPD_KPH_RT=None
        elif trip_dict1['row_number'] == r_num+2:
          lead_SPD_KPH_RT=trip_dict1['SPD_KPH_RT']
        if trip_dict1['row_number'] > r_num+2:
          break
      if DEBUG_SPEED_SPIKE_SCRUBBED_POSITION in trip_dict['SCRBD_FLD_DESC'] and lead_SPD_KPH_RT is not None and lag_SPD_KPH_RT is not None and builtins.abs(lead_SPD_KPH_RT-lag_SPD_KPH_RT) <= SPIKE_THRESHOLD_3:
        trip_dict['SPD_KPH_RT']=lag_SPD_KPH_RT
      if DEBUG_SPEED_SPIKE_SCRUBBED_POSITION in trip_dict['SCRBD_FLD_DESC'] and lead_SPD_KPH_RT is not None and lag_SPD_KPH_RT is not None and builtins.abs(lead_SPD_KPH_RT-lag_SPD_KPH_RT) > SPIKE_THRESHOLD_3:
        trip_dict['SPD_KPH_RT']=Decimal(builtins.round((lag_SPD_KPH_RT+lead_SPD_KPH_RT)/2))
      trip_data1.append(trip_dict)
    print('changed speedspikes' + str(datetime.now(tz)))
    return trip_data1
  else:
    print('no changes in speed ' + str(datetime.now(tz)))
    return trip_data


# COMMAND ----------

def scrubSpeedSpikes(partitionData):
  print('scrubbing (start) ' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_trip_data=[]
  for tripid in data_by_trip:
    trip_data = data_by_trip[tripid]
    spikes1 =[]
    trip_len = len(trip_data)
    speeds_to_scrub = []
    times_of_spikes = []
    z = 0
    for row in trip_data:
      if z == 0:
        prevSpeed = row['SPD_KPH_RT']
        prevTime = row['PSTN_TS']
      elif z == 1:
        currSpeed = row['SPD_KPH_RT']
        currTime = row['PSTN_TS']
      else:
        nextSpeed = row['SPD_KPH_RT']
        nextTime = row['PSTN_TS']
        if satisfiesRule1(prevSpeed, currSpeed, nextSpeed, z):
          speeds_to_scrub.append(currSpeed)
          times_of_spikes.append(currTime)
          spikes1.append(z-1)
        prevSpeed = currSpeed
        prevTime = currTime
        currSpeed = nextSpeed
        currTime = nextTime
        if z == trip_len -1:
          trip_data = applyRule2(trip_data, spikes1, speeds_to_scrub, times_of_spikes, trip_len)
      z = z + 1
    return_trip_data.extend(trip_data)
    print('scrubbing (end) ' + str(datetime.now(tz)))
  return iter(return_trip_data)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select * from dhf_iot_harmonized_test.trip_detail_seconds_chlg where TRIP_SMRY_KEY = '00000001116883541651429945'

# COMMAND ----------


