# Databricks notebook source
# MAGIC %python
# MAGIC from decimal import Decimal
# MAGIC from datetime import time, datetime
# MAGIC from pyspark.sql.types import StructType,StructField, TimestampType, DecimalType, StringType, IntegerType
# MAGIC from pytz import timezone
# MAGIC import pyspark.sql.functions as f
# MAGIC tz = timezone('US/Eastern')
# MAGIC
# MAGIC
# MAGIC def sort_PSTN_TS(ele):
# MAGIC   return str(ele['IDLE_CENTROID_NB'])+str(ele['PSTN_TS'])
# MAGIC
# MAGIC
# MAGIC
# MAGIC IDLE_TIME_THRESHOLD = 210
# MAGIC RPM_SEGMENT_SIZE = 200
# MAGIC DELTA_RPM_THRESHOLD = 50
# MAGIC LAST_SECOND_ACCELERATION_FOR_SPEED_DELTA_CENTROID_RULE_EXCLUSION = 9.0
# MAGIC MAX_SPEED_LESS_MIN_SPEED_DELTA_FOR_CENTROID_RULE_EXCLUSION = 14.0
# MAGIC MIN_NUMBER_OF_SECONDS_FOR_LAST_SECOND_ACCELERATION_SPEED_DELTA_CENTROID_RULE_EXCLUSION = 4
# MAGIC MAX_SPEED_DELTA_RPM_CENTROID_THRESHOLD = 25
# MAGIC SPEED_INCREASE_THRESHOLD = 30
# MAGIC SPEED_DECREASE_THRESHOLD = -50
# MAGIC RPM_ONE_THOUSAND_SEVEN_HUNDRED = 1700
# MAGIC INT_ZERO = 0
# MAGIC INT_ONE = 1

# COMMAND ----------

def initializeUpperBoundary(trip_data, size):
  print('starting to initialize upper ' + str(datetime.now(tz)))
  lastChangeInSpeedIndex = -1
  j = size - 1
  while j > -1:
    if trip_data[j]['SPD_KPH_RT'] != Decimal(0):
      lastChangeInSpeedIndex = j
      break
    j = j -1
  return lastChangeInSpeedIndex

def isLastSecondSpeedBump(trip_data, centroid_len, trustedIndex, speedIncreases):
  print('is speed bump ' + str(datetime.now(tz)))
  secondsThreshold = MIN_NUMBER_OF_SECONDS_FOR_LAST_SECOND_ACCELERATION_SPEED_DELTA_CENTROID_RULE_EXCLUSION
  if centroid_len >= secondsThreshold and speedIncreases == 1:
    lastSpeed = trip_data[trustedIndex-1]['SPD_KPH_RT']
    secondToLastSpeed = trip_data[trustedIndex-2]['SPD_KPH_RT']
    deltaSpeed = lastSpeed - secondToLastSpeed
    return 1 if deltaSpeed > 0 and deltaSpeed < LAST_SECOND_ACCELERATION_FOR_SPEED_DELTA_CENTROID_RULE_EXCLUSION else 0
  return 0

# COMMAND ----------

def eventCentroidScrub3(partitionData):
#   return partitionData
  print('start scrubbing ' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_trip=[]
  for tripid in data_by_trip:
    input_data=[] 
    trip_data = data_by_trip[tripid]
    for i_row in trip_data:
      i_row['dataframe_cd']='accelLag_df'
      input_data.append(i_row)
    size = len(trip_data)
    winMin = 0
    winMax = 0
    i = 0
    centroids = []
    rows = []
    start_rpms = []
    last_speed_of_prior_centroid = []
    last_speed_of_prior_centroid.append(None)
    first_sec_of_centroid = []
    last_sec_of_centroid = []
    minKph_lst = []
    maxKph_lst = []
    minKphDelta_lst = []
    maxKphDelta_lst = []
    speedIncreases_lst = []
    speedDecreases_lst = []
    speedSteady_lst = []
    bump_lst = []
    plausibility_lst = [0] * size
    centroid = 0
    
    idle_centroids = []
    idle_centroid = 0 
    idle_rows = []
    
  
    is_drive_time = [0] * size
    firstChangeInSpeedIndex = -1
    lastChangeInSpeedIndex = -1
    
    lastChangeInSpeedIndex = initializeUpperBoundary(trip_data, size)
  
    for row in trip_data:
      previous_second = None
      createCentroid = False
      createIdleCentroid = True
      count = 0
  
      if row['SPD_KPH_RT'] != Decimal(0) and firstChangeInSpeedIndex == -1:
        firstChangeInSpeedIndex = i    
      if (firstChangeInSpeedIndex <= i and i <= lastChangeInSpeedIndex) and firstChangeInSpeedIndex != -1:
        is_drive_time = 1
      else:
        is_drive_time = 0
        
      if row['SPD_KPH_RT'] == Decimal(0) and i > 0:
        createIdleCentroid = False  
        
      if row['ENGIN_RPM_RT'] == None:
        createCentroid = True if i == 0 or trip_data[i - 1]['ENGIN_RPM_RT'] is not None else False
      else:
        if (i > 0 and trip_data[i-1]['ENGIN_RPM_RT'] == None) or (i == 0) or (row['ENGIN_RPM_RT'] < winMin) or (row['ENGIN_RPM_RT'] > winMax):
          winMin = row['ENGIN_RPM_RT'] - RPM_SEGMENT_SIZE
          winMax = row['ENGIN_RPM_RT'] + RPM_SEGMENT_SIZE
          createCentroid = True
      if createIdleCentroid:
        idle_centroid = idle_centroid + 1
      if createCentroid:
        if i > 0:
          if minKphDelta == None:
            minKphDelta = Decimal(0)
          if maxKphDelta == None:
            maxKphDelta = Decimal(0)
          last_sec_of_centroid.append(trip_data[i - 1]['PSTN_TS'])
          last_speed_of_prior_centroid.append(trip_data[i-1]['SPD_KPH_RT'])
          minKph_lst.append(minKph)
          maxKph_lst.append(maxKph)
          minKphDelta_lst.append(minKphDelta)
          maxKphDelta_lst.append(maxKphDelta)
          speedIncreases_lst.append(speedIncreases)
          speedDecreases_lst.append(speedDecreases)
          speedSteady_lst.append(speedSteady)
          isBump = isLastSecondSpeedBump(trip_data, count, i, speedIncreases)
          bump_lst.append(isBump)
        count = 0
        minKph = None
        maxKph = None
        minKphDelta = None
        maxKphDelta = None
        speedIncreases = 0
        speedDecreases = 0
        speedSteady = 0
        centroid = centroid + 1
        centroids.append(centroid)
        start_rpms.append(row['ENGIN_RPM_RT'])
        first_sec_of_centroid.append(row['PSTN_TS'])
      else:
        previous_second = trip_data[i - 1]['PSTN_TS']
        centroids.append(centroid)
        count = count + 1
      if previous_second is not None:
        deltaSpeed = row['SPD_KPH_RT'] - trip_data[i-1]['SPD_KPH_RT']
        if minKphDelta == None or minKphDelta > deltaSpeed:
          minKphDelta = deltaSpeed 
        if maxKphDelta == None or maxKphDelta < deltaSpeed:
          maxKphDelta = deltaSpeed 
        if deltaSpeed > 0:
          speedIncreases = speedIncreases + 1
        elif deltaSpeed < 0:
          speedDecreases = speedDecreases + 1
        else:
          speedSteady = speedSteady + 1
          
      if minKph == None or minKph > row['SPD_KPH_RT']:
        minKph = row['SPD_KPH_RT'] 
      if maxKph == None or maxKph < row['SPD_KPH_RT']:
        maxKph = row['SPD_KPH_RT']
        
      idle_rows.append({"ENRLD_VIN_NB":row["ENRLD_VIN_NB"], "TRIP_SMRY_KEY":row["TRIP_SMRY_KEY"], "DEVC_KEY":row['DEVC_KEY'], "PSTN_TS":row["PSTN_TS"], "PSTN_OFFST_TS":row['PSTN_OFFST_TS'], "TIME_ZONE_OFFST_NUM":row['TIME_ZONE_OFFST_NUM'], "ORGNL_SPD_RT":row['ORGNL_SPD_RT'], "SPD_MPH_RT":row['SPD_MPH_RT'], "SPD_KPH_RT":row['SPD_KPH_RT'], "ORGNL_RPM_RT":row['ORGNL_RPM_RT'], "ENGIN_RPM_RT":row['ENGIN_RPM_RT'], "DISTNC_MPH":row['DISTNC_MPH'], "DISTNC_KPH":row['DISTNC_KPH'], "SCRBD_FLD_DESC":row['SCRBD_FLD_DESC'], "LAT_NB":row['LAT_NB'], "LNGTD_NB":row['LNGTD_NB'], "SRC_SYS_CD":row['SRC_SYS_CD'], "MSSNG_TOO_MANY_SEC_FLAG":row['MSSNG_TOO_MANY_SEC_FLAG'],"LOAD_DT":row["LOAD_DT"], "LOAD_HR_TS":row["LOAD_HR_TS"], "IDLE_CENTROID_NB":idle_centroid, "IS_DRIVE_TIME":is_drive_time,"PLCY_RT_ST_CD":row["PLCY_RT_ST_CD"],"POLICY_KEY":row["POLICY_KEY"],"POLICY_KEY_ID":row["POLICY_KEY_ID"]})     
      i = i + 1
    last_sec_of_centroid.append(trip_data[i -1]['PSTN_TS'])
    last_speed_of_prior_centroid.append(trip_data[i-1]['SPD_KPH_RT'])
    minKph_lst.append(minKph)
    maxKph_lst.append(maxKph)
    minKphDelta_lst.append(minKphDelta)
    maxKphDelta_lst.append(maxKphDelta)
    speedIncreases_lst.append(speedIncreases)
    speedDecreases_lst.append(speedDecreases)
    speedSteady_lst.append(speedSteady)
    isBump = isLastSecondSpeedBump(trip_data, count, i, speedIncreases)
    bump_lst.append(isBump)
    cents = list(set(centroids))
    k = 0
    rows = []
      
    while k < len(start_rpms):
      rows.append({"ENRLD_VIN_NB":trip_data[k]['ENRLD_VIN_NB'],"TRIP_SMRY_KEY":trip_data[k]['TRIP_SMRY_KEY'], "ENGIN_RPM_RT":start_rpms[k], "TRIP_START_TS":first_sec_of_centroid[k], "TRIP_END_TS":last_sec_of_centroid[k], "MIN_KPH":minKph_lst[k], "MAX_KPH":maxKph_lst[k], "MIN_KPH_DELTA":minKphDelta_lst[k], "MAX_KPH_DELTA":maxKphDelta_lst[k], "SPEED_DECREASES":speedDecreases_lst[k], "SPEED_INCREASES":speedIncreases_lst[k], "SPEED_STEADY":speedSteady_lst[k], "MAX_MIN_DELTA":builtins.abs(maxKph_lst[k]) - builtins.abs(minKph_lst[k]), "IS_LAST_SECOND_SPEED_BUMP":bump_lst[k], "CNTRD_NUM":cents[k],"LAST_SEC_PRIOR_CNTRD":last_speed_of_prior_centroid[k],"dataframe_cd":'rpmCentroid_df'})
      k = k + 1
    print('done scrubbing ' + str(datetime.now(tz)))
    df_rpm_scrubbed = rows
    idle_rows.sort(key=sort_PSTN_TS)
    idle_dict={}
    for r_num,row in enumerate(idle_rows):
      if idle_dict.get(f"{row['IDLE_CENTROID_NB']}_fs",'') =='':
        idle_dict[f"{row['IDLE_CENTROID_NB']}_fs"]=row['SPD_KPH_RT']
      idle_dict[f"{row['IDLE_CENTROID_NB']}_c"]=idle_dict.get(f"{row['IDLE_CENTROID_NB']}_c",0)+1
    r_idle_rows=[]
    for row in idle_rows:
      row['dataframe_cd']="idleTimeCentroid_df"
      row['CNTRD_NUM']=cents[0]
      row['IS_LAST_SECOND_SPEED_BUMP']=bump_lst[0]
      row['MAX_KPH']=Decimal(0)
      row['MAX_KPH_DELTA']=Decimal(0)
      row['MAX_MIN_DELTA']=Decimal(0)
      row['MIN_KPH']=Decimal(0)
      row['MIN_KPH_DELTA']=Decimal(0)
      row['SPEED_DECREASES']=speedDecreases_lst[0]
      row['SPEED_INCREASES']=speedIncreases_lst[0]
      row['SPEED_STEADY']=speedSteady_lst[0]
      row['TRIP_END_TS']=last_sec_of_centroid[0]
      row['TRIP_START_TS']=first_sec_of_centroid[0]
      row['first_speed']=idle_dict[f"{row['IDLE_CENTROID_NB']}_fs"]
      row['centroid_len']=idle_dict[f"{row['IDLE_CENTROID_NB']}_c"]
      if ((row['SPD_KPH_RT']== Decimal(0)) and (row['first_speed'] == Decimal(0)) and (row['centroid_len'] <IDLE_TIME_THRESHOLD)) or ((row['SPD_KPH_RT']== Decimal(0)) and (row['first_speed'] != Decimal(0)) and ((row['centroid_len']-1) <IDLE_TIME_THRESHOLD)):
        row['IDLE_SC_CNT']=1
      else:
        row['IDLE_SC_CNT']=0
      if row['MSSNG_TOO_MANY_SEC_FLAG'] ==1:
        row['IDLE_SC_CNT']=-1
      if (row['SPD_KPH_RT']!= Decimal(0) and row['IS_DRIVE_TIME']==1) or (row['IS_DRIVE_TIME']==1 and row['IDLE_SC_CNT']==1):
        row['DRVNG_SC_CNT']=1
      else:
        row['DRVNG_SC_CNT']=0
      if row['MSSNG_TOO_MANY_SEC_FLAG'] ==1:
        row['DRVNG_SC_CNT']=-1
      r_idle_rows.append(row)  

    return_trip.extend(r_idle_rows)
    return_trip.extend(df_rpm_scrubbed)
    return_trip.extend(input_data)
  return iter(return_trip)
    
