# Databricks notebook source
# DBTITLE 1,Importing Functions
from delta.tables import *
KPH_TO_MPH_CONVERSION_FACTOR = Decimal(1.609334)

FAST_ACCELERATION_THRESHOLD = Decimal(13)
HARD_BRAKE_THRESHOLD = Decimal(-13)
NIGHT_TIME_DRIVING_THRESHOLD_LB = "00:00:00"
NIGHT_TIME_DRIVING_THRESHOLD_UB = "05:00:00"

def isExceptionToRule(row):
  return (row['MAX_KPH'] - row['MIN_KPH']) < Decimal(14) or row['SPEED_DECREASES'] == 0 or row['SPEED_INCREASES'] == 0 or row['IS_LAST_SECOND_SPEED_BUMP'] == 0

# COMMAND ----------

# def perSecPlausibleRules2(df1, first_sec) -> int:
#   print('in per second plausibility ' + str(datetime.now(tz)))
# #   df1 = df_trip_centroid.collect()
#   i=0
#   plausible_flag = 1
#   plausible_reason = None
#   base_rpm = None
#   for row in df1:
#     if row["SRC_SYS_CD"] is not None and row['SRC_SYS_CD'] != 'NOKEY' and ((('FMC') in row['SRC_SYS_CD']) or (('TIMS') in row['SRC_SYS_CD'])):
#       return 1
#     if i==0:
#       prev_time = row["PSTN_TS"]
#       prev_speed = row["SPD_KPH_RT"]
#       base_rpm = row['ENGIN_RPM_RT']
#     else:
#       current_time = row['PSTN_TS']
#       current_speed = row['SPD_KPH_RT']
#       delta_speed = current_speed - prev_speed
        
#       if row['MAX_KPH_DELTA'] > Decimal(30):
#         plausible_flag = 0
#         plausible_reason = "SPEED_INCREASE_THIRTY_KPM_IN_ONE_SECOND"
#         return plausible_flag
#       elif row['MIN_KPH_DELTA'] < Decimal(-50):
#         plausible_flag = 0
#         plausible_reason = "SPEED_DECREASE_FIFTY_KPM_IN_ONE_SECOND"
#         return plausible_flag
#       elif (current_speed == Decimal(0) and base_rpm > Decimal(1700) and ((current_time - first_sec).seconds > 2)): # centroid cannot contain first 3 seconds of trip for this rule to apply (!first centroid of trip, > 3sec in) need to check
#         plausible_flag = 0
#         plausible_reason = "BASE_RPM_1700_AND_SPEED_ZERO" # changed as per prod
#         return plausible_flag
#       elif row['MAX_MIN_DELTA'] > Decimal(25):
#         if not isExceptionToRule(row):
#           plausible_flag = 0
#           plausible_reason = "MAX_LESS_MIN_DELTA_SPEEDS_GTE_25"
#           return plausible_flag
#       prev_time = current_time
#       prev_speed = current_speed
#     i=i+1 
#   print('done in plausibility rules ' + str(datetime.now(tz)))
#   return plausible_flag   

  
  

# COMMAND ----------

def perSecPlausibleRules2(df1, first_sec) -> int:
  print('in per second plausibility ' + str(datetime.now(tz)))
#   df1 = df_trip_centroid.collect()
  i=0
  plausible_flag = 1
  plausible_reason = None
  base_rpm = None
  for row in df1:
    if row["SRC_SYS_CD"] is not None and row['SRC_SYS_CD'] != 'NOKEY' and ((('FMC') in row['SRC_SYS_CD']) or (('TIMS') in row['SRC_SYS_CD'])):
      return plausible_flag
    if i==0:
      base_rpm = row['ENGIN_RPM_RT']
    if i==0 and row['LAST_SEC_PRIOR_CNTRD'] is not None and (row['SPD_KPH_RT'] - row['LAST_SEC_PRIOR_CNTRD']) > Decimal(30):
      plausible_flag = 0
      plausible_reason = "SPEED_INCREASE_THIRTY_KPM_IN_ONE_SECOND"
    elif row['MAX_KPH_DELTA'] is not None and row['MAX_KPH_DELTA'] > Decimal(30):
      plausible_flag = 0
      plausible_reason = "SPEED_INCREASE_THIRTY_KPM_IN_ONE_SECOND"
      return plausible_flag
    elif i==0 and row['LAST_SEC_PRIOR_CNTRD'] is not None and (row['SPD_KPH_RT'] - row['LAST_SEC_PRIOR_CNTRD']) < Decimal(-50):
      plausible_flag = 0
      plausible_reason = "SPEED_DECREASE_FIFTY_KPM_IN_ONE_SECOND"
      return plausible_flag
    elif row['MIN_KPH_DELTA'] is not None and row['MIN_KPH_DELTA'] < Decimal(-50):
      plausible_flag = 0
      plausible_reason = "SPEED_DECREASE_FIFTY_KPM_IN_ONE_SECOND"
      return plausible_flag
    elif (row['SPD_KPH_RT'] == Decimal(0) and base_rpm > Decimal(1700)  and (row['PSTN_TS'] - first_sec).seconds > 2): # centroid cannot contain first 3 seconds of trip for this rule to apply (!first centroid of trip, > 3sec in) need to check
      plausible_flag = 0
      plausible_reason = "BASE_RPM_1700_AND_SPEED_ZERO" # changed as per prod
      return plausible_flag
    elif row['MAX_MIN_DELTA'] is not None and row['MAX_MIN_DELTA'] > Decimal(25):
      if not isExceptionToRule(row):
        plausible_flag = 0
        plausible_reason = "MAX_LESS_MIN_DELTA_SPEEDS_GTE_25"
        return plausible_flag
    i=i+1 
  print('done in plausibility rules ' + str(datetime.now(tz)))
  return plausible_flag   

  
  

# COMMAND ----------

def callPlausibleRules2(partitionData):  
  print('calling plausible rules ' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    row_dict=row.asDict()
    row_dict['PLSBL_SC_CNT']=0
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row_dict)
  return_data=[]
  for tripid in data_by_trip:
    trip_data = data_by_trip[tripid]
    df2=[]
    i = 0
    first_sec = None
    for row_dict in trip_data:
      first_sec = row_dict['PSTN_TS'] if i == 0 else first_sec
      if row_dict['CNTRD_NUM'] not in df2:
        df2.append(row_dict['CNTRD_NUM'])
      i = i + 1
    centroid_plausible_in={}
    for row_centroid in df2:
      row1={"CNTRD_NUM":row_centroid}
      rpm_list=[]
      for cntrd_row in trip_data:
        if cntrd_row['CNTRD_NUM']==row1['CNTRD_NUM']:
          rpm_list.append(cntrd_row)
      plausible_in = perSecPlausibleRules2(rpm_list, first_sec)
      centroid_plausible_in[row1['CNTRD_NUM']]=plausible_in
    plausible_list=[]
    for cntrd_row in trip_data:
#       cntrd_row['PLSBL_SC_CNT']=centroid_plausible_in.get(cntrd_row['CNTRD_NUM'],0)
      cntrd_row['PLSBL_SC_CNT']=centroid_plausible_in.get(cntrd_row['CNTRD_NUM'],1)
      plausible_list.append(cntrd_row)
    print('done calling plausible rules ' + str(datetime.now(tz)))
    return_data.extend(plausible_list)
  return iter(return_data)

# COMMAND ----------

def NeighboringCentroidRule2(dfrpmcent, rpm_cent, centroidno,max_centroid) -> int:
  print('in neighboring centroid rule ' + str(datetime.now(tz)))
  plausible_flag= rpm_cent[0]['PLSBL_SC_CNT']
  if centroidno > 1 and centroidno < max_centroid:
    for row in dfrpmcent:
      if row['CNTRD_NUM'] == centroidno+1:
        x=row['PLSBL_SC_CNT']
        break
    for row in dfrpmcent:
      if row['CNTRD_NUM'] == centroidno-1:
        y=row['PLSBL_SC_CNT']
        break
    print('done in neighboring centroid ' + str(datetime.now(tz)))
    if x==0 and y==0:
      plausible_flag=0
      return plausible_flag
    else:
      return plausible_flag
  return plausible_flag


# COMMAND ----------

def callNeighboringCentroidRule2(partitionData):
#   idle_time_data=[]
#   for row in idleTimeCentroid_rdd:
#     row['df_cd']='idleTimeCentroid_df'
#     row['CNTRD_NUM']=0
#     row['FAST_ACLRTN_EVNT_COUNTR']=0
#     row['HARD_BRKE_COUNTR']=0
#     row['IS_LAST_SECOND_SPEED_BUMP']=0
#     row['MAX_KPH']=Decimal(0)
#     row['MIN_KPH']=Decimal(0)
#     row['NIGHT_TIME_DRVNG_SEC_CNT']=0
#     row['PLSBL_SC_CNT']=0
#     row['SPEED_DECREASES']=0
#     row['SPEED_INCREASES']=0
#     row['STOP_SC_CNT']=0
#     idle_time_data.append(row)
  print('calling neighboring centroid rule ' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_data=[]
#   return_data1=[]
  print('done organizing dataframe ' + str(datetime.now(tz)))
  for tripid in data_by_trip:
    trip_data = data_by_trip[tripid]
    centroidgroupmax={}
    for row in trip_data:
      centroidgroupmax[f"row['TRIP_SMRY_KEY']_max"]=builtins.max(centroidgroupmax.get(f"row['TRIP_SMRY_KEY']_max",0),row['CNTRD_NUM'])
    uniq_centroid={}
    df2=[]
    for row in trip_data:
      if uniq_centroid.get(f'{row["TRIP_SMRY_KEY"]}{row["CNTRD_NUM"]}',0) ==0:
        df2.append({"TRIP_SMRY_KEY":row['TRIP_SMRY_KEY'],"CNTRD_NUM":row['CNTRD_NUM'],"max_centroid":centroidgroupmax[f"row['TRIP_SMRY_KEY']_max"]})
        uniq_centroid[f'{row["TRIP_SMRY_KEY"]}{row["CNTRD_NUM"]}']=1
      else:
        continue
    centroid_plausible_in={}
    for row1 in df2:
      rpm_cent=[]
      for row_rpmcent in trip_data:
        if row_rpmcent['CNTRD_NUM'] == row1['CNTRD_NUM']:
          rpm_cent.append(row_rpmcent)
      plausible_in = NeighboringCentroidRule2(trip_data, rpm_cent, row1['CNTRD_NUM'],row1['max_centroid'])
      centroid_plausible_in[row1['CNTRD_NUM']]=plausible_in
    df_neighboring=[]
    for row_num,n_row in enumerate(trip_data):
      n_row['row_number']=row_num+1
      n_row['PLSBL_SC_CNT']=centroid_plausible_in.get(n_row['CNTRD_NUM'],0)
      df_neighboring.append(n_row)
    trip_data = df_neighboring
    print('done calling neighboring centroid ' + str(datetime.now(tz)))
    len_trip=len(df_neighboring)
    for r_num,r_row in enumerate(df_neighboring):
      for trip_dict in df_neighboring:
        if r_num ==0:
          lag_SPD_KPH_RT=None
          lag_PLSBL_SC_CNT=None
        elif trip_dict['row_number'] == r_num:
          lag_SPD_KPH_RT=trip_dict['SPD_KPH_RT']
          lag_PLSBL_SC_CNT = trip_dict['PLSBL_SC_CNT']
        if trip_dict['row_number'] > r_num+2:
          break
      if r_row['PLCY_RT_ST_CD'] == 'CA':
        r_row['SCRBD_FLD_DESC'] = f"{r_row['SCRBD_FLD_DESC']}_CA"
      if lag_SPD_KPH_RT is not None and Decimal(r_row['SPD_KPH_RT'] - lag_SPD_KPH_RT) >=FAST_ACCELERATION_THRESHOLD and r_row['PLSBL_SC_CNT'] ==1 and row['PLCY_RT_ST_CD'] != 'CA' and lag_PLSBL_SC_CNT !=0:
        r_row['FAST_ACLRTN_EVNT_COUNTR']=1
      else:
        r_row['FAST_ACLRTN_EVNT_COUNTR']=0
      if lag_SPD_KPH_RT is not None and Decimal(r_row['SPD_KPH_RT'] - lag_SPD_KPH_RT) <=HARD_BRAKE_THRESHOLD and r_row['PLSBL_SC_CNT'] ==1 and row['PLCY_RT_ST_CD'] != 'CA' and lag_PLSBL_SC_CNT !=0:
        r_row['HARD_BRKE_COUNTR']=1
      else:
        r_row['HARD_BRKE_COUNTR']=0
      if lag_SPD_KPH_RT is not None and lag_SPD_KPH_RT !=Decimal(0) and r_row['SPD_KPH_RT'] == Decimal(0) and r_row['PLSBL_SC_CNT'] ==1 and row['PLCY_RT_ST_CD'] != 'CA' and lag_PLSBL_SC_CNT !=0:
        r_row['STOP_SC_CNT']=1
      else:
        r_row['STOP_SC_CNT']=0
      if datetime.strptime(NIGHT_TIME_DRIVING_THRESHOLD_LB, '%H:%M:%S').time() <= r_row['PSTN_OFFST_TS'].time() <= datetime.strptime(NIGHT_TIME_DRIVING_THRESHOLD_UB, '%H:%M:%S').time()  and row['PLCY_RT_ST_CD'] != 'CA' and lag_PLSBL_SC_CNT !=0: 
        r_row['NIGHT_TIME_DRVNG_SEC_CNT']=1
      else:
        r_row['NIGHT_TIME_DRVNG_SEC_CNT']=0
#       r_row['df_cd']='neighboringCentroid_df'
      return_data.append(r_row)
#     return_data1.extend(idle_time_data)
#     return_data1.extend(return_data)
  return iter(return_data)

# COMMAND ----------


