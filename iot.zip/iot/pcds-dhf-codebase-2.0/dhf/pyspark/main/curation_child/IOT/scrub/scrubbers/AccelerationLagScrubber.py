# Databricks notebook source
# DBTITLE 1,Imports
from decimal import Decimal
DEBUG_ACCEL_LAG_SCRUBBED_POSITION = "AL"
ACCELERATION_LAG_RATIO = Decimal("1.4")
KPH_TO_MPH_CONVERSION_FACTOR = Decimal(1.609334)

# COMMAND ----------

def acceleration_lag_scrubber6(partitionData):
  print('starting acceleration lag ' + str(datetime.now(tz)))
  data_by_trip={}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_trip_data=[]
  for tripid in data_by_trip:
    data_by_trip_list = data_by_trip[tripid]
    trip_data=[]
    for r_num,trip_dict in enumerate(data_by_trip_list):
      trip_dict['row_number']=r_num+1
      trip_data.append(trip_dict)
    i = 0
    x = 0
    accelLag_lst = []
    lagstartindex = None
    timebeforelag = None
    speedbeforelag:Decimal = None
    timeofflag = None
    for row in trip_data:
      if i == 0: 
        prev_second = row['PSTN_TS']
        prev_rpm = row['ENGIN_RPM_RT']
        prev_speed = row['SPD_KPH_RT']
      else:
        current_second = row['PSTN_TS']
        current_speed = row['SPD_KPH_RT']
        current_rpm = row['ENGIN_RPM_RT']
        if current_speed == Decimal(0):
          if (prev_rpm > Decimal(0) and (current_rpm / prev_rpm) > ACCELERATION_LAG_RATIO):
            timeofflag = current_second if timeofflag is None else timeofflag
            timebeforelag = prev_second if timebeforelag is None else timebeforelag
            speedbeforelag = prev_speed if speedbeforelag is None else speedbeforelag
            lagstartindex = i if lagstartindex is None else lagstartindex
            x = x+1
          if x > 0:
            if current_rpm < prev_rpm:
              lagstartindex = None
              timebeforelag = None
              speedbeforelag = None
              timeofflag = None
              x = 0
        elif current_speed > Decimal(0) and x > 0:
          if (current_second-timeofflag).seconds <=2:
            if (current_second-timeofflag).seconds == 2:
              speed_rt = Decimal(current_speed / 3)
            elif (current_second-timeofflag).seconds == 1:
              speed_rt = Decimal(current_speed / 2)
            trip_list=[]
            for row in trip_data:
              if row['PSTN_TS'] < current_second and timebeforelag < row['PSTN_TS']:
                row['SPD_KPH_RT']=Decimal(builtins.round(((row['row_number']-lagstartindex)*speed_rt)))
                row['SCRBD_FLD_DESC']=f"{row['SCRBD_FLD_DESC']}{DEBUG_ACCEL_LAG_SCRUBBED_POSITION}"
              trip_list.append(row)
            trip_data=trip_list
          x = 0
          lagstartindex = None
          timebeforelag = None
          speedbeforelag = None
          timeofflag = None
        else:
          pass
        prev_second = current_second
        prev_rpm = current_rpm
        prev_speed = current_speed
      i = i + 1
    print('done with acceleration lag ' + str(datetime.now(tz)))
    r_trip_data=[]
    for row in trip_data:
      row['SPD_MPH_RT']=Decimal(row['SPD_KPH_RT']/Decimal(KPH_TO_MPH_CONVERSION_FACTOR))
      row['DISTNC_MPH']=Decimal(row['SPD_MPH_RT']/3600)
      row['DISTNC_KPH']=Decimal(row['DISTNC_MPH']* Decimal(KPH_TO_MPH_CONVERSION_FACTOR))
#       del row['row_number']
      r_trip_data.append(row)
    return_trip_data.extend(r_trip_data)
  return return_trip_data

# COMMAND ----------


