# Databricks notebook source
ONE_HOUR_IN_SECONDS = 60 * 60
MISSING_SECONDS_HOUR_TRIP_THRESHOLD = 0.25
MISSING_SECONDS_GT_HOUR_TRIP_THRESHOLD = 0.06
MIN_NUMBER_OF_SECONDS_TO_ACCEPT_TRUNCATED_TRIP = 3

# COMMAND ----------

# MAGIC %python
# MAGIC def isMissingTooManySeconds(second1, second2, size):
# MAGIC   print('is missing too many seconds? (start) ' + str(datetime.now(tz)))
# MAGIC   missngTooManySeconds = False
# MAGIC   if size > 0:
# MAGIC     timeBetween = second2 - second1
# MAGIC     secondsBetween = timeBetween.seconds
# MAGIC     percentMissing = float(1 - (size / (secondsBetween + 1)))
# MAGIC     lessThanOneHour = secondsBetween < ONE_HOUR_IN_SECONDS
# MAGIC     missingTooManySeconds = lessThanOneHour and percentMissing > MISSING_SECONDS_HOUR_TRIP_THRESHOLD or not lessThanOneHour and percentMissing > MISSING_SECONDS_GT_HOUR_TRIP_THRESHOLD
# MAGIC     print('is missing too many seconds? (end) ' + str(datetime.now(tz)))
# MAGIC   return missingTooManySeconds

# COMMAND ----------

def removeFarFutureEndSecond(partitionData): 
  print('removing far future end second (start)' + str(datetime.now(tz)))
  data_by_trip = {}
  for row in partitionData:
    # Add name to dict if not exists
    if row["TRIP_SMRY_KEY"] not in data_by_trip:
        data_by_trip[row["TRIP_SMRY_KEY"]] = []
    data_by_trip[row["TRIP_SMRY_KEY"]].append(row)
  return_data=[]
  for tripid in data_by_trip:
    trip_data = data_by_trip[tripid]
    missingTooManySeconds = False
    trip_len = len(trip_data)
    if trip_len > 0:
      r_mssng_flag_data=[]
      second1 = trip_data[0]['PSTN_TS']
      lastSec = trip_data[-1]['PSTN_TS']
      missingTooManySeconds = isMissingTooManySeconds(second1, lastSec, trip_len)
      if missingTooManySeconds and trip_len > 1:
        sizeMinusOne = trip_len - 1
        try:
          secondToLast = trip_data[-2]['PSTN_TS']
        except:
          secondToLast = trip_data[-1]['PSTN_TS']
        if (lastSec - secondToLast).seconds > 60:
          missingTooManySeconds = sizeMinusOne < MIN_NUMBER_OF_SECONDS_TO_ACCEPT_TRUNCATED_TRIP or isMissingTooManySeconds(second1, secondToLast, sizeMinusOne)
          if not missingTooManySeconds:
            for key in trip_data:
              row_as_dict=key.asDict()
              row_as_dict['MSSNG_TOO_MANY_SEC_FLAG']=0
              if row_as_dict['PSTN_TS'] != lastSec:
                r_mssng_flag_data.append(row_as_dict)
            print('removing far future end second (deleting, end) ' + str(datetime.now(tz)))
    print('removing far future end second (no deletion, end)' + str(datetime.now(tz)))
    if len(r_mssng_flag_data)==0:
      r_data=[]
      for row in trip_data:
        row_as_dict = row.asDict()
        row_as_dict["MSSNG_TOO_MANY_SEC_FLAG"] = 1 if missingTooManySeconds else 0
        r_data.append(row_as_dict)
      return_data.extend(r_data)
    else:
      return_data.extend(r_mssng_flag_data)
  return iter(return_data)
#       yield Row(**row_as_dict)
