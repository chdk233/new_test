# Databricks notebook source
print("calling the python child notebook")

# COMMAND ----------

def test_curation_child_sensitive(microBatchDF, batchId, harmonizedDB, curateDB, target_table,encryptColumns,secretKey,is_encryptdata):
  print("\n entering test_curation_child_sensitive \n")
  curate_table = curateDB +"."+target_table
  print("---curate table--",curate_table)
  print("---curateDB----",curateDB)
  
#   print("Microbatch received in child notebook... ") # added for testing 
#   microBatchDF.show() #added for testing,to see if df have decrypted columns..Should not have show() statement in actual notebook!!!
  #Encrypt
  if is_encryptdata:
    encryptedDF =encryptDataframe(microBatchDF,encryptColumns,secretKey)
    encryptedDF.createOrReplaceGlobalTempView("V")
    display(spark.sql("select * from global_temp.V"))
    encryptedDF.write.mode("append").format("delta").saveAsTable(f"{curate_table}")
    
  else:
    microBatchDF.createOrReplaceGlobalTempView("V")
    display(spark.sql("select * from global_temp.V"))
    microBatchDF.write.mode("append").format("delta").saveAsTable(f"{curate_table}")
   
 
