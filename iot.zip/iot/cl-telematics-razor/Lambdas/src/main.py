"""
Acquire AWS Lambda function is for moving file from external transient bucket to Nationwide internal bucket.
"""
import boto3
import json
from datetime import datetime

def move_file(client, source_bucket, source_key, target_bucket, target_key):
    # Copy the source Amazon S3 object to the target Amazon S3 location.
        client.copy_object(
            CopySource={
                "Bucket": source_bucket,
                "Key": source_key
            },
            Bucket=target_bucket,
            Key=target_key
        )

    # Delete the source Amazon S3 object.
        client.delete_object(
            Bucket=source_bucket,
            Key=source_key
        )
        
def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]
    
    current_timestamp = datetime.now()
    current_date = current_timestamp.date()
    current_hour = str(current_timestamp.hour) + '00' if current_timestamp.hour > 9 else '0' + str(current_timestamp.hour) + '00'
    #print(json.dumps(event))
    # Get Amazon S3 source information.
    s3_source = json.loads(event.get("Records")[0].get("Sns").get("Message")).get("Records")[0].get("s3")
    print(s3_source)
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    s3_source_object_key = s3_source.get("object").get("key")
    s3_file_size = s3_source.get("object").get("size")
    
    if s3_file_size == 0: 
        pass
    else:
        # Get Amazon S3 target information.
        s3_target_bucket_name = f"pcd-internal-cl-telematics-razor-{account_number}-us-east-1"
        source_object_array = s3_source_object_key.split("/")
        target_folder = source_object_array[0]
        object_key = source_object_array[1]
        s3_target_object_key = f"{target_folder}/load_date={current_date}/{current_hour}/{object_key}"
    
        print("S3 Source bucket: " + s3_source_bucket_name)
        print("S3 Source Object key: " + s3_source_object_key) 
        print("S3 Target bucket: " + s3_target_bucket_name)
        print("S3 Target Object key: " + s3_target_object_key)
        
        move_file(s3_client, s3_source_bucket_name, s3_source_object_key, s3_target_bucket_name, s3_target_object_key)