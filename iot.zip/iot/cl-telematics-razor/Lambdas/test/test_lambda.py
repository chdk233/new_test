import unittest
from main import lambda_handler

class TestLambda(unittest.TestCase):

    def setUp(self):
        """Set up resources needed for test"""
        pass

    def test_lambda(self):
        """ Run the unit test"""
        test_event = dict()
        test_event["queryStringParameters"] = ""
        test_event["pathParameters"] = ""
        test_event["stageVariables"] = ""
        test_event["httpMethod"] = "get"
        test_event["body"] = "TestBody"

        test_context = dict()

        #response = lambda_handler(test_event, test_context)
        self.assertEqual("Hello World!", "Hello World!")

    def tearDown(self):
        """Delete resources created by setUp"""
        pass


