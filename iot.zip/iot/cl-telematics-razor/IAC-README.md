# Serverless

[Product Guide on GoCloud](https://gocloud.nwie.net/docs/aws/management-and-governance/service-catalog/pipeline-serverless-simple/)

