"""
AWS Lambda function for the DW PersonalLines SmartHome application.
Moves source files from SmartHome External bucket to Internal Bucket.
"""
import boto3
import json
import datetime
import csv

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    print(f"Received following event {event}")
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    s3_resource = boto3.resource('s3')
    
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]
    
    # filename=event.get('filename')
    # bucket="dw-internal-telematics-786994105833"
    path=event.get('s3path')
    # key="test2/REPLAY.csv"
    bucket=path.split('/')[2]
    key=path.split('/',3)[3]
    
    s3_object = s3_resource.Object(bucket, key)
    data = s3_object.get()['Body'].read().decode('utf-8').splitlines()
    lines = csv.reader(data)
    headers = next(lines)
    for row in lines:
      load_date=datetime.datetime.strptime(row[1], '%m/%d/%Y').strftime('%Y-%m-%d')
      load_hour=datetime.datetime.strptime(row[2], '%Y-%m-%dT%H:%M:%S.%f+0000').strftime('%H00')
      print(load_date,load_hour)
      if row[3]=='IMS_SM_5X':
        s3_source_bucket_name=f"dw-internal-telematics-{account_number}"
        s3_source_object_key=f'SmartMiles-IMS-SourceFiles/load_date='+load_date+'/'+load_hour+'/'+row[0]+'.zip'
        s3_target_object_key=f'SmartMiles-IMS-SourceFiles/load_dateReplay='+load_date+'/'+load_hour+'/'+row[0]+'.zip'
      if row[3]=='IMS_SR_5X':
        s3_source_bucket_name=f"dw-internal-telematics-{account_number}"
        s3_source_object_key=f'SmartRide-IMS-SourceFiles/load_date='+load_date+'/'+load_hour+'/'+row[0]+'.zip'
        s3_target_object_key=f'SmartRide-IMS-SourceFiles/load_dateReplay='+load_date+'/'+load_hour+'/'+row[0]+'.zip'
      if row[3]=='IMS_SR_4X':
        s3_source_bucket_name=f"dw-internal-telematics-{account_number}"
        s3_source_object_key=f'SmartRide4X-IMS-SourceFiles/load_date='+load_date+'/'+load_hour+'/'+row[0]+'.DAT'
        s3_target_object_key=f'SmartRide4X-IMS-SourceFiles/load_dateReplay='+load_date+'/'+load_hour+'/'+row[0]+'.DAT'
      if row[3]=='FMC_SM':
        s3_source_bucket_name=f"dw-internal-telematics-{account_number}"
        s3_source_object_key=f'SmartMiles-FMC-SourceFiles/load_date='+load_date+'/'+load_hour+'/'+'CC_FMC_'+row[0]+'.json'
        s3_target_object_key=f'SmartMiles-FMC-SourceFiles/load_dateReplay='+load_date+'/'+load_hour+'/'+'CC_FMC_'+row[0]+'.json'
      if row[3]=='FMC_SR':
        s3_source_bucket_name=f"dw-internal-telematics-{account_number}"
        s3_source_object_key=f'SmartRide-FMC-SourceFiles/load_date='+load_date+'/'+load_hour+'/'+'CC_FMC_'+row[0]+'.json'
        s3_target_object_key=f'SmartRide-FMC-SourceFiles/load_dateReplay='+load_date+'/'+load_hour+'/'+'CC_FMC_'+row[0]+'.json'
      if row[3]=='TIMS_SR':
        s3_source_bucket_name=f"dw-internal-telematics-{account_number}"
        s3_source_object_key=f'SmartRide-TIMS-SourceFiles/load_date='+load_date+'/'+load_hour+'/'+row[0]+'.zip'
        s3_target_object_key=f'SmartRide-TIMS-SourceFiles/load_dateReplay='+load_date+'/'+load_hour+'/'+row[0]+'.zip'
      s3_client.copy_object(
              CopySource={
              "Bucket": s3_source_bucket_name,
              "Key": s3_source_object_key
              },
         Bucket=s3_source_bucket_name,
         Key=s3_target_object_key)
    return event