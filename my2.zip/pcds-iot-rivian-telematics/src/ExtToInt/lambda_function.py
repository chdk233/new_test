"""
Acquire AWS Lambda function for the DW Personal Lines Rivian application.
"""
from datetime import datetime
import boto3
import json

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    print(f"Received following event {event}")
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]

    # Get Amazon S3 source information.
    sns_message = event.get('Records')[0].get('Sns').get('Message')
    s3_source = json.loads(sns_message).get("Records")[0].get("s3")
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    s3_source_object_key = s3_source.get("object").get("key") 
    
    # Get Amazon S3 target information.
    extracted_date=s3_source_object_key.rsplit('_',1)[1].split('.')[0]
    date_format=datetime.strptime(extracted_date,'%Y%m%d').strftime('%Y-%m-%d')
    
    s3_target_bucket_name = f"pcds-internal-iot-rivian-telematics-{account_number}"
   
    s3_target_object_key = f"rivian-sourcefiles/daily/load_date={date_format}/{s3_source_object_key}"
    
    print('Target path: ',s3_target_object_key)
    
    # Copy the source Amazon S3 object to the target Amazon S3 location.
    s3_client.copy_object(
        CopySource={
            "Bucket": s3_source_bucket_name,
            "Key": s3_source_object_key
        },
        Bucket=s3_target_bucket_name,
        Key=s3_target_object_key
    )

    # Delete the source Amazon S3 object.
    s3_client.delete_object(
        Bucket=s3_source_bucket_name,
        Key=s3_source_object_key
    )
