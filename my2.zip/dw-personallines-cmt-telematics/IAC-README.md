# Serverless

[Product Guide on GoCloud](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/simple-serverless-pipeline/)

