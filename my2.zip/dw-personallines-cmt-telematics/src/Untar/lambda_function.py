"""
Standardize AWS Lambda function for the DW PersonalLines CMT Telematics application.
Untar tar.gz files into NW Internal bucket.
Also to create a duplicate copy for Json file to send to SRP
"""
import os
import sys
import re
import json
import tarfile
import datetime
import dateutil.tz
import urllib.parse
from io import BytesIO

import boto3

#Set timezone to US/Eastern 
#eastern = dateutil.tz.gettz('US/Eastern')
#s3_file_timestamp = datetime.datetime.now(tz=eastern).strftime("%Y%m%d%H%M_")
    
def lambda_handler(event, context):
    
    # Initialize client objects for AWS services.
    s3_client = boto3.client('s3')
    sns_client = boto3.client('sns')
    s3_resource = boto3.resource('s3')
    
    # List of expected files and size
    expected = {
        'trip_detail.csv': 169,
        'trip_summary.json': 0
    }
    present = []
    missing = []
    empty = []

    # Parse and prepare required items from event
    global s3_source_bucket_name, path, tardata, s3_target_prefix
    print('event:',event)
    
    # Get Amazon S3 source information.
    sns_message = event.get('Records')[0].get('Sns').get('Message')
    s3_source = json.loads(sns_message).get("Records")[0].get("s3")
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    print(f"s3_source_bucket_name:'{s3_source_bucket_name}'")
    s3_source_object_key = urllib.parse.unquote(s3_source.get("object").get("key"))
    print(f"s3_source_object_key:'{s3_source_object_key}'")
    print(os.path.dirname(s3_source_object_key))
    s3_target_bucket_name = s3_source_bucket_name
    
    #event = next(iter(event['Records']))
    #s3_source_bucket_name = event['s3']['bucket']['name']
    #print(f"s3_source_bucket_name:'{s3_source_bucket_name}'")
    #s3_source_object_key = urllib.parse.unquote(event['s3']['object']['key'])
    #print(f"s3_source_object_key:'{s3_source_object_key}'")
    #print(os.path.dirname(s3_source_object_key))
    #s3_target_bucket_name = s3_source_bucket_name
    
    s3_path = os.path.dirname(s3_source_object_key)
    s3_filename = os.path.basename(s3_source_object_key)
    if 'DS_CMT_SRMCM' in s3_filename:
      s3_strip_filename          = s3_filename.lstrip('DS_CMT_SRMCM_')
    elif 'DS_CMT_SRM' in s3_filename:
      s3_strip_filename          = s3_filename.lstrip('DS_CMT_SRM')
    else :
      s3_strip_filename          = s3_filename
    
    #s3_target_prefix = "CMT/"+s3_path.split("/")[2]+"/"+s3_filename.split('.')[0]
    s3_target_prefix = "CMT/"+s3_path.split('/',3)[3]+"/"+s3_strip_filename.split('.')[0]
    
    #Get and extract the tar file from the source key location.
    response = s3_client.get_object(Bucket=s3_source_bucket_name,Key=s3_source_object_key)
    stream = response.get('Body').read()
    
    with tarfile.open(fileobj= BytesIO(stream)) as tar:
        for tar_content in tar:
            if(tar_content.isfile()):
                inner_tar_content = tar.extractfile(tar_content).read()
                s3_target_object_key = f'{s3_target_prefix}/{tar_content.name}'
                s3_client.upload_fileobj(BytesIO(inner_tar_content),s3_target_bucket_name,s3_target_object_key)
                print('File: '+s3_target_object_key+' uploaded successfully.')
                # Check for all expected files among the present files
                for name_f in expected:
                    if name_f in tar_content.name:
                        present.append(name_f)
                # Check if any files are empty. If so, add to list
                real_time = s3_resource.Object(s3_target_bucket_name, s3_target_object_key)
                if real_time.content_length <= expected[tar_content.name]:
                    empty.append(tar_content.name)
            
                
    # Assess all missing files
    for name_f in expected:
        if name_f not in present:
            missing.append(name_f)
    
    print('Missing: ',missing)
    print('Present: ',present)
    print('Empty: ',empty)
            
    # Send SNS if a missing file is found
    if len(missing) > 0:
        missing_files = '\n'.join(missing)
        sns_client.publish(
            TopicArn = os.getenv("SnsNotification"),
            Message = f'The following files received were missing: \n {missing_files}',
            Subject = 'dw-pl-cmt-TelematicsS3FileUntar:Real time data file(s) missing')
        print('Missing file(s) found, SNS sent.')
        
    # Send SNS if file is empty
    if len(empty) > 0:
        empty_files = '\n'.join(empty)
        sns_client.publish(
            TopicArn = os.getenv("SnsNotification"),
            Message = f'The following files received were empty: \n {empty_files}',
            Subject = 'dw-pl-cmt-TelematicsS3FileUntar:Real time data file(s) empty')
        print('Empty file(s) found, SNS sent.')