"""
Provide AWS Lambda function for the DW PersonalLines CMT Telematics application.
Copy 3 files from NW Internal bucket to SRP Bucket.
"""
import os
import urllib.parse
import boto3
# import logging
# logger = logging.getLogger()
# logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # logger.info('## ENVIRONMENT VARIABLES')
    # logger.info(os.environ)
    # logger.info('## EVENT')
    # logger.info(event)
    # logging.basicConfig(filename="mylog.log", level=logging.DEBUG)
    """
    The entry point of the AWS Lambda function.
    """
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
   
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]

    # Get Amazon S3 source information.
    s3_source = event.get("Records")[0].get("s3")
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    s3_source_object_key = urllib.parse.unquote(s3_source.get("object").get("key"))
    s3_source_object_base_name = os.path.basename(s3_source_object_key)
    print(f"s3_source_object_base_name:'{s3_source_object_base_name}'")    
    s3_filename_text = os.path.splitext(s3_source_object_base_name)[0]
    print(f"s3_filename_text:'{s3_filename_text}'") 
    dataset_identifier = s3_filename_text[8:]
    print(f"dataset_identifier:'{dataset_identifier}'") 
    
    #Print Source values
    print(f"s3_source_bucket_name: '{s3_source_bucket_name}' s3_source_object_key: '{s3_source_object_key}'")

    # Get Amazon S3 target information.
    s3_target_bucket_name = os.getenv("S3_TargetBucketName")
    s3_target_object_key = f"{s3_source_object_base_name}"

    #Print Target values
    print(f"s3_target_bucket_name: '{s3_target_bucket_name}' s3_target_object_key: '{s3_target_object_key}'")
    
    # Copy the source Amazon S3 object to the target Amazon S3 location.
    s3_client.copy_object(
        CopySource={
            "Bucket": s3_source_bucket_name,
            "Key": s3_source_object_key
        },
        Bucket=s3_target_bucket_name,
        Key=s3_target_object_key,
        ACL='bucket-owner-full-control'
    )

