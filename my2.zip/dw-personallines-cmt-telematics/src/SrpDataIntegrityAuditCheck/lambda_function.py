"""
AWS Lambda function to perform DataIntegrity Audit check on files processed by SRP
"""
import boto3
import io
import re
import time
from datetime import date, timedelta, datetime
from io import BytesIO

def lambda_handler(event, context):
    global s3_source_bucket_name, s3_client
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    sns_client = boto3.client('sns')
    # Define the Amazon S3 source and target information.
    account_number = sts_client.get_caller_identity()['Account']
    s3_source_bucket_name = f'dw-internal-pl-cmt-telematics-{account_number}'
    sns_topic_arn = f'arn:aws:sns:us-east-1:{account_number}:DW-PL-CMT-Telematics'
    
    #Fetch the previous and current date value
    previous_date = str(datetime.now()-timedelta(days=1))[:10]
    currrent_date = str(datetime.now())[:10]

    print('Data Integrity Audit of files for the date: ',previous_date)

    #Prepare Audit Query
    processed_trip_query = f"Select drive_id from telematics_staging_db.cmt_sr_mobile_stage_trip_summary where drive_id not in (Select trip_id from telematics_staging_db.cmt_sr_srp_di_trip_summary_successtrips where load_dt between '{previous_date}' and '{currrent_date}' union Select trip_id from telematics_staging_db.cmt_sr_srp_di_trip_summary_ignoretrips where load_dt between '{previous_date}' and '{currrent_date}') and load_date='{previous_date}'"

    print('Data Integrity Audit Query: ',processed_trip_query)

    #Default parameters for S3 bucket that would contain the default output file generated post query execution.
    #These files will be removed post successful completion of the repair statements.
    params = {
        'region': 'us-east-1',
        'database': 'telematics_staging_db',
        'path': 'DataIntegrityLogs',
        'source_bucket': s3_source_bucket_name
    }
    
    
    #Clear out old output log files, if any
    cleanup(params)

    #Run Audit query in Athena 
    athena_to_s3(params=params,query=processed_trip_query)
    time.sleep(30)  
    #Check if there are any missing trips and notify via SNS
    missing_trip_id_list = check_drive_ids(params)
    if len(missing_trip_id_list) == 0:
        print(f'CMT DI Audit succeeded for the date: {previous_date}.')
        print('CMT Data Integrity check completed.')
    else:
        search_location = f'CMT/CMT_trip_control/load_date={previous_date}'
        missing_trip_ctl_prefix = {tripid:f'{search_location}/{tripid}' for tripid in missing_trip_id_list}
        
        drive_id = lambda filename: filename.split('_')[0]
        trip_hour = lambda filename: filename.rsplit('/',1)[1].rsplit('_',1)[1].split('.')[0]
        
        trip_ctl_file_prefix = {tripid:pull_trip_ids(s3_client,s3_source_bucket_name,previous_date,search_location,prefix) for tripid,prefix in missing_trip_ctl_prefix.items()}
        copytosrp_search_prefix = {tripid:f'CMT/CopyToSRP/load_date={previous_date}/{trip_hour(prefix)}/DS_CMT_{tripid}_{previous_date}_{trip_hour(prefix)}_trip_intervals_SRP.csv' for tripid,prefix in trip_ctl_file_prefix.items() if prefix and prefix.strip()}
        copytosrp_trips = {tripid:pull_trip_ids(s3_client,s3_source_bucket_name,previous_date,search_location,prefix) for tripid, prefix in copytosrp_search_prefix.items()}
        
        
        trip_without_realtime_files, trip_missing_in_CopyToSRP, trip_available_in_CopyToSRP = [], [], []
        for tripid,ctl_file_path in trip_ctl_file_prefix.items():
            if ctl_file_path == '':
                trip_without_realtime_files.append(tripid)
        available_trip_count = 0
        for tripid,srp_file_path in copytosrp_trips.items():
            if srp_file_path == '':
                trip_missing_in_CopyToSRP.append(tripid)
            else:
                trip_available_in_CopyToSRP.append(tripid)
        
        #print('CopyToSrp trips: ',copytosrp_trips)
        print('Trips with no realtime files in Internal Bucket: ',trip_without_realtime_files)
        print('Trips missing in CopyToSRP: ',trip_missing_in_CopyToSRP)
        
        if len(trip_without_realtime_files)>0:
            print(f'Realtime files not received for {len(trip_without_realtime_files)} trip id(s).')
            trips_without_realtime_files_msg = '\n'.join(trip_without_realtime_files)
            msg = f'Realtime files source files (tar.gz) have not been received for the following set of trip id(s):\n{trips_without_realtime_files_msg}'
            sub = f'Data Integrity Audit check-{previous_date}:Missing trip source files'
            publish_sns_message(sns_client,sns_topic_arn,msg,sub)
        
        if len(trip_missing_in_CopyToSRP)>0:
            print(f'{len(trip_missing_in_CopyToSRP)} trip(s) are missing in CopyToSRP.')
            trip_missing_in_CopyToSRP_msg = '\n'.join(trip_missing_in_CopyToSRP)
            msg = f'Realtime files unavailable in CopyToSRP for the following set of trip id(s):\n{trip_missing_in_CopyToSRP_msg}'
            sub = f'Data Integrity Audit check-{previous_date}: Trips missing in CopyToSRP'
            publish_sns_message(sns_client,sns_topic_arn,msg,sub)
            
        if len(trip_available_in_CopyToSRP)>0:
            trips_not_processed_by_SRP = '\n'.join(trip_available_in_CopyToSRP)
            print(f'Following trip id(s) have not been processed by SRP: {str(trips_not_processed_by_SRP)}.')
            msg = f'Following trip id(s) have not been processed by SRP:\n{str(trips_not_processed_by_SRP)}'
            sub = f'Data Integrity Audit check-{previous_date}: Trips not processed by SRP'
            publish_sns_message(sns_client,sns_topic_arn,msg,sub)
                
    #Delete output files post run
    cleanup(params)


#Function to execute Athena statements
def athena_query(client, params, query):
    
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': params['database']
        },
        ResultConfiguration={
            'OutputLocation': 's3://' + s3_source_bucket_name + '/' + params['path']
        }
    )
    return response

#Function to execute the athena audit query and notify the state of execution
def athena_to_s3(params, query, max_execution = 20):
    client = boto3.client('athena')
    execution = athena_query(client, params, query)
    execution_id = execution['QueryExecutionId']
    state = 'RUNNING'

    while (max_execution > 0 and state in ['RUNNING','QUEUED']):
        max_execution = max_execution - 1
        response = client.get_query_execution(QueryExecutionId = execution_id)

        if 'QueryExecution' in response and \
                'Status' in response['QueryExecution'] and \
                'State' in response['QueryExecution']['Status']:
            state = response['QueryExecution']['Status']['State']

            if state == 'FAILED':
                print('Audit Query run failed.')
                print('response: ',response)
                return False
            elif state == 'SUCCEEDED':
                print('Audit Query run succeeded.')
                s3_path = response['QueryExecution']['ResultConfiguration']['OutputLocation']
                filename = re.findall('.*\/(.*)', s3_path)[0]
                return filename
        time.sleep(5)
    
    return False

#Function to fetch the the query output file and return the extracted drive id values list
def check_drive_ids(params):
    s3_client = boto3.client('s3')
    response = s3_client.list_objects_v2(Bucket=s3_source_bucket_name, Prefix=params['path']+'/')
    if 'Contents' not in response:
        print('Output file not available.')
    else:
        run_date = str(datetime.now())[:10]
        s3_source_object_key = response['Contents'][0]['Key']
        s3_file_size = response['Contents'][0]['Size']
        decodeBytes = lambda byteStream: byteStream.decode('utf-8')
        drive_id_list = []
        response = s3_client.get_object(Bucket=s3_source_bucket_name,Key=s3_source_object_key)
        stream = response.get('Body')
        outboundStream = BytesIO()
        outboundStream.seek(0)
        for line in stream.iter_lines():
            drive_id_list.append(str(decodeBytes(line)).strip('\"'))
        return drive_id_list[1:]


#Function to cleanup output file generated in S3 location
def cleanup(params):
    s3_resource = boto3.resource('s3')
    response = s3_client.list_objects_v2(Bucket=s3_source_bucket_name, Prefix=params['path']+'/')
    if 'Contents' in response:
        for item in response['Contents']:
            s3_resource.Object(s3_source_bucket_name, item['Key']).delete()
            print(s3_source_bucket_name+'/'+item['Key'] +' Deleted Successfully')
    else:
        print('No files available for cleanup.')
        
#Helper function to publish SNS messages
def publish_sns_message(sns_client, topic_arn, msg, sub):
    sns_client.publish(
                TopicArn = topic_arn,
                Message = msg,
                Subject = sub
            )      

#Function to pull out all the record keys with the assigned prefix from S3
def pull_trip_ids(client,s3_source_bucket_name,previous_date,location,prefix):
    paginator = client.get_paginator('list_objects')
    operational_parameters = {'Bucket': s3_source_bucket_name,'Prefix':prefix}
    page_iterator = paginator.paginate(**operational_parameters)
    available_trips = ''
    for page in page_iterator:
        if 'Contents' not in page:
            continue
        else:
            for records in page['Contents']:
                if prefix in records['Key']:
                    available_trips = records['Key']
                    break

    return available_trips