"""
AWS Lambda function to load CMT Enrollment data
"""
import json
import boto3
import io
from io import BytesIO
import datetime

def convertHeaderContextJSONToCSV(headerContextCSVList,header_context_dict,offset):
    
    lists = headerContextCSVList
    offset = offset
    lis_ = []
    if header_context_dict:
        id_val = header_context_dict.get('id','')
        source_val = header_context_dict.get('source','')
        time_val = header_context_dict.get('time','')
        type_val = header_context_dict.get('type').split('.')[-2]+'.'+header_context_dict.get('type').split('.')[-1] if header_context_dict.get('type','') != '' else ''
        lis_.extend([id_val,source_val,time_val,type_val,offset])
    else:
        print('Source data does not have context dict.')
    lists.append(lis_)
    #print(lists)
    return lists

def convertCMTEnrollmentJSONToCSV(CMTEnrollmentCSVList,CMTEnrollment_dict,event_id,offset):
    
    lis_ = []
    lists = CMTEnrollmentCSVList
    event_id = event_id
    offset = offset
    enrollment_id = CMTEnrollment_dict.get("enrollmentId",'')
    policy_nb = CMTEnrollment_dict.get("policyNumber",'')
    program_type = CMTEnrollment_dict.get('programType','')
    program_effective_date = CMTEnrollment_dict.get('effectiveDate','')
    vendor = CMTEnrollment_dict.get('vendor','')
    enrollmentprocess_dt = CMTEnrollment_dict.get('enrollmentProcessDate','')
    programstatus = CMTEnrollment_dict.get('status','')
    program_end_date = CMTEnrollment_dict.get('endDate','')
    
    #Driver dictionary within Enrollment dictionary
    driver_dict = CMTEnrollment_dict.get('driver')
    driver_nb = driver_dict.get('driverNumber','')
    driver_nb = round(driver_nb)
    driver_fname = driver_dict.get('firstName','')
    driver_mname = driver_dict.get('middleName','')
    driver_lname = driver_dict.get('lastName','')
    driver_suffix = driver_dict.get('suffix','')
    
    #Data Collectionary dictionary within Driver dictionary
    datacollection_dict = driver_dict.get('dataCollection')
    datacollection_id = datacollection_dict.get('dataCollectionId','')
    shortuser_id = datacollection_dict.get('shortUserId','')
    datacollectionbegin_date = datacollection_dict.get('dataCollectionBeginDate','')
    datacollectionend_date = datacollection_dict.get('dataCollectionEndDate','') if datacollection_dict.get('dataCollectionEndDate','') != '' else ''
    datacollection_status = datacollection_dict.get('dataCollectionStatus','')
    
    # Device dictionary within Data Collection dictionary
    device_dict = datacollection_dict.get('device')
    device_id = device_dict.get('deviceId','')
    device_status = device_dict.get('deviceStatus','')
    deviceregistration_dt = device_dict.get('registrationDate','')
    
    #Score and discount dictionary within Enrollment dictionary
    score_discount_dict = CMTEnrollment_dict.get('scoreAndDiscount')
    if score_discount_dict:
        score = score_discount_dict.get('score','') if score_discount_dict.get('score','') != '' else ''
        score_type = score_discount_dict.get('scoreType','') if score_discount_dict.get('scoreType','') != '' else ''
        driverscoremodel = score_discount_dict.get('driverScoreModel','') if score_discount_dict.get('driverScoreModel','') != '' else ''
        scoredate = score_discount_dict.get('scoreDate','') if score_discount_dict.get('scoreDate','') != '' else ''
        discountpercent = score_discount_dict.get('discountPercent','') if score_discount_dict.get('discountPercent','') != '' else ''
    else:
        score = ''
        score_type = ''
        driverscoremodel = ''
        scoredate = ''
        discountpercent = ''
    lis_.extend([enrollment_id,policy_nb,program_type,program_effective_date,vendor,enrollmentprocess_dt,programstatus,program_end_date,driver_nb,driver_fname,driver_mname,driver_lname,driver_suffix,datacollection_id,shortuser_id,datacollectionbegin_date,datacollectionend_date,datacollection_status,device_id,device_status,deviceregistration_dt,score,score_type,driverscoremodel,scoredate,discountpercent,event_id,offset])
    lists.append(lis_)
    #print(lists)
    return lists
    
def convertHeaderJSONToCSV(headerCSVList,header_dict,event_id):
    
    lis_ = []
    lists = headerCSVList
    event_id = event_id
    topic = header_dict.get('topic','')
    partition = header_dict.get('partition','')
    offset = header_dict.get('offset','')
    timestamp = header_dict.get('timestamp','')
    timestamp_type = header_dict.get('timestampType','')
    lis_.extend([event_id,topic,partition,offset,timestamp,timestamp_type])
    lists.append(lis_)
    #print(lists)
    return lists

def writeCSVByteData(data_list):
    concatenate_list_values = lambda list_data: ','.join([str(data) for data in list_data])
    merge_values = [concatenate_list_values(row) for row in data_list]
    add_new_lines = '\n'.join(merge_values)
    encoded_data = str.encode(add_new_lines)
    bytes_io = BytesIO()
    bytes_io.seek(0)
    bytes_io.write(encoded_data)
    return bytes_io

def lambda_handler(event, context):
    
    #Define S3 client and folder details
    print(f'Received the following event: {event}')
    s3_client = boto3.client('s3')
    s3_source_event = event.get("Records")[0].get("s3")
    s3_source_bucket_name=s3_source_event.get("bucket").get("name")
    s3_source_object_key = s3_source_event.get("object").get("key")
    event_time = event.get('Records')[0].get('eventTime')[11:-1].replace(':','').replace('.','-')
    target_object_prefix = 'CMT/SRPPLEnrollment_rt'
    load_date = str(datetime.datetime.utcnow())[:10]
    
    context_folder_name = 'SHPContext'
    enrollment_folder_name = 'SHPEnrollment'
    header_folder_name = 'SHPHeader'
    
    context_file_name = 'CMT-enrollment-header-context'
    CMTEnrollment_file_name = 'CMT-enrollment'
    header_file_name = 'CMT-enrollment-header'
    
    header_context_key = []
    CMTEnrollment_key = []
    header_key = []
   
    #Define headers for all the target files
    header_context_keys = ['event_id','event_source','event_time', 'event_type', 'offset']
    CMTEnrollment_keys = ['enrollment_id','policy_nb', 'program_type', 'program_effective_date', 'vendor', 'enrollmentprocess_dt', 'programstatus', 'program_end_date', 'driver_nb', 'driver_fname', 'driver_mname', 'driver_lname', 'driver_suffix', 'datacollection_id', 'shortuser_id', 'datacollectionbegin_date', 'datacollectionend_date', 'datacollection_status', 'device_id', 'device_status', 'deviceregistration_dt', 'score', 'score_type', 'driverscoremodel', 'scoredate', 'discountpercent', 'event_id', 'offset']
    header_keys = ['event_id','topic','partition','offset','timestamp','timestamp_type']
    
    header_context_key.append(header_context_keys)
    CMTEnrollment_key.append(CMTEnrollment_keys)
    header_key.append(header_keys)
    
    #Define the List variable
    headerContextCSVList = header_context_key
    CMTEnrollmentCSVList = CMTEnrollment_key
    headerCSVList = header_key    
    
    #Stream the S3 Source object and convert JSON data to CSV ByteStreams
    data = s3_client.get_object(Bucket=s3_source_bucket_name,Key=s3_source_object_key)
    body = data['Body'].read().decode('utf-8')
    #body = data.get('Body')[0]
    body = body.replace("\\","")
    body = body.replace('"u0000u0000u0000u0000u0013',"")
    body = body.replace('}"','}')
    body = io.StringIO(body)
    
    for line in body:
        #source_data = json.load(line.get('Body'))[0]
        source_data = json.loads(line)
        
        #Define source dicts from which the data is to be extracted
        header_context_dict = source_data.get('value').get('context')
        CMTEnrollment_dict = source_data.get('value').get('smartRideEnrollment')
        header_dict = source_data
        offset = header_dict.get('offset','')
        event_id = header_context_dict.get('id','')
        
        #Get multiple rows in a single list
        headerContextCSVList = convertHeaderContextJSONToCSV(headerContextCSVList,header_context_dict,offset)
        CMTEnrollmentCSVList = convertCMTEnrollmentJSONToCSV(CMTEnrollmentCSVList,CMTEnrollment_dict,event_id,offset)
        headerCSVList = convertHeaderJSONToCSV(headerCSVList,header_dict,event_id)
    
    #Call JSONToCSV functions to extract field data from source dicts
    headerContextCSVByteStream = writeCSVByteData(headerContextCSVList)
    CMTEnrollmentCSVByteStream = writeCSVByteData(CMTEnrollmentCSVList)
    headerCSVByteStream = writeCSVByteData(headerCSVList)
    
    #Seek ByteStreams to starting position
    headerContextCSVByteStream.seek(0)
    CMTEnrollmentCSVByteStream.seek(0)
    headerCSVByteStream.seek(0)
    
    #Upload ByteStream data to target S3 location
    print(f'Upload Context file to: {target_object_prefix}/{context_folder_name}/load_dt={load_date}/{context_file_name}-{offset}-{event_time}.csv')
    s3_client.upload_fileobj(headerContextCSVByteStream,s3_source_bucket_name,f'{target_object_prefix}/{context_folder_name}/load_dt={load_date}/{context_file_name}-{offset}-{event_time}.csv')
    print(f'Uploading Enrollment file to: {target_object_prefix}/{enrollment_folder_name}/load_dt={load_date}/{CMTEnrollment_file_name}-{offset}-{event_time}.csv')
    s3_client.upload_fileobj(CMTEnrollmentCSVByteStream,s3_source_bucket_name,f'{target_object_prefix}/{enrollment_folder_name}/load_dt={load_date}/{CMTEnrollment_file_name}-{offset}-{event_time}.csv')
    print(f'Uploading Header file to: {target_object_prefix}/{header_folder_name}/load_dt={load_date}/{header_file_name}-{offset}-{event_time}.csv')
    s3_client.upload_fileobj(headerCSVByteStream,s3_source_bucket_name,f'{target_object_prefix}/{header_folder_name}/load_dt={load_date}/{header_file_name}-{offset}-{event_time}.csv')
    
    #Reposition the source file to its corresponding load_date folder
    target_s3_object_key = s3_source_object_key.rsplit('/',2)[0]+'/ProcessedFiles/load_dt='+load_date+'/'+s3_source_object_key.rsplit('/',1)[1]
    copy_source = {'Bucket':s3_source_bucket_name,'Key':s3_source_object_key}
    s3_client.copy_object(CopySource=copy_source,Bucket=s3_source_bucket_name,Key=target_s3_object_key)
    s3_client.delete_object(Bucket=s3_source_bucket_name,Key=s3_source_object_key)
