"""
AWS Lambda function to perform RealTime Audit check.  
"""
import boto3
import io
import re
import time
import os
from datetime import date, timedelta, datetime
from io import BytesIO

def lambda_handler(event, context):
    global s3_source_bucket_name, s3_client
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    
    print('Received the following event: ',event)
    
    s3_source = event.get("Records")[0].get("s3")
    s3_object_key = s3_source.get('object').get('key')
    
    #Fetch the previous and current date values from the source filename
    previous_date = s3_object_key.split('/')[2].split('__')[1]
    current_date = s3_object_key.split('/')[2].split('__')[2].split('_')[0]

    # Define the Amazon S3 source and target information.
    s3_source_bucket_name = s3_source.get('bucket').get('name')

    print(f"S3 Source Bucket Name:'{s3_source_bucket_name}'")

    print('Audit check of files for the dates: ' +previous_date+' to '+current_date)

    #Repair statements for individual CMT Athena tables
    cmt_audit_query = f"Select * from telematics_staging_db.cmt_sr_mobile_stage_trip_summary where drive_id not in (Select distinct drive_id from telematics_staging_db.cmt_sr_mobile_stage_trip_detail_rt where load_date between '{previous_date}' and '{current_date}') and load_date='{previous_date}'"

    print('Audit Query: ',cmt_audit_query)

    #Default parameters for S3 bucket that would contain the default output file generated post query execution.
    #These files will be removed post successful completion of the repair statements.
    params = {
        'region': 'us-east-1',
        'database': 'telematics_staging_db',
        'path': 'AuditLogs'
    }
    
    #Clear out old output log files, if any
    cleanup(params)

    #Run Audit query in Athena 
    athena_to_s3(params=params,query=cmt_audit_query)
    time.sleep(30)    
    #Check for drive id's in the output file
    check_drive_ids(s3_client,params,previous_date)
    
    #Delete the output file generated during query execution
    cleanup(params)


#Function to execute Athena statements
def athena_query(client, params, query):
    
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': params['database']
        },
        ResultConfiguration={
            'OutputLocation': 's3://' + s3_source_bucket_name + '/' + params['path']
        }
    )
    return response

#Function to execute the athena audit query and notify the state of execution
def athena_to_s3(params, query, max_execution = 20):
    client = boto3.client('athena')
    execution = athena_query(client, params, query)
    execution_id = execution['QueryExecutionId']
    state = 'RUNNING'

    while (max_execution > 0 and state in ['RUNNING','QUEUED']):
        max_execution = max_execution - 1
        response = client.get_query_execution(QueryExecutionId = execution_id)

        if 'QueryExecution' in response and \
                'Status' in response['QueryExecution'] and \
                'State' in response['QueryExecution']['Status']:
            state = response['QueryExecution']['Status']['State']

            if state == 'FAILED':
                print('Audit Query run failed.')
                print('response: ',response)
                return False
            elif state == 'SUCCEEDED':
                print('Audit Query run succeeded.')
                s3_path = response['QueryExecution']['ResultConfiguration']['OutputLocation']
                filename = re.findall('.*\/(.*)', s3_path)[0]
                return filename
        time.sleep(5)
    
    return False

#Function to check the query output file and send SNS notification about audit check success/failure
def check_drive_ids(s3_client,params,previous_date):

    response = s3_client.list_objects_v2(Bucket=s3_source_bucket_name, Prefix=params['path']+'/')
    if 'Contents' not in response:
        print('Output file not available.')
    else:
        sns_client = boto3.client('sns')
        sts_client = boto3.client('sts')
        account_number = sts_client.get_caller_identity()['Account']
        sns_topic_arn = f'arn:aws:sns:us-east-1:{account_number}:DW-PL-CMT-Telematics'
        run_date = str(datetime.now())[:10]
        s3_source_object_key = response['Contents'][0]['Key']
        s3_file_size = response['Contents'][0]['Size']
        drive_id_list = []
        record_count = 0
        get_object_response = s3_client.get_object(Bucket=s3_source_bucket_name,Key=s3_source_object_key)
        stream = get_object_response.get('Body')
        for line in stream.iter_lines():
            decoded_string = decodeBytes(line)
            drive_id_data = decoded_string.split(',')[4].strip('"')
            drive_id_list.append(drive_id_data)
            record_count= record_count+1
        if(record_count < 2):
            print('CMT RealTime Audit check is successful.')
        else:
            search_location = f'CMT/CMT_trip_control/load_date={previous_date}'
            missing_trip_ctl_prefix = {tripid:f'{search_location}/{tripid}' for tripid in drive_id_list[1:]}
            trip_ctl_file_prefix = {tripid:pull_trip_ids(s3_client,s3_source_bucket_name,previous_date,search_location,prefix) for tripid,prefix in missing_trip_ctl_prefix.items()}
            #print('trip_ctl_file_prefix: ',trip_ctl_file_prefix)
            
            trip_without_realtime_files = []
            for tripid,ctl_file_path in trip_ctl_file_prefix.items():
                if ctl_file_path == '':
                    trip_without_realtime_files.append(tripid)
            trips_not_in_Intl_fldr = [tripid for tripid in drive_id_list[1:] if tripid not in trip_without_realtime_files]
			
            if len(trips_not_in_Intl_fldr)>0:
                drive_id_values = '\n'.join(trips_not_in_Intl_fldr)
                print(f'CMT RealTime Audit check failed. Found {len(trips_not_in_Intl_fldr)} drive id values. Sending SNS notification.')
                msg = f'CMT RealTime Audit check failed.\n\nBelow listed Drive id values have not been processed:\n\n{drive_id_values}'
                sub = f'CMT RealTime Audit check: {previous_date}'
                publish_sns_message(sns_client, sns_topic_arn, msg, sub)
            
            if len(trip_without_realtime_files)>0:
                drive_id_values = '\n'.join(trip_without_realtime_files)
                print(f'CMT RealTime Audit check failed. Found {len(trip_without_realtime_files)} drive id(s) for which realtime tar.gz file(s) are not available. Sending SNS notification.')
                msg = f'CMT RealTime Audit check failed.\n\nRealtime tar.gz files not received from CMT for the listed Drive id(s) :\n\n{drive_id_values}'
                sub = f'CMT RealTime Audit check: {previous_date}'
                publish_sns_message(sns_client, sns_topic_arn, msg, sub)


#Function to cleanup output file generated in S3 location
def cleanup(params):
    s3_resource = boto3.resource('s3')
    response = s3_client.list_objects_v2(Bucket=s3_source_bucket_name, Prefix=params['path']+'/')
    if 'Contents' in response:
        for item in response['Contents']:
            s3_resource.Object(s3_source_bucket_name, item['Key']).delete()
            print(s3_source_bucket_name+'/'+item['Key'] +' Deleted Successfully')
    else:
        print('No files available for cleanup.')
        
#Helper function to publish SNS messages
def publish_sns_message(sns_client, topic_arn, msg, sub):
    sns_client.publish(
                TopicArn = topic_arn,
                Message = msg,
                Subject = sub
            )
            
#Helper function to decode Bytestream into string format
def decodeBytes(byteStream):
    return byteStream.decode('utf-8')

#Function to pull out all the record keys with the assigned prefix from S3
def pull_trip_ids(client,s3_source_bucket_name,previous_date,location,prefix):
    paginator = client.get_paginator('list_objects')
    operational_parameters = {'Bucket': s3_source_bucket_name,'Prefix':prefix}
    page_iterator = paginator.paginate(**operational_parameters)
    available_trips = ''
    for page in page_iterator:
        if 'Contents' not in page:
            continue
        else:
            for records in page['Contents']:
                if prefix in records['Key']:
                    available_trips = records['Key']
                    break

    return available_trips