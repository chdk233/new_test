import json
import boto3
import ast
import os
import urllib.parse
import datetime
def lambda_handler(event, context):
    try:

        print(event)
        #Define S3 resource
        s3_resource = boto3.resource('s3')
        #Get event details:
        s3_target_bucket = event.get('TargetPath').split('/')[2]
        s3_target_object_key_path = 'CMT/CopyToSRP/'
        #s3_target_object_key_path = 'trip_summary_SRP/DS_CMT_'
        messages = ast.literal_eval(event.get('Message'))
        print('Message: ',messages)
        s3_source_object_key = urllib.parse.unquote(messages.get('TripSummaryPath').split('//')[1].split('/',1)[1].rsplit('/',1)[0]+'/trip_summary.json')
        print(s3_source_object_key)
        #s3_event_hour = str(datetime.datetime.utcnow())[11:13]+'00'
        #s3_event_date = str(datetime.datetime.utcnow())[:10]
        s3_event_hour = s3_source_object_key.split('/')[2]
        s3_event_date = s3_source_object_key.split('/')[1].split('=')[1]        
        #Prepare file for rename
        copy_source = {'Bucket': s3_target_bucket, 'Key': s3_source_object_key}
        #s3_target_object_key = s3_target_object_key_path+copy_source['Key'].split('/')[2]+'_trip_summary_SRP.json'
        s3_target_object_key = s3_target_object_key_path+s3_source_object_key.split('/',1)[1].rsplit('/',3)[0]+'/DS_CMT_'+s3_source_object_key.split('/')[4]+'_'+s3_event_date+'_'+s3_event_hour+'_trip_summary_SRP.json'
        #s3_target_object_key = f"{s3_target_object_key_path}/load_date={s3_event_date}/{s3_event_hour}/DS_CMT_{s3_source_object_key.split('/')[4]}_trip_summary_SRP.json"
        print('Target Bucket:',s3_target_bucket)
        print('S3 Copy Source: ',copy_source)
        print('Target Key: ',s3_target_object_key)            
        s3_resource.meta.client.copy(CopySource=copy_source,Bucket=s3_target_bucket,Key=s3_target_object_key)
    except Exception as e:
        sns_arn=':'.join(event.get("SnsErrorArn").split(':')[:-1]).strip(' ')+':TripSummaryError'
        print(sns_arn)
        print(e)
        sns = boto3.resource('sns')
        topic = sns.Topic(sns_arn)
        MESSAGE_JSON={ "Error" : str(e) ,
                         "LogStreamName" : context.log_stream_name,
                         "LogGroupName" : context.log_group_name }
        topic.publish(Message=json.dumps(
            {'default':  json.dumps(MESSAGE_JSON)}
        ),
            Subject='Trip Summary Json Lambda Failed',
            MessageStructure='json')
        exit(1)
