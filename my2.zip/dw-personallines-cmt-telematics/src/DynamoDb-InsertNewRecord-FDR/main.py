import boto3
import datetime
import os
import logging
import json

FORMAT = '%(asctime)s [%(module)s.%(funcName)s:%(lineno)d] %(levelname)s: %(message)s'
logging.basicConfig(format=FORMAT, datefmt="%Y-%m-%d %H:%M:%S")
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv("LOGLEVEL", "INFO"))

def handler(event,context):

    LOGGER.info(f"Event received: {event}")

    AWS_PROFILE          = event.get('AwsProfile')
    SNS_MESSAGE          = event.get('Records')[0].get('Sns').get('Message')
    S3_SOURCE            = json.loads(SNS_MESSAGE).get("Records")[0].get("s3")
    S3_SOURCE_OBJECT_KEY = S3_SOURCE.get("object").get("key")
    REGION               = context.invoked_function_arn.split(':')[4]
    NOW                  = datetime.datetime.now()
    CURRENT_DATE         = NOW.strftime('%Y-%m-%d')
    CURRENT_TIME         = NOW.strftime('%H:%M:%S.%f')
    TABLE_NAME           = os.getenv('TABLE_NAME')

    (root,basename)      = S3_SOURCE_OBJECT_KEY.split("/")
    accountId            = root.strip('DS_FDR_NW-')
    driveId              = basename.rstrip(".tar.gz")

    if AWS_PROFILE:
        dynamoDb = boto3.Session(profile_name=AWS_PROFILE,
                                 region_name=REGION).client('dynamodb')
    else:
        dynamoDb = boto3.client('dynamodb')

    LOGGER.info(f"Inserting drive id {driveId} for account id {accountId} "+
                f"into dynamo db table {TABLE_NAME}")

    response = dynamoDb.put_item(
        TableName=TABLE_NAME,
        Item={
            'AccountId' : {
                'S' : accountId
            },
            'DriveId' : {
                'S' : driveId
            },
            'FileReceivedDate' : {
                'S' : CURRENT_DATE
            },
            'FileReceivedTime' : {
                'S' : CURRENT_TIME
            }
        }
    )

    LOGGER.info(f"Dynamo DB put item response: {response}")

if __name__ == "__main__":

    event = {'AwsProfile' : 'DevDW01-CUSTOMADMIN-AWS',
        'Records': [{'EventSource': 'aws:sns', 'EventVersion': '1.0', 'EventSubscriptionArn': 'arn:aws:sns:us-east-1:786994105833:DW-PL-FDR-InboundS3Event:ae5022c6-8c98-4d54-babb-90ef58cd1040', 'Sns': {'Type': 'Notification', 'MessageId': '825fc490-8f7d-505f-8ec2-9337060491b7', 'TopicArn': 'arn:aws:sns:us-east-1:786994105833:DW-PL-FDR-InboundS3Event', 'Subject': 'Amazon S3 Notification', 'Message': '{"Records":[{"eventVersion":"2.1","eventSource":"aws:s3","awsRegion":"us-east-1","eventTime":"2020-08-07T16:54:12.580Z","eventName":"ObjectCreated:Copy","userIdentity":{"principalId":"AWS:AROAJRBIQJL57GYU2HFFG:roberd7"},"requestParameters":{"sourceIPAddress":"104.225.190.129"},"responseElements":{"x-amz-request-id":"47506A7B211E6780","x-amz-id-2":"rFDDyvvXR3v1JKP/dQhsHrZjQDWxTIRM9S0yZPFXqtwok17DxuzU12eVTk6J+Je8Xj491wDC0faLGf7tnvsgDhG9e9U14Ohh"},"s3":{"s3SchemaVersion":"1.0","configurationId":"0588176c-dfc4-4de8-b33f-f5738ddcef2f","bucket":{"name":"dw-pl-fdr-telematics-786994105833","ownerIdentity":{"principalId":"A11HQLDEIK1LLY"},"arn":"arn:aws:s3:::dw-pl-fdr-telematics-786994105833"},"object":{"key":"FDR_NW-2ba9d51e-8c82-49f0-91a9-abe8f0036aaf/08F24489-1C44-4C20-B558-4B42A5E6D2BA.tar.gz","size":65992,"eTag":"2cd64e0533638cae91623a098b0882c2","sequencer":"005F2D8737EE8AA584"}}}]}', 'Timestamp': '2020-08-07T16:54:17.773Z', 'SignatureVersion': '1', 'Signature': 'kKd01KyE9Y4RJBiqG8SKbi73CBLiX0HqZyVYzeR9DPjrvXTd0bc1i6yMQk6GVuOeWIu8quYbnpfCUHRezHKEubDFNsIMmHtGcDbkJEB4SMYBk0U8SO8i5AaNzxYAk+pN1zx7BUfCPPDEReArlIgO34GYLrlxkj5U2vivF6+uBd1A37oRvrE5Pwly60PPNDdqa7gRGGtqRzMmP8H4RzLvtgPU33CJxmu0qKuVmLn+IDYCn60t5rZC0xjUfb1n2CFLKssV/MZJojQgXuxqR5ZblSiUKTSCTbRhTVEcnRLtcRB954Iz4+bzFIlpgoexNq0biOJn98lReYhtvn7A/rm3Tw==', 'SigningCertUrl': 'https://sns.us-east-1.amazonaws.com/SimpleNotificationService-a86cb10b4e1f29c941702d737128f7b6.pem', 'UnsubscribeUrl': 'https://sns.us-east-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-east-1:786994105833:DW-PL-FDR-InboundS3Event:ae5022c6-8c98-4d54-babb-90ef58cd1040', 'MessageAttributes': {}}}]}

    class context:

        def __init__(self):
            self.invoked_function_arn = 'arn:aws:lambda:123456789:us-east-1:function:foobar'

    os.environ['TABLE_NAME']='fdr-trips-control-table'

    handler(event,context())