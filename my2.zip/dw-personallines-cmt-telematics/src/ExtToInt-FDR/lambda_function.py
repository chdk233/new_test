"""
Acquire AWS Lambda function for the DW Personal Lines Telematics application.
"""
import boto3
import json
import datetime
from io import BytesIO

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    print(f"Received following event {event}")
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    
    current_utcdate = str(datetime.datetime.utcnow())[:10]
    current_utchour = str(datetime.datetime.utcnow())[11:13]+'00'
    
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]

    # Get Amazon S3 source information.
    sns_message = event.get('Records')[0].get('Sns').get('Message')
    s3_source = json.loads(sns_message).get("Records")[0].get("s3")
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    s3_source_object_key = s3_source.get("object").get("key") 
    
    # Get Amazon S3 target information.
    s3_target_bucket_name = f"dw-internal-pl-cmt-telematics-{account_number}"
    #Set target file path to the updated location for tar.gz source files
    if '.tar.gz' in s3_source_object_key:
        s3_target_object_key = f'FDR-SourceFiles/realtime/load_date={current_utcdate}/{current_utchour}/{s3_source_object_key}'
        filename_split = s3_source_object_key.split('/')
        account_id, drive_id = filename_split[0], filename_split[1].split('.')[0]
        control_file_name = f'{drive_id}_{account_id}_{current_utchour}.txt'
        control_file_object_key = f'FDR/FDR_trip_control/load_date={current_utcdate}/{control_file_name}'
        outboundStream = BytesIO()
        outboundStream.seek(0)
        s3_client.upload_fileobj(outboundStream,Bucket=s3_target_bucket_name,Key=control_file_object_key)
        print('Control file object key: ',control_file_object_key,s3_source_bucket_name)
    else:
        s3_target_object_key = f"FDR-SourceFiles/daily/{s3_source_object_key}"
    
    print('Target path: ',s3_target_object_key)
    
    # Copy the source Amazon S3 object to the target Amazon S3 location.
    s3_client.copy_object(
        CopySource={
            "Bucket": s3_source_bucket_name,
            "Key": s3_source_object_key
        },
        Bucket=s3_target_bucket_name,
        Key=s3_target_object_key
    )

    # Delete the source Amazon S3 object.
    s3_client.delete_object(
        Bucket=s3_source_bucket_name,
        Key=s3_source_object_key
    )
