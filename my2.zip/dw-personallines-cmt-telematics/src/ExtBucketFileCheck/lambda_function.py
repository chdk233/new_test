import boto3
import datetime
from dateutil.tz import tzlocal

def lambda_handler(event, context):
    #Define S3 and STS Clients
    s3_client = boto3.client('s3')
    sts_client = boto3.client('sts')
    account_number = sts_client.get_caller_identity()['Account']
    paginator = s3_client.get_paginator('list_objects_v2')
    s3_source_bucket_name = f'dw-pl-cmt-telematics-{account_number}'
    file_receipt_time_check = lambda file_datetime : (datetime.datetime.now(tz=tzlocal()) - file_datetime).total_seconds() > 7200
    response_dict = {}
    for response in paginator.paginate(Bucket=s3_source_bucket_name):
        if 'Contents' in response:
            response_dict = {record['Key']:record['LastModified']  for record in response['Contents'] if file_receipt_time_check(record['LastModified'])}
    if response_dict:
        print(f'Found {len(response_dict.keys())} file(s) older than 2 hours....Sending SNS notification.')
        sns_client = boto3.client('sns')
        sns_topic_arn = f'arn:aws:sns:us-east-1:{account_number}:DW-PL-CMT-Telematics'
        message = f'{len(response_dict.keys())} file(s) have been unprocessed for the past 2 hours or more. \n\nFile Names:\n'+"\n".join(response_dict.keys())
        subject = f'CMT S3 External Bucket File check: {str(datetime.datetime.now())[:16]} UTC'
        sns_client.publish(TopicArn=sns_topic_arn,Message=message,Subject=subject)
        print(f'S3 External file check for: {str(datetime.datetime.now())[:16]} UTC completed successfully.')
    else:
        print('Could not find files that have been unprocessed for the past 2 hours or more in S3 External Bucket.')
        print(f'S3 External file check for: {str(datetime.datetime.now())[:16]} UTC completed successfully.')
