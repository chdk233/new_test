"""
This program will read a trip summary and trip detail file for a given trip and
 define kilometers drive for each given time period. The json file 
 time_bucket_config.json defines bucket boundaries
"""
# standard
import logging
import os
import json
import argparse

# pyspark
from pyspark.sql.functions import lit
from pyspark.sql.functions import regexp_extract
from pyspark.sql import SparkSession

# app specific
from __transformations__ import (define_sum_expression,
                                 calculate_distance,
                                 retrieve_time_bucket_config,
                                 create_time_buckets_udfs)

# arguments

parser = argparse.ArgumentParser()
parser.add_argument('--trip-summary',
                    dest='ts',
                    type=str,
                    required=True)
parser.add_argument('--trip-detail',
                    dest='td',
                    type=str,
                    required=True)
parser.add_argument('--data-root',
                    dest='data_root',
                    type=str,
                    required=True)

args = parser.parse_args()

data_root = args.data_root
trip_summary_path = f"{data_root}/{args.ts}"
trip_detail_path = f"{data_root}/{args.td}"

# setting session
spark = SparkSession.builder.getOrCreate()

# read from trip_summary file to acquire utc offset and drive id
# these will be used when creating the time of day reporting
trip_summary = spark.read.csv(trip_summary_path, header=True)

# defining utc_offset and drive_id
# utc_offset is used during trip_detail processing
# drive_id is used to name the final file
drive_id, utc_offset = trip_summary.select(trip_summary.Driveid,
                    regexp_extract(trip_summary.Utc_offset,r'^(.*?):.*',1).cast('int')).head()

utc_offset = lit(utc_offset).cast('int').alias('utc_offset')


# read from trip_detail file to build distance driven by time bucket/period
trip_detail = spark.read.csv(trip_detail_path, header=True)

#reduce to needed columns and convert epoch ms to timestamp

trip_detail = trip_detail.select(trip_detail.drive_id,
                                 (trip_detail.time.cast('long')/1000.0).cast('timestamp').alias('time'),
                                 trip_detail.mm_dist_km
                                 )


trip_detail = \
    trip_detail.select(trip_detail.drive_id,
                       trip_detail.time,
                       calculate_distance(trip_detail.mm_dist_km,trip_detail.time)
                        )

trip_detail = trip_detail.withColumn('utc_offset',utc_offset)

time_buckets_conf = retrieve_time_bucket_config(spark)

myUdfs = create_time_buckets_udfs(time_buckets_conf)

trip_detail = trip_detail.select('drive_id', *myUdfs , 'distance')

# sum distance driven for each interval
trip_detail = \
    trip_detail.groupBy('drive_id') \
    .agg(*define_sum_expression(trip_detail))

# write output
trip_detail.coalesce(1) \
    .write.csv(f"{data_root}/{drive_id}_trip_intervals.temp",
               sep=',',
               header=True, mode='overwrite')

#Now to rename the output file
if data_root.startswith('/'):
    from shutil import rmtree
    dir_list = os.listdir(f"{data_root}/{drive_id}_trip_intervals.temp")
    temp_file = [path for path in dir_list if path.startswith('part')][0]
    os.rename(f"{data_root}/{drive_id}_trip_intervals.temp/{temp_file}",
              f"{data_root}/{drive_id}_trip_intervals.csv")
    rmtree(f"{data_root}/{drive_id}_trip_intervals.temp")
