"""Logic used to define time interval fields. The file "time_bucket_config.json"
found in the same directory as this file will drive how the time buckets are
created.

{
    "interval_one": {
        "Saturday": {
            "lower": "00:00:00",
            "upper": "04:59:59"
        },
        "Sunday": {
            "lower": "00:00:00",
            "upper": "04:59:59"
        }
    },
    .
    .
    .
    "interval_eight": {
        "Monday": {
            "lower": "19:00:00",
            "upper": "23:59:59"
        },
        "Tuesday": {
            "lower": "19:00:00",
            "upper": "23:59:59"
        },
        "Wednesday": {
            "lower": "19:00:00",
            "upper": "23:59:59"
        },
        "Thursday": {
            "lower": "19:00:00",
            "upper": "23:59:59"
        },
        "Friday": {
            "lower": "19:00:00",
            "upper": "23:59:59"
        }
    }
}
"""

# Standard
import datetime
import calendar
import os
import json
from decimal import Decimal

# Spark
from pyspark.sql import DataFrame
from pyspark.sql import Column
from pyspark.sql import Row
from pyspark.sql import SparkSession
from pyspark import SparkContext
import pyspark.sql.functions as pyspark_funct
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType
from pyspark.sql.types import StringType


def retrieve_time_bucket_config(spark: SparkSession):
    """Used to parse time_bucket_conf.json and returns dict"""
    CONFIG_DIR = os.path.dirname(__file__)
    CONFIG_FILE = "time_bucket_config.json"
    CONFIG_PATH = f"{CONFIG_DIR}/{CONFIG_FILE}"
    spark.sparkContext.addFile(CONFIG_PATH)
    with open(CONFIG_PATH) as f:
        time_buckets_conf = json.load(f)

    return time_buckets_conf

def encode_interval_conf(interval: dict):
    """Takes the interval dict and converts day names to integer representing
    day of the week and converts values to array of datetime.time objects
    representing lower and upper time boundaries """
    DAYS = list(calendar.day_name)
    encoded_interval = {}
    for k,v in interval.items():
        encoded_interval[DAYS.index(k)]=[parse_time_string(v.get('lower')),
                                         parse_time_string(v.get('upper'))]
    return encoded_interval


def create_time_buckets_udfs(conf: dict):
    """dynamically creates udfs based on time_bucket_config.json. Returns a list
    of UDFs, one for each interval"""
    udfs = []
    for interval_name in conf:
        # convert interval specs
        interval_conf = encode_interval_conf(conf.get(interval_name))
        # this lambda represents the udf logic
        # first condition checks to see if the local time zone day is in that 
        # interval definition.
        # second condition validates that the local timestamp is within the
        # lower and upper boundaries for that day.
        # if both conditions are met it returns the distance, otherwise 0.0
        f = lambda utc_offset,utc_date_time,distance:  \
                distance \
                if interval_conf.get((utc_date_time + datetime.timedelta(hours=utc_offset)).weekday()) \
                    and \
                    interval_conf.get((utc_date_time + datetime.timedelta(hours=utc_offset)).weekday())[0] \
                        <= utc_date_time.time() <= \
                    interval_conf.get((utc_date_time + datetime.timedelta(hours=utc_offset)).weekday())[1] \
                else Decimal(0.0)
        
        interval_udf = pyspark_funct.udf(f,DecimalType(precision=10,scale=3))

        udfs.append(
            interval_udf('utc_offset',
                         'time',
                         'distance').alias(interval_name)
        )
    return udfs


def calculate_distance(cumulative_distance: Column, time: Column):
    """
    windowing used to compare prior row, this is to derive distance driven
    since previous row.
    """
    w = Window.orderBy(time)
    return (
        cumulative_distance.cast('float') - pyspark_funct.lag(cumulative_distance,
                                                              default=0.0)
        .over(w).cast('float')
    ).alias('distance').cast(DecimalType(precision=10,scale=3))


def define_sum_expression(dataframe: DataFrame):
    """Will return a list of sum expressions for each column
    except drive_id. It will also rename distance to total_dist
    """
    return [pyspark_funct.sum(dataframe[col])
            .alias(col if col != 'distance' else 'total_dist')
            for col in dataframe.columns
            if col != 'drive_id']

def parse_time_string(time: str):
    """Converts time as string hh:mm:ss to datetime.time object"""
    time_parts = time.split(":")
    time_dict = \
        {"hour": int(time_parts[0]),
         "minute": int(time_parts[1]),
         "second": int(time_parts[2])}
    return datetime.time(**time_dict)

