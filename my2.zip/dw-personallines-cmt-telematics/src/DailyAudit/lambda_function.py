"""
AWS Lambda function to check if daily files received to internal bucket from CMT or not. This requirement is not to check Internal Vs GDL. 
"""
import json
import boto3
import os
from datetime import date, timedelta, datetime

def lambda_handler(event, context):
    # Get today's date and format propely
    today = date.today()
    today = today.strftime("%Y-%m-%d")
    print('Today: ' + today)
    
    # Get expected date
    expected_date = datetime.now() - timedelta(days = 1)
    expected_date = str(expected_date)
    expected_date = expected_date[:10]
    print('Expected date: ' + expected_date)
    
    client = boto3.client('s3')
    
    # Get the key of the expected date's daily files
    daily_file = client.list_objects(
        Bucket= os.getenv("InternalBucketName"),
        Prefix='CMT/DS_CMT__'+expected_date
    )
    
    print('Prefix: ' + 'CMT/DS_CMT__'+expected_date)
    # If the key is blank, the file hasn't been received, send SNS
    if 'Contents' not in daily_file:
        client = boto3.client('sns')
        client.publish(
            TopicArn = os.getenv("SnsNotification"),
            Message = f'The daily files have not been received for {expected_date}.',
            Subject = 'dw-pl-cmt-TelematicsDaily-Audit:Daily Zip file is not received'
        )
        print("Daily files not received, SNS sent.")
    else:
        print('Daily files received.')
