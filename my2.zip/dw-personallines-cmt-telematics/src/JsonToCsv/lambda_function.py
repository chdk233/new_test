"""
Standardize AWS Lambda function for the DW PersonalLines CMT Telematics application.
Convert CMT drive events data to a CSV format.
"""
import io
import json
import os
import shutil
import sys

import urllib.parse
import boto3
from io import BytesIO


def concatenate_list_values(list_data):
	str_list = [str(data) for data in list_data]
	return ','.join(str_list) 


def write_csv_data(data):
    """
    Write CSV data to a string buffer.
    """
    print('data: ',data)
    merge_values = [concatenate_list_values(row) for row in data]
    print('merge_values: ',merge_values)
    add_new_lines = '\n'.join(merge_values)
    print('add_new_lines: ',add_new_lines)
    encoded_data = str.encode(add_new_lines)
    print('encoded_data: ',encoded_data)
    bytes_io = BytesIO()
    bytes_io.seek(0)
    bytes_io.write(encoded_data)

    return bytes_io

def convert_summary_data(data):
    """
    Convert CMT drive summary data to a CSV format.
    """
    lists = []
    dictionaries = [{}]

    summary_fields = (
        "Driveid",
        "Distance_km",
        "Driving",
        "Id",
        "Deviceid",
        "Utc_offset",
        "classification",
        "idle_sec",
        "nightdriving_sec",
        "account_id"
    )
    for field in summary_fields:
        dictionaries[0][field]=data.get(field.lower(),'')
        

    # Add field headers.
    lists.append(list(summary_fields))

    # Convert dictionaries to lists for events array.
    if dictionaries:
        for dictionary in dictionaries:
            list_ = []

            for field in summary_fields:
                list_.append(dictionary.get(field))

            none_removed = ['' if field is None else field for field in list_]
            lists.append(none_removed)
    
    return write_csv_data(lists)

def convert_events_data(data):
    """
    Convert CMT drive events data to a CSV format.
    """
    
    lists = []
    dictionaries = data.get("events")

    event_fields = (
        "event_type",
        "displayed",
        "lon",
        "lat",
        "ts",
        "value",
        "severe",
        "speed_kmh",
        "max_mss",
        "duration_sec",
        "speed_delta_kmh",
        "duration_for_speed_delta_sec",
        "turn_dps"
    )

    # Add field headers.
    lists.append(list(event_fields))

    # Convert dictionaries to lists for events array.
    if dictionaries:
        for dictionary in dictionaries:
            list_ = []

            for field in event_fields:
                list_.append(dictionary.get(field))

            none_removed = ['' if field is None else field for field in list_]
            lists.append(none_removed)

    return write_csv_data(lists)


def convert_waypoints_data(data):
    """
    Convert CMT drive events waypoints data to a CSV format.
    """
    lists = []
    dictionaries = data.get("waypoints")

    fields = (
        "display_code_a",
        "display_code_b",
        "lon",
        "lat",
        "ts",
        "avg_moving_speed_kmh",
        "max_speed_kmh",
        "speed_limit_kmh",
        "link_id",
        "prepended"
    )

    # Add field headers.
    lists.append(list(fields))

    # Convert dictionaries to lists.
    if dictionaries:
        for dictionary in dictionaries:
            list_ = []

            for field in fields:
                if field == "display_code_a":
                    list_.append(dictionary.get("display_code")[0])
                elif field == "display_code_b":
                    list_.append(dictionary.get("display_code")[1])
                else:
                    list_.append(dictionary.get(field))

            none_removed = ['' if field is None else field for field in list_]
            lists.append(none_removed)

    return write_csv_data(lists)



def convert_tripstart_data(data):
    """
    Convert CMT trip start data to a CSV format.
    """
    lists = []
    dictionaries = data.get("start")

    start_fields = (
        "ts",
        "lat",
        "lon"
    )
    # Add field headers.
    lists.append(list(start_fields))

    list_ = [dictionaries.get(field) for field in start_fields]
    none_removed = ['' if field is None else field for field in list_]
    lists.append(none_removed)

    return write_csv_data(lists)


def convert_tripend_data(data):
    """
    Convert CMT trip end data to a CSV format.
    """
    lists = []
    dictionaries = data.get("end")


    end_fields = (
        "ts",
        "lat",
        "lon"
    )
    # Add field headers.
    lists.append(list(end_fields))

    list_ = [dictionaries.get(field) for field in end_fields]
    none_removed = ['' if field is None else field for field in list_]
    lists.append(none_removed)
    
    return write_csv_data(lists)



def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")

    # Get source Amazon S3 information.
    source_s3_event = event.get("Records")[0].get("s3")
    source_s3_bucket_name = source_s3_event.get("bucket").get("name")
    source_s3_object_key = urllib.parse.unquote(source_s3_event.get("object").get("key"))
    source_s3_object_base_name = os.path.basename(source_s3_object_key)
    source_s3_object_prefix = os.path.dirname(source_s3_object_key)

    # Parse out the drive identifier from the source Amazon S3 object base name.
    drive_identifier = source_s3_object_base_name.split("_")[0]

    # Build target Amazon S3 information.
    target_s3_bucket_name = source_s3_bucket_name
    target_s3_object_prefix = source_s3_object_prefix
    target_summary_s3_object_base_name = f"{drive_identifier}_summaryrt.csv"
    target_events_s3_object_base_name = f"{drive_identifier}_events.csv"
    target_waypoints_s3_object_base_name = f"{drive_identifier}_waypoints.csv"
    target_start_s3_object_base_name = f"{drive_identifier}_start.csv"
    target_end_s3_object_base_name = f"{drive_identifier}_end.csv"
    target_summary_s3_object_key = f"{target_s3_object_prefix}/{target_summary_s3_object_base_name}"   
    target_events_s3_object_key = f"{target_s3_object_prefix}/{target_events_s3_object_base_name}"
    target_waypoints_s3_object_key = f"{target_s3_object_prefix}/{target_waypoints_s3_object_base_name}"
    target_start_s3_object_key = f"{target_s3_object_prefix}/{target_start_s3_object_base_name}"
    target_end_s3_object_key = f"{target_s3_object_prefix}/{target_end_s3_object_base_name}"

    
    print('source_s3_object_key:', source_s3_object_key)
    #print('source_file_path:', source_file_path)

    # Stream the source Amazon S3 object.
    response = s3_client.get_object(Bucket=source_s3_bucket_name,Key=source_s3_object_key)
    stream = response.get('Body')
    source_data = json.load(stream)
    target_summary_buffer = convert_summary_data(source_data)
    target_events_buffer = convert_events_data(source_data)
    target_waypoints_buffer = convert_waypoints_data(source_data)
    target_start_buffer = convert_tripstart_data(source_data)
    target_end_buffer = convert_tripend_data(source_data)
    
    #Seek the target file buffers to starting position
    target_summary_buffer.seek(0)
    target_events_buffer.seek(0)
    target_waypoints_buffer.seek(0)
    target_start_buffer.seek(0)
    target_end_buffer.seek(0)
    
    
    # Upload the target summary byte stream to Amazon S3.
    s3_client.upload_fileobj(
        target_summary_buffer,
        target_s3_bucket_name,
        target_summary_s3_object_key
    )
    # Upload the target events byte stream to Amazon S3.
    s3_client.upload_fileobj(
        target_events_buffer,
        target_s3_bucket_name,
        target_events_s3_object_key
    )

    # Upload the target waypoints byte stream to Amazon S3.
    s3_client.upload_fileobj(
        target_waypoints_buffer,
        target_s3_bucket_name,
        target_waypoints_s3_object_key
    )
    
    # Upload the target start byte stream to Amazon S3.
    s3_client.upload_fileobj(
        target_start_buffer,
        target_s3_bucket_name,
        target_start_s3_object_key
    )
    
    # Upload the target end byte stream to Amazon S3.
    s3_client.upload_fileobj(
        target_end_buffer,
        target_s3_bucket_name,
        target_end_s3_object_key
    )

    print(f"s3://{target_s3_bucket_name}/{target_summary_s3_object_key}")
    print(f"s3://{target_s3_bucket_name}/{target_s3_object_prefix}/trip_detail.csv")

    if os.getenv("PUBLISH_TO_SQS") == "True":

        sns = boto3.resource('sns')

        accountId = context.invoked_function_arn.split(':')[4]

        topic = sns.Topic(f"arn:aws:sns:us-east-1:{accountId}:TimeIntervalMain")

        topic.publish(Message=json.dumps(
                {'default': 
                    json.dumps(
                        {"TripSummaryPath": 
                            f"s3://{target_s3_bucket_name}/{target_summary_s3_object_key}",
                        "TripDetailPath":
                            f"s3://{target_s3_bucket_name}/{target_s3_object_prefix}/trip_detail.csv"
                        }
                    )
                }
            ),Subject='Main',MessageStructure='json')