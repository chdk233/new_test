import ast
from distutils.log import error
from email import message
import boto3
from botocore.errorfactory import ClientError
import uuid
import json
import logging as log
import time

def lambda_handler(event, context):
    log.info(event)
    try:
        # Initialize client objects for AWS services.
        s3_client = boto3.client('s3')
        s3_resource = boto3.resource('s3')
        log.info("Initialize client objects for AWS services")
        dynamodb=boto3.client('dynamodb')
        #Source bucket
        # Source_bucket_name = 'dw-internal-pl-cmt-telematics-786994105833'
        # Source_Prefix = 'CMT/Archive/tar/'
        # #target bucket
        # target_bucket_name = 'dw-internal-pl-cmt-telematics-786994105833'
        # target_Prefix = 'test_missingfiles/'
        Source_bucket_name = event['Source_bucket_name']
        Source_Prefix = event['Source_Prefix']
        #target bucket
        target_bucket_name = event['target_bucket_name']
        target_Prefix = event['target_Prefix']

        #load_date
        load_date= event['load_date']
        load_hour= event['load_hour']
        # print(load_hour)
        #tablename 'Reprocessfiles-tosqs-table'
        dynamodb_table = event['table_name'] 

        #flagindicator
        flag_indicator ='N'



        paginator = s3_client.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=Source_bucket_name, Prefix=f'{Source_Prefix}load_date={load_date}/{load_hour}')
        items=[]
        for page in pages:
            for obj in page['Contents']:
                file_pathlist=obj['Key'].split('/')
                filepath = ('/').join(file_pathlist[5:])
                try:
                    #check if file exist in bucket using key
                    s3_client.head_object(Bucket=target_bucket_name, Key=f'{target_Prefix}load_date={load_date}/{load_hour}/{filepath}')

                except ClientError:

                    missing_filepath= f'{Source_Prefix}load_date={load_date}/{load_hour}/{filepath}'
                    # print(missing_filepath)
                    file_etag = obj['ETag']
                    file_size = int(obj['Size'])

                    EVENT_TEMPLATE ={
                    'Id': str(uuid.uuid1),
                    'MessageBody':{
                    "Records":[  
                        {  
                            "eventVersion":"2.2",
                            "eventSource":"aws:s3",
                            "awsRegion":"us-east-1",
                            "eventTime": None,
                            "eventName":"ObjectCreated:Copy",
                            "userIdentity":{  
                                "principalId":"Amazon-customer-ID-of-the-user-who-caused-the-event"
                            },
                            "requestParameters":{  
                                "sourceIPAddress":"104.225.170.109"
                            },
                            "responseElements":{  
                                "x-amz-request-id":"Amazon S3 generated request ID",
                                "x-amz-id-2":"Amazon S3 host that processed the request"
                            },
                            "s3":{  
                                "s3SchemaVersion":"1.0",
                                "configurationId":"f19e4853-9f7f-4e8c-8058-e0d39209efac",
                                "bucket":{  
                                "name": Source_bucket_name,
                                "ownerIdentity":{  
                                    "principalId":"A11HQLDEIK1LLY"
                                },
                                "arn": f"arn:aws:s3:::{Source_bucket_name}"
                                },
                                "object":{  
                                "key": missing_filepath,
                                "size":file_size,
                                "eTag":file_etag,
                                "versionId":"object version if bucket is versioning-enabled, otherwise null",
                                "sequencer": "a string representation of a hexadecimal value used to determine event sequence, only used with PUTs and DELETEs"
                                }
                            }
                        }
                    ]
                    }
                    }
                    items.append(
                        {'PutRequest': {
                        'Item' : 
                            {
                            'Id' : {
                                'S' : str(uuid.uuid1())
                            },
                            'ProcessedFlag' : {
                                'S' : flag_indicator
                            },
                            'LoadDate' : {
                                'S' : load_date
                            }, 
                            'LoadHour' : {
                                'N' : load_hour
                            },
                            'Event' : {
                                'S' : json.dumps(EVENT_TEMPLATE)
                            },
                            'SourceBucket':{
                                'S' : Source_bucket_name
                            },
                            'TargetBucket':{
                                'S' : target_bucket_name
                            },
                            'SourcePrefix':{
                                'S' : Source_Prefix
                            },
                            'TargetPrefix':{
                                'S' : target_Prefix
                            }
                            }
                        }
                        }
                    )
                    if len(items) % 2000 == 0:
                        time.sleep(2)
                        print(" sleeping 2 second")
                    if len(items) % 25 == 0:
                        print("Inserting batch of 25")
                        response = dynamodb.batch_write_item(
                        RequestItems={dynamodb_table : items}
                    )
                        event.update({"BatchIntervalSeconds":20})
                        items.clear()
                        if response.get('UnprocessedItems'):
                            print("Adding unprocessed items to items to process and sleeping 1 second")
                            time.sleep(1)
                            items += response.get('UnprocessedItems').get(dynamodb_table)
                    if len(items) >0:
                        response = dynamodb.batch_write_item(
                            RequestItems={dynamodb_table : items}
                        )
                        items.clear()
                        if response.get('UnprocessedItems'):
                            print("Adding unprocessed items to items to process and sleeping 1 second")
                            time.sleep(1)
                            items += response.get('UnprocessedItems').get(dynamodb_table)
                    event.update({"BatchIntervalSeconds":20})
                    if len(items)==0:
                        event.update({"EndExecution":"True"})
        return event
    except Exception as e:
        log.error(f"Error occured in function ..{e}")


