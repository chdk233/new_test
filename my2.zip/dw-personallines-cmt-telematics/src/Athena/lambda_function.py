"""
AWS Lambda function to add CMT athena table partitions in telematics_staging_db.
"""
import boto3
import io
import re
import time
import os
from datetime import date, timedelta, datetime

def lambda_handler(event, context):
    global s3_source_bucket_name, s3_client
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")

    # Define the Amazon S3 source and target information.
    s3_source_bucket_name = os.getenv("InternalBucketName")
    print(f"s3_source_bucket_name:'{s3_source_bucket_name}'")
    # Get expected date
    current_date = datetime.now()
    next_date = current_date + timedelta(days = 1)
    current_date = str(current_date)
    next_date = str(next_date)[:10]
    current_date = current_date[:10]
    print('Current date in GMT: ' + current_date)
	
    print('Next date in GMT: ' + next_date)

    #Repair statements for individual CMT Athena tables
    cmt_repair_statements = [
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_badge add if not exists partition (load_date='{0}') Location 's3://{1}/CMTDaily/CMTPLbadge/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_driver_profile add if not exists partition (load_date='{0}') Location 's3://{1}/CMTDaily/CMTPLdriver_profile/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_driver_summary add if not exists partition (load_date='{0}') Location 's3://{1}/CMTDaily/CMTPLdriver_summary/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_fraud add if not exists partition (load_date='{0}') Location 's3://{1}/CMTDaily/CMTPLfraud/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_heartbeat add if not exists partition (load_date='{0}') Location 's3://{1}/CMTDaily/CMTPLheartbeat/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_labels add if not exists partition (load_date='{0}') Location 's3://{1}/CMTDaily/CMTPLtrip_labels/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_summary add if not exists partition (load_date='{0}') Location 's3://{1}/CMTDaily/CMTPLtrip_summary/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_detail_rt add if not exists partition (load_date='{0}') Location 's3://{1}/CMT/CMTPLtrip_detail_rt/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_end_rt add if not exists partition (load_date='{0}') Location 's3://{1}/CMT/CMTPLtrip_end_rt/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_events_rt add if not exists partition (load_date='{0}') Location 's3://{1}/CMT/CMTPLtrip_events_rt/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_start_rt add if not exists partition (load_date='{0}') Location 's3://{1}/CMT/CMTPLtrip_start_rt/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_summary_rt add if not exists partition (load_date='{0}') Location 's3://{1}/CMT/CMTPLtrip_summaryrt_rt/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_mobile_stage_trip_waypoints_rt add if not exists partition (load_date='{0}') Location 's3://{1}/CMT/CMTPLtrip_waypoints_rt/load_date={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_srp_di_trip_summary_successtrips add if not exists partition (load_dt='{0}') Location 's3://{1}/SRP/cmt_sr_srp_di_trip_summary_successtrips/load_dt={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_srp_di_trip_summary_ignoretrips add if not exists partition (load_dt='{0}') Location 's3://{1}/SRP/cmt_sr_srp_di_trip_summary_ignoretrips/load_dt={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.cmt_sr_srp_di_trip_summary_errortrips add if not exists partition (load_dt='{0}') Location 's3://{1}/SRP/cmt_sr_srp_di_trip_summary_errortrips/load_dt={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.srp_cmt_header add if not exists partition (load_dt='{0}') Location 's3://{1}/CMT/SRPPLEnrollment_rt/SHPHeader/load_dt={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.srp_cmt_context add if not exists partition (load_dt='{0}') Location 's3://{1}/CMT/SRPPLEnrollment_rt/SHPContext/load_dt={0}/'".format(next_date,s3_source_bucket_name),
        "Alter table telematics_staging_db.srp_cmt_enrollment add if not exists partition (load_dt='{0}') Location 's3://{1}/CMT/SRPPLEnrollment_rt/SHPEnrollment/load_dt={0}/'".format(next_date,s3_source_bucket_name)
    ]

    print('cmt_repair_statements: ',cmt_repair_statements)

    #Default parameters for S3 bucket that would contain the default output file generated post query execution.
    #These files will be removed post successful completion of the repair statements.
    params = {
        'region': 'us-east-1',
        'database': 'telematics_staging_db',
        'path': 'AthenaLogs'
    }

    #Run repair statements for each CMT table
    for statement in cmt_repair_statements:
        athena_to_s3(params=params,query=statement)
    
    #Delete the output file generated during query execution
    cleanup(params)

#Function to execute repair statements
def athena_query(client, params, query):
    
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': params['database']
        },
        ResultConfiguration={
            'OutputLocation': 's3://' + s3_source_bucket_name + '/' + params['path']
        }
    )
    return response

#Function to execute the repair function and notify the state of execution
def athena_to_s3(params, query, max_execution = 20):
    client = boto3.client('athena')
    execution = athena_query(client, params, query)
    execution_id = execution['QueryExecutionId']
    state = 'RUNNING'

    while (max_execution > 0 and state in ['RUNNING','QUEUED']):
        max_execution = max_execution - 1
        response = client.get_query_execution(QueryExecutionId = execution_id)

        if 'QueryExecution' in response and \
                'Status' in response['QueryExecution'] and \
                'State' in response['QueryExecution']['Status']:
            state = response['QueryExecution']['Status']['State']

            if state == 'FAILED':
                print(query.split(".")[1].split(" ")[0]+' Add Partition Failed')
                print('response: ',response)
                return False
            elif state == 'SUCCEEDED':
                print(query.split(".")[1].split(" ")[0]+'  Add Partition Succeeded')
                s3_path = response['QueryExecution']['ResultConfiguration']['OutputLocation']
                filename = re.findall('.*\/(.*)', s3_path)[0]
                return filename
        time.sleep(1)
    
    return False

#Function to cleanup output file generated in S3 location
def cleanup(params):
    s3_resource = boto3.resource('s3')
    for item in s3_client.list_objects_v2(Bucket=s3_source_bucket_name, Prefix=params['path']+'/')['Contents']:
        s3_resource.Object(s3_source_bucket_name, item['Key']).delete()
        print(s3_source_bucket_name+'/'+item['Key'] +' Deleted Successfully')
