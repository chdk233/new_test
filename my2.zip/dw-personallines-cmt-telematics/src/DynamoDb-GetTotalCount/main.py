import boto3

d = boto3.Session(profile_name='pcdwDevelopers-TeamRole-AWS-785562577411',region_name='us-east-1').client('dynamodb')

paginator = d.get_paginator('scan')

paginator_kwargs = {
    'TableName' : 'cmt-trips-control-table'
}

paginator_kwargs.update({
    'ExpressionAttributeNames' : {'#TimeIntervalCreateDate' : 'TimeIntervalCreateDate'} ,
    'ExpressionAttributeValues' : {
        ':date' :  {'S' : '2020-08-12'}
    },
    'FilterExpression' : '#TimeIntervalCreateDate = :date'
})

# paginator_kwargs.update({
#     'ExpressionAttributeNames' : {'#FileReceivedDate' : 'FileReceivedDate'} ,
#     'ExpressionAttributeValues' : {
#         ':date' :  {'S' : '2020-08-10'}
#     },
#     'FilterExpression' : '#FileReceivedDate = :date'
# })

# paginator_kwargs.update({
#     'FilterExpression' : 'attribute_exists(TimeIntervalCreateDate)'
# })



with open('./data.csv','w+') as f:

    total_count=0
    for page in paginator.paginate(**paginator_kwargs):
        # for item in page.get('Items'):
        #     f.write(f"{item.get('TimeIntervalCreateDate').get('S')},{item.get('TimeIntervalCreateTime').get('S')},{item.get('DriveId').get('S')}\n")
        total_count+=page.get('Count')

print(total_count)