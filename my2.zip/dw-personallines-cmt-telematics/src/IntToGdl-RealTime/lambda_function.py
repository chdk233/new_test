"""
Append driver_identifier to drive details, drive events, drive start, drive end & waypoint csv files
After append is done then copy all 6 real time files to same internal bucket for further processing.
"""
import io
import os
import urllib.parse
import tempfile
import boto3
from botocore.exceptions import ClientError
import datetime
import dateutil.tz
from io import BytesIO

#Set timezone to US/Eastern 
eastern = dateutil.tz.gettz('US/Eastern')

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]
    
    # Get source Amazon S3 information.
    source_s3_event = event.get("Records")[0].get("s3")
    source_s3_bucket_name = source_s3_event.get("bucket").get("name")
    source_s3_object_key = urllib.parse.unquote(source_s3_event.get("object").get("key"))
    source_s3_object_base_name = os.path.basename(source_s3_object_key)
    source_s3_object_prefix = os.path.dirname(source_s3_object_key)
    print('source_s3_object_prefix: ',source_s3_object_prefix)

    # Parse out the drive identifier & date prefix from the source Amazon S3 object base name.
    drive_identifier = source_s3_object_prefix.split("/")[4]
    source_s3_date = source_s3_object_prefix.split('/')[1].split('=')[1]
    source_s3_filename_text = os.path.splitext(source_s3_object_base_name)[0]
    print(f"source_s3_filename_text: '{source_s3_filename_text}'")
    #dataset_identifier = source_s3_filename_text.split("_")[-1]

    #Print source variables
    print(f"drive_identifier: '{drive_identifier}' source_s3_date: '{source_s3_date}'")
    
    # Build target Amazon S3 information.
    #target_s3_bucket_name = f"gdl-{account_number}-us-east-1-dbox"
    target_s3_bucket_name = source_s3_bucket_name
    print(f"target_s3_bucket_name: '{target_s3_bucket_name}'")
    #target_s3_object_prefix = f"datasets/Telematics/CMTPL{dataset_identifier}_rt/"
    #target_s3_object_prefix = f"datasets/Telematics/CMTPL{source_s3_filename_text}_rt/"
    #target_s3_object_prefix = f"CMT/"+source_s3_date+"/CMTPL"+source_s3_filename_text+"_rt/"
    target_s3_object_prefix = f"CMT/CMTPL"+source_s3_filename_text+"_rt/load_date="+source_s3_date+"/"
    target_s3_object_base_name = f"{drive_identifier}_{source_s3_filename_text}_rt_{source_s3_date}.csv"
    target_s3_object_key = os.path.join(target_s3_object_prefix,target_s3_object_base_name)
    
    #Print target variables
    print(f"target_s3_object_prefix: '{target_s3_object_prefix}' target_s3_object_key: '{target_s3_object_key}'")
    
    #Append drive_identification to the end of records for trip_detail, trip_events and trip_waypoints
    response = s3_client.get_object(Bucket=source_s3_bucket_name,Key=source_s3_object_key)
    stream = response.get('Body')
    outboundStream = BytesIO()
    #Reset byte stream to start position
    outboundStream.seek(0)
    counter = 0
    for line in stream.iter_lines():
        if source_s3_filename_text in ('trip_detail', 'trip_events', 'trip_waypoints', 'trip_start', 'trip_end'):
            if counter == 0:
                outboundStream.write(line+str.encode(',drive_id\n'))
            else:
                outboundStream.write(line+str.encode(','+drive_identifier+'\n'))
            counter += 1
        else:
            outboundStream.write(line+str.encode('\n'))
    
    #Reset byte stream to start position
    outboundStream.seek(0)
    
    # Upload the target file to Amazon S3.
    try:
        s3_client.upload_fileobj(outboundStream,target_s3_bucket_name,target_s3_object_key)
    except ClientError as e:
        print('Error: File Upload failed')
        print(e)
    
    