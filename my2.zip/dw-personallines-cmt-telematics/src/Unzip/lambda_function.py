"""
Standardize AWS Lambda function for the DW PersonalLines CMT Telematics application.
Unzip .zip files into NW Internal bucket.
Also to create duplicate copies for heartbeat and trip_labels to send to SRP
"""
import os
import sys
import re
import zipfile
from io import BytesIO
import json
import urllib.parse

import boto3

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sns_client = boto3.client('sns')
    s3_check = boto3.resource("s3")
    
    # List of expected files and placeholder lists for validation checks
    expected_files = {
    "driver_profile.csv" : 30, 
    "driver_summary.csv": 283,
    "fraud.csv" : 83, 
    "heartbeat.csv" : 87, 
    "trip_labels.csv" : 0, 
    "trip_summary.csv" : 365, 
    "badge.csv" : 60
    }
    present = []
    missing = []
    empty = []
    target_keys = []

    sns_message = event.get('Records')[0].get('Sns').get('Message')
    s3_source = json.loads(sns_message).get("Records")[0].get("s3")
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    print(f"s3_source_bucket_name:'{s3_source_bucket_name}'")
    s3_source_object_key = urllib.parse.unquote(s3_source.get("object").get("key"))
    print(f"s3_source_object_key:'{s3_source_object_key}'")
    print(os.path.dirname(s3_source_object_key))
    s3_target_bucket_name = s3_source_bucket_name
    s3_target_prefix = "CMT" 
    
    # # Define the Amazon S3 source and target information.
    # s3_source = event.get("Records")[0].get("s3")
    # s3_source_bucket_name = s3_source.get("bucket").get("name")
    # s3_source_object_key = s3_source.get("object").get("key")
    # s3_target_bucket_name = s3_source_bucket_name
    # s3_target_prefix = "CMT" 
    
    
    # Download the source Amazon S3 object.
    print(f"Streaming the '{s3_source_object_key}' object from the '{s3_source_bucket_name}' bucket")
    
    response = s3_client.get_object(Bucket=s3_source_bucket_name,Key=s3_source_object_key)
    inboundStream = response.get('Body').read()
    zip_file = zipfile.ZipFile(BytesIO(inboundStream))
    

    member_files = [
        ( 
            name, 
            "{}/{}".format(s3_target_prefix, name)
        ) 
        for name in zip_file.namelist()
    ]
    
    print(f"member_files:'{member_files}'")
    for member_source_file_path, s3_target_object_key in member_files:
        print(f"member_source_file_path:'{member_source_file_path}'")
        member_source_file_data = zip_file.read(member_source_file_path)
        
        # Add each file's target key to list for later validation
        target_keys.append(s3_target_object_key)
        
        # Check for all expected files among the present files
        for name_f in expected_files:
            if name_f in member_source_file_path:
                present.append(name_f)
        
        s3_client.upload_fileobj(BytesIO(member_source_file_data),s3_target_bucket_name,s3_target_object_key)
        print(f'File: {s3_target_object_key} uploaded successfully.')
        
        # Create duplicate copy for hearbeat to send to SRP.
        if '_heartbeat.csv' in s3_target_object_key or '_trip_labels.csv' in s3_target_object_key or '_trip_summary.csv' in s3_target_object_key:
            s3_target_object_base_name = "CMT/CopyToSRP/"+os.path.basename(s3_target_object_key)
            print(f"s3_target_object_base_name:'{s3_target_object_base_name}'")
            s3_client.upload_fileobj(BytesIO(member_source_file_data),s3_target_bucket_name,s3_target_object_base_name.replace('.csv','_SRP.csv'))
            
    
    # Delete_hearbeat_SRP files >30 days.    
    # s3_resource = boto3.resource("s3")
    # bucket_name= s3_source_bucket_name
    # latest_files_count=30
    # get_last_modified = lambda obj: int(obj['LastModified'].strftime('%s'))
    # objs = s3_client.list_objects_v2(Bucket=bucket_name,Prefix='CMT/CopyToSRP')['Contents']
    # files_list=[obj['Key'] for obj in sorted(objs, key=get_last_modified,reverse=True)]
    # file_count=len(files_list)
    # if file_count > latest_files_count:
    #     for i in range(latest_files_count,file_count):
    #         s3_resource.Object(bucket_name, files_list[i]).delete()
    #         print("File "+files_list[i]+ "Deleted Successfully")
    
    # Assess all missing files
    for name_f in expected_files:
        if name_f not in present:
            missing.append(name_f)
    
    # Check if any files are empty. If so, add to list
    for key in target_keys:
        daily = s3_check.Object(s3_target_bucket_name, key)

        if daily.content_length <= expected_files[key[66:]]:
            empty.append(key[66:])
    
    # Send out a message if any files are missing
    if len(missing) != 0:
        msg = "The following daily CMT files were missing: " + '\n'.join(missing)
        sns_client.publish(
            TopicArn = os.getenv("SnsNotification"),
            Message = msg,
            Subject = "dw-pl-cmt-TelematicsS3FileUnzip:Daily CMT data files missing")
        print("Data file(s) missing, SNS sent.")
    
    # Send out a message if any files are empty
    if len(empty) != 0:
        msg = "The following daily CMT files were empty: " + '\n'.join(empty)
        sns_client.publish(
            TopicArn = os.getenv("SnsNotification"),
            Message = msg,
            Subject = "dw-pl-cmt-TelematicsS3FileUnzip:Daily CMT data files empty")
        print("Data file(s) empty, SNS sent.")
