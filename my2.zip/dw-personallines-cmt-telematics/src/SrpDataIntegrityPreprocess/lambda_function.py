"""
AWS Lambda function to process success/ignore/error files sent by SRP, containing processed trip id values.  
"""
import boto3
import os
from io import BytesIO
import urllib.parse

#Encode String data to BytesIO stream
def encodeString(stringText):
    return str.encode(stringText+'\n')

#Generate the trip_id, trip_date and trip_hour from the source file and prepare key-value pairs for trip_date and trip_id
def generateTripData(trip_list):
    trip_date = [trip.split('_')[1] for trip in trip_list]
    trip_date_dict = {date: [] for date in trip_date}
    for date in trip_date_dict.keys():
        for trip in trip_list:
            if date in trip:
                row_list = []
                trip_id = trip.split('_')[0]
                trip_hour = trip.split('_')[2]
                trip_date_dict[date].append(trip_id+','+trip_hour)
    return trip_date_dict

#Write the file data to the BytesIO buffer
def writeStreamFileData(outboundStream,data_list):
    addLineBreaks = lambda listdata: '\n'.join(listdata)
    outboundStream.write(encodeString(addLineBreaks(data_list)))
    return outboundStream

#Write the header to the BytesIO buffer
def writeStreamHeaderData(input_list):
    outboundStream = BytesIO()
    outboundStream.seek(0)
    outboundStream.write(encodeString(input_list))
    return outboundStream

#Reset byte stream to start position and write the data to target location
def upload_file_to_S3(s3_client,outboundStream,s3_target_bucket_name,s3_target_object_key):
    outboundStream.seek(0)
    s3_client.upload_fileobj(outboundStream,s3_target_bucket_name,s3_target_object_key)
    print('File: '+s3_target_object_key+' uploaded successfully')

#Generate the target file properties and upload target file to s3
def generateTargetS3Files(s3_client,trip_date_dict,folder_name,s3_filename,s3_target_bucket_name):
    for key,value in trip_date_dict.items():
        print(f'Key: {key} Value: {value}')
        fields = 'trip_id,trip_hour'
        outboundStreamWithHeader = writeStreamHeaderData(fields)
        outboundStream = writeStreamFileData(outboundStreamWithHeader,value)
        s3_target_file_prefix = f'SRP/{folder_name}/load_dt={key}/'
        s3_target_file_name = s3_filename.split('.')[0]+'_processed.csv'
        s3_target_object_key = s3_target_file_prefix+s3_target_file_name
        upload_file_to_S3(s3_client,outboundStream,s3_target_bucket_name,s3_target_object_key)

def lambda_handler(event, context):
    
    print('Received the following event: ',event)
    #Define S3 client and extract source S3 Bucket and object key from incoming event
    s3_client = boto3.client('s3')
    s3_source_event = event.get('Records')[0].get('s3')
    s3_source_bucket_name = s3_source_event.get('bucket').get('name')
    s3_source_file_key = urllib.parse.unquote(s3_source_event.get('object').get('key'))
    s3_target_bucket_name = s3_source_bucket_name
    print(f'Source Bucket: {s3_source_bucket_name} Source Object Key: {s3_source_file_key}')
    #Stream each file and fetch the trip details
    s3_filename = os.path.basename(s3_source_file_key)
    decodeBytes = lambda byteStream: byteStream.decode('utf-8')
    trip_list = []
    response = s3_client.get_object(Bucket=s3_source_bucket_name,Key=s3_source_file_key)
    stream = response.get('Body')
    for row in stream.iter_lines():
        trip_list.append(decodeBytes(row))
    #print('Trip list: ',trip_list)
    cleansed_trip_list = [record for record in trip_list if record and record.strip()]
    if len(cleansed_trip_list)>0:
        trip_date_dict = generateTripData(cleansed_trip_list)
        if 'Success' in s3_filename:
            generateTargetS3Files(s3_client,trip_date_dict,'cmt_sr_srp_di_trip_summary_successtrips',s3_filename,s3_target_bucket_name)
        elif 'Ignore' in s3_filename:
            generateTargetS3Files(s3_client,trip_date_dict,'cmt_sr_srp_di_trip_summary_ignoretrips',s3_filename,s3_target_bucket_name)
        elif 'Error' in s3_filename:
            generateTargetS3Files(s3_client,trip_date_dict,'cmt_sr_srp_di_trip_summary_errortrips',s3_filename,s3_target_bucket_name)
    else:
        print(f'No data available in: {s3_filename}')
