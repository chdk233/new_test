import json
import boto3
import os
from boto3.dynamodb.conditions import Key, Attr,And
import datetime
from dateutil.tz import UTC
import time

def lambda_handler(event, context):
    dynamoDb = boto3.resource('dynamodb',region_name='us-east-1')
    dynamoDbClient = boto3.client('dynamodb',region_name='us-east-1')
    dynamodb_table=event.get('DynamoDbTable')
    table = dynamoDb.Table(dynamodb_table)
    sns = boto3.resource('sns')
    sns_topic = event.get('sns_topic')
    sns_topic_resource = sns.Topic(sns_topic)
    #s3 to dynamodb 
    #s3_bucket_name=event.get('S3_BucketName')
    #s3_prefix=event.get('S3_Prefix')
    #s3_start_hour=event.get('S3_StartHour')
    #s3_end_hour=event.get('S3_EndHour')
    process_flag=event.get('ProcessFlag')
    
    if process_flag=='dynamodb_insert':
        load_dt=event.get('InsertLoadDate')
        from_load_hr=event.get('InsertStartHour')
        to_load_hr=event.get('InsertEndHour')
        ld_hr=event.get('InsertNextLoadHour',from_load_hr)
        REGION       = 'us-east-1'
        BUCKET_NAME  = event.get('InsertBucketName')
        PREFIX = event.get('InsertPrefix')
         
        EVENT_TEMPLATE = {  
   "Records":[  
      {  
         "eventVersion":"2.2",
         "eventSource":"aws:s3",
         "awsRegion":"us-east-1",
         "eventTime": None,
         "eventName":"ObjectCreated:Copy",
         "userIdentity":{  
            "principalId":"Amazon-customer-ID-of-the-user-who-caused-the-event"
         },
         "requestParameters":{  
            "sourceIPAddress":"104.225.170.109"
         },
         "responseElements":{  
            "x-amz-request-id":"Amazon S3 generated request ID",
            "x-amz-id-2":"Amazon S3 host that processed the request"
         },
         "s3":{  
            "s3SchemaVersion":"1.0",
            "configurationId":"f19e4853-9f7f-4e8c-8058-e0d39209efac",
            "bucket":{  
               "name": BUCKET_NAME,
               "ownerIdentity":{  
                  "principalId":"A11HQLDEIK1LLY"
               },
               "arn": f"arn:aws:s3:::{BUCKET_NAME}"
            },
            "object":{  
               "key": None,
               "size": None,
               "eTag":"object eTag",
               "versionId":"object version if bucket is versioning-enabled, otherwise null",
               "sequencer": "a string representation of a hexadecimal value used to determine event sequence, only used with PUTs and DELETEs"
            }
         }
      }
   ]
}
        print (f"running for load hour {ld_hr}")
        s = boto3.session.Session(region_name=REGION)
        dynamodb = s.client('dynamodb')
        s3 = s.client('s3')
        paginator = s3.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=BUCKET_NAME, Prefix=f'{PREFIX}load_date={load_dt}/{ld_hr}')
        items=[]
        items1=[]
        counter=0
        for page in pages:
          for obj in page['Contents']:
            counter+=1
            s3Key = str(obj['Key'])
            drive_Id = str(obj['Key'].split('/')[3].split('.')[0])
            timeStamp = obj['LastModified']
            timeStampISO = timeStamp.isoformat().split('+')[0]
            flag_indicator = 'N'
            load_date = str(obj['Key'].split('/')[1].split('=')[1])
            load_hour = str(obj['Key'].split('/')[2])
            s3ObjectSize = str(obj['Size'])
            EVENT_TEMPLATE['Records'][0]['eventTime'] = timeStampISO
            EVENT_TEMPLATE['Records'][0]['s3']['object']['key'] = s3Key
            EVENT_TEMPLATE['Records'][0]['s3']['object']['size'] = int(s3ObjectSize)
            items.append(
            {'PutRequest': {
              'Item' : 
                {
                  'Id' : {
                    'S' : drive_Id
                  },
                  'ProcessedFlag' : {
                    'S' : flag_indicator
                  },
                  'LoadDate' : {
                    'S' : load_date
                  }, 
                  'LoadHour' : {
                    'N' : load_hour
                  },
                  'Event' : {
                    'S' : json.dumps(EVENT_TEMPLATE)
                  }
                }
              }
            }
          )
            if len(items) % 2000 == 0:
                time.sleep(2)
                print(" sleeping 2 second")
            if len(items) % 25 == 0:
              print("Inserting batch of 25")
              response = dynamodb.batch_write_item(
                RequestItems={dynamodb_table : items}
              )
              items.clear()
              #print(f'response: {response}')
              if response.get('UnprocessedItems'):
                print("Adding unprocessed items to items to process and sleeping 1 second")
                time.sleep(1)
                items += response.get('UnprocessedItems').get(dynamodb_table)
        if len(items) >0:
            response = dynamodb.batch_write_item(
                RequestItems={dynamodb_table : items}
              )
            print(response)
        print(f"inserted {counter} records for load hour {ld_hr}")
        event.update({"InsertNextLoadHour":str(int(ld_hr[0:2])+1).rjust(2,'0')+'00'})
        event.update({"BatchIntervalSeconds":20})
        if ld_hr == to_load_hr:
            event.update({"EndExecution":"True"})
    #dynamodb to sqs
    if process_flag=='dynamodb_sqs':
        print(process_flag)
        batch_size=int(event.get('BatchSize')) 
        load_date=event.get('LoadDate')
        start_hour=int(event.get('StartHour'))
        end_hour=int(event.get('EndHour'))
        no_of_batches=int(event.get('NoOfBatches'))
        current_batch_run=int(event.get('CurrentBatchRun',0))
        filter_expression_list = []
        processed_flag='N'
        filter_expression_list.append(Key("LoadDate").eq(load_date))
        filter_expression_list.append(Attr("ProcessedFlag").eq(processed_flag))
        #filter_expression_list.append(Attr("LoadHour").between(start_hour,end_hour))
        scanKwargs = {
            'TableName' : dynamodb_table,
            'FilterExpression':And(And(*filter_expression_list),Attr("LoadHour").between(start_hour,end_hour)),
            'ProjectionExpression':"Id,LoadDate,Event"
        }
        items = []
        items1=[]
        
        while len(items) <= batch_size-1:
            if event.get('LastEvaluatedKey'):
                scanKwargs.update({
                    'ExclusiveStartKey' : event.get('LastEvaluatedKey')
                })
            response = table.scan(**scanKwargs)
            print(response)
            if response.get('LastEvaluatedKey'):
                event.update({'LastEvaluatedKey' : response.get('LastEvaluatedKey')})
            else:
                event.update({"EndExecution":"True"}) 
                print('Scanned entire table')
                break
            items1=items+response.get('Items')
            items=items1[:batch_size]
            execution_time1=900000-context.get_remaining_time_in_millis()
            print(execution_time1)
            if (len(items) ==0 and execution_time1 >45000) or execution_time1 >45000:
                #event.update({"EndExecution":"True"})
                print("partital items in dynamodb table")
                break
            
        for item in items:
            sns_message={'Path':item.get('Id')}
            S3event = item.get('Event')
            S3event_dict = json.loads(S3event)
            S3event_dict['Records'][0]['eventTime']=datetime.datetime.now(tz=UTC).isoformat()
            s3_event_encoded = json.dumps(S3event_dict)
            sns_topic_resource.publish(Message=json.dumps({"default":s3_event_encoded}),
                                        MessageStructure="json",
                                        Subject="Amazon S3 Notification")
            dynamoDbClient.update_item(
    					TableName = dynamodb_table,
                        Key={
                            'Id': {'S':item.get('Id')},
    						'LoadDate':{'S':item.get('LoadDate')}
                        },
                        UpdateExpression='SET ProcessedFlag = :val1',
                        ExpressionAttributeValues={
                            ':val1': {'S':'Y'}
                        }
                    )
        current_batch_run+=1
        print(f"Completed {current_batch_run} Batch run")
        event.update({"CurrentBatchRun":current_batch_run})
        if current_batch_run == no_of_batches:
            event.update({"EndExecution":"True"})
        execution_time=900000-context.get_remaining_time_in_millis()
        print(f"execution time {execution_time} in milli seconds")
        
        if execution_time >60000 or execution_time <0:
            print("Lambda executed for more than 1 minute")
            BatchIntervalSeconds=60
        else:
            BatchIntervalSeconds=60-round(execution_time/1000)-1
        event.update({"BatchIntervalSeconds":BatchIntervalSeconds})
    if process_flag=='dynamodb_update':
        update_load_date=event.get('UpdateLoadDate')
        update_start_hour=int(event.get('UpdateStartHour'))
        update_end_hour=int(event.get('UpdateEndHour'))
        filter_expression_list = []
        processed_flag='Y'
        filter_expression_list.append(Key("LoadDate").eq(update_load_date))
        #filter_expression_list.append(Attr("ProcessedFlag").eq(processed_flag))
        filter_expression_list.append(Attr("LoadHour").between(update_start_hour,update_end_hour))
        scanKwargs = {
            'TableName' : dynamodb_table,
            'FilterExpression':And(*filter_expression_list),
            'ProjectionExpression':"Id,LoadDate,LoadHour,ProcessedFlag"
        }
        if event.get('LastEvaluatedKey'):
            scanKwargs.update({
                    'ExclusiveStartKey' : event.get('LastEvaluatedKey')
                    })
        response = table.scan(**scanKwargs)
        if response.get('LastEvaluatedKey'):
            event.update({'LastEvaluatedKey' : response.get('LastEvaluatedKey')})
        else:
            event.update({"EndExecution":"True"})
        print(response)
        items=response.get('Items')
        update_counter=0
        while len(items) >=0:
            for item in items:
                if item.get('ProcessedFlag').strip('').upper() =='Y':
                    update_counter+=1
                    dynamoDbClient.update_item(
    					TableName = dynamodb_table,
                        Key={
                            'Id': {'S':item.get('Id')},
    						'LoadDate':{'S':item.get('LoadDate')}
                        },
                        UpdateExpression='SET ProcessedFlag = :val1',
                        ExpressionAttributeValues={
                            ':val1': {'S':'N'}
                        }
                    )
                if update_counter%500==0 and update_counter !=0:
                    time.sleep(1)
            items.clear()
            if event.get('LastEvaluatedKey'):
                scanKwargs.update({
                    'ExclusiveStartKey' : event.get('LastEvaluatedKey')
                    })
            else:
                event.update({"EndExecution":"True"})    
                break
            response = table.scan(**scanKwargs)
            if response.get('LastEvaluatedKey'):
                event.update({'LastEvaluatedKey' : response.get('LastEvaluatedKey')})
            else:
                event.update({"EndExecution":"True"})
                del(event['LastEvaluatedKey'])
            items+=response.get('Items')
            print(f"Total update count: {update_counter}")
            #if len(items) ==0:
            #    event.update({"EndExecution":"True"})
            if context.get_remaining_time_in_millis() <=300000:
                print("exiting the lambda due to time constraint")
                break
            print(event)
    return event

