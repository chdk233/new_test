from distutils.log import error
from email import message
import boto3
from botocore.errorfactory import ClientError
import uuid
import json
from boto3.dynamodb.conditions import Key, Attr,And


def lambda_handler(event,context):    
    sqs=boto3.resource('sqs')
    dynamodb=boto3.resource('dynamodb')
    queue_name= event['queue_name']

    table_name = event['table_name']
    #load_date
    load_date= event['load_date']
    load_hour= event['load_hour']
    dynamodb_table = dynamodb.Table(table_name)


    dynamodb_client=boto3.client('dynamodb')
    dynamodb_table = dynamodb.Table(table_name)




    processed_flag='N'
    update_flag='Y'

    items =[]

    if len(items)<=25:
        scanKwargs ={
            'FilterExpression':Key("LoadDate").eq(load_date)&Attr("LoadHour").eq(int(load_hour))&Attr("ProcessedFlag").eq(processed_flag),
            'ProjectionExpression':"Id,LoadDate,Event"
        }
        output = dynamodb_table.scan(**scanKwargs)
        for item in output['Items']:
            res = json.loads(item['Event'])
            EVENT_TEMPLATE = res['MessageBody']
            #print(EVENT_TEMPLATE)
            id = str(item['Id'])
            message = {
                'Id':id,
                'MessageBody':json.dumps(EVENT_TEMPLATE)
            }
            items.append(message)
            # print(items)
            UpdateExpression = 'SET ProcessedFlag = :val'
            ExpressionAttributeValues = {':val': update_flag }


            update = dynamodb_client.update_item(
    					TableName = table_name,
                        Key={
                            'Id': {'S':item['Id']},
    						'LoadDate':{'S':item['LoadDate']}
                        },
                        UpdateExpression='SET ProcessedFlag = :val1',
                        ExpressionAttributeValues={
                            ':val1': {'S':'Y'}
                        }
                    )
            

        queue = sqs.get_queue_by_name(QueueName=queue_name)
        if len(items)==0:
            event.update({"EndMessageExecution":"True"})
        else:
            event.update({"BatchIntervalSeconds":20})
            execution_time=900000-context.get_remaining_time_in_millis()
            response = queue.send_messages(Entries =items)
            items.clear()
        if len(items)==0:
            event.update({"EndMessageExecution":"True"})
                # print(response)
        
    return event

    





