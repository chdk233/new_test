import boto3
import json
import boto3
import datetime
import os
import logging
import json
import sys


AWS_PROFILE  = 'pcdwDevelopers-TeamRole-AWS-785562577411'
REGION       = 'us-east-1'
TABLE_NAME   = 'cmt-trips-control-table'

s = boto3.Session(profile_name=AWS_PROFILE,region_name=REGION)

sns = s.resource('sns')

topic = sns.Topic("arn:aws:sns:us-east-1:785562577411:TimeIntervalReplay")

dynamoDb = s.client('dynamodb')

input_file_path = sys.argv[1]

answer=None
while not answer or not answer.lower() in ['y','n']:
    answer = input(f"Is the following source path correct? (y/n) \"{input_file_path}\"")

if answer == 'n':
    exit(0)

with open(input_file_path) as f:
    lines = f.readlines()

try:


    for line in lines:

        (path,timestamp) = line.split(',')

        (root,driveId)      = path.split("/")[1:3]

        accountId            = root.strip('DS_CMT_NW-')

        DATETIME = datetime.datetime.strptime(timestamp.rstrip(),'%Y-%m-%dT%H:%M:%S.%f%z')
        CURRENT_DATE         = DATETIME.strftime('%Y-%m-%d')
        CURRENT_TIME         = DATETIME.strftime('%H:%M:%S.%f')

        mymsg = {"TripSummaryPath": 
            f"s3://dw-internal-pl-cmt-telematics-785562577411/{path.rstrip('/trip_summaryrt.csv')}/trip_summaryrt.csv",
                "TripDetailPath":
        f"s3://dw-internal-pl-cmt-telematics-785562577411/{path.rstrip('/trip_summaryrt.csv')}/trip_detail.csv"  }

        topic.publish(Message=json.dumps({'default':json.dumps(mymsg)}),Subject='Replay',MessageStructure='json')


        item = {
                'AccountId' : {
                    'S' : accountId
                },
                'DriveId' : {
                    'S' : driveId
                },
                'FileReceivedDate' : {
                    'S' : CURRENT_DATE
                },
                'FileReceivedTime' : {
                    'S' : CURRENT_TIME
                }
            }

        response = dynamoDb.put_item(
            TableName=TABLE_NAME,
            Item=item
        )

except Exception as e:
    print(f"Died at line {line}\n due to error {str(e)} ")