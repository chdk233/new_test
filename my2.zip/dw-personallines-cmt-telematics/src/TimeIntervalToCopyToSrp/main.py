"""
Acquire AWS Lambda function for the DW Personal Lines Telematics application.
"""
import boto3
import os
import urllib

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    print(f"Event received {event}")
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")

    # Get the current AWS account number.
    account_number = context.invoked_function_arn.split(':')[4] 

    # Get Amazon S3 source information.
    s3_source = event.get("Records")[0].get("s3")
    s3_event_hour = event.get("Records")[0].get("eventTime")[11:13]+'00'
    s3_event_date =  event.get("Records")[0].get("eventTime")[:10]
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    s3_source_object_key = urllib.parse.unquote(s3_source.get("object").get("key") )
    print('s3_source_object_key: ', s3_source_object_key)

    # Get Amazon S3 target information.
    s3_target_bucket_name = f"dw-internal-pl-cmt-telematics-{account_number}"
    s3_target_object_key = f"CMT/CopyToSRP/load_date={s3_event_date}/{s3_event_hour}/{os.path.basename(s3_source_object_key)}"
    
    print(f"Copying s3://{s3_source_bucket_name}/{s3_source_object_key} " +
        f"to s3://{s3_target_bucket_name}/{s3_target_object_key}")

    # Copy the source Amazon S3 object to the target Amazon S3 location.
    s3_client.copy_object(
        CopySource={
            "Bucket": s3_source_bucket_name,
            "Key": s3_source_object_key
        },
        Bucket=s3_target_bucket_name,
        Key=s3_target_object_key
    )
