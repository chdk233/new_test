import boto3
from botocore.exceptions import ClientError
import os
import datetime
import logging
import json

FORMAT = '%(asctime)s [%(module)s.%(funcName)s:%(lineno)d] %(levelname)s: %(message)s'
logging.basicConfig(format=FORMAT, datefmt="%Y-%m-%d %H:%M:%S")
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv("LOGLEVEL", "INFO"))

def add_aws_glue_table_partition(database_name,
                                 table_name,
                                 partition_spec,
                                 aws_profile):
    """
    Add a partition to an aws glue table.
    
    Parameters
    ----------
    glue_database:
        database partition will be added to
    glue_table:
        table partition will be added to
    partition_spec:
        partition specification which will be added. Examples:
            load_dt=20181217
            source_cd=LEX/load_dt=20181217
    aws_profile:
        Can provide this for local testing. Should match a 
        profile existing in local aws credentials file
    """
   
    # Setup glue client

    if aws_profile:
        s = boto3.Session(profile_name=aws_profile,
                          region_name="us-east-1")
        glue_client = s.client("glue")
    else:
        glue_client = boto3.client("glue")

    # Retrieve target tables storage descriptor. This will be modified and 
    # used for create partition request.

    response = glue_client.get_table(DatabaseName=database_name,
                                      Name=table_name)

    table_def = response.get("Table")

    table_storage_descriptor = table_def.get("StorageDescriptor")

    # Get location and append partition specification

    s3_path = table_storage_descriptor.get("Location")

    s3_path = "{}/{}".format(s3_path,partition_spec)

    table_storage_descriptor.update(
        {"Location": s3_path}
    )

    # Define partition input and define key word arguments used for create
    # partition request.

    partition_input = {
        "Values": [spec.split("=")[1] for spec in partition_spec.split("/")],
        "StorageDescriptor": table_storage_descriptor
    }

    create_partition_kwargs = {
        "DatabaseName":database_name,
        "TableName":table_name,
        "PartitionInput": partition_input
    }

    try:
        LOGGER.info("Creating partition using kwargs:\n{}"
            .format(create_partition_kwargs))
        response = glue_client.create_partition(**create_partition_kwargs)
        LOGGER.info("Partition created")
    except ClientError as e:
        exception_code = e.response.get("Error").get("Code")
        if exception_code == "AlreadyExistsException":
            LOGGER.info("Partition already exists so no need to create one")
        else:
            raise e

def handler(event, context):

    LOGGER.info(f"Event provided to lambda \"{event}\".")

    AWS_PROFILE = event.get("AwsProfile")
    EXECUTION_DURATION_DICT = event.get("ExecutionDuration")
    BATCH_SIZE = event.get('BatchSize')
    MAIN_QUEUE = event.get('SqsMainQueueName')
    REPLAY_QUEUE = event.get('SqsReplayQueueName')
    ERROR_SNS = event.get('SnsErrorArn')
    START_TIME_STR = event.get("StartTime")
    msg = None
    EXECUTION_DURATION = None

    LOGGER.info(f"Main queue: {MAIN_QUEUE}")
    LOGGER.info(f"Replay queue: {REPLAY_QUEUE}")
    LOGGER.info(f"SNS topic for errors: {ERROR_SNS}")

    # Validate execution duration passed in event

    try:
        LOGGER.info(
            f"Validating execution duration specification {EXECUTION_DURATION_DICT}")
        EXECUTION_DURATION = datetime.timedelta(**EXECUTION_DURATION_DICT)
    except TypeError as e:
        LOGGER.error(f"Incorrect exexcution_duration defined '{EXECUTION_DURATION_DICT}'." +
                     " Refer to datetime.timedetla documenation for proper kwargs")
        exit(1)

    # Set start time if it hasn't been set already

    if START_TIME_STR:

        LOGGER.info(f"Converting START_TIME_STR to datetime object and checking" +
                    " if start time exceeds execution duration")
        START_TIME_DT = datetime.datetime.strptime(
            START_TIME_STR, '%Y-%m-%d %H:%M:%S')

        if datetime.datetime.now() - START_TIME_DT >= EXECUTION_DURATION:
            LOGGER.info(f"Setting end_execution to True as a ")
            event.update({"EndExecution": "True"})
            return event
    else:

        START_TIME_STR = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        LOGGER.info(f"Setting execution start time as {START_TIME_STR}")
        event.update({"StartTime": START_TIME_STR})
        event.update({"EndExecution": "False"})

        add_aws_glue_table_partition(database_name=os.getenv("DATABASE"),
                                     table_name=os.getenv("TABLE"),
                                     partition_spec=f"load_date={START_TIME_STR[0:10]}",
                                     aws_profile=AWS_PROFILE)

    # AWS client setup

    if AWS_PROFILE:

        LOGGER.info(
            f"Using aws profile {AWS_PROFILE} as that was passed in the event")
        s = boto3.Session(profile_name=AWS_PROFILE, region_name="us-east-1")
        sqs = s.resource('sqs')
        sns = s.resource('sns')
    else:

        sqs = boto3.resource('sqs')
        sns = boto3.resource('sns')

    # Setup messaging

    replay_queue = sqs.get_queue_by_name(QueueName=REPLAY_QUEUE)
    main_queue = sqs.get_queue_by_name(QueueName=MAIN_QUEUE)
    error_topic = sns.Topic(ERROR_SNS)

    # Read messages from SQS

    messages = []

    while len(messages) < int(BATCH_SIZE) and \
            context.get_remaining_time_in_millis() >= 10000:

        LOGGER.info("Checking replay queue for messages")
        msg = replay_queue.receive_messages(AttributeNames=['SentTimestamp'],
                                            MaxNumberOfMessages=1,
                                            WaitTimeSeconds=1)

        if not msg:

            LOGGER.info("Replay queue is empty")
            LOGGER.info("Checking main queue")
            msg = main_queue.receive_messages(AttributeNames=['SentTimestamp'],
                                              MaxNumberOfMessages=1,
                                              WaitTimeSeconds=1)
        if msg:

            LOGGER.info(f"Reading message '{msg[0].body}'")

            bodyDict = json.loads(msg[0].body)
            
            try:
                messages.append({
                    "TopicArn" : bodyDict.get('TopicArn'),
                    "Message" : bodyDict.get('Message')

                })
            except json.decoder.JSONDecodeError as e:
                LOGGER.error(f"Message improperly formatted")
                LOGGER.warning(
                    "Deleting improperly formatted message and pushing to error queue")
                error_topic.publish(Message=json.dumps({'default': msg[0].body}),
                                    Subject='Improper Message Format',
                                    MessageStructure='json')
            finally:
                msg[0].delete()
        else:
            LOGGER.info("Main queue is empty")

    # Assess results of while loop

    if len(messages) >= int(BATCH_SIZE):
        LOGGER.info(f"{len(messages)} returning messages to step function")
        event.update({"messages": messages,
                      "SkipMapStep": "False"})
    elif len(messages) == 0:
        LOGGER.info("No messages retrieved, setting SkipMapStep flag to True")
        event.update({"SkipMapStep": "True"})
    else:
        LOGGER.info(
            f"Nearing lambda time out so returning {len(messages)} messages")
        event.update({"messages": messages,
                      "SkipMapStep": "False"})

    LOGGER.info(f"Returning following event: {event}")

    return event


if __name__ == "__main__":

    class mycontext:
        def __init__(self):
            self.time = 1001

        def get_remaining_time_in_millis(self):
            self.time -= 1
            return self.time

    os.environ['DATABASE']='telematics_staging_db'
    os.environ['TABLE']='cmt_sr_mobile_time_interval_rt'

    event = {
        "AwsProfile": "DevDW01-CUSTOMADMIN-AWS",
        "SqsMainQueueName":   "TimeIntervalMain",
        "SqsReplayQueueName": "TimeIntervalReplay",
        "BatchSize": 2,
        "ExecutionDuration": {"days": 1},
        "SnsReplayArn": "arn:aws:sns:us-east-1:786994105833:TimeIntervalReplay",
        "SnsErrorArn": "arn:aws:sns:us-east-1:786994105833:TimeIntervalError"
    }

    handler(event, mycontext())

