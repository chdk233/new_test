"""
This program will read a trip summary and trip detail file for a given trip and
 define kilometers drive for each given time period. The json file 
 time_bucket_config.json defines bucket boundaries
"""
# standard
import logging
import os
import json
import re
import pytz
import datetime
import calendar
import boto3

import pandas
# Need s3fs installed as well

FORMAT = '%(asctime)s [%(module)s.%(funcName)s:%(lineno)d] %(levelname)s: %(message)s'
logging.basicConfig(format=FORMAT, datefmt="%Y-%m-%d %H:%M:%S")
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv("LOGLEVEL", "INFO"))


def log_indent(func):
	def inner_func(*args, **kwargs):
		current_handler = LOGGER.handlers[0]
		current_format = current_handler.formatter._fmt
		formatter = logging.Formatter(fmt=f"\t{current_format}")
		current_handler.setFormatter(formatter)
		result = func(*args, **kwargs)
		formatter = logging.Formatter(fmt=current_format)
		current_handler.setFormatter(formatter)
		return result
	return inner_func


def handler(event, context):

	LOGGER.info(f"Executing lambda with following event info:\n{event}")

	MESSAGE		   = json.loads(event.get("Message"))
	TRIP_SUMMARY_PATH = MESSAGE.get("TripSummaryPath")
	TRIP_DETAIL_PATH  = MESSAGE.get("TripDetailPath")
	START_TIME		= event.get("StartTime")
	TARGET_PATH	   = event.get("TargetPath")

	@log_indent
	def retrieve_time_bucket_config():
		"""Used to parse time_bucket_conf.json and returns dict"""
		CONFIG_DIR = os.path.dirname(__file__)
		CONFIG_FILE = "time_bucket_config.json"
		CONFIG_PATH = f"{CONFIG_DIR}/{CONFIG_FILE}"
		LOGGER.debug(f"Opening config json file from {CONFIG_PATH}")
		with open(CONFIG_PATH) as f:
			time_buckets_conf = json.load(f)
		LOGGER.debug(
			f"Time bucket configuration retrieved {time_buckets_conf}")
		return time_buckets_conf

	@log_indent
	def encode_interval_conf(interval: dict):
		"""Takes the interval dict and converts day names to integer representing
		day of the week and converts values to array of datetime.time objects
		representing lower and upper time boundaries """
		DAYS = list(calendar.day_name)
		encoded_interval = {}
		LOGGER.debug("Parsing interval dictionary")
		for k, v in interval.items():
			encoded_interval[DAYS.index(k)] = [parse_time_string(v.get('lower'),
																 000000),
											   parse_time_string(v.get('upper'),
																 999999)]
		return encoded_interval

	@log_indent
	def parse_time_string(time: str, microsecond: int):
		"""Converts time as string hh:mm:ss to datetime.time object"""
		time_parts = time.split(":")
		time_dict = \
			{"hour": int(time_parts[0]),
			 "minute": int(time_parts[1]),
			 "second": int(time_parts[2]),
			 "microsecond": microsecond}
		time_obj = datetime.time(**time_dict)
		LOGGER.debug(
			f"Time string provided: {time}.{microsecond} Returning Time Object: {time_obj}")
		return time_obj

	LOGGER.debug(
		"Reading trip summary file to retrieve utc offset and drive id")

	try:

		trip_summary = pandas.read_csv(TRIP_SUMMARY_PATH,
									   header='infer')

		trip_summary = trip_summary[['Driveid', 'Utc_offset']]

		drive_id = trip_summary['Driveid'][0]

		utc_offset_raw = trip_summary['Utc_offset'][0]
		match_pattern = r'^(-?\d\d):.*'
		m = re.search(match_pattern, utc_offset_raw)

		try:
			utc_offset = m.group(1)
		except Exception as e:
			LOGGER.error(f"Cannot find match to extract utc offset from {utc_offset_raw}" +
						 f" using match pattern {match_pattern}",
						 exc_info=1)
			raise e

		LOGGER.debug(f"UTC Offset: {utc_offset}\nDrive ID: {drive_id}")

		LOGGER.debug("Reading trip detail file to generate time interval file")

		trip_detail = pandas.read_csv(TRIP_DETAIL_PATH, header='infer')

		trip_detail['drive_id'] = drive_id

		trip_detail = trip_detail[['drive_id', 'time', 'mm_dist_km']]

		LOGGER.debug("Convert epoch ms to utc timestamp")

		trip_detail['time'] = pandas.to_datetime(
			trip_detail['time'], unit='ms', utc=True)

		LOGGER.debug("Convert utc time to local time zone")

		trip_detail['time'] = trip_detail['time'] + \
			pandas.to_timedelta(int(utc_offset), unit='h')

		LOGGER.debug(
			"Calculate distance by comparing current mm_dist_km with previous row")

		trip_detail['mm_dist_km_prev'] = trip_detail['mm_dist_km'].shift(
			1, fill_value=0)

		trip_detail['distance'] = trip_detail['mm_dist_km'] - \
			trip_detail['mm_dist_km_prev']

		trip_detail = trip_detail[['drive_id', 'time', 'distance']]

		TIME_BUCKETS_CONF = retrieve_time_bucket_config()

		LOGGER.debug(
			"Encode time bucket config for building condition expressions")

		for time_interval in TIME_BUCKETS_CONF:
			TIME_BUCKETS_CONF[time_interval] = encode_interval_conf(
				TIME_BUCKETS_CONF[time_interval])

		LOGGER.debug(f"Encoded configuration:\n{TIME_BUCKETS_CONF}")

		LOGGER.debug("Defining time intervals")

		def bucket_distance(trip_detail):
			BUCKETING_RESULTS = {k: 0.000 for k in TIME_BUCKETS_CONF}
			t = trip_detail.time
			for interval_name, encoded_interval in TIME_BUCKETS_CONF.items():
				if encoded_interval.get(t.weekday()) and \
					(encoded_interval.get(t.weekday())[0]
					 <= t.time() <= encoded_interval.get(t.weekday())[1]):
					BUCKETING_RESULTS[interval_name] = trip_detail.distance
					return pandas.Series(BUCKETING_RESULTS)

		trip_detail[[interval_name for interval_name in TIME_BUCKETS_CONF]] =\
			trip_detail.apply(bucket_distance, axis=1)

		LOGGER.debug("Sum interval columns and distance expressions")

		agg_expression = {k: 'sum' for k in TIME_BUCKETS_CONF}

		agg_expression['distance'] = 'sum'

		trip_detail = trip_detail.groupby('drive_id').agg(agg_expression)
		
		SRP_target_prefix = TARGET_PATH.rsplit('/',1)[0]
		SRP_load_date = TRIP_SUMMARY_PATH.split('/')[4]
		SRP_date = SRP_load_date.split('=')[1]
		SRP_load_hour = TRIP_SUMMARY_PATH.split('/')[5]		

		LOGGER.debug(
			f"Writing time interval file to {TARGET_PATH}/load_date={SRP_date}/DS_CMT_{drive_id}_trip_intervals.csv")

		trip_detail.to_csv(f"{TARGET_PATH}/load_date={SRP_date}/DS_CMT_{drive_id}_trip_intervals_SRP.csv",
						   line_terminator='\n')

		LOGGER.info(
			f"file {TARGET_PATH}/load_date={SRP_date}/DS_CMT_{drive_id}_trip_intervals.csv written successfully")

		#Send another copy of the target file to CopyToSRP folder
		
		LOGGER.debug(
			f"Writing time interval file to {SRP_target_prefix}/CopyToSRP/{SRP_load_date}/{SRP_load_hour}/DS_CMT_{drive_id}_{SRP_date}_{SRP_load_hour}_trip_intervals_SRP.csv")
			
		trip_detail.to_csv(f"{SRP_target_prefix}/CopyToSRP/{SRP_load_date}/{SRP_load_hour}/DS_CMT_{drive_id}_{SRP_date}_{SRP_load_hour}_trip_intervals_SRP.csv",
						   line_terminator='\n')
		
		LOGGER.info(
			f"file {SRP_target_prefix}/CopyToSRP/{SRP_load_date}/{SRP_load_hour}/DS_CMT_{drive_id}_{SRP_date}_{SRP_load_hour}_trip_intervals_SRP.csv written successfully")				
		
		
		AWS_PROFILE  = event.get("AwsProfile")
		REGION	   = context.invoked_function_arn.split(':')[4]
		TABLE_NAME   = os.getenv('TABLE_NAME')
		NOW				  = datetime.datetime.now()
		CURRENT_DATE		 = NOW.strftime('%Y-%m-%d')
		CURRENT_TIME		 = NOW.strftime('%H:%M:%S.%f')

		(accountId,driveId) = TRIP_SUMMARY_PATH.split("/")[-3:-1]
		accountId		   = accountId.strip('DS_CMT_NW-')

		if AWS_PROFILE:
			dynamoDb = boto3.Session(profile_name=AWS_PROFILE,
									region_name=REGION).client('dynamodb')
		else:
			dynamoDb = boto3.client('dynamodb')

		LOGGER.info(f"Updating drive id {driveId} for account id {accountId} "+
						f"into dynamo db table {TABLE_NAME}")

		response = dynamoDb.update_item(
			TableName=TABLE_NAME,
			Key={
				'AccountId' : {
					'S' : accountId
				},
				'DriveId' : {
					'S' : driveId
				}
			},
			ExpressionAttributeNames={
				'#TISD' : 'TimeIntervalCreateDate',
				'#TIST' : 'TimeIntervalCreateTime'
			},
			ExpressionAttributeValues={
				':d' : {
					'S' : CURRENT_DATE
				},
				':s' : {
					'S' : CURRENT_TIME
				}
			},
			UpdateExpression='SET #TISD = :d , #TIST = :s'
		)

		LOGGER.info(f"Dynamo DB put item response: {response}")

	except Exception as e:

		LOGGER.error("Time Interval for provided event has failed", exc_info=1)

		AWS_PROFILE = event.get("AwsProfile")

		if AWS_PROFILE:
			LOGGER.info(
				f"Using aws profile {AWS_PROFILE} as that was passed in the event")
			s = boto3.Session(profile_name=AWS_PROFILE,
							  region_name="us-east-1")
			sns = s.resource('sns')
		else:
			sns = boto3.resource('sns')

		TOPIC_ARN = event.get('TopicArn')
		if 'Main' in TOPIC_ARN:
			LOGGER.warning(
				"Replaying event by publishing message to replay queue")
			topic = sns.Topic(event.get("SnsReplayArn"))
		else:
			LOGGER.warning("Publishing event to error queue")
			topic = sns.Topic(event.get("SnsErrorArn"))

		MESSAGE.update({ "Error" : str(e) ,
						 "LogStreamName" : context.log_stream_name,
						 "LogGroupName" : context.log_group_name })

		topic.publish(Message=json.dumps(
			{'default':  json.dumps(MESSAGE)}
		),
			Subject='Time Interval Lambda Failed',
			MessageStructure='json')

		exit(1)


if __name__ == "__main__":

	event = {
	"AwsProfile": "DevDW01-CUSTOMADMIN-AWS",
  "TopicArn": "arn:aws:sns:us-east-1:786994105833:TimeIntervalReplay",
  "Message": "{\"TripSummaryPath\": \"s3://dw-internal-pl-cmt-telematics-786994105833/CMT/load_date=2020-11-11/1400/DS_CMT_72cc1e43-1088-406f-92ee-abed2cc16ab5/13042EDC-C3FB-496D-931D-297BC2B7082B/trip_summaryrt.csv\", \"TripDetailPath\": \"s3://dw-internal-pl-cmt-telematics-786994105833/CMT/load_date=2020-11-11/1400/DS_CMT_72cc1e43-1088-406f-92ee-abed2cc16ab5/13042EDC-C3FB-496D-931D-297BC2B7082B/trip_detail.csv\"}",
  "TargetPath": "s3://dw-internal-pl-cmt-telematics-786994105833/CMT/CMTPLtrip_interval_rt",
  "SnsErrorArn": "arn:aws:sns:us-east-1:786994105833:TimeIntervalError",
  "SnsReplayArn": "arn:aws:sns:us-east-1:786994105833:TimeIntervalReplay",
  "StartTime" : datetime.datetime.now().strftime('%Y-%m-%d')
}


	class context:
		def __init__(self):
			self.log_stream_name='foobar'
			self.log_group_name='foobar'
			self.invoked_function_arn = 'arn:aws:lambda:123456789:us-east-1:function:foobar'

	os.environ['TABLE_NAME']='cmt-trips-control-table'

	handler(event, context())