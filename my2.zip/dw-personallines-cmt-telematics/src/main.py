"""Basic lambda function that returns Hello World to any request."""
import logging
import requests

logger = logging.getLogger("sample-app")
logger.setLevel(logging.DEBUG)


def lambda_handler(event, context):
    """Main function, triggered when new message added to topic"""

    # Debug prints for reference
    logger.info("Lambda execution starting up...")
    logger.debug(f"event: {event}")
    logger.debug(f"context: {context}")

    logger.info("Hello World Demo.")

    return "Hello World!"
