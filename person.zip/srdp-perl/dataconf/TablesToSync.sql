--dc_audit_bal_tripcumu_tripsumm
INSERT INTO TABLE smartride_work_hive_db.dc_audit_bal_tripcumu_tripsumm
PARTITION (source_cd, batch)
SELECT
c.dc_instance_id
,a.loadevent_id
,a.tripsummary_trip_ct
,a.cumulative_trip_ct
,a.source_cd
,a.batch
FROM smartride_canonical_hive_db.audit_bal_tripcumu_tripsumm a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch = b.batch
AND a.source_cd = b.source_cd

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr

WHERE from_unixtime(unix_timestamp(substr(a.batch,0,8) ,'yyyyMMdd'), 'yyyy-MM-dd') >= c.active_start_dt
AND from_unixtime(unix_timestamp(substr(a.batch,0,8) ,'yyyyMMdd'), 'yyyy-MM-dd') < c.active_end_dt;

--dc_centroid_summary
INSERT OVERWRITE TABLE smartride_work_hive_db.dc_centroid_summary
PARTITION (source_cd, batch)
SELECT
c.dc_instance_id
,a.trip_nb
,a.centroid_rpm_start
,a.centroid_start_time
,a.centroid_end_time
,a.min_scrubbed_speed
,a.max_scrubbed_speed
,a.min_delta_scrubbed_speed
,a.max_delta_scrubbed_speed
,a.scrubbed_speed_decreasing_count
,a.scrubbed_speed_increasing_count
,a.scrubbed_speed_steady_count
,a.absolute_speed_change
,a.end_scrubbed_speed_bump
,a.plausible_indicator
,a.plausibility_reason
,a.centroid_number
,a.source_cd
,a.batch
FROM smartride_canonical_hive_db.centroid_summary a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch = b.batch
AND a.source_cd = b.source_cd

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc c
ON a.sr_pgm_instnc_id =c.sr_pgm_instnc_id;


--- Handling bonus trip for dc_centroid_summary
INSERT INTO TABLE smartride_work_hive_db.dc_centroid_summary
PARTITION (source_cd, batch)
SELECT
c.dc_instance_id
,a.trip_nb
,a.centroid_rpm_start
,a.centroid_start_time
,a.centroid_end_time
,a.min_scrubbed_speed
,a.max_scrubbed_speed
,a.min_delta_scrubbed_speed
,a.max_delta_scrubbed_speed
,a.scrubbed_speed_decreasing_count
,a.scrubbed_speed_increasing_count
,a.scrubbed_speed_steady_count
,a.absolute_speed_change
,a.end_scrubbed_speed_bump
,a.plausible_indicator
,a.plausibility_reason
,a.centroid_number
,a.source_cd
,a.batch
FROM smartride_canonical_hive_db.centroid_summary a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch = b.batch
AND a.source_cd = b.source_cd

INNER JOIN smartride_canonical_hive_db.tsp_tripsummary d
ON a.batch = d.batch
AND a.source_cd = d.source_cd
AND a.trip_nb=d.trip_nb
AND a.sr_pgm_instnc_id ='-1'

INNER JOIN
(
	SELECT dc_instance_id, dev_id_nbr, vhcl_id_nbr
	FROM smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc
	GROUP BY dc_instance_id, dev_id_nbr, vhcl_id_nbr
) c
ON d.deviceserial_nb = c.dev_id_nbr
AND d.enrolledvin_nb = c.vhcl_id_nbr;


--dc_tripdetail_seconds
INSERT OVERWRITE TABLE smartride_work_hive_db.dc_tripdetail_seconds PARTITION(source_cd,batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.trip_nb
,a.position_ts
,a.position_offset_ts
,a.speed_mph
,a.speed_kph
,a.distance
,a.distance_kph
,a.nighttime_driving_ind
,a.eventcounter_fa
,a.eventcounter_hb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL )THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END
,a.tripzoneoffset_am
,a.plcy_ratd_st_cd
,a.enginerpm_qt
,a.time_driving_ind
,a.time_idle_ind
,a.plausible_ind
,a.centroid_nb
,a.scrubbed_fields
,a.loadevent_id
,a.source_cd
,a.batch
FROM smartride_canonical_hive_db.tripdetail_seconds a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch= b.batch
AND a.source_cd = b.source_cd

INNER JOIN
(SELECT dc_instance_id, dev_id_nbr, vhcl_id_nbr
FROM smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc
GROUP BY dc_instance_id, dev_id_nbr, vhcl_id_nbr
)c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr;


--dc_tsp_tripsummary
INSERT OVERWRITE TABLE smartride_work_hive_db.dc_tsp_tripsummary PARTITION (source_cd,batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.fullpolicy_nb
,a.voucher_nb
,a.trip_nb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END
,a.tripstart_ts
,a.tripend_ts
,a.plcy_ratd_st_cd
,a.tripdistance_qt
,a.averagespeed_qt
,a.maximumspeed_qt
,a.fuelconsumption_qt
,a.milstatus_cd
,a.tripzoneoffset_am
,a.idletime_ts
,a.trippositionalquality_qt
,a.accelerometerquality_qt
,a.distancemotorways_qt
,a.distanceurbanareas_qt
,a.distanceotherroad_qt
,a.distanceunknownroad_qt
,a.timetravelled_qt
,a.timemotorways_qt
,a.timeurbanareas_qt
,a.timeotherroad_qt
,a.timeunknownroad_qt
,a.speedingdistancemotorways_qt
,a.speedingdistanceurbanareas_qt
,a.speedingdistanceotherroad_qt
,a.speedingdistanceunknownroad_qt
,a.speedingtimemotorways_qt
,a.speedingtimeurbanareas_qt
,a.speedingtimeotherroad_qt
,a.speedingtimeunknownroad_qt
,a.source_cd
,a.batch
FROM smartride_canonical_hive_db.tsp_tripsummary a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch= b.batch
and a.source_cd = b.source_cd

INNER JOIN
(
SELECT dc_instance_id, dev_id_nbr, vhcl_id_nbr
FROM smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc
GROUP BY dc_instance_id, dev_id_nbr, vhcl_id_nbr
) c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr;


--dc_trip_details
insert into table smartride_work_hive_db.dc_trip_details
PARTITION (source_cd, batch)
select
c.dc_instance_id
,a.period_type
,a.periodstart_ts
,a.periodend_ts
,a.miles
,a.kilometers
,a.night_time_driving_sec_ct
,a.fast_acceleration_ct
,a.hard_brake_ct
,a.idle_time_sec_ct
,a.drive_time_sec_ct
,a.idle_time_ratio
,a.trip_seconds_json
,a.trip_nb
,a.source_cd
,a.batch
FROM smartride_canonical_hive_db.trip_details a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch = b.batch
AND a.source_cd = b.source_cd

JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc c
ON a.sr_pgm_instnc_id = c.sr_pgm_instnc_id
;

---dc_tsp_tripcumulative
INSERT OVERWRITE TABLE smartride_work_hive_db.dc_tsp_tripcumulative PARTITION (source_cd,batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.voucher_nb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END
,a.cumulativetrips_qt
,a.cumulativedistance_qt
,a.cumulativeengineon_qt
,a.firsttripstart_ts
,a.lasttripend_ts
,a.lastprocessing_ts
,a.source_cd
,a.batch
from smartride_canonical_hive_db.tsp_tripcumulative a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch = b.batch
and a.source_cd = b.source_cd

INNER JOIN
(
SELECT dc_instance_id, dev_id_nbr, vhcl_id_nbr
FROM smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc
GROUP BY dc_instance_id, dev_id_nbr, vhcl_id_nbr
) c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr;

---dc_garbage_tripdetail_seconds
INSERT OVERWRITE TABLE smartride_work_hive_db.dc_garbage_tripdetail_seconds PARTITION (source_cd, batch)
SELECT
c.dc_instance_id,
a.dataload_dt,
a.trip_nb,
a.position_ts,
a.position_offset_ts,
a.speed_mph,
a.speed_kph,
a.distance,
a.distance_kph,
a.nighttime_driving_ind,
a.eventcounter_fa,
a.eventcounter_hb,
CASE WHEN UPPER(TRIM(a.detectedvin_nb))='NULL' THEN NULL
WHEN TRIM(a.detectedvin_nb) IS NULL THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END,
a.tripzoneoffset_am,
a.plcy_ratd_st_cd,
a.enginerpm_qt,
a.time_driving_ind,
a.time_idle_ind,
a.plausible_ind,
a.centroid_nb,
a.scrubbed_fields,
a.loadevent_id,
a.source_cd,
a.batch
FROM smartride_canonical_hive_db.garbage_tripdetail_seconds a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch = b.batch
AND a.source_cd = b.source_cd

INNER JOIN
(
	SELECT dc_instance_id, dev_id_nbr, vhcl_id_nbr
	FROM smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc
	GROUP BY dc_instance_id, dev_id_nbr, vhcl_id_nbr
) c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr;


--dc_TSP_TripPoint
insert into table  smartride_work_hive_db.dc_tsp_trippoint
PARTITION (source_cd, batch)
select  a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.fullpolicy_nb
,a.voucher_nb
,a.trip_nb
,a.position_ts
,a.vssspeed_am
,a.vssacceleration_pc
,a.enginerpm_qt
,a.throttleposition_pc
,a.accelerationlateral_qt
,a.accelerationlongitudinal_qt
,a.accelerationvertical_qt
,a.gpsheading_nb  small
,a.positionquality_nb
,a.odometerreading_qt
,a.eventaveragespeed_qt
,a.eventaverageacceleration_qt
,a.distancetravelled_qt
,a.timeelapsed_qt
,a.gpspointspeed_qt
,a.road_tp
,a.source_cd
,a.batch
from smartride_canonical_hive_db.TSP_TripPoint a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
on a.source_cd = b.source_cd
and a.batch = b.batch;

--dc_tsp_tripevent
INSERT INTO TABLE smartride_work_hive_db.dc_tsp_tripevent PARTITION(source_cd,batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.contract_nb
,a.voucher_nb
,a.trip_nb
,CASE WHEN TRIM(a.detectedvin_nb) IS NULL THEN NULL
       WHEN TRIM(UPPER(a.detectedvin_nb)) = 'NULL' THEN NULL
  ELSE CONCAT(SUBSTRING(TRIM(a.detectedvin_nb),0,10),'*******') 
  END AS detectedvin_nb
,a.event_ts
,a.eventtimezoneoffset_nb
,a.latitude_it
,a.longitude_it
,a.eventtype_cd
,a.eventreferencevalue_ds
,a.eventstart_ts
,a.eventend_ts
,a.eventduration_am
,a.source_cd
,a.batch
FROM smartride_canonical_hive_db.tsp_tripevent a

INNER JOIN smartride_work_hive_db.dc_batch_to_process b
ON a.batch= b.batch
and a.source_cd = b.source_cd

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc c
ON a.enrolledvin_nb = c.vhcl_id_nbr

where from_unixtime(unix_timestamp(substr(a.batch,0,8) ,'yyyyMMdd'), 'yyyy-MM-dd') >= c.active_start_dt
AND from_unixtime(unix_timestamp(substr(a.batch,0,8) ,'yyyyMMdd'), 'yyyy-MM-dd') < c.active_end_dt;


--dc_hive_sre_hourly
INSERT INTO smartride_work_hive_db.dc_hive_sre_hourly
PARTITION (source_cd, batch)
SELECT
c.dc_instance_id
,a.trip_nb
,CASE WHEN TRIM(a.detectedvin_nb) IS NULL THEN NULL
       WHEN TRIM(UPPER(a.detectedvin_nb)) = 'NULL' THEN NULL
  ELSE CONCAT(SUBSTRING(TRIM(a.detectedvin_nb),0,10),'*******') 
  END AS detectedvin_nb
,a.plcy_ratd_st_cd
,a.periodstart_ts
,a.periodend_ts
,a.periodstart_hr
,a.periodend_hr
,a.fast_acceleration_ct
,a.hard_brake_ct
,a.miles
,a.kilometers
,a.adjusted_miles
,a.adjusted_km
,a.plausible_miles
,a.plausible_km
,a.nighttime_driving_sec_count
,a.idle_time_sec_count
,a.plausible_idle_time_sec_count
,a.drive_time_sec_count
,a.plausible_drive_time_sec_count
,a.mph_json
,a.fa_json
,a.hb_json
,a.source_cd
,a.batch

FROM smartride_canonical_hive_db.hive_sre_hourly a

INNER JOIN smartride_work_hive_db.batch_to_process b
ON a.batch = b.batch
AND a.source_cd = b.source_cd

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc c
ON a.sr_pgm_instnc_id = c.sr_pgm_instnc_id;


---dc_orphan_trippoint
INSERT OVERWRITE TABLE smartride_work_hive_db.dc_orphan_trippoint PARTITION (source_cd,batch)
SELECT
dataload_dt
,sourcefilename_ts
,loadevent_id
,devicetype_cd
,fullpolicy_nb
,voucher_nb
,trip_nb
,position_ts
,latitude_it
,longitude_it
,vssspeed_am
,vssacceleration_pc
,enginerpm_qt
,throttleposition_pc
,accelerationlateral_qt
,accelerationlongitudinal_qt
,accelerationvertical_qt
,gpsheading_nb
,positionquality_nb
,odometerreading_qt
,eventaveragespeed_qt
,eventaverageacceleration_qt
,distancetravelled_qt
,timeelapsed_qt
,gpspointspeed_qt
,road_tp
,source_cd
,batch
FROM smartride_canonical_hive_db.orphan_trippoint
WHERE regexp_replace(batch,'conv','') <= concat(regexp_replace(cast(date_add(current_date,-730) as string),'-',''),'0000');



--dc_orphan_ts
INSERT INTO TABLE smartride_work_hive_db.dc_orphan_ts
PARTITION (source_cd, batch)
SELECT
b.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.fullpolicy_nb
,a.voucher_nb
,CASE WHEN TRIM(a.detectedvin_nb) IS NULL THEN NULL
       WHEN TRIM(UPPER(a.detectedvin_nb)) = 'NULL' THEN NULL
  ELSE CONCAT(SUBSTRING(TRIM(a.detectedvin_nb),0,10),'*******') 
  END AS detectedvin_nb
,a.trip_nb
,a.tripstart_ts
,a.tripend_ts
,a.plcy_ratd_st_cd
,a.tripdistance_qt
,a.averagespeed_qt
,a.maximumspeed_qt
,a.fuelconsumption_qt
,a.milstatus_cd
,a.tripzoneoffset_am
,a.idletime_ts
,a.trippositionalquality_qt
,a.accelerometerquality_qt
,a.distancemotorways_qt
,a.distanceurbanareas_qt
,a.distanceotherroad_qt
,a.distanceunknownroad_qt
,a.timetravelled_qt
,a.timemotorways_qt
,a.timeurbanareas_qt
,a.timeotherroad_qt
,a.timeunknownroad_qt
,a.speedingdistancemotorways_qt
,a.speedingdistanceurbanareas_qt
,a.speedingdistanceotherroad_qt
,a.speedingdistanceunknownroad_qt
,a.speedingtimemotorways_qt
,a.speedingtimeurbanareas_qt
,a.speedingtimeotherroad_qt
,a.speedingtimeunknownroad_qt
,a.source_cd
,a.batch
FROM  smartride_canonical_hive_db.orphan_ts a

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc  b
ON a.enrolledvin_nb = b.vhcl_id_nbr
AND a.deviceserial_nb = b.dev_id_nbr

WHERE regexp_replace(a.batch,'conv','') <= concat(regexp_replace(cast(date_add(current_date,-730) as string),'-',''),'0000')
AND b.sr_pgm_instnc_id = 0
;



--dc_annual_mileage
INSERT INTO TABLE smartride_work_hive_db.dc_annual_mileage
PARTITION (load_date)
SELECT
 b.dc_instance_id
,a.plcy_ratd_st_cd
,a.first_activity_date
,a.last_activity_date
,a.days_installed
,a.install_percentage
,a.uninstall_percentage
,a.plausible_speed_pcnt
,a.tier1_10avg
,a.tier11_30avg
,a.tier31_70avg
,a.tier71_90avg
,a.tier91_100avg
,a.estimatedkilometers
,a.estimatedmileage
,a.load_date

FROM smartride_canonical_hive_db.annual_mileage a

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc  b
ON a.sr_pgm_instnc_id = b.sr_pgm_instnc_id

WHERE cast(a.load_date as date) > cast(~>last_run_dt as date)
;

--dc_annual_mileage_score
INSERT INTO smartride_work_hive_db.dc_annual_mileage_score
PARTITION (score_date)
SELECT
b.dc_instance_id,
a.policy_nb,
a.score_dt,
a.tripstart_dt,
a.tripend_dt,
a.score_days,
a.percenttime_disconnected,
a.score_1,
a.score_2,
a.score_3,
a.score_4,
a.score_5,
a.score_6,
a.score_7,
a.score_8,
a.score_9,
a.score_10,
a.floor_estimatedkilometers,
a.filler,
a.score_date
FROM smartride_canonical_hive_db.annual_mileage_score a

INNER JOIN
(SELECT dc_instance_id, dev_id_nbr, vhcl_id_nbr
FROM smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc
GROUP BY dc_instance_id, dev_id_nbr, vhcl_id_nbr
) b

ON a.deviceserial_nb = b.dev_id_nbr
AND a.enrolledvin_nb = b.vhcl_id_nbr

WHERE cast(a.score_date AS date) > cast(~>last_run_dt AS date);


---dc_hive_sre_scoring
INSERT OVERWRITE TABLE smartride_work_hive_db.dc_hive_sre_scoring PARTITION (score_date)
SELECT
b.dc_instance_id
,a.policy_number
,a.score_start_date
,a.score_end_date
,a.score_days
,a.score_model_1
,a.pure_score_1
,a.rated_score_1
,a.filler_1
,a.score_model_2
,a.pure_score_2
,a.rated_score_2
,a.filler_2
,a.score_model_3
,a.pure_score_3
,a.rated_score_3
,a.filler_3
,a.score_model_4
,a.pure_score_4
,a.rated_score_4
,a.filler_4
,a.score_model_5
,a.pure_score_5
,a.rated_score_5
,a.filler_5
,a.score_model_6
,a.pure_score_6
,a.rated_score_6
,a.filler_6
,a.score_model_7
,a.pure_score_7
,a.rated_score_7
,a.filler_7
,a.score_model_8
,a.pure_score_8
,a.rated_score_8
,a.filler_8
,a.score_model_9
,a.pure_score_9
,a.rated_score_9
,a.filler_9
,a.score_model_10
,a.pure_score_10
,a.rated_score_10
,a.filler_10
,a.percent_time_disconnected
,a.calculated_annual_mileage
,a.number_of_connect_disconect
,a.uninstalled_time
,a.filler
,a.model_id
,a.hard_brake_ct
,a.fast_acceleration_ct
,a.scrub_miles
,a.adjust_miles
,a.no_idle_time
,a.idle_time
,a.install_percentage
,a.plausible_percentage
,a.score_date
FROM smartride_canonical_hive_db.hive_sre_scoring a

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc b
ON a.program_instance_id = b.sr_pgm_instnc_id

WHERE cast(a.score_date AS date) > cast(~>last_run_dt AS date);


--smartride_work_hive_db.dc_devicestatus
-------------------------PROD----------------------------------

--Step 1 of 6
--drop-create devicestatus tbl 
DROP TABLE IF EXISTS smartride_work_hive_db.dc_devicestatus;
CREATE TABLE smartride_work_hive_db.dc_devicestatus(
dc_instance_id bigint,
status int,
statusstart_ts timestamp,
statusend_ts timestamp,
lastactivity_ts timestamp,
loststatus_flag int)
ROW FORMAT SERDE 
'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
STORED AS TEXTFILE;


--Step 2 of 6
--insert all records fro mprod canonical table
INSERT INTO TABLE smartride_work_hive_db.dc_devicestatus
SELECT 
b.dc_instance_id
,a.status
,a.statusstart_ts
,a.statusend_ts
,a.lastactivity_ts
,a.loststatus_flag
FROM smartride_canonical_hive_db.devicestatus a
  
INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc  b
ON a.sr_pgm_instnc_id = b.sr_pgm_instnc_id  
;

--Step 3 of 6
--sync down table to work-db in QA (different script)

------------------------ QA -------------------------------------

--Step 4 of 6
--take everything from smartride_analysis_db that is not in our work_db table

INSERT INTO TABLE smartride_work_hive_db.dc_devicestatus
SELECT 
a.dc_instance_id
,a.status
,a.statusstart_ts
,a.statusend_ts
,a.lastactivity_ts
,a.loststatus_flag
FROM smartride_analysis_db.devicestatus a   
  
LEFT OUTER JOIN  smartride_work_hive_db.dc_devicestatus b
ON a.dc_instance_id = b.dc_instance_id 
AND a.statusstart_ts = b.statusstart_ts

WHERE b.dc_instance_id is null
;


--Step 5 of 6
--rename analysis table to keep a backup
DROP TABLE IF EXISTS smartride_analysis_db.devicestatus_bkp;
ALTER TABLE RENAME smartride_analysis_db.devicestatus to devicestatus_bkp;


--Step 6 of 6
--recreate analysis table and load data from workdb
DROP TABLE IF EXISTS smartride_analysis_db.devicestatus; 
CREATE  TABLE  smartride_analysis_db.devicestatus (
dc_instance_id bigint,
status int,
statusstart_ts timestamp,
statusend_ts timestamp,
lastactivity_ts timestamp,
loststatus_flag int)
ROW FORMAT SERDE 
'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
STORED AS TEXTFILE;


INSERT INTO TABLE  smartride_analysis_db.devicestatus
SELECT
dc_instance_id
,status
,statusstart_ts
,statusend_ts
,lastactivity_ts
,loststatus_flag
FROM smartride_work_hive_db.dc_devicestatus;





----------------------------------------PROD Start  - Table: device_install_pcnt--------------------------------------

DROP TABLE smartride_work_hive_db.dc_device_install_pcnt;

CREATE TABLE smartride_work_hive_db.dc_device_install_pcnt(
  dc_instance_id bigint,
  loststatus_flag bigint,
  total_time bigint,
  total_install_time bigint,
  install_percentage double,
  total_uninstall_time bigint,
  uninstall_percentage double,
  first_activity_date timestamp,
  last_activity_date timestamp,
  total_days bigint,
  days_installed bigint,
  connection_ct bigint,
  disconnection_ct bigint)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

-- Insert all rows from canonical to work table---
INSERT INTO smartride_work_hive_db.dc_device_install_pcnt
SELECT
b.dc_instance_id
,a.loststatus_flag
,a.total_time
,a.total_install_time
,a.install_percentage
,a.total_uninstall_time
,a.uninstall_percentage
,a.first_activity_date
,a.last_activity_date
,a.total_days
,a.days_installed
,a.connection_ct
,a.disconnection_ct

FROM smartride_canonical_hive_db.device_install_pcnt a

INNER JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc b
ON a.sr_pgm_instnc_id = b.sr_pgm_instnc_id
;

----------------------------------------PROD End  - Table: device_install_pcnt--------------------------------------


----------------------------------------QA Start  - Table: device_install_pcnt--------------------------------------
/* This is incremental load*/
-- COPY smartride_work_hive_db.dc_device_install_pcnt with data from Prod to QA ---

DROP TABLE smartride_work_hive_db.dc_device_install_pcnt_prep;

CREATE TABLE smartride_work_hive_db.dc_device_install_pcnt_prep(
  dc_instance_id bigint,
  loststatus_flag bigint,
  total_time bigint,
  total_install_time bigint,
  install_percentage double,
  total_uninstall_time bigint,
  uninstall_percentage double,
  first_activity_date timestamp,
  last_activity_date timestamp,
  total_days bigint,
  days_installed bigint,
  connection_ct bigint,
  disconnection_ct bigint)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

--- Pass 1: Insert all rows from cannonical to prep---
INSERT INTO smartride_work_hive_db.dc_device_install_pcnt_prep
SELECT
a.dc_instance_id
,a.loststatus_flag
,a.total_time
,a.total_install_time
,a.install_percentage
,a.total_uninstall_time
,a.uninstall_percentage
,a.first_activity_date
,a.last_activity_date
,a.total_days
,a.days_installed
,a.connection_ct
,a.disconnection_ct

FROM smartride_work_hive_db.dc_device_install_pcnt a
;

--- Pass 2: Insert all rows from hist that are not in canonical---
INSERT INTO smartride_work_hive_db.dc_device_install_pcnt_prep
SELECT
a.dc_instance_id
,a.loststatus_flag
,a.total_time
,a.total_install_time
,a.install_percentage
,a.total_uninstall_time
,a.uninstall_percentage
,a.first_activity_date
,a.last_activity_date
,a.total_days
,a.days_installed
,a.connection_ct
,a.disconnection_ct

FROM smartride_work_hive_db.device_install_pcnt a

LEFT OUTER JOIN smartride_work_hive_db.dc_device_install_pcnt b
ON a.dc_instance_id = b.dc_instance_id

WHERE b.dc_instance_id IS NULL;


--- Pass 3: Recreate final table ---
DROP TABLE smartride_work_hive_db.device_install_pcnt;

CREATE TABLE smartride_work_hive_db.device_install_pcnt(
  dc_instance_id bigint,
  loststatus_flag bigint,
  total_time bigint,
  total_install_time bigint,
  install_percentage double,
  total_uninstall_time bigint,
  uninstall_percentage double,
  first_activity_date timestamp,
  last_activity_date timestamp,
  total_days bigint,
  days_installed bigint,
  connection_ct bigint,
  disconnection_ct bigint)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

INSERT INTO smartride_work_hive_db.device_install_pcnt
SELECT
dc_instance_id
,loststatus_flag
,total_time
,total_install_time
,install_percentage
,total_uninstall_time
,uninstall_percentage
,first_activity_date
,last_activity_date
,total_days
,days_installed
,connection_ct
,disconnection_ct
FROM smartride_work_hive_db.dc_device_install_pcnt_prep;

----------------------------------------QA End  - Table: device_install_pcnt--------------------------------------


--hive_sre_summary
-----------------------------------------------------------------
---------------------PROD----------------------------------------
-----------------------------------------------------------------
--Step 1 of 6
--drop/recreate dc table
drop table if exists smartride_work_hive_db.dc_hive_sre_summary;
CREATE TABLE  smartride_work_hive_db.dc_hive_sre_summary (
   dc_instance_id bigint,
   period_type  string,
   periodstart_ts  timestamp,
   periodend_ts  timestamp,
   miles  double,
   kilometers  double,
   night_time_driving_sec_ct  int,
   fast_acceleration_ct  int,
   hard_brake_ct  int,
   idle_time_sec_ct  int,
   drive_time_sec_ct  int,
   idle_time_ratio  double)
PARTITIONED BY (
   source_cd  string)
STORED AS ORC;

--Step 2 of 6
--insert all records from our prod canonical table
INSERT INTO TABLE  smartride_work_hive_db.dc_hive_sre_summary
PARTITION (source_cd)
SELECT
b.dc_instance_id
,a.period_type
,a.periodstart_ts
,a.periodend_ts
,a.miles
,a.kilometers
,a.night_time_driving_sec_ct
,a.fast_acceleration_ct
,a.hard_brake_ct
,a.idle_time_sec_ct
,a.drive_time_sec_ct
,a.idle_time_ratio
,a.source_cd

FROM  smartride_canonical_hive_db.hive_sre_summary a

JOIN smartride_work_hive_db.dc_smt_ods_bigin_pgm_instnc    b
ON a.sr_pgm_instnc_id = b.sr_pgm_instnc_id
;


--Step 3 of 6
--sync down table to work-db in QA (different script)

---------------------------------------------------------------------------
--------------------- QA --------------------------------------------------
---------------------------------------------------------------------------
--Step 4 of 6
--take everything from smartride_analysis_db that is not in our work_db table

INSERT INTO TABLE  smartride_work_hive_db.dc_hive_sre_summary
PARTITION (source_cd)
SELECT
a.dc_instance_id
,a.period_type
,a.periodstart_ts
,a.periodend_ts
,a.miles
,a.kilometers
,a.night_time_driving_sec_ct
,a.fast_acceleration_ct
,a.hard_brake_ct
,a.idle_time_sec_ct
,a.drive_time_sec_ct
,a.idle_time_ratio
,a.source_cd
FROM  smartride_analysis_db.hive_sre_summary a

LEFT OUTER JOIN smartride_work_hive_db.dc_hive_sre_summary b
ON a.dc_instance_id = b.dc_instance_id
AND a.period_type = b.period_type
AND a.periodstart_ts = b.periodstart_ts

WHERE b.dc_instance_id  IS NULL;

--Step 5 of 6
--rename analysis table to keep a backup
DROP TABLE IF EXISTS smartride_analysis_db.hive_sre_summary_bkp;
ALTER TABLE RENAME smartride_analysis_db.hive_sre_summary to hive_sre_summary_bkp;


--Step 6 of 6
--recreate analysis table and load data from workdb
DROP TABLE IF EXISTS smartride_analysis_db.hive_sre_summary; 
CREATE  TABLE  smartride_analysis_db.hive_sre_summary (
   dc_instance_id bigint, 
   period_type  string, 
   periodstart_ts  timestamp, 
   periodend_ts  timestamp, 
   miles  double, 
   kilometers  double, 
   night_time_driving_sec_ct  int, 
   fast_acceleration_ct  int, 
   hard_brake_ct  int, 
   idle_time_sec_ct  int, 
   drive_time_sec_ct  int, 
   idle_time_ratio  double)
PARTITIONED BY ( 
   source_cd  string)
STORED AS ORC;


INSERT INTO TABLE  smartride_analysis_db.hive_sre_summary
PARTITION (source_cd)
SELECT
dc_instance_id
,period_type
,periodstart_ts
,periodend_ts
,miles
,kilometers
,night_time_driving_sec_ct
,fast_acceleration_ct
,hard_brake_ct
,idle_time_sec_ct
,drive_time_sec_ct
,idle_time_ratio
,source_cd
FROM smartride_work_hive_db.dc_hive_sre_summary;