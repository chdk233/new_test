#!/bin/bash

set -e -u -x

cat image-version/version > version-and-tag/version
echo " $1" >> version-and-tag/version