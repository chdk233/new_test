
## ESP Applications

* [GDWTEL2](https://github.nwie.net/Nationwide/srdp-perl#gdwdtel2-ims)
* GDWTEL3
* [GDWDBIGI.GDWEXPD](https://github.nwie.net/Nationwide/srdp-perl#gdwdbigigdwexpd-experian)
* [GDWDBIGI.GDWSRD01](https://github.nwie.net/Nationwide/srdp-perl#gdwdbigigdwsrd01-smartridedaily)
* GDWDBIGI.GDWSRDM

## Related Repositories

- [srdp repository containing hive udf java functions](https://github.nwie.net/Nationwide/srdp-java-hive-udf)
- [srdp repository containing map reduce program used for trip scrubbing and device status](https://github.nwie.net/Nationwide/srdp-java-map-reduce)

---

# GDWDTEL2-IMS

(GDWTEL3-OCTO is basically the same except for Acquire)

---

## GDW_SRDP_1301_IMS_HF_FILE_TRANSFER_PRD

**Grabs files from dropbox, performs auditing, combines files, transfers them to HDFS and backs them up**

### Oracle Parameters:

| JOB_CD | PARM_NAME                          | PARM_VALUE                       |
|:-------|:-----------------------------------|:---------------------------------|
| 1301   | InputFile1                         | IMS_N                            |
| 1301   | InputFile2                         | END                              |
| 1301   | next_job_cd_IMSTripsAuditThreshold | 2309                             |
| 1301   | next_job_cd_IMSaudit               | 2300                             |
| 1301   | srdp_support_email                 | DW- RAPID- RESPONSE@nationwide.com |

### gdw1301IMSHfAcquire.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw1301IMSHfAcquire.pl)

#### FindIMSDataSets()

- Identify files.
- Identify file date (from file name).
- Validates all files received.
- MD5 file integrity verification.
- Removes MD5 and DONE files.

```yaml
inbound_dir: /etl03/dropbox/SRDP/NIMS_HF
```

#### RemoveFilesFromWorking()

- clean up any files that could be remaining in working directory

#### DataToWorking()

```yaml
inbound_dir: /etl03/dropbox/SRDP/NIMS_HF
working_dir: /etl03/prod/data/srdp/working
```

#### VerifyAndCombineDataSets()

- uses unix tail and redirect to new combined file

#### GetSourceAuditCount()

- Insert job audit counts into oracle job audit table

#### CopyFilesToHadoop()

- Uses curl command and webhdfs rest api.

```yaml
hadoop_ims_root: /Programs/SmartRide/IMS/
```

```perl
my $name;
switch ($1) {
case "CTR" { $name = "Cumulative"; }
case "TPR" { $name = "TripPoint"; }
case "TSR" { $name = "TripSummary"; }
case "EVT" { $name = "EventCapture"; }
}
my $hadoop_root = $ProcVars->{hadoop_ims_root};
my $hadoop_path = "$hadoop_root/$name/loadevent=$ProcVars->{load_event_id}";
.
.
.
$hadoop_path = "$hadoop_path/$batch_dir";
```

#### RemoveFilesFromWorking()

- clean up any files in working directory.

#### MoveFilesToBackup()

- Compresses raw files.
- Moves compressed files to backup.

---

## GDW_SRDP_2300_IMS_AUDIT_BALANCE

**Identifies duplicate trips and creates a list of trips that are both in tripsummary and trippoint**

### Oracle Parameters:

| JOB_CD | PARM_NAME                                 | PARM_VALUE                                                                 |
|:-------|:------------------------------------------|:---------------------------------------------------------------------------|
| 2300   | drop_and_create_partitioned_cano_wk_table | gdw2300StandardizeIMSauditCanonical_DropRecreate_Step1                     |
| 2300   | location1                                 | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_dup_ctrl_temp |
| 2300   | next_job_cd_IMScumulative                 | 2304                                                                       |
| 2300   | next_job_cd_IMSevent                      | 2303                                                                       |
| 2300   | next_job_cd_IMStripp                      | 2301                                                                       |
| 2300   | next_job_cd_IMStrips                      | 2302                                                                       |
| 2300   | previous_job_cd                           | 1301                                                                       |
| 2300   | smartride_canonical_hive_db               | SmartRide_Canonical_Hive_DB                                                |
| 2300   | smartride_raw_hive_db                     | SmartRide_Raw_Hive_DB                                                      |
| 2300   | smartride_work_hive_db                    | smartride_work_hive_db                                                     |
| 2300   | source_cd                                 | IMS                                                                        |
| 2300   | sql_altr_tbl_add_partition_ext_table      | gdw2300StandardizeIMSAuditCanonical_AlterExtTable_Step2                    |
| 2300   | sql_load_wk_cano_partition                | gdw2300StandardizeIMSauditCanonical_DupCtrlTableLoad_Step3                 |


### gdw23xxstandardize_audit.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw23xxStandardize_Audit.pl)

#### step1 and 2 is drop and (re)create table/partitions

#### gdw2300standardizeimsauditcanonical_dupctrltableload_step3.sql

1. Identify trippoint duplicates in current loadevent_id

   * *SOURCE*: smartride_raw_hive_db.ims_trippoint_ext
   * *TARGET*: smartride_work_hive_db.wk_ims_trippoint_ext_dups

```sql
 where loadevent = ~>load_event_id
 group by trip_nb,position_ts having count(*) > 1
```

2. Identify tripevent duplicates in current loadevent_id

   * *SOURCE*: smartride_raw_hive_db.ims_tripevent_ext
   * *TARGET*: smartride_work_hive_db.wk_ims_tripevent_ext_dups

```sql
 where loadevent = ~>load_event_id
 group by trip_nb,event_ts,eventtype_cd having count(*) > 1
```

3. Identify tripsummary duplicates in current loadevent_id

   * *SOURCE*: smartride_raw_hive_db.ims_tripsummary_ext
   * *TARGET*: smartride_work_hive_db.wk_ims_tripsummary_ext_dups

```sql
 where loadevent= ~>load_event_id
 group by trip_nb having count(*) > 1
```

4. Creates distinct list of trips that are duplicated

   * *SOURCE*: smartride_work_hive_db.wk_ims_tripsummary_ext_dups
   * *SOURCE*: smartride_work_hive_db.wk_ims_tripevent_ext_dups
   * *SOURCE*: smartride_work_hive_db.wk_ims_trippoint_ext_dups
   * *TARGET*: smartride_work_hive_db.wk_ims_dup_ctrl_temp

5. Running list of duplicates stored in canonical table

   * *SOURCE*: smartride_work_hive_db.wk_ims_dup_ctrl_temp
   * *TARGET*: smartride_canonical_hive_db.ims_dup_ctrl

6. List of trips present in tripsummary and trippoint

   * *SOURCE*: smartride_raw_hive_db.ims_trippoint_ext
   * *SOURCE*: smartride_raw_hive_db.ims_tripsummary_ext
```sql
inner join: smartride_raw_hive_db.ims_tripsummary_ext
 on tp.trip_nb = ts.trip_nb
 and ts.loadevent = tp.loadevent
 where ts.loadevent= ~>load_event_id
```
*TARGET*: smartride_work_hive_db.wk_ims_missing_trip_ctrl_temp

7. Insert from temp to target table

**Perl code loops by loadevent_id. Since temp table is dropped and recreated, temp table is inserted into target table IMS_Missing_Trip_Ctrl**

   * *SOURCE*: smartride_canonical_hive_db.WK_IMS_Missing_Trip_Ctrl_Temp
   * *TARGET*: smartride_work_hive_db.IMS_Missing_Trip_Ctrl

---

## GDW_SRDP_2301_IMS_CANONICAL_CTR

**Loads current bactch(s) into smartride_canonical_hive_db.tsp_tripcumulative**

### Oracle Parameters:

| JOB_CD | PARM_NAME                                 | PARM_VALUE                                                                      |
|:-------|:------------------------------------------|:--------------------------------------------------------------------------------|
| 2301   | can_tripcumulative                        | TSP_TripCumulative                                                              |
| 2301   | drop_and_create_partitioned_cano_wk_table | gdw2301StandardizeIMSCanonicalCumulative_DropRecreate_Step1                     |
| 2301   | ext_ims_tripcumulative                    | IMS_TripCumulative_Ext                                                          |
| 2301   | location1                                 | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_tsp_tripcumulative |
| 2301   | previous_job_cd                           | 1301                                                                            |
| 2301   | smartride_canonical_hive_db               | SmartRide_Canonical_Hive_DB                                                     |
| 2301   | smartride_raw_hive_db                     | SmartRide_Raw_Hive_DB                                                           |
| 2301   | smartride_work_hive_db                    | smartride_work_hive_db                                                          |
| 2301   | source_cd                                 | IMS                                                                             |
| 2301   | sql_altr_tbl_add_partition_ext_table      | gdw2301StandardizeIMSCanonicalCumulative_AlterExtTable_Step2                    |
| 2301   | sql_file_name                             | gdw2301StandardizeIMSCanonicalCumulative.sql                                    |
| 2301   | sql_load_canonical                        | gdw2301StandardizeIMSCanonicalCumulative_LoadTSP_TripCumulative_Step4           |
| 2301   | sql_load_wk_cano_partition                | gdw2301StandardizeIMSCanonicalCumulative_WkTableLoad_Step3                      |
| 2301   | sql_logfile_name                          | gdw2301Standardize_IMSCanonicalCumulative                                       |
| 2301   | wk_ims_tripcumulative                     | WK_IMS_TSP_TripCumulative                                                       |


### gdw23xxstandardize.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw23xxStandardize.pl)


---

## GDW_SRDP_2302_IMS_CANONICAL_TSR

**Loads current bactch(s) into smartride_canonical_hive_db.tsp_tripsummary**

### Oracle Parameters:

| JOB_CD | PARM_NAME                                 | PARM_VALUE                                                                   |
|:-------|:------------------------------------------|:-----------------------------------------------------------------------------|
| 2302   | can_tripsummary                           | TSP_TripSummary                                                              |
| 2302   | drop_and_create_partitioned_cano_wk_table | gdw2302StandardizeIMSCanonicalSummary_DropRecreate_Step1                     |
| 2302   | ext_ims_tripsummary                       | IMS_TripSummary_Ext                                                          |
| 2302   | location1                                 | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_tsp_tripsummary |
| 2302   | previous_job_cd                           | 1301                                                                         |
| 2302   | smartride_canonical_hive_db               | SmartRide_Canonical_Hive_DB                                                  |
| 2302   | SmartRide_Canonical_Hive_DB               | smartride_canonical_hive_db                                                  |
| 2302   | smartride_raw_hive_db                     | SmartRide_Raw_Hive_DB                                                        |
| 2302   | smartride_work_hive_db                    | smartride_work_hive_db                                                       |
| 2302   | source_cd                                 | IMS                                                                          |
| 2302   | sql_altr_tbl_add_partition_ext_table      | gdw2302StandardizeIMSCanonicalSummary_AlterExtTable_Step2                    |
| 2302   | sql_file_name                             | gdw2302StandardizeIMSCanonicalTripSummary.sql                                |
| 2302   | sql_load_canonical                        | gdw2302StandardizeIMSCanonicalSummary_LoadTSP_TripSummary_Step4              |
| 2302   | sql_load_wk_cano_partition                | gdw2302StandardizeIMSCanonicalSummary_WkTableLoad_Step3                      |
| 2302   | sql_logfile_name                          | gdw2302Standardize_IMSCanonicalTripSummary                                   |
| 2302   | wk_ims_tripsummary                        | WK_IMS_TSP_TripSummary                                                       |


### gdw23xxstandardize.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw23xxStandardize.pl)

#### step1 and 2 is drop and recreate table/partitions

#### gdw2302standardizeimscanonicalsummary_wktableload_step3.sql

   * *SOURCE*: smartride_raw_hive_db.ims_tripsummary_ext
**filtered by loadevent_id**
   * *TARGET*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp

#### gdw2302standardizeimscanonicalsummary_loadtsp_tripsummary_step4.sql

1. identify trips that have already occured in other batches found in tps

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp
   * *SOURCE*: smartride_canonical_hive_db.tsp_tripsummary
   * *TARGET*: smartride_canonical_hive_db.ims_tsp_tripsummary_dups
**overwrite partition(*SOURCE*_cd,batch)**
```sql
outer join: smartride_canonical_hive_db.tsp_tripsummary
 on tsp_ts.trip_nb = temp.trip_nb
 and tsp_ts.SOURCE_cd = temp.SOURCE_cd
 where  tsp_ts.trip_nb is not null and
 tsp_ts.batch <> temp.batch
```

2. unique trips, those not in step1.

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp
   * *SOURCE*: smartride_work_hive_db.ims_tsp_tripsummary_dups
   * *TARGET*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp_2
```sql
outer join: smartride_canonical_hive_db.ims_tsp_tripsummary_dups
 on dups.trip_nb = temp.trip_nb and
  dups.*SOURCE*_cd = temp.*SOURCE*_cd and
  dups.batch = temp.batch
  where dups.trip_nb is null;
```

3. trip dups in current load

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp
   * *SOURCE*: smartride_work_hive_db.wk_ims_dup_ctrl_temp
   * *TARGET*: smartride_work_hive_db.wk_ims_tsp_tripsummary_dups
```sql
outer join: smartride_work_hive_db.wk_ims_dup_ctrl_temp
on dup.trip_nb = temp.trip_nb
where dup.trip_nb is not null;
```

4. trip dups in current load

   * *SOURCE*: smartride_canonical_hive_db.wk_ims_tsp_tripsummary_dups
   * *TARGET*: smartride_work_hive_db.ims_tsp_tripsummary_dups

5. Unique trips in current load

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp_2
   * *SOURCE*: smartride_work_hive_db.wk_ims_dup_ctrl_temp
   * *TARGET*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp_3
```sql
 left outer join ~>smartride_work_hive_db.wk_ims_dup_ctrl_temp dup
 on
 dup.trip_nb = temp.trip_nb
 where
 dup.trip_nb is null;
```

6. Trips missing from trippoint

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp_3
   * *SOURCE*: smartride_work_hive_db.WK_IMS_Missing_Trip_Ctrl_Temp
   * *TARGET*: smartride_work_hive_db.wk_ims_tsp_tripsummary_mis
```sql
 left outer join ~>smartride_work_hive_db.WK_IMS_Missing_Trip_Ctrl_Temp mis
 on mis.trip_nb = temp.trip_nb
 where mis.trip_nb is null;
```

7. Trips missing from trippoint work to canonical

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_mis
   * *TARGET*: smartride_canonical_hive_db.ims_tsp_tripsummary_mis
```sql
INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.ims_tsp_tripsummary_mis
PARTITION (source_cd, batch)
```

8. non missing trips

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp_3
   * *SOURCE*: smartride_work_hive_db.wk_ims_missing_trip_ctrl_temp
   * *TARGET*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp_4
```sql
 left outer join ~>smartride_work_hive_db.WK_IMS_Missing_Trip_Ctrl_Temp mis
 on mis.trip_nb = temp.trip_nb
 where mis.trip_nb is not null;
```

9. Has orphans and non- orphans

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_tripsummary_temp_4
   * *SOURCE*: smartride_work_hive_db.wk_smt_ods_lkp
   * *TARGET*: smartride_work_hive_db.wk_ims_tsp_pid
```sql
LEFT OUTER JOIN
~>smartride_work_hive_db.WK_SMT_ODS_LKP as lkp
on temp.DeviceSerial_Nb = lkp.dev_id_nbr
and temp.EnrolledVIN_Nb = lkp.vhcl_id_nbr
```

10. Orphans (only if no program instance exists, if exists but outside of enrollment then bonus)

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_pid
   * *TARGET*: smartride_work_hive_db.wk_ims_orphan_ts
```sql
 where dev_id_nbr is null and vhcl_id_nbr is null
```

11. non orphan and non bonus( trip has piid and didn't occur outside of enrollment)

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_pid
   * *SOURCE*: smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC
   * *TARGET*: smartride_work_hive_db.wk_ims_non_orphans_non_bonus
```sql
LEFT OUTER JOIN
~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC as lkp
ON tsp.DeviceSerial_Nb = lkp.dev_id_nbr and
tsp.EnrolledVIN_Nb = lkp.vhcl_id_nbr
WHERE tsp.dev_id_nbr IS NOT NULL and
tsp.vhcl_id_nbr IS NOT NULL
AND tsp.tripstart_ts between lkp.sr_enrlmnt_dt and lkp.active_end_dt
```

12. Insert bonus trips using a program instance of -1 (bonus = has piid but outside of enrollment)
(Trips not found in non orphan and non bonus)

   * *SOURCE*: smartride_work_hive_db.wk_ims_tsp_pid
   * *SOURCE*: smartride_work_hive_db.WK_ims_non_orphans_non_bonus
   * *TARGET*: smartride_work_hive_db.WK_IMS_TSP_TripSummary_final
```sql
left outer join
~>smartride_work_hive_db.WK_ims_non_orphans_non_bonus nonb
ON tsp.Trip_Nb = nonb.Trip_Nb
WHERE tsp.dev_id_nbr IS NOT NULL and
tsp.vhcl_id_nbr IS NOT NULL and
nonb.Trip_Nb is null;
```

13. Insert non- bonus and non- orphan

   * *SOURCE*: smartride_work_hive_db.wk_ims_non_orphans_non_bonus
   * *TARGET*: smartride_work_hive_db.WK_IMS_TSP_TripSummary_final

14. TripSummary Work to Target and another work table (not sure why)

   * *SOURCE*: smartride_work_hive_db.WK_IMS_TSP_TripSummary_final
   * *TARGET*: smartride_canonical_hive_db.tsp_tripsummary
**overwrite partition(*SOURCE*_cd,batch)**
   * *TARGET*: smartride_work_hive_db.WK_IMS_TSP_TripSummary
**overwrite table**

15. Insert Orphan_Ts Work to Target

   * *SOURCE*: smartride_work_hive_db.wk_ims_orphan_ts
   * *TARGET*: smartride_canonical_hive_db.orphan_ts
**overwrite partition(*SOURCE*_cd)**

---

## GDW_SRDP_2303_IMS_CANONICAL_TPR

**Loads current bactch(s) into smartride_canonical_hive_db.tsp_trippoint**

### Oracle Parameters:

| JOB_CD | PARM_NAME                                 | PARM_VALUE                                                                 |
|:-------|:------------------------------------------|:---------------------------------------------------------------------------|
| 2303   | can_trippoint                             | TSP_TripPoint                                                              |
| 2303   | drop_and_create_partitioned_cano_wk_table | gdw2303StandardizeIMSCanonicalTripPoint_DropRecreate_Step1                 |
| 2303   | ext_ims_trippoint                         | IMS_TripPoint_Ext                                                          |
| 2303   | location1                                 | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_tsp_trippoint |
| 2303   | next_job_cd_scrub                         | 2311                                                                       |
| 2303   | previous_job_cd                           | 1301                                                                       |
| 2303   | smartride_canonical_hive_db               | SmartRide_Canonical_Hive_DB                                                |
| 2303   | smartride_raw_hive_db                     | SmartRide_Raw_Hive_DB                                                      |
| 2303   | smartride_work_hive_db                    | smartride_work_hive_db                                                     |
| 2303   | source_cd                                 | IMS                                                                        |
| 2303   | sql_altr_tbl_add_partition_ext_table      | gdw2303StandardizeIMSCanonicalTripPoint_AlterExtTable_Step2                |
| 2303   | sql_file_name                             | gdw2303StandardizeIMSCanonicalTripPoint.sql                                |
| 2303   | sql_load_canonical                        | gdw2303StandardizeIMSCanonicalTripPoint_LoadTSP_TripPoint_Step4            |
| 2303   | sql_load_wk_cano_partition                | gdw2303StandardizeIMSCanonicalTripPoint_WkTableLoad_Step3                  |
| 2303   | sql_logfile_name                          | gdw2303Standardize_IMSCanonicalTripPoint                                   |
| 2303   | wk_ims_trippoint                          | WK_IMS_TSP_TripPoint                                                       |

---

## GDW_SRDP_2304_IMS_CANONICAL_EVT

**Loads current bactch(s) into smartride_canonical_hive_db.tsp_tripevent**

### Oracle Parameters:

| JOB_CD | PARM_NAME                                 | PARM_VALUE                                                                 |
|:-------|:------------------------------------------|:---------------------------------------------------------------------------|
| 2304   | can_tripevent                             | TSP_TripEvent                                                              |
| 2304   | drop_and_create_partitioned_cano_wk_table | gdw2304StandardizeIMSCanonicalTripEvent_DropRecreate_Step1                 |
| 2304   | ext_ims_tripevent                         | IMS_TripEvent_Ext                                                          |
| 2304   | location1                                 | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_tsp_tripevent |
| 2304   | previous_job_cd                           | 1301                                                                       |
| 2304   | smartride_canonical_hive_db               | SmartRide_Canonical_Hive_DB                                                |
| 2304   | smartride_raw_hive_db                     | SmartRide_Raw_Hive_DB                                                      |
| 2304   | smartride_work_hive_db                    | smartride_work_hive_db                                                     |
| 2304   | source_cd                                 | IMS                                                                        |
| 2304   | sql_altr_tbl_add_partition_ext_table      | gdw2304StandardizeIMSCanonicalTripEvent_AlterExtTable_Step2                |
| 2304   | sql_file_name                             | gdw2304StandardizeIMSCanonicalTripEvent.sql                                |
| 2304   | sql_load_canonical                        | gdw2304StandardizeIMSCanonicalTripEvent_LoadTSP_TripEvent_Step4            |
| 2304   | sql_load_wk_cano_partition                | gdw2304StandardizeIMSCanonicalTripEvent_WkTableLoad_Step3                  |
| 2304   | sql_logfile_name                          | gdw2304Standardize_IMSCanonicalTripEvent                                   |
| 2304   | wk_ims_tripevent                          | WK_IMS_TSP_TripEvent                                                       |


---

## GDW_SRDP_2311_IMS_TRIPSCRUB

**Trip scubbing occurs in map reduce program.**

### Oracle Parameters:

| JOB_CD | PARM_NAME                       | PARM_VALUE                                                                      |
|:-------|:--------------------------------|:--------------------------------------------------------------------------------|
| 2311   | PostScrub_sql_file_name         | gdw23xxBuildTablesFromMROutput.sql                                              |
| 2311   | PostScrub_sql_logfile_name      | gdw23xxBuildTablesFromMROutput                                                  |
| 2311   | PreScrub_sql_file_name          | gdw23xxTripScrub.sql                                                            |
| 2311   | PreScrub_sql_logfile_name       | gdw2311TripScrub                                                                |
| 2311   | location1                       | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_tsp_ims_trippoint      |
| 2311   | location2                       | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_tripp_trips        |
| 2311   | location3                       | /biginsights/hive/warehouse/smartride_canonical_hive_db.db/orphan_ims_trippoint |
| 2311   | map_reduce_driver_name          | com.nationwide.smartride.scrub.TripScrubMain                                    |
| 2311   | map_reduce_input_file           | wk_ims_tripp_trips                                                              |
| 2311   | map_reduce_input_path           | /apps/hive/warehouse/smartride_work_hive_db.db/                                 |
| 2311   | map_reduce_jar_name             | mapReduce-0.0.1-SNAPSHOT.jar                                                    |
| 2311   | map_reduce_output_file          | ims_result                                                                      |
| 2311   | map_reduce_output_path          | /Programs/SmartRide/TEMP/IMS/postcentriod/                                      |
| 2311   | next_job_cd                     | 3301                                                                            |
| 2311   | orphan_trippoint                | orphan_ims_trippoint                                                            |
| 2311   | smartride_canonical_hive_db     | SmartRide_Canonical_Hive_DB                                                     |
| 2311   | smartride_work_hive_db          | smartride_work_hive_db                                                          |
| 2311   | source_cd                       | IMS                                                                             |
| 2311   | wk_centroid_summary             | wk_ims_centroid_summary                                                         |
| 2311   | wk_tripdetail_seconds           | wk_ims_tripdetail_seconds                                                       |
| 2311   | wk_tripp_trips                  | wk_ims_tripp_trips                                                              |
| 2311   | wk_tsp_trippoint                | wk_ims_tsp_trippoint                                                            |
| 2311   | wk_tsp_tripsummary              | wk_ims_tsp_tripsummary                                                          |


### gdw23xxtripscrub.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw23xxTripScrub.pl)

#### gdw23xxtripscrub.sql

   * *SOURCE*: smartride_work_hive_db.wk_tsp_tripsummary
   * *SOURCE*: smartride_work_hive_db.wk_tsp_trippoint
   * *TARGET*: smartride_work_hive_db.wk_tripp_trips

```sql
inner join ON tp.trip_nb = ts.trip_nb;
```

#### mapreduce-0.0.1- snapshot.jar

`hadoop jar /home/srdpprod/mapReduce-0.0.1- SNAPSHOT.jar com.nationwide.smartride.scrub.TripScrubMain /apps/hive/warehouse/roberd7_db.db/wk_ims_tripp_trips /user/roberd7/ims_results`

   * *SOURCE*: smartride_work_hive_db.wk_tripp_trips
   * *TARGET*: results
   * *TARGET*: tripscub

#### gdw23xxbuildtablesfrommroutput.sql

   * *SOURCE*: results
   * *TARGET*: smartride_work_hive_db.wk_centroid_summary
   * *SOURCE*: smartride_work_hive_db.wk_centroid_summary
   * *TARGET*: smartride_canonical_hive_db.centroid_summary

```sql
overwrite partition(*SOURCE*_cd,batch)
```

   * *SOURCE*: tripscrub
   * *TARGET*: smartride_work_hive_db.wk_tripdetail_seconds
   * *SOURCE*: smartride_work_hive_db.wk_tripdetail_seconds
   * *TARGET*: smartride_canonical_hive_db.tripdetail_seconds
```sql
overwrite partition(*SOURCE*_cd,batch) where tds.garbage_flag=0
```

   * *TARGET*: smartride_canonical_hive_db.garbage_tripdetail_seconds
```sql
overwrite partition(*SOURCE*_cd,batch) where tds.garbage_flag=1
```

---

## GDW_SRDP_3301_IMS_TRIPHOURLYDETAIL

**Loads current batch(s) into smartride_canonical_hive_db.trip_details and smartride_canonical_hive_db.hive_sre_hourly**

### Oracle Parameters:

| JOB_CD | PARM_NAME                   | PARM_VALUE                                                                       |
|:-------|:----------------------------|:---------------------------------------------------------------------------------|
| 3301   | location                    | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_hourly_trip_details |
| 3301   | next_job_cd                 | 3302                                                                             |
| 3301   | smartride_canonical_hive_db | SmartRide_Canonical_Hive_DB                                                      |
| 3301   | smartride_work_hive_db      | smartride_work_hive_db                                                           |
| 3301   | source_cd                   | IMS                                                                              |
| 3301   | sql_file_name               | gdw33xxTripHourSummarization.sql                                                 |
| 3301   | sql_logfile_name            | gdw3301HourSummarization                                                         |
| 3301   | wk_hourly_trip_details      | wk_ims_hourly_trip_details                                                       |
| 3301   | wk_trip_details             | wk_ims_trip_details                                                              |
| 3301   | wk_tripdetail_seconds       | wk_ims_tripdetail_seconds                                                        |


### gdw33xxtripsummarizationhive.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw33xxTripSummarizationHive.pl)

#### gdw33xxtriphoursummarization.sql


   * *SOURCE* smartride_work_hive_db.wk_tripdetail_seconds.
   * *TARGET* smartride_work_hive_db.wk_hourly_trip_details
**custom hive udaf used here.**

   * *SOURCE* smartride_work_hive_db.wk_hourly_trip_details
   * *TARGET* smartride_canonical_hive_db.hive_sre_hourly
`overwrite partition(*SOURCE*_cd,batch)`

   * *SOURCE*: smartride_work_hive_db.wk_hourly_trip_details.
   * *TARGET* smartride_work_hive_db.wk_trip_details
**json is created here.**
`overwrite partition(*SOURCE*_cd,batch)`

   * *SOURCE*: smartride_work_hive_db.wk_trip_details
   * *TARGET*: smartride_canonical_hive_db.trip_details
```sql
overwrite partition(SOURCE_cd,batch)
```

---

## GDW_SRDP_3302_IMS_TRIPSUMMARIZATION

**Loads current batch(s) into smartride_canonical_hive_db.hive_sre_summary**

### Oracle Parameters:

| JOB_CD | PARM_NAME                    | PARM_VALUE                                                                    |
|:-------|:-----------------------------|:------------------------------------------------------------------------------|
| 3302   | hive_sre_summary             | hive_sre_summary                                                              |
| 3302   | location1                    | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_trip_details     |
| 3302   | location2                    | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_hive_sre_summary |
| 3302   | next_job_cd                  | 3303                                                                          |
| 3302   | smartride_canonical_hive_db  | SmartRide_Canonical_Hive_DB                                                   |
| 3302   | smartride_reporting_hbase_db | Smartride_Reporting_Hbase_db                                                  |
| 3302   | smartride_work_hive_db       | smartride_work_hive_db                                                        |
| 3302   | source_cd                    | IMS                                                                           |
| 3302   | sql_file_name                | gdw33xxTripSummarization.sql                                                  |
| 3302   | sql_logfile_name             | gdw3302TripSummarization                                                      |
| 3302   | trip_details                 | trip_details                                                                  |
| 3302   | wk_delta_data                | wk_ims_delta_data                                                             |
| 3302   | wk_hive_sre_summary          | wk_ims_hive_sre_summary                                                       |
| 3302   | wk_sre_summary_delta         | wk_ims_sre_summary_delta                                                      |
| 3302   | wk_trip_details              | wk_ims_trip_details                                                           |
| 3302   | wk_trip_details_piid         | wk_ims_trip_details_piid                                                      |
| 3302   | wk_tripdetail_seconds        | wk_ims_tripdetail_seconds                                                     |


### gdw3xxtripsummarization.pl

#### gdw33xxtripsummarization.sql:

**Creates list of piids from last incremental**
   * *SOURCE*: smartride_work_hive_db.wk_trip_details
   * *TARGET*: smartride_work_hive_db.wk_trip_details_piid

   * *SOURCE* smartride_canonical_hive_db.trip_details
   * *SOURCE* smartride_work_hive_db.wk_trip_details_piid
   * *TARGET* smartride_work_hive_db.wk_detla_data  **trips from last incremental**
```sql
INNER JOIN: smartride_work_hive_db.wk_trip_details_piid
```

   * *SOURCE* smartride_work_hive_db.wk_detla_data
   * *TARGET* smartride_work_hive_db.wk_sre_summary_delta in appropriate format

   * *SOURCE*: smartride_canonical_hive_db.hive_sre_summary
   * *SOURCE*: smartride_work_hive_db.wk_sre_summary_delta
   * *TARGET* smartride_work_hive_db.wk_hive_sre_summary **trips missing from last incremental**
```sql
outer join: smartride_work_hive_db.wk_sre_summary_delta
```

   * *SOURCE* smartride_work_hive_db.wk_sre_summary_delta
   * *TARGET* smartride_work_hive_db.wk_hive_sre_summary

   * *SOURCE* smartride_work_hive_db.wk_hive_sre_summary.
   * *TARGET* smartride_canonical_hive_db.hive_sre_summary

---

## GDW_SRDP_3303_IMS_SRE_SUMMARY

**Loads trip data into hbase table**

### Oracle Parameters:

| JOB_CD | PARM_NAME                    | PARM_VALUE                                                                           |
|:-------|:-----------------------------|:-------------------------------------------------------------------------------------|
| 3303   | location1                    | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_sre_summary_delta       |
| 3303   | location3                    | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_ims_hbase_sre_summary_delta |
| 3303   | location_hive_sre_summary    | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_hive_sre_summary            |
| 3303   | next_job_cd                  | 3304                                                                                 |
| 3303   | smartride_canonical_hive_db  | SmartRide_Canonical_Hive_DB                                                          |
| 3303   | smartride_reporting_hbase_db | Smartride_Reporting_Hbase_db                                                         |
| 3303   | smartride_work_hive_db       | smartride_work_hive_db                                                               |
| 3303   | source_cd                    | IMS                                                                                  |
| 3303   | splits                       | 16                                                                                   |
| 3303   | sql_file_name                | gdw33xxSreSummary.sql                                                                |
| 3303   | sql_logfile_name             | gdw3303SreSummary                                                                    |
| 3303   | wk_hbase_sre_summary_delta   | wk_ims_hbase_sre_summary_delta                                                       |
| 3303   | wk_sre_summary_delta         | wk_ims_sre_summary_delta                                                             |


### gdw33xxhbasesresummary.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw33xxHbaseSreSummary.pl)

#### gdw33xxSreSummary.sql

   * *SOURCE*: smartride_work_hive_db.wk_sre_summary_delta
   * *TARGET*: smartride_reporting_hbase_db.SRE_SUMMARY_ext

---

# GDWDBIGI.GDWEXPD-experian

---

## GDW_SRDP_1307_AQB_FILE_TRANSFER

**Processes incoming AQBfiles**

### Oracle Parameters:

| JOB_CD | PARM_NAME                  | PARM_VALUE                     |
|:-------|:---------------------------|:-------------------------------|
| 1307   | experian_canonical_hive_db | experian_canonical_hive_db     |
| 1307   | experian_raw_hive_db       | experian_raw_hive_db           |
| 1307   | experian_work_hive_db      | experian_work_hive_db          |
| 1307   | InputFile                  | AQB_BD_NWI_BIND                |
| 1307   | sql_file_name              | gdw1307ExternalTablePartitions |

---

## GDW_SRDP_1304_EXPN_FILE_TRANSFER

**Process incoming experian files**

### Oracle Parameters:

| JOB_CD | PARM_NAME                   | PARM_VALUE                       |
|:-------|:----------------------------|:---------------------------------|
| 1304   | email_address               | dw-rapid-response@nationwide.com |
| 1304   | InputFile                   | SD-UPR                           |
| 1304   | next_job_cd_EXPNStandardize | 2314                             |
| 1304   | raw_hive_db                 | experian_raw_hive_db             |
| 1304   | sql_file_name               | gdw1304ExternalTablePartitions   |
| 1304   | sql_file_name_cano          | gdw2XXXCanonicalTable            |

### gdw1304EXPNAcquire.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw1304EXPNAcquire.pl)

#### FindEXPNDataSets()

- Identifies files.
- Checks that number of files received matches first record in INDEX file.

```yaml
expn_inbound_dir: /etl03/dropbox/SRDP/EXPN
```

#### RemoveFilesFromWorking()

- Deletes any files that may be remaining in working directory

```yaml
working_dir: /etl03/prod/data/srdp/working
```

#### DataToWorking()

- Copies files from inbound to working

```yaml
expn_inbound_dir: /etl03/dropbox/SRDP/EXPN
working_dir: /etl03/prod/data/srdp/working
```

#### GetSourceAuditCount()

- Insert file record counts into Job_Audit

#### CopyFilesToHadoop()

- Uses curl command and webhdfs rest api

#### RemoveFilesFromWorking()

- Deletes any files that may be remaining in working directory

#### MoveFilesToBackup()

- Also compresses files.

```yaml
expn_inbound_dir: /etl03/dropbox/SRDP/EXPN
backup_dir: /etl03/backup/dropbox
```
```perl
my $src    = "$ProcVars->{expn_inbound_dir}/$file";
my $target = "$ProcVars->{backup_dir}/$file";
LogInfo( $ProcVars, "Moving File: $src $target.tar.gz \n" );
try {
    MoveFile( $ProcVars, $src, $target );
    my $cmd1 = "tar -cvzf $target.tar.gz $target";
    system($cmd1);
    unlink $file;
    unlink $target;

}
```

#### AddExternalPartitions()

- Uses [gdw1304ExternalTablePartitions.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw1304ExternalTablePartitions.sql) to add external partitions.
- Partitioned by:
	- loadevent_id
	- sourcefile_dt (extracted from file names)
	- partnernotificationid (extracted from file names)

---

## GDW_SRDP_2314_EXPN_STANDARDIZE

**Canonical load for EXPN**

### Oracle Parameters:

| JOB_CD | PARM_NAME                                 | PARM_VALUE                                          |
|:-------|:------------------------------------------|:----------------------------------------------------|
| 2314   | drop_and_create_partitioned_cano_wk_table | gdw2314StandardizeExperian_DropRecreate_Step1       |
| 2314   | experian_canonical_hive_db                | experian_canonical_hive_db                          |
| 2314   | experian_raw_hive_db                      | experian_raw_hive_db                                |
| 2314   | experian_work_hive_db                     | experian_work_hive_db                               |
| 2314   | next_job_cd_OrionScore                    | 5312                                                |
| 2314   | source_cd                                 | EXPN                                                |
| 2314   | sql_load_canonical                        | gdw2314StandardizeExperian_CanonicalTableLoad_Step3 |
| 2314   | sql_load_wk_cano_partition                | gdw2314StandardizeExperian_WkTableLoad_Step2        |

### gdw2314EXPNStandardize.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw2314EXPNStandardize.pl)

#### Load()

1. Runs [gdw2314StandardizeExperian_DropRecreate_Step1.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw2314StandardizeExperian_DropRecreate_Step1.sql)
```perl
 @result = $connection1->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{drop_and_create_partitioned_cano_wk_table}.sql", %$ProcVars );
```
	- Drops and recreates:
		- experian_work_hive_db.wk_Vehicle
		- experian_work_hive_db.wk_TripSummary
		- experian_work_hive_db.wk_TripEvent



2. For each loadevent_id runs [gdw2314StandardizeExperian_WkTableLoad_Step2.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw2314StandardizeExperian_WkTableLoad_Step2.sql)

```perl
my $connection3 = new HiveSQLConnection( $ProcVars->{hive_logon_file}, "$ProcVars->{sql_logfile_path}/$ProcVars->{sql_load_wk_cano_partition}_@load_event_id_list[-1].txt" );
```
   * *SOURCE*: ~>experian_raw_hive_db.experian_driving_ext
   * *TARGET*: ~>experian_work_hive_db.wk_Vehicle
```sql
INSERT OVERWRITE TABLE ...
--PARTITION (SourceFile_Dt, PartnerNotification_Id)
.
.
.
WHERE col1 = 'H' AND loadevent=~>loadevent_id
```
   * *SOURCE*: ~>experian_raw_hive_db.experian_driving_ext
   * *TARGET*: ~>experian_work_hive_db.wk_TripSummary
```sql
INSERT OVERWRITE TABLE ...
--PARTITION (SourceFile_Dt, PartnerNotification_Id)
.
.
.
WHERE col1 = 'S' AND loadevent=~>loadevent_id
```

   * *SOURCE*: ~>experian_raw_hive_db.experian_driving_ext
   * *TARGET*: ~>experian_work_hive_db.wk_TripEvent
```sql
INSERT OVERWRITE TABLE ...
--PARTITION (SourceFile_Dt, PartnerNotification_Id)
.
.
.
WHERE col1 = 'D' AND loadevent=~>loadevent_id;
```

3. Runs [gdw2314StandardizeExperian_CanonicalTableLoad_Step3.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw2314StandardizeExperian_CanonicalTableLoad_Step3.sql)

```perl
my $connection4 = new HiveSQLConnection( $ProcVars->{hive_logon_file}, "$ProcVars->{sql_logfile_path}/$ProcVars->{sql_load_canonical}_@load_event_id_list[-1].txt" );
```
```sql
INSERT OVERWRITE TABLE  ~>experian_canonical_hive_db.Vehicle
--PARTITION (sourcefile_dt,partnernotification_id)
PARTITION (sourcefile_dt)
.
.
.
FROM ~>experian_work_hive_db.wk_Vehicle;

INSERT OVERWRITE TABLE  ~>experian_canonical_hive_db.TripSummary
--PARTITION (sourcefile_dt,partnernotification_id)
PARTITION (sourcefile_dt)
.
.
.
FROM  ~>experian_work_hive_db.wk_TripSummary;

INSERT OVERWRITE TABLE  ~>experian_canonical_hive_db.TripEvent
--PARTITION (sourcefile_dt,partnernotification_id)
PARTITION (sourcefile_dt)
.
.
.
FROM ~>experian_work_hive_db.wk_TripEvent;
```

---

## GDW_SRDP_5312_EXPN_PROVIDE_SCORE

**Calculates score and transfers file via ftp**

### Oracle Parameters:

| JOB_CD | PARM_NAME                      | PARM_VALUE                                                                       |
|:-------|:-------------------------------|:---------------------------------------------------------------------------------|
| 5312   | aqb_conn_file                  | .aqb_connection                                                                  |
| 5312   | aqb_file_directory             | /Out/igdwexp2                                                                    |
| 5312   | experian_canonical_hive_db     | experian_canonical_hive_db                                                       |
| 5312   | experian_raw_hive_db           | experian_raw_hive_db                                                             |
| 5312   | experian_reporting_hive_db     | experian_reporting_hive_db                                                       |
| 5312   | experian_work_hive_db          | experian_work_hive_db                                                            |
| 5312   | expn_conn_file                 | .experian_connection                                                             |
| 5312   | expn_file_directory            | /FromNationwide/egdwexpn                                                         |
| 5312   | ftp_aqb_filename               | NWI_BD_AQB_Rated                                                                 |
| 5312   | ftp_expn_filename              | RatedRecord_11_Nationwide                                                        |
| 5312   | hdfs_score_aqb_file_directory  | /apps/hive/warehouse/experian_work_hive_db.db/wk_nwi_bd_aqb_rated/sourcefile_dt= |
| 5312   | hdfs_score_expn_file_directory | /apps/hive/warehouse/experian_work_hive_db.db/wk_ratedrecord_11_nationwide       |
| 5312   | hive_merge_size_per_task       | 209715200                                                                        |
| 5312   | hive_merge_smallfiles_avgsize  | 10737418240                                                                      |
| 5312   | mapred_max_split_size          | 68157440                                                                         |
| 5312   | mapred_min_split_size          | 68157440                                                                         |
| 5312   | sql_file_name                  | gdw5312ScoreEXPN                                                                 |
| 5312   | time_out                       | 10000                                                                            |


### gdw5312ScoreEXPN.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw5312ScoreEXPN.pl)

#### CalculateOrionScore()

- Runs [gdw5312ScoreEXPN.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw5312ScoreEXPN.sql) to calculate score.
```perl
@result = $connection->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{sql_file_name}.sql", %$ProcVars );
```
**TODO More detail about sql steps**
- Contains a bunch of sql to create ratedrecord_11_nationwide and nwi_bd_aqb_rated files

#### FtpAQBScoreFile()

- Uses curl and webhdfs rest api to download file from hdfs.
- FTP downloaded file to /Out/igdwexp2/NWI_BD_AQB_Rated_20170720.csv on server tower.nwie.net

#### FtpEXPNScoreFile()

- Uses curl and webhdfs rest api to download file from hdfs.
- FTP downloaded file to /FromNationwide/egdwexpn/RatedRecord_11_Nationwide_20170720_164042.csv on server tower.nwie.net

---

# GDWDBIGI.GDWSRD01-SmartRideDaily

---

## GDW_SRDP_1303_SMT_ODS_BIGIN_PGM_INSTNC_DLY
  RUN DAILY
  DELAYSUB 18:05

**Retrievs ProgramInstance data from ODS**

### Oracle Parameters:

| JOB_CD | PARM_NAME                    | PARM_VALUE                                                                        |
|:-------|:-----------------------------|:----------------------------------------------------------------------------------|
| 1303   | location1                    | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_smt_ods_bigin_pgm_instnc |
| 1303   | smartride_canonical_hive_db  | smartride_canonical_hive_db                                                       |
| 1303   | smartride_work_hive_db       | smartride_work_hive_db                                                            |
| 1303   | sql_file_name_ods            | gdw1303SmtOdsPgmInstanceAcquire                                                   |
| 1303   | sql_file_name_retry          | gdw1303SmtOdsPgmInstanceAcquireRetry                                              |
| 1303   | sql_file_name_wk             | gdw1303WkSmtOdsPgmInstanceAcquire                                                 |
| 1303   | sqoop_db_driver              | com.ibm.db2.jcc.DB2Driver                                                         |
| 1303   | sqoop_db_schema              | NW_DBG2                                                                           |
| 1303   | sqoop_db_table_or_query      | DBSMTNR.VSMTO003                                                                  |
| 1303   | sqoop_db_table_or_query_flag | table                                                                             |
| 1303   | sqoop_libdir                 | /iop/apps/4.1.0.0/sqoop/                                                          |
| 1303   | sqoop_maps                   | 1                                                                                 |
| 1303   | sqoop_op                     | import                                                                            |
| 1303   | sqoop_status_output_file     | sqoop.output                                                                      |
| 1303   | sqoop_target_dir             | /Programs/SmartRide/ODS/DB2view                                                   |
| 1303   | srdp_support_email           | DW-RAPID-RESPONSE,NI-DATAWH-PERSONAL-LINES-SRDP-team.email                        |

### gdw1303SmtOdsPgmInstanceAcquire.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw1303SmtOdsPgmInstanceAcquire.pl)

#### HadoopRemoteExecSqoopJob()

- Sqoops from table DBSMTNR.VSMTO003 on dg0b.gmed.ent.nwie.net:2448/NW_DBG2 to /Programs/SmartRide/ODS/DB2view

```perl
HadoopRemoteExecSqoopJob( \%ProcVars, %ProcVars->{sqoop_op}, %ProcVars->{sqoop_db_driver}, %ProcVars->{db2_logon_file}, %ProcVars->{sqoop_db_schema}, %ProcVars->{hadoop_logon_file}, %ProcVars->{sqoop_target_dir}, %ProcVars->{sqoop_db_table_or_query_flag}, %ProcVars->{sqoop_db_table_or_query}, %ProcVars->{sqoop_maps}, 10000 );
```

#### LoadODSWorkTableAndValidate()

- Runs [gdw1303WkSmtOdsPgmInstanceAcquire.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw1303WkSmtOdsPgmInstanceAcquire.sql)

```perl
@result = $connection->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{sql_file_name_wk}.sql", %$ProcVars );
```

```sql
load data inpath '/Programs/SmartRide/ODS/DB2view/part*' OVERWRITE INTO TABLE smartride_work_hive_db.wk_SMT_ODS_BIGIN_step1_temp PARTITION (source_cd = 'ODS');
.
.
.
CREATE  TABLE ~>smartride_canonical_hive_db.SMT_ODS_BIGIN_step1
as
select
.
.
.
 from ~>smartride_work_hive_db.wk_SMT_ODS_BIGIN_step1_temp;
```

#### LoadBiginODSTableAndValidate()

- Runs [gdw1303SmtOdsPgmInstanceAcquire.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw1303SmtOdsPgmInstanceAcquire.sql) to reload smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC and smartride_work_hive_db.WK_SMT_ODS_LKP.

```perl
@result = $connection->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{sql_file_name_ods}.sql", %$ProcVars );
```

```sql
INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC_OLD
PARTITION (source_cd)
.
.
.
FROM ~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC;

FROM  ~>smartride_canonical_hive_db.SMT_ODS_BIGIN_step1
INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC
PARTITION (source_cd)
.
.
.;

CREATE TABLE ~>smartride_work_hive_db.WK_SMT_ODS_LKP
AS
SELECT
.
.
.
FROM
~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC
WHERE dev_id_nbr is not null;

```

---

## LINUX_JOB GDW_SRDP_3309_ORPHAN
  RUN DAILY

### Oracle Parameters:

| JOB_CD | PARM_NAME                      | PARM_VALUE                                                             |
|:-------|:-------------------------------|:-----------------------------------------------------------------------|
| 3309   | sql_logfile_name               | gdw33xxSreDaily                                                        |
| 3309   | sql_file_name                  | gdw33xxSreDaily.sql                                                    |
| 3309   | smartride_work_hive_db         | smartride_work_hive_db                                                 |
| 3309   | smartride_canonical_hive_db    | SmartRide_Canonical_Hive_DB                                            |
| 3309   | orphan_reprocess_sql_file_name | gdw33xxOrphanReprocess                                                 |
| 3309   | location_wk_non_orphan_pid     | /biginsights/hive/warehouse/smartride_work_hive_db.db/wk_nonorphan_pid |


### gdw33xxSreDaily.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw33xxSreDaily.pl)

#### ReprocessOrpahns()

- Runs [gdw33xxOrphanReprocess.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw33xxOrphanReprocess.sql)

```perl
@result = $connection->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{orphan_reprocess_sql_file_name}.sql", %$ProcVars );
```

```sql
DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_distinct_piid;
create table ~>smartride_work_hive_db.wk_distinct_piid as select distinct vhcl_id_nbr, dev_id_nbr from ~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC where vhcl_id_nbr is not null and dev_id_nbr is not null;

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.orphan_piid_loj_ods PARTITION (source_cd)
Select
.
.
.
from
~>smartride_canonical_hive_db.orphan_ts op
LEFT OUTER JOIN
~>smartride_work_hive_db.wk_distinct_piid dp
on
op.enrolledvin_nb = dp.vhcl_id_nbr
and
op.deviceserial_nb = dp.dev_id_nbr;

use ~>smartride_canonical_hive_db;
ALTER TABLE orphan_ts  DROP IF EXISTS PARTITION (source_cd = 'IMS');
ALTER TABLE orphan_ts  DROP IF EXISTS PARTITION (source_cd = 'OCTO');

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.non_orphan_batches_trip_summary PARTITION (source_cd)
SELECT DISTINCT loadevent_id, BATCH, source_cd
FROM ~>smartride_canonical_hive_db.orphan_piid_loj_ods
where vhcl_id_nbr is not null and dev_id_nbr is not null;

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.orphan_ts PARTITION (source_cd,batch)
SELECT
.
.
.
FROM ~>smartride_canonical_hive_db.orphan_piid_loj_ods
where  vhcl_id_nbr is null and dev_id_nbr is null;

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.non_orphan_batches_trip_point PARTITION (source_cd)
Select * from ~>smartride_canonical_hive_db.non_orphan_batches_trip_summary;
```

---

## GDW_SRDP_2309_IMS_AUDIT_ENHANCE
  RUN DAILY

**Various auditing done for informational purposes.**

### Oracle Parameters:

| JOB_CD | PARM_NAME                      | PARM_VALUE                                                                        |
|:-------|:-------------------------------|:----------------------------------------------------------------------------------|
| 2309   | audit_bal_tripcumu_tripsumm    | audit_bal_tripcumu_tripsumm                                                       |
| 2309   | location1                      | /apps/hive/warehouse/smartride_work_hive_db.db/wk_ims_audit_bal_tripcumu_tripsumm |
| 2309   | smartride_canonical_hive_db    | SmartRide_Canonical_Hive_DB                                                       |
| 2309   | smartride_work_hive_db         | smartride_work_hive_db                                                            |
| 2309   | sql_file_name                  | gdw23xxAuditTripBalancing.sql                                                     |
| 2309   | sql_logfile_name               | gdw2309AuditTripBalancing                                                         |
| 2309   | sql_tripthreshold_logfile_name | gdw2309AuditTripThreshold                                                         |
| 2309   | tripcumlulative_audit_prev     | ims_tripcumlulative_audit_prev                                                    |
| 2309   | tripsummary_ext                | smartride_raw_hive_db.ims_tripsummary_ext                                         |
| 2309   | wk_audit_bal_tripcumu_tripsumm | wk_ims_audit_bal_tripcumu_tripsumm                                                |
| 2309   | wk_audit_tripcumulative        | wk_ims_audit_tripcumulative                                                       |
| 2309   | wk_tripcumlulative_audit_curr  | wk_ims_tripcumlulative_audit_curr                                                 |

### gdw23xxAudit.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw23xxAudit.pl)

---

## GDW_SRDP_2310_OCTO_AUDIT_ENHANCE
  RUN DAILY

**Various auditing done for informational purposes.**

### Oracle Parameters:

| JOB_CD | PARM_NAME                      | PARM_VALUE                                                                         |
|:-------|:-------------------------------|:-----------------------------------------------------------------------------------|
| 2310   | audit_bal_tripcumu_tripsumm    | audit_bal_tripcumu_tripsumm                                                        |
| 2310   | location1                      | /apps/hive/warehouse/smartride_work_hive_db.db/wk_octo_audit_bal_tripcumu_tripsumm |
| 2310   | smartride_canonical_hive_db    | SmartRide_Canonical_Hive_DB                                                        |
| 2310   | smartride_work_hive_db         | smartride_work_hive_db                                                             |
| 2310   | sql_file_name                  | gdw23xxAuditTripBalancing.sql                                                      |
| 2310   | sql_logfile_name               | gdw2310AuditTripBalancing                                                          |
| 2310   | sql_tripthreshold_logfile_name | gdw2310AuditTripThreshold                                                          |
| 2310   | tripcumlulative_audit_prev     | octo_tripcumlulative_audit_prev                                                    |
| 2310   | tripsummary_ext                | smartride_raw_hive_db.octo_tripsummary_ext                                         |
| 2310   | wk_audit_bal_tripcumu_tripsumm | wk_octo_audit_bal_tripcumu_tripsumm                                                |
| 2310   | wk_audit_tripcumulative        | wk_octo_audit_tripcumulative                                                       |
| 2310   | wk_tripcumlulative_audit_curr  | wk_octo_tripcumlulative_audit_curr                                                 |


### gdw23xxAudit.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw23xxAudit.pl)

---

## GDW_SRDP_3313_DEVICE_STATUS
  RUN DAILY
  DELAYSUB 04:00

**Steps to determine telematics device status.**

### Oracle Parameters:

| JOB_CD | PARM_NAME                   | PARM_VALUE                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|:-------|:----------------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 3313   | map_reduce_driver_name      | com.nationwide.smartride.scoring.devicestatus.DeviceStatusMain -D mapreduce.reduce.java.opts=-Djava.util.Arrays.useLegacyMergeSort=true -D mapred.reduce.tasks=150                                                                                                                                                                                                                                                                                               |
| 3313   | map_reduce_input_file       | apps/hive/warehouse/smartride_canonical_hive_db.db/tsp_tripsummary/source_cd=IMS/batch=*,/apps/hive/warehouse/smartride_canonical_hive_db.db/tsp_tripsummary/source_cd=OCTO/batch=*,/apps/hive/warehouse/smartride_canonical_hive_db.db/tsp_tripevent/source_cd=IMS/batch=*,/apps/hive/warehouse/smartride_canonical_hive_db.db/tsp_tripevent/source_cd=OCTO/batch=*,/apps/hive/warehouse/smartride_canonical_hive_db.db/smt_ods_bigin_pgm_instnc/source_cd=ODS/ |
| 3313   | map_reduce_input_path       | /                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| 3313   | map_reduce_jar_name         | mapReduce-0.0.1-SNAPSHOT.jar                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 3313   | map_reduce_output_file      | devicestatus                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| 3313   | map_reduce_output_path      | /Programs/SmartRide/TEMP/devicestatus/                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 3313   | smartride_canonical_hive_db | SmartRide_Canonical_Hive_DB                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| 3313   | smartride_work_hive_db      | smartride_work_hive_db                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 3313   | sql_file_name               | gdw33xxDeviceStatus.sql                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| 3313   | sql_logfile_name            | gdw33xxDeviceStatus                                                                                                                                                                                                                                                                                                                                                                                                                                              |

### gdw33xxDeviceStatus.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw33xxDeviceStatus.pl)

#### HadoopRemoteExecMapReduceJob()

- Executes map reduce jobs which creates device status records

```perl
HadoopRemoteExecMapReduceJob( \%ProcVars, %ProcVars->{hadoop_logon_file}, %ProcVars->{map_reduce_jar_path}, %ProcVars->{map_reduce_jar_name}, %ProcVars->{map_reduce_driver_name}, %ProcVars->{map_reduce_input_path}, %ProcVars->{map_reduce_input_file}, %ProcVars->{map_reduce_output_path}, %ProcVars->{map_reduce_output_file} );
```

#### LoadDeviceStatus()

- Loads device status records into hive table and derives percentage installed using [gdw33xxDeviceStatus.sql]()

```perl
@result = $connection->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{sql_file_name}", %$ProcVars );
```

```sql
DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_devicestatus;

CREATE TABLE ~>smartride_work_hive_db.wk_devicestatus(
.
.
.;

load data inpath '~>map_reduce_output_path~>map_reduce_output_file/part*' OVERWRITE INTO TABLE ~>smartride_work_hive_db.wk_devicestatus;

drop table if exists  ~>smartride_canonical_hive_db.devicestatus;

create table ~>smartride_canonical_hive_db.devicestatus as
select
.
.
.
from ~>smartride_work_hive_db.wk_devicestatus;

DROP TABLE IF EXISTS ~>smartride_canonical_hive_db.device_install_pcnt;

CREATE  TABLE ~>smartride_canonical_hive_db.DEVICE_INSTALL_PCNT AS
SELECT
.
.
.
FROM ~>smartride_canonical_hive_db.DEVICESTATUS D WHERE sr_pgm_instnc_id <> -1
.
.
.;
```

---

## GDW_SRDP_5310_DAILY_SCORE
  RUN DAILY

**Creates score and transmits via ftp to the mainframe (ODS)

### Oracle Parameters:

| JOB_CD | PARM_NAME                     | PARM_VALUE                                                                        |
|:-------|:------------------------------|:----------------------------------------------------------------------------------|
| 5310   | area                          | SRDP001                                                                           |
| 5310   | ftp_file_length               | 400                                                                               |
| 5310   | ftp_filename                  | SCRVNDVB.DWBI                                                                     |
| 5310   | hdfs_score_file_directory     | /apps/hive/warehouse/smartride_work_hive_db.db/wk_sre_scoring_daily_file/000000_0 |
| 5310   | hive_merge_size_per_task      | 209715200                                                                         |
| 5310   | hive_merge_smallfiles_avgsize | 10737418240                                                                       |
| 5310   | mapred_max_split_size         | 68157440                                                                          |
| 5310   | mapred_min_split_size         | 68157440                                                                          |
| 5310   | smartride_canonical_database  | SmartRide_Canonical_Hive_DB                                                       |
| 5310   | smartride_canonical_hive_db   | smartride_canonical_hive_db                                                       |
| 5310   | smartride_work_hive_db        | smartride_work_hive_db                                                            |
| 5310   | sql_file_name                 | gdw5310Scoring.sql                                                                |
| 5310   | sql_logfile_name              | gdw5310ScoringDaily                                                               |

### gdw5310ScoringDaily.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw5310ScoringDaily.pl)

#### RunDaily()

- Runs [gdw5310Scoring.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw5310Scoring.sql) to derive score.

```perl
@result = $connection->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{sql_file_name}", %$ProcVars );
```

```sql
drop table if exists ~>smartride_work_hive_db.wk_daily_record;
create table  ~>smartride_work_hive_db.wk_daily_record
as select
.
.
.
from  ~>smartride_canonical_hive_db.hive_sre_hourly
where plcy_ratd_st_cd <> 'CA' ;

drop table if exists ~>smartride_work_hive_db.wk_sre_scoring_daily;
create table  ~>smartride_work_hive_db.wk_sre_scoring_daily
as
select
.
.
.
from smartride_canonical_hive_db.device_install_pcnt device
left join
smartride_work_hive_db.wk_daily_record trip
on device.sr_pgm_instnc_id = trip.sr_pgm_instnc_id
and device.deviceserial_id = trip.deviceserial_nb
and device.enrolledvin_nb = trip.enrolledvin_nb
where device.sr_pgm_instnc_id is not null
and device.sr_pgm_instnc_id != -1
and case when trip.plcy_ratd_st_cd is null then 'Null State' else trip.plcy_ratd_st_cd  end  <> 'CA';

from ~>smartride_work_hive_db.wk_sre_scoring_daily
Insert overwrite table ~>smartride_canonical_hive_db.hive_sre_scoring partition(score_date);

drop table if exists ~>smartride_work_hive_db.wk_sre_scoring_daily_file;

create table ~>smartride_work_hive_db.wk_sre_scoring_daily_file as
Select
.
.
.
from ~>smartride_work_hive_db.wk_sre_scoring_daily;
```

#### FtpScoreFile()

- Retrieves score file from hdfs

```perl
HadoopDownload( $ProcVars, $target_dir, $ProcVars->{hdfs_score_file_directory} );
```

- Uses shell script to ftp file to GM1.ENT.NWIE.NET in directory DWCI.SRP and file SCRVNDVB.DWBI

```perl
my $Cmd_ftp_file_from_appl_server_to_mainframe = "sh \$bin/Galaxy_FTP_Mainframe.ksh $ProcVars->{working_dir} $ProcVars->{ftp_dir_name} $ProcVars->{ftp_filename} $ProcVars->{ftp_file_length} NULL NULL TAPENO $ProcVars->{area} 2>&1 && echo COMMAND_SUCCESS || echo COMMAND_FAILURE 2>&1";
```

---

## GDW_SRDP_5311_ANNUAL_MILEAGE
  RUN DAILY

**Calculates annual milage and transmits file to mainframe via ftp**

### Oracle Paramaters:

| JOB_CD | PARM_NAME                     | PARM_VALUE                                                                                                                          |
|:-------|:------------------------------|:------------------------------------------------------------------------------------------------------------------------------------|
| 5311   | area                          | SRDP001                                                                                                                             |
| 5311   | ftp_file_length               | 253                                                                                                                                 |
| 5311   | ftp_filename                  | SCRVNDVB.DW                                                                                                                         |
| 5311   | hdfs_score_file_directory     | /apps/hive/warehouse/smartride_work_hive_db.db/wk_ca_annual_mileage_score_file/000000_0                                             |
| 5311   | hive_merge_size_per_task      | 209715200                                                                                                                           |
| 5311   | hive_merge_smallfiles_avgsize | 10737418240                                                                                                                         |
| 5311   | mapred_max_split_size         | 68157440                                                                                                                            |
| 5311   | mapred_min_split_size         | 68157440                                                                                                                            |
| 5311   | smartride_canonical_database  | SmartRide_Canonical_Hive_DB                                                                                                         |
| 5311   | smartride_canonical_hive_db   | smartride_canonical_hive_db                                                                                                         |
| 5311   | smartride_raw_hive_db         | smartride_raw_hive_db                                                                                                               |
| 5311   | smartride_work_hive_db        | smartride_work_hive_db                                                                                                              |
| 5311   | sql_file_name                 | gdw5311AnnualMileage                                                                                                                |
| 5311   | sqoop_db_driver               | com.teradata.jdbc.TeraDriver                                                                                                        |
| 5311   | sqoop_db_schema               | STG_NIMS_DB                                                                                                                         |
| 5311   | sqoop_db_table_or_query       | 'SELECT Policy_Id, InsuredItem_Id, VehicleIdentification_Nb, Effective_Dt FROM STG_NIMS_DB.WK2_ACTIVE_RE_ENROLLS where $CONDITIONS' |
| 5311   | sqoop_db_table_or_query_flag  | query                                                                                                                               |
| 5311   | sqoop_maps                    | 1                                                                                                                                   |
| 5311   | sqoop_op                      | import                                                                                                                              |
| 5311   | sqoop_target_dir              | /user/srdpdevl/eprod_active_re_enrolls                                                                                              |
| 5311   | time_out                      | 10000                                                                                                                               |

### gdw5311AnnualMileage.pl [link](https://github.nwie.net/Nationwide/srdp-perl/blob/master/bin/gdw5311AnnualMileage.pl)

#### CalculateCAAnnualMileage()

- Runs [gdw5311AnnualMileage.sql](https://github.nwie.net/Nationwide/srdp-perl/blob/master/sql/gdw5311AnnualMileage.sql) to calculate the score.

```perl
@result = $connection->runQueryFromFile( "$ProcVars->{sql_dir}/$ProcVars->{sql_file_name}.sql", %$ProcVars );
```

```sql
DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_hive_sre_daily;

CREATE TABLE ~>smartride_work_hive_db.wk_hive_sre_daily AS
  SELECT sr_pgm_instnc_id,
  .
  .
  .
    FROM   ~>smartride_canonical_hive_db.hive_sre_hourly
  WHERE  source_cd = 'IMS' ;

DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_device_vin;

CREATE TABLE ~>smartride_work_hive_db.wk_device_vin AS
  SELECT DISTINCT sr_pgm_instnc_id
  .
  .
  .
  FROM   ~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC;

DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_device_install_pcnt;

CREATE TABLE ~>smartride_work_hive_db.wk_device_install_pcnt AS
  SELECT
  .
  .
  .
  FROM   ~>smartride_canonical_hive_db.device_install_pcnt dip
         INNER JOIN ~>smartride_work_hive_db.wk_device_vin cdv
                 ON dip.sr_pgm_instnc_id = cdv.sr_pgm_instnc_id
                    AND dip.deviceserial_id = cdv.dev_id_nbr
                    AND dip.enrolledvin_nb = cdv.vhcl_id_nbr;

DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_device_active_days;

create table ~>smartride_work_hive_db.wk_device_active_days as
SELECT
.
.
.
FROM   ~>smartride_work_hive_db.wk_device_install_pcnt dip
JOIN   default.days d
where  d.day_id <= total_days ;

DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_annual_mileage;

CREATE TABLE ~>smartride_work_hive_db.wk_annual_mileage AS
SELECT
.
.
.
FROM
~>smartride_work_hive_db.wk_device_active_days dad
LEFT OUTER JOIN
~>smartride_work_hive_db.wk_hive_sre_daily hsd
ON dad.sr_pgm_instnc_id = hsd.sr_pgm_instnc_id
AND dad.DeviceSerial_Id = hsd.deviceserial_nb
AND dad.EnrolledVIN_Nb = hsd.enrolledvin_nb
AND dad.Trip_Dt = hsd.trip_date;

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.annual_mileage partition (load_date)
Select
.
.
.
From
~>smartride_work_hive_db.wk_annual_mileage;

DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_ca_annual_mileage_score;

create table ~>smartride_work_hive_db.wk_ca_annual_mileage_score as
select
.
.
.
from ~>smartride_work_hive_db.wk_annual_mileage where plcy_ratd_st_cd = 'CA';

DROP TABLE IF EXISTS ~>smartride_work_hive_db.wk_ca_annual_mileage_score_file;

create table ~>smartride_work_hive_db.wk_ca_annual_mileage_score_file as
.
.
.
from smartride_work_hive_db.wk_ca_annual_mileage_score;

Insert overwrite table ~>smartride_canonical_hive_db.annual_mileage_score partition(score_date)
Select
.
.
.
from ~>smartride_work_hive_db.wk_ca_annual_mileage_score;
```

#### FtpScoreFile()

- Uses shell script to ftp file to GM1.ENT.NWIE.NET in directory DWCI.SRP and file SCRVNDVB.DWBI

```perl
my $Cmd_ftp_file_from_appl_server_to_mainframe = "sh \$bin/Galaxy_FTP_Mainframe.ksh $ProcVars->{working_dir} $ProcVars->{ftp_dir_name} $ProcVars->{ftp_filename} $ProcVars->{ftp_file_length} NULL NULL TAPENO $ProcVars->{area} 2>&1 && echo COMMAND_SUCCESS || echo COMMAND_FAILURE 2>&1";
```
