INSERT INTO difcontrolmaster.JOB_DETAIL
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('5310', 'SRE Scoring Daily', 'D001', 1000000004, 'A', 'gdw5310ScoringDaily.pl', NULL, NULL, 'NONE ');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'srdp_score_table_name', 'smartride_scoring_daily_file');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'srdp_score_file_name', '000000_0');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'smdp_score_table_name', 'smartmiles_daily_scoring_export');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'smdp_score_file_name', '000000_0');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'Score_file_SmartMiles', 'SmartMilesScores.dat');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'Score_file_SmartRide', 'SmartRideScores.dat');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'area', 'SRDP001');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'ftp_file_length', '400');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'ftp_filename', 'SCRVNDVB.DWBI');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'hive_merge_size_per_task', '209715200');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'hive_merge_smallfiles_avgsize', '10737418240');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'mapred_max_split_size', '68157440');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'mapred_min_split_size', '68157440');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'sql_file_name', 'gdwSmartRideDailyScoring.sql');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'jdbc_server', 'telematics-smartride-daily-dev.aws.e1.nwie.net');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'jdbc_port', '9001');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'hive_logon_file', '/vol/dif/srdp/priv/.hive_connection_smartride_daily');

INSERT INTO job_parm
(job_cd, parm_name, parm_value)
VALUES('5310', 's3_bucket_name', 'dw-telematics-dev');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'hadoop_logon_file', '/vol/dif/srdp/priv/.hadoop_connection_smartride_daily');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'skip_ftp', 'TRUE');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'skip_smls_logic', 'TRUE');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'aconfig', '/vol/dif/srdp/priv');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'working_dir', '/vol/dif/srdp/data/working');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5310', 'ftp_dir_name', 'T410.DWCI.SRP');
