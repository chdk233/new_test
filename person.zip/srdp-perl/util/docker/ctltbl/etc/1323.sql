Insert into difcontrolmaster.JOB_DETAIL (JOB_CD,JOB_DESCR,FREQUENCY_CD,ASSET_ID,JOB_EFF_STATUS,SCRIPT_NAME,FOLDER_NAME,WORKFLOW_NAME,SOURCE_CD) 
values ('1323','Acquire job for Connected Car vendors like CCC, Verisk, etc.','D001','1000000004','A','gdwCommonAcquire.pl',NULL,NULL, 'CCC');

insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1323', 's3_bucket_name', 'dw-telematics-dev');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1323', 'staging_database', 'telematics_staging_db');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1323', 'staging_table', 'connected_car_summary');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1323', 'inbound_file_pattern', '^connectedCarDWExtract');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1323', 'inbound_dir', '/mnt/efs/dropbox/CCAR');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1323', 'regex_date_pattern', '(\d{8})'); 