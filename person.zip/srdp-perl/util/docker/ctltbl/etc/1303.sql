INSERT INTO difcontrolmaster.job_detail
(job_cd, job_descr, frequency_cd, asset_id, job_eff_status, script_name, folder_name, workflow_name, source_cd)
VALUES('1303', 'Acquire for ODS program instance id', 'D001', 1000000004, 'A', 'gdw1303SmtOdsPgmInstanceAcquire.pl', NULL, NULL, 'ODS  ');


INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'hadoop_logon_file', '/vol/dif/srdp/priv/.hadoop_connection_smartride_daily');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'db2_logon_file', '/vol/dif/srdp/priv/.db2_connection');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sql_load_ods', 'gdwSmartRideAcquireODS.sql');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sqoop_db_driver', 'com.ibm.db2.jcc.DB2Driver');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sqoop_db_schema', 'NW_DBT1:''specialRegisters=CURRENT QUERY ACCELERATION=ELIGIBLE;''');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sqoop_db_table_or_query', 'DBSMTC1.VSMTO003');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'skip_kerberos_initialization', 'TRUE');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sqoop_db_table_or_query_flag', 'table');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'jdbc_server', 'telematics-smartride-daily-dev.aws.e1.nwie.net');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sqoop_maps', '1');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sqoop_op', 'import');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'sqoop_target_dir', '/user/hive/sqoop-output');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'srdp_support_email', 'smirnoe1@nationwide.com, roberd7@nationwide.com');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'jdbc_port', '9001');
INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1303', 'hive_logon_file', '/vol/dif/srdp/priv/.hive_connection_smartride_daily');
