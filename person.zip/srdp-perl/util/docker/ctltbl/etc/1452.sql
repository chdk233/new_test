insert into  difcontrolmaster.asset (ASSET_ID, DESCRIPTION, PROCESS_SUPPORT_EMAIL)
values (1000000004, 'SmartRideProgram',            'NI-DATAWH-PERSONAL-LINES-SRDP-team.email') ;


insert into difcontrolmaster.job_detail (JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
values ('1452',    'TrueMotion - Move file from dropbox to Hadoop', 'D001', 1000000004, 'A', 'gdwTrueMotionAcquire.pl', null, null, 'TRMTN');


insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1452', 's3_bucket_name', 'dw-telematics-dev');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1452', 'staging_database', 'telematics_staging_db');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1452', 'staging_table', 'truemotion');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) values ('1452', 'inbound_dir', '/mnt/efs/dropbox/TRMT');