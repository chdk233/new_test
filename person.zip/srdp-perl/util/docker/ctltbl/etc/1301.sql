

INSERT INTO difcontrolmaster.job_detail
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('1301', 'Acquire for SmartRide IMS', 'H001', 1000000004, 'A', 'gdwSmartRideAcquireIMS.pl', NULL, NULL, 'NIMS ');


INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 'InputFile1', 'IMS_N');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 'InputFile2', 'END');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 'srdp_support_email', 'NWLine-Agility@nationwide.com');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 'next_job_cd_IMSTripsAuditThreshold', '2309');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 'next_job_cd_IMSaudit', '2300');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 'inbound_dir', '/mnt/efs/dropbox/SRDP/NIMS_HF');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 'working_dir', '/vol/dif/srdp/data');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1301', 's3_bucket_name', 'dw-telematics-dev');