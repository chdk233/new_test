INSERT INTO difcontrolmaster.job_detail
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('2314', 'Standardize job for Experian', 'D001', 1000000004, 'A', 'gdwExperianStandardize.pl', NULL, NULL, 'EXPN ');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'standardize_sql', 'gdwExperianStandardize.sql');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'next_job_cd', '5312');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'work_db', 'telematics_work_db');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'staging_db', 'telematics_staging_db');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'foundation_db', 'telematics_db');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'jdbc_server', 'telematics-emr-dev.aws.e1.nwie.net');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'jdbc_port', '9001');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('2314', 'hive_logon_file', '/vol/dif/srdp/priv/.hive_connection_experian');

