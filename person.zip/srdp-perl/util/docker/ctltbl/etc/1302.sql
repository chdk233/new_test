

INSERT INTO difcontrolmaster.job_detail
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('1302', 'Acquire for SmartRide OCTO', 'H008', 1000000004, 'A', 'gdwSmartRideAcquireOCTO.pl', NULL, NULL, 'NOCT ');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 'InputFile1', 'OCTO_NWI');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 'InputFile2', 'csv');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 'next_job_cd_OCTOTripsAuditThreshold', '2310');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 'next_job_cd_OCTOaudit', '2313');
INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 'srdp_support_email', 'DW-RAPID-RESPONSE@nationwide.com');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 'inbound_dir', '/mnt/efs/dropbox/SRDP/NOCT_HF');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 'working_dir', '/vol/dif/srdp/data');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1302', 's3_bucket_name', 'dw-telematics-dev');