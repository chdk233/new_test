INSERT INTO difcontrolmaster.JOB_DETAIL
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('1307', 'Acquire job for AQB', 'D001', 1000000004, 'A', 'gdw1307_EXPN_AQB_Acquire.pl', NULL, NULL, 'AQB  ');

INSERT INTO difcontrolmaster.JOB_PARM (JOB_CD, PARM_NAME, PARM_VALUE) VALUES('1307', 'InputFile', 'AQB_BD_NWI_BIND');
INSERT INTO difcontrolmaster.JOB_PARM (JOB_CD, PARM_NAME, PARM_VALUE) VALUES('1307', 'staging_database', 'telematics_staging_db');
INSERT INTO difcontrolmaster.JOB_PARM (JOB_CD, PARM_NAME, PARM_VALUE) VALUES('1307', 'staging_table', 'experian_auto_quote_bind_policy');
INSERT INTO difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) VALUES('1307', 'inbound_dir', '/mnt/efs/dropbox/EXPN');
INSERT INTO difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) VALUES('1307', 'working_dir', '/vol/dif/srdp/data');
INSERT INTO difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) VALUES('1307', 'regex_date_pattern', '(\d{8})');
insert into difcontrolmaster.job_parm (JOB_CD, PARM_NAME, PARM_VALUE) VALUES('1307', 's3_bucket_name', 'dw-telematics-dev');
