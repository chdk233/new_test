INSERT INTO difcontrolmaster.job_detail
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('1304', 'Acquire job for Experian', 'D001', 1000000004, 'A', 'gdw1304ExperianAcquire.pl', NULL, NULL, 'EXPN ');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1304', 'inbound_dir', '/mnt/efs/dropbox/EXPN');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1304', 'working_dir', '/vol/dif/srdp/data');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1304', 'staging_database', 'telematics_staging_db');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1304', 'staging_table', 'experian_driving');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1304', 's3_bucket_name', 'dw-telematics-dev');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1304', 'next_job_cd', '2314');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1304', 'file_filter_regex', 'SD-UPR-\d{8}-.*zip');

INSERT INTO difcontrolmaster."owner"
(owner_id, support_group, support_email, support_phone, secondary_email, secondary_phone)
VALUES(1, 'Agility', 'roberd7@nationwide.com', NULL, NULL, NULL);

INSERT INTO difcontrolmaster."location"
(LOCATION_ID, SERVER_NAME, SERVER_TYPE, USER_NAME, CONNECTION_FILE_NAME, DESCRIPTION, CONNECTION_PARM)
VALUES(0, 'LOCAL', 'linux', 'na', 'na', 'Local Files -> No FTP needed', NULL);


INSERT INTO difcontrolmaster.FILE_INFO
(JOB_CD, FILE_NB, FILE_TYPE, FOLDER_NAME, DATA_FILE_NAME, CONTROL_FILE_NAME, OWNER_ID, LOCATION_ID)
VALUES('1304', 1, 'INBOUND', '/mnt/efs/dropbox/EXPN', 'SD-UPR-YYYYMMDD-\d+.zip', 'SD-UPR-YYYYMMDD-.*.INDEX.zip', 1, 0);

INSERT INTO difcontrolmaster.job_detail
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('2314', 'Standardize job for Experian', 'D001', 1000000004, 'A', 'gdw23xxExperian.pl', NULL, NULL, 'EXPN ');
