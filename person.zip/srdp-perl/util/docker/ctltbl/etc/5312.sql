INSERT INTO difcontrolmaster.job_detail
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('5312', 'Orion Scoring Daily', 'D001', 1000000004, 'A', 'gdw5312ScoreOrion.pl', NULL, NULL, 'EXPN ');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'expn_file_directory', '/FromNationwide/egdwexpn');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'ftp_expn_filename', 'RatedRecord_11_Nationwide');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 's3_prefix_for_expn_score_file', 'warehouse/telematics_provide_db/experian_rated_record_11_nationwide');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'srp_score_filename', 'NWI_BD_AQB_Rated');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'outbound_dir', '/vol/dif/srdp/data/outbound');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 's3_prefix_for_aqb_score_file', 'warehouse/telematics_provide_db/experian_nwi_bd_aqb_rated/sourcefile_dt=');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 's3_bucket_name', 'dw-telematics-dev');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'provide_db', 'telematics_provide_db');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'work_db', 'telematics_work_db');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'pcdw_ftp_logon_file', '/vol/dif/srdp/priv/.ftp_connection');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'expn_conn_file', '/vol/dif/srdp/priv/.experian_connection');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'jdbc_server', 'telematics-emr-dev.aws.e1.nwie.net');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'jdbc_port', '9001');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('5312', 'hive_logon_file', '/vol/dif/srdp/priv/.hive_connection_experian');