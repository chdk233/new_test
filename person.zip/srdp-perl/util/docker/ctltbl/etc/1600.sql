INSERT INTO difcontrolmaster.job_detail
(job_cd, job_descr, frequency_cd, asset_id, job_eff_status, script_name, folder_name, workflow_name, source_cd)
VALUES('1600', 'SmartMiles acquire job', 'H001', 1000000004, 'A', 'gdwSmartMilesAcquire.pl', NULL, NULL, NULL);

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1600', 'Staging_next_job_cd', '[2600,STGWK]');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1600', 'telematics_support_email', 'DW-RAPID-RESPONSE@nationwide.com');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1600', 'tims_file_prefix', 'CC_TOYO');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1600', 'smartmiles_dropbox_dir', '/mnt/efs/dropbox/SMLS');

INSERT INTO difcontrolmaster.JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1600', 'fmc_dropbox_dir', '/mnt/efs/dropbox/SMLS');

INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1600', 's3_bucket_name', 'dw-telematics-dev');

INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1600', 'staging_summary', 'smartmiles_trip_summary');

INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1600', 'staging_event', 'smartmiles_trip_event');

INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1600', 'staging_point', 'smartmiles_trip_point');

INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1600', 'staging_tbl_dir', 'smartmiles_staging_json');

INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1600', 'working_dir', '/vol/dif/srdp/data');

INSERT INTO difcontrolmaster.job_parm
(job_cd, parm_name, parm_value)
VALUES('1600', 'staging_database', 'telematics_staging_db');

