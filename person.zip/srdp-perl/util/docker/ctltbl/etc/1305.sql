INSERT INTO difcontrolmaster.job_detail
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('1305', 'Acquire job for SmartPhone', 'D001', 1000000004, 'A', 'gdw1305SmartPhoneAcquire.pl', NULL, NULL, 'LXNX ');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1305', 'file_prefix', 'TD_');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1305', 'inbound_dir', '/mnt/efs/dropbox/LXNX');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1305', 'working_dir', '/mnt/efs/data/lxnx');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1305', 'staging_database', 'telematics_staging_db');

INSERT INTO difcontrolmaster.job_parm
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('1305', 's3_bucket_name', 'dw-telematics-dev');