create schema difcontrolmaster;

create table difcontrolmaster.ASSET
(
ASSET_ID BIGINT not null
constraint XPKASSET
    primary key,
DESCRIPTION VARCHAR(1000),
PROCESS_SUPPORT_EMAIL VARCHAR(1000)
)
;

create table difcontrolmaster.AUDIT_TYPE
(
AUDIT_TYPE_CD VARCHAR(20) not null
constraint XPKAUDIT_TYPE
    primary key,
DESCRIPTION VARCHAR(200)
)
;

create table difcontrolmaster.FREQUENCY
(
FREQUENCY_CD VARCHAR(10) not null
constraint XPKFREQUENCY
    primary key,
DESCRIPTION VARCHAR(1000)
)
;

create table difcontrolmaster.JOB_DETAIL
(
JOB_CD CHAR(4) not null
constraint XPKJOB_DETAIL
    primary key,
JOB_DESCR VARCHAR(1000) not null,
FREQUENCY_CD VARCHAR(10) not null
constraint R_6
    references difcontrolmaster.FREQUENCY,
ASSET_ID BIGINT not null
constraint R_15
    references difcontrolmaster.ASSET,
JOB_EFF_STATUS CHAR,
SCRIPT_NAME VARCHAR(200),
FOLDER_NAME VARCHAR(200),
WORKFLOW_NAME VARCHAR(200),
SOURCE_CD CHAR(5)
)
;

create table difcontrolmaster.JOB_PARM
(
JOB_CD CHAR(4) not null
constraint R_2
    references difcontrolmaster.JOB_DETAIL,
PARM_NAME VARCHAR(1000) not null,
PARM_VALUE VARCHAR(1000),
constraint XPKJOB_PARM
primary key (JOB_CD, PARM_NAME)
)
;

create table difcontrolmaster.LOCATION
(
LOCATION_ID BIGINT not null
constraint XPKLOCATION
    primary key,
SERVER_NAME VARCHAR(100),
SERVER_TYPE VARCHAR(100),
USER_NAME VARCHAR(100),
CONNECTION_FILE_NAME VARCHAR(100),
DESCRIPTION VARCHAR(1000),
CONNECTION_PARM VARCHAR(1000)
)
;

create table difcontrolmaster.OWNER
(
OWNER_ID BIGINT not null
constraint XPKOWNER
    primary key,
SUPPORT_GROUP VARCHAR(1000),
SUPPORT_EMAIL VARCHAR(1000),
SUPPORT_PHONE VARCHAR(255),
SECONDARY_EMAIL VARCHAR(1000),
SECONDARY_PHONE VARCHAR(255)
)
;

create table difcontrolmaster.FILE_INFO
(
JOB_CD CHAR(4) not null
constraint R_11
    references difcontrolmaster.JOB_DETAIL,
FILE_NB BIGINT not null,
FILE_TYPE VARCHAR(25) not null,
FOLDER_NAME VARCHAR(200),
DATA_FILE_NAME VARCHAR(200),
CONTROL_FILE_NAME VARCHAR(200),
OWNER_ID BIGINT not null
constraint R_16
    references difcontrolmaster.OWNER,
LOCATION_ID BIGINT not null
constraint R_17
    references difcontrolmaster.LOCATION,
constraint XPKFILE_INFO
primary key (FILE_NB, FILE_TYPE, LOCATION_ID, JOB_CD),
constraint UNQFILE_INFO
unique (JOB_CD, FILE_NB)
)
;

create table difcontrolmaster.STATUS
(
STATUS_CD CHAR not null
constraint XPKSTATUS
    primary key,
DESCRIPTION VARCHAR(100)
)
;

create table difcontrolmaster.JOB_EVENT
(
JOB_CD CHAR(4) not null
constraint R_10
    references difcontrolmaster.JOB_DETAIL,
LOAD_EVENT_ID BIGINT not null,
START_TS TIMESTAMP(0) not null,
END_TS TIMESTAMP(0),
STATUS_CD CHAR not null
constraint R_20
    references difcontrolmaster.STATUS,
LOG_FILE VARCHAR(1000),
SOURCE_CD CHAR(5),
constraint XPKJOB_EVENT
primary key (LOAD_EVENT_ID, JOB_CD, START_TS)
)
;



create table difcontrolmaster.JOB_AUDIT
(
JOB_CD CHAR(4) not null,
LOAD_EVENT_ID BIGINT not null,
START_TS TIMESTAMP(0) not null,
AUDIT_ID BIGINT not null,
AUDIT_DIRECTION_TYPE_CD CHAR(6),
AUDIT_TYPE_CD VARCHAR(20) not null
constraint R_19
    references difcontrolmaster.AUDIT_TYPE,
AUDIT_TOTAL VARCHAR(255),
DESCRIPTION VARCHAR(1000),
constraint XPKJOB_AUDIT
primary key (AUDIT_ID, JOB_CD, LOAD_EVENT_ID),
constraint R_14
foreign key (LOAD_EVENT_ID, JOB_CD, START_TS) references difcontrolmaster.JOB_EVENT
)
;

create table difcontrolmaster.JOB_EVENT_INFO
(
LOAD_EVENT_ID BIGINT not null,
JOB_CD CHAR(4) not null,
START_TS TIMESTAMP(0) not null,
EVENT_INFO_NAME VARCHAR(200) not null,
EVENT_INFO_VALUE VARCHAR(200),
constraint XPKJOB_EVENT_INFO
primary key (LOAD_EVENT_ID, JOB_CD, START_TS, EVENT_INFO_NAME)
)
;

create table difcontrolmaster.EXCEPTION_RESPONSE
(
EXCEPTION_RESPONSE_ID INT not null
constraint EXCEPTION_RESPONSE_PK
    primary key,
DESCRIPTION VARCHAR(1000)
)
;

create table difcontrolmaster.EXCEPTION_CLASSIFICATION
(
EXCEPTION_CLASSIFICATION_ID INT not null
constraint EXCEPTION_CLASSIFICATION_PK
    primary key,
DESCRIPTION VARCHAR(1000),
EXCEPTION_RESPONSE_ID INT not null
constraint EXCEPTION_CLASSI_EXCEPTION__FK
    references difcontrolmaster.EXCEPTION_RESPONSE
)
;

create table difcontrolmaster.JOB_EXCEPTION
(
JOB_CD CHAR(4) not null,
START_TS TIMESTAMP(0) not null,
LOAD_EVENT_ID BIGINT not null,
EXCEPTION_ID BIGINT not null,
EXCEPTION_CLASSIFICATION_ID INT not null
constraint JOB_EXC_EXCEPTION_CLASSIFI_FK
    references difcontrolmaster.EXCEPTION_CLASSIFICATION,
EXCEPTION_TYPE_DESC VARCHAR(256),
EXCEPTION_ELEMENT VARCHAR(256),
EXCEPTION_SOURCE VARCHAR(256),
constraint JOB_EXCEPTION_PK
primary key (EXCEPTION_ID, JOB_CD, START_TS, LOAD_EVENT_ID),
constraint R_21
foreign key (LOAD_EVENT_ID, JOB_CD, START_TS) references difcontrolmaster.JOB_EVENT
)
;

create index JOB_EXCEPTION_FK01
on difcontrolmaster.JOB_EXCEPTION (LOAD_EVENT_ID, JOB_CD, START_TS)
;

create table difcontrolmaster.JOB_EXCEPTION_DETAIL
(
JOB_CD CHAR(4) not null,
START_TS TIMESTAMP(6) not null,
LOAD_EVENT_ID BIGINT not null,
EXCEPTION_ID BIGINT not null,
EXCEPTION_DETAIL_ID BIGINT not null,
EXCEPTION_VALUE VARCHAR(256) not null,
SOURCE_ROW_IDENTIFIER VARCHAR(256),
constraint JOB_EXCEPTION_DETAIL_PK
primary key (JOB_CD, START_TS, LOAD_EVENT_ID, EXCEPTION_ID, EXCEPTION_DETAIL_ID),
constraint JOB_EXCEPTION_DE_JOB_EXCEP_FK
foreign key (EXCEPTION_ID, JOB_CD, START_TS, LOAD_EVENT_ID) references difcontrolmaster.JOB_EXCEPTION
)
;

create table difcontrolmaster.FILE_PARM
(
JOB_CD CHAR(4) not null,
FILE_NB BIGINT not null,
PARM_NAME VARCHAR(1000) not null,
PARM_VALUE VARCHAR(1000),
constraint XPKFILE_PARM
primary key (FILE_NB, PARM_NAME, JOB_CD),
constraint R_22
foreign key (JOB_CD, FILE_NB) references difcontrolmaster.FILE_INFO (JOB_CD, FILE_NB)
)
;




insert into difcontrolmaster.status values ('R','Ready for Processing');
insert into difcontrolmaster.status values ('S','Successful');
insert into difcontrolmaster.status values ('E','Error During Processing');
insert into difcontrolmaster.status values ('T','Test updated status to get out of the way of other tests');
insert into difcontrolmaster.status values ('M','Some sort of Manual Intervention was needed to manipulate the status');
insert into difcontrolmaster.status values ('W','Job is Waiting on upstream process');
insert into difcontrolmaster.status values ('I','Job is in Process');
INSERT INTO difcontrolmaster.EXCEPTION_RESPONSE VALUES ('5','Stop the load due to detection of critical error');
insert into difcontrolmaster.audit_type values ('Count','Count of number of records');
insert into difcontrolmaster.audit_type values ('Amount','Total sum of a column in dollars');
insert into difcontrolmaster.audit_type values ('Checksum','Checksum value of a file');
INSERT INTO difcontrolmaster.EXCEPTION_RESPONSE VALUES (1,'Load source value');
INSERT INTO difcontrolmaster.EXCEPTION_RESPONSE VALUES (2,'Load default value');
INSERT INTO difcontrolmaster.EXCEPTION_RESPONSE VALUES (3,'Reject the source record');
INSERT INTO difcontrolmaster.EXCEPTION_RESPONSE VALUES (4,'Stop the load due to exceeded exception threshold');
INSERT INTO difcontrolmaster.EXCEPTION_CLASSIFICATION values ('11','Audit Comparison Failure',5);
INSERT INTO difcontrolmaster.EXCEPTION_CLASSIFICATION values ('23','Audit Comparison Failure',1);

INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('TEST001', 'Test Frequency');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('M001', 'Monthly');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('H004', 'Hourly (4)');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('D002', 'Every other day');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('W002', 'Every Tuesday');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('D001', 'Daily');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('W006', 'Friday');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('W003', 'Every Monday');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('W001', 'Sunday');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('AH001', 'Ad-Hoc');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('D015', 'Every 15 minutes');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('Q001', 'Quarterly');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('H001', 'Hourly');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('H008', 'Every 8 hours');
INSERT INTO difcontrolmaster.FREQUENCY
(FREQUENCY_CD, DESCRIPTION)
VALUES('T01', 'Test Frequency');



--PostGres Seeds

CREATE SEQUENCE difcontrolmaster.load_event_id START 1000000;
CREATE SEQUENCE difcontrolmaster.audit_id START 1;
CREATE SEQUENCE difcontrolmaster.exception_detail_id START 1;
CREATE SEQUENCE difcontrolmaster.exception_id START 1;

INSERT INTO difcontrolmaster.ASSET
(ASSET_ID, DESCRIPTION, PROCESS_SUPPORT_EMAIL)
VALUES(9999999999, 'Test Asset', 'EDW_TESTING@nationwide.com');

INSERT INTO difcontrolmaster.JOB_DETAIL
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('BIGH', 'Big Heroes testing job code', 'D001', 9999999999, 'A', NULL, 'JUNK5', 'wf_tdd_workflow', NULL);

INSERT INTO difcontrolmaster.OWNER
(OWNER_ID, SUPPORT_GROUP, SUPPORT_EMAIL, SUPPORT_PHONE, SECONDARY_EMAIL, SECONDARY_PHONE)
VALUES(1, 'test_support_group', 'test@nationwide.com', '6142490000', 'test2@nationwide.com', '6142499999');

INSERT INTO difcontrolmaster.LOCATION
(LOCATION_ID, SERVER_NAME, SERVER_TYPE, USER_NAME, CONNECTION_FILE_NAME, DESCRIPTION, CONNECTION_PARM)
VALUES(0, 'LOCAL', 'linux', 'na', 'na', 'Local Files -> No FTP needed', NULL);

create user difcontrolmaster password 'difcontrolmaster';

GRANT USAGE ON SCHEMA difcontrolmaster TO difcontrolmaster;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA difcontrolmaster TO difcontrolmaster;

GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA difcontrolmaster TO difcontrolmaster;

insert into  difcontrolmaster.asset (ASSET_ID, DESCRIPTION, PROCESS_SUPPORT_EMAIL)
values (1000000004, 'SmartRideProgram',            'NI-DATAWH-PERSONAL-LINES-SRDP-team.email') ;



