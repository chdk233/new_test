INSERT INTO JOB_DETAIL
(JOB_CD, JOB_DESCR, FREQUENCY_CD, ASSET_ID, JOB_EFF_STATUS, SCRIPT_NAME, FOLDER_NAME, WORKFLOW_NAME, SOURCE_CD)
VALUES('3313', 'IMS Device Status', 'D001', 1000000004, 'A', 'gdw33xxDeviceStatus.pl', NULL, NULL, 'NIMS ');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'map_reduce_driver_name', 'com.nationwide.smartride.scoring.devicestatus.DeviceStatusMain -D mapreduce.reduce.java.opts=-Djava.util.Arrays.useLegacyMergeSort=true -D mapred.reduce.tasks=150 -D mapreduce.reduce.memory.mb=7500 -D mapreduce.map.memory.mb=7500');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'map_reduce_input_file', 's3://dw-telematics-dev/warehouse/telematics_db/smartride_tsp_tripsummary/source_cd=IMS/*,s3://dw-telematics-dev/warehouse/telematics_db/smartride_tsp_tripsummary/source_cd=OCTO/*,s3://dw-telematics-dev/warehouse/telematics_db/smartride_tsp_tripevent/source_cd=IMS/*,s3://dw-telematics-dev/warehouse/telematics_db/smartride_tsp_tripevent/source_cd=OCTO/*,s3://dw-telematics-dev/warehouse/telematics_db/smartride_smt_ods_bigin_pgm_instnc_parquet/*');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'map_reduce_input_path', '');


INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'map_reduce_jar_path', '/usr/local/bin/');


INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'map_reduce_jar_name', 'mapReduce-0.0.1-SNAPSHOT.jar');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'map_reduce_output_file', 'devicestatus');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'map_reduce_output_path', '/user/hive/devicestatus');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'sql_file_name', 'gdwSmartRideDeviceStatus.sql');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'jdbc_port', '9001');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'jdbc_server', 'telematics-smartride-daily-dev.aws.e1.nwie.net');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'hive_logon_file', '/vol/dif/srdp/priv/.hive_connection_smartride_daily');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'skip_kerberos_initialization', 'TRUE');

INSERT INTO JOB_PARM
(JOB_CD, PARM_NAME, PARM_VALUE)
VALUES('3313', 'hadoop_logon_file', '/vol/dif/srdp/priv/.hadoop_connection_smartride_daily');

INSERT INTO job_parm
(job_cd, parm_name, parm_value)
VALUES('3313', 's3_bucket_name', 'dw-telematics-dev');
