#!/bin/bash
set -e

if [ "$1" = 'postgres' ]; then

    if [ -z "$(ls -A "$PGDATA")" ]; then
        initdb 
    fi
    cp /pg_hba.conf $PGDATA/pg_hba.conf
    cp /postgresql.conf $PGDATA/postgresql.conf
    pg_ctl -D $PGDATA -l $PGDATA/../logfile start
    sleep 5
    createdb dif
    psql -d dif -f /setup.sql
    for f in /[1-9]*.sql;do psql -d dif -f $f;done;
    pg_ctl stop
    sleep 5
    exec postgres

fi

exec "$@"