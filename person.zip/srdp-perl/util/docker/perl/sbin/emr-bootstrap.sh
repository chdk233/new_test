#! /bin/bash
# Run as root, .pem files will not longer work after running this script so make sure you are putting your ID/group correctly in access.conf and /etc/sudoers

#Install required software bundles
yum install -y sssd-ldap oddjob oddjob-mkhomedir

#Create /etc/sssd/sssd.conf
curl https://raw.github.nwie.net/Nationwide/ansible-base-linux/development/common/files/sssd/sssd.conf -o /etc/sssd/sssd.conf
chmod 600 /etc/sssd/sssd.conf

#Replace /etc/openldap/nsswitch.conf
mv /etc/openldap/nsswitch.conf /etc/openldap/nsswitch.conf.backup
curl https://raw.github.nwie.net/Nationwide/ansible-base-linux/development/common/files/nsswitch.conf -o /etc/openldap/nsswitch.conf

#Create /etc/pki/tls/certs/ca-bundle.crt
curl https://raw.github.nwie.net/Nationwide/ansible-base-linux/development/common/files/sssd/ca-bundle.crt -o /etc/pki/tls/certs/ca-bundle.crt

#Replace /etc/pam.d/system-auth-ac
mv /etc/pam.d/system-auth-ac /etc/pam.d/system-auth-ac.backup
curl https://raw.github.nwie.net/Nationwide/ansible-base-linux/development/common/files/pam/system-auth-ac -o /etc/pam.d/system-auth-ac
                
#Replace /etc/pam.d/password-auth-ac
mv /etc/pam.d/password-auth-ac /etc/pam.d/password-auth-ac.backup
curl https://raw.github.nwie.net/Nationwide/ansible-base-linux/development/common/files/pam/password-auth-ac -o /etc/pam.d/password-auth-ac

#Modify /etc/nsswitch.conf
cp /etc/nsswitch.conf /etc/nsswitch.conf.backup
sed -i 's/group:      files sss/group:      files sss\nnetgroup:   files sss/g' /etc/nsswitch.conf

#Modify /etc/ssh/sshd_config
# cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup
# sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config

#Restart sshd service
# service sshd restart

#Modify /etc/security/access.conf
echo "
# Managed File: base/templates/access.j2
+:root:ALL
-:@BadUser:ALL
+:@access-standard:ALL
+:oracle:ALL
+:roberd7:ALL
+:ALL:LOCAL
+:@nsc-datawarehouse-admin-users:ALL
-:ALL:ALL" > /etc/security/access.conf

#Modify /etc/sudoers
echo '+nsc-datawarehouse-admin-users ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers
echo 'roberd7 ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers

authconfig --enablemkhomedir --update

#Start sssd service
/usr/sbin/sssd

exec "$@"