"""
AWS Lambda function for the DW PersonalLines SmartHome application.
Moves source files from SmartHome External bucket to Internal Bucket.
"""
import boto3
import json
import datetime

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    print(f"Received following event {event}")
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    current_utcdate = str(datetime.datetime.utcnow())[:10]
    current_utchour = str(datetime.datetime.utcnow())[11:13]+'00'
    
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]
    
    # Get Amazon S3 source information.
    sns_message = event.get('Records')[0].get('Sns').get('Message')
    s3_source = json.loads(sns_message).get("Records")[0].get("s3")
    s3_source_bucket_name = s3_source.get("bucket").get("name")
    s3_source_object_key = s3_source.get("object").get("key") 

    
    # Get Amazon S3 target information.
    s3_target_bucket_name = f"dw-internal-telematics-{account_number}"
    s3_target_object_key=s3_source_object_key
    
    # Copy the source Amazon S3 object to the target Amazon S3 location.
    s3_client.copy_object(
        CopySource={
            "Bucket": s3_source_bucket_name,
            "Key": s3_source_object_key
        },
        Bucket=s3_target_bucket_name,
        Key=s3_target_object_key
    )

    s3_client.copy_object(
        CopySource={
            "Bucket": s3_source_bucket_name,
            "Key": s3_source_object_key
        },
        Bucket=s3_target_bucket_name,
        Key=f"SmartMiles-IMS-SourceFiles/load_date={current_utcdate}/{current_utchour}/{s3_source_object_key.split('/')[-1]}"
    )
    
    # Delete the source Amazon S3 object.
    s3_client.delete_object(
        Bucket=s3_source_bucket_name,
        Key=s3_source_object_key
    )
    sns = boto3.resource('sns')
    topic = sns.Topic(f"arn:aws:sns:us-east-1:{account_number}:dw-pl-smls-ims-telematics-Main")
    topic.publish(Message=json.dumps(
                {'default': 
                    json.dumps(
                        {"ID": 
                            f"s3://dw-internal-telematics-{account_number}/{s3_source_object_key}"
                        }
                    )
                }
            ),Subject='Main',MessageStructure='json')
    print(f"Pushed the message s3://dw-internal-telematics-{account_number}/{s3_source_object_key} to SQS")
    
    with open ('/tmp/SmartMiles_IMS_Ext_Last_Modified_Time.csv','w') as f:
        f.write(str(datetime.datetime.now()))
    filename='SmartMiles-IMS-FileCheck/SmartMiles_IMS_Ext_Last_Modified_Time.csv'
    s3_resource=boto3.resource('s3')
    s3_resource.meta.client.upload_file('/tmp/SmartMiles_IMS_Ext_Last_Modified_Time.csv', s3_target_bucket_name, filename)

