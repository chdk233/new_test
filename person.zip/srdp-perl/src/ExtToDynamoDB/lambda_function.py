import boto3
import datetime
import os
import logging
import json

FORMAT = '%(asctime)s [%(module)s.%(funcName)s:%(lineno)d] %(levelname)s: %(message)s'
logging.basicConfig(format=FORMAT, datefmt="%Y-%m-%d %H:%M:%S")
LOGGER = logging.getLogger()
LOGGER.setLevel(os.getenv("LOGLEVEL", "INFO"))

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    LOGGER.info(f"Event received: {event}")
    NOW                  = datetime.datetime.now()
    CURRENT_DATE         = NOW.strftime('%Y-%m-%d')
    CURRENT_TIME         = NOW.strftime('%H:%M:%S.%f')
    
    # Initialize client objects for AWS services.
    s3_client = boto3.client("s3")
    sts_client = boto3.client("sts")
    
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]
    
    # Get Amazon S3 source information.
    sns_message = event.get('Records')[0].get('Sns').get('Message')
    s3_source = json.loads(sns_message).get("Records")[0].get("s3")
    s3_bucket_name = s3_source.get("bucket").get("name")
    s3_object_key = s3_source.get("object").get("key") 
    


    dynamoDb = boto3.client('dynamodb')
    TABLE_NAME='Smartmiles-IMS-Control-Table'
    Id=s3_object_key.split('/')[-1].split('.')[0]
    LOGGER.info(f"Inserting Trip/Event id {Id} "+
                f"into dynamo db table {TABLE_NAME}")
    response = dynamoDb.put_item(
        TableName=TABLE_NAME,
        Item={
            'ID' : {
                'S' : Id
            },
            'FileReceivedDate' : {
                'S' : CURRENT_DATE
            },
            'FileReceivedTime' : {
                'S' : CURRENT_TIME
            }
        }
    )

    LOGGER.info(f"Dynamo DB put item response: {response}")
    
    
    
    