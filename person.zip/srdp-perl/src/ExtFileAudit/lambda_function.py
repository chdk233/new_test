import json
import boto3
import datetime

def lambda_handler(event, context):
    # TODO implement
    s3_client = boto3.client('s3')
    sts_client = boto3.client("sts")
    sns_client = boto3.client("sns")
    # Get the current AWS account number.
    account_number = sts_client.get_caller_identity()["Account"]
    s3_bucket_name = f"dw-internal-telematics-{account_number}"
    s3_key = 'SmartMiles-IMS-FileCheck/SmartMiles_IMS_Ext_Last_Modified_Time.csv'
    temp_file_path= '/tmp/SmartMiles_IMS_Ext_Last_Modified_Time.csv'
    topic_arn=f'arn:aws:sns:us-east-1:{account_number}:dw-pl-smls-ims-telematics'
    s3_client.download_file(s3_bucket_name,s3_key,temp_file_path)
    date_time=datetime.datetime.now()
    print(date_time)
    with open(temp_file_path) as f:
        p_read=f.readlines()
    diff=date_time-datetime.datetime.strptime(p_read[0],'%Y-%m-%d %H:%M:%S.%f')
    if diff.total_seconds() >= 10800:
        today_date=str(datetime.datetime.now()).split(' ')[0]
        diff_hrs=int(diff.total_seconds()/(3600))
        sns_client.publish(
                TopicArn = topic_arn,
                Message = f'Telematics Smartmiles - IMS files not received from {diff_hrs} hours on {today_date}',
                Subject = f'Telematics Smartmiles - IMS files not received - {today_date}'
            )  
        print('sns notification sent')
        print(f'Telematics Smartmiles - IMS files not received from {diff_hrs} hours on {today_date}')
