import json
import boto3
import os
import datetime



def lambda_handler(event, context):
    # TODO implement
    try:
        local_mount_path='/mnt/ccar'
        efs_client=boto3.client('efs')
        efs_location=f'{local_mount_path}/dropbox/CCAR/'
        ERROR_SNS=os.getenv('ERROR_SNS')
        load_dt=str(datetime.datetime.utcnow())[:10]
        sns=boto3.resource('sns')
        sqs = boto3.resource('sqs')
        s3_client = boto3.client('s3')
        s3_resource = boto3.resource('s3')
        error_topic = sns.Topic(ERROR_SNS)
        # Get Amazon S3 source information.
        s3_message = event.get('Records')[0].get('s3')

        s3_source_bucket_name = s3_message.get("bucket").get("name")
        print(f'Source Bucket Name : {s3_source_bucket_name}')
        s3_source_object_key = s3_message.get("object").get("key") 
        print(f'Source Key : {s3_source_object_key}')
        location=efs_location+s3_source_object_key.split('/')[-1]
        print(f'efs location:{location}')
        s3_client.download_file(s3_source_bucket_name,s3_source_object_key,location)
        s3_resource.Object(s3_source_bucket_name, s3_source_object_key).delete()
        print(f'Deleted the file {s3_source_object_key}')
    except Exception as e:
        print(f'lambda execution failed with error {e}')
        sns_message={ "Error" : f'lambda execution failed with error {e} ' ,
		      				 "LogStreamName" : context.log_stream_name,
		      				 "Source Bucket":s3_source_bucket_name,
                               "Source File Name":s3_source_object_key,
		      				 "LogGroupName" : context.log_group_name }
        error_topic.publish(Message=json.dumps({'default': json.dumps(sns_message)}),
                                          Subject=f'CCAR Dropbox to EFS Lambda Failed for load_date:{load_dt}',
                                          MessageStructure='json')