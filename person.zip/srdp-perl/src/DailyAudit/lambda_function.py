import json
import boto3
import time
import re
import dateutil
from datetime import datetime
import csv
from subprocess import call

def lambda_handler(event, context):
    global s3_target_bucket_name,load_dt,s3_client,s3_resource
    # TODO implement
    s3_client=boto3.client('s3')
    sts_client=boto3.client('sts')
    s3_resource=boto3.resource('s3')
    account_number = sts_client.get_caller_identity()["Account"]
    #print(context.invoked_function_arn)
    s3_external_bucket=f"dw-external-telematics-ims-{account_number}"
    s3_external_prefix='SmartMiles-Audit/'
    s3_target_bucket_name=f"dw-internal-telematics-{account_number}"
    
    
    paginator = s3_client.get_paginator('list_objects_v2')
    print('s3_external_bucket:',s3_external_bucket)
    print('s3_target_bucket_name:',s3_target_bucket_name)
    
    for result in paginator.paginate(Bucket=s3_external_bucket,Prefix=s3_external_prefix):
        for file in result['Contents']:
            if file['Key'].strip('/') != s3_external_prefix.strip('/') :
                if '_TRIPSUMMARY.csv' in file['Key']:
                    work_table_name='smartmiles_tripsummary_audit'
                elif '_EVENTS.csv' in file['Key']:
                    work_table_name='smartmiles_events_audit'
                else:
                    continue
                load_dt=file['Key'].split('/')[-1].split('_')[3]
                print('load date is :',load_dt)
                load_month=load_dt[:6]
                next_load_month = (datetime.strptime(load_dt,'%Y%m%d')+dateutil.relativedelta.relativedelta(months=1)).strftime('%Y%m%d')[:6]
                print(load_dt,load_month,next_load_month)
                s3_object_key='/'.join(file['Key'].split('/')[:-1])+'/load_dt='+load_dt+'/'+file['Key'].split('/')[-1]
                print(file['Key']) 
                s3_client.copy_object(
                CopySource={
                "Bucket": s3_external_bucket,
                "Key": file['Key']
                },
                Bucket=s3_target_bucket_name,
                Key=s3_object_key
                )
                params = {
                    'region': 'us-east-1',
                    'database': 'telematics_staging_db',
                    'log_path': 'AuditLogs',
                    'missedtrip_path':'SmartMilesMissedTripFiles',
                    'missedevents_path':'SmartMilesMissedEventFiles'
                    }
                if '_TRIPSUMMARY.csv' in file['Key']:
                    print(file['Key'])
                    alter_query=f"alter table  telematics_work_db.{work_table_name} add partition (load_dt='{load_dt}');"
                    athena_to_s3(params=params,query=alter_query,path='log_path')
                    trip_query=f'''SELECT svt.trip_summary_id
FROM (select * from telematics_work_db.{work_table_name} where load_dt = '{load_dt}')svt
LEFT OUTER JOIN  (
                                Select ts.trip_summary_id, ts.batch_nb
                                From telematics_staging_db.smartmiles_trip_event ts
                                where source_cd = 'IMS' and (batch_nb like '{load_dt}%' or batch_nb like '{load_month}%' or batch_nb like '{next_load_month}%' )
                                and ts.trip_summary_id is not null and ts.trip_event_id is null
                                group by ts.trip_summary_id, ts.batch_nb
                                )s
                ON svt.trip_summary_id = s.trip_summary_id
where s.trip_summary_id is null	
order by 1;'''
                    o_filename=athena_to_s3(params=params,query=trip_query,path='missedtrip_path')
                    
                    print(f'query result file name : {o_filename}')
                    rename_s3_object(s3_target_bucket_name,params['missedtrip_path']+'/'+o_filename,load_dt+'_missed_trips')
                    outputfilename=f'load_date_'+load_dt+'_missed_trips.csv'
                    check_Trip_ids(params['missedtrip_path']+'/'+outputfilename)
                if '_EVENTS.csv' in file['Key']:
                    alter_query=f"alter table  telematics_work_db.{work_table_name} add partition (load_dt='{load_dt}');"
                    athena_to_s3(params=params,query=alter_query,path='log_path')
                    event_query=f'''SELECT svt.trip_event_id
FROM (select * from telematics_work_db.{work_table_name} where load_dt = '{load_dt}')svt
LEFT OUTER JOIN   (
                                Select e.trip_event_id as trip_event_id, e.batch_nb
                                From telematics_staging_db.smartmiles_trip_event e
                                where source_cd = 'IMS' and (batch_nb like '{load_dt}%' or batch_nb like '{load_month}%' or batch_nb like '{next_load_month}%' )
                                and e.trip_summary_id is null and e.trip_event_id is not null
                                group by e.trip_event_id, e.batch_nb
                                )e
                ON svt.trip_event_id = e.trip_event_id
where e.trip_event_id is null	
order by 1;'''
                    o_filename=athena_to_s3(params=params,query=event_query,path='missedevents_path')
                    print(f'query result file name : {o_filename}')
                    rename_s3_object(s3_target_bucket_name,params['missedevents_path']+'/'+o_filename,load_dt+'_missed_events')
                    outputfilename=f'load_date_'+load_dt+'_missed_events.csv'
                    check_Trip_ids(params['missedevents_path']+'/'+outputfilename)
                cleanup(params)
                s3_resource.Object(s3_external_bucket, file['Key']).delete()
                
def rename_s3_object(bucket,key,l_date):
    target_key='/'.join(key.split('/')[:-1])+'/load_date_'+l_date+'.csv'
    
    s3_client.copy_object(
                CopySource={
                "Bucket": bucket,
                "Key": key
                },
                Bucket=bucket,
                Key=target_key
                )
    s3_resource.Object(bucket, key).delete()
                
def check_Trip_ids(object_key):
    if 'Trip' in object_key:
        msg_type='Trip'
    else:
        msg_type='Event'
    s3_client = boto3.client('s3')
    temp_file_path = '/tmp/output.csv'
    trip_id_list=[]
    record_count=0
    sns_client = boto3.client('sns')
    sts_client = boto3.client('sts')
    account_number = sts_client.get_caller_identity()['Account']
    sns_topic_arn = f'arn:aws:sns:us-east-1:{account_number}:dw-pl-smls-ims-telematics'
    s3_client.download_file(s3_target_bucket_name,object_key,temp_file_path)
    with open(temp_file_path,'r') as csv_file:
        csv_reader = csv.reader(csv_file,delimiter=",")
        for line in csv_reader:
            if 'trip_summary_id' not in line and 'trip_event_id' not in line:
                trip_id_list.append(line[0])
                record_count = record_count+1
    if(record_count < 1):
        print(f'Smartmiles IMS {msg_type} Validation check is successful.')
    else:
        print(f'Smartmiles IMS Trip Validation check failed. Found {len(trip_id_list)} Trip id values. Sending SNS notification.')
        trip_id_values = '\n'.join(trip_id_list[1:])
        msg = f'Smartmiles IMS {msg_type} Validation check failed.\n\nBelow s3 bucket file has the {record_count} missed Trip id values for load_dt {load_dt}:\n\ns3://{s3_target_bucket_name}/{object_key}'
        sub = f'Smartmiles IMS {msg_type} Validation check failure: {load_dt}'
        publish_sns_message(sns_client, sns_topic_arn, msg, sub)
    #Delete temp file
    call('rm -f '+temp_file_path,shell=True)

def publish_sns_message(sns_client, topic_arn, msg, sub):
    sns_client.publish(
                TopicArn = topic_arn,
                Message = msg,
                Subject = sub
            )      


#Function to execute Athena statements
def athena_query(client, params, query,path):
    
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': params['database']
        },
        ResultConfiguration={
            'OutputLocation': 's3://' + s3_target_bucket_name + '/' + params[path]
        }
    )
    return response

def athena_to_s3(params, query, path,max_execution = 20):
    client = boto3.client('athena')
    execution = athena_query(client, params, query,path)
    execution_id = execution['QueryExecutionId']
    state = 'RUNNING'

    while (max_execution > 0 and state in ['RUNNING','QUEUED']):
        max_execution = max_execution - 1
        response = client.get_query_execution(QueryExecutionId = execution_id)

        if 'QueryExecution' in response and \
                'Status' in response['QueryExecution'] and \
                'State' in response['QueryExecution']['Status']:
            state = response['QueryExecution']['Status']['State']

            if state == 'FAILED':
                print('Audit Query run failed.')
                print('response: ',response)
                return False
            elif state == 'SUCCEEDED':
                print('Audit Query run succeeded.')
                s3_path = response['QueryExecution']['ResultConfiguration']['OutputLocation']
                filename = re.findall('.*\/(.*)', s3_path)[0]
                return filename
        time.sleep(5)
    
    return False
#Function to cleanup output file generated in S3 location
def cleanup(params):
    s3_resource = boto3.resource('s3')
    response = s3_client.list_objects_v2(Bucket=s3_target_bucket_name, Prefix=params['log_path']+'/')
    if 'Contents' in response:
        for item in response['Contents']:
            s3_resource.Object(s3_target_bucket_name, item['Key']).delete()
            print(s3_target_bucket_name+'/'+item['Key'] +' Deleted Successfully')
    else:
        print('No files available for cleanup.')

