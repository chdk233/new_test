import json
import boto3
import os
import datetime

def lambda_handler(event, context):
    # TODO implement
    efs_client=boto3.client('efs')
    efs_location='/mnt/Smartmiles-IMS'+event.get('EFSLocation')
    MAIN_QUEUE=event.get('MainQueue')
    REPLAY_QUEUE=event.get('ReplayQueue')
    ERROR_SNS=event.get('ErrorSNS')
    EXECUTION_DURATION_DICT = event.get('ExecutionDuration')
    START_TIME_STR = event.get('StartTime')
    sns=boto3.resource('sns')
    sqs = boto3.resource('sqs')
    s3_client = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    error_topic = sns.Topic(ERROR_SNS)
    replay_queue = sqs.get_queue_by_name(QueueName=REPLAY_QUEUE)
    main_queue = sqs.get_queue_by_name(QueueName=MAIN_QUEUE)
    messages = []
    BATCH_SIZE=event.get('BatchSize')
    try:
        print(
            f"Validating execution duration specification {EXECUTION_DURATION_DICT}")
        EXECUTION_DURATION = datetime.timedelta(**EXECUTION_DURATION_DICT)
    except TypeError as e:
        print(f"Incorrect exexcution_duration defined '{EXECUTION_DURATION_DICT}'." +
                     " Refer to datetime.timedetla documenation for proper kwargs")
        exit(1)
    if START_TIME_STR:
        print(f"Converting START_TIME_STR to datetime object")
        START_TIME_DT = datetime.datetime.strptime(
            START_TIME_STR, '%Y-%m-%d %H:%M:%S')
        if datetime.datetime.now() - START_TIME_DT >= EXECUTION_DURATION:
            print(f"Specified execution duration {EXECUTION_DURATION}")
            print(f"Setting end_execution to True as a ")
            event.update({"EndExecution": "True"})
            return event
    else:
        START_TIME_STR = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        START_TIME_DT = datetime.datetime.strptime(
            START_TIME_STR, '%Y-%m-%d %H:%M:%S')
        print(f"Setting execution start time as {START_TIME_STR}")
        event.update({"StartTime": START_TIME_STR})
        event.update({"EndExecution": "False"})
    while len(messages) < int(BATCH_SIZE) and \
            context.get_remaining_time_in_millis() >= 10000 :
        print("Checking replay queue for messages")
        msg = replay_queue.receive_messages(AttributeNames=['ID'],
                                            MaxNumberOfMessages=1,
                                            WaitTimeSeconds=1)
        if not msg:
            print("Replay queue is empty")
            print("Checking main queue")
            msg = main_queue.receive_messages(AttributeNames=['ID'],
                                              MaxNumberOfMessages=1,
                                              WaitTimeSeconds=1)
        if msg:
            
            bodyDict = json.loads(msg[0].body)
            try:
                messages.append({
                    "TopicArn" : bodyDict.get('TopicArn'),
                    "Message" : bodyDict.get('Message')
                })
                sqs_message=json.loads(bodyDict.get('Message'))
                s3_bucket=sqs_message.get('ID').split('/')[2]
                s3_key='/'.join(sqs_message.get('ID').split('/')[3:])
                print(f"Source Bucket Name: {s3_bucket}")
                print(f"Source Key Name: {s3_key}")
                location=efs_location+s3_key.split('/')[-1]
                s3_client.download_file(s3_bucket,s3_key,location)
                s3_resource.Object(s3_bucket, s3_key).delete()
            except Exception as e:
                print(f"Message improperly formatted")
                print(
                    "S3 to EFS file move for the provided event has failed")
                sns_message=json.loads(msg[0].body)
                sns_message.update({ "Error" : str(e) ,
						 "LogStreamName" : context.log_stream_name,
						 "LogGroupName" : context.log_group_name })
                error_topic.publish(Message=json.dumps({'default': json.dumps(sns_message)}),
                                    Subject='S3 to EFS Lambda Failed ',
                                    MessageStructure='json')
            finally:
                msg[0].delete()
        else:
            print("Main queue is empty")
            break
    if len(messages) == 0 and (datetime.datetime.now() - START_TIME_DT) < EXECUTION_DURATION:
        print("no messages in the queue")
        event.update({"SleepStateSeconds":900})
    elif len(messages) < int(BATCH_SIZE) and (datetime.datetime.now() - START_TIME_DT) < EXECUTION_DURATION:
        print("messages available in the queue are less than the queue ")
        event.update({"SleepStateSeconds":900})
    else:
        event.update({"SleepStateSeconds":2})
    return event

if __name__ == "__main__":

    class mycontext:
        def __init__(self):
            self.time = 1001

        def get_remaining_time_in_millis(self):
            self.time -= 1
            return self.time