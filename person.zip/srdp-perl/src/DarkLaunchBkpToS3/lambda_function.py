import json
import boto3
import os
import tarfile
import datetime
import dateutil.tz
import urllib.parse
from io import BytesIO

def lambda_handler(event, context):
    # TODO implement
    try:
        ERROR_SNS=os.getenv('ERROR_SNS')
        sns=boto3.resource('sns')
        error_topic = sns.Topic(ERROR_SNS)
        s3_details=event['Records'][0]['s3']
        s3_bucket_name=s3_details['bucket']['name']
        print(f"Source Bucket Name :{s3_bucket_name}")
        s3_prefix=s3_details['object']['key']
        print(f"Source File Key :{s3_prefix}")
        s3_client=boto3.client('s3')
        sts_client = boto3.client("sts")
        load_dt=str(datetime.datetime.utcnow())[:10]
        load_hr=str(datetime.datetime.utcnow())[11:13]+'00'
        account_number = sts_client.get_caller_identity()["Account"]
        target_bucket_name=f'dw-internal-telematics-{account_number}'
        print(f"Load Date :{load_dt}")
        filename=s3_prefix.split('/')[-1]
        response=s3_client.list_objects_v2(Bucket=s3_bucket_name,Prefix=s3_prefix)
        size=response['Contents'][0]['Size']
        print(f"file size in bytes {size}")
        if int(size/(1024*1024*1024)) >= 8:
            print('lambda execution failed due to file size constraint')
            sns_message={ "Error" : 'lambda execution failed due to file size constraint' ,
                     "Source Bucket":s3_bucket_name,
                     "Source File Name":s3_prefix,
	    			 "LogStreamName" : context.log_stream_name,
	    			 "LogGroupName" : context.log_group_name }
            error_topic.publish(Message=json.dumps({'default': json.dumps(sns_message)}),
                                        Subject=f'Backup to S3 Lambda Failed for load_date:{load_dt}',
                                        MessageStructure='json')
        else:
            smartride_ims_bucket_name=target_bucket_name
            smartride_ims_prefix=f'SmartRide4X-IMS-SourceFiles/load_date={load_dt}/{load_hr}'
            smartride_octo_bucket_name=target_bucket_name
            smartride_octo_prefix=f'SmartRide-OCTO-SourceFiles/load_date={load_dt}/{load_hr}'
            smartmiles_tims_bucket_name=target_bucket_name
            smartmiles_tims_prefix=f'SmartRide-TIMS-SourceFiles/load_date={load_dt}/{load_hr}'
            if 'IMS_N_' in filename:
                s3_target_bucket_name=smartride_ims_bucket_name
                s3_target_prefix=smartride_ims_prefix
            elif 'OCTO_NWI_' in filename:
                s3_target_bucket_name=smartride_octo_bucket_name
                s3_target_prefix=smartride_octo_prefix
            elif 'SmartMiles_FMC_TIMS' in filename:
                s3_target_bucket_name=smartmiles_tims_bucket_name
                s3_target_prefix=smartmiles_tims_prefix
            print(f"Target Bucket Name : {s3_target_bucket_name}")
            print(f"Target Prefix Name : {s3_target_prefix}")
            response = s3_client.get_object(Bucket=s3_bucket_name,Key=s3_prefix)
            stream = response.get('Body').read()
            tims_flag='false'
            with tarfile.open(fileobj= BytesIO(stream)) as tar:
                for tar_content in tar:
                    if(tar_content.isfile()):
                        inner_tar_content = tar.extractfile(tar_content).read()
                        s3_target_object_key = f'{s3_target_prefix}/{tar_content.name.split("/")[-1]}'
                        compressed_file_name=tar_content.name.split("/")[-1]
                        if 'SmartMiles_FMC_TIMS' in filename  and ('CC_TOYO_' in  tar_content.name):
                            s3_client.upload_fileobj(BytesIO(inner_tar_content),s3_target_bucket_name,s3_target_object_key)
                            tims_flag='true'
                            print(f"uploaded file {s3_target_object_key} to bucket :{s3_target_bucket_name}")
                        elif 'IMS_N_' in filename  and compressed_file_name.split('.')[-1].lower()=='dat' and ('IMS_N_TSR_' in compressed_file_name or 'IMS_N_TPR_' in compressed_file_name or 'IMS_N_EVT_' in compressed_file_name) :
                            s3_client.upload_fileobj(BytesIO(inner_tar_content),s3_target_bucket_name,s3_target_object_key)
                            print(f"uploaded file {s3_target_object_key} to bucket :{s3_target_bucket_name}")
                        elif 'OCTO_NWI_' in filename  and compressed_file_name.split('.')[-1].lower()=='csv' and ('OCTO_NWI_TRIPS_' in compressed_file_name or 'OCTO_NWI_TRIPP_' in compressed_file_name or 'OCTO_NWI_TRIPE_' in compressed_file_name or 'OCTO_NWI_CUMULATIVE_' in compressed_file_name) :
                            s3_client.upload_fileobj(BytesIO(inner_tar_content),s3_target_bucket_name,s3_target_object_key)
                            print(f"uploaded file {s3_target_object_key} to bucket :{s3_target_bucket_name}")
                    if context.get_remaining_time_in_millis() <= 30000:
                        print('lambda execution stopped due to lambda execution time constraint')
                        sns_message={ "Error" : 'lambda execution stopped due to lambda execution time constraint' ,
	    	    				 "LogStreamName" : context.log_stream_name,
	    	    				 "Source Bucket":s3_bucket_name,
                                 "Source File Name":s3_prefix,
	    	    				 "LogGroupName" : context.log_group_name }
                        error_topic.publish(Message=json.dumps({'default': json.dumps(sns_message)}),
                                            Subject=f'Backup to S3 Lambda Failed for load_date:{load_dt}',
                                            MessageStructure='json')
                        break
                if 'SmartMiles_FMC_TIMS' in filename and tims_flag =='false':
                    print('no TOYO files avaialble in the compressed file')
    except Exception as e:
        print(f'lambda execution failed with error {e}')
        sns_message={ "Error" : f'lambda execution failed with error {e} ' ,
		      				 "LogStreamName" : context.log_stream_name,
		      				 "Source Bucket":s3_bucket_name,
                               "Source File Name":s3_prefix,
		      				 "LogGroupName" : context.log_group_name }
        error_topic.publish(Message=json.dumps({'default': json.dumps(sns_message)}),
                                          Subject=f'Backup to S3 Lambda Failed for load_date:{load_dt}',
                                          MessageStructure='json')
