import boto3
import json
import os
import random
import string
from datetime import datetime

def lambda_handler(event, context):
    """
    The entry-point of the AWS Lambda function.
    """

    print(f"Received event data:\n{event}")
    step_function_arn = os.getenv("STEP_FUNCTION_ARN")

    print(f"step function arn from environment variables -> {step_function_arn}")

    random.seed = (os.urandom(256))

    randomChars =''.join(random.choice(string.ascii_lowercase) for i in range(6)) + \
    ''.join(random.choice(string.ascii_uppercase) for i in range(6)) + \
    ''.join(random.choice(string.digits) for i in range(4))

    randomChars = ''.join(random.sample(randomChars,len(randomChars)))

    execution_name =  f"{step_function_arn.split(':')[-1]}-{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}{randomChars}"

    event.update({
        'messages' : []
    })
    sf_client = boto3.client("stepfunctions")

    execution_input_string = json.dumps(event)

    start_execution_response = sf_client.start_execution(
        stateMachineArn=step_function_arn,
        name=execution_name,
        input=execution_input_string
    )

    execution_arn = start_execution_response["executionArn"]

    print(f"Started execution of AWS Step Functions state machine.")
    print(f"Input data:\n{execution_input_string}")
    print(f"Execution ARN: {execution_arn}")

    return execution_arn