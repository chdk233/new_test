import json
import boto3
from datetime import date,datetime,timedelta,timezone
import os
from collections import Counter,defaultdict


source = 'smartmiles-ims-sourcefiles/load_date='
destination = 'SmartMiles-IMS-Pcds-Audit/Source-Duplicate-Check/'


# Initialize client objects for AWS services.
s3_client = boto3.client("s3")
sts_client = boto3.client("sts")
account_number = sts_client.get_caller_identity()['Account']
bucket_name = f'dw-internal-telematics-{account_number}'

#Add two dictionaries (add values if same keys)
def add_dictionaries(dict1 , dict2):
    return Counter(dict1) + Counter(dict2)


#Read data from a file as json        
def read_data_from_file(filename):
    data = s3_client.get_object(Bucket=bucket_name,Key=filename)
    contents=data['Body'].read()
    return json.loads(contents)

#Function to create day file. Delete the incomplete file first ,if present   
def create_day_file(filename,data,day):
    #if data is None need to delete incomplete data file and move its contents to day file.
    if(not data):
        data = read_data_from_file(filename)
    if(filename):
        s3_client.delete_object(Bucket=bucket_name,Key=filename)

    s3_client.put_object(Body=json.dumps(data),Bucket=bucket_name,Key=destination+day+"/day_file"+str(day)+".json")



def compare_with_day_file(today,filename,current_data,last_hour,complete_flag):

    duplicates_with_prev = defaultdict(int)

    #Compares the files in current hours with the files already collected in day
    day_data = read_data_from_file(filename)

    for each_val in current_data:
        if each_val in day_data:
            duplicates_with_prev[each_val] +=1


    day_data.extend(current_data)


    if(not complete_flag):
        s3_client.delete_object(Bucket=bucket_name,Key=filename)
        s3_client.put_object(Body=json.dumps(day_data),Bucket=bucket_name,Key=destination+today+"/Incomplete_file"+str(today)+'_'+str(last_hour)+".json")
    else:
        create_day_file(filename,day_data,today)
    return duplicates_with_prev


def check_if_file_exist(key,bucket):
    response = s3_client.list_objects_v2(Bucket=bucket,Prefix=key)
    if response:
        if('Contents' in response):
            for obj in response['Contents']:
                if(key==obj['Key']):
                    return True
    return False


def check_if_folder_exist(key):
    response = s3_client.list_objects_v2(Bucket=bucket_name,Prefix=key)
    if response:
        if('Contents' in response):
            return True

    return False


def check_prev_days(yesterday,day_before,current_res):
    res_yesterday = []
    res_day_before = []
    dupli_temp = {}
    dupli_prev_days = defaultdict(int)


    #Check if yesterday data present
    #check if day file is present for yesterday,If yes load data from day_file  and retrun duplicates(compare themselves)
    #If not present load data from prev days and return duplicates(compare to themselves), create day file and save
    if(check_if_file_exist(source+yesterday+'/',bucket_name)):
        if not check_if_file_exist(destination+yesterday+'/day_file'+str(yesterday)+'.json',bucket_name):
            res_yesterday,dupli_temp = get_files_from_bucket(source+yesterday+'/')
            create_day_file(None,res_yesterday,yesterday)
        else:
            res_yesterday = read_data_from_file(destination+yesterday+'/day_file'+str(yesterday)+'.json')

    #Check if yesterday data present
    #check if day file is present for yesterday,If yes load data from day_file and retrun duplicates(comparin to themselves)
    #If not present load data from prev days and return duplicates, create day file and save
    if(check_if_file_exist(source+day_before+'/',bucket_name)):
        if(not check_if_file_exist(destination+day_before+'/day_file'+str(day_before)+'.json',bucket_name)):
            res_day_before,dupli_temp = get_files_from_bucket(source+day_before+'/')
            create_day_file(None,res_day_before,day_before)
        else:
            res_day_before = read_data_from_file(destination+day_before+'/day_file'+str(day_before)+'.json')


    #Check if there is any duplicates by comparing hours data to prev days        
    for each_val in current_res:
        if(each_val in res_yesterday ):
            dupli_prev_days[each_val] += 1

        if(each_val in res_day_before):
            dupli_prev_days[each_val] += 1


    return dupli_prev_days


def get_files_from_bucket(prefix):
    res=[]
    duplicates= defaultdict(int)

    paginator = s3_client.get_paginator('list_objects_v2')
    for result in paginator.paginate(Bucket=bucket_name,Prefix=prefix):
        for file in result['Contents']:
            head,tail=os.path.split(file['Key'])
            if(len(tail)>1):
                if(tail in res):
                    duplicates[tail] += 1
                res.append(tail)
    return res,duplicates


def get_incomplete_file(today_date,key):

    response = s3_client.list_objects_v2(Bucket=bucket_name,Prefix=destination+today_date+'/')
    if response:
        if('Contents' in response ):
            for obj in response['Contents']:
                head,tail=os.path.split(obj['Key'])
                if(tail.startswith(key)):
                    return obj['Key']
    return None


def load_hours_data(today_date,current_hour):
    incomplete_file_name = get_incomplete_file(today_date,"Incomplete")
    if(incomplete_file_name):
        last_hour=int(incomplete_file_name[-9:-7])
    else:
        last_hour= -1

    res_whole = []
    dup_whole = defaultdict(int)
    res = []
    dup = {}
    final_hour=last_hour
    complete = False


    for time in range(last_hour+1,int(current_hour)+1):
        time_z=str(time).ljust(len(str(time))+2,'0')
        time_zz=time_z.rjust(4,'0')
        if(time==23):
            complete = True
        if(check_if_file_exist(source+today_date+'/'+time_zz+'/',bucket_name)):
            final_hour = time_zz
            res,dup = get_files_from_bucket(source+today_date+'/'+time_zz+'/')
            if(len(res_whole)):
                for val in res:
                    if(val in res_whole):
                        dup_whole[val] += 1
            else:
                for val in dup:
                    dup_whole[val] += 1
            res_whole.extend(res)


    return res_whole,dup_whole,incomplete_file_name ,final_hour,complete


def send_notification(data,file_loc):
    sns_client = boto3.client('sns')
    data_list=[]
    for x,y in data.items():
        data_list.append(f'{x}:{y}')
    sns_client.publish(
        TopicArn = f'arn:aws:sns:us-east-1:{account_number}:dw-pl-smls-ims-telematics-Error',
        Message = f'File location :https://s3.console.aws.amazon.com/s3/buckets/dw-internal-telematics-{account_number}?region=us-east-1&prefix={file_loc} \n Following files are duplicates:\n {data_list}',
        Subject = 'Alert-Smartmiles-ims-sourcefile: Duplicate File Received '
        )

    print("Notification sent now")




def lambda_handler(event, context):

    """
    The entry point of the AWS Lambda function.
    """

    #Get dates in required format
    today_date = date.today().strftime("%Y-%m-%d")
    yesterday = ((date.today()) - timedelta(days=1)).strftime("%Y-%m-%d")
    day_before = ((date.today()) - timedelta(days=2)).strftime("%Y-%m-%d")



    current_res = []
    current_dup = {}
    duplicates_with_day =  {}
    incomplete_file_name = None
    last_hour = '0000'
    current_hour = datetime.now(timezone.utc).strftime("%H")


    #Load last 3 hours data if present
    current_res,current_dup,incomplete_file_name,last_hour,complete_flag=load_hours_data(today_date,current_hour)


    if(len(current_res) == 0):
        print("No new data")
        if(incomplete_file_name and complete_flag):
            create_day_file(incomplete_file_name,None,today_date)
        return
    print("Duplicates in 3 hour",current_dup)


    #Call compare_with_day_file to see if the current files are duplicate of any file received earlier in the day
    #edit when 3 hour logic
    if(incomplete_file_name):
        duplicates_with_day = compare_with_day_file(today_date,incomplete_file_name,current_res,last_hour,complete_flag)
        current_dup = add_dictionaries(current_dup,duplicates_with_day)

    print("Duplicates to the same day:",duplicates_with_day)

    #Check if previous day files are present ,if yes compare to current data and return duplicates
    #If not present create day file and also return duplicates
    duplicates_with_prev = check_prev_days(yesterday,day_before,current_res)

    print("Duplicates when compared to prev 2 days",duplicates_with_prev)

    current_dup = add_dictionaries(current_dup,duplicates_with_prev)
    print("Total Duplicates:",current_dup)


    #Create an incomplete file if not present
    if(incomplete_file_name is None ):
        print("Creating incomplete file")
        if(not complete_flag):
            s3_client.put_object(Body=json.dumps(current_res),Bucket=bucket_name,Key = destination+today_date+"/Incomplete_file"+str(today_date)+'_'+str(last_hour)+".json")
        else:
            print("Creating day file")
            create_day_file(None,current_res,today_date)
            #s3_client.put_object(Body=json.dumps(current_res),Bucket=bucket_name,Key = destination+today_date+"/day_file"+str(today_date)+'.json')



    #find latest duplicate file
    if(check_if_folder_exist(destination+today_date+"/Duplicates/")):
        duplicate_files , d1 = get_files_from_bucket(destination+today_date+"/Duplicates/")
        if(len(duplicate_files)):
            duplicate_files.sort()
            latest = duplicate_files[-1]
            data = s3_client.get_object(Bucket=bucket_name,Key= destination+today_date+"/Duplicates/"+latest)
            contents=data['Body'].read()
            dup_dict = json.loads(contents)
            if(not dup_dict == current_dup):
                #Send notification mail with current dup
                send_notification(current_dup,destination+today_date+"/Duplicates/Duplicate_"+str(today_date)+'_'+str(last_hour)+".json")
            else:
                print("No new duplicates, so no notification")
    else:
        if(len(current_dup)):
            send_notification(current_dup,destination+today_date+"/Duplicates/Duplicate_"+str(today_date)+'_'+str(last_hour)+".json")


    #Create duplicate file for the current trigger
    if(len(current_dup)):
        s3_client.put_object(Body=json.dumps(current_dup),Bucket=bucket_name,Key = destination+today_date+"/Duplicates/Duplicate_"+str(today_date)+'_'+str(last_hour)+".json")
