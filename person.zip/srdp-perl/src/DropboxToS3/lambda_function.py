"""
AWS Lambda function for the DW PersonalLines SmartHome application.
Moves source files from dropbox to Internal Bucket.
"""
import boto3
import datetime
import json
import os

def lambda_handler(event, context):
    """
    The entry point of the AWS Lambda function.
    """
    try:
        ERROR_SNS=os.getenv('ERROR_SNS')
        sns=boto3.resource('sns')
        error_topic = sns.Topic(ERROR_SNS)
        print(f"Received following event {event}")
        # Initialize client objects for AWS services.
        s3_client = boto3.client("s3")
        sts_client = boto3.client("sts")
        load_dt=str(datetime.datetime.utcnow())[:10]
        load_hr=str(datetime.datetime.utcnow())[11:13]+'00'
        
        # Get the current AWS account number.
        account_number = sts_client.get_caller_identity()["Account"]
        
        # Get Amazon S3 source information.
        s3_message = event.get('Records')[0].get('s3')
        s3_source_bucket_name = s3_message.get("bucket").get("name")
        print(f'Source Bucket Name : {s3_source_bucket_name}')
        s3_source_object_key = s3_message.get("object").get("key") 
        print(f'Source Key : {s3_source_object_key}')
        src_file_name=s3_source_object_key.split('/')[-1]
        # Get Amazon S3 target information.
        s3_target_bucket_name = s3_source_bucket_name
        print(f'Target Bucket Name : {s3_target_bucket_name}')
        
        if 'Dropbox/SRDP/NIMS_HF/' in s3_source_object_key:
          s3_target_object_key=f'SmartRide4X-IMS-SourceFiles/load_date={load_dt}/{load_hr}/{src_file_name}'
          print(f'Target Key : {s3_target_object_key}')
          if src_file_name.split('.')[-1].strip(' ').lower() == 'dat' and ('IMS_N_TSR_' in src_file_name or 'IMS_N_TPR_' in src_file_name or 'IMS_N_EVT_' in src_file_name):
              s3_client.copy_object(
            CopySource={
                "Bucket": s3_source_bucket_name,
                "Key": s3_source_object_key
            },
            Bucket=s3_target_bucket_name,
            Key=s3_target_object_key)
          # Delete the source Amazon S3 object.
          
              s3_client.delete_object(
            Bucket=s3_source_bucket_name,
            Key=s3_source_object_key
        )
              print(f'Deleted the file {s3_source_object_key}')
        elif 'Dropbox/SMLS/' in s3_source_object_key:
          s3_target_object_key=f'SmartRide-TIMS-SourceFiles/load_date={load_dt}/{load_hr}/{src_file_name}'
          
          if 'CC_TOYO_' in src_file_name :
              print(f'Target Key : {s3_target_object_key}')
              s3_client.copy_object(
            CopySource={
                "Bucket": s3_source_bucket_name,
                "Key": s3_source_object_key
            },
            Bucket=s3_target_bucket_name,
            Key=s3_target_object_key)
          # Delete the source Amazon S3 object.
              s3_client.delete_object(
            Bucket=s3_source_bucket_name,
            Key=s3_source_object_key
         )
              print(f'Deleted the file {s3_source_object_key}')
    except Exception as e:
        print(f'lambda execution failed with error {e}')
        sns_message={ "Error" : f'lambda execution failed with error {e} ' ,
		      				 "LogStreamName" : context.log_stream_name,
		      				 "Source Bucket":s3_source_bucket_name,
                               "Source File Name":s3_source_object_key,
		      				 "LogGroupName" : context.log_group_name }
        error_topic.publish(Message=json.dumps({'default': json.dumps(sns_message)}),
                                          Subject=f'Dropbox to S3 Lambda Failed for load_date:{load_dt}',
                                          MessageStructure='json')
    
      

