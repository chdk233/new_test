# Utilities for AWS CloudFormation.


# Create an AWS CloudFormation stack.
aws::cloudformation::create_stack() {
    local cluster_name="$1"
    local stack_name="$2"
    local template_url="$3"
    local region_name="$4"
    local profile_name="$5"

    if test -z "$profile_name"; then
        aws cloudformation create-stack --stack-name "$stack_name" --template-url "$template_url" --region "$region_name" --capabilities "CAPABILITY_NAMED_IAM" --parameters ParameterKey=pClusterName,ParameterValue="$cluster_name"
    else
        aws cloudformation create-stack --stack-name "$stack_name" --template-url "$template_url" --region "$region_name" --capabilities "CAPABILITY_NAMED_IAM" --parameters ParameterKey=pClusterName,ParameterValue="$cluster_name" --profile "$profile_name"
    fi
}


# Delete an AWS CloudFormation stack.
aws::cloudformation::delete_stack() {
    local stack_name="$1"
    local region_name="$2"
    local profile_name="$3"

    if test -z "$profile_name"; then
        aws cloudformation delete-stack --stack-name "$stack_name" --region "$region_name"
    else
        aws cloudformation delete-stack --stack-name "$stack_name" --region "$region_name" --profile "$profile_name"
    fi
}


# Get the identifier an AWS CloudFormation stack.
aws::cloudformation::get_stack_identifier() {
    local stack_name="$1"
    local region_name="$2"
    local profile_name="$3"
    local stack_identifier

    if test -z "$profile_name"; then
        stack_identifier=$(aws cloudformation describe-stacks --stack-name "$stack_name" --query "Stacks[0].StackId" --region "$region_name")
    else
        stack_identifier=$(aws cloudformation describe-stacks --stack-name "$stack_name" --query "Stacks[0].StackId" --region "$region_name" --profile "$profile_name")
    fi

    # Remove leading and trailing double quotation marks.
    stack_identifier="${stack_identifier%\"}"
    stack_identifier="${stack_identifier#\"}"

    echo "$stack_identifier"
}


# Get the status an AWS CloudFormation stack.
aws::cloudformation::get_stack_status() {
    local stack_name="$1"
    local region_name="$2"
    local profile_name="$3"
    local stack_status

    if test -z "$profile_name"; then
        stack_status=$(aws cloudformation describe-stacks --stack-name "$stack_name" --query "Stacks[0].StackStatus" --region "$region_name")
    else
        stack_status=$(aws cloudformation describe-stacks --stack-name "$stack_name" --query "Stacks[0].StackStatus" --region "$region_name" --profile "$profile_name")
    fi

    # Remove leading and trailing double quotation marks.
    stack_status="${stack_status%\"}"
    stack_status="${stack_status#\"}"

    echo "$stack_status"
}
