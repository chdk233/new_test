use strict;
use warnings;
use DIF;
use GDW::HiveConnect;
use SmartRide::Common;
use File::Basename;

sub AuditAndUnzip {
    my $ProcVars = shift;
    my @dates_from_file;

    LogHeader($ProcVars);

    #############################
    # FIND FILES MATCHING REGEX #
    #############################
    opendir( DIR, $ProcVars->{inbound_dir} );
    my @files_matching_regex = grep( /$ProcVars->{file_filter_regex}/, readdir(DIR) );
    closedir(DIR);

    if ( !@files_matching_regex ) {
        LogInfo( $ProcVars, "No files found in $ProcVars->{inbound_dir} matching" . 
        "the regex $ProcVars->{file_filter_regex}.  Exiting script successfully." );
        UpdateJobEventIToS($ProcVars);
        exit 0;
    }

    ################################
    # EXTRACT DATES FROM FILE NAME #
    ################################
    foreach my $file (@files_matching_regex) {
        $file =~ m/(\d{8})/;
        push( @dates_from_file, $1 );    #
    }

    #store only duplicate values from array; this means should have found a data zip and an INDEX zip
    my %seen = ();
    my @unique_dates = map { 1 == $seen{$_}++ ? $_ : () } @dates_from_file;

    if ( !@unique_dates ) {
        LogInfo( $ProcVars, "ERROR: One of the required files is missing. " . 
        " Expected to find two files for a given date, but only found one. " .
        "The files found in $ProcVars->{inbound_dir} are: " . join( ',', @files_matching_regex ) );
        die;
    }

    my @zipped_index_array;
    my $unzipped_index_file;
    my @zipped_data_array;

    #################
    # AUDIT & UNZIP #
    #################
    foreach my $date (@unique_dates) {

        $ProcVars->{logger}->info("\n");
        LogInfo( $ProcVars, "***PREPARING FILES CONTAINING DATE $date***" );

        #GET COUNT FROM INDEX FILE#
        ( my $zipped_index_regex = $ProcVars->{InputFileCtl1} ) =~ s/YYYYMMDD/$date/g;

        @zipped_index_array = grep( /$zipped_index_regex/, @files_matching_regex );

        if (scalar @zipped_index_array >1){
            LogDie( $ProcVars, "There should only be one index file per date but " .
                               scalar @zipped_index_array . " were found.");
        }

        InboundToWorking( $ProcVars, $zipped_index_array[0] );

        $unzipped_index_file = `/usr/bin/zipinfo -1 $ProcVars->{working_dir}/$zipped_index_array[0]`;
        chomp $unzipped_index_file;

        LogInfo( $ProcVars, "Unzipping $ProcVars->{working_dir}/$zipped_index_array[0]" );
        `cd $ProcVars->{working_dir}; /usr/bin/unzip $zipped_index_array[0]`;

        open my $FH, '<', "$ProcVars->{working_dir}/$unzipped_index_file";
        my $IndexCount = <$FH>;
        chomp $IndexCount;
        close $FH;

        #GET COUNT OF FILES FROM DAT FILE#
        ( my $zipped_data_regex = $ProcVars->{InputFileName1} ) =~ s/YYYYMMDD/$date/g;
        @zipped_data_array = grep( /$zipped_data_regex/, @files_matching_regex );

        if (scalar @zipped_data_array >1){
            LogDie( $ProcVars, "There should only be one data file per date but " .
                               scalar @zipped_data_array . " were found.");
        }

        InboundToWorking( $ProcVars, $zipped_data_array[0] );

        my $DataCount = `/usr/bin/zipinfo $ProcVars->{working_dir}/$zipped_data_array[0] | grep ^- | wc -l`;

        if ( $DataCount == $IndexCount ) {
            LogInfo( $ProcVars, "Unzipping $ProcVars->{working_dir}/$zipped_data_array[0]" );
            `cd $ProcVars->{working_dir}; /usr/bin/unzip $zipped_data_array[0]`;
        }
        else {
            LogInfo( $ProcVars, "ERROR: Audit failed. The value in $unzipped_index_file is $IndexCount while the number of files in $zipped_data_array[0] is $DataCount" );
            die;
        }

        LogInfo( $ProcVars, "Audit successful: The value in $unzipped_index_file is equal to the number of files in $zipped_data_array[0].  Both have a count of $IndexCount" );
    }

    LogFooter($ProcVars);

    return \@unique_dates;
}

sub MoveToHadoop {
    my $ProcVars = shift;
    my $date_partition;
    my $hadoop_path;

    LogHeader($ProcVars);

    foreach my $file ( @{ $ProcVars->{file_list} } ) {
        $hadoop_path = "$ProcVars->{hadoop_expn_root}/loadevent=$ProcVars->{load_event_id}/sourcefile_dt=";
        $file =~ m/-(\d{8})-/;
        $date_partition = $1;
        $hadoop_path .= $date_partition;

        LogInfo( $ProcVars, "Writing $file to $hadoop_path" );
        HadoopCreate( $ProcVars, $file, $hadoop_path );
    }

    LogFooter($ProcVars);
}

sub MoveToS3 {
    my $ProcVars = $_[0];
    my $file_list = $_[1];
    my $file;


    LogHeader($ProcVars);

    foreach $file ( @{ $file_list }){
        UploadFileToS3($ProcVars, 
                    $file,
                    $ProcVars->{s3_bucket_name},
                    "$ProcVars->{s3_warehouse_prefix}/" .
                    "$ProcVars->{staging_database}/" .
                    "$ProcVars->{staging_table}/" .
                    "loadevent=$ProcVars->{load_event_id}/" .
                    CreatePartitionSpec( $ProcVars, 'sourcefile_dt', $file, '-(\d{8})-') .
                    "/" . basename($file));
    }

    LogFooter($ProcVars);

}

sub ModifyAndCombineCSV {
    my $ProcVars = $_[0];
    my $unique_dates = $_[1];

    LogHeader($ProcVars);

    my @csv_files;
    my @file_list;
    my @columns_in_row;
    my $partnernotification_id;
    my $combined_file_name;
    my $max_columns = 9;
    my $add_columns;
    my $added_commas;

    foreach my $unique_dates ( @{ $unique_dates } ) {
        @csv_files = glob "$ProcVars->{working_dir}/*SD-UPR*$unique_dates*csv";

        LogInfo( $ProcVars, "Adding partnernotification_id to all files with file name like $ProcVars->{working_dir}/SD-UPR*$unique_dates*csv" );

        foreach my $csv_file (@csv_files) {
            $csv_file =~ m/(\d+).csv/;
            $partnernotification_id = $1;

            open my $in,  '<', $csv_file       or die "Can't read file: $!";
            open my $out, '>', "$csv_file.new" or die "Can't write file: $!";

            while (<$in>) {
                chomp $_;
                $_ =~ s/\r//g;

                @columns_in_row = split( ",", $_ );
                $add_columns = $max_columns - ( scalar @columns_in_row );

                for ( my $i = 0; $i < $add_columns; $i++ ) {
                    push( @columns_in_row, '' );
                }

                push( @columns_in_row, $partnernotification_id );

                print $out join( ',', @columns_in_row ) . "\n";
            }

            close $out;
            rename "$csv_file.new", $csv_file;
        }

        ( $combined_file_name = @csv_files[0] ) =~ s/(.*)-\d+.csv/$1/g;
        $combined_file_name = $combined_file_name . ".$ProcVars->{load_event_id}.csv";

        LogInfo( $ProcVars, "Combining all modified CSV files into one file called $combined_file_name" );
        `cd $ProcVars->{working_dir}; cat *$unique_dates*csv > $combined_file_name`;
        push( @file_list, $combined_file_name );
    }

    LogFooter($ProcVars);

    return \@file_list;
}

sub AddExternalPartitions {
    my $ProcVars = shift;

    LogHeader($ProcVars);

    LogInfo( $ProcVars, "Adding partitions to $ProcVars->{expn_rw_db}.experian_driving_ext: loadevent=$ProcVars->{load_event_id} and sourcefile_dt= @{$ProcVars->{unique_dates}}" );
    $ProcVars->{logger}->info("\n");

    foreach my $date ( @{ $ProcVars->{unique_dates} } ) {
        ExecuteHiveScript( $ProcVars, "alter table $ProcVars->{expn_rw_db}.experian_driving_ext add IF NOT EXISTS partition (loadevent='$ProcVars->{load_event_id}',sourcefile_dt='$date')" );
    }

    LogFooter($ProcVars);
}

sub AddGluePartitions {
    my $ProcVars = $_[0];
    my $unique_dates = $_[1];
    my $date;

    LogHeader($ProcVars);

    foreach $date ( @{$unique_dates}){
        AddGlueCatalogTablePartition( $ProcVars, 
                                    $ProcVars->{staging_database},
                                    $ProcVars->{staging_table},
                                    "loadevent=$ProcVars->{load_event_id}/" .
                                    "sourcefile_dt=$date"
                                    );
    }

    LogFooter($ProcVars);

}

sub BackupAndCompress {
    my $ProcVars = $_[0];
    my $file_list = $_[1];
    my $inbound_file_regex = $_[2];
    my $backup_file_prefix = $_[3];
    my $file_mask;
    my @files_to_compress;
    my @files_to_delete;

    LogHeader($ProcVars);

    foreach my $file ( @{ $file_list } ) {
        $file =~ m/($inbound_file_regex)/;
        #$file =~ m/(SD-UPR-\d{8})/;
        $file_mask = $1;

        $ProcVars->{logger}->info("\n");
        LogInfo( $ProcVars, "***PACKAGE AND COMPRESS***" );

        @files_to_compress = glob "$ProcVars->{inbound_dir}/$file_mask*";
#        @files_to_compress = glob "$ProcVars->{inbound_dir}/$file_mask*zip";

        LogInfo( $ProcVars, "Compressing files @files_to_compress into $backup_file_prefix.$file_mask.$ProcVars->{load_event_id}.tar.gz" );

        my $tar_command = "cd $ProcVars->{inbound_dir}; tar -cvzf $ProcVars->{working_dir}".
                          "/$backup_file_prefix.$file_mask.$ProcVars->{load_event_id}.tar.gz $file_mask* --remove-files";
        `$tar_command`;

        $ProcVars->{logger}->info("\n");
        LogInfo( $ProcVars, "***MOVE TO BACKUP***" );

        UploadFileToS3($ProcVars, 
                    "$ProcVars->{working_dir}/$backup_file_prefix.$file_mask.$ProcVars->{load_event_id}.tar.gz",
                    $ProcVars->{s3_bucket_name},
                    "$ProcVars->{s3_backup_prefix}/" .
                    "$backup_file_prefix.$file_mask.$ProcVars->{load_event_id}.tar.gz");

        unlink "$ProcVars->{working_dir}/$backup_file_prefix.$file_mask.$ProcVars->{load_event_id}.tar.gz";

        $ProcVars->{logger}->info("\n");
        LogInfo( $ProcVars, "***CLEANUP WORK DIRECTORY***" );

        my @files_to_delete = glob "$ProcVars->{working_dir}/$file_mask*";
        LogInfo( $ProcVars, "Deleting all files with pattern $ProcVars->{working_dir}/$file_mask*" );
        foreach (@files_to_delete) {
            unlink $_;
        }
    }

    LogFooter($ProcVars);
}

sub FindAQBDataSets {
    my $ProcVars = $_[0];
    my @warn_msg;

    #LogInfo( $ProcVars, "\n******************************************\n* Checking that all required files exist *\n******************************************\n" );

    opendir DIR, $ProcVars->{inbound_dir} or LogDie( $ProcVars, "Failed to open inbound_dir: $ProcVars->{inbound_dir} for file input" );

    my $file_prefix = $ProcVars->{InputFile};   #  Job_parm ! 1307	InputFile	AQB_BD_NWI_BIND
    my $file_filter = "^$file_prefix" . '_(\d{8})\.csv$';

    LogInfo( $ProcVars, "Opened directory: $ProcVars->{inbound_dir} search for AQB files" ); 
    LogInfo( $ProcVars, "Search with REGEX: $file_filter" );
    my @AQB_files = grep( /$file_filter/, readdir DIR );
    closedir DIR;

    LogInfo( $ProcVars, "Final list: " . Dumper( \@AQB_files ) );

    if ( scalar(@AQB_files) == 0 ) {
        LogWarn( $ProcVars, "No data sets found, nothing to process." );
        UpdateJobEventIToS($ProcVars);
        #LogInfo( $ProcVars, "\n*******************\n* SCRIPT COMPLETE *\n*******************\n" );
        exit 0;
    }

    return ( \@AQB_files );

}
#This function is not used for AQB Acquire:
sub RemoveFilesFromWorking {
    my $ProcVars    = $_[0];
    my $file_data   = $_[1];
    my $error       = 0;
    my $file_prefix = $ProcVars->{InputFile};
    #LogInfo( $ProcVars, "\n******************************************\n* Removing files from working dir  *\n*************************\n" );

    opendir DIR, $ProcVars->{working_dir} or LogDie( $ProcVars, "Failed to open inbound_dir: $ProcVars->{working_dir} for file input" );
    my $file;
    my @endfiles = grep( /$file_prefix/, readdir(DIR) );
    foreach $file (@endfiles) {
        my $src = "$ProcVars->{working_dir}/$file";

        LogInfo( $ProcVars, "Removing File: $src \n" );
        try {

            DeleteFile( $ProcVars, $src );

        }
        catch {
            LogDie( $ProcVars, "Delete failed, this file has not been deleted yet: $src \n" );
            $error++;
        };
    }
    closedir(DIR);
}

sub GetSourceAuditCount {
    my $ProcVars    = $_[0];
    my $file_data   = $_[1];
    my $file_prefix = $ProcVars->{InputFile};

    #LogInfo( $ProcVars, "\n***************************\n* Get Source audit values *\n***************************\n" );

    foreach my $file (@$file_data) {
        chomp $file;
        if ( $file =~ /\.csv/ ) {
            GetFileRecordCount( $ProcVars, $ProcVars->{inbound_dir} . "/" . $file );
            $ProcVars->{job_audit_total} = $ProcVars->{file_record_count};
            $ProcVars->{job_audit_desc}  = "$file";
            InsertJobAuditSourceCount($ProcVars);
        }
    }

    #LogInfo( $ProcVars, "Source Audit Count for all AQB files have been stored in the Job Audit table successfully." );
}

1;
