use strict;
use warnings;
use Getopt::Long;
use Data::Dumper;
use DBI;
use DIF;
use DIF::HadoopExec;
use Try::Tiny;
use Tie::File;
use GDW::HiveConnect;
use DateTime;
use DateTime::Duration;

sub Initialize {
    my $ProcVars = $_[0];
    my $send_email = 0;

    GetOptions(
        "job_cd|j=s"    => \$ProcVars->{job_cd},
        "email|e"       => \$send_email,
        "path|p=s"      => \$ProcVars->{hadoop_ims_root},
    );

    if (not $send_email){
        $ProcVars->{noemail} = 1;
    }

    if ( not defined( $ProcVars->{job_cd} ) ) {
        die "Must supply job_cd to script";
    }

    ProcessSetup($ProcVars);

}

sub GetReadyBatcheventsByLoadEvent {
    my $ProcVars = $_[0];
    my $batch_id_list;
    my $batch_id_concat_list;
    my $max_batchid;
	
	LogInfo( $ProcVars, "\n***************************************\n* Get Ready Batch ID By Load Event ID *\n***************************************\n" );
	
	if (not defined ($ProcVars->{load_event_id_list})) {
		LogDie ($ProcVars, "Load event ID's not defined in hash.  Exiting script.");
	};
	
	
	
    my $load_id_sql =  "select case job_cd
    when '1301' then batches[2]||batches[3]||'~'||batches[1] 
    when '1302' then batches[2]||batches[3]||batches[4]||batches[5]||'00~'||batches[1] 
    else null   end as batches
    from (  select  
            CASE job_cd
            WHEN '1301' THEN regexp_matches(description,'.*/(.*?)_.*(\\d{8})_(\\d{4}).*')
            WHEN '1302' THEN regexp_matches(description,'.*/(.*?)_.*(\\d{4})-(\\d{2})-(\\d{2})_(\\d{2}).*')
            ELSE NULL END AS batches,
            job_cd
            FROM $ProcVars->{control_schema}.job_audit 
            where load_event_id in ($ProcVars->{load_event_id_list})
        ) subquery
    group by batches,job_cd
    order by batches";


    # my $load_id_concat_sql = "select LISTAGG(batches, ',') WITHIN GROUP (ORDER BY batches) FROM  (select distinct  (CASE WHEN job_cd = '1301' THEN ''''||substr(description,-21,8)||substr(description,-12,4)||''''
    #                                WHEN job_cd = '1302' THEN ''''||substr(description,-22,4)||substr(description,-17,2)||substr(description,-14,2)||substr(description,-11,2)||'00'''
    #                                ELSE NULL 
    #                           END) as batches 
    #                   from $ProcVars->{control_schema}.job_audit where load_event_id in ($ProcVars->{load_event_id_list}))
    #                   group by 'temp'";
     
    my $maxbatch_id_sql = "select max(b.batches) from (
    SELECT 
    CASE job_cd
    WHEN '1301' then batches[2]||batches[3]||'~'||batches[1] 
    WHEN '1302' then batches[2]||batches[3]||batches[4]||batches[5]||'00~'||batches[1] 
    ELSE null
    END AS batches
    FROM(
        SELECT  
        CASE job_cd
        WHEN '1301' THEN regexp_matches(description,'.*/(.*?)_.*(\\d{8})_(\\d{4}).*')
        WHEN '1302' THEN regexp_matches(description,'.*/(.*?)_.*(\\d{4})-(\\d{2})-(\\d{2})_(\\d{2}).*')
        ELSE NULL
        END AS batches,
        job_cd
        FROM $ProcVars->{control_schema}.job_audit 
        WHERE load_event_id in ($ProcVars->{load_event_id_list})
        ) a
    group by batches,job_cd
    order by batches
    ) b
";


    LogInfo( $ProcVars, "\n***************************************\n* Batch ID SQL executed = $load_id_sql *\n***************************************\n" );
    #LogInfo( $ProcVars, "\n***************************************\n* Concatenated Batch ID SQL executed = $load_id_concat_sql *\n***************************************\n" );
    LogInfo( $ProcVars, "\n***************************************\n* Max Batch ID SQL executed = $maxbatch_id_sql *\n***************************************\n" );

	my $load_id_qry = $ProcVars->{ctldbh}->prepare( $load_id_sql );
	#my $load_id_concat_qry = $ProcVars->{ctldbh}->prepare( $load_id_concat_sql );
    my $max_batchid_qry = $ProcVars->{ctldbh}->prepare( $maxbatch_id_sql );  
    if ( defined($DBI::errstr) ) {
        LogDie( $ProcVars, "Database error occurred when trying to query Job Event for Ready Records By Source Code : $DBI::errstr" );
    }    
    
    $load_id_qry->execute;
    #$load_id_concat_qry->execute;
    $max_batchid_qry->execute;

    $load_id_qry->bind_columns( \my ($batch_id) );
    #$load_id_concat_qry->bind_columns( \my ($batch_id_str) );
    $max_batchid_qry->bind_columns( \my ($max_batch_id_str) );
    
    
    $load_id_qry->fetch;
    #$load_id_concat_qry->fetch;
    $max_batchid_qry->fetch;
    
    $batch_id_list = $batch_id;
    # $batch_id_concat_list = $batch_id_str;
    $max_batchid = $max_batch_id_str;
    
    if ( defined $batch_id ) {
        while ( $load_id_qry->fetch ) {
            $batch_id_list .= ',' . $batch_id;
        }
    }
    
    if ( not defined($batch_id_list) ) {
        LogInfo( $ProcVars, "No batch Ids Ready for Processing. Exiting Script." );
        exit 0;
    }


    # if ( not defined($batch_id_concat_list) ) {
    #     LogInfo( $ProcVars, "No batch Ids Ready for Processing. Exiting Script." );
    #     exit 0;
    # }
    
    if ( not defined($max_batchid) ) {
        LogInfo( $ProcVars, "No max batch Ids Ready for Processing. Exiting Script." );
        exit 0;
    }
    $ProcVars->{batch_id_list} = $batch_id_list;
    # $ProcVars->{batch_id_concat_list} = $batch_id_concat_list;
    $ProcVars->{current_max_batch_id} = $max_batchid;
    
        
    LogInfo( $ProcVars, "The following batch id's is ready for processing and has been assigned to the hash: $ProcVars->{batch_id_list}" );
    #LogInfo( $ProcVars, "The following concatenated list of batch id's is ready for processing and has been assigned to the hash: $ProcVars->{batch_id_concat_list}" );
    LogInfo( $ProcVars, "The following concatenated max batch id is ready for processing and has been assigned to the hash: $ProcVars->{current_max_batch_id}" );
    return;
	
}

sub UpdateLoadEventIdListIToS {

    my $ProcVars = $_[0];

    LogInfo( $ProcVars, "\n******************************************************\n* Update Load Event Id List from InProgress to Success *\n******************************************************\n" );

    my @load_event_list = split( ',', $ProcVars->{load_event_id_list} );

    foreach my $load_event_id (@load_event_list) {
        $ProcVars->{load_event_id} = $load_event_id;
        try {
            UpdateJobEventIToS($ProcVars);
        }
        catch {
            LogWarn( $ProcVars, 'Failure while calling UpdateLoadEventIdListRToI.' );
            UpdateLoadEventErrorListAndDie($ProcVars);
	      return 1;
        };
    }
    return 0;
}

sub InsertMultipleLoadEventIDListAsR {
	my $ProcVars = $_[0];
	LogInfo( $ProcVars, "\n**********************************\n* Inserting Ready Records *\n**********************************\n" );
	my $temp_load_id = $ProcVars->{load_event_id};
    my @load_event_id_list = split( ',', $ProcVars->{load_event_id_list} );
    foreach my $key ( keys %{$ProcVars} )
    {  
        if ( $key =~ 'next_job_cd' ) {
       
            $ProcVars->{next_job_cd} = ${$ProcVars}{$key}; 
            foreach my $load_event_id (@load_event_id_list) {
       
                $ProcVars->{load_event_id} = $load_event_id;
    	        try {
    	            InsertJobEventReady($ProcVars);
                }
                catch {
                    LogWarn( $ProcVars, 'Failure while calling InsertMultipleLoadEventIDListAsR.' );
                    UpdateLoadEventErrorListAndDie($ProcVars);
	                return 1;
                };
            }   
        }
    }      
    $ProcVars->{load_event_id} = $temp_load_id;
}

sub LoadCanonicalModel {

    #my %ProcVars = $_[0];
    my $ProcVars = $_[0];
    my @result;
    my $connection;
    my $count=0;

    LogInfo( $ProcVars, "\n******************************************************\n* Start loading Cannonical model *\n******************************************************\n" );

    my @batch_id_list = split( ',', $ProcVars->{batch_id_list} );

    foreach my $batch_id (@batch_id_list) {
    	
    my @val = split('~', $batch_id);    
    $batch_id=$val[0];
    $ProcVars->{batch_id} = $val[0];
    $ProcVars->{source_cd} = $val[1];
    	
    	
        $ProcVars->{batch_id} = $batch_id;
        $count++;
        my $ temp_var;
        my $hour = substr($batch_id,8,2);
        if($hour eq "24") 
        { $temp_var = '00';} 
        else 
        {$temp_var = substr($batch_id,8,2);}
        
        my ($var1,$var2,$var3,$var4,$var5,$var6,$var7,$var8,$var9,$var10,$var11)=(substr($batch_id,0,4),'-',substr($batch_id,4,2),'-',substr($batch_id,6,2),' ',$temp_var,':',substr($batch_id,10,2),':00','.000000');
        $ProcVars->{sourcefilename_ts}=$var1.$var2.$var3.$var4.$var5.$var6.$var7.$var8.$var9.$var10.$var11;
        try {
            LogInfo($ProcVars,"Sql Log File for batch :$ProcVars->{batch_id} is $ProcVars->{sql_logfile_path}/$ProcVars->{sql_logfile_name}$ProcVars->{batch_id}.txt");
            $connection = new HiveSQLConnection($ProcVars->{hive_logon_file}, "$ProcVars->{sql_logfile_path}/$ProcVars->{sql_logfile_name}$ProcVars->{batch_id}.txt");
       	    @result = $connection->runQueryFromFile("$ProcVars->{sql_dir}/$ProcVars->{sql_file_name}", %$ProcVars);
	        $connection->endConnection();
        }
        catch {
            LogWarn( $ProcVars, 'Failure while calling LoadCanonicalModel.' );
            LogInfo($ProcVars, "check this : @result");
            UpdateLoadEventErrorListAndDie($ProcVars);
	        #return 1;
        };
    }
    return 0;
}

sub IdentifyPartitionsToPurge {

    my $ProcVars=$_[0];
    my $months_old=$_[1];
    my ( %TableSpecs, @IdentifiedPartitions, @QueryResult, $partition_spec, $PrtnDt, $Duration, $exception);
    my $key_exists = 0;
    my $email_body="Failed to parse into dates the following partitions:\n\n";

    LogHeader($ProcVars);
    $ProcVars->{log_indent}++;

    my $CurDt = DateTime->now();
    my $CurrentBatch = $CurDt->year().$CurDt->month().$CurDt->day()."0000";

    if(not defined $months_old) {die "ERROR: The function expects an integer as the second argument. The integer represents the number of months prior to current and is used to identify what partitions to purge.";}

    foreach my $key (%$ProcVars){

        if(defined $key && $key =~ /^purge_(.*)/ ){

            $key_exists=1;

            my $db = $1 =~ /raw/ ? $ProcVars->{srdp_rw_db} : $ProcVars->{srdp_cncl_db};

            foreach my $tbl (split ',',$ProcVars->{$key}){

                my $db_and_tbl = $db . '.' . $tbl;
                $ProcVars->{logger}->info("\n");
                LogInfo($ProcVars,"TABLE: $db_and_tbl");
                $ProcVars->{logger}->info("\n");
                $ProcVars->{log_indent}++;

                @QueryResult = ExecuteHiveScript($ProcVars, "show partitions $db_and_tbl;");

                foreach my $row (@QueryResult){

                    $partition_spec= $$row[0];

                    if($partition_spec=~/batch|load_date|score_date/){
                        $partition_spec =~ m/.*[batch|load_date|score_date]=(conv)?(\d{4})-?(\d{2})-?(\d{2})/;
                        try{
                            $PrtnDt=DateTime->new(
                                    year => $2,
                                    month => (length $3 < 2 ? '0'.$3 : $3),
                                    day => (length $4 < 2 ? '0'.$4 : $4)
                                    );
                            $Duration = $PrtnDt->delta_md($CurDt);
                            if($Duration->delta_months()>=$months_old && $PrtnDt->year() < $CurDt->year()){
                                LogInfo($ProcVars,"PARTITION: $partition_spec");
                                push @IdentifiedPartitions, $partition_spec;
                            }
                        }
                        catch   {
                            $exception = $_;
                            $email_body = $email_body . "Table: $db_and_tbl\n\nPartition: $partition_spec\n\n$exception\n\n";
                        }

                    }

                }
                $ProcVars->{log_indent}--;
                if(scalar @IdentifiedPartitions > 0){
                    $TableSpecs{$db_and_tbl}= [@IdentifiedPartitions];
                    @IdentifiedPartitions=();
                }
            }
        }
    }

    if(not $key_exists) {die "ERROR: The purge.... does not exist in the hash. The function expects at least one key starting with purge to be defined with a list of tables";}

    SendAnEmail($ProcVars,$ProcVars->{audit_email_to},$email_body,"Exceptions while identifying partitions to purge") unless not defined $exception;

    $ProcVars->{log_indent}--;
    LogFooter($ProcVars);

    $ProcVars->{PurgeTableSpecs}=\%TableSpecs;

    return %TableSpecs;
}

sub ClearPurgeTables {

    my $ProcVars=$_[0];
    my $key_exists = 0;
    LogHeader($ProcVars);
    $ProcVars->{log_indent}++;

    foreach my $key (%$ProcVars){

        if(defined $key && $key =~ /^purge_(.*)/ ){

            $key_exists=1;

            my $db = $1 =~ /raw/ ? $ProcVars->{srdp_rw_db} : $ProcVars->{srdp_cncl_db};

            foreach my $tbl (split ',',$ProcVars->{$key}) {

                my $purge_db_and_tbl="$ProcVars->{srdp_rchv_db}.${tbl}_purge";

                $ProcVars->{logger}->info("\n");
                LogInfo($ProcVars,"DROP/RECREATE: $purge_db_and_tbl");
                $ProcVars->{logger}->info("\n");
                $ProcVars->{log_indent}++;

                ExecuteHiveScript($ProcVars, "drop table if exists $purge_db_and_tbl;
                                            create table $purge_db_and_tbl like $db.$tbl;
                                            alter table $purge_db_and_tbl SET TBLPROPERTIES ('EXTERNAL'='FALSE');");

                $ProcVars->{log_indent}--;

            }

        }
    }

    if(not $key_exists) {die "ERROR: The purge.... does not exist in the hash. The function expects at least one key starting with purge to be defined with a list of tables";}

    $ProcVars->{log_indent}--;
    LogFooter($ProcVars);

}

sub MovePartionsToPurgeTables {

    my $ProcVars=$_[0];
    my ($partition_specs,$partition_specs_path);

    $ProcVars->{recovery_file_name} = "$ProcVars->{log_dir}/$ProcVars->{log_file_name}";
    $ProcVars->{recovery_file_name} =~ s/(.*).log$/\1.recovery.sql/;
    open(my $fh, '>', $ProcVars->{recovery_file_name}) or  LogDie( $ProcVars, "Could not open or create logfile: $ProcVars->{hive_log_file_name}");

    LogHeader($ProcVars);
    $ProcVars->{log_indent}++;

    if(not exists $ProcVars->{PurgeTableSpecs}) {die "ERROR: The PurgeTableSpecs does not exist in the hash. The function expects the key of PurgeTableSpecs to be defined in the hash";}

    my $TableSpecs = $ProcVars->{PurgeTableSpecs};

    foreach my $src_db_and_tbl (keys %$TableSpecs) {

        $src_db_and_tbl=~ m/^(.*)\.(.*)$/;
        my $src_db=$1;
        my $src_tbl=$2;
        my $tgt_tbl="${src_tbl}_purge";

        $ProcVars->{logger}->info("\n");
        LogInfo($ProcVars,"MOVING PARTITIONS: $src_db_and_tbl to $ProcVars->{srdp_rchv_db}.$tgt_tbl");
        $ProcVars->{logger}->info("\n");
        $ProcVars->{log_indent}++;

        $partition_specs = $TableSpecs->{$src_db_and_tbl};

        LogInfo($ProcVars,"Number of partitions found: ". scalar @$partition_specs);

        foreach my $partition_spec (@$partition_specs){

            $partition_specs_path = $partition_spec;

            $partition_spec=~ s/(.*?)=(.*?)(\/|$)/$1='$2'$3/g;

            $partition_spec=~ s/\//,/g;

            $ProcVars->{logger}->info("\n");
            LogInfo($ProcVars,"PARTITION: $partition_specs_path");
            $ProcVars->{logger}->info("\n");
            $ProcVars->{log_indent}++;

            try{ExecuteHiveScript( $ProcVars , "LOAD DATA INPATH '$ProcVars->{hive_root_dir}/$src_db.db/$src_tbl/$partition_specs_path' INTO TABLE $ProcVars->{srdp_rchv_db}.$tgt_tbl PARTITION ($partition_spec)");
            print $fh "LOAD DATA INPATH '$ProcVars->{hive_root_dir}/$ProcVars->{srdp_rchv_db}.db/$tgt_tbl/$partition_specs_path' INTO TABLE $src_db.$src_tbl PARTITION ($partition_spec);\n";
            }catch{
                    if ( $_ =~ /No files matching path.*$ProcVars->{hive_root_dir}\/$src_db.db\/$src_tbl\/$partition_specs_path/ ) {
                    ExecuteHiveScript($ProcVars, "alter table $ProcVars->{srdp_rchv_db}.$tgt_tbl add partition ($partition_spec)");
                    print $fh  "alter table $src_db.$src_tbl add partition ($partition_spec);\n";

                    $ProcVars->{log_indent}--;
                 }else{
                    die;
                 }
            }

            LogInfo($ProcVars,"Removing partition $partition_spec from hive metastore for $src_db_and_tbl");

            ExecuteHiveScript($ProcVars, "alter table $src_db_and_tbl drop partition ($partition_spec)");

        $ProcVars->{log_indent}--;
        }

        $ProcVars->{log_indent}--;
    }

    close $fh;
    $ProcVars->{log_indent}--;
    LogFooter($ProcVars);

}

sub MoveFilesToBackup {
    my $ProcVars  = $_[0];
    my $filesets = $_[1];
    my (%seen,@batches,@files_to_backup,$file_filter);

    if($ProcVars->{job_dtl_source_cd}=~/NIMS/){
        $file_filter="$ProcVars->{InputFile1}_.*(\\d{8}_\\d{4}_\\d+)";
    } elsif ($ProcVars->{job_dtl_source_cd}=~/NOCT/){
        $file_filter="^$ProcVars->{InputFile1}.*(\\d{4}-\\d{2}-\\d{2}[-_]\\d{4})";
    } else {
        LogDie($ProcVars, "job_dtl_source_cd in ProcVars is not defined or is not NIMS or NOCT.");
    }

    foreach my $fileset (@$filesets) {
      foreach my $file (@$fileset){
        $file=~/$file_filter/;
        if(defined $1){
            push @batches, $1 unless $seen{$1}++;
        }
      }
    }

    LogDie($ProcVars, "Unable to identify batches using file name regex filter $file_filter on following file set.\n". Dumper($filesets)) if scalar @batches == 0;

    foreach my $batch (@batches){
      opendir DIR,  $ProcVars->{inbound_dir} or LogDie( $ProcVars, "Failed to open inbound_dir: $ProcVars->{inbound_dir} for file input" );
      push @files_to_backup , grep(/$batch/,readdir(DIR));
      close DIR;
    }

    my $output = `cd $ProcVars->{inbound_dir}; tar -cvzf $ProcVars->{working_dir}/$ProcVars->{InputFile1}_$ProcVars->{load_event_id}.tar.gz @files_to_backup --remove-files 2>&1`;
    
    $? ? LogDie( $ProcVars, "Encountered an error while creating archive, here is the stderr for your perusal:\n$output" ) : LogInfo( $ProcVars, "Files archived into $ProcVars->{working_dir}/$ProcVars->{InputFile1}_$ProcVars->{load_event_id}.tar.gz:\n$output") ;

    UploadFileToS3($ProcVars, 
                   "$ProcVars->{working_dir}/".
                   "$ProcVars->{InputFile1}_$ProcVars->{load_event_id}.tar.gz",
                   $ProcVars->{s3_bucket_name},
                   "$ProcVars->{s3_backup_prefix}/" .
                   "$ProcVars->{InputFile1}_$ProcVars->{load_event_id}.tar.gz");

    unlink "$ProcVars->{working_dir}/$ProcVars->{InputFile1}_$ProcVars->{load_event_id}.tar.gz";
}

1;
