use strict;
use warnings;
use DIF;
use DIF::AWS::S3;
use POSIX;
use GDW::HiveConnect;
use DateTime;

sub ListS3Contents {
    my $ProcVars = $_[0];
    my $bucket   = $_[1];
    my $prefix   = $_[2];
    my $aws_std_out;

    LogHeader($ProcVars);

    if ( !defined($bucket ) ) {
        LogDie( $ProcVars, "ERROR: Not all arguments were passed into the function. The function should be called like: ListS3Contents(Hash, Bucket, [prefix])" );
    }

    $aws_std_out = qx(aws s3api head-bucket --bucket $bucket 2>&1);

    if ( $? != 0 ) {
        LogInfo( $ProcVars, "ERROR: The bucket s3://$bucket cannot be accessed. $aws_std_out" );
        die;
    }

    my $aws_cmd = "aws s3api list-objects-v2 --bucket $bucket --query 'Contents[?Size!=`0`].Key'";
    my $s3_path = "s3://$bucket";

    if(defined($prefix)){
        $s3_path = "$s3_path/$prefix" ;
        $aws_cmd = $aws_cmd . " --prefix $prefix";
    }

    LogInfo( $ProcVars, "Retrieving list of contents in $s3_path" );

    $aws_std_out = qx($aws_cmd 2>&1);

    if ( $? == 0 ) {
        LogInfo( $ProcVars, $aws_std_out );
    }
    else {
        LogInfo( $ProcVars, "ERROR: There was an issue listing the bucket. $aws_std_out" );
        die;
    }

    if ($aws_std_out eq "null\n"){
        LogWarn( $ProcVars, "Returning an empty list");
        LogFooter($ProcVars);
        return ();
    } else {
        my $file_list = decode_json($aws_std_out);
        LogInfo( $ProcVars, "Returning a list containing " . scalar @{$file_list} . " files.");
        LogFooter($ProcVars);
        return @{$file_list};
    }

}


sub CreatePartitionSpec {
    
    my $ProcVars              = $_[0];
    my $partition_column_name = $_[1];
    my $file_name             = $_[2];
    my $date_regex_pattern    = $_[3];
    my $partition_spec;

    LogHeader( $ProcVars );

    if (not defined $partition_column_name){
        LogInfo( $ProcVars, "Must supply the partition column name");
        die;
    }

    my $processing_date;

    if ( exists $ProcVars->{partition_date} and $ProcVars->{partition_date} =~ m/\d+/ ) {
        $processing_date = $ProcVars->{partition_date};
    }
    elsif ( defined $file_name  ){

        if (not defined $date_regex_pattern) {
            LogInfo($ProcVars, "Must supply date regex pattern when file name passed to subroutine");
            die;
        }

        $file_name =~ m/$date_regex_pattern/;

        $processing_date = $1;

        if (not defined $processing_date){
            LogInfo($ProcVars, "Unable to define partition value using regex pattern $date_regex_pattern" .
                               " given supplied file name $file_name");
            die;
        }

    }
    else {
        $processing_date = strftime "%Y%m%d", localtime;
    }

    $partition_spec = "$partition_column_name=$processing_date";

    LogInfo($ProcVars, "Returning partition specification: $partition_spec");

    LogFooter( $ProcVars );

    return $partition_spec;

}

sub AddGlueCatalogTablePartition {

    my $ProcVars       = $_[0];
    my $database_name  = $_[1];
    my $table_name     = $_[2];
    my $partition_spec = $_[3];
    my $aws_cmd;
    my $aws_std_out;
    my %storage_descriptor;
    my $s3_location;
    my %partition_input;
    my $json_encoded_partition_input;
    my @partition_values;

    LogHeader( $ProcVars);

    $aws_cmd = "aws glue get-table --database-name $database_name " .
                    "--name $table_name --query Table.StorageDescriptor " .
                    "--region $ProcVars->{aws_region}";

    $aws_std_out = qx($aws_cmd 2>&1);

    if ( $? == 0 ) {
        LogInfo( $ProcVars, "Successfully retrieved table storage descriptor" .
                            " for $database_name.$table_name." );
    }
    else {
        LogInfo( $ProcVars, "ERROR: There was an issue retrieving table " .
                            "storage descriptor. $aws_std_out" );
        die;
    }

    %storage_descriptor = %{decode_json($aws_std_out)};

    $storage_descriptor{Location} = "$storage_descriptor{Location}/$partition_spec";

    $partition_input{StorageDescriptor} = \%storage_descriptor;

    foreach my $spec (split('/',$partition_spec)){
        my ($col,$value) = split('=',$spec);
        push(@partition_values,$value);
    }

    $partition_input{Values} = \@partition_values;

    $json_encoded_partition_input = encode_json(\%partition_input);

    $aws_cmd = "aws glue create-partition --database-name $database_name " .
                "--table-name $table_name --partition-input '$json_encoded_partition_input' " .
                "--region $ProcVars->{aws_region}";

    $aws_std_out = qx($aws_cmd 2>&1);

    if ( $? == 0 ) {

        LogInfo( $ProcVars, "Successfully created partition $partition_spec" );

    }
    else {

        if($aws_std_out =~ m/AlreadyExistsException/){

            LogInfo($ProcVars, "Partition already exists");

        } else {

            LogInfo( $ProcVars, "ERROR: There was an issue creating the partition" .
                                " $aws_std_out" );
            die;
        }
        
    }

    LogFooter($ProcVars);

}

sub IdentifyInboundFiles {
    my $ProcVars             = $_[0];
    my $inbound_dir          = $_[1];
    my $inbound_file_pattern = $_[2];

    LogHeader( $ProcVars);

    opendir DIR, $inbound_dir or LogDie( $ProcVars, "Failed to open inbound_dir: $inbound_dir" );

    my @file_list = grep( /$inbound_file_pattern/, readdir DIR );

    closedir DIR;

    LogInfo( $ProcVars, "Found following files in $inbound_dir:\n@file_list" );

    LogFooter( $ProcVars );

    return \@file_list;
}

sub RemoveGlueCatalogPartitions {

    my $ProcVars              = $_[0];
    my $database_name         = $_[1];
    my $table_name            = $_[2];
    my @partition_values      = @{$_[3]};
    my $aws_cmd;
    my $aws_std_out;

    LogHeader( $ProcVars);

    $aws_cmd = "aws glue batch-delete-partition --database-name $database_name " .
                "--table-name $table_name --partitions-to-delete Values=" .
                join(',',@partition_values) .
                " --region $ProcVars->{aws_region}";

    $aws_std_out = qx($aws_cmd 2>&1);

    if ( $? == 0 ) {

        LogInfo( $ProcVars, "Successfully deleted partitions " . 
                            join(',',@partition_values) );

    }
    else {

        LogInfo( $ProcVars, "ERROR: There was an issue deleting the partition(s)" .
                            " $aws_std_out" );
        die;

    }

    LogFooter( $ProcVars );
}

sub HiveDBConnectWithRetry{

    my $ProcVars = shift;
    my $attempt  = shift // 1;
    my $sleep_interval = ( 1 + (60 * $attempt) - 60 ) + int rand(60 * $attempt);

    try{
        HiveDBConnect($ProcVars );
    }catch{
        if( $attempt <= 3) {
            LogInfo( $ProcVars, "Hive connection attempt $attempt failed, trying again in $sleep_interval seconds: $_");
            sleep $sleep_interval;
            $attempt++;
            HiveDBConnectWithRetry($ProcVars , $attempt);
        } else {
            LogDie( $ProcVars, "Hive connection failed 4 consecutive times: $_");
        }

    }

}

sub define_date_and_batch_filter_values {
    my $ProcVars = shift;

    LogHeader( $ProcVars );

    $ProcVars->{date_filter_current}  = DateTime->now()->ymd;

    $ProcVars->{batch_filter_1_mo_ago} = 
        sprintf("%s0000", DateTime->now()->subtract( months => 1 )->ymd(''));

    $ProcVars->{batch_filter_3_mo_ago} = 
        sprintf("%s0000", DateTime->now()->subtract( months => 3 )->ymd(''));

    $ProcVars->{batch_filter_18_mo_ago} = 
        sprintf("%s0000", DateTime->now()->subtract( months => 18 )->ymd(''));

    $ProcVars->{date_filter_2_wks_from_sun} = 
        DateTime->now()->subtract( weeks => 2, days => DateTime->now()->day_of_week())->ymd;

    $ProcVars->{date_filter_18_mo_ago} = 
        DateTime->now()->subtract( months => 18 )->ymd();

    LogInfo( $ProcVars, "Defined 1 month old batch filter value: $ProcVars->{batch_filter_1_mo_ago}");
    LogInfo( $ProcVars, "Defined 3 month old batch filter value: $ProcVars->{batch_filter_3_mo_ago}");
    LogInfo( $ProcVars, "Defined 18 month old batch filter value: $ProcVars->{batch_filter_18_mo_ago}");
    LogInfo( $ProcVars, "Defined current date filter value: $ProcVars->{date_filter_current}");
    LogInfo( $ProcVars, "Defined 2 weeks from last sunday date filter value: $ProcVars->{date_filter_2_wks_from_sun}");
    LogInfo( $ProcVars, "Defined 18 month ago date filter value: $ProcVars->{date_filter_18_mo_ago}");

    LogFooter( $ProcVars );
}

1;