use strict;
use warnings;
use DIF;
use feature qw(switch);
use SmartRide::Common;
use DIF::AWS::S3;

sub ValidateMD5ForAllFiles {
    my $ProcVars   = $_[0];
    my $data_files = $_[1];
    my $file_path  = $_[2];
    LogHeader($ProcVars);
    my @validated_file_list;
    my @invalid_file_list;
    my @warn_msg = ();
    foreach my $file (@$data_files) {
        my $error = 0;
        my $md5File;
        my $m;
        if ( ( -e "$file_path/$file.zip.md5" ) || ( -e "$file_path/$file.zip.MD5" ) ) {
            if ( -e "$file_path/$file.zip.md5" ) {
                $md5File = "$file_path/$file.zip.md5";
            }
            else {
                $md5File = "$file_path/$file.zip.MD5";
            }
            open FH, '<', $md5File or $error = 1;
            if ($error) {
                $m = "Failed to open md5 file: $md5File";
            }
            else {
                my $checksum1 = <FH>;
                chomp $checksum1;
                chdir $file_path;
                my $checksum2 = CheckSumMD5WithoutDigest( $ProcVars, "$file" );
                chomp $checksum2;
                if ( $checksum1 ne $checksum2 ) {
                    $m = "Bad MD5 Checksum on file: $file";
                    push @invalid_file_list, $file;
                }
                else {
                    push @validated_file_list, $file;
                    LogInfo( $ProcVars, "MD5 validated successfully for file : $file" );
                }
            }
        }
        else {
            $m = "No MD5 file found for : $file";
        }
        LogInfo( $ProcVars, $m ) if ($m);
        push @warn_msg, $m if ($m);
    }
    LogFooter($ProcVars);
    return ( \@validated_file_list, \@invalid_file_list, \@warn_msg );
}

sub FilterStrings {
    my ( $strings, $regexes ) = @_;
    my @results;
    for my $string (@$strings) {
        my $flag = 0;
        for my $regex (@$regexes) {
            if ( $string !~ qr/$regex/ ) {
                $flag = 1;
                last;
            }
        }
        push @results, $string if ( $flag == 0 );
    }
    return \@results;
}

sub MergeMultiPartFiles {
    my $ProcVars       = $_[0];
    my $file_set       = $_[1];
    my @warn_msg       = ();
    my @return_dataset = ();
    LogHeader($ProcVars);
    foreach my $file (@$file_set) {
        if ( ( $file =~ /TD_CRT_|TD_SRD_|TD_SRT_|TD_ER_\d+/ ) and ( $file =~ /_1_/ ) and ( $file !~ /md5/ ) ) {
            my @warn = ();
            chomp $file;
            my @list            = ();
            my $file_to_check   = $file;
            $file =~/.*_(\d+)/;
            my $number_of_files = $1;
            my $file_prefix     = substr( $file_to_check, 0, -3 );
            my $outfile         = substr( $file_to_check, 0, -4 );
            for my $i ( 1 .. $number_of_files ) {

                if ( -e "$ProcVars->{working_dir}/$file_prefix$i" . "_" . $number_of_files ) {
                    push @list, "$file_prefix$i" . "_" . $number_of_files;
                }

                else {
                    my $msg = "$file_prefix$i" . "_" . "$number_of_files was expected but not found!!";
                    LogWarn( $ProcVars, $msg );
                    push @warn_msg, $msg if ($msg);
                    push @warn,     $msg if ($msg);
                }
            }
            my $mergefile = MergeFiles( \@list, $ProcVars->{working_dir}, $outfile ) if ( !@warn );
            my $list_to_print = join( ',', @list );
            LogInfo( $ProcVars, "Files $list_to_print merged to $mergefile\n" ) if ( !@warn );
            push @return_dataset, $mergefile if ( !@warn );
        }
    }
    LogFooter($ProcVars);
    return ( \@return_dataset, \@warn_msg );
}

sub CheckSumMD5WithoutDigest {
    my $ProcVars    = $_[0];
    my $source_file = $_[1];
    LogHeader($ProcVars);
    LogInfo( $ProcVars, "CheckSum MD5 *" );

    my $md5 = Digest::MD5->new;

    my $error = 0;
    open( my $CHECKSUM_FH, $source_file ) or $error = 1;

    if ($error) {
        LogWarn( $ProcVars, "Unable to open $source_file for checksum calculation." );
        UpdateLoadEventErrorListAndDie($ProcVars);
    }
    my $checksum = `md5sum $source_file`;

    close $CHECKSUM_FH;

    LogInfo( $ProcVars, "The checksum for file $source_file has successfully been created." );
    LogFooter($ProcVars);
    return $checksum;

}

sub handleHeader {
    my $ProcVars    = $_[0];
    my $source_file = $_[1];
    my $file_path   = $_[2];
    LogHeader($ProcVars);
    my $file_name   = $file_path . "/" . $source_file;
    my $code        = system("sed -i '1d' $file_name");
    if ( $code != 0 ) {
        LogWarn( $ProcVars, "Failed to remove the header for the file: $source_file" );
    }
    else {
        LogInfo( $ProcVars, "Header removed successfully: $source_file" );
    }
    LogFooter($ProcVars);
    return $code;
}

sub handleFooter {
    my $ProcVars           = $_[0];
    my $source_file        = $_[1];
    my $file_path          = $_[2];
    LogHeader($ProcVars);
    my $count_from_trailer = qx "tail -1 $file_path/$source_file|cut -f3 -d'|'";
    my $file_rec_count     = qx(wc -l < $file_path/$source_file);
    my $code               = 0;
    my $record_count       = $file_rec_count - 2;
    if ( $count_from_trailer != $record_count ) {
        $code = 1;
        LogWarn( $ProcVars, "Trailer count and record count not matching for: $source_file Tailer recod count:$count_from_trailer File Record Count: $record_count" );
    }
    else {
        $code = system("sed -i '\$d' $file_path/$source_file");
        if ( $code != 0 ) {
            LogWarn( $ProcVars, "Failed to remove the trailer for the file: $source_file" );
        }
        else {
            LogInfo( $ProcVars, "Trailer removed successfully: $source_file" );
        }
    }
    LogFooter($ProcVars);
    return $code;
}

sub FindLXNXDataSets {
    my $ProcVars    = $_[0];
    my $input_dir   = $_[1];
    my $file_prefix = $_[2];
    LogHeader($ProcVars);
    LogInfo( $ProcVars, "Checking that all required files exist" );

    opendir DIR, $input_dir or LogDie( $ProcVars, "Failed to open inbound_dir: $input_dir for file input" );

    my @sequence_files = grep( /$file_prefix|csv/, readdir DIR );

    closedir DIR;

    LogInfo( $ProcVars, "LXNX DataSet to be processed:\n @sequence_files" );
    LogFooter($ProcVars);
    return @sequence_files;

}

sub CopyFilesToTargetAndAddPartition {
    my $ProcVars    = $_[0];
    my $file_data   = $_[1];
    LogHeader($ProcVars);
    my $myFileName;
    my $table_name;
    my $date;

    foreach my $set ( \@$file_data ) {

        foreach my $file (@$set) {
            chomp $file;

            $file =~ /(CstmRptDrv|TD_{1}(CRT|SRD|SRT|ER)_\d+)/ ;

            given($1) {
                when("CstmRptDrv") { 
                    $table_name = "ln_sr_mobile_custom_driversummary"; 
                    $file =~ /CstmRptDrv_\d{2}(\d{6})\d{2}.csv/;
                    $date = $1;
                    }
                default {
                    given($2){
                        when("SRT") { $table_name = "ln_sr_mobile_std_tripsummary"; }
                        when("SRD") { $table_name = "ln_sr_mobile_std_driversummary"; }
                        when("CRT") { $table_name = "ln_sr_mobile_custom_tripsummary"; }
                        when("ER")  { $table_name = "ln_sr_mobile_custom_trippulse";}
                    }
                    $file =~ /.*TD_\w+_(\d{6}).*/;
                    $date = $1;
                }
            }

            if ( -z $file ) {    # Skip files with 0 byte size
                LogInfo( $ProcVars, "File: $file not being moved to Hadoop, has 0 size" );
                unlink $file;
                next;
            }

            UploadFileToS3($ProcVars,
                           $file, 
                           $ProcVars->{s3_bucket_name},
                           "$ProcVars->{s3_warehouse_prefix}/" .
                           "$ProcVars->{staging_database}/" .
                           "$table_name/" .
                           "sourcefile_dt=$date/".
                           "$file");

            AddGlueCatalogTablePartition($ProcVars,
                                         $ProcVars->{staging_database},
                                         $table_name,
                                         "sourcefile_dt=$date");
            unlink $file;
        }
    }
    LogFooter($ProcVars);
}

sub DataToWorking {
    my $ProcVars = $_[0];
    my $data     = $_[1];
    LogHeader($ProcVars);
    LogInfo( $ProcVars, "Data to Working in Progress" );
    foreach my $file (@$data) {
        InboundToWorking( $ProcVars, $file );
    }
    LogFooter($ProcVars);
}

sub MoveFilesToBackup {
    my $ProcVars         = $_[0];
    my @file_list        = @{$_[1]};
    my $backup_file_name = "LexusNexus.$ProcVars->{load_event_id}.tar.gz";

    LogHeader($ProcVars);
 
    LogInfo( $ProcVars, "Compressing " . scalar @file_list . " files" );

    my $tar_command = "cd $ProcVars->{inbound_dir}; tar -cvzf $backup_file_name -P @file_list --remove-files";

    LogInfo( $ProcVars, "Executing following command to archive files: $tar_command");

    `$tar_command`;
    $ProcVars->{logger}->info("\n");

    UploadFileToS3( $ProcVars, "$ProcVars->{inbound_dir}/$backup_file_name", $ProcVars->{s3_bucket_name},"$ProcVars->{s3_backup_prefix}/$backup_file_name" );

    unlink "$ProcVars->{inbound_dir}/$backup_file_name";

    LogFooter($ProcVars);
}

sub GetFilesToMD5Validate {
    my $ProcVars   = $_[0];
    my $data_files = $_[1];
    return FilterStrings( \@$data_files, [ $ProcVars->{file_prefix}, '^((?!md5).)*$' ] );
}

sub GetFilesToHeaderTrailerValidate {
    my $ProcVars   = $_[0];
    my $data_files = $_[1];
    return FilterStrings( \@$data_files, ['csv'] );
}

sub HandleHeaderTrailer {
    my $ProcVars = $_[0];
    my $data_files = $_[1];
    my $file_path  = $_[2];
    LogHeader($ProcVars);
    my @validated_file_list;
    my @invalid_file_list;
    my @warn_msg = ();
    my $report_files = FilterStrings( \@$data_files, ['CstmRptDrv'] );
    foreach my $file (@$report_files) {
        my $m;
        LogInfo( $ProcVars, "Started Header and Trailer validation for file : $file" );
        my $trailer_code = handleFooter( \%$ProcVars, $file, $file_path );
        my $header_code = handleHeader( \%$ProcVars, $file, $file_path );
        if ( ( $header_code == 0 ) && ( $trailer_code == 0 ) ) {
            push @validated_file_list, $file;
            LogInfo( $ProcVars, "header/trailer validated successfully for the file : $file" );
        }
        else {
            $m = "failed for header/trailer validation for the file : $file";
            push @invalid_file_list, $file;
            push @warn_msg,          $m;
            LogInfo( $ProcVars, "$m" );
        }
    }
    LogFooter($ProcVars);
    return ( \@validated_file_list, \@invalid_file_list, \@warn_msg );

}


sub MergeFiles {
    my $file_set  = $_[0];
    my $file_path = $_[1];
    my $outfile   = $_[2];
    foreach my $file (@$file_set) {
        if ( -e $file ) {
            system("cat $file >> $outfile");
        }
    }
    return $outfile;
}

sub CleanDirectory {
    my $ProcVars = $_[0];
    my $DataSet  = $_[1];
    my $DirName  = $_[2];
    LogHeader($ProcVars);
    if ( -e $DirName ) {
        foreach my $file (@$DataSet) {
            next if $file =~ /^\.\.?$/;
            if ( -e "$DirName/$file" ) {
                unlink "$DirName/$file";
                LogInfo( $ProcVars, "Deleting file:$DirName/$file " );
            }
        }
    }
    else {
        LogWarn( $ProcVars, "No directory available $DirName" );
    }
    LogFooter($ProcVars);
}

1;
