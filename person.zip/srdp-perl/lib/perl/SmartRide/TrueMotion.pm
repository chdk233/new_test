use strict;
use warnings;
use Getopt::Long;
use DIF;
use DIF::AWS::S3;

sub CombineFiles {
    my $ProcVars = shift;

    LogHeader($ProcVars);

    my $file_to_transfer = "$ProcVars->{inbound_dir}/TrueMotion.$ProcVars->{load_event_id}.csv";

    unlink $file_to_transfer;

    opendir( DIR, $ProcVars->{inbound_dir} ) or die "couldn't open $ProcVars->{inbound_dir}: $!\n";

    my @files = grep {/tar.gz$/} readdir DIR;

    closedir DIR;

    if ( !@files ) {
        LogInfo( $ProcVars, "Found 0 tar.gz files in directory $ProcVars->{inbound_dir}. Exiting script." );
        UpdateJobEventIToS($ProcVars);
        exit 0;
    }

    LogInfo( $ProcVars, "Found " . scalar @files . " tar.gz files in directory $ProcVars->{inbound_dir}" );

    LogInfo( $ProcVars, "Extracting files from tar and combining all trip csv files into one file called $file_to_transfer" );

    foreach my $file (@files) {
        system("cd $ProcVars->{inbound_dir}; tar -xzf $ProcVars->{inbound_dir}/$file");
    }

    #remove header row from all CSV files
    system("sed -i '1d' $ProcVars->{inbound_dir}/*.csv");

    #combine all csv files into one
    system("find $ProcVars->{inbound_dir} -name '*.csv' ! -wholename $file_to_transfer -exec cat {} + > $file_to_transfer");

    LogInfo( $ProcVars, 'All CombineFiles tasks complete.' );

    LogFooter($ProcVars);

    return $file_to_transfer,\@files;
}

sub BackupAndCompressIndividualTripFiles {

    my $ProcVars = $_[0];
    my @files    = @{$_[1]};
    my $backup_file_name = "TrueMotion.$ProcVars->{load_event_id}.tar.gz";

    LogHeader($ProcVars);

    LogInfo( $ProcVars, "Compressing " . scalar @files . " $ProcVars->{inbound_dir}/*tar.gz files into $backup_file_name and moving to backup" );

    my $tar_command = "cd $ProcVars->{inbound_dir}; tar -cvzf $backup_file_name -P @files --remove-files";
    `$tar_command`;
    $ProcVars->{logger}->info("\n");

    UploadFileToS3( $ProcVars, "$ProcVars->{inbound_dir}/$backup_file_name", $ProcVars->{s3_bucket_name},"$ProcVars->{s3_backup_prefix}/$backup_file_name" );

    LogInfo( $ProcVars, "Removing all csv files from $ProcVars->{inbound_dir}" );
    unlink glob "$ProcVars->{inbound_dir}/*.csv";
    unlink "$ProcVars->{inbound_dir}/$backup_file_name";

    LogFooter($ProcVars);
}

1;
