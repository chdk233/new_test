use strict;
use warnings;
use DIF;
use Getopt::Long;
use POSIX qw(strftime);
use DateTime;
use File::Basename;
use SmartRide::Common;

sub BackupAndCompress {
    my $ProcVars = shift;

    LogHeader($ProcVars);

    my @file_to_tar = @{ $ProcVars->{dropbox_zip_array} };

    my $file_location = "$ProcVars->{working_dir}/SmartMiles_Archive_Files.csv";
    open(DATA, ">$file_location") or die $!;
    foreach $a (@file_to_tar) {
    print DATA "$a\n";
    }
    close DATA;

    my $num = scalar @file_to_tar;

    LogInfo( $ProcVars, "Compressing $num files into SmartMiles_FMC_TIMS.$ProcVars->{batch_nb}.tar.gz and move to backup" );

    my $tar_command = "cd $ProcVars->{working_dir}; tar -cvzf SmartMiles_FMC_TIMS.$ProcVars->{batch_nb}.tar.gz -P --files-from $file_location --remove-files";
    `$tar_command`;
    $ProcVars->{logger}->info("\n");

    UploadFileToS3($ProcVars, 
                   "$ProcVars->{working_dir}/".
                   "SmartMiles_FMC_TIMS.$ProcVars->{batch_nb}.tar.gz",
                   $ProcVars->{s3_bucket_name},
                   "$ProcVars->{s3_backup_prefix}/" .
                   "SmartMiles_FMC_TIMS.$ProcVars->{batch_nb}.tar.gz");

    LogInfo( $ProcVars, "Upload to back up successful. Deleting archive " .
     "$ProcVars->{working_dir}/SmartMiles_FMC_TIMS.$ProcVars->{batch_nb}.tar.gz" .
     " from local file system");

     unlink "$ProcVars->{working_dir}/SmartMiles_FMC_TIMS.$ProcVars->{batch_nb}.tar.gz";

    foreach my $file ( $ProcVars->{smls_file_to_transfer},
                       $ProcVars->{fmc_file_to_transfer},
                       $ProcVars->{tims_file_to_transfer} ) {

                           if( -e $file){
                            LogInfo( $ProcVars, "Deleting combined trip json file: $file");
                            unlink $file;
                           }

                       }

    LogInfo( $ProcVars, "Deleting processed files from $ProcVars->{smartmiles_dropbox_dir} and $ProcVars->{fmc_dropbox_dir}" );
     
     my $base_dir;
    
    foreach my $file (@file_to_tar) {
 
        if ($file =~ /.*CC_FMC_.*.json/) {
            $base_dir = "$ProcVars->{fmc_dropbox_dir}/";
        } else{
            $base_dir = "$ProcVars->{smartmiles_dropbox_dir}/";
        }
        unlink $base_dir  . basename($file) . ".done";
        unlink $base_dir  . basename($file);
 
    }

    LogInfo( $ProcVars, 'All BackupAndCompress tasks complete.' );

    LogFooter($ProcVars);
}

sub Initialize {
    my $ProcVars = shift;

    GetOptions(
        "job_cd=s"     => \$ProcVars->{job_cd},
        "table_name=s" => \$ProcVars->{table_name}
    );

    if ( not defined( $ProcVars->{job_cd} ) ) {
        die "Must supply job_cd to script";
    }

    my %ConversionHash = (
        Staging               => 'STAGE',
        Staging_to_Work       => 'STGWK',
        Trip_Event            => 'TPEVT',
        Wk_PreScrub           => 'PRESB',
        Scrubbing             => 'SCRUB',
        Wk_Centroid_Summary   => 'CNSUM',
        Centroid_Summary      => 'CNSUM',
        Wk_Trip_Detail_Second => 'TDSEC',
        Trip_Detail_Second    => 'TDSEC',
        Wk_Trip_Detail_Hourly => 'TDHRY',
        Trip_Detail_Hourly    => 'TDHRY',
        Wk_Trip_Detail        => 'TPDTL',
        Trip_Detail           => 'TPDTL',
        Wk_Program_Summary    => 'PGSMY',
        Program_Summary       => 'PGSMY',
        Device_Status         => 'DVSTS',
        Device_Summary        => 'DVSMY',
        Daily_Scoring         => 'DLYSC',
        Daily_Mileage         => 'DLYML',
        SRE_Summary           => 'SRESM',
        Annual_Mileage        => 'ANMLG'
    );

    if ( !defined $ConversionHash{ $ProcVars->{table_name} } ) {
        $ProcVars->{source_cd} = 'UNKWN';
    }
    else {
        $ProcVars->{source_cd} = $ConversionHash{ $ProcVars->{table_name} };
    }

    ProcessSetup($ProcVars);

    #if acquire and no files, write token file and exit
    #else set variable and continue
    if ( $ProcVars->{job_cd} eq '1600' ) {
        unlink "$ProcVars->{smartmiles_dropbox_dir}/no_files.token";
        unlink "$ProcVars->{smartmiles_dropbox_dir}/Event_files.token";

        my @smls_zipped_files = glob "$ProcVars->{smartmiles_dropbox_dir}/*.zip";

        my @fmc_json_files = glob "$ProcVars->{fmc_dropbox_dir}/*.json";

        if ( !@smls_zipped_files and !@fmc_json_files) {
            open( my $fh, '>', "$ProcVars->{smartmiles_dropbox_dir}/no_files.token" ) or die "Could not create file $ProcVars->{smartmiles_dropbox_dir}/no_files.token $!";
            close $fh;

            LogInfo( $ProcVars, "Created file $ProcVars->{smartmiles_dropbox_dir}/no_files.token since no .zip files exist in the dropbox at the time of run.  Exiting script successfully." );
            exit 0;
        }
        else {
            $ProcVars->{job_dtl_source_cd} = $ProcVars->{source_cd};
        }
    }

    #if no_files.token exists and its not one of the source codes to skip, then write a message and exit
    #if Event_files.token exists and its not one of the source codes to skip, then write a message and exit
    #else proceed as normal
    if ( -e "$ProcVars->{smartmiles_dropbox_dir}/no_files.token" and $ProcVars->{source_cd_to_ignore} !~ m/$ProcVars->{source_cd}/ ) {
        LogInfo( $ProcVars, "The token file $ProcVars->{smartmiles_dropbox_dir}/no_files.token exists which indicates there were no files in the dropbox in the acquire job.  There is nothing to process and we are successfully exiting the script." );
        exit 0;
    }
    elsif ( -e "$ProcVars->{smartmiles_dropbox_dir}/Event_files.token" and 'STGWK,TPEVT' !~ m/$ProcVars->{source_cd}/ and $ProcVars->{source_cd_to_ignore} !~ m/$ProcVars->{source_cd}/ ) {
        LogInfo( $ProcVars, "The token file $ProcVars->{smartmiles_dropbox_dir}/Event_files.token exists which indicates the batch consists of all Event files, no trip data.  Skipping job since no trip data to process." );
        $ProcVars->{ctldbh}->do("delete from $ProcVars->{control_schema}.job_event where job_cd = '2600' and source_cd = 'PRESB' and status_cd = 'R'") if ( $ProcVars->{source_cd} eq 'PRESB' );
        exit 0;
    }
    else {
        $ProcVars->{job_dtl_source_cd} = $ProcVars->{source_cd};
    }

    #Integrity constraint logic
    if ( ( $ProcVars->{source_cd} eq 'CNSUM' and $ProcVars->{job_cd} =~ /^2/ ) or $ProcVars->{source_cd} eq 'DLYSC' ) {
        sleep 12;    #added to prevent integrity constraint in ESP.  Only applies for same job codes that run in parallel
        $ProcVars->{job_start_ts} = strftime '%Y-%m-%d %H:%M:%S', localtime();
    }

}

sub InsertNextJobDetails {
    my $ProcVars = shift;
    my $downstream_batch_nb;
    my %job_event_info_hash;
    my $job_cd_holder;

    LogHeader($ProcVars);

    if ( !exists $ProcVars->{ $ProcVars->{table_name} . '_next_job_cd' } ) {
        LogInfo( $ProcVars, "There are no Ready records to insert since the key $ProcVars->{table_name}_next_job_cd does not exist on the ProcVars hash." );
        LogFooter($ProcVars);
        return 0;
    }

    my $dt = DateTime->now;

    my $job_source_string = $ProcVars->{ $ProcVars->{table_name} . '_next_job_cd' };

    $job_source_string =~ s/\]\[/,/g;
    $job_source_string =~ s/[\[\]]//g;

    my @job_source_array = split( ',', $job_source_string );

    for ( my $i = 0; $i < @job_source_array; $i += 2 ) {
        $ProcVars->{next_job_cd}       = $job_source_array[$i];
        $ProcVars->{job_dtl_source_cd} = $job_source_array[ $i + 1 ];
        $ProcVars->{job_start_ts}      = $dt->add( seconds => 1 )->strftime('%Y-%m-%d %H:%M:%S');

        InsertJobEventReady($ProcVars);

        #insert batch_nb into job-event-info for the next job code
        #if it does not already exist in the job-event-info table
        my $batch_number_query = $ProcVars->{ctldbh}->prepare("select event_info_value from $ProcVars->{control_schema}.job_event_info where job_cd = '$ProcVars->{next_job_cd}' and load_event_id = $ProcVars->{load_event_id} and event_info_name = 'batch_nb'    ");
        $batch_number_query->execute();
        $batch_number_query->bind_columns( \$downstream_batch_nb );
        $batch_number_query->fetch();
        $batch_number_query->finish();

        unless ( defined $downstream_batch_nb ) {
            $job_cd_holder = $ProcVars->{job_cd};
            $ProcVars->{job_cd} = $ProcVars->{next_job_cd};

            %job_event_info_hash = ( batch_nb => $ProcVars->{batch_nb} );
            InsertJobEventInfo( $ProcVars, \%job_event_info_hash );

            $ProcVars->{job_cd} = $job_cd_holder;
        }

        $downstream_batch_nb = undef;
    }

    LogFooter($ProcVars);
}

sub PrepareJobParms {
    my $ProcVars = shift;

    LogHeader($ProcVars);

    #prepare parameters depending on if job is running SQL or MAPREDUCE
    if ( exists $ProcVars->{"$ProcVars->{table_name}_map_reduce_driver_name"} ) {
        LogInfo( $ProcVars, "Preparing MapReduce parameters for $ProcVars->{table_name}" );

        $ProcVars->{run_map_reduce} = 'Y';

        $ProcVars->{map_reduce_driver_name} = $ProcVars->{ $ProcVars->{table_name} . '_map_reduce_driver_name' };
        $ProcVars->{map_reduce_input_path}  = $ProcVars->{ $ProcVars->{table_name} . '_map_reduce_input_path' };
        $ProcVars->{map_reduce_input_file}  = $ProcVars->{ $ProcVars->{table_name} . '_map_reduce_input_file' };
        $ProcVars->{map_reduce_output_file} = $ProcVars->{ $ProcVars->{table_name} . '_map_reduce_output_file' };
        $ProcVars->{map_reduce_jar_name}    = $ProcVars->{ $ProcVars->{table_name} . '_map_reduce_jar_name' };

        if ( defined $ProcVars->{ $ProcVars->{table_name} . '_map_reduce_output_path' } ) {
            $ProcVars->{map_reduce_output_path} = $ProcVars->{ $ProcVars->{table_name} . '_map_reduce_output_path' };
        }

    }
    elsif ( exists $ProcVars->{"$ProcVars->{table_name}_sql"} ) {
        LogInfo( $ProcVars, "Preparing SQL parameters for $ProcVars->{table_name}" );
        $ProcVars->{run_map_reduce} = 'N';

        $ProcVars->{sql_file} = $ProcVars->{ $ProcVars->{table_name} . '_sql' };
    }
    else {
        LogInfo( $ProcVars, "ERROR: We did not find any keys on the hash named $ProcVars->{table_name}_map_reduce_driver_name or $ProcVars->{table_name}_sql." );
        die;
    }

    #set parms if we are downloading any files from Hadoop
    if ( exists $ProcVars->{"$ProcVars->{table_name}_hadoop_download_source"} ) {

        LogInfo( $ProcVars, "Preparing YYYYMMDD parameters" );
        my $processing_date = strftime "%Y%m%d", localtime;

        foreach my $key ( sort( keys %{$ProcVars} ) ) {
            if ( defined( $ProcVars->{$key} ) and $ProcVars->{$key} =~ /YYYYMMDD/ ) {
                my $old_hash_value = $ProcVars->{$key};
                $ProcVars->{$key} =~ s/YYYYMMDD/$processing_date/g;
                LogInfo( $ProcVars, "The hash value $old_hash_value has been renamed to $ProcVars->{$key}" );
            }
        }

        LogInfo( $ProcVars, "Preparing HadoopDownload parameters" );
        $ProcVars->{download_source_location} = $ProcVars->{ $ProcVars->{table_name} . '_hadoop_download_source' };
        $ProcVars->{download_target_file}     = $ProcVars->{ $ProcVars->{table_name} . '_hadoop_download_target' };
    }

    LogFooter($ProcVars);
}

sub ValidateDoneFilesExist {

    my $ProcVars = shift;
    my $glob_expression = shift;
    my $ignore_expression = shift;

    ######################################################
    # First step is to grab all files in dropbox         #
    # that have a corresponding .done file and store     #
    # them in an array.                                  #
    #                                                    #
    # The .done file means the files has been fully      #
    # transferred through EFTS                           #
    ######################################################
    my @files = glob $glob_expression;

    if(defined $ignore_expression){
        @files = grep { ! /$ignore_expression/  } @files;
    }

    my @fully_transfered_files;    #this array contains zip files that have been fully transferred (have a corresponding .done file)  - except for IMS which does not require .done files since April 2021)
    my $skipped_files = 0;

    foreach my $file (@files) {
        if ( -e "$file.done" or (defined $ignore_expression and index($file, "CC_FMC") == -1)) {
            my $file_name = basename($file);
            $ProcVars->{inbound_dir} = dirname($file);
            InboundToWorking( $ProcVars ,basename($file) );
            push( @fully_transfered_files, "$ProcVars->{working_dir}/$file_name" );
        }
        else {
            $skipped_files++;
        }
    }

    unless ( $skipped_files == 0 ) { LogInfo( $ProcVars, "NOTE: We will not process $skipped_files files because there was not a corresponding .done file.  This indicates that the file transfer is still in process" ); }

    LogInfo( $ProcVars, "Found " . scalar @fully_transfered_files . " fully transferred data files in dropbox" );

    return @fully_transfered_files;
}

sub RemoveNewLinesFromJsonFiles {

    my $ProcVars = shift;
    my $json_files = shift;

    ######################################################
    # Each unzipped file contains a single json. Remove  #
    # the newline characters from each json and combine  #
    # all json files into one combined json file.  This  #
    # combined json file will eventually get transferred #
    # to Hadoop.                                         #
    ######################################################
    LogInfo( $ProcVars, 'Removing newline characters from json files...' );

    foreach my $file (@$json_files) {
        open my $in,  '<', "$ProcVars->{working_dir}/$file"     or die "Can't read file: $!";
        open my $out, '>', "$ProcVars->{working_dir}/$file.new" or die "Can't write file: $!";

        while (<$in>) {
            chomp $_;
            print $out $_;
        }

        close $out;

        rename "$ProcVars->{working_dir}/$file.new", "$ProcVars->{working_dir}/$file";
    }

}

sub CombineJsonFiles {

    my $ProcVars = shift;
    my $file_list = shift;
    my $file_to_transfer = shift;

    LogInfo( $ProcVars, "Combining all trip json files into one file called $file_to_transfer and deleting individual trip json files..." );
    
    unlink $file_to_transfer;
    
    foreach (@$file_list) {
            `cat $ProcVars->{working_dir}/$_ >> $file_to_transfer`;
            `echo >> $file_to_transfer` unless $file_to_transfer =~ m/TIMS/;    # adds new line at the end after each cat
            if ($_ !~ m/FMC/) {
                unlink "$ProcVars->{working_dir}/$_";
            }

    }

}

sub UnzipSourceFiles {

    my $ProcVars = shift;
    my $fully_transfer_zip_files = shift;
    my $send_email = 'N';

    ######################################################
    # Next, unzip all the files from zipped_files array  #
    # and store in the new validated_zip_files array.    #
    #                                                    #
    # If there is an issue unzipping any of the files,   #
    # move corrupt zip files to ProcVars{error_dir} and  #
    # send out an email                                  #
    ######################################################

    LogInfo( $ProcVars, 'Unzipping files...' );

    my @validated_zip_files;    #this array will contain zip files that have been fully transferred and are able to be unzipped
    my @validated_unzipped_files;

    foreach my $file (@$fully_transfer_zip_files) {
        my $unzip_output = system("cd $ProcVars->{working_dir}; /usr/bin/unzip -o $file > /dev/null 2>&1");
        if ( $unzip_output > 0 ) {
            LogInfo( $ProcVars, "  Error unzipping file: $file. Moving to $ProcVars->{error_dir}" );
            my $file_name = basename $file;
            move( $file,        "$ProcVars->{error_dir}/$file_name" );
            move( "$file.done", "$ProcVars->{error_dir}/$file_name.done" );
            $send_email = 'Y';
        }
        else {
            # TIMS has multiple json files per zip file
            #TODO: something is wrong here
            if ($file =~ m/$ProcVars->{tims_file_prefix}/) {
                my @unzipped_file = `unzip -Z1 $file`;
                chomp @unzipped_file;
                push( @validated_unzipped_files,  @unzipped_file);
            } else {
                my $unzipped_file = `unzip -Z1 $file`;
                chomp $unzipped_file;
                push( @validated_unzipped_files,  $unzipped_file);
            }

            push( @validated_zip_files, $file );
        }
    }

    if ( $send_email eq 'Y' and exists $ProcVars->{telematics_support_email} ) {
        SendAnEmail( $ProcVars, $ProcVars->{telematics_support_email}, "Error unzipping files from dropbox.  Please check $ProcVars->{log_dir}/$ProcVars->{log_file_name} and $ProcVars->{error_dir} for more information", "WARNING: Error Unzipping Files for job code $ProcVars->{job_cd}" );
    }

    LogInfo( $ProcVars, "Unzipped " . scalar @validated_zip_files . " files from directory $ProcVars->{working_dir}" );

    return \@validated_zip_files,\@validated_unzipped_files;

}

sub CreateTokenFileIfAllEventFiles {

    my $ProcVars = shift;

    my $validated_files = shift;

    ######################################################
    # Check if all files in validated_files are          #
    # Event files.  If they are, then create an empty    #
    # token file which will allow certain downstream     #
    # jobs to be bypassed.                               #
    ######################################################
    my $event_file_counter = 0;
    foreach my $file (@$validated_files) {
        if ( $file =~ /\/EVT_/ ) {
            $event_file_counter++;
        }
    }

    if ( $event_file_counter eq scalar @$validated_files ) {
        open( my $fh, '>', "$ProcVars->{smartmiles_dropbox_dir}/Event_files.token" ) or die "Could not create file $ProcVars->{smartmiles_dropbox_dir}/Event_files.token $!";
        close $fh;

        LogInfo( $ProcVars, "Created file $ProcVars->{smartmiles_dropbox_dir}/Event_files.token since all .zip files in the dropbox at the time of run are Event (EVT) files.  This token file will be used downstream to skip jobs that do not need to run." );
    }

}


sub PrepareFMCSourceFiles {

    my $ProcVars = shift;

    LogHeader($ProcVars);

    LogInfo( $ProcVars, "Preparing FMC source files");

    my @fully_transfer_json_files = ValidateDoneFilesExist($ProcVars , "$ProcVars->{fmc_dropbox_dir}/*CC_FMC_*.json");

    my @file_list;
    foreach (@fully_transfer_json_files){
        push @file_list, basename($_);
    }

    $ProcVars->{fmc_file_to_transfer} = "$ProcVars->{working_dir}/FMC.$ProcVars->{batch_nb}.json";

    CombineJsonFiles( $ProcVars, \@file_list, $ProcVars->{fmc_file_to_transfer});

    LogFooter($ProcVars);

    return \@fully_transfer_json_files;

}

sub PrepareSMLSSourceFiles {

    my $ProcVars = shift;
    my $send_email = 'N';

    LogHeader($ProcVars);

    LogInfo( $ProcVars, "Preparing SMLS source files");

    my @fully_transfer_zip_files = ValidateDoneFilesExist($ProcVars , "$ProcVars->{smartmiles_dropbox_dir}/*.zip", "$ProcVars->{tims_file_prefix}" );

    my ($validated_zip_files, $validated_unzipped_files) = UnzipSourceFiles( $ProcVars, \@fully_transfer_zip_files);

    RemoveNewLinesFromJsonFiles( $ProcVars, $validated_unzipped_files);

    $ProcVars->{smls_file_to_transfer} = "$ProcVars->{working_dir}/SmartMiles.$ProcVars->{batch_nb}.json";

    CombineJsonFiles( $ProcVars, $validated_unzipped_files, $ProcVars->{smls_file_to_transfer});

    LogFooter($ProcVars);

    return $validated_zip_files;
}

sub PerpareTIMSSourceFiles {
    my $ProcVars = shift;

    LogHeader($ProcVars);

    LogInfo( $ProcVars, "Preparing TIMS source files");

    my @fully_transfer_zip_files = ValidateDoneFilesExist($ProcVars , "$ProcVars->{smartmiles_dropbox_dir}/*$ProcVars->{tims_file_prefix}*.zip" );

    my ($validated_zip_files, $validated_unzipped_files) = UnzipSourceFiles( $ProcVars, \@fully_transfer_zip_files);

    $ProcVars->{tims_file_to_transfer} = "$ProcVars->{working_dir}/TIMS.$ProcVars->{batch_nb}.json";

    CombineJsonFiles( $ProcVars, $validated_unzipped_files, $ProcVars->{tims_file_to_transfer});

    LogFooter($ProcVars);

    return $validated_zip_files;
}

sub PrepareSourceFiles {
    my $ProcVars   = shift;

    LogHeader($ProcVars);

    my $validated_SMLS_files = PrepareSMLSSourceFiles( $ProcVars);

    my $validated_FMC_files =  PrepareFMCSourceFiles( $ProcVars );

    my $validated_TIMS_files = PerpareTIMSSourceFiles( $ProcVars);

    my @consolidated_files_list;

    push @consolidated_files_list, @{$validated_SMLS_files};

    push @consolidated_files_list, @{$validated_FMC_files};

    push @consolidated_files_list, @{$validated_TIMS_files};

    CreateTokenFileIfAllEventFiles( $ProcVars, \@consolidated_files_list);

    $ProcVars->{dropbox_zip_array} = \@consolidated_files_list;
   
    LogInfo( $ProcVars, 'All PrepareSourceFiles tasks complete.' );

    LogFooter($ProcVars);

}



sub RetrieveBatchNumber {
    my $ProcVars = shift;
    LogHeader($ProcVars);

    my $batch_number_query = $ProcVars->{ctldbh}->prepare("select event_info_value from $ProcVars->{control_schema}.job_event_info where job_cd = '$ProcVars->{job_cd}' and load_event_id = $ProcVars->{load_event_id} and event_info_name = 'batch_nb' ");
    $batch_number_query->execute();
    $batch_number_query->bind_columns( \( $ProcVars->{batch_nb} ) );
    $batch_number_query->fetch();
    $batch_number_query->finish();

    if ( not defined $ProcVars->{batch_nb} ) {
        LogInfo( $ProcVars, "ERROR: A batch number was not found in Job_Event_Info for job code $ProcVars->{job_cd} and load event $ProcVars->{load_event_id}." );
        die;
    }

    if ( $ProcVars->{batch_nb} !~ /^\d{12}$/ ) {
        LogInfo( $ProcVars, "ERROR: Invalid batch_nb.  We got $ProcVars->{batch_nb} but expected a value with 12 digits." );
        die;
    }

    if ( $ProcVars->{batch_nb} =~ /^(\d{8})2400$/ ) {
        $ProcVars->{daily_mileage_batch_nb} = $1;
        LogInfo( $ProcVars, "Batch number found is $ProcVars->{batch_nb}.  This batch contains 24 for the hour which indicates this process is a daily job. We need to access all batches for this date to calculate daily-mileage, so setting the hash key daily_mileage_batch_nb to $ProcVars->{daily_mileage_batch_nb}" );
    }
    else {
        LogInfo( $ProcVars, "The batch to be loaded is $ProcVars->{batch_nb}" );
    }

    LogFooter($ProcVars);
}

sub SetBatchNumber {
    my $ProcVars = shift;
    my ( $retrieved_batch, $retrieved_loadevent, $retrieved_status_cd );

    LogHeader($ProcVars);

    if ( $ProcVars->{source_cd} eq 'DVSTS' ) {
        $ProcVars->{batch_nb} = DateTime->now()->subtract( days => 1 )->strftime('%Y%m%d2400');
    }
    else {
        $ProcVars->{batch_nb} = strftime '%Y%m%d%H00', localtime;
    }

    $ProcVars->{job_event_info}{batch_nb} = $ProcVars->{batch_nb};
    LogInfo( $ProcVars, "The batch number created is $ProcVars->{batch_nb}" );

    LogFooter($ProcVars);
}

sub UpdateJobEventIToSBySourceCd {
    my $ProcVars  = $_[0];
    my $source_cd = $_[1];

    LogHeader($ProcVars);

    $ProcVars->{job_end_ts} = strftime "%Y-%m-%d %H%M%S", localtime;

    my $error = 0;
    try {
        $ProcVars->{ctldbh}->do(
            "UPDATE $ProcVars->{control_schema}.job_event
            SET status_cd  = 'S',
            end_ts = to_date('$ProcVars->{job_end_ts}','YYYY-MM-DD HH24:MI:SS')
            WHERE load_event_id = $ProcVars->{load_event_id}
            AND job_cd = '$ProcVars->{job_cd}'
            and source_cd = '$source_cd'
            AND status_cd = 'I'"
        );
    }
    catch { $error = 1; };

    if ( defined($DBI::errstr) or $error ) {
        LogInfo( $ProcVars, "Database error occurred while updating Job_Event status_cd from I to S: $DBI::errstr" );
        die;
    }

    LogInfo( $ProcVars, "Job_Event status code updated from In Process to Successful for job code $ProcVars->{job_cd}, source code $source_cd, and load event id $ProcVars->{load_event_id}" );

    LogFooter($ProcVars);
}

sub UpdateJobEventIToEBySourceCd {
    my $ProcVars  = $_[0];
    my $source_cd = $_[1];

    LogHeader($ProcVars);

    $ProcVars->{job_end_ts} = strftime "%Y-%m-%d %H%M%S", localtime;

    my $error = 0;
    try {
        $ProcVars->{ctldbh}->do(
            "UPDATE $ProcVars->{control_schema}.job_event
            SET status_cd  = 'E',
            end_ts = to_date('$ProcVars->{job_end_ts}','YYYY-MM-DD HH24:MI:SS')
            WHERE load_event_id = $ProcVars->{load_event_id}
            AND job_cd = '$ProcVars->{job_cd}'
            and source_cd = '$source_cd'
            AND status_cd = 'I'"
        );
    }
    catch { $error = 1; };

    if ( defined($DBI::errstr) or $error ) {
        LogInfo( $ProcVars, "Database error occurred while updating Job_Event status_cd from I to E: $DBI::errstr" );
        die;
    }

    LogInfo( $ProcVars, "Job_Event status code updated from In Process to Error for job code $ProcVars->{job_cd}, source code $source_cd, and load event id $ProcVars->{load_event_id}" );

    LogFooter($ProcVars);
}

sub UpdateJobEventRToIBySourceCd {
    my $ProcVars  = $_[0];
    my $source_cd = $_[1];

    LogHeader($ProcVars);

    my $error = 0;
    try {
        $ProcVars->{ctldbh}->do(
            "UPDATE $ProcVars->{control_schema}.job_event
            SET status_cd  = 'I',
            start_ts = to_date('$ProcVars->{job_start_ts}','YYYY-MM-DD HH24:MI:SS'),
            log_file = '$ProcVars->{log_file_name}'
            WHERE load_event_id = $ProcVars->{load_event_id}
            AND job_cd = '$ProcVars->{job_cd}'
            AND source_cd = '$source_cd'
            AND status_cd = 'R'"
        );
    }
    catch { $error = 1; };

    if ( defined($DBI::errstr) or $error ) {
        LogInfo( $ProcVars, "Database error occurred while updating Job_Event status_cd from R to I: $DBI::errstr" );
        die;
    }

    LogInfo( $ProcVars, "Job_Event status code updated from Ready to In Process for job code $ProcVars->{job_cd}, source code $source_cd, and load event id $ProcVars->{load_event_id}" );

    LogFooter($ProcVars);
}

sub UploadAndAddPartitions{

    my $ProcVars = shift;

    LogHeader($ProcVars);

    my %FileToSourceCd = (
        $ProcVars->{smls_file_to_transfer} => 'IMS',
        $ProcVars->{fmc_file_to_transfer}  => 'FMC',
        $ProcVars->{tims_file_to_transfer} => 'TIMS'
    );

    foreach my $file ( $ProcVars->{smls_file_to_transfer},
                       $ProcVars->{fmc_file_to_transfer},
                       $ProcVars->{tims_file_to_transfer} ){

        if (-e $file){

            UploadFileToS3( $ProcVars, 
                $file, 
                $ProcVars->{s3_bucket_name},
                "$ProcVars->{s3_warehouse_prefix}/" .
                "$ProcVars->{staging_db}/" .
                "$ProcVars->{staging_tbl_dir}/" .
                "source_cd=$FileToSourceCd{$file}/" .
                "batch_nb=$ProcVars->{batch_nb}/".
                basename($file));

            foreach my $table ( $ProcVars->{staging_summary},
                                $ProcVars->{staging_event},
                                $ProcVars->{staging_point} ){

                AddGlueCatalogTablePartition( $ProcVars,
                                    $ProcVars->{staging_database},
                                    $table,
                                    "source_cd=$FileToSourceCd{$file}/" .
                                    "batch_nb=$ProcVars->{batch_nb}");

                }
        }

    }

    LogFooter($ProcVars);

}

1;
