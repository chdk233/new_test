use strict;
use warnings;
use DIF;
use GDW::DistCp;


sub GenerateBatchString {
    my $ProcVars = $_[0];
    my $source_cd = $_[1];

    LogHeader($ProcVars);

    if (!defined $source_cd) {
    	LogInfo( $ProcVars, 'ERROR: The source_cd value was not passed into the function. The function expects to be called like GenerateBatchString(X,Y) where X is the hash and Y is a source code in the dc_batch_to_process table.' );
    	die;
    }

    my @list_of_batches;

		my $batch_query = $ProcVars->{hivedbh}->prepare("Select batch From $ProcVars->{srdp_wk_db}.dc_batch_to_process where source_cd = '$source_cd'");
    $batch_query->execute();
    while ( my $row = $batch_query->fetchrow_array ) {
        push @list_of_batches, $row;
    }
    $batch_query->finish();

		foreach (@list_of_batches) {
			if ($_ =~ /[[:alpha:]]/) {
		    $_ = "'$_'";
		  }
		}

    $ProcVars->{batch_list} = join(',', @list_of_batches);
    $ProcVars->{source_cd} = $source_cd;

    LogInfo( $ProcVars, "There were " . scalar @list_of_batches . " batches with source code $ProcVars->{source_cd} found in $ProcVars->{srdp_wk_db}.dc_batch_to_process.  These batches were put on the hash ProcVars{batch_list}" );


    my @list_of_orphan_batches;

		$batch_query = $ProcVars->{hivedbh}->prepare("Select batch From $ProcVars->{srdp_cncl_db}.orphan_ts WHERE source_cd = '$source_cd' AND regexp_replace(batch,'conv','')<= concat(regexp_replace(cast(date_add(current_date,-730)as string),'-',''),'0000') group by batch");
    $batch_query->execute();
    while ( my $row = $batch_query->fetchrow_array ) {
        push @list_of_orphan_batches, $row;
    }
    $batch_query->finish();

		foreach (@list_of_orphan_batches) {
			if ($_ =~ /[[:alpha:]]/) {
		    $_ = "'$_'";
		  }
		}

    if(scalar @list_of_orphan_batches>0){
        $ProcVars->{orphan_batch_list} = join(',', @list_of_orphan_batches);
        LogInfo( $ProcVars, "There were " . scalar @list_of_orphan_batches . " batches older than 2 years with source code $ProcVars->{source_cd} found in $ProcVars->{srdp_cncl_db}.orphan_ts.  These batches were put on the hash ProcVars{orphan_batch_list}" );

        }else{
        $ProcVars->{orphan_batch_list}='0';
        LogInfo( $ProcVars, "There were " . scalar @list_of_orphan_batches . " batches older than 2 years with source code $ProcVars->{source_cd} found in $ProcVars->{srdp_cncl_db}.orphan_ts. The default '0' was put on the hash ProcVars{orphan_batch_list}" );
        }

    LogFooter($ProcVars);
};

sub DataConfTableSyncDown {

    my $ProcVars = $_[0];
    my @partitioned_table_list = split /,/, $_[1];
    my @non_partitioned_table_list = split /,/, $_[2];
    my $distcp_src_root_dir="$ProcVars->{hive_root_dir}/$ProcVars->{srdp_wk_db}.db";
    my $distcp_tgt_root_dir="$ProcVars->{hive_root_dir}/$ProcVars->{tlmtcs_auto_db}.db";
    my $orig_log_file;
    my $errors;
    my $warnings;
    my $error;
    my $warning;

    if (!defined @partitioned_table_list) {
        LogInfo( $ProcVars, 'ERROR: The list of partitioned tables was not passed into the function. The function expects to be called like DataConfTableSyncDown(X,Y,Z) where X is the hash, Y is the list of partitioned tables and Z is the comma delimited list of non partitioned tables.' );
        die;
    }

    if (!defined @non_partitioned_table_list) {
        LogInfo( $ProcVars, 'ERROR: The list of non partitioned tables was not passed into the function. The function expects to be called like DataConfTableSyncDown(X,Y,Z) where X is the hash, Y is the list of partitioned tables and Z is the comma delimited list of non partitioned tables.' );
        die;
    }

    LogHeader( $ProcVars );

    $ProcVars->{log_file_name} =~ m/(.*).log$/;

    LogInfo($ProcVars, "Outputing distcp log to $ProcVars->{log_dir}/$1.sync_down.log");

    Log::Log4perl->easy_init(
        {
            file   => "$ProcVars->{log_dir}/$1.sync_down.log",
            layout => "%m%n"
        },
    );

    $ProcVars->{logger} = get_logger();


    TABLEITERATOR: foreach my $table (@partitioned_table_list){

        my @wk_db_results;
        my @tgt_db_results;
        my $wk_db_partition_spec;
        my $tgt_db_partition_spec;
        $table=lc($table);

        LogInfo($ProcVars, "BEGIN: sync down steps for partitioned table $table");

        try{
            LogInfo($ProcVars, "STEP 1: Drop and create $ProcVars->{tlmtcs_auto_db}.${table}_tmp\n");
            ExecuteHiveScript($ProcVars,"drop table if exists $ProcVars->{tlmtcs_auto_db}.${table}_tmp; create table $ProcVars->{tlmtcs_auto_db}.${table}_tmp like $ProcVars->{tlmtcs_auto_db}.${table}");
        } catch{
            LogInfo($ProcVars,"ERROR: Failed to Drop/Recreate temp table for $table. Check Hive Log for more info. Skipping remaining steps for this table.");
            $ProcVars->{log_indent}--;
            $errors = $errors . "ERROR: Failed to Drop/Recreate temp table for $table. Check Hive Log for more info. Skipping remaining steps for this table.\n";
            next TABLEITERATOR;
        };

        try{
            LogInfo($ProcVars, "STEP 2: Distcp from $ProcVars->{distcp_source_host}:${distcp_src_root_dir}/${table} to $ProcVars->{distcp_target_host}:${distcp_tgt_root_dir}/${table}_tmp\n");
            HadoopDistCp( $ProcVars, "${distcp_src_root_dir}/${table}", "${distcp_tgt_root_dir}/${table}_tmp",'Y');
        } catch{
            $error = "ERROR: distcp failed for $table. Check distcp log for more info. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars, $error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
        };

        try{
            LogInfo($ProcVars, "STEP 3: Adding new partitions to hive metastore for table $ProcVars->{tlmtcs_auto_db}.${table}_tmp\n");
            ExecuteHiveScript($ProcVars,"msck repair table $ProcVars->{tlmtcs_auto_db}.${table}_tmp");
        } catch{
            $error = "ERROR: msck repair table failed for ${table}_tmp. Check hive log for more information. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars, $error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
        };

        try{
            LogInfo($ProcVars, "STEP 4: Retrieving partition specs for source table $ProcVars->{tlmtcs_auto_db}.${table}_tmp\n");
            @wk_db_results = ExecuteHiveScript($ProcVars,"show partitions $ProcVars->{tlmtcs_auto_db}.${table}_tmp");
            if(scalar @wk_db_results == 0){
                $warning="WARNING: No partitions retrieved for $ProcVars->{tlmtcs_auto_db}.${table}_tmp. Moving to next table.\n";
                LogInfo($ProcVars, $warning);
                $warnings= $warnings .$warning;
                try{
                    LogInfo($ProcVars, "Droping temp table $ProcVars->{tlmtcs_auto_db}.${table}_tmp\n");
                    ExecuteHiveScript($ProcVars,"drop table if exists $ProcVars->{tlmtcs_auto_db}.${table}_tmp");
                } catch{
                    $error="ERROR: drop temp table failed for $table. Check distcp log for more information.\n";
                    LogInfo($ProcVars,$error);
                    $ProcVars->{log_indent}--;
                    $errors = $errors . $error;
                    next TABLEITERATOR;
                };
                next TABLEITERATOR;
            }
        } catch{
            $error="ERROR: Unable to retrieve partition info for $ProcVars->{tlmtcs_auto_db}.${table}_tmp. Check hive log for more information. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
        };

        try{
            LogInfo($ProcVars, "STEP 5: Retrieving partition specs for target table $ProcVars->{tlmtcs_auto_db}.${table}\n");
            @tgt_db_results = ExecuteHiveScript($ProcVars,"show partitions $ProcVars->{tlmtcs_auto_db}.${table}");
        } catch{
            $error="ERROR: Unable to retrieve partition info for $ProcVars->{tlmtcs_auto_db}.${table}. Check hive log for more information. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
        };

        LogInfo($ProcVars, "STEP 6: Removing partitions from target table $ProcVars->{tlmtcs_auto_db}.${table} that exist in source table $ProcVars->{tlmtcs_auto_db}.${table}_tmp and then moving all partitions from source to target\n");

        foreach my $record (@wk_db_results){

            $wk_db_partition_spec= $$record[0];

            if (grep {$$_[0] eq $wk_db_partition_spec} @tgt_db_results) {

                LogInfo($ProcVars, "Partition $wk_db_partition_spec already exists in in $ProcVars->{tlmtcs_auto_db}.${table}. Removing partition from target table.\n");

                try{
                    HadoopDelete($ProcVars, "$ProcVars->{hive_root_dir}/$ProcVars->{tlmtcs_auto_db}.db/${table}/$wk_db_partition_spec");
                } catch{

            $error="ERROR: Unable to delete data partition $wk_db_partition_spec on $table. Check distcp log for more information. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
                };
            }

            # This logic only really applies for the first run to make sure that the HadoopMove does not fail. If source_cd=xxxx directory does not
            # exist then the HadoopMove will fail.

            if( $wk_db_partition_spec=~/source_cd=(\w*)?/m ){
                try{ HadoopInfo( $ProcVars , "$ProcVars->{hive_root_dir}/$ProcVars->{tlmtcs_auto_db}.db/${table}/source_cd=$1"); }
                catch {
                    $ProcVars->{log_indent}--;
                    HadoopMkdir($ProcVars , "$ProcVars->{hive_root_dir}/$ProcVars->{tlmtcs_auto_db}.db/${table}/source_cd=$1");
                }
            }

            try{
                HadoopMove( $ProcVars , "$ProcVars->{hive_root_dir}/$ProcVars->{tlmtcs_auto_db}.db/${table}_tmp/$wk_db_partition_spec", "$ProcVars->{hive_root_dir}/$ProcVars->{tlmtcs_auto_db}.db/${table}/$wk_db_partition_spec");
            } catch{

            $error="ERROR: Unable to move partition $wk_db_partition_spec to $table. Check distcp log for more information. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
            };
        }

        try{
            LogInfo($ProcVars, "STEP 7: Adding new partitions to hive metastore for table $ProcVars->{tlmtcs_auto_db}.${table}\n");
            ExecuteHiveScript($ProcVars,"msck repair table $ProcVars->{tlmtcs_auto_db}.${table}");
        } catch{
            $error="ERROR: mcsk repair table failed for $table. Check distcp log for more information. Skipping remaining step for this table.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
        };

        try{
            LogInfo($ProcVars, "STEP 8: Droping temp table $ProcVars->{tlmtcs_auto_db}.${table}_tmp\n");
            ExecuteHiveScript($ProcVars,"drop table if exists $ProcVars->{tlmtcs_auto_db}.${table}_tmp");
        } catch{
            $error="ERROR: drop temp table failed for $table. Check distcp log for more information.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR;
        };

        LogInfo($ProcVars, "END: sync down steps for partitioned table $table");
    }

    TABLEITERATOR2: foreach my $table (@non_partitioned_table_list){

        $table=lc($table);

        LogInfo($ProcVars, "BEGIN: sync down steps for non partitioned table $table");

        try{

            LogInfo($ProcVars, "STEP 1: Drop and create $ProcVars->{tlmtcs_auto_db}.${table}_tmp\n");
            ExecuteHiveScript($ProcVars,"drop table if exists $ProcVars->{tlmtcs_auto_db}.${table}_tmp; create table $ProcVars->{tlmtcs_auto_db}.${table}_tmp like $ProcVars->{tlmtcs_auto_db}.${table}");
        } catch{
            $error="ERROR: Failed to Drop/Recreate temp table for $table. Check Hive Log for more info. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR2;
        };

        try{
            LogInfo($ProcVars, "STEP 2: Distcp from $ProcVars->{distcp_source_host}:${distcp_src_root_dir}/${table} to $ProcVars->{distcp_target_host}:${distcp_tgt_root_dir}/${table}_tmp\n");
            HadoopDistCp( $ProcVars, "${distcp_src_root_dir}/${table}", "${distcp_tgt_root_dir}/${table}_tmp",'Y');
        } catch{
            $error="ERROR: distcp failed for $table. Check distcp log for more info. Skipping remaining steps for this table.\n";
            LogInfo($ProcVars,$error);
            $ProcVars->{log_indent}--;
            $errors = $errors . $error;
            next TABLEITERATOR2;
        };

        LogInfo($ProcVars, "END: sync down steps for non partitioned table $table");
    };

    Log::Log4perl->easy_init(
        {
            file   => ">>$ProcVars->{log_dir}/$ProcVars->{log_file_name}",
            layout => "%m%n"
        },
    );

    $ProcVars->{logger} = get_logger();

    if (defined $errors){
        LogDie( $ProcVars, $errors);
    } else {
        LogInfo( $ProcVars, "Tables successfully copied.");
        if(defined $warnings){
            LogInfo( $ProcVars, $warnings);
        }
    }

    LogFooter($ProcVars);

}

sub SetRunDate {

    my $ProcVars = $_[0];

    LogHeader( $ProcVars );

    if ( exists $ProcVars->{run_date} ) {

        if ( $ProcVars->{run_date} =~ /[0-9]/ ) {
            LogInfo( $ProcVars, "There is a value of $ProcVars->{run_date} populated in the parameter run_date. This value will be used for processing." );
        }
        else {
            $ProcVars->{run_date} = substr($ProcVars->{job_start_ts}, 0, 10 );
            LogInfo( $ProcVars, "There is no date value populated in the parameter run_date. The current date of $ProcVars->{run_date} will be set." );

        }
    } else {
        LogInfo( $ProcVars, 'ERROR: SetRunDate requires run_date to exist in job parm');
        die;
    }

    LogFooter($ProcVars);
}

sub PostProcessingActivities {
    my $ProcVars = $_[0];
    my $job_cd=$_[1];
    my $parm_value;

    LogHeader( $ProcVars );

    if($ProcVars->{run_date} ne 'YYYY-MM-DD'){
        UpdateJobParm ( $ProcVars , 'run_date' , 'YYYY-MM-DD' );
    }

    if(exists $ProcVars->{last_run_dt}){

        my $results = $ProcVars->{ctldbh}->prepare("SELECT parm_value FROM $ProcVars->{control_schema}.job_parm where job_cd='$job_cd' and parm_name='last_run_dt'");
        $results->bind_columns(\($parm_value));
        $results->execute();
        $results->fetch();
        UpdateJobParm ( $ProcVars , 'last_run_dt' , $parm_value );
    }

    LogFooter($ProcVars);
}

1;