
Drop table IF EXISTS ~>work_db.~>wk_tripp_trips;

CREATE  TABLE ~>work_db.~>wk_tripp_trips(
  dataload_dt timestamp,
  sourcefilename_ts timestamp,
  loadevent_id bigint,
  fullpolicy_nb string,
  voucher_nb bigint,
  sr_pgm_instnc_id bigint,
  deviceserial_nb bigint,
  enrolledvin_nb string,
  detectedvin_nb string COMMENT '/*@type="varchar(32768)"*/',
  trip_nb string,
  position_ts timestamp,
  tripzoneoffset_am string,
  plcy_ratd_st_cd string,
  vssspeed_am double,
  vssacceleration_pc double,
  enginerpm_qt int,
  throttleposition_pc double,
  accelerationlateral_qt double,
  accelerationlongitudinal_qt double,
  accelerationvertical_qt double,
  latitude_it double, 
  longitude_it double,
  source_cd string,
  batch string)
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/~>wk_tripp_trips'
;

set mapred.job.name = "~>job_cd Load ~>work_db.~>wk_tripp_trips from ~>wk_tsp_tripsummary and ~>wk_tsp_trippoint";

INSERT into TABLE ~>work_db.~>wk_tripp_trips 
Select /*+MAPJOIN(~>wk_tsp_tripsummary)*/ 
tp.dataload_dt  as tp_dataload_dt
,tp.sourcefilename_ts as tp_sourcefilename_ts
,tp.loadevent_id as tp_loadevent_id
,tp.fullpolicy_nb as tp_fullpolicy_nb
,tp.voucher_nb as tp_voucher_nb
,ts.sr_pgm_instnc_id as ts_sr_pgm_instnc_id
,ts.deviceserial_nb as ts_deviceserial_nb
,ts.enrolledvin_nb as ts_enrolledvin_nb
,ts.detectedvin_nb as ts_detectedvin_nb
,ts.trip_nb as ts_trip_nb
,tp.position_ts as tp_position_ts
,ts.tripzoneoffset_am as ts_tripzoneoffset_am
,ts.plcy_ratd_st_cd as ts_plcy_ratd_st_cd
,tp.vssspeed_am as tp_vssspeed_am
,tp.vssacceleration_pc as tp_vssacceleration_pc
,tp.enginerpm_qt as tp_enginerpm_qt
,tp.throttleposition_pc as tp_throttleposition_pc
,tp.accelerationlateral_qt as tp_accelerationlateral_qt
,tp.accelerationlongitudinal_qt as tp_accelerationlongitudinal_qt
,tp.accelerationvertical_qt as tp_accelerationvertical_qt
,tp.latitude_it as tp_latitude_it
,tp.longitude_it as tp_longitude_it
,tp.source_cd as tp_source_cd
,ts.batch as ts_batch
from  
~>work_db.~>wk_tsp_tripsummary ts 
inner join 
~>work_db.~>wk_tsp_trippoint tp
ON tp.trip_nb = ts.trip_nb;
