use ~>smartride_raw_hive_db;

Alter table IMS_TripEvent_Ext_H add IF NOT EXISTS partition (batch='~>batch_id');

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_IMS_TSP_TripEvent_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_IMS_TSP_TripEvent_H from smartride_raw_hive_db.IMS_TripEvent_Ext_H";

CREATE TABLE ~>smartride_work_hive_db.WK_IMS_TSP_TripEvent_H
as
select  
cast(cast(dataload_dt as date) as timestamp) as dataload_dt,
cast(cast(dataload_dt as date) as timestamp) as sourcefilename_ts,
~>load_event_id as LoadEvent_Id ,
'' as DeviceType_Cd ,
'' as Contract_Nb,
'' as Voucher_Nb,
Trip_Nb,
EnrolledVIN_Nb,
DetectedVIN_Nb,
Event_Ts,
EventTimeZoneOffSet_Nb,
Latitude_It,
Longitude_It,
EventType_Cd,
EventReferenceValue_Ds,
'' as eventstart_ts,
'' as eventend_ts,
''as eventduration_am,
'IMS' as source_cd,
batch from  ~>smartride_raw_hive_db.IMS_TripEvent_Ext_H WHERE
batch='~>batch_id';



use ~>smartride_canonical_hive_db;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set  hive.exec.max.dynamic.partitions=100000;
set  hive.exec.max.dynamic.partitions.pernode=100000;
set  hive.exec.parallel=false;

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.TSP_Tripevent from smartride_work_hive_db.WK_IMS_TSP_TripEvent_H";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.TSP_Tripevent
PARTITION (source_cd , batch)
SELECT
  DataLoad_Dt  ,
 SourceFileName_Ts,
 LoadEvent_Id,
 DeviceType_Cd ,
 Contract_Nb ,
 Voucher_Nb,
 Trip_Nb ,
 EnrolledVIN_Nb ,
 DetectedVIN_Nb ,
 Event_Ts ,
 EventTimeZoneOffSet_Nb ,
 Latitude_It ,
 Longitude_It ,
 EventType_Cd ,
 EventReferenceValue_Ds ,
 EventStart_Ts ,
 EventEnd_Ts,
 EventDuration_Am ,
source_cd,
batch
from ~>smartride_work_hive_db.WK_IMS_TSP_TripEvent_H;
