SET mapred.job.name = "~>job_cd Load all data from smartride_analysis_db table that is not in dc_devicestatus";

-------------------------------------------------------------
-- Project: Data Confidential                              --
-- Created On: 11/06/2017                                  --
-- Created By: Big Heroes Team                             --
-- Description: This script will capture delta for the     --
--              smartride tables which do not have batch or--
--              date information.                          --
--              It script will run in the lower environment--
--              and is assumed that Prod data is available.--
-------------------------------------------------------------

---------------------------------------- Table: devicestatus--------------------------------------

--take everything from smartride_analysis_db that is not in our work_db table

INSERT INTO TABLE ~>srdp_wk_db.dc_devicestatus
SELECT 
a.dc_instance_id
,a.status
,a.statusstart_ts
,a.statusend_ts
,a.lastactivity_ts
,a.loststatus_flag
FROM ~>tlmtcs_auto_db.dc_devicestatus a   
  
LEFT OUTER JOIN  ~>tlmtcs_auto_db.dc_devicestatus_tmp b
ON a.dc_instance_id = b.dc_instance_id 
AND a.statusstart_ts = b.statusstart_ts

WHERE b.dc_instance_id is null
;

--rename analysis table to keep a backup
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_devicestatus_bkp;

SET mapred.job.name = "~>job_cd create backup table for dc_devicestatus";
ALTER TABLE ~>tlmtcs_auto_db.dc_devicestatus RENAME TO ~>srdp_wk_db.dc_devicestatus_bkp;

--recreate analysis table and load data from workdb
DROP TABLE IF EXISTS ~>tlmtcs_auto_db.dc_devicestatus; 

CREATE  TABLE  ~>tlmtcs_auto_db.dc_devicestatus (
dc_instance_id bigint,
status int,
statusstart_ts timestamp,
statusend_ts timestamp,
lastactivity_ts timestamp,
loststatus_flag int)
STORED AS ORC;

SET mapred.job.name = "~>job_cd Copy all data from work table to final analysis table devicestatus";
INSERT INTO TABLE  ~>tlmtcs_auto_db.dc_devicestatus
SELECT
dc_instance_id
,status
,statusstart_ts
,statusend_ts
,lastactivity_ts
,loststatus_flag
FROM ~>tlmtcs_auto_db.dc_devicestatus_tmp;

DROP TABLE IF EXISTS ~>tlmtcs_auto_db.dc_devicestatus_tmp;


---------------------------------------- Table: device_install_pcnt--------------------------------------

--  Rename the existing table --
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_device_install_pcnt_bkp;

SET mapred.job.name = "~>job_cd create backup table for device_install_pcnt";
ALTER TABLE ~>tlmtcs_auto_db.dc_device_install_pcnt RENAME TO ~>srdp_wk_db.dc_device_install_pcnt_bkp;

--drop and recreate target table --
DROP TABLE IF EXISTS ~>tlmtcs_auto_db.dc_device_install_pcnt;

CREATE TABLE ~>tlmtcs_auto_db.dc_device_install_pcnt(
  dc_instance_id bigint, 
  loststatus_flag bigint, 
  total_time bigint, 
  total_install_time bigint, 
  install_percentage double, 
  total_uninstall_time bigint, 
  uninstall_percentage double, 
  first_activity_date timestamp, 
  last_activity_date timestamp, 
  total_days bigint, 
  days_installed bigint, 
  connection_ct bigint, 
  disconnection_ct bigint)
STORED AS ORC;


SET mapred.job.name = "~>job_cd Load all data from work table to smartride_analysis_db table device_install_pcnt";

--- Pass 1: Insert all rows from work table to target ---
INSERT INTO ~>tlmtcs_auto_db.dc_device_install_pcnt 
SELECT
a.dc_instance_id
,a.loststatus_flag
,a.total_time
,a.total_install_time
,a.install_percentage
,a.total_uninstall_time
,a.uninstall_percentage
,a.first_activity_date
,a.last_activity_date
,a.total_days
,a.days_installed
,a.connection_ct
,a.disconnection_ct

FROM ~>tlmtcs_auto_db.dc_device_install_pcnt_tmp a;


SET mapred.job.name = "~>job_cd Load data into analysis table device_install_pcnt that is not in the work table ";
--- Pass 2: Insert all rows from backup(hist) that are not in canonical---
INSERT INTO ~>tlmtcs_auto_db.dc_device_install_pcnt 
SELECT
a.dc_instance_id
,a.loststatus_flag
,a.total_time
,a.total_install_time
,a.install_percentage
,a.total_uninstall_time
,a.uninstall_percentage
,a.first_activity_date
,a.last_activity_date
,a.total_days
,a.days_installed
,a.connection_ct
,a.disconnection_ct

FROM ~>srdp_wk_db.dc_device_install_pcnt_bkp a -- this is history backup 

LEFT OUTER JOIN ~>tlmtcs_auto_db.dc_device_install_pcnt_tmp b
ON a.dc_instance_id = b.dc_instance_id

WHERE b.dc_instance_id IS NULL;

DROP TABLE IF EXISTS ~>tlmtcs_auto_db.dc_device_install_pcnt_tmp;

---------------------------------------- Table: dc_smt_ods_bigin_pgm_instnc--------------------------------------

DROP TABLE IF EXISTS ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_old;

ALTER TABLE ~>tlmtcs_auto_db.dc_smt_ods_bigin_pgm_instnc RENAME TO ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_old;

DROP TABLE IF EXISTS ~>tlmtcs_auto_db.dc_smt_ods_bigin_pgm_instnc;

CREATE TABLE ~>tlmtcs_auto_db.dc_smt_ods_bigin_pgm_instnc like ~>tlmtcs_auto_db.dc_smt_ods_bigin_pgm_instnc_tmp;

SET mapred.job.name = "~>job_cd Load data into analysis table dc_smt_ods_bigin_pgm_instnc";

LOAD DATA INPATH '~>hive_root_dir/~>tlmtcs_auto_db.db/dc_smt_ods_bigin_pgm_instnc_tmp' OVERWRITE INTO TABLE ~>tlmtcs_auto_db.dc_smt_ods_bigin_pgm_instnc;

DROP TABLE IF EXISTS ~>tlmtcs_auto_db.dc_smt_ods_bigin_pgm_instnc_tmp;