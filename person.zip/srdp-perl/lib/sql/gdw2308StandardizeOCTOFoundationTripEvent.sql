-- Step 1-- Standardize OCTO Foundation Trip Event Drop recreate
--------------------------------------------------------------------------------------------------------
-- DESCRIPTION This script is used for loading TSP_TripEvent table from HDFS vendor Event file
---------------------------------------------------------------------------------------------------------

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tsp_tripevent_temp;

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripevent_temp(
 DataLoad_Dt  TIMESTAMP COMMENT 'Load date',
 SourceFileName_Ts TIMESTAMP COMMENT 'Source file datestamp',
 LoadEvent_Id BIGINT COMMENT 'Unique  Identifier to indicate the load',
 DeviceType_Cd BIGINT COMMENT 'To Indicate data record from Octo vendor',
 Contract_Nb STRING,
 Voucher_Nb BIGINT,
 Trip_Nb STRING COMMENT 'Trip number',
 EnrolledVIN_Nb STRING COMMENT 'Enrolled Vehicle Indentification number',
 DetectedVIN_Nb STRING COMMENT 'Detected Vehicle Indentification number',
 Event_Ts TIMESTAMP,
 EventTimeZoneOffSet_Nb STRING,
 Latitude_It DOUBLE,
 Longitude_It DOUBLE,
 EventType_Cd STRING,
 EventReferenceValue_Ds STRING,
 EventStart_Ts TIMESTAMP,
 EventEnd_Ts TIMESTAMP,
 EventDuration_Am DOUBLE,
 source_cd string, batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripevent_temp';



set mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.smartride_WK_OCTO_TSP_TripEvent_Temp from ~>staging_db.smartride_OCTO_TripEvent";


-- Step 2-- Standardize OCTO Foundation Trip Event Wk Table Load
--------------------------------------------------------------------------------------------------------
-- DESCRIPTION This script is used for loading TSP_TripEvent table from HDFS vendor Event file
--------------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripevent_temp
SELECT
from_unixtime(unix_timestamp())as DataLoad_Dt,
CONCAT(substr(batch,1,4),'-',substr(batch,5,2),'-',substr(batch,7,2),' ',CASE substr(batch,9,2) WHEN '24' THEN '00' ELSE substr(batch,9,2) END,':',substr(batch,11,2),':00','.000000')as SourceFileName_Ts,
loadevent, 
Type_Cd,
contract_nb,
Voucher_Nb,
Trip_Nb,
EnrolledVIN_Nb,
DetectedVIN_Nb,
Event_Ts,    
EventTimeZoneOffSet_Nb,
Latitude_It,
Longitude_It,  
EventType_Cd,
EventReferenceValue_Ds,
EventStart_Ts,
EventEnd_Ts,
EventDuration_Am,
'OCTO' as source_cd,
batch
FROM ~>staging_db.smartride_octo_tripevent
WHERE loadevent in (~>load_event_id_list);

-- Step 3-- Standardize OCTO Foundation Trip Event Load TSP Trip Event

--------------------------------------------------------------------------------------------------------
-- DESCRIPTION This script is used for loading TSP_TripEvent table from HDFS vendor Event file
---------------------------------------------------------------------------------------------------------

DROP TABLE IF EXISTS  ~>work_db.smartride_wk_octo_tsp_tripevent;

set mapred.job.name = "~>job_cd Load data into smartride_tsp_tripevent table from smartride_wk_octo_tsp_tripevent table";

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripevent(
  dataload_dt timestamp,
  sourcefilename_ts timestamp,
  loadevent_id bigint,
  devicetype_cd bigint,
  contract_nb string,
  voucher_nb bigint,
  trip_nb string,
  enrolledvin_nb string,
  detectedvin_nb string,
  event_ts timestamp,
  eventtimezoneoffset_nb string,
  latitude_it double,
  longitude_it double,
  eventtype_cd string,
  eventreferencevalue_ds string,
  eventstart_ts timestamp,
  eventend_ts timestamp,
  eventduration_am double,
  source_cd string,
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripevent';

from ~>work_db.smartride_wk_octo_tsp_tripevent_temp
INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripevent
Select
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id, 
DeviceType_Cd,
contract_nb,
Voucher_Nb,
Trip_Nb,
EnrolledVIN_Nb,
'' as DetectedVIN_Nb,
Event_Ts,    
EventTimeZoneOffSet_Nb,
Latitude_It,
Longitude_It,  
EventType_Cd,
EventReferenceValue_Ds,
EventStart_Ts,
EventEnd_Ts,
EventDuration_Am,
source_cd,
batch 

INSERT OVERWRITE TABLE ~>foundation_db.smartride_tsp_tripevent
PARTITION (source_cd='OCTO', batch)
SELECT 
 DataLoad_Dt  ,
 SourceFileName_Ts ,
 LoadEvent_Id, 
 DeviceType_Cd ,
 Contract_Nb ,
 Voucher_Nb,
 Trip_Nb ,
 EnrolledVIN_Nb ,
 '' as DetectedVIN_Nb,
 Event_Ts ,    
 EventTimeZoneOffSet_Nb ,
 Latitude_It ,
 Longitude_It ,  
 EventType_Cd ,
 EventReferenceValue_Ds ,
 EventStart_Ts ,
 EventEnd_Ts,
 EventDuration_Am,
 batch
;