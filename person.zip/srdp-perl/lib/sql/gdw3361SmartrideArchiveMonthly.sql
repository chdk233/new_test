
--use ~>smartride_canonical_database;
use ~>foundation_db;

ALTER TABLE ~>smartride_archive_hive_database.hive_sre_summary_swap drop partition(source_cd='OCTO');
ALTER TABLE ~>smartride_archive_hive_database.hive_sre_summary_swap drop partition(source_cd='IMS');
ALTER TABLE ~>smartride_archive_hive_database.hive_sre_summary_swap EXCHANGE partition(source_cd='OCTO') WITH TABLE hive_sre_summary;
ALTER TABLE ~>smartride_archive_hive_database.hive_sre_summary_swap EXCHANGE partition(source_cd='IMS') WITH TABLE hive_sre_summary;


set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.parallel=true;

--set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_database.hive_sre_summary, smartride_archive_hive_database.hive_sre_summary from smartride_archive_hive_database.hive_sre_summary_swap";
set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.hive_sre_summary, smartride_archive_hive_database.hive_sre_summary from smartride_archive_hive_database.hive_sre_summary_swap";

from ~>smartride_archive_hive_database.hive_sre_summary_swap
insert overwrite table ~>foundation_db.hive_sre_summary partition(source_cd)
Select 
 sr_pgm_instnc_id
,period_type
,periodstart_ts
,periodend_ts
,miles
,kilometers
,night_time_driving_sec_ct
,fast_acceleration_ct
,hard_brake_ct
,idle_time_sec_ct
,drive_time_sec_ct
,idle_time_ratio
,trip_seconds_json
,source_cd
where period_type = 't' OR  periodstart_ts >= cast('~>archive_date 00:00:00' as timestamp) 

insert into table ~>smartride_archive_hive_database.hive_sre_summary partition(source_cd)
Select 
 sr_pgm_instnc_id
,period_type
,periodstart_ts
,periodend_ts
,miles
,kilometers
,night_time_driving_sec_ct
,fast_acceleration_ct
,hard_brake_ct
,idle_time_sec_ct
,drive_time_sec_ct
,idle_time_ratio
,trip_seconds_json
,source_cd
where  period_type != 't' OR  periodstart_ts < cast('~>archive_date 00:00:00' as timestamp);
