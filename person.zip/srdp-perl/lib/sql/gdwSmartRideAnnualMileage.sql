
DROP TABLE IF EXISTS ~>work_db.smartride_wk_device_vin;

SET mapred.job.name = "~>job_cd Create Table smartride_wk_device_vin from smartride_SMT_ODS_BIGIN_PGM_INSTNC";

CREATE TABLE ~>work_db.smartride_wk_device_vin (
      sr_pgm_instnc_id     bigint,
      vhcl_id_nbr     string,
      dev_id_nbr     bigint,
      plcy_ratd_st_cd     string,
      active_end_dt timestamp,
      active_start_dt timestamp)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_device_vin';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_device_vin
  SELECT DISTINCT sr_pgm_instnc_id
                 ,vhcl_id_nbr
                 ,dev_id_nbr
                 ,plcy_ratd_st_cd
                 ,active_end_dt
                 ,active_start_dt               
  FROM   ~>foundation_db.smartride_SMT_ODS_BIGIN_PGM_INSTNC
  WHERE  plcy_ratd_st_cd = 'CA'
  AND    date(active_end_dt) = date('3500-01-01');

DROP TABLE IF EXISTS ~>work_db.smartride_wk_hive_sre_daily;

SET mapred.job.name = "~>job_cd Create Table smartride_wk_hive_sre_daily from smartride_hive_sre_hourly";

CREATE TABLE ~>work_db.smartride_wk_hive_sre_daily
(
     sr_pgm_instnc_id    bigint,
     deviceserial_nb    bigint,
     enrolledvin_nb    string,
     plcy_ratd_st_cd    string,
     trip_date    varchar(10),
     miles    double,
     kms    double,
     adjusted_miles    double,
     adjusted_kms    double,
     plausible_miles    double,
     plausible_kms    double,
     idle_time_sec_count    bigint,
     plausible_idle_time_sec_count    bigint,
     drive_time_sec_count    bigint,
     plausible_drive_time_sec_count    bigint)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_hive_sre_daily';

INSERT INTO TABLE  ~>work_db.smartride_wk_hive_sre_daily 
  SELECT dev.sr_pgm_instnc_id,
         dev.dev_id_nbr,
         hr.enrolledvin_nb,
         dev.plcy_ratd_st_cd,
         CAST(hr.periodstart_ts AS VARCHAR(10)) AS trip_date,
         SUM(hr.miles) AS miles,
         SUM(hr.miles) * 1.609334 AS kms,
         SUM(hr.adjusted_miles) AS adjusted_miles,
         SUM(hr.adjusted_miles) * 1.609334 AS adjusted_kms,
         SUM(hr.plausible_miles) AS plausible_miles,
         SUM(hr.plausible_miles) * 1.609334 AS plausible_kms,
         SUM(hr.idle_time_sec_count) AS idle_time_sec_count,
         SUM(hr.plausible_idle_time_sec_count) AS plausible_idle_time_sec_count,
         SUM(hr.drive_time_sec_count) AS drive_time_sec_count,
         SUM(hr.plausible_drive_time_sec_count) AS plausible_drive_time_sec_count
  FROM   ~>foundation_db.smartride_hive_sre_hourly hr
  JOIN   ~>work_db.smartride_wk_device_vin dev
  ON     hr.enrolledvin_nb = dev.vhcl_id_nbr 
          AND    source_cd = 'IMS'
          AND	   hr.periodstart_ts >= dev.active_start_dt 
          AND	   hr.periodstart_ts < dev.active_end_dt 
          AND	   date(active_start_dt) >= add_months(current_date,-18)
  GROUP  BY dev.sr_pgm_instnc_id,
            dev.dev_id_nbr,
            hr.enrolledvin_nb,
            dev.plcy_ratd_st_cd,
            Cast(hr.periodstart_ts AS VARCHAR(10));

DROP TABLE IF EXISTS ~>work_db.smartride_wk_device_install_pcnt;

SET mapred.job.name = "~>job_cd Create Table smartride_wk_device_install_pcnt from smartride_device_install_pcnt, smartride_work_hive_db.smartride_wk_device_vin";

CREATE TABLE ~>work_db.smartride_wk_device_install_pcnt (
     sr_pgm_instnc_id    bigint,
     deviceserial_id    bigint,
     enrolledvin_nb    string,
     first_activity_date    timestamp,
     last_activity_date    timestamp,
     total_days    bigint,
     days_installed    bigint,
     install_percentage    double,
     uninstall_percentage    double,
     plcy_ratd_st_cd    string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_device_install_pcnt';

INSERT INTO TABLE  ~>work_db.smartride_wk_device_install_pcnt
  SELECT cdv.sr_pgm_instnc_id,
         cdv.dev_id_nbr,
         cdv.vhcl_id_nbr,
         first_activity_date,
         last_activity_date,
         total_days,
         days_installed,
         install_percentage,
         uninstall_percentage,
         plcy_ratd_st_cd
  FROM   ~>foundation_db.smartride_device_install_pcnt dip
         INNER JOIN ~>work_db.smartride_wk_device_vin cdv
                  ON dip.enrolledvin_nb = cdv.vhcl_id_nbr
                  AND first_activity_date >= cdv.active_start_dt
                  AND	first_activity_date < cdv.active_end_dt
                  AND	date(active_start_dt) >= add_months(current_date,-18);

DROP TABLE IF EXISTS ~>work_db.smartride_wk_device_active_days;

SET mapred.job.name = "~>job_cd Create Table smartride_wk_device_active_days from smartride_wk_device_install_pcnt";

CREATE TABLE ~>work_db.smartride_wk_device_active_days (
      sr_pgm_instnc_id     bigint, 
      deviceserial_id     bigint, 
      enrolledvin_nb     string, 
      trip_dt     string, 
      first_activity_date     timestamp, 
      last_activity_date     timestamp, 
      total_days     bigint, 
      days_installed     bigint, 
      install_percentage     double, 
      uninstall_percentage     double, 
      plcy_ratd_st_cd     string)
STORED AS PARQUET 
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_device_active_days';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_device_active_days 
SELECT sr_pgm_instnc_id,
       deviceserial_id,
       enrolledvin_nb,
       Date_add(Cast(Cast(first_activity_date AS VARCHAR(10)) AS DATE), Cast(day_id AS INT)) AS trip_dt,
       first_activity_date,
       last_activity_date,
       total_days,
       days_installed,
       install_percentage,
       uninstall_percentage,
       plcy_ratd_st_cd
FROM   ~>work_db.smartride_wk_device_install_pcnt dip
JOIN   telematics_provide_db.days d
WHERE  d.day_id <= total_days ;

DROP TABLE IF EXISTS ~>work_db.smartride_wk_annual_mileage;

SET mapred.job.name = "~>job_cd Create Table smartride_wk_annual_mileage from smartride_wk_device_active_days, smartride_wk_hive_sre_daily";

CREATE TABLE ~>work_db.smartride_wk_annual_mileage (
  sr_pgm_instnc_id     bigint,
  deviceserial_id     bigint,
  enrolledvin_nb     string,
  plcy_ratd_st_cd     string,
  first_activity_date     timestamp,
  last_activity_date     timestamp,
  days_installed     bigint,
  install_percentage     double,
  uninstall_percentage     double,
  plausible_speed_pcnt     double,
  tier1_10avg     decimal(10,0),
  tier11_30avg     decimal(10,0),
  tier31_70avg     decimal(10,0),
  tier71_90avg     decimal(10,0),
  tier91_100avg     decimal(10,0),
  estimatedkilometers     double,
  estimatedmileage     double,
  floor_estimatedkilometers     bigint,
  rate_in     string,
  load_date     varchar(10))
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_annual_mileage';

INSERT INTO TABLE ~>work_db.smartride_wk_annual_mileage 
SELECT
 S4.sr_pgm_instnc_id
,S4.DeviceSerial_Id
,S4.EnrolledVIN_Nb
,S4.plcy_ratd_st_cd
,S4.first_activity_date
,S4.last_activity_date
,S4.Days_Installed
,S4.install_percentage
,S4.uninstall_percentage
,S4.plausible_speed_pcnt
,S4.Tier1_10Avg
,S4.Tier11_30Avg
,S4.Tier31_70Avg
,S4.Tier71_90Avg
,S4.Tier91_100Avg
,(365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) ) AS EstimatedKilometers
,((365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) ) /1.609344) AS EstimatedMileage
,FLOOR((365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) )) AS Floor_EstimatedKilometers
,CASE WHEN (S4.uninstall_percentage > 5 OR S4.plausible_speed_pcnt < 97) THEN 'N' ELSE 'Y' END AS RATE_IN
,CAST (from_unixtime(unix_timestamp()) AS varchar(10)) AS load_date
FROM
(
SELECT
 S3.sr_pgm_instnc_id
,S3.DeviceSerial_Id
,S3.EnrolledVIN_Nb
,S3.first_activity_date
,S3.last_activity_date
,S3.Days_Installed
,S3.install_percentage
,S3.uninstall_percentage
,S3.plausible_speed_pcnt
,CASE WHEN S3.Tier00_10Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier1_10Dist / S3.Tier00_10Obs_Ct) AS DECIMAL) END AS Tier1_10Avg
,CASE WHEN S3.Tier11_30Obs_Ct = 0.00 THEN CAST(0.00  AS DECIMAL) ELSE CAST((S3.Tier11_30Dist / S3.Tier11_30Obs_Ct) AS DECIMAL) END AS Tier11_30Avg
,CASE WHEN S3.Tier31_70Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier31_70Dist / S3.Tier31_70Obs_Ct) AS DECIMAL) END AS Tier31_70Avg
,CASE WHEN S3.Tier71_90Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL)  ELSE CAST((S3.Tier71_90Dist / S3.Tier71_90Obs_Ct) AS DECIMAL) END AS Tier71_90Avg
,CASE WHEN S3.Tier91_100Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier91_100Dist / S3.Tier91_100Obs_Ct) AS DECIMAL) END AS Tier91_100Avg
--,EstimatedKilometers/1.609344 AS EstimatedMileage
,s3.plcy_ratd_st_cd
FROM
(
SELECT
 s2.sr_pgm_instnc_id
,s2.DeviceSerial_Id
,s2.EnrolledVIN_Nb
,s2.first_activity_date
,s2.last_activity_date
,s2.Days_Installed
,s2.install_percentage
,s2.uninstall_percentage
,CASE WHEN (SUM(s2.idle_time_sec_count) + SUM(s2.drive_time_sec_count)) = 0 THEN 0.00
     ELSE (((SUM(s2.plausible_idle_time_sec_count)  + SUM(s2.plausible_drive_time_sec_count))/(SUM(s2.idle_time_sec_count) + SUM(s2.drive_time_sec_count))) * 100)
     END AS plausible_speed_pcnt
,SUM(CASE WHEN S2.PctRank < 0.10 THEN 1.00 ELSE 0.00 END)   AS Tier00_10Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.10 AND S2.PctRank < 0.30 THEN 1.00 ELSE 0.00 END)  AS Tier11_30Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.30  AND S2.PctRank < 0.70 THEN 1.00 ELSE 0.00 END)  AS Tier31_70Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.70 AND S2.PctRank < 0.90 THEN 1.00 ELSE 0.00 END)  AS Tier71_90Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.90  THEN 1.00 ELSE 0.00 END)  AS Tier91_100Obs_Ct
,SUM(CASE WHEN S2.PctRank < 0.10 THEN S2.Distance_kms ELSE 0.00 END)  AS Tier1_10Dist
,SUM(CASE WHEN S2.PctRank >= 0.10 AND S2.PctRank < 0.30 THEN S2.Distance_kms ELSE 0.00 END)  AS  Tier11_30Dist
,SUM(CASE WHEN S2.PctRank >= 0.30  AND S2.PctRank < 0.70 THEN S2.Distance_kms ELSE 0.00 END) AS  Tier31_70Dist
,SUM(CASE WHEN  S2.PctRank >= 0.70 AND S2.PctRank < 0.90 THEN S2.Distance_kms ELSE 0.00 END) AS  Tier71_90Dist
,SUM(CASE WHEN S2.PctRank >= 0.90 THEN S2.Distance_kms ELSE 0.00 END)  AS Tier91_100Dist
,s2.plcy_ratd_st_cd
FROM
(
SELECT
s1.sr_pgm_instnc_id,
s1.DeviceSerial_Id ,
s1.EnrolledVIN_Nb,
s1.Distance_kms,
s1.first_activity_date,
s1.last_activity_date,
s1.total_days,
s1.days_installed,
s1.install_percentage,
s1.uninstall_percentage,
s1.plausible_idle_time_sec_count,
s1.plausible_drive_time_sec_count,
s1.idle_time_sec_count,
s1.drive_time_sec_count,
s1.RankDistance,
s1.Obs_Ct,
CAST((s1.RankDistance / s1.Obs_Ct ) AS DECIMAL ) AS PctRank,
s1.plcy_ratd_st_cd
FROM
(SELECT
dad.sr_pgm_instnc_id,
dad.DeviceSerial_Id ,
dad.EnrolledVIN_Nb,
CASE WHEN (kms IS NULL) THEN 0.00 ELSE kms END AS Distance_kms,
--dad.Trip_Dt,
first_activity_date,
last_activity_date,
total_days,
(days_installed + 1) AS days_installed,
install_percentage,
uninstall_percentage,
CASE WHEN (idle_time_sec_count IS NULL) THEN CAST(0 AS BIGINT) ELSE idle_time_sec_count END AS idle_time_sec_count,
CASE WHEN (plausible_idle_time_sec_count IS NULL) THEN CAST(0 AS BIGINT) ELSE plausible_idle_time_sec_count END AS plausible_idle_time_sec_count,
CASE WHEN (drive_time_sec_count IS NULL) THEN CAST(0 AS BIGINT) ELSE drive_time_sec_count END AS drive_time_sec_count,
CASE WHEN (plausible_drive_time_sec_count IS NULL) THEN CAST(0 AS BIGINT) ELSE plausible_drive_time_sec_count END AS plausible_drive_time_sec_count,
ROW_NUMBER() OVER(PARTITION BY dad.sr_pgm_instnc_id , dad.DeviceSerial_Id, dad.EnrolledVIN_Nb ORDER BY kms) AS RankDistance,
COUNT(*) OVER(PARTITION BY dad.sr_pgm_instnc_id , dad.DeviceSerial_Id, dad.EnrolledVIN_Nb) AS Obs_Ct,
dad.plcy_ratd_st_cd
FROM ~>work_db.smartride_wk_device_active_days dad
JOIN ~>work_db.smartride_wk_hive_sre_daily hsd
ON dad.EnrolledVIN_Nb = hsd.enrolledvin_nb
AND dad.Trip_Dt = hsd.trip_date) s1 )s2
GROUP BY
 s2.sr_pgm_instnc_id
,s2.DeviceSerial_Id
,s2.EnrolledVIN_Nb
,s2.first_activity_date
,s2.last_activity_date
,s2.Days_Installed
,s2.install_percentage
,s2.uninstall_percentage
,s2.plcy_ratd_st_cd
)S3
)S4
;

SET hive.exec.dynamic.partition=TRUE;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.exec.parallel=FALSE;

SET mapred.job.name = "~>job_cd Insert Overwrite smartride_annual_mileage from smartride_wk_annual_mileage";

INSERT OVERWRITE TABLE ~>provide_db.smartride_annual_mileage partition (load_date)
SELECT
  sr_pgm_instnc_id
,deviceserial_id
,enrolledvin_nb
,plcy_ratd_st_cd
,first_activity_date
,last_activity_date
,days_installed
,install_percentage
,uninstall_percentage
,plausible_speed_pcnt
,tier1_10avg
,tier11_30avg
,tier31_70avg
,tier71_90avg
,tier91_100avg
,estimatedkilometers
,estimatedmileage
,load_date
FROM
~>work_db.smartride_wk_annual_mileage;

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ca_annual_mileage_score;

SET mapred.job.name = "~>job_cd Create Table smartride_wk_ca_annual_mileage_score from smartride_wk_annual_mileage";

CREATE TABLE ~>work_db.smartride_wk_ca_annual_mileage_score (
      deviceserial_nb     string, 
      policy_nb     string, 
      enrolledvin_nb     string, 
      score_dt     string, 
      tripstart_dt     string, 
      tripend_dt     string, 
      score_days     string, 
      percenttime_disconnected     string, 
      score_1     string, 
      score_2     string, 
      score_3     string, 
      score_4     string, 
      score_5     string, 
      score_6     string, 
      score_7     string, 
      score_8     string, 
      score_9     string, 
      score_10     string, 
      floor_estimatedkilometers     string, 
      filler     string, 
      score_date     varchar(10))
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ca_annual_mileage_score';

INSERT INTO TABLE ~>work_db.smartride_wk_ca_annual_mileage_score 
SELECT
LPAD(TRIM(CAST( deviceserial_id AS VARCHAR(19))),20,' ') AS DeviceSerial_Nb
,'                    ' AS Policy_Nb
,enrolledvin_nb
,translate(load_date, '-', '') AS Score_Dt
,translate(CAST(first_activity_date AS varchar(10)),'-','') AS TripStart_Dt
,translate(CAST(last_activity_date AS varchar(10)),'-','') AS TripEnd_Dt
,LPAD(cast(days_installed AS varchar(3)),3,' ') AS Score_Days
,concat(lpad(floor(CAST (uninstall_percentage AS decimal(5,2))),2,' '),'.',rpad(((abs(CAST (uninstall_percentage AS decimal(5,2))) - floor(abs(CAST (uninstall_percentage AS decimal(5,2)))))*100),2,'0')) AS PercentTime_Disconnected
,' -1' AS  Score_1
,CASE WHEN uninstall_percentage > 5 AND floor(plausible_speed_pcnt) < 97 THEN '998'
     WHEN uninstall_percentage > 5 THEN '998'
     WHEN uninstall_percentage < 5 AND floor(plausible_speed_pcnt) < 97  THEN '997'
     ELSE ' -1'  END AS Score_2
,' -1' AS  Score_3
,' -1' AS  Score_4
,' -1' AS  Score_5
,' -1' AS  Score_6
,' -1' AS  Score_7
,' -1' AS  Score_8
,' -1' AS  Score_9
,' -1' AS  Score_10
,LPAD(CAST(floor_estimatedkilometers AS varchar(6)),6,' ') AS floor_estimatedkilometers
,RPAD('',128,' ') AS filler
,CAST (from_unixtime(unix_timestamp()) AS varchar(10) ) AS Score_Date
FROM ~>work_db.smartride_wk_annual_mileage WHERE plcy_ratd_st_cd = 'CA';

INSERT OVERWRITE TABLE ~>provide_db.smartride_ca_annual_mileage_score_file 
SELECT CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(deviceserial_nb,policy_nb),enrolledvin_nb),score_dt),tripstart_dt),tripend_dt),score_days),percenttime_disconnected),score_1),score_2),score_3),score_4),score_5),score_6),score_7),score_8),score_9),score_10),floor_estimatedkilometers),filler) AS value
FROM ~>work_db.smartride_wk_ca_annual_mileage_score;

SET hive.exec.dynamic.partition=TRUE;
SET hive.exec.dynamic.partition.mode=nonstrict;

SET mapred.job.name = "~>job_cd Insert Overwrite smartride_annual_mileage_score from smartride_wk_ca_annual_mileage_score";

INSERT overwrite TABLE ~>provide_db.smartride_annual_mileage_score
PARTITION(score_date)
SELECT
 deviceserial_nb
,policy_nb
,enrolledvin_nb
,score_dt
,tripstart_dt
,tripend_dt
,score_days
,percenttime_disconnected
,score_1
,score_2
,score_3
,score_4
,score_5
,score_6
,score_7
,score_8
,score_9
,score_10
,floor_estimatedkilometers
,filler
,score_date
FROM ~>work_db.smartride_wk_ca_annual_mileage_score;