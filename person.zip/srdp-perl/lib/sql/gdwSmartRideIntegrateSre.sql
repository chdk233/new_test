
DROP TABLE IF EXISTS ~>work_db.~>wk_trip_details_piid;

CREATE TABLE ~>work_db.~>wk_trip_details_piid(
  enrolledvin_nb string,
  sr_pgm_instnc_id bigint,
  sr_enrlmnt_dt timestamp,
  active_start_dt timestamp,
  active_end_dt timestamp,
  plcy_ratd_st_cd string
)
STORED AS ORC
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/~>wk_trip_details_piid';

set hive.support.concurrency=false;
set hive.lock.manager= ;
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.map.aggr=true;
SET hive.exec.parallel=true;
set hive.exec.compress.intermediate=true;
set mapred.map.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.exec.reducers.bytes.per.reducer=128000000;
set hive.merge.tezfiles=true;
set hive.merge.smallfiles.avgsize=128000000;
set hive.merge.size.per.task=128000000;
set tez.grouping.min-size=34000000;
set tez.grouping.max-size=128000000;

set mapred.job.name = "~>job_cd Insert Into ~>work_db.~>wk_trip_details_piid from ~>work_db.~>wk_trip_details";

insert into ~>work_db.~>wk_trip_details_piid 
SELECT
enrolledvin_nb,
sr_pgm_instnc_id,
sr_enrlmnt_dt,
active_start_dt,
active_end_dt,
plcy_ratd_st_cd
from (
    select
    enrolledvin_nb,
    sr_pgm_instnc_id,
    sr_enrlmnt_dt,
    active_start_dt,
    active_end_dt,
    plcy_ratd_st_cd,
    ROW_NUMBER() over (partition by enrolledvin_nb order by active_start_dt desc) as row_nb
    from ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc ods
    join ~>work_db.~>wk_trip_details wtd
    on wtd.enrolledvin_nb = ods.vhcl_id_nbr
    where active_start_dt >= '~>date_filter_18_mo_ago'
    group by
    enrolledvin_nb,
    sr_pgm_instnc_id,
    sr_enrlmnt_dt,
    active_start_dt,
    active_end_dt,
    plcy_ratd_st_cd
    ) query
where row_nb = 1;

DROP TABLE IF EXISTS ~>work_db.~>wk_delta_data;

set mapred.job.name = "~>job_cd Create Table ~>work_db.wk_delta_data from ~>foundation_db.trip_details, ~>work_db.wk_trip_details_piid";

CREATE TABLE ~>work_db.~>wk_delta_data (
      sr_pgm_instnc_id     bigint, 
      periodstart_ts     timestamp, 
      periodend_ts     timestamp, 
      trip_cn     int, 
      miles     double, 
      kilometers     double, 
      night_time_driving_sec_ct     int, 
      fast_acceleration_ct     int, 
      hard_brake_ct     int, 
      idle_time_sec_ct     int, 
      drive_time_sec_ct     int,
      idle_time_ratio     double,
      trip_nb     string, 
      period_type_trip     varchar(20), 
      period_type_day     varchar(20), 
      periodstart_ts_day     timestamp, 
      periodend_ts_day     timestamp, 
      period_type_week     varchar(20), 
      periodstart_ts_week     timestamp, 
      periodend_ts_week     timestamp, 
      period_type_month     varchar(20), 
      periodstart_ts_month     timestamp, 
      periodend_ts_month     timestamp, 
      period_type_total     varchar(20), 
      periodstart_ts_total     timestamp, 
      periodend_ts_total     timestamp, 
      trip_seconds_json     string)
STORED AS PARQUET
LOCATION
   'hdfs:///user/hive/warehouse/~>work_db/~>wk_delta_data'; 

INSERT OVERWRITE TABLE ~>work_db.~>wk_delta_data
SELECT 
CAST(wk.SR_PGM_INSTNC_ID AS BIGINT) AS SR_PGM_INSTNC_ID
,PERIODSTART_TS
,PERIODEND_TS
,1 as TRIP_CN
,MILES AS MILES
,KILOMETERS As KILOMETERS
,NIGHT_TIME_DRIVING_SEC_CT AS NIGHT_TIME_DRIVING_SEC_CT
,FAST_ACCELERATION_CT AS FAST_ACCELERATION_CT
,HARD_BRAKE_CT AS HARD_BRAKE_CT
,CASE WHEN wk.plcy_ratd_st_cd = 'CA' THEN 0 ELSE IDLE_TIME_SEC_CT END AS IDLE_TIME_SEC_CT
,CASE WHEN wk.plcy_ratd_st_cd = 'CA' THEN 0 ELSE DRIVE_TIME_SEC_CT END AS DRIVE_TIME_SEC_CT
,CASE WHEN wk.plcy_ratd_st_cd = 'CA' THEN 0 ELSE IDLE_TIME_RATIO END AS IDLE_TIME_RATIO
,TRIP_NB
,CAST('tp' AS VARCHAR(20)) as PERIOD_TYPE_trip
,CAST('d' AS VARCHAR(20)) AS PERIOD_TYPE_day
,CAST(CONCAT(substr(PERIODSTART_TS,0,10),' 00:00:00') AS TIMESTAMP) AS PERIODSTART_TS_day
,CAST(CONCAT(substr(PERIODSTART_TS,0,10),' 23:59:59') AS TIMESTAMP) AS PERIODEND_TS_day
,CAST('w' AS VARCHAR(20)) AS PERIOD_TYPE_week
,CASE CAST(date_format(PERIODSTART_TS,'u') as int) WHEN 7 THEN CAST(CONCAT(substr(PERIODSTART_TS,0,10),' 00:00:00') AS TIMESTAMP) 
ELSE CAST(CONCAT(date_sub(substr(PERIODSTART_TS,0,10),CAST(date_format(PERIODSTART_TS,'u') as int)),' 00:00:00') AS TIMESTAMP) END AS PERIODSTART_TS_week
,CASE CAST(date_format(PERIODSTART_TS,'u') as int) WHEN 7 THEN CAST(CONCAT(date_add(substr(PERIODSTART_TS,0,10),6),' 23:59:59.0') AS TIMESTAMP) 
ELSE CAST(CONCAT(date_add(substr(PERIODSTART_TS,0,10),6-CAST(date_format(PERIODSTART_TS,'u') as int)),' 23:59:59') AS TIMESTAMP) END AS PERIODEND_TS_week             
,CAST('m' AS VARCHAR(20)) AS PERIOD_TYPE_month
,CAST(CONCAT(substr(PERIODSTART_TS,0,7),'-01 00:00:00') AS TIMESTAMP) AS PERIODSTART_TS_month
,CAST(CONCAT(LAST_DAY(PERIODSTART_TS),' 23:59:59') AS TIMESTAMP) AS PERIODEND_TS_month
,CAST('t' AS VARCHAR(20)) AS PERIOD_TYPE_total
,CAST('1970-01-01 00:00:00.0' as TIMESTAMP)AS PERIODSTART_TS_total
,CAST('2999-12-31 00:00:00.0' as TIMESTAMP)AS PERIODEND_TS_total
,TRIP_SECONDS_JSON
FROM ~>work_db.~>wk_trip_details_piid  wk
INNER JOIN ~>foundation_db.smartride_trip_details td
on 
td.enrolledvin_nb = wk.enrolledvin_nb
where td.source_cd = '~>source_cd'
and td.periodstart_ts between wk.active_start_dt and wk.active_end_dt
and td.batch >= '~>batch_filter_18_mo_ago';


DROP TABLE IF EXISTS ~>work_db.~>wk_sre_summary_delta;


CREATE  TABLE ~>work_db.~>wk_sre_summary_delta(
 SR_PGM_INSTNC_ID BIGINT
,PERIODSTART_TS TIMESTAMP
,PERIODEND_TS TIMESTAMP
,TRIP_CN INT
,MILES DOUBLE
,KILOMETERS DOUBLE
,NIGHT_TIME_DRIVING_SEC_CT INT
,FAST_ACCELERATION_CT INT
,HARD_BRAKE_CT INT
,idle_time_SEC_CT INT
,DRIVE_TIME_SEC_CT INT
,idle_time_ratio double
,TRIP_SECONDS_JSON STRING
,PERIOD_TYPE string
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS ORC
LOCATION
      'hdfs:///user/hive/warehouse/~>work_db/~>wk_sre_summary_delta'; 


set mapred.job.name = "~>job_cd Insert Into work_db.wk_sre_summary_delta from smartride_work_hive_db.wk_delta_data";

insert into table ~>work_db.~>wk_sre_summary_delta  
Select  sr_pgm_instnc_id ,periodstart_ts ,periodend_ts, trip_cn ,miles ,kilometers ,night_time_driving_sec_ct ,fast_acceleration_ct ,hard_brake_ct ,idle_time_sec_ct ,drive_time_sec_ct ,idle_time_ratio ,trip_seconds_json ,period_type 
from (
SELECT sr_pgm_instnc_id,periodstart_ts AS periodstart_ts, periodend_ts AS periodend_ts, trip_cn, miles, kilometers, CAST(night_time_driving_sec_ct AS INT) AS night_time_driving_sec_ct, CAST(fast_acceleration_ct AS INT) AS fast_acceleration_ct,CAST(hard_brake_ct AS INT) AS hard_brake_ct, CAST(idle_time_sec_ct AS INT) AS idle_time_sec_ct,CAST(drive_time_sec_ct AS INT) AS drive_time_sec_ct, CAST(idle_time_ratio AS DOUBLE) AS idle_time_ratio ,trip_seconds_json ,	period_type_trip AS  period_type from ~>work_db.~>wk_delta_data 
UNION ALL 
SELECT sr_pgm_instnc_id,periodstart_ts_day AS periodstart_ts, periodend_ts_day AS periodend_ts, SUM(trip_cn)AS trip_cn, SUM(miles) AS miles, SUM(kilometers) AS kilometers, SUM(night_time_driving_sec_ct) AS night_time_driving_sec_ct, SUM(fast_acceleration_ct)AS fast_acceleration_ct ,SUM(hard_brake_ct)  AS hard_brake_ct,		SUM(idle_time_sec_ct) AS idle_time_sec_ct,SUM(drive_time_sec_ct) AS drive_time_sec_ct, IF(SUM(drive_time_sec_ct) = 0,0,SUM(idle_time_sec_ct)/SUM(drive_time_sec_ct)) AS  idle_time_ratio , CAST(' ' AS VARCHAR(32768))  AS trip_seconds_json,period_type_day AS  period_type from ~>work_db.~>wk_delta_data GROUP	BY  sr_pgm_instnc_id,period_type_day,periodstart_ts_day,periodend_ts_day 
UNION ALL 
SELECT sr_pgm_instnc_id,periodstart_ts_week AS periodstart_ts, periodend_ts_week AS periodend_ts, SUM(trip_cn)AS trip_cn ,SUM(miles) AS miles, SUM(kilometers) AS kilometers, SUM(night_time_driving_sec_ct) AS night_time_driving_sec_ct, SUM(fast_acceleration_ct)AS fast_acceleration_ct,SUM(hard_brake_ct)  AS hard_brake_ct , SUM(idle_time_sec_ct) AS idle_time_sec_ct,SUM(drive_time_sec_ct) AS drive_time_sec_ct, IF(SUM(drive_time_sec_ct) = 0,0,SUM(idle_time_sec_ct)/SUM(drive_time_sec_ct)) AS  idle_time_ratio , CAST(' ' AS VARCHAR(32768))  AS trip_seconds_json,period_type_week AS  period_type from ~>work_db.~>wk_delta_data GROUP	BY  sr_pgm_instnc_id,period_type_week,periodstart_ts_week,periodend_ts_week 
UNION ALL 
SELECT sr_pgm_instnc_id,periodstart_ts_month AS periodstart_ts, periodend_ts_month AS periodend_ts, SUM(trip_cn)AS trip_cn, SUM(miles) AS miles, SUM(kilometers) AS kilometers, SUM(night_time_driving_sec_ct) AS night_time_driving_sec_ct, SUM(fast_acceleration_ct)AS fast_acceleration_ct ,SUM(hard_brake_ct)  AS hard_brake_ct, SUM(idle_time_sec_ct) AS idle_time_sec_ct,SUM(drive_time_sec_ct) AS drive_time_sec_ct, IF(SUM(drive_time_sec_ct) = 0,0,SUM(idle_time_sec_ct)/SUM(drive_time_sec_ct)) AS  idle_time_ratio , CAST(' ' AS VARCHAR(32768))  AS trip_seconds_json ,period_type_month AS  period_type from ~>work_db.~>wk_delta_data GROUP	BY  sr_pgm_instnc_id,period_type_month,periodstart_ts_month,periodend_ts_month 
UNION ALL 
SELECT sr_pgm_instnc_id,periodstart_ts_total AS periodstart_ts, periodend_ts_total AS periodend_ts, SUM(trip_cn)AS trip_cn, SUM(miles) AS miles, SUM(kilometers) AS kilometers, SUM(night_time_driving_sec_ct) AS night_time_driving_sec_ct,SUM(fast_acceleration_ct)AS fast_acceleration_ct,SUM(hard_brake_ct)  AS hard_brake_ct, SUM(idle_time_sec_ct) AS idle_time_sec_ct,SUM(drive_time_sec_ct) AS drive_time_sec_ct, IF(SUM(drive_time_sec_ct) = 0,0,SUM(idle_time_sec_ct)/SUM(drive_time_sec_ct)) AS  idle_time_ratio, CAST(' ' AS VARCHAR(32768))  AS trip_seconds_json,period_type_total AS  period_type from ~>work_db.~>wk_delta_data GROUP BY sr_pgm_instnc_id,period_type_total,periodstart_ts_total,periodend_ts_total
) temp;

DROP TABLE IF EXISTS ~>work_db.~>wk_hive_sre_summary;

CREATE  TABLE ~>work_db.~>wk_hive_sre_summary(
  sr_pgm_instnc_id bigint, 
  period_type varchar(30), 
  periodstart_ts timestamp, 
  periodend_ts timestamp, 
  trip_cn int,
  miles double, 
  kilometers double, 
  night_time_driving_sec_ct int, 
  fast_acceleration_ct int, 
  hard_brake_ct int, 
  idle_time_sec_ct int, 
  drive_time_sec_ct int, 
  idle_time_ratio double, 
  trip_seconds_json string, 
  source_cd string)
STORED AS ORC
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/~>wk_hive_sre_summary';

INSERT INTO ~>work_db.~>wk_hive_sre_summary 
SELECT 
HSS.SR_PGM_INSTNC_ID
,HSS.PERIOD_TYPE
,HSS.PERIODSTART_TS
,HSS.PERIODEND_TS
,HSS.TRIP_CN
,HSS.MILES
,HSS.KILOMETERS
,HSS.NIGHT_TIME_DRIVING_sec_ct
,HSS.FAST_ACCELERATION_CT
,HSS.HARD_BRAKE_CT
,HSS.IDLE_TIME_sec_ct
,HSS.DRIVE_TIME_sec_ct
,HSS.IDLE_TIME_RATIO
,HSS.TRIP_SECONDS_JSON 
,'~>source_cd' as SOURCE_CD 
FROM ~>provide_db.smartride_hive_sre_summary HSS
LEFT OUTER JOIN  ~>work_db.~>wk_sre_summary_delta WSSD
ON WSSD.SR_PGM_INSTNC_ID = HSS.SR_PGM_INSTNC_ID 
WHERE HSS.SOURCE_CD = '~>source_cd' 
AND WSSD.SR_PGM_INSTNC_ID IS NULL 
AND HSS.PERIOD_TYPE in ('w', 'd','tp')
AND HSS.PERIODSTART_TS >= '~>date_filter_2_wks_from_sun';

INSERT INTO TABLE ~>work_db.~>wk_hive_sre_summary
SELECT 
CAST(SR_PGM_INSTNC_ID AS BIGINT) AS SR_PGM_INSTNC_ID
,CAST(PERIOD_TYPE AS VARCHAR(30)) AS PERIOD_TYPE
,CAST(PERIODSTART_TS AS TIMESTAMP) AS PERIODSTART_TS
,CAST(PERIODEND_TS AS TIMESTAMP) AS PERIODEND_TS
,CAST(TRIP_CN AS INT) AS TRIP_CN
,CAST(MILES AS DOUBLE) AS MILES
,CAST(KILOMETERS AS DOUBLE) AS KILOMETERS
,CAST(NIGHT_TIME_DRIVING_sec_ct AS INT) AS NIGHT_TIME_DRIVING_sec_ct
,CAST(FAST_ACCELERATION_CT AS INT) AS FAST_ACCELERATION_CT
,CAST(HARD_BRAKE_CT AS INT ) AS HARD_BRAKE_CT
,CAST(IDLE_TIME_sec_ct as INT) as IDLE_TIME_sec_ct
,CAST(DRIVE_TIME_sec_ct as INT) as DRIVE_TIME_sec_ct
,CAST(IDLE_TIME_RATIO as DOUBLE) as IDLE_TIME_RATIO,TRIP_SECONDS_JSON
,'~>source_cd' as SOURCE_CD FROM ~>work_db.~>wk_sre_summary_delta
WHERE PERIOD_TYPE in ('w', 'd','tp')
AND PERIODSTART_TS >= '~>date_filter_2_wks_from_sun';

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartride_hive_sre_summary from ~>work_db.~>wk_hive_sre_summary";

INSERT OVERWRITE TABLE ~>provide_db.smartride_hive_sre_summary partition(SOURCE_CD='~>source_cd') 
SELECT SR_PGM_INSTNC_ID
,PERIOD_TYPE
,PERIODSTART_TS
,PERIODEND_TS
,TRIP_CN
,MILES
,KILOMETERS
,NIGHT_TIME_DRIVING_sec_ct
,FAST_ACCELERATION_CT
,HARD_BRAKE_CT
,IDLE_TIME_sec_ct
,DRIVE_TIME_sec_ct
,IDLE_TIME_RATIO
,trip_seconds_json
FROM ~>work_db.~>wk_hive_sre_summary;

set mapred.job.name = "~>job_cd Insert Into ~>provide_db.sre_summary_ext from ~>work_db.wk_sre_summary_delta";

set hbase.zookeeper.quorum=~>zookeeper_quorum;

insert into ~>provide_db.smartride_sre_summary_ext
Select 
concat(concat(substr('00',1,2-length(cast(pmod(sr_pgm_instnc_id,~>splits)as varchar(2)))),cast(pmod(sr_pgm_instnc_id,16)as varchar(2))), '_', sr_pgm_instnc_id,'_',Period_type,'_',unix_timestamp(periodstart_ts) + (case
when periodstart_ts between date_format( cast(extract(year from periodstart_ts) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(periodstart_ts as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(periodstart_ts as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from periodstart_ts) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(periodstart_ts as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(periodstart_ts as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600 ) as key,
unix_timestamp(periodend_ts) + (case
when periodend_ts between date_format( cast(extract(year from periodend_ts) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(periodend_ts as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(periodend_ts as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from periodend_ts) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(periodend_ts as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(periodend_ts as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600 as pets,
trip_cn,
miles as mls,
night_time_driving_sec_ct as ntd,
fast_acceleration_ct as fac,hard_brake_ct as hbc,
idle_time_sec_ct as it,
DRIVE_TIME_sec_CT as dt,
idle_time_ratio as itr,
regexp_replace(trip_seconds_json,',','\;') as tsj 
from ~>work_db.~>wk_sre_summary_delta;