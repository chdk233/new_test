set hive.exec.dynamic.partition.mode=nonstrict
set hive.merge.tezfiles=true;

DROP TABLE IF EXISTS ~>work_db.expn_vehicle;

CREATE  TABLE ~>work_db.expn_vehicle
(
Vin10_Nb STRING
,State_Cd STRING
,Make_Ds STRING
,Model_Ds STRING
,ManufactureYear_Nb STRING
,ProgramStart_Ts  TIMESTAMP
,ProgramStartOffsetTime_Am DOUBLE
,ProgramEnd_Ts TIMESTAMP
,ProgramEndOffsetTime_Am DOUBLE
,loadevent_id DOUBLE
,SourceFile_Dt STRING
,PartnerNotification_Id STRING
) 
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/expn_vehicle'
;

DROP TABLE IF EXISTS ~>work_db.expn_trip_summary;

CREATE TABLE ~>work_db.expn_trip_summary
(TripStart_Ts TIMESTAMP
,TripStartOffsetTime_Am DOUBLE
,TripEnd_Ts TIMESTAMP
,TripEndtOffsetTime_Am DOUBLE
,OdometerReadingStart_Qt DOUBLE
,OdometerReadingEnd_Qt DOUBLE
,IdleTime_Am INT
, loadevent_id DOUBLE
,SourceFile_Dt STRING
,PartnerNotification_Id STRING
) 
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/expn_trip_summary'
;


DROP TABLE IF EXISTS ~>work_db.expn_trip_event;

CREATE  TABLE ~>work_db.expn_trip_event
(
Event_Ts TIMESTAMP
,EventOffsetTime_Am DOUBLE
,VehicleSpeed_Am DOUBLE
,HardBrakesAcceleration_Am DOUBLE
, loadevent_id DOUBLE
,SourceFile_Dt STRING
,PartnerNotification_Id STRING
) STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/expn_trip_event'
;

set mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.wk_vehicle, wk_tripsummary, wk_tripevent from ~>staging_db.experian_driving";

FROM ~>staging_db.experian_driving
INSERT OVERWRITE TABLE ~>work_db.expn_vehicle
Select
col3 as Vin10_Nb
,col6 as State_Cd
,col8 as Make_Ds
,col9 as Model_Ds
,col7 as ManufactureYear_Nb
,CONCAT(SUBSTR(col4,0,10),' ',SUBSTR(col4,12,12)) as ProgramStart_Ts
,CAST(CONCAT(SUBSTR(col4,24,3),'.',SUBSTR(col4,28,2))  as DOUBLE)as ProgramStartOffsetTime_Am
,CONCAT(SUBSTR(col5,0,10),' ',SUBSTR(col5,12,12)) as ProgramEnd_Ts
,CAST(CONCAT(SUBSTR(col5,24,3),'.',SUBSTR(col5,28,2))  as DOUBLE)as ProgramStartOffsetTime_Am
,loadevent as loadevent_id
,sourcefile_dt
,col2 as PartnerNotification_Id
WHERE col1 = 'H' AND loadevent=~>load_event_id

INSERT OVERWRITE TABLE ~>work_db.expn_trip_summary
Select
CONCAT(SUBSTR(col2,0,10),' ',SUBSTR(col2,12,12)) as TripStart_Ts
,CAST(CONCAT(SUBSTR(col2,24,3),'.',SUBSTR(col2,28,2))  as DOUBLE) as TripStartOffsetTime_Am
,CONCAT(SUBSTR(col3,0,10),' ',SUBSTR(col3,12,12)) as TripEnd_Ts
,CAST(CONCAT(SUBSTR(col3,24,3),'.',SUBSTR(col3,28,2))  as DOUBLE) as TripEndtOffsetTime_Am
,col4 as OdometerReadingStart_Qt
,col5 as OdometerReadingEnd_Qt
,col6 as IdleTime_Am
,loadevent as loadevent_id
,sourcefile_dt
,PartnerNotification_Id
WHERE col1 = 'S' AND loadevent=~>load_event_id

INSERT OVERWRITE TABLE ~>work_db.expn_trip_event
Select
CONCAT(SUBSTR(col2,0,10),' ',SUBSTR(col2,12,12)) as Event_Ts
,CAST(CONCAT(SUBSTR(col2,24,3),'.',SUBSTR(col2,28,2))   as DOUBLE) as EventOffsetTime_Am
,col3 as VehicleSpeed_Am
,col4 as HardBrakesAcceleration_Am
,loadevent as loadevent_id
,sourcefile_dt
,PartnerNotification_Id
WHERE col1 = 'D' AND loadevent=~>load_event_id;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.Vehicle from experian_work_hive_db.expn_vehicle";

INSERT OVERWRITE TABLE  ~>foundation_db.experian_vehicle
PARTITION (sourcefile_dt)
Select
Vin10_Nb
,State_Cd
,Make_Ds
,Model_Ds
,ManufactureYear_Nb
,ProgramStart_Ts
,ProgramStartOffsetTime_Am
, ProgramEnd_Ts
,ProgramStartOffsetTime_Am
,loadevent_id
,PartnerNotification_Id
,sourcefile_dt
FROM ~>work_db.expn_vehicle;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.TripSummary from experian_work_hive_db.expn_trip_summary";

INSERT OVERWRITE TABLE  ~>foundation_db.experian_trip_summary
PARTITION (sourcefile_dt)
Select
TripStart_Ts
,TripStartOffsetTime_Am
,TripEnd_Ts
,TripEndtOffsetTime_Am
,OdometerReadingStart_Qt
,OdometerReadingEnd_Qt
,IdleTime_Am
,loadevent_id
,PartnerNotification_Id
,sourcefile_dt
FROM  ~>work_db.expn_trip_summary;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.TripEvent from experian_work_hive_db.expn_trip_event";

INSERT OVERWRITE TABLE  ~>foundation_db.experian_trip_event
PARTITION (sourcefile_dt)
Select
Event_Ts
,EventOffsetTime_Am
,VehicleSpeed_Am
,HardBrakesAcceleration_Am
,loadevent_id
,PartnerNotification_Id
,sourcefile_dt
FROM ~>work_db.expn_trip_event;