use ~>smartride_raw_hive_db;

alter table OCTO_TripPoint_Ext_h add IF NOT EXISTS partition (batch='~>batch_id');

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_OCTO_TSP_TripPoint;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_OCTO_TSP_TripPoint from smartride_raw_hive_db.OCTO_TripPoint_Ext_h";

CREATE TABLE ~>smartride_work_hive_db.WK_OCTO_TSP_TripPoint as
select cast(cast(DataLoad_Dt as date) as timestamp) as DataLoad_Dt,
cast(cast(DataLoad_Dt as date) as timestamp) as sourcefilename_ts,
~>load_event_id as LoadEvent_Id, 
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
Trip_Nb,
Position_Ts,
Latitude_It,
Longitude_It,
VSSSpeed_Am,
VSSAcceleration_Pc,
EngineRPM_Nb as EngineRPM_Qt,
ThrottlePosition_Pc,
AccelerationLateral_Nb as AccelerationLateral_Qt,
AccelerationLongitudinal_Nb as AccelerationLongitudinal_Qt,
AccelerationVertical_Nb as AccelerationVertical_Qt,    
GPSHeading_Nb,
PositionQuality_Nb,
OdometerReading_Qt,
EventAverageSpeed_Qt,
EventAverageAcceleration_Qt,
DistanceTravelled_Qt,
TimeElapsed_Qt,
GPSPointSpeed_Qt,
Road_Tp,
'OCTO' as Source_cd,
batch
from  ~>smartride_raw_hive_db.OCTO_TripPoint_Ext_h WHERE
batch='~>batch_id';

use smartride_canonical_hive_db;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=100000; 
set hive.exec.max.dynamic.partitions.pernode=100000; 

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.TSP_TripPoint from smartride_work_hive_db.WK_OCTO_TSP_TripPoint";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.TSP_TripPoint PARTITION(source_cd,batch)
SELECT
DataLoad_Dt,
sourcefilename_ts,
LoadEvent_Id,
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
Trip_Nb,
Position_Ts,
Latitude_It,
Longitude_It,
VSSSpeed_Am,
VSSAcceleration_Pc,
enginerpm_qt,
ThrottlePosition_Pc,
AccelerationLateral_qt,
AccelerationLongitudinal_qt,
AccelerationVertical_qt,
GPSHeading_Nb,
PositionQuality_Nb,
OdometerReading_Qt,
EventAverageSpeed_Qt,
EventAverageAcceleration_Qt,
DistanceTravelled_Qt,
TimeElapsed_Qt,
GPSPointSpeed_Qt,
Road_Tp,
source_cd,
batch
FROM ~>smartride_work_hive_db.WK_OCTO_TSP_TripPoint;
