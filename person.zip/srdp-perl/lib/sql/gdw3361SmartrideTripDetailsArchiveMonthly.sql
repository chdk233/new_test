 
LOAD DATA INPATH '~>base_load_path/source_cd=~>source_cd/batch=~>batch/*' OVERWRITE INTO TABLE ~>smartride_archive_hive_database.trip_details PARTITION(source_cd='~>source_cd',batch='~>batch');
 
--use ~>smartride_canonical_database;
 use  ~>foundation_db;

alter table trip_details drop if EXISTS partition (source_cd='~>source_cd',batch='~>batch');