set hive.exec.dynamic.partition.mode=nonstrict;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.experian_vehicle 
from ~>work_db.experian_vehicle_purge, ~>foundation_db.bindpolicy ";

DROP TABLE IF EXISTS ~>work_db.experian_vehicle_purge;

CREATE EXTERNAL TABLE ~>work_db.experian_vehicle_purge(
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb string, 
  programstart_ts timestamp, 
  programstartoffsettime_am double, 
  programend_ts timestamp, 
  programendoffsettime_am double, 
  loadevent_id double, 
  partnernotification_id string)
PARTITIONED BY ( 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>work_db/experian_vehicle_purge';

MSCK REPAIR TABLE ~>work_db.experian_vehicle_purge;

INSERT OVERWRITE TABLE  ~>foundation_db.experian_vehicle
PARTITION (sourcefile_dt)
SELECT
v.Vin10_Nb
,v.State_Cd
,v.Make_Ds
,v.Model_Ds
,v.ManufactureYear_Nb
,v.ProgramStart_Ts
,v.ProgramStartOffsetTime_Am
,v.ProgramEnd_Ts
,v.ProgramStartOffsetTime_Am
,v.loadevent_id
,v.PartnerNotification_Id
,v.sourcefile_dt
FROM ~>staging_db.experian_auto_quote_bind_policy bp
INNER JOIN ~>work_db.experian_vehicle_purge v
ON v.partnernotification_id = bp.partnernotification_id;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.experian_trip_summary 
from ~>work_db.experian_vehicle_purge, ~>staging_db.experian_auto_quote_bind_policy";

DROP TABLE IF EXISTS ~>work_db.experian_trip_summary_purge;

CREATE EXTERNAL TABLE ~>work_db.experian_trip_summary_purge(
  tripstart_ts timestamp, 
  tripstartoffsettime_am double, 
  tripend_ts timestamp, 
  tripendtoffsettime_am double, 
  odometerreadingstart_qt double, 
  odometerreadingend_qt double, 
  idletime_am int, 
  loadevent_id double, 
  partnernotification_id string)
PARTITIONED BY ( 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>work_db/experian_trip_summary_purge';

MSCK REPAIR TABLE ~>work_db.experian_trip_summary_purge;

INSERT OVERWRITE TABLE  ~>foundation_db.experian_trip_summary
PARTITION (sourcefile_dt)
SELECT
 ts.TripStart_Ts
,ts.TripStartOffsetTime_Am
,ts.TripEnd_Ts
,ts.TripEndtOffsetTime_Am
,ts.OdometerReadingStart_Qt
,ts.OdometerReadingEnd_Qt
,ts.IdleTime_Am
,ts.loadevent_id
,ts.PartnerNotification_Id
,ts.sourcefile_dt
FROM  ~>staging_db.experian_auto_quote_bind_policy bp
INNER JOIN ~>work_db.experian_trip_summary_purge ts
ON ts.partnernotification_id = bp.partnernotification_id;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.experian_trip_event 
from ~>work_db.experian_trip_event_purge, ~>staging_db.experian_auto_quote_bind_policy ";

DROP TABLE IF EXISTS ~>work_db.experian_trip_event_purge;

CREATE EXTERNAL TABLE ~>work_db.experian_trip_event_purge(
  event_ts timestamp, 
  eventoffsettime_am double, 
  vehiclespeed_am double, 
  hardbrakesacceleration_am double, 
  loadevent_id double, 
  partnernotification_id string)
PARTITIONED BY ( 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>work_db/experian_trip_event_purge';

MSCK REPAIR TABLE ~>work_db.experian_trip_event_purge;

INSERT OVERWRITE TABLE  ~>foundation_db.experian_trip_event
PARTITION (sourcefile_dt)
SELECT
 te.Event_Ts
,te.EventOffsetTime_Am
,te.VehicleSpeed_Am
,te.HardBrakesAcceleration_Am
,te.loadevent_id
,te.PartnerNotification_Id
,te.sourcefile_dt
FROM ~>staging_db.experian_auto_quote_bind_policy bp
INNER JOIN ~>work_db.experian_trip_event_purge te
ON te.partnernotification_id = bp.partnernotification_id;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.experian_vehicle_partition 
from ~>work_db.experian_vehicle_partition_purge, ~>staging_db.experian_auto_quote_bind_policy";

DROP TABLE IF EXISTS ~>work_db.experian_vehicle_partition_purge;

CREATE EXTERNAL TABLE ~>work_db.experian_vehicle_partition_purge(
  partnernotification_id string, 
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb smallint, 
  programstart_ts timestamp, 
  programstartoffsettime_am double, 
  programend_ts timestamp, 
  programendoffsettime_am double, 
  totaltraveltime_am bigint, 
  totaltraveldistance_qt double, 
  totalidletime_am bigint, 
  totalidletime_pc double, 
  tripstart_ts timestamp, 
  tripstartoffsettime_am double, 
  tripend_ts timestamp, 
  tripendtoffsettime_am double, 
  odometerreadingstart_qt double, 
  odometerreadingend_qt double, 
  idletime_am int, 
  hardbrakes_ct int, 
  fastacceleration_ct int, 
  satsunpartition1time_am bigint, 
  satsunpartition2time_am bigint, 
  satsunpartition3time_am bigint, 
  monfripartition4time_am bigint, 
  monfripartition5time_am bigint, 
  monfripartition6time_am bigint, 
  monfripartition7time_am bigint, 
  monfripartition8time_am bigint, 
  satsunpartition1_pc double, 
  satsunpartition2_pc double, 
  satsunpartition3_pc double, 
  monfripartition4_pc double, 
  monfripartition5_pc double, 
  monfripartition6_pc double, 
  monfripartition7_pc double, 
  monfripartition8_pc double, 
  satsunpartition1adjdistance_qt double, 
  satsunpartition2adjdistance_qt double, 
  satsunpartition3adjdistance_qt double, 
  satsunpartition4adjdistance_qt double, 
  satsunpartition5adjdistance_qt double, 
  satsunpartition6adjdistance_qt double, 
  satsunpartition7adjdistance_qt double, 
  satsunpartition8adjdistance_qt double, 
  loadevent_id double)
PARTITIONED BY ( 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>work_db/experian_vehicle_partition_purge';

MSCK REPAIR TABLE ~>work_db.experian_vehicle_partition_purge;

INSERT OVERWRITE TABLE  ~>provide_db.experian_vehicle_partition
PARTITION (sourcefile_dt)
SELECT
 vp.partnernotification_id
,vp.vin10_nb
,vp.state_cd
,vp.make_ds
,vp.model_ds
,vp.manufactureyear_nb
,vp.programstart_ts
,vp.programstartoffsettime_am
,vp.programend_ts
,vp.programendoffsettime_am
,vp.totaltraveltime_am
,vp.totaltraveldistance_qt
,vp.totalidletime_am
,vp.totalidletime_pc
,vp.tripstart_ts
,vp.tripstartoffsettime_am
,vp.tripend_ts
,vp.tripendtoffsettime_am
,vp.odometerreadingstart_qt
,vp.odometerreadingend_qt
,vp.idletime_am
,vp.hardbrakes_ct
,vp.fastacceleration_ct
,vp.satsunpartition1time_am
,vp.satsunpartition2time_am
,vp.satsunpartition3time_am
,vp.monfripartition4time_am
,vp.monfripartition5time_am
,vp.monfripartition6time_am
,vp.monfripartition7time_am
,vp.monfripartition8time_am
,vp.satsunpartition1_pc
,vp.satsunpartition2_pc
,vp.satsunpartition3_pc
,vp.monfripartition4_pc
,vp.monfripartition5_pc
,vp.monfripartition6_pc
,vp.monfripartition7_pc
,vp.monfripartition8_pc
,vp.satsunpartition1adjdistance_qt
,vp.satsunpartition2adjdistance_qt
,vp.satsunpartition3adjdistance_qt
,vp.satsunpartition4adjdistance_qt
,vp.satsunpartition5adjdistance_qt
,vp.satsunpartition6adjdistance_qt
,vp.satsunpartition7adjdistance_qt
,vp.satsunpartition8adjdistance_qt
,vp.loadevent_id
,vp.sourcefile_dt
FROM ~>staging_db.experian_auto_quote_bind_policy bp
INNER JOIN ~>work_db.experian_vehicle_partition_purge vp
ON vp.partnernotification_id = bp.partnernotification_id;

set mapred.job.name = "~>job_cd Insert Overwrite ~>provide_db.experian_telematics_score
 from ~>work_db.experian_telematics_score_purge, ~>staging_db.experian_auto_quote_bind_policy";

DROP TABLE IF EXISTS ~>work_db.experian_telematics_score_purge;

CREATE EXTERNAL TABLE ~>work_db.experian_telematics_score_purge(
  partnernotification_id string, 
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb smallint, 
  installedday_ct smallint, 
  totalhardbrakes_ct int, 
  dailyhardbrakes_ct double, 
  totalfastacceleration_ct int, 
  dailyfastacceleration_ct double, 
  totalidletime_am int, 
  totaltraveltime_am int, 
  idletime_pc double, 
  totaltraveldistance_qt double, 
  adjusteddistance_qt double, 
  averagedailydistance_qt double, 
  mileage_fr double, 
  telematicsscore1_qt int, 
  telematicsscore2_qt int, 
  telematicsscore3_qt int, 
  telematicsscore4_qt int, 
  telematicsscore5_qt int, 
  telematicsscore6_qt int, 
  telematicsscore7_qt int, 
  telematicsscore8_qt int, 
  qualify_cd string, 
  loadevent_id double)
PARTITIONED BY ( 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>work_db/experian_telematics_score_purge';

INSERT OVERWRITE TABLE  ~>provide_db.experian_telematics_score
PARTITION (sourcefile_dt)
select
 case when bp.partnernotification_id is null then ' ' else t.partnernotification_id end as partnernotification_id
,case when bp.partnernotification_id is null then ' ' else t.vin10_nb end as vin10_nb
,t.state_cd
,t.make_ds
,t.model_ds
,t.manufactureyear_nb
,t.installedday_ct
,t.totalhardbrakes_ct
,t.dailyhardbrakes_ct
,t.totalfastacceleration_ct
,t.dailyfastacceleration_ct
,t.totalidletime_am
,t.totaltraveltime_am
,t.idletime_pc
,t.totaltraveldistance_qt
,t.adjusteddistance_qt
,t.averagedailydistance_qt
,t.mileage_fr
,t.telematicsscore1_qt
,t.telematicsscore2_qt
,t.telematicsscore3_qt
,t.telematicsscore4_qt
,t.telematicsscore5_qt
,t.telematicsscore6_qt
,t.telematicsscore7_qt
,t.telematicsscore8_qt
,t.qualify_cd
,t.loadevent_id
,t.sourcefile_dt
from ~>staging_db.experian_auto_quote_bind_policy bp
inner join ~>work_db.experian_telematics_score_purge t
on t.partnernotification_id = bp.partnernotification_id;

set mapred.job.name = "~>job_cd Insert Overwrite ~>provide_db.experian_nwi_bd_aqb_rated
 from ~>work_db.experian_nwi_bd_aqb_rated_purge, ~>staging_db.experian_auto_quote_bind_policy";

DROP TABLE IF EXISTS ~>work_db.experian_nwi_bd_aqb_rated_purge;

CREATE EXTERNAL TABLE ~>work_db.experian_nwi_bd_aqb_rated_purge(
  partnernotification_id string, 
  vin10_nb string, 
  manufactureyear_nb string, 
  make_ds string, 
  model_ds string, 
  score string)
PARTITIONED BY ( 
  sourcefile_dt string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ',' 
STORED AS TEXTFILE
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>work_db/experian_nwi_bd_aqb_rated_purge';

MSCK REPAIR TABLE ~>work_db.experian_nwi_bd_aqb_rated_purge;

INSERT OVERWRITE TABLE  ~>provide_db.experian_nwi_bd_aqb_rated
PARTITION (sourcefile_dt)
SELECT 
  r.partnernotification_id,
  vin10_nb,
  manufactureyear_nb,
  make_ds,
  model_ds,
  score,
  r.sourcefile_dt
FROM ~>staging_db.experian_auto_quote_bind_policy bp
INNER JOIN ~>work_db.experian_nwi_bd_aqb_rated_purge r
ON r.partnernotification_id = bp.partnernotification_id;

set mapred.job.name = "~>job_cd Insert Overwrite ~>staging_db.experian_driving
 from ~>work_db.experian_driving_purge, ~>staging_db.experian_auto_quote_bind_policy";

DROP TABLE IF EXISTS ~>work_db.experian_driving_purge;

CREATE EXTERNAL TABLE ~>work_db.experian_driving_purge(
  col1 string, 
  col2 string, 
  col3 string, 
  col4 string, 
  col5 string, 
  col6 string, 
  col7 string, 
  col8 string, 
  col9 string, 
  partnernotification_id string)
PARTITIONED BY ( 
  loadevent string, 
  sourcefile_dt string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ',' 
STORED AS TEXTFILE
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>work_db/experian_driving_purge';

MSCK REPAIR TABLE ~>work_db.experian_driving_purge;

INSERT OVERWRITE TABLE ~>staging_db.experian_driving
PARTITION (loadevent, sourcefile_dt )
SELECT 
 col1,
 col2,
 col3,
 col4,
 col5,
 col6,
 col7,
 col8,
 col9,
 d.partnernotification_id,
 loadevent,
 d.sourcefile_dt
FROM ~>staging_db.experian_auto_quote_bind_policy bp
INNER JOIN ~>work_db.experian_driving_purge d
ON d.partnernotification_id = bp.partnernotification_id;
