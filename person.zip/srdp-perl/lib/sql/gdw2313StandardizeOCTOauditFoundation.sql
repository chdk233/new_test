-- Step 1-- Standardize OCTO Audit Foundation Alter Ext Table

ALTER TABLE ~>staging_db.OCTO_TripCumulative_Ext ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.OCTO_TripCumulative_Ext PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.OCTO_TripSummary_Ext ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.OCTO_TripSummary_Ext PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.OCTO_TripPoint_Ext ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.OCTO_TripPoint_Ext PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.OCTO_TripEvent_Ext ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.OCTO_TripEvent_Ext PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

-- Step 2-- Standardize OCTO Audit Foundation Dup Ctrl Table Load

DROP TABLE IF EXISTS ~>work_db.wk_octo_trippoint_ext_dups;

set mapred.job.name = "~>job_cd Create Table ~>work_db.wk_octo_trippoint_ext_dups from ~>staging_db.octo_trippoint_ext";

CREATE TABLE ~>work_db.wk_octo_trippoint_ext_dups(
  trip_nb string, 
  position_ts timestamp)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_octo_trippoint_ext_dups';

INSERT OVERWRITE TABLE ~>work_db.wk_octo_trippoint_ext_dups	
SELECT
TRIP_NB,
Position_Ts
FROM ~>staging_db.octo_trippoint_ext
WHERE loadevent in (~>load_event_id_list)
GROUP BY TRIP_NB,Position_Ts HAVING COUNT(*) > 1
;

DROP TABLE IF EXISTS ~>work_db.wk_octo_tripevent_ext_dups;

set mapred.job.name = "~>job_cd Create Table ~>work_db.wk_octo_tripevent_ext_dups from ~>staging_db.octo_tripevent_ext";

CREATE TABLE ~>work_db.wk_octo_tripevent_ext_dups  (
    trip_nb   string,
    event_ts   timestamp,
    eventtype_cd   string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_octo_tripevent_ext_dups';
  
INSERT OVERWRITE TABLE ~>work_db.wk_octo_tripevent_ext_dups
SELECT
TRIP_NB,
Event_Ts,
EventType_Cd
FROM ~>staging_db.octo_tripevent_ext
WHERE loadevent  in (~>load_event_id_list)
GROUP BY TRIP_NB,Event_Ts,EventType_Cd HAVING COUNT(*) > 1;

DROP TABLE IF EXISTS ~>work_db.wk_octo_tripsummary_ext_dups;

set mapred.job.name = "~>job_cd Create Table ~>work_db.wk_octo_tripsummary_ext_dups from ~>staging_db.octo_tripsummary_ext";

CREATE TABLE ~>work_db.wk_octo_tripsummary_ext_dups
( trip_nb   string)
STORED AS PARQUET
LOCATION  
'hdfs:///user/hive/warehouse/~>work_db/wk_octo_tripsummary_ext_dups'  ;

INSERT OVERWRITE TABLE ~>work_db.wk_octo_tripsummary_ext_dups
SELECT Trip_Nb
FROM ~>staging_db.octo_tripsummary_ext
WHERE loadevent in (~>load_event_id_list)
GROUP BY Trip_Nb HAVING COUNT(*) > 1;

DROP TABLE IF EXISTS ~>work_db.WK_OCTO_Dup_Ctrl;

SET hive.exec.parallel=true;

set mapred.job.name = "~>job_cd Create Table ~>work_db.WK_OCTO_Dup_Ctrl_Temp from wk_octo_tripsummary_ext_dups, wk_octo_tripevent_ext_dups, wk_octo_trippoint_ext_dups";

CREATE TABLE ~>work_db.WK_OCTO_Dup_Ctrl(
    trip_nb   string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\054'
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_octo_dup_ctrl';

INSERT OVERWRITE TABLE TABLE ~>work_db.WK_OCTO_Dup_Ctrl
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\054' 
SELECT DISTINCT TRIP_NB
FROM

CREATE TABLE ~>work_db.WK_OCTO_Dup_Ctrl(
    trip_nb   string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\054'
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_octo_dup_ctrl';

INSERT OVERWRITE TABLE TABLE ~>work_db.WK_OCTO_Dup_Ctrl
SELECT DISTINCT TRIP_NB
FROM
(
SELECT DISTINCT Trip_Nb from ~>work_db.wk_octo_tripsummary_ext_dups
UNION ALL
SELECT DISTINCT Trip_Nb from ~>work_db.wk_octo_tripevent_ext_dups
UNION ALL
SELECT DISTINCT Trip_Nb from ~>work_db.wk_octo_trippoint_ext_dups
) DIST_TRIPS;


DROP TABLE IF EXISTS ~>work_db.WK_OCTO_Missing_Trip_Ctrl;

set mapred.job.name = "~>job_cd Create Table ~>work_db.WK_OCTO_Missing_Trip_Ctrl_Temp from ~>staging_db.octo_trippoint_ext & octo_tripsummary_ext";

CREATE TABLE ~>work_db.WK_OCTO_Missing_Trip_Ctrl(
    trip_nb   string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\054'
STORED AS PARQUET 
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_octo_missing_trip_ctrl'; 

INSERT OVERWRITE TABLE TABLE ~>work_db.WK_OCTO_Missing_Trip_Ctrl
SELECT ts.Trip_Nb
FROM ~>staging_db.octo_trippoint_ext tp inner join
~>staging_db.octo_tripsummary_ext ts
on tp.trip_nb = ts.trip_nb
and ts.loadevent = tp.loadevent
WHERE ts.loadevent in (~>load_event_id_list)
GROUP BY ts.trip_nb
;