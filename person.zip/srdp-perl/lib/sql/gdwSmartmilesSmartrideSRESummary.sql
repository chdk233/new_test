SET mapred.job.name = "~>job_cd Insert  into ~>work_db.wk_hbase_event";

DROP TABLE IF EXISTS ~>work_db.wk_hbase_event;

CREATE  TABLE ~>work_db.wk_hbase_event(
  program string, 
  strt_ts timestamp, 
  max_strt_ts timestamp,batch bigint
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS ORC
LOCATION
      'hdfs:///user/hive/warehouse/~>work_db/wk_hbase_event'; 

insert into ~>work_db.wk_hbase_event select program,start_ts,max_strt_ts,batch from 
( select 'SM-SR' program,
CURRENT_TIMESTAMP() start_ts,coalesce(max(strt_ts),CURRENT_TIMESTAMP() - interval 1 month) as max_strt_ts,'1' dummy
from ~>staging_db.program_summary_dsd_hbase_event)a join (select COALESCE (max(batch),0) batch ,'1' dummy
from ~>staging_db.program_summary_dsd_intmd) b on a.dummy=b.dummy;


SET mapred.job.name = "~>job_cd Insert smartmiles data into ~>foundation_db.smartride_Sre_Summary_Ext from ~>staging_db.program_summary_dsd_intmd";

SET hbase.zookeeper.quorum=~>zookeeper_quorum;

INSERT INTO ~>provide_db.smartride_Sre_Summary_Ext
SELECT  
concat(ENRLD_VIN_NB, '_',PE_CD,'_',unix_timestamp(PE_STRT_TS) + (case
when PE_STRT_TS between date_format( cast(extract(year from PE_STRT_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_STRT_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600)  AS key,
unix_timestamp(PE_END_TS) + (case
when PE_END_TS between date_format( cast(extract(year from PE_END_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_END_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600,
TRIP_CT,
MILE_CT,
NIGHT_TIME_DRVNG_SC_CT,
FAST_ACLRTN_CT,
HARD_BRKE_CT,
IDLE_SC_CT,
DRVNG_SC_CT,
IDLE_TIME_RATIO,
regexp_replace(TRIP_RPRT_JSON_TT,',','\;')
FROM ~>staging_db.program_summary_dsd_intmd a
inner join ~>work_db.wk_hbase_event b on a.LOAD_HR_TS >=b.max_strt_ts and a.LOAD_HR_TS <b.strt_ts
where src_sys_cd like '%SM%' and ENRLD_VIN_NB is not null;

SET mapred.job.name = "~>job_cd Insert  Smartride data into ~>foundation_db.smartride_Sre_Summary_Ext from ~>staging_db.program_summary_dsd_intmd";

SET hbase.zookeeper.quorum=~>zookeeper_quorum;

INSERT INTO ~>provide_db.smartride_Sre_Summary_Ext
Select  
concat(concat(substr('00',1,2-length(cast(pmod(PRGRM_INSTC_ID,~>splits)as varchar(2)))),cast(pmod(PRGRM_INSTC_ID,16)as varchar(2))), '_', PRGRM_INSTC_ID,'_',PE_CD,'_',unix_timestamp(PE_STRT_TS) + (case
when PE_STRT_TS between date_format( cast(extract(year from PE_STRT_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_STRT_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600 ) as key,
unix_timestamp(PE_END_TS) + (case
when PE_END_TS between date_format( cast(extract(year from PE_END_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_END_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600 as pets,
TRIP_CT,
MILE_CT as mls,
NIGHT_TIME_DRVNG_SC_CT as ntd,
FAST_ACLRTN_CT as fac,HARD_BRKE_CT as hbc,
IDLE_SC_CT as it,
DRVNG_SC_CT as dt,
IDLE_TIME_RATIO as itr,
regexp_replace(TRIP_RPRT_JSON_TT,',','\;') as tsj 
FROM ~>staging_db.program_summary_dsd_intmd a
inner join ~>work_db.wk_hbase_event b on a.LOAD_HR_TS >=b.max_strt_ts and a.LOAD_HR_TS <b.strt_ts
where (src_sys_cd like '%_SR%') and PRGRM_INSTC_ID is not null;


INSERT OVERWRITE TABLE telematics_provide_db.smartride_hive_sre_summary partition(SOURCE_CD) 
SELECT prgrm_instc_id as SR_PGM_INSTNC_ID
,pe_cd as PERIOD_TYPE
,pe_strt_ts as PERIODSTART_TS
,pe_end_ts as PERIODEND_TS
,trip_ct as TRIP_CN
,mile_ct as MILES
,km_ct as KILOMETERS
,night_time_drvng_sc_ct as NIGHT_TIME_DRIVING_sec_ct
,fast_aclrtn_ct as FAST_ACCELERATION_CT
,hard_brke_ct as HARD_BRAKE_CT
,idle_sc_ct as IDLE_TIME_sec_ct
,drvng_sc_ct as DRIVE_TIME_sec_ct
,idle_time_ratio as IDLE_TIME_RATIO
,trip_rprt_json_tt as trip_seconds_json
,src_sys_cd as SOURCE_CD
FROM ~>staging_db.program_summary_dsd_intmd a
inner join ~>work_db.wk_hbase_event b on a.batch=b.batch
where src_sys_cd like '%SR%' and pe_cd in ('w', 'd','tp');

insert into ~>staging_db.program_summary_dsd_hbase_event partition(load_mth) 
select program,strt_ts,current_timestamp(),extract(month from current_timestamp()) from ~>work_db.wk_hbase_event;
