ALTER TABLE ~>staging_db.smartride_octo_cumulative ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_octo_cumulative PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.smartride_octo_tripsummary ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_octo_tripsummary PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.smartride_octo_trippoint ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_octo_trippoint PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.smartride_octo_tripevent ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_octo_tripevent PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;