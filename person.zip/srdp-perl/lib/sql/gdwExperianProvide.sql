set mapred.job.name = "~>job_cd Drop and recreate tripsummary_tripevent from expn_trip_summary,expn_trip_event";

drop table if exists ~>work_db.tripsummary_tripevent;

CREATE TABLE ~>work_db.tripsummary_tripevent(
  partnernotification_id string, 
  sourcefile_dt string, 
  tripstart_ts timestamp, 
  tripend_ts timestamp, 
  triphardbrakes_ct bigint, 
  tripfastacceleration_ct bigint)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/tripsummary_tripevent';

set hive.tez.auto.reducer.parallelism=true;

set hive.tez.min.partition.factor=0.25;

set hive.tez.max.partition.factor=2.0;

set hive.exec.reducers.bytes.per.reducer=2500000;

insert into ~>work_db.tripsummary_tripevent
select
 ts.partnernotification_id
,ts.sourcefile_dt
,ts.tripstart_ts
,ts.tripend_ts
,sum(case when te.HardBrakesAcceleration_Am < -3.61111 then 1 else 0 end) as TripHardBrakes_Ct
,sum(case when te.HardBrakesAcceleration_Am >  3.61111 then 1 else 0 end) as TripFastAcceleration_Ct
from
~>work_db.expn_trip_summary TS
INNER JOIN ~>work_db.expn_trip_event TE
ON TS.partnernotification_id = TE.partnernotification_id
where
(case when te.eventOffsetTime_Am > 0
     then from_unixtime(cast ((unix_timestamp(te.event_ts)-((floor(abs(te.eventOffsetTime_Am))*60*60) + ((abs(te.eventOffsetTime_Am) - floor(abs(te.eventOffsetTime_Am)))*100)*60)) as int))
     else from_unixtime(cast ((unix_timestamp(te.event_ts)+((floor(abs(te.eventOffsetTime_Am))*60*60) + ((abs(te.eventOffsetTime_Am) - floor(abs(te.eventOffsetTime_Am)))*100)*60)) as int))
end)
>= (case when ts.TripStartOffsetTime_Am > 0
        then from_unixtime(cast ((unix_timestamp(ts.tripstart_ts)-((floor(abs(ts.TripStartOffsetTime_Am))*60*60) + ((abs(ts.TripStartOffsetTime_Am) - floor(abs(ts.TripStartOffsetTime_Am)))*100)*60)) as int))
        else from_unixtime(cast ((unix_timestamp(ts.tripstart_ts)+((floor(abs(ts.TripStartOffsetTime_Am))*60*60) + ((abs(ts.TripStartOffsetTime_Am) - floor(abs(ts.TripStartOffsetTime_Am)))*100)*60)) as int))
    end)
AND
(case when te.eventOffsetTime_Am > 0
     then from_unixtime(cast ((unix_timestamp(te.event_ts)-((floor(abs(te.eventOffsetTime_Am))*60*60) + ((abs(te.eventOffsetTime_Am) - floor(abs(te.eventOffsetTime_Am)))*100)*60)) as int))
     else from_unixtime(cast ((unix_timestamp(te.event_ts)+((floor(abs(te.eventOffsetTime_Am))*60*60) + ((abs(te.eventOffsetTime_Am) - floor(abs(te.eventOffsetTime_Am)))*100)*60)) as int))
end)
<= (case when ts.tripendtoffsettime_am > 0
        then from_unixtime(cast ((unix_timestamp(ts.tripEnd_ts)-((floor(abs(ts.tripendtoffsettime_am))*60*60) + ((abs(ts.tripendtoffsettime_am) - floor(abs(ts.tripendtoffsettime_am)))*100)*60)) as int))
        else from_unixtime(cast ((unix_timestamp(ts.tripEnd_ts)+((floor(abs(ts.tripendtoffsettime_am))*60*60) + ((abs(ts.tripendtoffsettime_am) - floor(abs(ts.tripendtoffsettime_am)))*100)*60)) as int))
    end)
 group by  ts.tripstart_ts,ts.tripend_ts,ts.partnernotification_id,ts.sourcefile_dt;

reset;

set mapred.job.name = "~>job_cd Drop and recreate tripsummary_partition from expn_trip_summary";

drop table if exists ~>work_db.tripsummary_partition;

CREATE TABLE ~>work_db.tripsummary_partition(
  tripstart_ts timestamp, 
  tripstartoffsettime_am double, 
  tripend_ts timestamp, 
  tripendtoffsettime_am double, 
  odometerreadingstart_qt double, 
  odometerreadingend_qt double, 
  idletime_am int, 
  sourcefile_dt string, 
  partnernotification_id string, 
  satsunpartition1time_am bigint, 
  satsunpartition2time_am bigint, 
  satsunpartition3time_am bigint, 
  monfripartition4time_am bigint, 
  monfripartition5time_am bigint, 
  monfripartition6time_am bigint, 
  monfripartition7time_am bigint, 
  monfripartition8time_am bigint)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/tripsummary_partition';

set hive.strict.checks.cartesian.product=false;
set hive.mapred.mode='nonstrict';

insert into ~>work_db.tripsummary_partition
Select
 tripstart_ts
,min(tripstartoffsettime_am) as tripstartoffsettime_am
,tripend_ts
,min(tripendtoffsettime_am) as tripendtoffsettime_am
,min(odometerreadingstart_qt) as odometerreadingstart_qt
,min(odometerreadingend_qt) as odometerreadingend_qt
,min(idletime_am) as idletime_am
,min(sourcefile_dt) as sourcefile_dt
,partnernotification_id
,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) = 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 00:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 04:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 04:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 04:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as SatSunPartition1Time_Am
,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) = 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 18:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 18:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 18:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               when date_start_ts < cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp) and date_end_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 18:59:59') as timestamp)
                         then cast((unix_timestamp(date_end_ts) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp))+1) as bigint)
                         else cast((unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 18:59:59') as timestamp)) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp))+1) as bigint)
                         end
              else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as SatSunPartition2Time_Am
,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) = 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 23:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 23:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 23:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               when date_start_ts < cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp) and date_end_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 23:59:59') as timestamp)
                         then cast((unix_timestamp(date_end_ts) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp))+1) as bigint)
                         else cast((unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 23:59:59') as timestamp)) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp))+1) as bigint)
                         end
              else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as SatSunPartition3Time_Am

,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) != 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 00:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 04:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 04:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 04:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as MonFriPartition4Time_Am

,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) != 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 08:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 08:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 08:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               when date_start_ts < cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp) and date_end_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 08:59:59') as timestamp)
                         then cast((unix_timestamp(date_end_ts) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp))+1) as bigint)
                         else cast((unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 08:59:59') as timestamp)) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 05:00:00') as timestamp))+1) as bigint)
                         end
              else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as MonFriPartition5Time_Am

 ,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) != 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 09:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 15:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 15:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 15:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               when date_start_ts < cast(concat(cast(date_start_ts as varchar(10)),' 09:00:00') as timestamp) and date_end_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 09:00:00') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 15:59:59') as timestamp)
                         then cast((unix_timestamp(date_end_ts) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 09:00:00') as timestamp))+1) as bigint)
                         else cast((unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 15:59:59') as timestamp)) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 09:00:00') as timestamp))+1) as bigint)
                         end
              else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as MonFriPartition6Time_Am

 ,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) != 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 16:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 18:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 18:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 18:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               when date_start_ts < cast(concat(cast(date_start_ts as varchar(10)),' 16:00:00') as timestamp) and date_end_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 16:00:00') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 18:59:59') as timestamp)
                         then cast((unix_timestamp(date_end_ts) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 16:00:00') as timestamp))+1) as bigint)
                         else cast((unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 18:59:59') as timestamp)) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 16:00:00') as timestamp))+1) as bigint)
                         end
              else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as MonFriPartition7Time_Am

  ,sum(case
     when (substr(from_unixtime(unix_timestamp(date_start_ts),'EEEE'),1,1) != 'S') and partnernotification_id is not null
          then case
               when date_start_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp) and date_start_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 23:59:59') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_end_ts as varchar(10)),' 23:59:59') as timestamp)
                           then cast ( (unix_timestamp(date_end_ts) - unix_timestamp(date_start_ts)+1) as bigint)
                         else cast ( (unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 23:59:59') as timestamp)) - unix_timestamp(date_start_ts)+1) as bigint)
                         end
               when date_start_ts < cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp) and date_end_ts >= cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp)
                    then case
                         when date_end_ts <= cast(concat(cast(date_start_ts as varchar(10)),' 23:59:59') as timestamp)
                         then cast((unix_timestamp(date_end_ts) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp))+1) as bigint)
                         else cast((unix_timestamp(cast(concat(cast(date_end_ts as varchar(10)),' 23:59:59') as timestamp)) - unix_timestamp(cast(concat(cast(date_start_ts as varchar(10)),' 19:00:00') as timestamp))+1) as bigint)
                         end
              else cast(0 as bigint)
              end
     else cast(0 as bigint)
     end) as MonFriPartition8Time_Am

  from
(select day_no, tripstart_ts,tripstartoffsettime_am,tripend_ts,tripendtoffsettime_am,odometerreadingstart_qt,odometerreadingend_qt,idletime_am,sourcefile_dt,partnernotification_id , temp_date, case when temp_date = cast(tripstart_ts as varchar(10)) then cast(tripstart_ts as timestamp) else cast(cast(concat(temp_date ,' 00:00:00') as timestamp) as timestamp) end as date_start_ts,
  case when temp_date = cast(cast(tripend_ts as varchar(10)) as date) then cast(tripend_ts as timestamp) else cast(concat(temp_date ,' 23:59:59') as timestamp) end as date_end_ts
from
(Select temp.day_no, from_unixtime((unix_timestamp(cast(cast(sumry.tripstart_ts as varchar(10))as date))+temp.day_no*86400)) as temp_date2,
cast(date_add(cast(cast(sumry.tripstart_ts as varchar(10))as date),day_no) as varchar(10)) as temp_date
,tripstart_ts,tripstartoffsettime_am,tripend_ts,tripendtoffsettime_am,odometerreadingstart_qt,odometerreadingend_qt,idletime_am,sourcefile_dt,partnernotification_id
from
(select   tripstart_ts,tripstartoffsettime_am,tripend_ts,tripendtoffsettime_am,odometerreadingstart_qt,odometerreadingend_qt,idletime_am,sourcefile_dt,partnernotification_id
          ,ceil((unix_timestamp(cast(concat(cast(tripend_ts as varchar(10)) ,' 00:00:00') as timestamp)) - unix_timestamp(cast(concat(cast(tripstart_ts as varchar(10)) ,' 00:00:00') as timestamp)))/86400) as days from  ~>work_db.expn_trip_summary ts
          ) sumry
inner join
(Select 0 as day_no union all
Select 1 as day_no union all
Select 2 as day_no union all
Select 3 as day_no union all
Select 4 as day_no
) temp
 where
days >= day_no and day_no <= days) sumry2
) ts
group by PartnerNotification_Id,tripstart_ts,tripend_ts;

reset;

set hive.exec.dynamic.partition.mode=nonstrict;

set mapred.job.name = "~>job_cd Drop and recreate vehicle_partition_1 from expn_vehicle, tripsummary_partition, tripsummary_tripevent";

drop table if exists ~>work_db.vehicle_partition_1;

CREATE TABLE ~>work_db.vehicle_partition_1(
  partnernotification_id string, 
  sourcefile_dt string, 
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb string, 
  programstart_ts timestamp, 
  programstartoffsettime_am double, 
  programend_ts timestamp, 
  programendoffsettime_am double, 
  tripstart_ts timestamp, 
  tripstartoffsettime_am double, 
  tripend_ts timestamp, 
  tripendtoffsettime_am double, 
  odometerreadingstart_qt double, 
  odometerreadingend_qt double, 
  idletime_am int, 
  totaltraveltime_am bigint, 
  totalidletime_am bigint, 
  totaltraveldistance_qt double, 
  triphardbrakes_ct bigint, 
  tripfastacceleration_ct bigint, 
  totaltripdistance_qt double, 
  satsunpartition1time_am bigint, 
  satsunpartition2time_am bigint, 
  satsunpartition3time_am bigint, 
  monfripartition4time_am bigint, 
  monfripartition5time_am bigint, 
  monfripartition6time_am bigint, 
  monfripartition7time_am bigint, 
  monfripartition8time_am bigint, 
  loadevent_id double)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/vehicle_partition_1';

insert into table ~>work_db.vehicle_partition_1 
select
 v.partnernotification_id AS PartnerNotification_Id
,v.sourcefile_dt AS SourceFile_Dt
,v.vin10_nb AS VIN10_Nb
,v.state_cd AS State_Cd
,v.make_ds AS Make_Ds
,v.model_ds AS Model_Ds
,v.manufactureyear_nb AS ManufactureYear_Nb
,v.programstart_ts AS ProgramStart_Ts
,v.programstartoffsettime_am AS ProgramStartOffsetTime_Am
,v.programend_ts AS ProgramEnd_Ts
,v.programendoffsettime_am AS ProgramEndOffsetTime_Am
,ts.tripstart_ts
,ts.tripstartoffsettime_am
,ts.tripend_ts
,ts.tripendtoffsettime_am
,ts.odometerreadingstart_qt as odometerreadingstart_qt
,ts.odometerreadingend_qt as odometerreadingend_qt
,ts.IdleTime_Am as idletime_am
,sum(unix_timestamp(ts.tripEnd_ts) - unix_timestamp(ts.tripstart_ts) + 1) over (partition by v.partnernotification_id) as totaltraveltime_am
,sum(ts.IdleTime_Am ) over (partition by v.partnernotification_id) as totalidletime_am
,sum(ts.OdometerReadingEnd_Qt - ts.OdometerReadingStart_Qt)  over (partition by v.partnernotification_id) totaltraveldistance_qt
,case when tse.partnernotification_id is not null then cast(tse.TripHardBrakes_Ct as bigint) else  cast ( 0 as bigint) end as TripHardBrakes_Ct
,case when tse.partnernotification_id is not null then cast(tse.TripFastAcceleration_Ct as bigint) else  cast ( 0 as bigint) end as TripFastAcceleration_Ct
,ts.OdometerReadingEnd_Qt - ts.OdometerReadingStart_Qt  as TotalTripDistance_Qt
,SatSunPartition1Time_Am
,SatSunPartition2Time_Am
,SatSunPartition3Time_Am
,MonFriPartition4Time_Am
,MonFriPartition5Time_Am
,MonFriPartition6Time_Am
,MonFriPartition7Time_Am
,MonFriPartition8Time_Am
,v.loadevent_id
from ~>work_db.expn_vehicle v
inner Join
~>work_db.tripsummary_partition ts ON
V.partnernotification_id = TS.partnernotification_id
left outer join
~>work_db.tripsummary_tripevent tse ON
V.partnernotification_id = tse.partnernotification_id
and ts.tripstart_ts = tse.tripstart_ts
and ts.tripend_ts = tse.tripend_ts
where v.state_cd <> 'CA' ;


set mapred.job.name = "~>job_cd Drop and recreate vehicle_partition_2 from vehicle_partition_1";


drop table if exists ~>work_db.vehicle_partition_2;

CREATE TABLE ~>work_db.vehicle_partition_2(
  partnernotification_id string, 
  sourcefile_dt string, 
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb string, 
  programstart_ts timestamp, 
  programstartoffsettime_am double, 
  programend_ts timestamp, 
  programendoffsettime_am double, 
  tripstart_ts timestamp, 
  tripstartoffsettime_am double, 
  tripend_ts timestamp, 
  tripendtoffsettime_am double, 
  odometerreadingstart_qt double, 
  odometerreadingend_qt double, 
  idletime_am int, 
  totaltraveltime_am bigint, 
  totalidletime_am bigint, 
  totalidletime_pc double, 
  totaltraveldistance_qt double, 
  triphardbrakes_ct bigint, 
  tripfastacceleration_ct bigint, 
  totaltripdistance_qt double, 
  satsunpartition1time_am bigint, 
  satsunpartition2time_am bigint, 
  satsunpartition3time_am bigint, 
  monfripartition4time_am bigint, 
  monfripartition5time_am bigint, 
  monfripartition6time_am bigint, 
  monfripartition7time_am bigint, 
  monfripartition8time_am bigint, 
  satsunpartition1_pc double, 
  satsunpartition2_pc double, 
  satsunpartition3_pc double, 
  monfripartition4_pc double, 
  monfripartition5_pc double, 
  monfripartition6_pc double, 
  monfripartition7_pc double, 
  monfripartition8_pc double, 
  loadevent_id double)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/vehicle_partition_2';

insert into table ~>work_db.vehicle_partition_2
select
 PartnerNotification_Id
,SourceFile_Dt
,VIN10_Nb
,State_Cd
,Make_Ds
,Model_Ds
,ManufactureYear_Nb
,ProgramStart_Ts
,ProgramStartOffsetTime_Am
,ProgramEnd_Ts
,ProgramEndOffsetTime_Am
,tripstart_ts
,tripstartoffsettime_am
,tripend_ts
,tripendtoffsettime_am
,odometerreadingstart_qt
,odometerreadingend_qt
,idletime_am
,totaltraveltime_am
,totalidletime_am
,case when totaltraveltime_am !=0 then cast(totalidletime_am/totaltraveltime_am as double) else  cast (0.0 as double) end as totalidletime_pc
,totaltraveldistance_qt
,TripHardBrakes_Ct
,TripFastAcceleration_Ct
,TotalTripDistance_Qt
,satsunpartition1time_am
,satsunpartition2time_am
,satsunpartition3time_am
,monfripartition4time_am
,monfripartition5time_am
,monfripartition6time_am
,monfripartition7time_am
,monfripartition8time_am
,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0.0
     then  cast((satsunpartition1time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as SatSunPartition1_Pc

,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0
     then cast((satsunpartition2time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as SatSunPartition2_Pc

,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0
     then cast((satsunpartition3time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as SatSunPartition3_Pc

,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0
     then cast((monfripartition4time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as MonFriPartition4_Pc

,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0
     then cast((monfripartition5time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as MonFriPartition5_Pc

,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0
     then cast((monfripartition6time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as MonFriPartition6_Pc

,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0
     then cast((monfripartition7time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as MonFriPartition7_Pc

,case when (satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am) > 0
     then cast((monfripartition8time_am/(satsunpartition1time_am+satsunpartition2time_am+satsunpartition3time_am+monfripartition4time_am+monfripartition5time_am+monfripartition6time_am+monfripartition7time_am+monfripartition8time_am))*100 as double)
     else cast( 0.0 as double) end as MonFriPartition8_Pc
,loadevent_id
from ~>work_db.vehicle_partition_1;


set mapred.job.name = "~>job_cd Drop and recreate vehicle_partition_3 from vehicle_partition_2";

drop table if exists ~>work_db.vehicle_partition_3;

CREATE TABLE ~>work_db.vehicle_partition_3(
  partnernotification_id string, 
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb int, 
  programstart_ts timestamp, 
  programstartoffsettime_am double, 
  programend_ts timestamp, 
  programendoffsettime_am double, 
  installedday_ct int, 
  totaltraveltime_am bigint, 
  totaltraveldistance_qt double, 
  totalidletime_am bigint, 
  totalidletime_pc double, 
  tripstart_ts timestamp, 
  tripstartoffsettime_am double, 
  tripend_ts timestamp, 
  tripendtoffsettime_am double, 
  odometerreadingstart_qt double, 
  odometerreadingend_qt double, 
  idletime_am int, 
  triphardbrakes_ct bigint, 
  tripfastacceleration_ct bigint, 
  satsunpartition1time_am bigint, 
  satsunpartition2time_am bigint, 
  satsunpartition3time_am bigint, 
  monfripartition4time_am bigint, 
  monfripartition5time_am bigint, 
  monfripartition6time_am bigint, 
  monfripartition7time_am bigint, 
  monfripartition8time_am bigint, 
  satsunpartition1_pc double, 
  satsunpartition2_pc double, 
  satsunpartition3_pc double, 
  satsunpartition4_pc double, 
  satsunpartition5_pc double, 
  satsunpartition6_pc double, 
  satsunpartition7_pc double, 
  satsunpartition8_pc double, 
  satsunpartition1adjdistance_qt double, 
  satsunpartition2adjdistance_qt double, 
  satsunpartition3adjdistance_qt double, 
  satsunpartition4adjdistance_qt double, 
  satsunpartition5adjdistance_qt double, 
  satsunpartition6adjdistance_qt double, 
  satsunpartition7adjdistance_qt double, 
  satsunpartition8adjdistance_qt double, 
  loadevent_id double, 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/vehicle_partition_3';

insert into table ~>work_db.vehicle_partition_3 
select
 partnernotification_id AS PartnerNotification_Id
,vin10_nb AS VIN10_Nb
,state_cd AS State_Cd
,make_ds AS Make_Ds
,model_ds AS Model_Ds
,cast (manufactureyear_nb as int) AS ManufactureYear_Nb
,programstart_ts AS ProgramStart_Ts
,programstartoffsettime_am AS ProgramStartOffsetTime_Am
,programend_ts AS ProgramEnd_Ts
,programendoffsettime_am AS ProgramEndOffsetTime_Am
,datediff(cast(ProgramEnd_Ts as varchar(10)),cast(ProgramStart_Ts as varchar(10) )) as InstalledDay_Ct
,totaltraveltime_am
,totaltraveldistance_qt
,totalidletime_am
,cast(totalidletime_pc as double) as totalidletime_pc
,tripstart_ts
,tripstartoffsettime_am
,tripend_ts
,tripendtoffsettime_am
,odometerreadingstart_qt
,odometerreadingend_qt
,idletime_am
,TripHardBrakes_Ct
,TripFastAcceleration_Ct
,satsunpartition1time_am
,satsunpartition2time_am
,satsunpartition3time_am
,monfripartition4time_am
,monfripartition5time_am
,monfripartition6time_am
,monfripartition7time_am
,monfripartition8time_am
,cast(satsunpartition1_pc as double) as satsunpartition1_pc
,cast(satsunpartition2_pc as double) as satsunpartition2_pc
,cast(satsunpartition3_pc as double) as satsunpartition3_pc
,cast(monfripartition4_pc as double) as satsunpartition4_pc
,cast(monfripartition5_pc as double) as satsunpartition5_pc
,cast(monfripartition6_pc as double) as satsunpartition6_pc
,cast(monfripartition7_pc as double) as satsunpartition7_pc
,cast(monfripartition8_pc as double) as satsunpartition8_pc
,round(cast(SatSunPartition1_Pc/100 * TotalTripDistance_Qt * 2.7 as double),2) as SatSunPartition1AdjDistance_Qt
,round(cast(SatSunPartition2_Pc/100 * TotalTripDistance_Qt * 1.0 as double),2) as SatSunPartition2AdjDistance_Qt
,round(cast(SatSunPartition3_Pc/100 * TotalTripDistance_Qt * 1.1 as double),2) as SatSunPartition3AdjDistance_Qt
,round(cast(MonFriPartition4_Pc/100 * TotalTripDistance_Qt * 1.6 as double),2) as SatSunPartition4AdjDistance_Qt
,round(cast(MonFriPartition5_Pc/100 * TotalTripDistance_Qt * 1.1 as double),2) as SatSunPartition5AdjDistance_Qt
,round(cast(MonFriPartition6_Pc/100 * TotalTripDistance_Qt * 1.2 as double),2) as SatSunPartition6AdjDistance_Qt
,round(cast(MonFriPartition7_Pc/100 * TotalTripDistance_Qt * 1.4 as double),2) as SatSunPartition7AdjDistance_Qt
,round(cast(MonFriPartition8_Pc/100 * TotalTripDistance_Qt * 1.3 as double),2) as SatSunPartition8AdjDistance_Qt
,loadevent_id
,sourcefile_dt
from
~>work_db.vehicle_partition_2;

set mapred.job.name = "~>job_cd Insert Overwrite ~>provide_db.vehicle_partition from vehicle_partition_3";

INSERT OVERWRITE TABLE  ~>provide_db.experian_vehicle_partition
PARTITION (sourcefile_dt)
Select
 partnernotification_id
,vin10_nb
,state_cd
,make_ds
,model_ds
,manufactureyear_nb
,programstart_ts
,programstartoffsettime_am
,programend_ts
,programendoffsettime_am
,totaltraveltime_am
,totaltraveldistance_qt
,totalidletime_am
,totalidletime_pc
,tripstart_ts
,tripstartoffsettime_am
,tripend_ts
,tripendtoffsettime_am
,odometerreadingstart_qt
,odometerreadingend_qt
,idletime_am
,triphardbrakes_ct
,tripfastacceleration_ct
,satsunpartition1time_am
,satsunpartition2time_am
,satsunpartition3time_am
,monfripartition4time_am
,monfripartition5time_am
,monfripartition6time_am
,monfripartition7time_am
,monfripartition8time_am
,satsunpartition1_pc
,satsunpartition2_pc
,satsunpartition3_pc
,satsunpartition4_pc
,satsunpartition5_pc
,satsunpartition6_pc
,satsunpartition7_pc
,satsunpartition8_pc
,satsunpartition1adjdistance_qt
,satsunpartition2adjdistance_qt
,satsunpartition3adjdistance_qt
,satsunpartition4adjdistance_qt
,satsunpartition5adjdistance_qt
,satsunpartition6adjdistance_qt
,satsunpartition7adjdistance_qt
,satsunpartition8adjdistance_qt
,loadevent_id
,sourcefile_dt
from ~>work_db.vehicle_partition_3;

set mapred.job.name = "~>job_cd Drop and recreate telematics_score_1 from vehicle_partition_3";

drop table if exists ~>work_db.telematics_score_1;

CREATE TABLE ~>work_db.telematics_score_1(
  partnernotification_id string, 
  sourcefile_dt string, 
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb int, 
  totaltriphardbrakes_ct bigint, 
  installedday_ct int, 
  dailyhardbrakes_ct double, 
  totalfastacceleration_ct bigint, 
  dailyfastacceleration_ct double, 
  totalidletime_am bigint, 
  totaltraveltime_am bigint, 
  idletime_pc double, 
  totaltraveldistance_qt double, 
  adjusteddistance_qt double, 
  averagedailydistance_qt double, 
  loadevent_id double)
STORED AS PARQUET
LOCATION
   'hdfs:///user/hive/warehouse/~>work_db/telematics_score_1';

INSERT INTO TABLE ~>work_db.telematics_score_1
select
 partnernotification_id
,min(sourcefile_dt) as sourcefile_dt
,min(vin10_nb) as vin10_nb
,min(state_cd) as state_cd
,min(make_ds) as make_ds
,min(model_ds) as model_ds
,min(manufactureyear_nb) as manufactureyear_nb
,sum(triphardbrakes_ct) as TotalTripHardBrakes_Ct
,min(installedday_ct) as InstalledDay_Ct
,case when sum(triphardbrakes_ct)/min(InstalledDay_Ct) > 7 then cast (7 as DOUBLE) else cast(sum(triphardbrakes_ct)/min(InstalledDay_Ct) as DOUBLE) end as DailyHardBrakes_Ct
,sum(tripfastacceleration_ct) as TotalFastAcceleration_Ct
,case when sum(tripfastacceleration_ct)/min(InstalledDay_Ct) > 4 then cast(4 as DOUBLE) else cast(sum(tripfastacceleration_ct)/min(InstalledDay_Ct) as DOUBLE) end as DailyFastAcceleration_Ct
,min(totalidletime_am) as totalidletime_am
,min(totaltraveltime_am) as totaltraveltime_am
,min(totalidletime_pc) as idletime_pc
,min(totaltraveldistance_qt) as totaltraveldistance_qt
,sum(SatSunPartition1AdjDistance_Qt+SatSunPartition2AdjDistance_Qt+SatSunPartition3AdjDistance_Qt+SatSunPartition4AdjDistance_Qt+SatSunPartition5AdjDistance_Qt+SatSunPartition6AdjDistance_Qt+SatSunPartition7AdjDistance_Qt+SatSunPartition8AdjDistance_Qt) as adjusteddistance_qt
,sum(SatSunPartition1AdjDistance_Qt+SatSunPartition2AdjDistance_Qt+SatSunPartition3AdjDistance_Qt+SatSunPartition4AdjDistance_Qt+SatSunPartition5AdjDistance_Qt+SatSunPartition6AdjDistance_Qt+SatSunPartition7AdjDistance_Qt+SatSunPartition8AdjDistance_Qt)/min(InstalledDay_Ct) as AverageDailyDistance_Qt
,min(loadevent_id) as loadevent_id 
from ~>work_db.vehicle_partition_3
group by PartnerNotification_Id;

set mapred.job.name = "~>job_cd Drop and recreate telematics_score_2 from telematics_score_1";

drop table if exists ~>work_db.telematics_score_2;

CREATE TABLE ~>work_db.telematics_score_2(
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb int, 
  installedday_ct int, 
  totalhardbrakes_ct bigint, 
  dailyhardbrakes_ct double, 
  totalfastacceleration_ct bigint, 
  dailyfastacceleration_ct double, 
  totalidletime_am bigint, 
  totaltraveltime_am bigint, 
  idletime_pc double, 
  totaltraveldistance_qt double, 
  adjusteddistance_qt double, 
  averagedailydistance_qt double, 
  mileage_fr double, 
  telematicsscore1_qt int, 
  telematicsscore2_qt int, 
  telematicsscore3_qt int, 
  telematicsscore4_qt int, 
  telematicsscore5_qt int, 
  telematicsscore6_qt int, 
  telematicsscore7_qt int, 
  telematicsscore8_qt int, 
  loadevent_id double, 
  partnernotification_id string, 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/telematics_score_2';

insert into table ~>work_db.telematics_score_2
Select
 vin10_nb as VIN10_Nb
,state_cd as State_Cd
,make_ds as Make_Ds
,model_ds as Model_Ds
,manufactureyear_nb as ManufactureYear_Nb
,installedday_ct as InstalledDay_Ct
,totaltriphardbrakes_ct as TotalHardBrakes_Ct
,dailyhardbrakes_ct as DailyHardBrakes_Ct
,totalfastacceleration_ct as TotalFastAcceleration_Ct
,dailyfastacceleration_ct as DailyFastAcceleration_Ct
,totalidletime_am as TotalIdleTime_Am
,totaltraveltime_am as TotalTravelTime_Am
,idletime_pc as IdleTime_Pc
,totaltraveldistance_qt as TotalTravelDistance_Qt
,adjusteddistance_qt as AdjustedDistance_Qt
,averagedailydistance_qt as AverageDailyDistance_Qt
,(case
                   when AverageDailyDistance_Qt > 0      and AverageDailyDistance_Qt< 8.82    then 0.0
                   when AverageDailyDistance_Qt > 8.82   and AverageDailyDistance_Qt<= 17.64  then 0.2399
                   when AverageDailyDistance_Qt > 17.64  and AverageDailyDistance_Qt<= 26.45  then 0.6353
                   when AverageDailyDistance_Qt > 26.45  and AverageDailyDistance_Qt<= 35.27  then 0.7423
                   when AverageDailyDistance_Qt > 35.27  and AverageDailyDistance_Qt<= 44.09  then 0.8572
                   when AverageDailyDistance_Qt > 44.09  and AverageDailyDistance_Qt<= 52.91  then 0.9678
                   when AverageDailyDistance_Qt > 52.91  and AverageDailyDistance_Qt<= 61.73  then 1.0059
                   when AverageDailyDistance_Qt > 61.73  and AverageDailyDistance_Qt<= 70.55  then 1.0440
                   when AverageDailyDistance_Qt > 70.55  and AverageDailyDistance_Qt<= 79.36  then 1.0835
                   when AverageDailyDistance_Qt > 79.36  and AverageDailyDistance_Qt<= 88.18  then 1.1261
                   when AverageDailyDistance_Qt > 88.18  and AverageDailyDistance_Qt<= 97.00  then 1.1686
                   when AverageDailyDistance_Qt > 97.00  and AverageDailyDistance_Qt<= 105.82 then 1.2111
                   when AverageDailyDistance_Qt > 105.82 and AverageDailyDistance_Qt<= 114.64 then 1.2537
                   when AverageDailyDistance_Qt > 114.64 and AverageDailyDistance_Qt<= 123.46 then 1.2962
                   when AverageDailyDistance_Qt > 123.46 and AverageDailyDistance_Qt<= 132.27 then 1.3388
                   when AverageDailyDistance_Qt > 132.27               then 1.3813
                   else 0.0
                   end) as Mileage_Fr
,cast(floor(Case
       when TotalTravelTime_Am = 0 then cast(0 as double)
       when (100 * ((case
                   when AverageDailyDistance_Qt > 0      and AverageDailyDistance_Qt< 8.82    then 0.0
                   when AverageDailyDistance_Qt > 8.82   and AverageDailyDistance_Qt<= 17.64  then 0.2399
                   when AverageDailyDistance_Qt > 17.64  and AverageDailyDistance_Qt<= 26.45  then 0.6353
                   when AverageDailyDistance_Qt > 26.45  and AverageDailyDistance_Qt<= 35.27  then 0.7423
                   when AverageDailyDistance_Qt > 35.27  and AverageDailyDistance_Qt<= 44.09  then 0.8572
                   when AverageDailyDistance_Qt > 44.09  and AverageDailyDistance_Qt<= 52.91  then 0.9678
                   when AverageDailyDistance_Qt > 52.91  and AverageDailyDistance_Qt<= 61.73  then 1.0059
                   when AverageDailyDistance_Qt > 61.73  and AverageDailyDistance_Qt<= 70.55  then 1.0440
                   when AverageDailyDistance_Qt > 70.55  and AverageDailyDistance_Qt<= 79.36  then 1.0835
                   when AverageDailyDistance_Qt > 79.36  and AverageDailyDistance_Qt<= 88.18  then 1.1261
                   when AverageDailyDistance_Qt > 88.18  and AverageDailyDistance_Qt<= 97.00  then 1.1686
                   when AverageDailyDistance_Qt > 97.00  and AverageDailyDistance_Qt<= 105.82 then 1.2111
                   when AverageDailyDistance_Qt > 105.82 and AverageDailyDistance_Qt<= 114.64 then 1.2537
                   when AverageDailyDistance_Qt > 114.64 and AverageDailyDistance_Qt<= 123.46 then 1.2962
                   when AverageDailyDistance_Qt > 123.46 and AverageDailyDistance_Qt<= 132.27 then 1.3388
                   when AverageDailyDistance_Qt > 132.27               then 1.3813
                   else 0.0
                   end)
            + DailyHardBrakes_Ct * 0.1604 + DailyFastAcceleration_Ct * 0.1184 + IdleTime_Pc * 4.2432)) < 1 then cast (1 as double)
      else cast((100 * ((case
                   when AverageDailyDistance_Qt > 0      and AverageDailyDistance_Qt< 8.82    then 0.0
                   when AverageDailyDistance_Qt > 8.82   and AverageDailyDistance_Qt<= 17.64  then 0.2399
                   when AverageDailyDistance_Qt > 17.64  and AverageDailyDistance_Qt<= 26.45  then 0.6353
                   when AverageDailyDistance_Qt > 26.45  and AverageDailyDistance_Qt<= 35.27  then 0.7423
                   when AverageDailyDistance_Qt > 35.27  and AverageDailyDistance_Qt<= 44.09  then 0.8572
                   when AverageDailyDistance_Qt > 44.09  and AverageDailyDistance_Qt<= 52.91  then 0.9678
                   when AverageDailyDistance_Qt > 52.91  and AverageDailyDistance_Qt<= 61.73  then 1.0059
                   when AverageDailyDistance_Qt > 61.73  and AverageDailyDistance_Qt<= 70.55  then 1.0440
                   when AverageDailyDistance_Qt > 70.55  and AverageDailyDistance_Qt<= 79.36  then 1.0835
                   when AverageDailyDistance_Qt > 79.36  and AverageDailyDistance_Qt<= 88.18  then 1.1261
                   when AverageDailyDistance_Qt > 88.18  and AverageDailyDistance_Qt<= 97.00  then 1.1686
                   when AverageDailyDistance_Qt > 97.00  and AverageDailyDistance_Qt<= 105.82 then 1.2111
                   when AverageDailyDistance_Qt > 105.82 and AverageDailyDistance_Qt<= 114.64 then 1.2537
                   when AverageDailyDistance_Qt > 114.64 and AverageDailyDistance_Qt<= 123.46 then 1.2962
                   when AverageDailyDistance_Qt > 123.46 and AverageDailyDistance_Qt<= 132.27 then 1.3388
                   when AverageDailyDistance_Qt > 132.27               then 1.3813
                   else 0.0
                   end)
            + DailyHardBrakes_Ct * 0.1604 + DailyFastAcceleration_Ct * 0.1184 + IdleTime_Pc * 4.2432)) as double)
	 end
	 ) as int) as TelematicsScore1_Qt
,0 as TelematicsScore2_Qt
,0 as TelematicsScore3_Qt
,0 as TelematicsScore4_Qt
,0 as TelematicsScore5_Qt
,0 as TelematicsScore6_Qt
,0 as TelematicsScore7_Qt
,0 as TelematicsScore8_Qt
,loadevent_id
,partnernotification_id as PartnerNotification_Id
,sourcefile_dt as SourceFile_Dt
from ~>work_db.telematics_score_1;

set mapred.job.name = "~>job_cd Drop and recreate telematics_score_3 from telematics_score_2 & experian_reporting_hive_db.ParticipatingState";

drop table if exists ~>work_db.telematics_score_3;

CREATE TABLE ~>work_db.telematics_score_3(
  vin10_nb string, 
  state_cd string, 
  make_ds string, 
  model_ds string, 
  manufactureyear_nb int, 
  installedday_ct int, 
  totalhardbrakes_ct bigint, 
  dailyhardbrakes_ct double, 
  totalfastacceleration_ct bigint, 
  dailyfastacceleration_ct double, 
  totalidletime_am bigint, 
  totaltraveltime_am bigint, 
  idletime_pc double, 
  totaltraveldistance_qt double, 
  adjusteddistance_qt double, 
  averagedailydistance_qt double, 
  mileage_fr double, 
  telematicsscore1_qt int, 
  telematicsscore2_qt int, 
  telematicsscore3_qt int, 
  telematicsscore4_qt int, 
  telematicsscore5_qt int, 
  telematicsscore6_qt int, 
  telematicsscore7_qt int, 
  telematicsscore8_qt int, 
  rollouteffective_dt date, 
  qualify_cd string, 
  loadevent_id double, 
  partnernotification_id string, 
  sourcefile_dt string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/telematics_score_3';

INSERT INTO TABLE ~>work_db.telematics_score_3 
select
 vin10_nb
,ts.state_cd
,make_ds
,model_ds
,manufactureyear_nb
,installedday_ct
,totalhardbrakes_ct
,dailyhardbrakes_ct
,totalfastacceleration_ct
,dailyfastacceleration_ct
,totalidletime_am
,totaltraveltime_am
,idletime_pc
,totaltraveldistance_qt
,adjusteddistance_qt
,averagedailydistance_qt
,mileage_fr
,telematicsscore1_qt
,telematicsscore2_qt
,telematicsscore3_qt
,telematicsscore4_qt
,telematicsscore5_qt
,telematicsscore6_qt
,telematicsscore7_qt
,telematicsscore8_qt
,ps.rollouteffective_dt
, case when ps.state_cd is not null and cast(concat(substr(sourcefile_dt,1,4),'-',substr(sourcefile_dt,5,2),'-',substr(sourcefile_dt,7,2)) as date) >= ps.rollouteffective_dt
       then  case when (ts.state_cd = 'PA' and telematicsscore1_qt > 0)
                  then 'A'
                  when (ts.state_cd = 'CA')
                  then 'C'
                  else
                   case when ((telematicsscore1_qt > 262 and telematicsscore1_qt < 996) or telematicsscore1_qt = 0 or telematicsscore1_qt = 998)
		              then 'C'
                        else 'A'
                    end
             end
      else 'C'
  end
    qualify_cd
,loadevent_id
,partnernotification_id
,sourcefile_dt
from ~>work_db.telematics_score_2 ts
left outer join ~>provide_db.experian_participating_state ps
on ts.state_cd = ps.state_cd;

set mapred.job.name = "~>job_cd Insert into telematics_score_3 from expn_vehicle, expn_trip_summary";

insert into table ~>work_db.telematics_score_3
select
 vin10_nb
,state_cd
,make_ds
,model_ds
,manufactureyear_nb
,datediff(cast(ProgramEnd_Ts as varchar(10)),cast(ProgramStart_Ts as varchar(10) )) as InstalledDay_Ct
,'' as totalhardbrakes_ct
,'' as dailyhardbrakes_ct
,'' as totalfastacceleration_ct
,'' as dailyfastacceleration_ct
,'' as totalidletime_am
,'' as totaltraveltime_am
,'' as idletime_pc
,'' as totaltraveldistance_qt
,'' as adjusteddistance_qt
,'' as averagedailydistance_qt
,'' as mileage_fr
,998 as telematicsscore1_qt
,'' as telematicsscore2_qt
,'' as telematicsscore3_qt
,'' as telematicsscore4_qt
,'' as telematicsscore5_qt
,'' as telematicsscore6_qt
,'' as telematicsscore7_qt
,'' as telematicsscore8_qt
,'' as rollouteffective_dt
,'C' as qualify_cd
,v.loadevent_id
,v.partnernotification_id
,v.sourcefile_dt
from ~>work_db.expn_vehicle v
left outer join
~>work_db.expn_trip_summary ts ON
V.partnernotification_id = TS.partnernotification_id
where v.state_cd <> 'CA' and ts.partnernotification_id is null;


set mapred.job.name = "~>job_cd Insert Overwrite TelematicsScore from telematics_score_3";

INSERT OVERWRITE TABLE  ~>provide_db.experian_telematics_score
PARTITION (sourcefile_dt)
select
 partnernotification_id
,vin10_nb
,state_cd
,make_ds
,model_ds
,manufactureyear_nb
,installedday_ct
,totalhardbrakes_ct
,dailyhardbrakes_ct
,totalfastacceleration_ct
,dailyfastacceleration_ct
,totalidletime_am
,totaltraveltime_am
,idletime_pc
,totaltraveldistance_qt
,adjusteddistance_qt
,averagedailydistance_qt
,mileage_fr
,telematicsscore1_qt
,telematicsscore2_qt
,telematicsscore3_qt
,telematicsscore4_qt
,telematicsscore5_qt
,telematicsscore6_qt
,telematicsscore7_qt
,telematicsscore8_qt
,qualify_cd
,loadevent_id
,sourcefile_dt
 from ~>work_db.telematics_score_3;


set mapred.job.name = "~>job_cd Insert Overwrite nwi_bd_aqb_rated from telematics_score_3";


INSERT OVERWRITE TABLE  ~>provide_db.experian_nwi_bd_aqb_rated
PARTITION (sourcefile_dt='~>current_date')
select
PartnerNotification_id,
VIN10_Nb,
ManufactureYear_Nb,
Make_Ds,
Model_Ds,
cast(TelematicsScore1_Qt as int) as TelematicsScore1_Qt
from ~>work_db.telematics_score_3
where qualify_cd = 'A';


set mapred.job.name = "~>job_cd Create table rated_record_11_nationwide from telematics_score_3 & expn_vehicle";

insert overwrite table ~>provide_db.experian_rated_record_11_nationwide
SELECT
concat(PartnerNotification_Id,',',qualify_cd) as private_record
FROM ~>work_db.telematics_score_3
UNION
SELECT
concat(PartnerNotification_Id,',','C') AS private_record
FROM ~>work_db.expn_vehicle
WHERE state_cd = 'CA';