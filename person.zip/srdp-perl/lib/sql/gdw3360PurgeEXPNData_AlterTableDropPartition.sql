alter table ~>expn_cncl_db.Vehicle drop IF EXISTS partition (sourcefile_dt = '~>sourcefile_dt');
alter table ~>expn_cncl_db.TripSummary drop IF EXISTS partition (sourcefile_dt = '~>sourcefile_dt');
alter table ~>expn_cncl_db.TripEvent drop IF EXISTS partition (sourcefile_dt = '~>sourcefile_dt');

alter table ~>expn_rpt_db.VehiclePartition drop IF EXISTS partition (sourcefile_dt = '~>sourcefile_dt');
alter table ~>expn_rpt_db.TelematicsScore drop IF EXISTS partition (sourcefile_dt = '~>sourcefile_dt');