--Step 1--  Standardize IMS Foundation Trip Point Drop Recreate

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_trippoint_temp;

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_trippoint_temp
(
DataLoad_Dt TIMESTAMP COMMENT 'Load date',
SourceFileName_Ts TIMESTAMP COMMENT 'Source file datestamp',
LoadEvent_Id BIGINT COMMENT 'Unique  Identifier to indicate the load', 
DeviceType_Cd INT  COMMENT 'To Indicate data record from Octo vendor',
FullPolicy_Nb STRING COMMENT 'Full Policy Number',
Voucher_Nb BIGINT,
Trip_Nb STRING COMMENT 'Trip number',
Position_Ts TIMESTAMP COMMENT 'Trip position timestamp',
Latitude_It DOUBLE,
Longitude_It DOUBLE,
VSSSpeed_Am DOUBLE,
VSSAcceleration_Pc DOUBLE,
EngineRPM_Qt INT,
ThrottlePosition_Pc DOUBLE,
AccelerationLateral_Qt DOUBLE,
AccelerationLongitudinal_Qt DOUBLE, 
AccelerationVertical_Qt DOUBLE,
GPSHeading_Nb SMALLINT,
PositionQuality_Nb DOUBLE,
OdometerReading_Qt DOUBLE,
EventAverageSpeed_Qt DOUBLE,
EventAverageAcceleration_Qt DOUBLE,
DistanceTravelled_Qt DOUBLE,
TimeElapsed_Qt DOUBLE,
GPSPointSpeed_Qt DOUBLE,
Road_Tp STRING,
source_cd string, 
batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_trippoint_temp';



set mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.WK_IMS_TSP_TripPoint_Temp from ~>staging_db.smartride_ims_trippoint";

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_trippoint_temp
SELECT   
from_unixtime(unix_timestamp())as DataLoad_Dt,
CONCAT(substr(batch,1,4),'-',substr(batch,5,2),'-',substr(batch,7,2),' ',CASE substr(batch,9,2) WHEN '24' THEN '00' ELSE substr(batch,9,2) END,':',substr(batch,11,2),':00','.000000')as SourceFileName_Ts,
loadevent, 
'',
'',
'',
Trip_Nb,
Position_Ts,
Latitude_It,
Longitude_It,
VSSSpeed_Am,
VSSAcceleration_Pc,
enginerpm_am,
ThrottlePosition_Pc,
AccelerationLateral_Nb,
AccelerationLongitudinal_Nb,
AccelerationVertical_Nb,    
GPSHeading_Nb,
PositionQuality_Nb,
'',
'',
'',
'',
'',
'',
'',
'IMS' as source_cd,
batch
from ~>staging_db.smartride_ims_trippoint
WHERE loadevent in (~>load_event_id_list);


-- Step 3 --  Standardize IMS Foundation Trip Point Load TSP Trip Point

-- Drop and recreate work table smartride_wk_ims_tsp_trippoint from smartride_wk_ims_tsp_trippoint

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_trippoint;

 CREATE TABLE ~>work_db.smartride_wk_ims_tsp_trippoint( 
 dataload_dt timestamp
,sourcefilename_ts timestamp
,loadevent_id bigint
,devicetype_cd int
,fullpolicy_nb string
,voucher_nb bigint
,trip_nb string
,position_ts timestamp
,latitude_it double
,longitude_it double
,vssspeed_am double
,vssacceleration_pc double
,enginerpm_qt int
,throttleposition_pc double
,accelerationlateral_qt double
,accelerationlongitudinal_qt double
,accelerationvertical_qt double
,gpsheading_nb smallint
,positionquality_nb double
,odometerreading_qt double
,eventaveragespeed_qt double
,eventaverageacceleration_qt double
,distancetravelled_qt double
,timeelapsed_qt double
,gpspointspeed_qt double
,road_tp string
,source_cd string
,batch string
)
STORED as PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_trippoint';

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.TSP_TripPoint & ~>work_db.smartride_wk_ims_tsp_trippoint from ~>work_db.smartride_wk_ims_tsp_trippoint_temp";

FROM ~>work_db.smartride_wk_ims_tsp_trippoint_temp
INSERT OVERWRITE TABLE ~>foundation_db.smartride_TSP_TripPoint
PARTITION (source_cd='IMS',batch)
SELECT 
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
Trip_Nb,
Position_Ts,
Latitude_It,
Longitude_It,
VSSSpeed_Am,
VSSAcceleration_Pc,
EngineRPM_Qt,
ThrottlePosition_Pc,
AccelerationLateral_Qt,
AccelerationLongitudinal_Qt,
AccelerationVertical_Qt,
GPSHeading_Nb,
PositionQuality_Nb,
OdometerReading_Qt,
EventAverageSpeed_Qt,
EventAverageAcceleration_Qt,
DistanceTravelled_Qt,
TimeElapsed_Qt,
GPSPointSpeed_Qt,
Road_Tp,
batch

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_trippoint
SELECT 
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
Trip_Nb,
Position_Ts,
Latitude_It,
Longitude_It,
VSSSpeed_Am,
VSSAcceleration_Pc,
EngineRPM_Qt,
ThrottlePosition_Pc,
AccelerationLateral_Qt,
AccelerationLongitudinal_Qt,
AccelerationVertical_Qt,
GPSHeading_Nb,
PositionQuality_Nb,
OdometerReading_Qt,
EventAverageSpeed_Qt,
EventAverageAcceleration_Qt,
DistanceTravelled_Qt,
TimeElapsed_Qt,
GPSPointSpeed_Qt,
Road_Tp,
source_cd,
batch;






