DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_trippoint_ext_dups;

set mapred.job.name = "~>job_cd Create table ~>work_db.smartride_wk_ims_trippoint_ext_dups from ~>staging_db.smartride_ims_trippoint";

CREATE TABLE ~>work_db.smartride_wk_ims_trippoint_ext_dups(
  trip_nb string, 
  position_ts timestamp)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_trippoint_ext_dups';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_trippoint_ext_dups
SELECT 
TRIP_NB,
Position_Ts
FROM ~>staging_db.smartride_ims_trippoint
WHERE loadevent in (~>load_event_id_list)
GROUP BY TRIP_NB,Position_Ts HAVING COUNT(*) > 1;

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tripevent_ext_dups;

set mapred.job.name = "~>job_cd Create ~>work_db.smartride_wk_ims_tripevent_ext_dups from ~>staging_db.smartride_ims_tripevent";

CREATE TABLE ~>work_db.smartride_wk_ims_tripevent_ext_dups(
  trip_nb string, 
  event_ts timestamp, 
  eventtype_cd string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tripevent_ext_dups';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tripevent_ext_dups
SELECT
TRIP_NB,
Event_Ts,
EventType_Cd
FROM ~>staging_db.smartride_ims_tripevent
WHERE loadevent in (~>load_event_id_list)
GROUP BY TRIP_NB,Event_Ts,EventType_Cd HAVING COUNT(*) > 1;

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tripsummary_ext_dups;

set mapred.job.name = "~>job_cd Create ~>work_db.smartride_wk_ims_tripsummary_ext_dups from ~>staging_db.smartride_ims_tripsummary";

CREATE TABLE ~>work_db.smartride_wk_ims_tripsummary_ext_dups(
  trip_nb string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tripsummary_ext_dups';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tripsummary_ext_dups
SELECT Trip_Nb
FROM ~>staging_db.smartride_ims_tripsummary
WHERE loadevent in (~>load_event_id_list)
GROUP BY Trip_Nb HAVING COUNT(*) > 1;

SET hive.exec.parallel=true;

-- loading all the dups into the below table 

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_dup_ctrl;

set mapred.job.name = "~>job_cd Create ~>work_db.smartride_WK_IMS_Dup_Ctrl_Temp from union of smartride_wk_ims_tripsummary_ext_dups, smartride_wk_ims_tripevent_ext_dups, smartride_wk_ims_trippoint_ext_dups";

CREATE TABLE ~>work_db.smartride_wk_ims_dup_ctrl(
  trip_nb string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_dup_ctrl';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_dup_ctrl
SELECT DISTINCT TRIP_NB
FROM
(
SELECT DISTINCT Trip_Nb from ~>work_db.smartride_wk_ims_tripsummary_ext_dups
UNION ALL
SELECT DISTINCT Trip_Nb from ~>work_db.smartride_wk_ims_tripevent_ext_dups
UNION ALL
SELECT DISTINCT Trip_Nb from ~>work_db.smartride_wk_ims_trippoint_ext_dups
) DIST_TRIPS;

-- Loading all non missing trips in the below table

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_missing_trip_ctrl;

set mapred.job.name = "~>job_cd Create table ~>work_db.smartride_WK_IMS_Missing_Trip_Ctrl_Temp from ~>staging_db.smartride_ims_trippoint & ~>staging_db.smartride_ims_tripsummary";

CREATE TABLE ~>work_db.smartride_wk_ims_missing_trip_ctrl(
  trip_nb string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_missing_trip_ctrl';

INSERT OVERWRITE  TABLE ~>work_db.smartride_wk_ims_missing_trip_ctrl
SELECT ts.Trip_Nb
FROM ~>staging_db.smartride_ims_trippoint tp inner join
~>staging_db.smartride_ims_tripsummary ts
on tp.trip_nb = ts.trip_nb
and ts.loadevent = tp.loadevent
WHERE ts.loadevent in (~>load_event_id_list)
GROUP BY ts.trip_nb
;