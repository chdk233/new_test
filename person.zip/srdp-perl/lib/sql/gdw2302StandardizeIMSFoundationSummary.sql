--------------------------------------------------------------------------------------------------------
--Step1-- Standardize IMS Foundation Summary Drop Recreate
--------------------------------------------------------------------------------------------------------


DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripsummary_temp;

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp(
 DataLoad_Dt  TIMESTAMP COMMENT 'Load date',
 SourceFileName_Ts TIMESTAMP COMMENT 'Source file datestamp',
 LoadEvent_Id BIGINT COMMENT 'Unique  Identifier to indicate the load',
 Trip_Nb STRING COMMENT 'Trip number',
 DeviceSerial_Nb BIGINT COMMENT 'Device serial number of the device',
 EnrolledVIN_Nb STRING COMMENT 'Enrolled Vehicle Indentification number',
 DetectedVIN_Nb STRING COMMENT 'Detected Vehicle Indentification number',
 TripStart_Ts TIMESTAMP COMMENT 'Start time of the trip',
 TripEnd_Ts  TIMESTAMP COMMENT 'End time of the trip',
 TripZoneOffset_AM STRING COMMENT 'Timezone offset',
 TripDistance_Qt DOUBLE,
 AverageSpeed_Qt DOUBLE,
 MaximumSpeed_Qt DOUBLE,
 FuelConsumption_Qt DOUBLE,
 MILStatus_Cd STRING,
 IdleTime_Ts INT,
 TripPositionalQuality_Qt DOUBLE,
 AccelerometerQuality_Qt DOUBLE,
 source_cd string,
 batch string)
 STORED AS PARQUET
 LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary_temp';
  

set mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.smartride_WK_IMS_TSP_TripSummary_Temp from ~>staging_db.smartride_ims_tripsummary";

--------------------------------------------------------------------------------------------------------
--Step2-- Standardize IMS Foundation Summary Wk Table Load
--------------------------------------------------------------------------------------------------------

INSERT overwrite TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp
select
from_unixtime(unix_timestamp())as DataLoad_Dt,
CONCAT(substr(batch,1,4),'-',substr(batch,5,2),'-',substr(batch,7,2),' ',CASE substr(batch,9,2) WHEN '24' THEN '00' ELSE substr(batch,9,2) END,':',substr(batch,11,2),':00','.000000')as SourceFileName_Ts,
loadevent,
trip_nb,
deviceserial_nb,
enrolledvin_nb,
detectedvin_nb,
tripstart_ts,
tripend_ts,
( case when instr(tripzoneoffset_am,':') > 0
then
case when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) > 0
then concat(' ',Substr('00' , 1 ,2-length(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)))),Trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) < 0 
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
case when instr(tripzoneoffset_am,'-') > 1
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
concat(' 00',substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
end
end
else concat(Substr('     ',1,5-length(tripzoneoffset_am)),trim(tripzoneoffset_am))
end )as tripzoneoffset_am,
tripdistance_qt,
averagespeed_qt,
maximumspeed_qt,
fuelconsumption_qt,
milstatus_cd,
idletime_ts,
trippositionalquality_qt,
accelerometerquality_qt,
'IMS' as source_cd,
batch
from ~>staging_db.smartride_ims_tripsummary
where loadevent in (~>load_event_id_list);

set mapred.job.name = "~>job_cd load all historical data without dups into ims_tsp_tripsummary_dups";

--------------------------------------------------------------------------------------------------------
--Step3-- Standardize IMS Foundation Summary Load TSP Trip Summary

-- DESCRIPTION This script is used for loading TSP_TripSummary table from HDFS vendor Summary file
-- Audit check to find the duplicates between Historical data and Incoming file
-- Audit check to find duplicates within the incremental batch
---------------------------------------------------------------------------------------------------------

INSERT OVERWRITE TABLE ~>foundation_db.smartride_ims_tsp_tripsummary_dups
PARTITION (source_cd='IMS',batch,flag) 
Select temp.dataload_dt 
,temp.sourcefilename_ts
,temp.loadevent_id
,temp.trip_nb
,temp.deviceserial_nb
,temp.enrolledvin_nb
,temp.detectedvin_nb
,temp.tripstart_ts
,temp.tripend_ts
,temp.tripzoneoffset_am
,temp.tripdistance_qt
,temp.averagespeed_qt
,temp.maximumspeed_qt
,temp.fuelconsumption_qt
,temp.milstatus_cd
,temp.idletime_ts
,temp.trippositionalquality_qt
,temp.accelerometerquality_qt
,temp.batch
, 'H' as flag 
 from ~>work_db.smartride_wk_ims_tsp_tripsummary_temp temp
 left outer join ~>foundation_db.smartride_tsp_tripsummary tsp_ts
 on tsp_ts.trip_nb = temp.trip_nb
 and tsp_ts.source_cd = temp.source_cd
 and tsp_ts.batch >= '~>batch_filter_3_mo_ago'
 and tsp_ts.source_cd = 'IMS'
 and tsp_ts.batch not like 'conv%'
 where  tsp_ts.trip_nb is not null 
 and tsp_ts.batch <> temp.batch;

---Drop work table of trip summary where there are no duplicates

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_2;

set mapred.job.name = "~>job_cd Create work table of trip summary where there are no duplicates.";

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_2(
  dataload_dt timestamp, 
  sourcefilename_ts timestamp, 
  loadevent_id bigint, 
  trip_nb string, 
  deviceserial_nb bigint, 
  enrolledvin_nb string, 
  detectedvin_nb string, 
  tripstart_ts timestamp, 
  tripend_ts timestamp, 
  tripzoneoffset_am string, 
  tripdistance_qt double, 
  averagespeed_qt double, 
  maximumspeed_qt double, 
  fuelconsumption_qt double, 
  milstatus_cd string, 
  idletime_ts int, 
  trippositionalquality_qt double, 
  accelerometerquality_qt double, 
  source_cd string, 
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary_temp_2';


INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_2
SELECT 
temp.dataload_dt
,temp.sourcefilename_ts
,temp.loadevent_id
,temp.trip_nb
,temp.deviceserial_nb
,temp.enrolledvin_nb
,temp.detectedvin_nb
,temp.tripstart_ts
,temp.tripend_ts
,temp.tripzoneoffset_am
,temp.tripdistance_qt
,temp.averagespeed_qt
,temp.maximumspeed_qt
,temp.fuelconsumption_qt
,temp.milstatus_cd
,temp.idletime_ts
,temp.trippositionalquality_qt
,temp.accelerometerquality_qt
,temp.source_cd
,temp.batch 
 from ~>work_db.smartride_wk_ims_tsp_tripsummary_temp temp 
 left outer join ~>foundation_db.smartride_ims_tsp_tripsummary_dups dups
 on dups.trip_nb = temp.trip_nb and
 dups.batch = temp.batch 
 where dups.trip_nb is null;
 
--- Phase 2 Audit check for identifying dups within the incremental batch

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripsummary_dups;

set mapred.job.name = "~>job_cd Create table ~>work_db.smartride_wk_ims_tsp_tripsummary_dups from ~>work_db.smartride_WK_IMS_TSP_TripSummary_Temp & ~>foundation_db.smartride_ims_dup_ctrl";

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_dups(
  dataload_dt timestamp, 
  sourcefilename_ts timestamp, 
  loadevent_id bigint, 
  trip_nb string, 
  deviceserial_nb bigint, 
  enrolledvin_nb string, 
  detectedvin_nb string, 
  tripstart_ts timestamp, 
  tripend_ts timestamp, 
  tripzoneoffset_am string, 
  tripdistance_qt double, 
  averagespeed_qt double, 
  maximumspeed_qt double, 
  fuelconsumption_qt double, 
  milstatus_cd string, 
  idletime_ts int, 
  trippositionalquality_qt double, 
  accelerometerquality_qt double, 
  source_cd string, 
  batch string, 
  flag string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary_dups';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_dups
SELECT 
 temp.dataload_dt
,temp.sourcefilename_ts
,temp.loadevent_id
,temp.trip_nb
,temp.deviceserial_nb
,temp.enrolledvin_nb
,temp.detectedvin_nb
,temp.tripstart_ts
,temp.tripend_ts
,temp.tripzoneoffset_am
,temp.tripdistance_qt
,temp.averagespeed_qt
,temp.maximumspeed_qt
,temp.fuelconsumption_qt
,temp.milstatus_cd
,temp.idletime_ts
,temp.trippositionalquality_qt
,temp.accelerometerquality_qt
,temp.source_cd
,temp.batch
,'I' as flag 
 from ~>work_db.smartride_wk_ims_tsp_tripsummary_temp temp 
 left outer join ~>work_db.smartride_wk_ims_dup_ctrl dup
 on dup.trip_nb = temp.trip_nb
 where dup.trip_nb is not null;


set mapred.job.name = "~>job_cd Load data into ims_tsp_tripsummary_dups from wk_ims_tsp_tripsummary_dups";

INSERT OVERWRITE TABLE ~>foundation_db.smartride_ims_tsp_tripsummary_dups
PARTITION (source_cd='IMS',batch,flag)
select 
dataload_dt
,sourcefilename_ts
,loadevent_id
,trip_nb
,deviceserial_nb
,enrolledvin_nb
,detectedvin_nb
,tripstart_ts
,tripend_ts
,tripzoneoffset_am
,tripdistance_qt
,averagespeed_qt
,maximumspeed_qt
,fuelconsumption_qt
,milstatus_cd
,idletime_ts
,trippositionalquality_qt
,accelerometerquality_qt
,batch
,flag
from ~>work_db.smartride_wk_ims_tsp_tripsummary_dups;


---Drop work table that consists of non-dups of incremental batch

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_3;

set mapred.job.name = "~>job_cd create work table that consists of non-dups of incremental batch";

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_3(
  dataload_dt timestamp, 
  sourcefilename_ts timestamp, 
  loadevent_id bigint, 
  trip_nb string, 
  deviceserial_nb bigint, 
  enrolledvin_nb string, 
  detectedvin_nb string, 
  tripstart_ts timestamp, 
  tripend_ts timestamp, 
  tripzoneoffset_am string, 
  tripdistance_qt double, 
  averagespeed_qt double, 
  maximumspeed_qt double, 
  fuelconsumption_qt double, 
  milstatus_cd string, 
  idletime_ts int, 
  trippositionalquality_qt double, 
  accelerometerquality_qt double, 
  source_cd string, 
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary_temp_3';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_3
SELECT 
temp.dataload_dt
,temp.sourcefilename_ts
,temp.loadevent_id
,temp.trip_nb
,temp.deviceserial_nb
,temp.enrolledvin_nb
,temp.detectedvin_nb
,temp.tripstart_ts
,temp.tripend_ts
,temp.tripzoneoffset_am
,temp.tripdistance_qt
,temp.averagespeed_qt
,temp.maximumspeed_qt
,temp.fuelconsumption_qt
,temp.milstatus_cd
,temp.idletime_ts
,temp.trippositionalquality_qt
,temp.accelerometerquality_qt
,temp.source_cd
,temp.batch from ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_2 temp 
 left outer join ~>work_db.smartride_wk_ims_dup_ctrl dup
 on dup.trip_nb = temp.trip_nb
 where  dup.trip_nb is null;
 
-- create work table that consists of missing trips of incremental batch

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripsummary_mis;

set mapred.job.name = "~>job_cd Create table ~>work_db.smartride_wk_ims_tsp_tripsummary_mis from wk_ims_tsp_tripsummary_temp_3 & wk_ims_missing_trip_ctrl";

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_mis(
  dataload_dt timestamp, 
  sourcefilename_ts timestamp, 
  loadevent_id bigint, 
  trip_nb string, 
  deviceserial_nb bigint, 
  enrolledvin_nb string, 
  detectedvin_nb string, 
  tripstart_ts timestamp, 
  tripend_ts timestamp, 
  tripzoneoffset_am string, 
  tripdistance_qt double, 
  averagespeed_qt double, 
  maximumspeed_qt double, 
  fuelconsumption_qt double, 
  milstatus_cd string, 
  idletime_ts int, 
  trippositionalquality_qt double, 
  accelerometerquality_qt double, 
  source_cd string, 
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary_mis';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_mis
SELECT 
temp.dataload_dt
,temp.sourcefilename_ts
,temp.loadevent_id
,temp.trip_nb
,temp.deviceserial_nb
,temp.enrolledvin_nb
,temp.detectedvin_nb
,temp.tripstart_ts
,temp.tripend_ts
,temp.tripzoneoffset_am
,temp.tripdistance_qt
,temp.averagespeed_qt
,temp.maximumspeed_qt
,temp.fuelconsumption_qt
,temp.milstatus_cd
,temp.idletime_ts
,temp.trippositionalquality_qt
,temp.accelerometerquality_qt
,temp.source_cd
,temp.batch 
 from ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_3 temp 
 left outer join ~>work_db.smartride_wk_ims_missing_trip_ctrl mis
 on mis.trip_nb = temp.trip_nb
 where mis.trip_nb is null;
 

set mapred.job.name = "~>job_cd Load data into ims_tsp_tripsummary_mis from wk_ims_tsp_tripsummary_mis";

INSERT OVERWRITE TABLE ~>foundation_db.smartride_ims_tsp_tripsummary_mis
PARTITION (source_cd='IMS', batch)
select 
dataload_dt,
sourcefilename_ts,
loadevent_id,
trip_nb,
deviceserial_nb,
enrolledvin_nb,
detectedvin_nb,
tripstart_ts,
tripend_ts,
tripzoneoffset_am,
tripdistance_qt,
averagespeed_qt,
maximumspeed_qt,
fuelconsumption_qt,
milstatus_cd,
idletime_ts,
trippositionalquality_qt,
accelerometerquality_qt,
batch
from ~>work_db.smartride_wk_ims_tsp_tripsummary_mis;


DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_4;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_4 from wk_ims_tsp_tripsummary_temp_3 & wk_ims_missing_trip_ctrl"; 

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_4(
  dataload_dt timestamp, 
  sourcefilename_ts timestamp, 
  loadevent_id bigint, 
  trip_nb string, 
  deviceserial_nb bigint, 
  enrolledvin_nb string, 
  detectedvin_nb string, 
  tripstart_ts timestamp, 
  tripend_ts timestamp, 
  tripzoneoffset_am string, 
  tripdistance_qt double, 
  averagespeed_qt double, 
  maximumspeed_qt double, 
  fuelconsumption_qt double, 
  milstatus_cd string, 
  idletime_ts int, 
  trippositionalquality_qt double, 
  accelerometerquality_qt double, 
  source_cd string, 
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary_temp_4';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_4
SELECT 
temp.dataload_dt
,temp.sourcefilename_ts
,temp.loadevent_id
,temp.trip_nb
,temp.deviceserial_nb
,temp.enrolledvin_nb
,temp.detectedvin_nb
,temp.tripstart_ts
,temp.tripend_ts
,temp.tripzoneoffset_am
,temp.tripdistance_qt
,temp.averagespeed_qt
,temp.maximumspeed_qt
,temp.fuelconsumption_qt
,temp.milstatus_cd
,temp.idletime_ts
,temp.trippositionalquality_qt
,temp.accelerometerquality_qt
,temp.source_cd
,temp.batch from ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_3 temp 
 left outer join ~>work_db.smartride_wk_ims_missing_trip_ctrl mis
 on mis.trip_nb = temp.trip_nb
 where mis.trip_nb is not null; 



DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripsummary_final;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_wk_ims_tsp_tripsummary_final from WK_IMS_TSP_TripSummary_Temp_4";

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_final(
  dataload_dt timestamp,
  sourcefilename_ts timestamp,
  loadevent_id bigint,
  devicetype_cd string,
  fullpolicy_nb string,
  voucher_nb string,
  sr_pgm_instnc_id int,
  deviceserial_nb bigint,
  enrolledvin_nb string,
  trip_nb string,
  detectedvin_nb string,
  tripstart_ts timestamp,
  tripend_ts timestamp,
  plcy_ratd_st_cd string,
  tripdistance_qt double,
  averagespeed_qt double,
  maximumspeed_qt double,
  fuelconsumption_qt double,
  milstatus_cd string,
  tripzoneoffset_am string,
  idletime_ts int,
  trippositionalquality_qt double,
  accelerometerquality_qt double,
  distancemotorways_qt string,
  distanceurbanareas_qt string,
  distanceotherroad_qt string,
  distanceunknownroad_qt string,
  timetravelled_qt string,
  timemotorways_qt string,
  timeurbanareas_qt string,
  timeotherroad_qt string,
  timeunknownroad_qt string,
  speedingdistancemotorways_qt string,
  speedingdistanceurbanareas_qt string,
  speedingdistanceotherroad_qt string,
  speedingdistanceunknownroad_qt string,
  speedingtimemotorways_qt string,
  speedingtimeurbanareas_qt string,
  speedingtimeotherroad_qt string,
  speedingtimeunknownroad_qt string,
  source_cd string,
  batch string)
  STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary_final';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary_final
SELECT
temp.DataLoad_Dt,
temp.SourceFileName_Ts,
temp.LoadEvent_Id,  
'' AS DeviceType_Cd,
'' AS FullPolicy_Nb,
'' AS Voucher_Nb,
-1 AS sr_pgm_instnc_id,
temp.DeviceSerial_Nb,
temp.EnrolledVIN_Nb,
temp.Trip_Nb,
'' AS DetectedVIN_Nb,
temp.TripStart_Ts,
temp.TripEnd_Ts,
'' AS plcy_ratd_st_cd,
temp.TripDistance_Qt,
temp.AverageSpeed_Qt,
temp.MaximumSpeed_Qt,
temp.FuelConsumption_Qt,
temp.MILStatus_Cd,
temp.TripZoneOffset_AM,
temp.IdleTime_Ts,
temp.TripPositionalQuality_Qt,
temp.AccelerometerQuality_Qt,
'' AS DistanceMotorways_Qt,
'' AS DistanceUrbanAreas_Qt,
'' AS DistanceOtherRoad_Qt,
'' AS DistanceUnknownRoad_Qt,
'' AS TimeTravelled_Qt,
'' AS TimeMotorways_Qt,
'' AS TimeUrbanAreas_Qt,
'' AS TimeOtherRoad_Qt,
'' AS TimeUnknownRoad_Qt,
'' AS SpeedingDistanceMotorways_Qt,
'' AS SpeedingDistanceUrbanAreas_Qt,
'' AS SpeedingDistanceOtherRoad_Qt,
'' AS SpeedingDistanceUnknownRoad_Qt,
'' AS SpeedingTimeMotorways_Qt,
'' AS SpeedingTimeUrbanAreas_Qt,
'' AS SpeedingTimeOtherRoad_Qt,
'' AS SpeedingTimeUnknownRoad_Qt,
'IMS' as source_cd,
temp.batch
from ~>work_db.smartride_wk_ims_tsp_tripsummary_temp_4 temp
;

DROP TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary;

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary
( 
dataload_dt timestamp
,sourcefilename_ts timestamp
,loadevent_id bigint
,devicetype_cd string
,fullpolicy_nb string
,voucher_nb string
,sr_pgm_instnc_id int
,deviceserial_nb bigint
,enrolledvin_nb string
,trip_nb string
,detectedvin_nb string
,tripstart_ts timestamp
,tripend_ts timestamp
,plcy_ratd_st_cd string
,tripdistance_qt double
,averagespeed_qt double
,maximumspeed_qt double
,fuelconsumption_qt double
,milstatus_cd string
,tripzoneoffset_am string
,idletime_ts int
,trippositionalquality_qt double
,accelerometerquality_qt double
,distancemotorways_qt string
,distanceurbanareas_qt string
,distanceotherroad_qt string
,distanceunknownroad_qt string
,timetravelled_qt string
,timemotorways_qt string
,timeurbanareas_qt string
,timeotherroad_qt string
,timeunknownroad_qt string
,speedingdistancemotorways_qt string
,speedingdistanceurbanareas_qt string
,speedingdistanceotherroad_qt string
,speedingdistanceunknownroad_qt string
,speedingtimemotorways_qt string
,speedingtimeurbanareas_qt string
,speedingtimeotherroad_qt string
,speedingtimeunknownroad_qt string
,source_cd string
,batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripsummary';

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartride_tsp_tripsummary & ~>work_db.smartride_WK_IMS_TSP_TripSummary from ~>work_db.smartride_WK_IMS_TSP_TripSummary_final";

FROM ~>work_db.smartride_wk_ims_tsp_tripsummary_final
INSERT OVERWRITE TABLE ~>foundation_db.smartride_tsp_tripsummary
PARTITION (source_cd='IMS',batch)
select
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
batch

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripsummary
select
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
source_cd,
batch;