
use ~>smartride_raw_hive_db;

alter table IMS_TripCumulative_Ext_H add IF NOT EXISTS partition(batch='~>batch_id'); 

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_IMS_TSP_TripCumulative_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_IMS_TSP_TripCumulative_H from smartride_raw_hive_db.IMS_TripCumulative_Ext_H";

CREATE TABLE ~>smartride_work_hive_db.WK_IMS_TSP_TripCumulative_H 
as
select  
    cast(cast(DataLoad_Dt as date)as timestamp) as DataLoad_Dt,
    cast(cast(DataLoad_Dt as date)as timestamp) as SourceFileName_Ts,  
    ~>load_event_id as LoadEvent_Id,  
    '' as DeviceType_Cd,
    '' as Voucher_Nb,
    DeviceSerial_Nb,
    EnrolledVIN_Nb,
    '' AS DetectedVIN_Nb,
    CumulativeTrips_Qt,
    CumulativeDistance_Qt,
    CumulativeEngineOn_Qt,
    FirstTripStart_Ts,
    LastTripEnd_Ts,
    LastProcessing_Ts,
    'IMS' as source_cd, 
    batch 
from  ~>smartride_raw_hive_db.IMS_TripCumulative_Ext_H WHERE
    batch='~>batch_id';

use ~>smartride_canonical_hive_db;

set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.dynamic.partitions.pernode=100000;
set hive.exec.parallel=false; 
	
set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.can_tripcumulative from smartride_work_hive_db.WK_IMS_TSP_TripCumulative_H";
	
INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.~>can_tripcumulative
PARTITION (source_cd, batch)
select
dataload_dt 
,sourcefilename_ts 
,loadevent_id
,devicetype_cd 
,voucher_nb 
,deviceserial_nb 
,enrolledvin_nb string 
,detectedvin_nb string 
,cumulativetrips_qt 
,cumulativedistance_qt 
,cumulativeengineon_qt 
,firsttripstart_ts 
,lasttripend_ts 
,lastprocessing_ts 
,source_cd
,batch
from ~>smartride_work_hive_db.WK_IMS_TSP_TripCumulative_H
;
