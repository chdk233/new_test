--------------------------
--  IDENTIFY NEW PIIDS  --
--------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.wk_new_pids;

CREATE TABLE ~>srdp_wk_db.wk_new_pids(
	 sr_pgm_instnc_id bigint,
	 vhcl_id_nbr string,
	 sr_enrlmnt_dt timestamp,
	 dev_id_nbr bigint,
	 plcy_ratd_st_cd string,
	 active_end_dt timestamp,
	 active_start_dt timestamp,
	 pid_md5 string,  -- pid, vin & device md5
	 vindev_md5 string)  -- vin & device md5
STORED AS ORC;

set mapred.job.name = "~>job_cd Insert new PIIDS into ~>srdp_wk_db.wk_new_pids";

INSERT INTO TABLE ~>srdp_wk_db.wk_new_pids
SELECT
a.sr_pgm_instnc_id,
a.vhcl_id_nbr,
a.sr_enrlmnt_dt,
a.dev_id_nbr,
a.plcy_ratd_st_cd,
a.active_end_dt,
a.active_start_dt,
default.md5(cast(a.sr_pgm_instnc_id as string)) as pid_md5,
default.md5(concat(a.vhcl_id_nbr,cast(a.dev_id_nbr as string))) as vindev_md5
FROM ~>srdp_cncl_db.smt_ods_bigin_pgm_instnc a

LEFT OUTER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc b
ON default.md5(cast(a.sr_pgm_instnc_id as string)) = b.pid_md5

WHERE b.dc_instance_id IS NULL
AND a.dev_id_nbr IS NOT NULL;

set mapred.job.name = "~>job_cd Assign DC_ID for existing vin/device";


---------------------------
--  ASSIGN DATA CONF IDS --
---------------------------
--New PIID, but the vin/dev combo already exists and has a DC_ID
INSERT INTO ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
SELECT
b.dc_instance_id,
a.sr_pgm_instnc_id,
a.vhcl_id_nbr,
a.sr_enrlmnt_dt,
a.dev_id_nbr,
a.plcy_ratd_st_cd,
a.active_end_dt,
a.active_start_dt,
a.pid_md5,
a.vindev_md5
FROM ~>srdp_wk_db.wk_new_pids a

INNER JOIN
(
	SELECT dc_instance_id, vindev_md5
	FROM ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
	GROUP BY dc_instance_id, vindev_md5
) b
ON a.vindev_md5 = b.vindev_md5;

set mapred.reduce.tasks=1;
set mapred.job.name = "~>job_cd Assign DC_ID for new vin/device";


--New PIID, need to assign a new DC_ID
INSERT INTO ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
SELECT
DENSE_RANK() OVER( ORDER BY a.vhcl_id_nbr ,a.dev_id_nbr) + b.max_dc_instance_id AS dc_instance_id,
a.*
FROM
(
		SELECT
		a.sr_pgm_instnc_id,
		a.vhcl_id_nbr,
		a.sr_enrlmnt_dt,
		a.dev_id_nbr,
		a.plcy_ratd_st_cd,
		a.active_end_dt,
		a.active_start_dt,
		a.pid_md5,
		a.vindev_md5
		FROM ~>srdp_wk_db.wk_new_pids a

		LEFT OUTER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc b
		ON a.pid_md5 = b.pid_md5

		WHERE b.pid_md5 IS NULL
) a

INNER JOIN
(
		SELECT COALESCE(max( dc_instance_id ),0) AS max_dc_instance_id
		FROM ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
) b ;

set mapred.reduce.tasks=-1;


------------------------------
--  IDENTIFY ORPHAN RECORDS --
------------------------------
DROP TABLE if exists ~>srdp_wk_db.orphans_to_process;

CREATE TABLE ~>srdp_wk_db.orphans_to_process (
  enrolledvin_nb string,
  deviceserial_nb bigint,
  orph_md5 string)  -- orphan md5 with vin & device
STORED AS ORC;

set mapred.job.name = "~>job_cd Get orphan records older than 2 years";

INSERT INTO ~>srdp_wk_db.orphans_to_process
SELECT enrolledvin_nb,deviceserial_nb,orph_md5
FROM
(
	SELECT enrolledvin_nb ,deviceserial_nb, default.md5(concat(enrolledvin_nb,cast(deviceserial_nb as string))) as orph_md5
	FROM ~>srdp_cncl_db.orphan_ts

	WHERE regexp_replace(batch,'conv','') <= concat(regexp_replace(cast(date_add(current_date,-730) as string),'-',''),'0000')
	AND deviceserial_nb IS NOT NULL
) a
GROUP BY enrolledvin_nb, deviceserial_nb, orph_md5;

set mapred.reduce.tasks=1;
set mapred.job.name = "~>job_cd Load dc_ods table";

---------------------------
--  ASSIGN DATA CONF IDS --
---------------------------
INSERT INTO ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
SELECT
ROW_NUMBER() OVER() + b.max_dc_instance_id AS dc_instance_id,
0 as sr_pgm_instnc_id,
a.enrolledvin_nb as vhcl_id_nbr,
CAST('1000-01-01 00:00:00.0' as TIMESTAMP) as sr_enrlmnt_dt,
a.deviceserial_nb as dev_id_nbr,
'@' as plcy_ratd_st_cd,
CAST('3500-01-01 00:00:00.0' as TIMESTAMP) as active_end_dt,
CAST('1000-01-01 00:00:00.0' as TIMESTAMP) as active_start_dt,
'@' as pid_md5,
default.md5(concat(a.enrolledvin_nb,cast(a.deviceserial_nb as string))) as vindev_md5
FROM
(
	SELECT
	 orphans.enrolledvin_nb
	,orphans.deviceserial_nb
	,orphans.orph_md5
	FROM ~>srdp_wk_db.orphans_to_process orphans

	LEFT OUTER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc oldorphans
	ON orphans.orph_md5 = oldorphans.vindev_md5

	WHERE oldorphans.vindev_md5 IS NULL
) a

INNER JOIN
(
	SELECT COALESCE(max( dc_instance_id ),0) AS max_dc_instance_id
	FROM ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
) b ;

set mapred.reduce.tasks=-1;

--------------------------
--  Create ODS skinny table for performance --
--------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny;

CREATE TABLE ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny(
  dc_instance_id bigint,
  dev_id_nbr bigint,
  vhcl_id_nbr string
  )ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS ORC;

set mapred.job.name = "~>job_cd Create a skinny table ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny for perfomance";
INSERT INTO ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny
SELECT dc_instance_id, dev_id_nbr, vhcl_id_nbr
FROM ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
GROUP BY
dc_instance_id,
dev_id_nbr,
vhcl_id_nbr;

------------------------
-- BATCHES TO PROCESS --
------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_batch_to_process;

CREATE TABLE ~>srdp_wk_db.dc_batch_to_process(
source_cd string,
batch string)
STORED AS ORC;

set mapred.job.name = "~>job_cd Load dc_batch_to_process table";

INSERT INTO ~>srdp_wk_db.dc_batch_to_process
SELECT source_cd, batch
FROM ~>srdp_cncl_db.tsp_tripsummary
WHERE dataload_dt >= '~>last_run_dt'
GROUP BY source_cd,batch;