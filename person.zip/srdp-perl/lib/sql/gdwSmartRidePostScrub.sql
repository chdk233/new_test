
DROP TABLE IF EXISTS ~>work_db.~>wk_centroid_summary;

create table  ~>work_db.~>wk_centroid_summary(
sr_pgm_instnc_id bigint,
trip_nb string,
centroid_rpm_start  int,
centroid_start_time timestamp,
centroid_end_time timestamp,
min_scrubbed_speed  double,
max_scrubbed_speed double,
min_delta_scrubbed_speed double,
max_delta_scrubbed_speed double,
scrubbed_speed_decreasing_count int,
scrubbed_speed_increasing_count int,
scrubbed_speed_steady_count int,
absolute_speed_change double,
end_scrubbed_speed_bump int,
plausible_indicator int,
plausibility_reason string,
centroid_nb int,
source_cd string,
batch string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/~>wk_centroid_summary';

set mapred.job.name = "~>job_cd Load data and Overwrite ~>work_db.wk_centroid_summary";

load data inpath '~>map_reduce_output_path~>map_reduce_output_file/CentroidTripScrub*' OVERWRITE INTO TABLE ~>work_db.~>wk_centroid_summary;


set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.centroid_Summary from ~>work_db.wk_centroid_summary";

insert overwrite table ~>foundation_db.smartride_centroid_Summary PARTITION(source_cd='~>source_cd', batch) 
select 
sr_pgm_instnc_id, 
trip_nb,
centroid_rpm_start,
centroid_start_time,
centroid_end_time,
min_scrubbed_speed,
max_scrubbed_speed,
min_delta_scrubbed_speed,
max_delta_scrubbed_speed,
scrubbed_speed_decreasing_count,
scrubbed_speed_increasing_count,
scrubbed_speed_steady_count, 
absolute_speed_change,
end_scrubbed_speed_bump,
plausible_indicator,
plausibility_reason,
centroid_nb,
batch
from ~>work_db.~>wk_centroid_summary;


DROP TABLE IF EXISTS ~>work_db.wk_tripdetail_seconds_temp;

create table ~>work_db.wk_tripdetail_seconds_temp( 
  dataload_dt timestamp COMMENT 'Load date', 
  sr_pgm_instnc_id bigint, 
  trip_nb string COMMENT 'Trip number', 
  position_ts timestamp, 
  position_offset_ts timestamp, 
  speed_mph double,  
  distance double, 
  nighttime_driving_ind smallint, 
  eventcounter_fa smallint, 
  eventcounter_hb smallint,
  deviceserial_nb bigint,
  enrolledvin_nb string,
  detectedvin_nb string,
  tripzoneoffset_am string,
  plcy_ratd_st_cd string,
  enginerpm_qt int,
  time_driving_ind smallint,
  time_idle_ind smallint,
  plausible_ind smallint,
  centroid_nb int,
  scrubbed_fields string, 
  loadevent_id bigint,
  latitude_it double,
  longitude_it double,
  source_cd string,
  batch string,
  garbage_flag int COMMENT 'Marked as 1 if trip is garbage',
  eventcounter_br smallint
) row format delimited fields terminated by '\054' 
  STORED AS TEXTFILE 
  LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_tripdetail_seconds_temp';


set mapred.job.name = "~>job_cd Load data and Overwrite ~>work_db.wk_tripdetail_seconds_temp";

load data inpath '~>map_reduce_output_path~>map_reduce_output_file/TripScrub*' OVERWRITE INTO TABLE ~>work_db.wk_tripdetail_seconds_temp;

DROP TABLE IF EXISTS ~>work_db.smartride_wk_device;

CREATE TABLE ~>work_db.smartride_wk_device(
  sr_pgm_instnc_id bigint, 
  vhcl_id_nbr string, 
  device_id bigint, 
  plcy_ratd_st_cd string,
  active_end_dt timestamp,
  active_start_dt timestamp)  
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_device';

set mapred.job.name = "~>job_cd Load data and Overwrite ~>work_db.smartride_wk_device";

INSERT INTO TABLE ~>work_db.smartride_wk_device
  SELECT DISTINCT
                 sr_pgm_instnc_id  
                 ,vhcl_id_nbr
                 ,dev_id_nbr as device_id
                 ,plcy_ratd_st_cd
                 ,active_end_dt
                 ,active_start_dt               
  FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc
  WHERE  date(active_end_dt) = date('3500-01-01');

set mapred.job.name = "~>job_cd Load data and Overwrite ~>work_db.~>wk_tripdetail_seconds"; 

DROP TABLE IF EXISTS ~>work_db.~>wk_tripdetail_seconds;

create table ~>work_db.~>wk_tripdetail_seconds( 
 dataload_dt timestamp COMMENT 'Load date', 
  sr_pgm_instnc_id bigint, 
  trip_nb string COMMENT 'Trip number', 
  position_ts timestamp, 
  position_offset_ts timestamp, 
  speed_mph double,  
  distance double, 
  nighttime_driving_ind smallint, 
  eventcounter_fa smallint, 
  eventcounter_hb smallint,
  deviceserial_nb bigint,
  enrolledvin_nb string,
  detectedvin_nb string,
  tripzoneoffset_am string,
  plcy_ratd_st_cd string,
  enginerpm_qt int,
  time_driving_ind smallint,
  time_idle_ind smallint,
  plausible_ind smallint,
  centroid_nb int,
  scrubbed_fields string, 
  loadevent_id bigint,
  latitude_it double,
  longitude_it double,
  source_cd string,
  batch string,
  garbage_flag int COMMENT 'Marked as 1 if trip is garbage',
  eventcounter_br smallint
) row format delimited fields terminated by '\054' 
  STORED AS TEXTFILE 
  LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/~>wk_tripdetail_seconds';

 Insert into ~>work_db.~>wk_tripdetail_seconds
    select  dst.dataload_dt,
            dev.sr_pgm_instnc_id, 
            dst.trip_nb, 
            dst.position_ts, 
            dst.position_offset_ts, 
            dst.speed_mph,  
            dst.distance, 
            CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.nighttime_driving_ind END as nighttime_driving_ind, 
            CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.eventcounter_fa END as eventcounter_fa, 
            CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.eventcounter_hb END as eventcounter_hb,
            dev.device_id,
            dst.enrolledvin_nb,
            dst.detectedvin_nb,
            dst.tripzoneoffset_am,
            dev.plcy_ratd_st_cd,
            dst.enginerpm_qt,
            dst.time_driving_ind,
            dst.time_idle_ind,
            dst.plausible_ind,
            dst.centroid_nb,
            dst.scrubbed_fields, 
            dst.loadevent_id,
            dst.latitude_it,
            dst.longitude_it,
            dst.source_cd,
            dst.batch,
            dst.garbage_flag,
            CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.eventcounter_br END as eventcounter_br
    	FROM ~>work_db.wk_tripdetail_seconds_temp dst
	    JOIN ~>work_db.smartride_wk_device dev
	    ON 	dst.enrolledvin_nb = dev.vhcl_id_nbr;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.TripDetail_Seconds & Garbage_TripDetail_Seconds from ~>work_db.wk_tripdetail_seconds";

FROM ~>work_db.~>wk_tripdetail_seconds tds
INSERT OVERWRITE TABLE ~>foundation_db.smartride_tripDetail_seconds PARTITION (source_cd='~>source_cd',batch)
SELECT
 dataload_dt
,sr_pgm_instnc_id
,trip_nb
,position_ts
,position_offset_ts
,speed_mph
,speed_mph * 1.609334 as speed_kph
,distance
,distance * 1.609334 as distance_kph
,nighttime_driving_ind
,eventcounter_fa
,eventcounter_hb
,deviceserial_nb
,enrolledvin_nb
,detectedvin_nb
,tripzoneoffset_am
,plcy_ratd_st_cd
,enginerpm_qt
,time_driving_ind
,time_idle_ind
,plausible_ind
,centroid_nb
,scrubbed_fields
,loadevent_id
,latitude_it
,longitude_it
,eventcounter_br
,batch
WHERE tds.garbage_flag=0
INSERT OVERWRITE TABLE ~>foundation_db.smartride_garbage_tripdetail_seconds PARTITION (source_cd='~>source_cd',batch)
SELECT
 dataload_dt
,sr_pgm_instnc_id
,trip_nb
,position_ts
,position_offset_ts
,speed_mph
,speed_mph * 1.609334 as speed_kph
,distance
,distance * 1.609334 as distance_kph
,nighttime_driving_ind
,eventcounter_fa
,eventcounter_hb
,deviceserial_nb
,enrolledvin_nb
,detectedvin_nb
,tripzoneoffset_am
,plcy_ratd_st_cd
,enginerpm_qt
,time_driving_ind
,time_idle_ind
,plausible_ind
,centroid_nb
,scrubbed_fields
,loadevent_id
,latitude_it
,longitude_it
,eventcounter_br
,batch
WHERE tds.garbage_flag=1;