
set mapred.job.name = "~>job_cd Insert Into ~>provide_db.SRE_SUMMARY_ext from ~>work_db.wk_sre_summary_delta";

insert into ~>provide_db.SRE_SUMMARY_ext
Select 
concat(concat(substr('00',1,2-length(cast(pmod(sr_pgm_instnc_id,~>splits)as varchar(2)))),cast(pmod(sr_pgm_instnc_id,16)as varchar(2))), '_', sr_pgm_instnc_id,'_',Period_type,'_',unix_timestamp(periodstart_ts)) as key, 
unix_timestamp(periodend_ts) as pets,
trip_cn,
miles as mls,
night_time_driving_sec_ct as ntd,
fast_acceleration_ct as fac,hard_brake_ct as hbc,
idle_time_sec_ct as it ,
DRIVE_TIME_sec_CT as dt ,
idle_time_ratio as itr,
regexp_replace(trip_seconds_json,',','\;') as tsj 
from ~>work_db.~>wk_sre_summary_delta;