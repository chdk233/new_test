ALTER TABLE ~>staging_db.smartride_ims_cumulative ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_ims_cumulative PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.smartride_ims_tripsummary ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_ims_tripsummary PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.smartride_ims_trippoint ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_ims_trippoint PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;

ALTER TABLE ~>staging_db.smartride_ims_tripevent ADD IF NOT EXISTS partition (loadevent=~>load_event_id,batch='~>batch_id');
ANALYZE TABLE ~>staging_db.smartride_ims_tripevent PARTITION(loadevent=~>load_event_id,batch='~>batch_id') COMPUTE STATISTICS;