DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_trippoint_dups;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_wk_octo_trippoint_dups from ~>staging_db.smartride_octo_trippoint";

CREATE TABLE ~>work_db.smartride_wk_octo_trippoint_dups(
  trip_nb string, 
  position_ts timestamp)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_trippoint_ext_dups';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_trippoint_dups
SELECT
TRIP_NB,
Position_Ts
FROM ~>staging_db.smartride_octo_trippoint
WHERE loadevent in (~>load_event_id_list)
GROUP BY TRIP_NB,Position_Ts HAVING COUNT(*) > 1
;

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tripevent_dups;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_wk_octo_tripevent_dups from ~>staging_db.smartride_octo_tripevent";

CREATE TABLE ~>work_db.smartride_wk_octo_tripevent_dups(
    trip_nb   string,
    event_ts   timestamp,
    eventtype_cd   string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tripevent_dups';
  
INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tripevent_dups
SELECT
TRIP_NB,
Event_Ts,
EventType_Cd
FROM ~>staging_db.smartride_octo_tripevent
WHERE loadevent  in (~>load_event_id_list)
GROUP BY TRIP_NB,Event_Ts,EventType_Cd HAVING COUNT(*) > 1;

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tripsummary_dups;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_wk_octo_tripsummary_dups from ~>staging_db.smartride_octo_tripsummary";

CREATE TABLE ~>work_db.smartride_wk_octo_tripsummary_dups
( trip_nb   string)
STORED AS PARQUET
LOCATION  
'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tripsummary_dups'  ;

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tripsummary_dups
SELECT Trip_Nb
FROM ~>staging_db.smartride_octo_tripsummary
WHERE loadevent in (~>load_event_id_list)
GROUP BY Trip_Nb HAVING COUNT(*) > 1;

DROP TABLE IF EXISTS ~>work_db.smartride_WK_OCTO_Dup_Ctrl;

SET hive.exec.parallel=true;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_WK_OCTO_Dup_Ctrl_Temp from wk_octo_tripsummary_dups, wk_octo_tripevent_dups, wk_octo_trippoint_dups";

CREATE TABLE ~>work_db.smartride_WK_OCTO_Dup_Ctrl(
    trip_nb   string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_dup_ctrl';

INSERT OVERWRITE TABLE ~>work_db.smartride_WK_OCTO_Dup_Ctrl
SELECT DISTINCT TRIP_NB
FROM
(
SELECT DISTINCT Trip_Nb from ~>work_db.smartride_wk_octo_tripsummary_dups
UNION ALL
SELECT DISTINCT Trip_Nb from ~>work_db.smartride_wk_octo_tripevent_dups
UNION ALL
SELECT DISTINCT Trip_Nb from ~>work_db.smartride_wk_octo_trippoint_dups
) DIST_TRIPS;


DROP TABLE IF EXISTS ~>work_db.smartride_WK_OCTO_Missing_Trip_Ctrl;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_WK_OCTO_Missing_Trip_Ctrl_Temp from ~>staging_db.smartride_octo_trippoint & smartride_octo_tripsummary";

CREATE TABLE ~>work_db.smartride_WK_OCTO_Missing_Trip_Ctrl(
    trip_nb   string)
STORED AS PARQUET 
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_missing_trip_ctrl'; 

INSERT OVERWRITE TABLE ~>work_db.smartride_WK_OCTO_Missing_Trip_Ctrl
SELECT ts.Trip_Nb
FROM ~>staging_db.smartride_octo_trippoint tp inner join
~>staging_db.smartride_octo_tripsummary ts
on tp.trip_nb = ts.trip_nb
and ts.loadevent = tp.loadevent
WHERE ts.loadevent in (~>load_event_id_list)
GROUP BY ts.trip_nb
;