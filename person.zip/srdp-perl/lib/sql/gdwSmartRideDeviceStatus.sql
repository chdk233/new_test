DROP TABLE IF EXISTS ~>work_db.wk_devicestatus;

CREATE TABLE ~>work_db.wk_devicestatus(
  sr_pgm_instnc_id bigint,
  deviceserial_id bigint,
  enrolledvin_nb string,
  status int,
  statusstart_ts timestamp,
  statusend_ts timestamp,
  lastactivity_ts timestamp,
  loststatus_flag int)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE
LOCATION 
'hdfs:///user/hive/warehouse/~>work_db/wk_devicestatus';

set mapred.job.name = "~>job_cd Load data and Overwrite ~>work_db.wk_devicestatus";

load data inpath '~>map_reduce_output_path~>map_reduce_output_file/part*' OVERWRITE INTO TABLE ~>work_db.wk_devicestatus;

DROP TABLE IF EXISTS  ~>foundation_db.smartride_devicestatus;

set mapred.job.name = "~>job_cd Create Table ~>foundation_db.smartride_devicestatus from ~>work_db.wk_devicestatus";

create table ~>foundation_db.smartride_devicestatus
(
  sr_pgm_instnc_id bigint, 
  deviceserial_id bigint, 
  enrolledvin_nb string, 
  status int, 
  statusstart_ts timestamp, 
  statusend_ts timestamp, 
  lastactivity_ts timestamp, 
  loststatus_flag int)
STORED AS PARQUET
LOCATION
  's3://~>s3_bucket_name/~>s3_warehouse_prefix/~>foundation_db/devicestatus';

INSERT OVERWRITE table ~>foundation_db.smartride_devicestatus 
select
sr_pgm_instnc_id,
deviceserial_id,
enrolledvin_nb,
status,
statusstart_ts,
statusend_ts,
lastactivity_ts,
loststatus_flag
from ~>work_db.wk_devicestatus
;

set mapred.job.name = "~>job_cd Create Table ~>foundation_db.smartride_device_install_pcnt from ~>foundation_db.smartride_devicestatus";

INSERT OVERWRITE TABLE ~>foundation_db.smartride_device_install_pcnt
SELECT
 sr_pgm_instnc_id
,DEVICESERIAL_ID
,ENROLLEDVIN_NB
,LOSTSTATUS_FLAG
,TOTAL_TIME
,TOTAL_INSTALL_TIME
,(TOTAL_INSTALL_TIME/TOTAL_TIME)*100 AS INSTALL_PERCENTAGE
,TOTAL_UNINSTALL_TIME
,(TOTAL_UNINSTALL_TIME/TOTAL_TIME)*100 AS UNINSTALL_PERCENTAGE
,FIRST_ACTIVITY_DATE
,LAST_ACTIVITY_DATE
,CEIL(TOTAL_TIME/86400) AS TOTAL_DAYS
,CEIL(TOTAL_INSTALL_TIME/86400) AS DAYS_INSTALLED
,CONNECTION_CT
,DISCONNECTION_CT
FROM
(
SELECT
sr_pgm_instnc_id,
DEVICESERIAL_ID,
ENROLLEDVIN_NB,
SUM(LOSTSTATUS_FLAG) LOSTSTATUS_FLAG,

CASE WHEN (MAX(FINAL_LOSTSTATUS_FLG) = 1  AND MAX(MAX_STATUS) <> 0) THEN ((UNIX_TIMESTAMP(MAX(MAX_LASTACTIVITY_TS))- UNIX_TIMESTAMP(MIN(STATUSSTART_TS)))+ 8*(24*60*60))
ELSE (UNIX_TIMESTAMP(MAX(STATUSEND_TS))+1-UNIX_TIMESTAMP(MIN(STATUSSTART_TS)))  END  AS TOTAL_TIME,

(CASE WHEN MAX(FINAL_LOSTSTATUS_FLG) = 1 AND MAX(MAX_STATUS) <> 0 THEN ((UNIX_TIMESTAMP(MAX(MAX_LASTACTIVITY_TS))- UNIX_TIMESTAMP(MIN(STATUSSTART_TS)))+ 8*(24*60*60))
       ELSE (UNIX_TIMESTAMP(MAX(STATUSEND_TS))+1-UNIX_TIMESTAMP(MIN(STATUSSTART_TS)))
END - SUM(UNINSTALL_TIME)) AS TOTAL_INSTALL_TIME,

SUM(UNINSTALL_TIME) AS TOTAL_UNINSTALL_TIME,
MIN(STATUSSTART_TS) FIRST_ACTIVITY_DATE,
MAX(LASTACTIVITY_TS) LAST_ACTIVITY_DATE,
SUM(STATUS) AS CONNECTION_CT,
(COUNT(*) - SUM(STATUS)) AS DISCONNECTION_CT
FROM
(SELECT D.*,
CASE  WHEN STATUS = 1
THEN (UNIX_TIMESTAMP(STATUSEND_TS)+1 - UNIX_TIMESTAMP(STATUSSTART_TS))
  ELSE CAST ( 0 AS BIGINT)
END AS INSTALL_TIME,

CASE WHEN STATUS = 0
THEN
   CASE WHEN LASTACTIVITY_TS = FIRST_VALUE(LASTACTIVITY_TS) OVER  (PARTITION  BY sr_pgm_instnc_id ORDER BY STATUSEND_TS  DESC  ROWS UNBOUNDED PRECEDING) AND  LOSTSTATUS_FLAG = 1 AND STATUS <> 0
   THEN (UNIX_TIMESTAMP(LASTACTIVITY_TS) - UNIX_TIMESTAMP(STATUSSTART_TS))
   ELSE (UNIX_TIMESTAMP(STATUSEND_TS)+1 - UNIX_TIMESTAMP(STATUSSTART_TS))
   END
ELSE CAST ( 0 AS BIGINT)
END AS UNINSTALL_TIME,

UNIX_TIMESTAMP(STATUSEND_TS) UNI_END_TS,
UNIX_TIMESTAMP(STATUSSTART_TS) UNIX_START_TS,
UNIX_TIMESTAMP(LASTACTIVITY_TS) UNIX_LST_ACTVY_TS,
FIRST_VALUE(LOSTSTATUS_FLAG) OVER  (PARTITION  BY sr_pgm_instnc_id ORDER BY STATUSEND_TS  DESC  ROWS UNBOUNDED PRECEDING) AS FINAL_LOSTSTATUS_FLG,
FIRST_VALUE(LASTACTIVITY_TS) OVER  (PARTITION  BY sr_pgm_instnc_id ORDER BY STATUSEND_TS  DESC  ROWS UNBOUNDED PRECEDING) AS MAX_LASTACTIVITY_TS,
FIRST_VALUE(status) OVER  (PARTITION  BY sr_pgm_instnc_id ORDER BY STATUSEND_TS  DESC  ROWS UNBOUNDED PRECEDING) AS MAX_STATUS
FROM ~>foundation_db.smartride_devicestatus D WHERE sr_pgm_instnc_id <> -1
) TEMP
GROUP BY sr_pgm_instnc_id, DEVICESERIAL_ID, ENROLLEDVIN_NB
) TEMP2;