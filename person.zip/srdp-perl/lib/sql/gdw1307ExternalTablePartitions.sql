use ~>experian_raw_hive_db;
alter table bindpolicy_ext add IF NOT EXISTS partition (loadevent=~>load_event_id,sourcefile_dt='~>sourcefile_dt');

set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=100000; 
set hive.exec.max.dynamic.partitions.pernode=100000; 
set hive.exec.parallel=true; 


set mapred.job.name = "~>job_cd Insert Overwrite experian_canonical_hive_db.BindPolicy from BindPolicy_ext";

from ~>experian_raw_hive_db.BindPolicy_ext
INSERT OVERWRITE TABLE  ~>experian_canonical_hive_db.BindPolicy
PARTITION (sourcefile_dt)
select partnernotification_id
,vin_nb
,policy_nb
,SourceFile_Dt
where loadevent=~>load_event_id;


