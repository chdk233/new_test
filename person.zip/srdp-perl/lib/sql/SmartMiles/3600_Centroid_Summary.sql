SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.exec.max.dynamic.partitions=100000;
SET hive.exec.max.dynamic.partitions.pernode=100000;

SET mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartmiles_Centroid_Summary from ~>work_db.smartmiles_Wk_Centroid_Summary";

INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_Centroid_Summary PARTITION(Batch_Nb)
SELECT
Enrolled_vin_nb,
Trip_summary_id,
Centroid_start_ts,
Centroid_end_ts,
Centroid_rpm_rt,
Min_scrubbed_speed_rt,
Max_scrubbed_speed_rt,
Min_delta_scrubbed_speed_rt,
Max_delta_scrubbed_speed_rt,
Absolute_speed_change_rt,
Scrubbed_speed_decreasing_cn,
Scrubbed_speed_increasing_cn,
Scrubbed_speed_steady_cn,
End_scrubbed_speed_bump_in,
Plausible_in,
Plausibile_reason_ds,
Centroid_nb,
Source_cd,
'~>load_event_id',
Batch_nb
FROM ~>work_db.smartmiles_WK_Centroid_Summary;