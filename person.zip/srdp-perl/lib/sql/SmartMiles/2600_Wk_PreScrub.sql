SET mapred.job.name = "~>job_cd Create & Load PreScrub table ~>work_db.smartmiles_WK_PreScrub FROM ~>work_db.smartmiles_WK_Trip_Point & ~>work_db.smartmiles_WK_Trip_Summary";


DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_prescrub;

CREATE TABLE ~>work_db.smartmiles_wk_prescrub(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
device_id varchar(128), 
position_ts timestamp, 
time_zone_offset_nb string, 
speed_kph_rt decimal(8,5), 
engine_rpm_rt decimal(8,3), 
latitude_nb decimal(24,16), 
longitude_nb decimal(24,16), 
source_cd string, 
batch_nb string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ','  
STORED AS TEXTFILE
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_prescrub';

INSERT INTO TABLE ~>work_db.smartmiles_WK_PreScrub
SELECT
ts.Enrolled_Vin_Nb
,ts.Trip_Summary_Id
,ts.Device_Id
,tp.Position_Ts
,ts.Time_Zone_Offset_Nb
,tp.Speed_Kph_Rt
,tp.Engine_Rpm_Rt
,tp.Latitude_Nb
,tp.Longitude_Nb
,tp.Source_Cd
,ts.Batch_Nb
FROM ~>work_db.smartmiles_WK_Trip_Summary ts

INNER JOIN ~>work_db.smartmiles_Wk_Trip_Point tp
ON ts.Batch_Nb=tp.Batch_Nb AND ts.Trip_Summary_Id=tp.Trip_Summary_Id;