SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.exec.max.dynamic.partitions=100000;
SET hive.exec.max.dynamic.partitions.pernode=100000;

SET mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartmiles_Trip_Detail_Hourly from ~>work_db.smartmiles_WK_Trip_Detail_Hourly";

INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_Trip_Detail_Hourly PARTITION (Batch_Nb='~>batch_nb')
SELECT
Enrolled_Vin_Nb
,Trip_Summary_Id
,Device_Id
,Period_Start_Ts
,Period_End_Ts
,Period_Start_Hour_Ts
,Period_End_Hour_Ts
,Mile_Cn
,Adjusted_Mile_Cn
,Plausible_Mile_Cn
,Kilometer_Cn
,Adjusted_Kilometer_Cn
,Plausible_Kilometer_Cn
,Fast_Acceleration_Cn
,Hard_Brake_Cn
,Driving_Second_Cn
,Idle_Second_Cn
,Stop_Second_Cn
,Night_Time_Driving_Second_Cn
,Plausible_Second_Cn
,Plausible_Drive_Second_Cn
,Plausible_Idle_Second_Cn
,Speed_Mph_Json_Tt
,Fast_Acceleration_Json_Tt
,Hard_Brake_Json_Tt
,Stop_Second_Json_Tt
,Latitude_Longitude_Json_Tt
,Source_Cd
,'~>load_event_id'
FROM
~>work_db.smartmiles_WK_Trip_Detail_Hourly;



