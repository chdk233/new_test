SET mapred.job.name = "~>job_cd Truncate and Load ~>work_db.smartmiles_WK_Centroid_Summary";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_centroid_summary;

CREATE TABLE ~>work_db.smartmiles_wk_centroid_summary(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
centroid_start_ts timestamp, 
centroid_end_ts timestamp, 
centroid_rpm_rt decimal(8,5), 
min_scrubbed_speed_rt decimal(8,5), 
max_scrubbed_speed_rt decimal(8,5), 
min_delta_scrubbed_speed_rt decimal(8,5), 
max_delta_scrubbed_speed_rt decimal(8,5), 
absolute_speed_change_rt decimal(8,5), 
scrubbed_speed_decreasing_cn int, 
scrubbed_speed_increasing_cn int, 
scrubbed_speed_steady_cn int, 
end_scrubbed_speed_bump_in int, 
plausible_in int, 
plausibile_reason_ds string, 
centroid_nb bigint, 
source_cd string, 
batch_nb string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ','  
STORED AS TEXTFILE
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_centroid_summary';

LOAD DATA INPATH '~>map_reduce_output_path/TEMP/SmartMiles/PostScrubbing/CentroidTripScrub*' OVERWRITE INTO TABLE ~>work_db.smartmiles_WK_Centroid_Summary;