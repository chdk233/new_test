
SET mapred.job.name = "~>job_cd Insert  into ~>foundation_db.smartride_Sre_Summary_Ext from ~>work_db.smartmiles_WK_Program_Summary";

SET hbase.zookeeper.quorum=~>zookeeper_quorum;

INSERT INTO ~>provide_db.smartride_Sre_Summary_Ext
SELECT
CASE WHEN source_cd in ('FMC','TIMS') THEN concat(concat(substr('00',1,2-length(cast(pmod(sr_pgm_instnc_id,~>splits)as varchar(2)))),cast(pmod(sr_pgm_instnc_id,~>splits)as varchar(2))), '_', sr_pgm_instnc_id,'_',Period_Cd,'_',unix_timestamp(period_start_ts) + (case
when period_start_ts between date_format( cast(extract(year from period_start_ts) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(period_start_ts as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(period_start_ts as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from period_start_ts) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(period_start_ts as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(period_start_ts as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600)
                                      ELSE concat(Enrolled_Vin_Nb, '_',Period_Cd,'_',unix_timestamp(Period_Start_Ts) + (case
when Period_Start_Ts between date_format( cast(extract(year from Period_Start_Ts) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(Period_Start_Ts as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(Period_Start_Ts as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from Period_Start_Ts) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(Period_Start_Ts as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(Period_Start_Ts as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600) END AS key,
unix_timestamp(Period_End_Ts) + (case
when Period_End_Ts between date_format( cast(extract(year from Period_End_Ts) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(Period_End_Ts as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(Period_End_Ts as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from Period_End_Ts) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(Period_End_Ts as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(Period_End_Ts as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600,
Trip_Cn,
Mile_Cn,
Night_Time_Driving_Second_Cn,
Fast_Acceleration_Cn,
Hard_Brake_Cn,
Idle_Second_Cn,
Driving_Second_Cn,
Idle_Second_Pc,
regexp_replace(Trip_Report_Json_tt,',','\;')
FROM ~>work_db.smartmiles_Wk_Program_Summary;