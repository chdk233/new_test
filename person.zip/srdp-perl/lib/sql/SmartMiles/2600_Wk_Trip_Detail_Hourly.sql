SET mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.smartmiles_Wk_Trip_Detail_Hourly from ~>work_db.smartmiles_Wk_Trip_Detail_Second";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_trip_detail_hourly;

CREATE TABLE ~>work_db.smartmiles_wk_trip_detail_hourly(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
device_id varchar(128), 
period_start_ts timestamp, 
period_end_ts timestamp, 
period_start_hour_ts timestamp, 
period_end_hour_ts timestamp, 
mile_cn decimal(8,5), 
adjusted_mile_cn decimal(8,5), 
plausible_mile_cn decimal(8,5), 
kilometer_cn decimal(8,5), 
adjusted_kilometer_cn decimal(8,5), 
plausible_kilometer_cn decimal(8,5), 
fast_acceleration_cn int, 
hard_brake_cn int, 
driving_second_cn int, 
idle_second_cn int, 
stop_second_cn int, 
night_time_driving_second_cn int, 
plausible_second_cn int, 
plausible_drive_second_cn int, 
plausible_idle_second_cn int, 
speed_mph_json_tt array<double>, 
fast_acceleration_json_tt string, 
hard_brake_json_tt string, 
stop_second_json_tt string, 
latitude_longitude_json_tt string, 
source_cd string, 
batch_nb string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_trip_detail_hourly';

INSERT INTO TABLE ~>work_db.smartmiles_Wk_Trip_Detail_Hourly
SELECT
Enrolled_Vin_Nb
,Trip_Summary_Id
,Device_Id
,min(Position_Offset_Ts) as Period_Start_Ts
,max(Position_Offset_Ts) as Period_End_Ts
,cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp) as Period_Start_Hour_Ts
,cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'59:59') as timestamp) as Period_End_Hour_Ts
,sum(Mile_Cn) as Mile_Cn
,(case from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'E')
when ('Sun') Then ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT )
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END )
when ('Sat') Then  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT )
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END )
Else  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT )
                    WHEN 0 THEN 1.6
                    WHEN 1 THEN 1.6
                    WHEN 2 THEN 1.6
                    WHEN 3 THEN 1.6
                    WHEN 4 THEN 1.6
                    WHEN 5 THEN 1.1
                    WHEN 6 THEN 1.1
                    WHEN 7 THEN 1.1
                    WHEN 8 THEN 1.1
                    WHEN 9 THEN 1.2
                    WHEN 10 THEN 1.2
                    WHEN 11 THEN 1.2
                    WHEN 12 THEN 1.2
                    WHEN 13 THEN 1.2
                    WHEN 14 THEN 1.2
                    WHEN 15 THEN 1.2
                    WHEN 16 THEN 1.4
                    WHEN 17 THEN 1.4
                    WHEN 18 THEN 1.4
                    ELSE 1.3
                    END
       )
end) * sum((IF(Plausible_Second_Cn = 1, Mile_Cn,0))) as Adjusted_Mile_Cn
,SUM(IF( Plausible_Second_Cn = 1,Mile_Cn,0)) as Plausible_Mile_Cn
,sum(Mile_Cn * 1.609334) as Kilometer_Cn
,(case from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'E')
when ('Sun') Then ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT )
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END )
when ('Sat') Then  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT )
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END )
Else  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(Position_Offset_Ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT )
                    WHEN 0 THEN 1.6
                    WHEN 1 THEN 1.6
                    WHEN 2 THEN 1.6
                    WHEN 3 THEN 1.6
                    WHEN 4 THEN 1.6
                    WHEN 5 THEN 1.1
                    WHEN 6 THEN 1.1
                    WHEN 7 THEN 1.1
                    WHEN 8 THEN 1.1
                    WHEN 9 THEN 1.2
                    WHEN 10 THEN 1.2
                    WHEN 11 THEN 1.2
                    WHEN 12 THEN 1.2
                    WHEN 13 THEN 1.2
                    WHEN 14 THEN 1.2
                    WHEN 15 THEN 1.2
                    WHEN 16 THEN 1.4
                    WHEN 17 THEN 1.4
                    WHEN 18 THEN 1.4
                    ELSE 1.3
                    END
       )
end) * sum((IF(Plausible_Second_Cn = 1, Mile_Cn,0)) * 1.609334 ) as Adjusted_Kilometer_Cn
,SUM(IF(Plausible_Second_Cn = 1,(Mile_Cn * 1.609334),0)) as Plausible_Kilometer_Cn
,sum(Fast_Acceleration_Cn) as Fast_Acceleration_Cn
,sum(Hard_Brake_Cn) as Hard_Brake_Cn
,sum(Driving_Second_Cn) as Driving_Second_Cn
,sum(IF((Driving_Second_Cn = 1 and Idle_Second_Cn = 1 ), 1,0 )) as Idle_Second_Cn
,sum(Stop_Second_Cn) as Stop_Second_Cn
,sum(Night_Time_Driving_Second_Cn) as Night_Time_Driving_Second_Cn
,sum(Plausible_Second_Cn) as Plausible_Second_Cn
,SUM(IF(Plausible_Second_Cn = 1,Driving_Second_Cn,0)) as Plausible_Drive_Second_Cn
,SUM(IF(Plausible_Second_Cn = 1,IF((Driving_Second_Cn = 1 and Idle_Second_Cn = 1 ), 1,0 ),0)) as Plausible_Idle_Second_Cn
,default.sre_collect_list(cast(Speed_Mph_Rt as double)) as Speed_Mph_Json_Tt
,default.sre_index_list_v2(Fast_Acceleration_Cn, 1) as Fast_Acceleration_Json_Tt
,default.sre_index_list_v2(Hard_Brake_Cn, 1) as Hard_Brake_Json_Tt
,default.sre_index_list_v2(Stop_Second_Cn, 1) as Stop_Second_Json_Tt
,case when (concat_ws(',',collect_list(coalesce(concat('[',Latitude_Nb,',',Longitude_Nb,']'),'null') ) ) ) like '%[%'
then (concat_ws(',',collect_list(coalesce(concat('[',Latitude_Nb,',',Longitude_Nb,']'),'null') ) ) )
else '' end as Latitude_Longitude_Json_Tt
,Source_Cd
,Batch_Nb
from ~>work_db.smartmiles_Wk_Trip_Detail_Second
WHERE garbage_flag_in=0
group by Enrolled_Vin_Nb,Trip_Summary_Id,Source_Cd,date(Position_Offset_Ts),hour(Position_Offset_Ts),Batch_Nb,Device_Id;