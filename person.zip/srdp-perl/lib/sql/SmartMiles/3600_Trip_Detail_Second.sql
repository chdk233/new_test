set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.dynamic.partitions.pernode=100000;

SET mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartmiles_trip_detail_second from ~>work_db.smartmiles_wk_trip_detail_second";

INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_Trip_Detail_Second PARTITION (Batch_Nb='~>batch_nb')
SELECT
 enrolled_vin_nb
,trip_summary_id
,device_id
,position_ts
,position_offset_ts
,time_zone_offset_nb
,speed_mph_rt
,(speed_mph_rt * 1.609334) AS speed_kph_rt
,engine_rpm_rt
,mile_cn
,(mile_cn * 1.609334) AS kilometer_cn
,fast_acceleration_cn
,hard_brake_cn
,driving_second_cn
,idle_second_cn
,stop_second_cn
,night_time_driving_second_cn
,plausible_second_cn
,centroid_nb
,scrubbed_field_nb
,latitude_nb
,longitude_nb
,source_cd
,'~>load_event_id'
FROM ~>work_db.smartmiles_WK_Trip_detail_Second
WHERE garbage_flag_in=0;


SET mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartmiles_Garbage_Trip_Detail_Second from ~>work_db.smartmiles_WK_Trip_detail_Second";

INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_Garbage_Trip_Detail_Second PARTITION (Batch_Nb='~>batch_nb')
SELECT
 enrolled_vin_nb
,trip_summary_id
,device_id
,position_ts
,position_offset_ts
,time_zone_offset_nb
,speed_mph_rt
,(speed_mph_rt * 1.609334) AS speed_kph_rt
,engine_rpm_rt
,mile_cn
,(mile_cn * 1.609334) AS kilometer_cn
,fast_acceleration_cn
,hard_brake_cn
,driving_second_cn
,idle_second_cn
,stop_second_cn
,night_time_driving_second_cn
,plausible_second_cn
,centroid_nb
,scrubbed_field_nb
,latitude_nb
,longitude_nb
,source_cd
,'~>load_event_id'
FROM ~>work_db.smartmiles_WK_Trip_detail_Second
WHERE garbage_flag_in=1;