INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_Program_Summary
SELECT
  enrolled_vin_nb
  ,sr_pgm_instnc_id
  ,DATA_CLCTN_ID
  ,period_cd
  ,period_start_ts
  ,period_end_ts
  ,trip_cn
  ,mile_cn
  ,kilometer_cn
  ,fast_acceleration_cn
  ,hard_brake_cn
  ,driving_second_cn
  ,idle_second_cn
  ,night_time_driving_second_cn
  ,idle_second_pc
  ,trip_report_json_tt
  ,source_cd
FROM ~>work_db.smartmiles_Wk_Program_Summary
WHERE period_cd in ('w','d','tp')
and period_start_ts >= '~>date_filter_2_wks_from_sun';