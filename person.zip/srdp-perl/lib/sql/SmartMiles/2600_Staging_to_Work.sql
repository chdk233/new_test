set mapred.job.name = "~>job_cd Truncate and Load ~>work_db.smartmiles_Wk_Trip_Summary from ~>staging_db.smartmiles_Trip_Summary";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_trip_summary;
 
CREATE TABLE ~>work_db.smartmiles_wk_trip_summary(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
device_id varchar(128), 
time_zone_offset_nb string, 
batch_nb string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_trip_summary';

INSERT INTO TABLE ~>work_db.smartmiles_WK_Trip_Summary
SELECT
case when source_cd in ('FMC','TIMS') then CAST(Vehicle.detected_vin_nb AS VARCHAR(128)) else CAST(Vehicle.Enrolled_Vin_Nb AS VARCHAR(128)) end AS Enrolled_Vin_Nb,
CAST(Trip_Summary_Id AS VARCHAR(128)) AS Trip_Summary_Id,
case when source_cd in ('FMC','TIMS') then CAST(crc32(Vehicle.detected_vin_nb) AS VARCHAR(128)) else CAST(Device.Device_Id AS VARCHAR(128)) end AS Device_Id,
Time_Zone_Offset_Nb,
Batch_Nb
FROM ~>staging_db.smartmiles_Trip_Summary
WHERE Batch_Nb = '~>batch_nb';

SET mapred.job.name = "~>job_cd Truncate and Load ~>work_db.smartmiles_WK_Trip_Point from ~>staging_db.smartmiles_Trip_Point";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_trip_point;
 
CREATE TABLE ~>work_db.smartmiles_wk_trip_point(
trip_summary_id varchar(128), 
engine_rpm_rt decimal(8,3), 
position_ts timestamp, 
speed_kph_rt decimal(8,5), 
latitude_nb decimal(24,16), 
longitude_nb decimal(24,16), 
source_cd string, 
batch_nb string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_trip_point';

INSERT INTO TABLE ~>work_db.smartmiles_WK_Trip_Point
SELECT CAST(Trip_Summary_Id AS VARCHAR(128)) AS Trip_Summary_Id,
CAST(Telemetrypoints_Ts.Engine_Rpm_Rt AS DECIMAL(8,3)) AS Engine_Rpm_Rt,
to_utc_timestamp(From_Unixtime((Unix_Timestamp(Telemetrypoints_TS.Position_Ts, "yyyy-MM-dd'T'HH:mm:ss" ) 
-  
   (case when Telemetrypoints_TS.Position_Ts 
   		      between 
   		      date_format( cast(extract(year from Telemetrypoints_TS.Position_Ts) as string) || '-03-' || 
                   cast(  8 + case when extract(dayofweek from to_date(cast(extract(year from Telemetrypoints_TS.Position_Ts ) as string) || '-03-01')) = 1 then 0 
                              else  8 - extract(dayofweek from to_date(cast(extract(year from Telemetrypoints_TS.Position_Ts ) as string) || '-03-01')) 
                              end as string
                       ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                   ) 
              and 
              date_format( cast(extract(year from Telemetrypoints_TS.Position_Ts) as string) || '-11-' || 
                   cast(  1 + case when extract(dayofweek from to_date(cast(extract(year from Telemetrypoints_TS.Position_Ts ) as string) || '-11-01')) = 1 then 0 
                              else  8 - extract(dayofweek from to_date(cast(extract(year from Telemetrypoints_TS.Position_Ts ) as string) || '-11-01')) 
                              end as string
                        ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                   ) 
     then 4  else 5 end
   )  

*3600)), "America/New_York")      AS Position_Ts,
CAST(Telemetrypoints_Ts.Speed_Rt AS DECIMAL(24,16)) AS Speed_Kph_Rt,
CAST(Telemetrypoints_Ts.Latitude_Nb AS DECIMAL(24,16)) AS Latitude_Nb,
CAST(Telemetrypoints_Ts.Longitude_Nb AS DECIMAL(24,16)) AS Longitude_Nb,
Source_cd,
Batch_Nb
FROM ~>staging_db.smartmiles_Trip_Point
LATERAL VIEW EXPLODE(Telemetrypoints) EXPLODED_TABLE AS Telemetrypoints_Ts
WHERE Batch_Nb = '~>batch_nb';

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_trip_event;

CREATE TABLE ~>work_db.smartmiles_wk_trip_event(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
average_speed_rt decimal(8,5), 
trip_event_type_ds varchar(500), 
trip_event_ts timestamp, 
driving_seconds_cn bigint, 
acceleration_rt decimal(8,5), 
speed_rt decimal(8,5), 
latitude_nb decimal(24,16), 
longitude_nb decimal(24,16), 
heading_degree_nb int, 
source_cd string, 
batch_nb string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_trip_event'
;

INSERT INTO TABLE ~>work_db.smartmiles_WK_Trip_Event
SELECT
case when source_cd in ('FMC','TIMS') then CAST(Vehicle.detected_vin_nb AS VARCHAR(128)) else CAST(Vehicle.Enrolled_Vin_Nb AS VARCHAR(128)) end AS Enrolled_Vin_Nb,
CAST(Trip_Summary_Id AS VARCHAR(128)) AS Trip_Summary_Id,
CAST(TelemetryEvents_Te.average_speed_rt AS DECIMAL(8,5)) AS Average_Speed_Rt,
CAST(TelemetryEvents_Te.Event_Type_Ds AS VARCHAR(500)) AS Event_Type_Ds,
to_utc_timestamp(From_Unixtime(Unix_Timestamp(TelemetryEvents_Te.Event_Ts, "yyyy-MM-dd'T'HH:mm:ss.SSSX")),"America/New_York") AS Position_Ts,
CAST(TelemetryEvents_Te.Driving_Second_Cn AS BIGINT) AS Driving_Second_Cn,
CAST(TelemetryEvents_Te.Acceleration_Rt AS DECIMAL(8,5)) AS Acceleration_Rt,
CAST(TelemetryEvents_Te.Speed_Rt AS DECIMAL(8,5)) AS Speed_Rt,
CAST(TelemetryEvents_Te.Latitude_Nb AS DECIMAL(24,16)) AS Latitude_Nb,
CAST(TelemetryEvents_Te.Longitude_Nb AS DECIMAL(24,16)) AS Longitude_Nb,
CAST(TelemetryEvents_Te.Heading_Degree_Nb AS INT) AS Heading_Degree_Nb,
Source_cd,
Batch_Nb
FROM ~>staging_db.smartmiles_Trip_Event
LATERAL VIEW EXPLODE(telemetryevents) EXPLODED_TABLE AS TelemetryEvents_Te
WHERE Batch_Nb = '~>batch_nb';
