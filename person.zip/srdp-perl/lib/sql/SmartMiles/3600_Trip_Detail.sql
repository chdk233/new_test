SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET  hive.exec.max.dynamic.partitions=100000;
SET  hive.exec.max.dynamic.partitions.pernode=100000;


SET mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartmiles_TripDetail from ~>work_db.smartmiles_WK_TripDetail";


INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_Trip_Detail
PARTITION(Batch_Nb='~>batch_nb')
SELECT
enrolled_vin_nb
,trip_summary_id
,period_start_ts
,period_end_ts
,mile_cn
,adjusted_mile_cn
,plausible_mile_cn
,kilometer_cn
,fast_acceleration_cn
,hard_brake_cn
,driving_second_cn
,idle_second_cn
,stop_second_cn
,night_time_driving_second_cn
,plausible_drive_second_cn
,plausible_idle_second_cn
,idle_second_pc
,trip_report_json_tt
,source_cd
,'~>load_event_id'
FROM ~>work_db.smartmiles_WK_Trip_Detail;