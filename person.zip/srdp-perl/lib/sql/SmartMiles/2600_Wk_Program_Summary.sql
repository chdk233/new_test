
set hive.support.concurrency=false;
set hive.lock.manager= ;
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.map.aggr=true;
SET hive.exec.parallel=true;
set hive.exec.compress.intermediate=true;
set mapred.map.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set hive.exec.reducers.bytes.per.reducer=128000000;
set hive.merge.tezfiles=true;
set hive.merge.smallfiles.avgsize=128000000;
set hive.merge.size.per.task=128000000;
set tez.grouping.min-size=34000000;
set tez.grouping.max-size=128000000;
set hive.tez.container.size=20000;


DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_program_summary;

CREATE TABLE ~>work_db.smartmiles_wk_program_summary(
enrolled_vin_nb varchar(128), 
sr_pgm_instnc_id bigint, 
DATA_CLCTN_ID string,
period_cd string, 
period_start_ts timestamp, 
period_end_ts timestamp, 
trip_cn int, 
mile_cn decimal(24,16), 
kilometer_cn decimal(24,16), 
fast_acceleration_cn int, 
hard_brake_cn int, 
driving_second_cn int, 
idle_second_cn int, 
night_time_driving_second_cn int, 
idle_second_pc double, 
trip_report_json_tt string, 
source_cd string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_program_summary';

SET mapred.job.name = "~>job_cd Insert into ~>work_db.smartmiles_Wk_Program_Summary FROM ~>work_db.smartmiles_WK_Trip_Detail";

INSERT INTO ~>work_db.smartmiles_Wk_Program_Summary
SELECT
td.enrolled_vin_nb
,ods.sr_pgm_instnc_id       -- see how this is populated, make sure there's no -1s
,null as DATA_CLCTN_ID    --- new, test / or ''
,'tp' AS period_cd
,td.period_start_ts
,td.period_end_ts
,1 as trip_cn
,td.mile_cn
,td.kilometer_cn
,td.fast_acceleration_cn
,td.hard_brake_cn
,CASE WHEN ods.plcy_ratd_st_cd = 'CA' THEN '0' ELSE td.driving_second_cn END AS driving_second_cn
,CASE WHEN ods.plcy_ratd_st_cd = 'CA' THEN '0' ELSE td.idle_second_cn END AS idle_second_cn
,td.night_time_driving_second_cn
,CASE WHEN ods.plcy_ratd_st_cd = 'CA' THEN '0' ELSE td.idle_second_pc END AS idle_second_pc
,td.trip_report_json_tt
,td.source_cd
FROM ~>foundation_db.smartmiles_Trip_Detail td

INNER JOIN
(
	SELECT Enrolled_Vin_Nb
	FROM  ~>work_db.smartmiles_WK_Trip_Detail
	GROUP BY Enrolled_Vin_Nb
) wtd
ON td.Enrolled_Vin_Nb = wtd.Enrolled_Vin_Nb

INNER JOIN ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc ods
on td.enrolled_vin_nb = ods.vhcl_id_nbr 
and td.period_start_ts >= ods.active_start_dt 
AND td.period_start_ts < ods.active_end_dt
AND date(active_end_dt) = date('3500-01-01')
--- new, test
AND td.source_cd in ('FMC', 'TIMS')
;



INSERT INTO ~>work_db.smartmiles_Wk_Program_Summary
SELECT
td.enrolled_vin_nb
,null as sr_pgm_instnc_id    --- new, test / or ''
,pe.DATA_CLCTN_ID
,'tp' AS period_cd
,td.period_start_ts
,td.period_end_ts
,1 as trip_cn
,td.mile_cn
,td.kilometer_cn
,td.fast_acceleration_cn
,td.hard_brake_cn
,CASE WHEN pe.PLCY_ST_CD = 'CA' THEN '0' ELSE td.driving_second_cn END AS driving_second_cn
,CASE WHEN pe.PLCY_ST_CD = 'CA' THEN '0' ELSE td.idle_second_cn END AS idle_second_cn
,td.night_time_driving_second_cn
,CASE WHEN pe.PLCY_ST_CD = 'CA' THEN '0' ELSE td.idle_second_pc END AS idle_second_pc
,td.trip_report_json_tt
,td.source_cd
FROM ~>foundation_db.smartmiles_Trip_Detail td

INNER JOIN
(
	SELECT Enrolled_Vin_Nb
	FROM  ~>work_db.smartmiles_WK_Trip_Detail
	GROUP BY Enrolled_Vin_Nb
) wtd
ON td.Enrolled_Vin_Nb = wtd.Enrolled_Vin_Nb
INNER JOIN
(select distinct(p.VIN_NB), p.PLCY_ST_CD, p.EVNT_SYS_TS, p.PRGRM_TERM_BEG_DT, p.PRGRM_TERM_END_DT, p.PRGRM_STTS_CD, p.DATA_CLCTN_STTS, p.DATA_CLCTN_ID
        from ~>staging_db.program_enrollment p
	inner join
       (select max(EVNT_SYS_TS) as max_time, VIN_NB 
		from ~>staging_db.program_enrollment pe
		where PRGRM_STTS_CD = 'Active' and DATA_CLCTN_STTS = 'Active'
		GROUP BY VIN_NB
		) p2
	on p.VIN_NB = p2.VIN_NB
	and p.EVNT_SYS_TS = p2.max_time) pe
on td.enrolled_vin_nb = pe.VIN_NB
AND date(td.period_start_ts) >= date(pe.PRGRM_TERM_BEG_DT)
AND date(td.period_start_ts) < date(pe.PRGRM_TERM_END_DT)
AND pe.PRGRM_STTS_CD = 'Active'
AND pe.DATA_CLCTN_STTS = 'Active'
AND td.source_cd in ('IMS')
;

SET mapred.job.name = "~>job_cd Insert overwrite ~>work_db.smartmiles_Wk_Program_Summary from smartmiles_Wk_Program_Summary - period type aggregations";

INSERT INTO ~>work_db.smartmiles_Wk_Program_Summary
SELECT
enrolled_vin_nb
,sr_pgm_instnc_id
,DATA_CLCTN_ID
,'d' AS period_cd
,CAST(CONCAT(SUBSTR(period_start_ts,0,10),' 00:00:00') AS TIMESTAMP) AS period_start_ts
,CAST(CONCAT(SUBSTR(period_start_ts,0,10),' 23:59:59') AS TIMESTAMP) AS period_end_ts
,SUM(trip_cn) AS trip_cn
,SUM(mile_cn) AS mile_cn
,SUM(kilometer_cn) AS kilometer_cn
,SUM(fast_acceleration_cn)AS fast_acceleration_cn
,SUM(hard_brake_cn)  AS hard_brake_cn
,SUM(driving_second_cn) AS driving_second_cn
,SUM(idle_second_cn) AS idle_second_cn
,SUM(night_time_driving_second_cn) AS night_time_driving_second_cn
,IF(SUM(driving_second_cn) = 0,0,SUM(idle_second_cn)/SUM(driving_second_cn)) AS idle_second_pc
,' ' AS trip_report_json_tt
,source_cd
FROM ~>work_db.smartmiles_Wk_Program_Summary
GROUP BY CAST(CONCAT(SUBSTR(period_start_ts,0,10),' 00:00:00') AS TIMESTAMP)
		,CAST(CONCAT(SUBSTR(period_start_ts,0,10),' 23:59:59') AS TIMESTAMP)
		,period_cd
		,enrolled_vin_nb
        ,sr_pgm_instnc_id,DATA_CLCTN_ID
		,source_cd

UNION ALL

SELECT
enrolled_vin_nb
,sr_pgm_instnc_id
,DATA_CLCTN_ID
,'w' as period_cd
,CASE CAST(date_format(period_start_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(substr(period_start_ts,0,10),' 00:00:00') AS TIMESTAMP)
ELSE CAST(CONCAT(date_sub(substr(period_start_ts,0,10),CAST(date_format(period_start_ts,'u') as int)),' 00:00:00') AS TIMESTAMP) END AS period_start_ts_Week
,CASE CAST(date_format(period_start_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(date_add(substr(period_start_ts,0,10),6),' 23:59:59.0') AS TIMESTAMP)
ELSE CAST(CONCAT(date_add(substr(period_start_ts,0,10),6-CAST(date_format(period_start_ts,'u') as int)),' 23:59:59') AS TIMESTAMP) END AS period_end_ts_Week
,SUM(trip_cn) AS trip_cn
,SUM(mile_cn) AS mile_cn
,SUM(kilometer_cn) AS kilometer_cn
,SUM(fast_acceleration_cn)AS fast_acceleration_cn
,SUM(hard_brake_cn)  AS hard_brake_cn
,SUM(driving_second_cn) AS driving_second_cn
,SUM(idle_second_cn) AS idle_second_cn
,SUM(night_time_driving_second_cn) AS night_time_driving_second_cn
,IF(SUM(driving_second_cn) = 0,0,SUM(idle_second_cn)/SUM(driving_second_cn)) AS idle_second_pc
,' ' AS trip_report_json_tt
,source_cd
FROM ~>work_db.smartmiles_Wk_Program_Summary
GROUP BY CASE CAST(date_format(period_start_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(substr(period_start_ts,0,10),' 00:00:00') AS TIMESTAMP)
ELSE CAST(CONCAT(date_sub(substr(period_start_ts,0,10),CAST(date_format(period_start_ts,'u') as int)),' 00:00:00') AS TIMESTAMP)  END
,CASE CAST(date_format(period_start_ts,'u') as int) WHEN 7 THEN CAST(CONCAT(date_add(substr(period_start_ts,0,10),6),' 23:59:59.0') AS TIMESTAMP)
ELSE CAST(CONCAT(date_add(substr(period_start_ts,0,10),6-CAST(date_format(period_start_ts,'u') as int)),' 23:59:59') AS TIMESTAMP) END
,period_cd
,enrolled_vin_nb
,sr_pgm_instnc_id,DATA_CLCTN_ID
,source_cd

UNION ALL

SELECT
enrolled_vin_nb
,sr_pgm_instnc_id
,DATA_CLCTN_ID
,'m' AS  period_cd
,CAST(CONCAT(SUBSTR(period_start_ts,0,7),'-01 00:00:00') AS TIMESTAMP) AS period_start_ts
,CAST(CONCAT(LAST_DAY(period_start_ts),' 23:59:59') AS TIMESTAMP) AS period_end_ts
,SUM(trip_cn) AS trip_cn
,SUM(mile_cn) AS mile_cn
,SUM(kilometer_cn) AS kilometer_cn
,SUM(fast_acceleration_cn)AS fast_acceleration_cn
,SUM(hard_brake_cn)  AS hard_brake_cn
,SUM(driving_second_cn) AS driving_second_cn
,SUM(idle_second_cn) AS idle_second_cn
,SUM(night_time_driving_second_cn) AS night_time_driving_second_cn
,IF(SUM(driving_second_cn) = 0,0,SUM(idle_second_cn)/SUM(driving_second_cn)) AS  idle_second_pc
,' '  AS trip_report_json_tt
,source_cd
FROM ~>work_db.smartmiles_Wk_Program_Summary
GROUP BY CAST(CONCAT(SUBSTR(period_start_ts,0,7),'-01 00:00:00') AS TIMESTAMP)
         ,CAST(CONCAT(LAST_DAY(period_start_ts),' 23:59:59') AS TIMESTAMP)
         ,period_cd
         ,enrolled_vin_nb
         ,sr_pgm_instnc_id,DATA_CLCTN_ID
         ,source_cd

UNION ALL

SELECT
enrolled_vin_nb
,sr_pgm_instnc_id
,DATA_CLCTN_ID
,'t' AS  period_cd
,CAST('1970-01-01 00:00:00.0' AS TIMESTAMP) AS period_start_ts
,CAST('2999-12-31 00:00:00.0' AS TIMESTAMP) AS period_end_ts
,SUM(trip_cn) AS trip_cn
,SUM(mile_cn) AS mile_cn
,SUM(kilometer_cn) AS kilometer_cn
,SUM(fast_acceleration_cn)AS fast_acceleration_cn
,SUM(hard_brake_cn)  AS hard_brake_cn
,SUM(driving_second_cn) AS driving_second_cn
,SUM(idle_second_cn) AS idle_second_cn
,SUM(night_time_driving_second_cn) AS night_time_driving_second_cn
,IF(SUM(driving_second_cn) = 0,0,SUM(idle_second_cn)/SUM(driving_second_cn)) AS  idle_second_pc
,' '  AS trip_report_json_tt
,source_cd
FROM ~>work_db.smartmiles_Wk_Program_Summary
GROUP BY CAST('1970-01-01 00:00:00.0' AS TIMESTAMP)
	    ,CAST('2999-12-31 00:00:00.0' AS TIMESTAMP)
	    ,period_cd
	    ,enrolled_vin_nb
        ,sr_pgm_instnc_id,DATA_CLCTN_ID
	    ,source_cd
;

SET mapred.job.name = "~>job_cd Insert existing records into ~>work_db.smartmiles_Wk_Program_Summary FROM ~>foundation_db.smartmiles_Program_Summary";

INSERT INTO ~>work_db.smartmiles_Wk_Program_Summary
SELECT
  ps.enrolled_vin_nb
  ,ps.sr_pgm_instnc_id
  ,ps.DATA_CLCTN_ID
  ,ps.period_cd
  ,ps.period_start_ts
  ,ps.period_end_ts
  ,ps.trip_cn
  ,ps.mile_cn
  ,ps.kilometer_cn
  ,ps.fast_acceleration_cn
  ,ps.hard_brake_cn
  ,ps.driving_second_cn
  ,ps.idle_second_cn
  ,ps.night_time_driving_second_cn
  ,ps.idle_second_pc
  ,ps.trip_report_json_tt
  ,ps.source_cd
FROM ~>foundation_db.smartmiles_Program_Summary ps

left outer join ~>work_db.smartmiles_Wk_Program_Summary  wps
on ps.Enrolled_Vin_Nb = wps.Enrolled_Vin_Nb

where wps.enrolled_vin_nb is null
and ps.sr_pgm_instnc_id is not null
and ps.DATA_CLCTN_ID is not NUll
and ps.period_cd in ('w','tp','d')
and ps.period_start_ts >= '~>date_filter_2_wks_from_sun';