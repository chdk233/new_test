insert overwrite table ~>foundation_db.smartmiles_trip_event
PARTITION (batch_nb='~>batch_nb')
SELECT 
enrolled_vin_nb, 
trip_summary_id, 
average_speed_rt, 
trip_event_type_ds, 
trip_event_ts, 
driving_seconds_cn, 
acceleration_rt, 
speed_rt, 
latitude_nb, 
longitude_nb, 
heading_degree_nb,
'~>load_event_id'
,source_cd
FROM ~>work_db.smartmiles_wk_trip_event;