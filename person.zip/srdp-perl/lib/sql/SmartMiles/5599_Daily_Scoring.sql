SET mapred.job.name = "~>job_cd Create Table smartmiles_Wk_Daily_Scoring_Prep from smartmiles_Trip_Detail";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_daily_scoring_prep;

CREATE TABLE ~>work_db.smartmiles_wk_daily_scoring_prep(
sr_pgm_instnc_id varchar(36), 
device_id varchar(128), 
enrolled_vin_nb varchar(128), 
score_dt timestamp, 
fast_acceleration_cn int, 
hard_brake_cn int, 
stop_second_cn int, 
plausible_mile_cn decimal(24,16), 
adjusted_mile_cn decimal(24,16), 
plausible_drive_second_cn int, 
plausible_idle_second_cn int, 
plausible_no_idle_second_cn int, 
plausible_pc double, 
weighted_time_of_day_rt decimal(8,5), 
stop_per_kilometer_rt decimal(10,9), 
brake_per_kilometer_rt decimal(10,9))
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_daily_scoring_prep';

INSERT INTO TABLE ~>work_db.smartmiles_Wk_Daily_Scoring_Prep
SELECT
device.sr_pgm_instnc_id
,device.device_id
,device.enrolled_vin_nb
,from_unixtime(unix_timestamp()) as score_dt
,sum(fast_acceleration_cn) as fast_acceleration_cn
,sum(hard_brake_cn) as hard_brake_cn
,sum(stop_second_cn) as stop_second_cn
,sum(plausible_mile_cn) as plausible_mile_cn
,sum(adjusted_mile_cn) as adjusted_mile_cn
,sum(plausible_drive_second_cn) as plausible_drive_second_cn
,sum(plausible_idle_second_cn) as plausible_idle_second_cn
,(sum(plausible_drive_second_cn) - sum(plausible_idle_second_cn)) as plausible_no_idle_second_cn
,case when sum(driving_second_cn)= 0 then 0.0 else cast (round((sum(plausible_drive_second_cn)/sum(driving_second_cn)) * 100,2) as double) end  as plausible_pc
,least(cast((sum(adjusted_mile_cn*1.60934)/sum(mile_cn*1.60934)) as double),1.5) as weighted_time_of_day_rt
,greatest(0.000000001,least(2.0,cast(sum(stop_second_cn)/sum(mile_cn*1.60934) as double))) as stop_per_kilometer_rt
,greatest(0.000000001,least(2.0,cast(sum(hard_brake_cn)/sum(mile_cn*1.60934) as double))) as brake_per_kilometer_rt
FROM  ~>foundation_db.smartmiles_Trip_Detail trip
INNER JOIN ~>foundation_db.smartmiles_Device_Summary device
ON device.enrolled_vin_nb = trip.enrolled_vin_nb
WHERE device.sr_pgm_instnc_id IS NOT NULL
AND (trip.period_start_ts BETWEEN device.start_ts AND device.end_ts)
GROUP BY device.sr_pgm_instnc_id,device.device_id,device.enrolled_vin_nb;

SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_ca_vins from ODS and program_enrollment to hold CA VINs only";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_ca_vins;

CREATE TABLE ~>work_db.smartmiles_wk_ca_vins(
enrolled_vin_nb varchar(128)
)
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_ca_vins';

INSERT INTO TABLE ~>work_db.smartmiles_wk_ca_vins
SELECT distinct(vhcl_id_nbr)
FROM ~>foundation_db.smartride_Smt_Ods_Bigin_Pgm_Instnc_Orc
WHERE plcy_ratd_st_cd = 'CA';

INSERT INTO TABLE ~>work_db.smartmiles_wk_ca_vins
SELECT distinct(VIN_NB)
FROM   ~>staging_db.program_enrollment
WHERE PLCY_ST_CD = 'CA'
and VIN_NB not in (SELECT enrolled_vin_nb  
FROM ~>work_db.smartmiles_wk_ca_vins);

SET mapred.job.name = "~>job_cd Create Table smartmiles_Wk_Daily_Scoring from smartmiles_Device_Summary & smartmiles_Wk_Daily_Scoring_Prep";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_daily_scoring;

CREATE TABLE ~>work_db.smartmiles_wk_daily_scoring(
device_serial_number bigint, 
policy_number string, 
enrolled_vin string, 
sr_pgm_instnc_id varchar(36), 
score_start_date timestamp, 
score_end_date timestamp, 
score_days bigint, 
score_model_1 string, 
pure_score_1 int, 
rated_score_1 int, 
filler_1 string, 
score_model_2 string, 
pure_score_2 string, 
rated_score_2 string, 
filler_2 string, 
score_model_3 string, 
pure_score_3 string, 
rated_score_3 string, 
filler_3 string, 
score_model_4 string, 
pure_score_4 string, 
rated_score_4 string, 
filler_4 string, 
score_model_5 string, 
pure_score_5 string, 
rated_score_5 string, 
filler_5 string, 
score_model_6 string, 
pure_score_6 string, 
rated_score_6 string, 
filler_6 string, 
score_model_7 string, 
pure_score_7 string, 
rated_score_7 string, 
filler_7 string, 
score_model_8 string, 
pure_score_8 string, 
rated_score_8 string, 
filler_8 string, 
score_model_9 string, 
pure_score_9 string, 
rated_score_9 string, 
filler_9 string, 
score_model_10 string, 
pure_score_10 string, 
rated_score_10 string, 
filler_10 string, 
percent_time_disconnected double, 
calculated_annual_mileage double, 
uninstalled_time bigint, 
filler string, 
model_id string, 
hard_brake_ct int, 
fast_acceleration_ct int, 
stop_second_cn int, 
scrub_miles double, 
adjust_miles double, 
no_idle_time bigint, 
idle_time bigint, 
install_percentage double, 
plausible_percentage double, 
score_date varchar(10), 
number_of_connect_disconect string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_daily_scoring';

INSERT INTO TABLE  ~>work_db.smartmiles_Wk_Daily_Scoring
SELECT
Device_Serial_Number
,' ' as Policy_Number
,Enrolled_VIN
,sr_pgm_instnc_id
,Score_Start_Date
,Score_End_Date
,Score_Days
,'ND1' as Score_Model_1
,case
when Pure_Score_1 < 1  then 1
when Pure_Score_1 > 995  then 995
else Pure_Score_1 end as Pure_Score_1
,case
when install_percentage < 95 then 998
when (plausible_percentage < 97 or plausible_percentage is null) then 997
else case
when Pure_Score_1 < 1  then 1
when Pure_Score_1 > 995  then 995
else Pure_Score_1 end
end
as rated_score_1
,' ' as Filler_1
,'SM1' as Score_Model_2
,case
when Pure_Score_2 < 1  then 1
when Pure_Score_2 > 995  then 995
else Pure_Score_2 end Pure_Score_2
,case
when install_percentage < 95 then 998
when (plausible_percentage < 97 or plausible_percentage is null) then 997
else case
when Pure_Score_2 < 1  then 1
when Pure_Score_2 > 995  then 995
else Pure_Score_2 end
end
as rated_score_2
,' ' as Filler_2
,' ' as Score_Model_3
,' ' as Pure_Score_3
,' ' as Rated_Score_3
,' ' as Filler_3
,' ' as Score_Model_4
,' ' as Pure_Score_4
,' ' as Rated_Score_4
,' ' as Filler_4
,' ' as Score_Model_5
,' ' as Pure_Score_5
,' ' as Rated_Score_5
,' ' as Filler_5
,' ' as Score_Model_6
,' ' as Pure_Score_6
,' ' as Rated_Score_6
,' ' as Filler_6
,' ' as Score_Model_7
,' ' as Pure_Score_7
,' ' as Rated_Score_7
,' ' as Filler_7
,' ' as Score_Model_8
,' ' as Pure_Score_8
,' ' as Rated_Score_8
,' ' as Filler_8
,' ' as Score_Model_9
,' ' as Pure_Score_9
,' ' as Rated_Score_9
,' ' as Filler_9
,' ' as Score_Model_10
,' ' as Pure_Score_10
,' ' as Rated_Score_10
,' ' as Filler_10
,Percent_Time_Disconnected
,case when (days_installed is null or days_installed = 0.0) then 0.0 else ((scrub_miles/days_installed) * 365) end as Calculated_Annual_Mileage
,Uninstalled_Time
,' ' as Filler
,' ' as Model_ID
,hard_brake_ct
,fast_acceleration_ct
,stop_second_cn
,scrub_miles
,adjust_miles
,no_idle_time
,idle_time
,install_percentage
,plausible_percentage
,Score_Date
,Number_of_Connect_Disconnect as Number_of_Connect_Disconect
FROM (
SELECT
days_installed
,( case
when (days_installed is null or days_installed = 0.0 or adjust_miles is null or  HBPD is null or  fapd is null or  itpct  is null) then 995
when (avg_distance*1.60934) <= 8.82 then                             cast(floor(100*(0.0+(HBPD)*0.1604    + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 8.82   and (avg_distance*1.60934) <= 17.64  then  cast(floor(100*(0.2399+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 17.64  and (avg_distance*1.60934) <= 26.45  then  cast(floor(100*(0.6353+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 26.45  and (avg_distance*1.60934) <= 35.27  then  cast(floor(100*(0.7423+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 35.27  and (avg_distance*1.60934) <= 44.09  then  cast(floor(100*(0.8572+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 44.09  and (avg_distance*1.60934) <= 52.91  then  cast(floor(100*(0.9678+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 52.91  and (avg_distance*1.60934) <= 61.73  then  cast(floor(100*(1.0059+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 61.73  and (avg_distance*1.60934) <= 70.55  then  cast(floor(100*(1.0440+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 70.55  and (avg_distance*1.60934) <= 79.36  then  cast(floor(100*(1.0835+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 79.36  and (avg_distance*1.60934) <= 88.18  then  cast(floor(100*(1.1261+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 88.18  and (avg_distance*1.60934) <= 97.00  then  cast(floor(100*(1.1686+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 97.00  and (avg_distance*1.60934) <= 105.82 then  cast(floor(100*(1.2111+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 105.82 and (avg_distance*1.60934) <= 114.64 then  cast(floor(100*(1.2537+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 114.64 and (avg_distance*1.60934) <= 123.46 then  cast(floor(100*(1.2962+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 123.46 and (avg_distance*1.60934) <= 132.27 then  cast(floor(100*(1.3388+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distance*1.60934) > 132.27                                      then  cast(floor(100*(1.3813+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
 end ) as Pure_Score_1
,ceil(200 * (1.4916 + (0.2932) * ln(brake_per_kilometer_rt) + (0.7247) * ln(stop_per_kilometer_rt) + (1.9933) * weighted_time_of_day_rt)) as Pure_Score_2
,Device_Serial_Number
,Enrolled_VIN
,sr_pgm_instnc_id
,Score_Start_Date
,Score_End_Date
,Score_Days
,Percent_Time_Disconnected
,Uninstalled_Time
,hard_brake_ct
,fast_acceleration_ct
,stop_second_cn
,scrub_miles
,no_idle_time
,idle_time
,install_percentage
,plausible_percentage
,Score_Date
,adjust_miles
,Number_of_Connect_Disconnect
FROM
(SELECT
 connected_day_cn as days_installed
,case when trip.adjusted_mile_cn is Null then 0.0 else trip.adjusted_mile_cn end as adjust_miles
,(case when trip.adjusted_mile_cn is Null then 0.0 else trip.adjusted_mile_cn end/connected_day_cn) as avg_distance
,case when connected_day_cn = 0 then 0.0 when ( case when trip.hard_brake_cn is null then 0 else cast(trip.hard_brake_cn as INT) end /connected_day_cn)> 7.0 then 7.0 else (case when trip.hard_brake_cn is null then 0 else cast(trip.hard_brake_cn as INT) end/connected_day_cn) end HBPD
,case when connected_day_cn = 0 then 0.0 when (case when trip.fast_acceleration_cn is null then 0 else cast(trip.fast_acceleration_cn as int) end/connected_day_cn)> 4.0 then 4.0 else (case when trip.fast_acceleration_cn is null then 0 else cast(trip.fast_acceleration_cn as int) end/connected_day_cn) end fapd
,case when (trip.plausible_idle_second_cn is null or trip.plausible_no_idle_second_cn is null) then 0.0 else (trip.plausible_idle_second_cn/(trip.plausible_idle_second_cn+trip.plausible_no_idle_second_cn)) end as itpct
,device.device_id as Device_Serial_Number
,device.enrolled_vin_nb as Enrolled_VIN
,device.sr_pgm_instnc_id as sr_pgm_instnc_id
,device.start_ts as Score_Start_Date
,device.end_ts as Score_End_Date
,device.lifetime_day_cn as Score_Days
,device.device_disconnected_pc as Percent_Time_Disconnected
,device.disconnected_second_cn as Uninstalled_Time
,case when trip.hard_brake_cn is null then 0 else cast(trip.hard_brake_cn as int) end as hard_brake_ct
,case when trip.fast_acceleration_cn is null then 0 else cast(trip.fast_acceleration_cn as int) end as fast_acceleration_ct
,case when trip.stop_second_cn is null then 0 else cast(trip.stop_second_cn as int) end as stop_second_cn
,case when trip.plausible_mile_cn is null then 0.0 else trip.plausible_mile_cn end as scrub_miles
,case when trip.plausible_no_idle_second_cn is null then cast(0 as bigint)  else trip.plausible_no_idle_second_cn end as no_idle_time
,case when trip.plausible_idle_second_cn is null then cast (0 as bigint) else trip.plausible_idle_second_cn end as idle_time
,device.device_connected_pc as install_percentage
,case when trip.plausible_pc is null then 100.00 else trip.plausible_pc end as plausible_percentage
,CAST (from_unixtime(unix_timestamp()) as varchar(10) ) as Score_Date
,concat(concat(LPAD(trim(cast(if (connected_status_cn is null,' ',connected_status_cn) as varchar(3))),3,'000'),'_'),LPAD(trim(cast(if (disconnected_status_cn is null,' ',disconnected_status_cn) as varchar(3))),3,'000'))  as Number_of_Connect_Disconnect
,trip.weighted_time_of_day_rt
,trip.stop_per_kilometer_rt
,trip.brake_per_kilometer_rt
	FROM ~>foundation_db.smartmiles_Device_Summary device
	LEFT JOIN
	~>work_db.smartmiles_Wk_Daily_Scoring_Prep trip
	on device.enrolled_vin_nb = trip.enrolled_vin_nb
	and device.sr_pgm_instnc_id = trip.sr_pgm_instnc_id
	WHERE device.sr_pgm_instnc_id is not null
--Excluding CA records since FMC is not supposed to get CA VINs scored here, and SmartMiles IMS is IL only
        AND device.enrolled_vin_nb not in (
            select enrolled_vin_nb from ~>work_db.smartmiles_wk_ca_vins )
) temp1) temp2
;

SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;

SET mapred.job.name = "~>job_cd Insert Overwrite Hive_SRE_Scoring from smartmiles_Wk_Daily_Scoring";


INSERT INTO TABLE ~>provide_db.smartride_Hive_SRE_Scoring partition(score_date)
SELECT
device_serial_number
,policy_number
,enrolled_vin
,sr_pgm_instnc_id
,score_start_date
,score_end_date
,score_days
,score_model_1
,pure_score_1
,rated_score_1
,filler_1
,score_model_2
,pure_score_2
,rated_score_2
,filler_2
,score_model_3
,pure_score_3
,rated_score_3
,filler_3
,score_model_4
,pure_score_4
,rated_score_4
,filler_4
,score_model_5
,pure_score_5
,rated_score_5
,filler_5
,score_model_6
,pure_score_6
,rated_score_6
,filler_6
,score_model_7
,pure_score_7
,rated_score_7
,filler_7
,score_model_8
,pure_score_8
,rated_score_8
,filler_8
,score_model_9
,pure_score_9
,rated_score_9
,filler_9
,score_model_10
,pure_score_10
,rated_score_10
,filler_10
,percent_time_disconnected
,calculated_annual_mileage
,number_of_connect_disconect
,uninstalled_time
,filler
,model_id
,hard_brake_ct
,fast_acceleration_ct
--,stop_second_cn # Commenting this out for now. Field not present in hive_sre_scoring. Should be added to end.
,scrub_miles
,adjust_miles
,no_idle_time
,idle_time
,install_percentage
,plausible_percentage
,score_date
FROM ~>work_db.smartmiles_Wk_Daily_Scoring;

SET hive.merge.mapfiles=true;
SET hive.merge.mapredfiles=true;
SET hive.merge.smallfiles.avgsize= ~>hive_merge_smallfiles_avgsize;
SET hive.merge.size.per.task= ~>hive_merge_size_per_task;
SET mapred.max.split.size= ~>mapred_max_split_size;
SET mapred.min.split.size= ~>mapred_min_split_size;

SET mapred.job.name = "~>job_cd Create Table smartmiles_Wk_Daily_Scoring_Export from smartmiles_Wk_Daily_Scoring";

INSERT OVERWRITE TABLE ~>provide_db.smartmiles_Daily_Scoring_Export
SELECT CONCAT(
 RPAD(TRIM(IF(device_serial_number IS NULL,' ', CAST(device_serial_number AS VARCHAR(25)))),25,' ')
,RPAD(TRIM(IF(policy_number IS NULL,' ', CAST(policy_number AS VARCHAR(20)))),20,' ')
,RPAD(TRIM(IF(enrolled_vin IS NULL,' ', CAST(enrolled_vin AS VARCHAR(17)))),17,' ')
,LPAD(TRIM(IF(sr_pgm_instnc_id IS NULL,' ', CAST(sr_pgm_instnc_id AS VARCHAR(36)))),36,'0')
,RPAD(REGEXP_REPLACE(IF(score_date IS NULL,' ', CAST(score_date AS VARCHAR(10))),'-',''),8,' ')
,RPAD(REGEXP_REPLACE(IF(score_start_date IS NULL,' ', CAST(score_start_date AS VARCHAR(10))),'-',''),8,' ')
,RPAD(REGEXP_REPLACE(IF(score_end_date IS NULL,' ', CAST(score_end_date AS VARCHAR(10))),'-',''),8,' ')
,LPAD(CAST(IF(score_days IS NULL,0,CAST(score_days AS INT)) AS VARCHAR(5)),3,'0')
,RPAD(TRIM(IF(score_model_1 IS NULL,' ', CAST(score_model_1 AS VARCHAR(4)))),4,' ')
,LPAD(TRIM(IF(pure_score_1 IS NULL,' ', CAST(pure_score_1 AS VARCHAR(3)))),3,'0')
,LPAD(TRIM(IF(rated_score_1 IS NULL,' ', CAST(rated_score_1 AS VARCHAR(3)))),3,'0')
,'          '
,RPAD(TRIM(IF(score_model_2 IS NULL,' ', CAST(score_model_2 AS VARCHAR(4)))),4,' ')
,LPAD(TRIM(IF(pure_score_2 IS NULL,' ', CAST(pure_score_2 AS VARCHAR(3)))),3,'0')
,LPAD(TRIM(IF(rated_score_2 IS NULL,' ', CAST(rated_score_2 AS VARCHAR(3)))),3,'0')
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,'    '
,'000'
,'000'
,'          '
,LPAD(CAST(IF(percent_time_disconnected IS NULL,0,CAST(percent_time_disconnected*100 AS INT)) AS VARCHAR(5)),5,'0')
,LPAD(TRIM(IF(calculated_annual_mileage IS NULL,' ', CAST(calculated_annual_mileage AS VARCHAR(6)))),6,'0')
,RPAD(TRIM(IF(number_of_connect_disconect IS NULL,' ', CAST(number_of_connect_disconect AS VARCHAR(7)))),7,' ')
,CONCAT(CONCAT(CONCAT(CONCAT (LPAD(TRIM(IF(uninstalled_time IS NULL,' ', CAST(CAST(uninstalled_time/86400 AS INT) AS VARCHAR(3)))),3,'0') , ':'),
LPAD(TRIM(IF(uninstalled_time IS NULL,' ', CAST(CAST((uninstalled_time%86400)/3600 AS INT) AS VARCHAR(3)))),2,'0') , ':'),
LPAD(TRIM(IF(uninstalled_time IS NULL,' ', CAST(CAST(((uninstalled_time%86400)%3600)/60 AS INT)AS VARCHAR(3)))),2,'0') , ':'),
LPAD(TRIM(IF(uninstalled_time IS NULL,' ', CAST(((uninstalled_time%86400)%3600)%60 AS VARCHAR(3)))),2,'0'))
,RPAD(TRIM(filler )  ,45,' '))   as filler
FROM ~>work_db.smartmiles_Wk_Daily_Scoring;