SET mapred.job.name = "~>job_cd Insert  into ~>work_db.wk_hbase_event";

DROP TABLE IF EXISTS ~>work_db.wk_hbase_event;

CREATE  TABLE ~>work_db.wk_hbase_event(
  program string, 
  strt_ts timestamp, 
  max_strt_ts timestamp
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS ORC
LOCATION
      'hdfs:///user/hive/warehouse/~>work_db/wk_hbase_event'; 

insert into ~>work_db.wk_hbase_event select 'SM-SR',CURRENT_TIMESTAMP(),coalesce(max(strt_ts),CURRENT_TIMESTAMP() - interval 1 month) as max_strt_ts  from ~>work_db.hbase_event;

SET mapred.job.name = "~>job_cd Insert  into ~>foundation_db.smartride_Sre_Summary_Ext from ~>work_db.Hbase_Program_Summary";

SET hbase.zookeeper.quorum=~>zookeeper_quorum;

INSERT INTO ~>provide_db.smartride_Sre_Summary_Ext
SELECT
concat(ENRLD_VIN_NB, '_',PE_CD,'_',unix_timestamp(PE_STRT_TS) + (case
when PE_STRT_TS between date_format( cast(extract(year from PE_STRT_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_STRT_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600)  AS key,
unix_timestamp(PE_END_TS) + (case
when PE_END_TS between date_format( cast(extract(year from PE_END_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_END_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600,
TRIP_CT,
MILE_CT,
NIGHT_TIME_DRVNG_SC_CT,
FAST_ACLRTN_CT,
HARD_BRKE_CT,
IDLE_SC_CT,
DRVNG_SC_CT,
IDLE_TIME_RATIO,
regexp_replace(TRIP_RPRT_JSON_TT,',','\;')
FROM ~>work_db.Hbase_PROGRAM_SUMMARY a
inner join ~>work_db.wk_hbase_event b on a.LOAD_HR_TS >=b.max_strt_ts and a.LOAD_HR_TS <b.strt_ts
where src_sys_cd='IMS_SM_5X'

union

Select 
concat(concat(substr('00',1,2-length(cast(pmod(PRGRM_INSTC_ID,~>splits)as varchar(2)))),cast(pmod(PRGRM_INSTC_ID,16)as varchar(2))), '_', PRGRM_INSTC_ID,'_',PE_CD,'_',unix_timestamp(PE_STRT_TS) + (case
when PE_STRT_TS between date_format( cast(extract(year from PE_STRT_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_STRT_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_STRT_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600 ) as key,
unix_timestamp(PE_END_TS) + (case
when PE_END_TS between date_format( cast(extract(year from PE_END_TS) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from PE_END_TS) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(PE_END_TS as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600 as pets,
TRIP_CT,
MILE_CT as mls,
NIGHT_TIME_DRVNG_SC_CT as ntd,
FAST_ACLRTN_CT as fac,HARD_BRKE_CT as hbc,
IDLE_SC_CT as it,
DRVNG_SC_CT as dt,
IDLE_TIME_RATIO as itr,
regexp_replace(TRIP_RPRT_JSON_TT,',','\;') as tsj 
FROM ~>work_db.Hbase_PROGRAM_SUMMARY a
inner join ~>work_db.wk_hbase_event b on a.LOAD_HR_TS >=b.max_strt_ts and a.LOAD_HR_TS <b.strt_ts
where (src_sys_cd like 'IMS_SR_%' or src_sys_cd in ('TIMS_SR','FMC_SR'));

SET mapred.job.name = "~>job_cd Insert  into ~>work_db.hbase_event";
insert into ~>work_db.hbase_event
select program,strt_ts,current_timestamp(),extract(month from current_timestamp()) from ~>work_db.wk_hbase_event;