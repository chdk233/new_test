SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_device from smartride_smt_ods_bigin_pgm_instnc_orc";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_device;

CREATE TABLE ~>work_db.smartmiles_wk_device(
  sr_pgm_instnc_id bigint, 
  vhcl_id_nbr string, 
  device_id bigint, 
  plcy_ratd_st_cd string,
  active_end_dt timestamp,
  active_start_dt timestamp)  
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_device';

INSERT INTO TABLE ~>work_db.smartmiles_wk_device
  SELECT DISTINCT
                 sr_pgm_instnc_id  
                 ,vhcl_id_nbr
                 ,dev_id_nbr as device_id
                 ,plcy_ratd_st_cd
                 ,active_end_dt
                 ,active_start_dt               
  FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc
  WHERE  date(active_end_dt) = date('3500-01-01');

INSERT INTO TABLE ~>work_db.smartmiles_wk_device
  SELECT DISTINCT
                 DATA_CLCTN_ID as sr_pgm_instnc_id  
                 ,VIN_NB as vhcl_id_nbr
                 ,DEVC_ID as device_id
                 ,PLCY_ST_CD as plcy_ratd_st_cd
                 ,PRGRM_TERM_END_DT as active_end_dt
                 ,PRGRM_TERM_BEG_DT as active_start_dt
  FROM (select distinct(p.VIN_NB), p.EVNT_SYS_TS, p.PRGRM_TERM_BEG_DT, p.PRGRM_TERM_END_DT, p.PRGRM_STTS_CD, p.DATA_CLCTN_STTS, p.DATA_CLCTN_ID, p.DEVC_ID, p.PLCY_ST_CD
        from ~>staging_db.program_enrollment p
	inner join
       (select max(EVNT_SYS_TS) as max_time, VIN_NB 
		from  ~>staging_db.program_enrollment pe
		where PRGRM_STTS_CD = 'Active' and DATA_CLCTN_STTS = 'Active'
		GROUP BY VIN_NB
		) p2
	on p.VIN_NB = p2.VIN_NB
	and p.EVNT_SYS_TS = p2.max_time) pe
	WHERE  pe.PRGRM_STTS_CD = 'Active'
	AND pe.DATA_CLCTN_STTS = 'Active'
	AND pe.VIN_NB 
	NOT IN 
	(SELECT DISTINCT vhcl_id_nbr
	FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc
	WHERE date(active_end_dt) = date('3500-01-01'));

SET mapred.job.name = "~>job_cd Truncate and Load ~>work_db.smartmiles_WK_Trip_Detail_Second_Temp";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_trip_detail_second_temp;

CREATE TABLE ~>work_db.smartmiles_wk_trip_detail_second_temp(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
device_id varchar(128), 
position_ts timestamp, 
position_offset_ts timestamp, 
time_zone_offset_nb int, 
speed_mph_rt decimal(8,5), 
engine_rpm_rt decimal(8,3), 
mile_cn decimal(8,5), 
fast_acceleration_cn int, 
hard_brake_cn int, 
driving_second_cn int, 
idle_second_cn int, 
stop_second_cn int, 
night_time_driving_second_cn int, 
plausible_second_cn int, 
centroid_nb bigint, 
scrubbed_field_nb int, 
latitude_nb decimal(9,6), 
longitude_nb decimal(9,6), 
garbage_flag_in int, 
source_cd string, 
batch_nb string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ','  
STORED AS TEXTFILE
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_trip_detail_second_temp';


LOAD DATA INPATH '~>map_reduce_output_path/TEMP/SmartMiles/PostScrubbing/TripScrub*' OVERWRITE INTO TABLE ~>work_db.smartmiles_wk_trip_detail_second_temp;


SET mapred.job.name = "~>job_cd Truncate and Load ~>work_db.smartmiles_WK_Trip_Detail_Second";


DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_trip_detail_second;

CREATE TABLE ~>work_db.smartmiles_wk_trip_detail_second(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
device_id varchar(128), 
position_ts timestamp, 
position_offset_ts timestamp, 
time_zone_offset_nb int, 
speed_mph_rt decimal(8,5), 
engine_rpm_rt decimal(8,3), 
mile_cn decimal(8,5), 
fast_acceleration_cn int, 
hard_brake_cn int, 
driving_second_cn int, 
idle_second_cn int, 
stop_second_cn int, 
night_time_driving_second_cn int, 
plausible_second_cn int, 
centroid_nb bigint, 
scrubbed_field_nb int, 
latitude_nb decimal(9,6), 
longitude_nb decimal(9,6), 
garbage_flag_in int, 
source_cd string, 
batch_nb string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ','  
STORED AS TEXTFILE
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_trip_detail_second';

INSERT into ~>work_db.smartmiles_wk_trip_detail_second
	SELECT 
			 dst.enrolled_vin_nb 
			,dst.trip_summary_id 
			,dst.device_id 
			,dst.position_ts
			,dst.position_offset_ts
			,dst.time_zone_offset_nb 
			,dst.speed_mph_rt 
			,dst.engine_rpm_rt 
			,dst.mile_cn 
			,CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.fast_acceleration_cn END AS fast_acceleration_cn
			,CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.hard_brake_cn END AS hard_brake_cn
			,dst.driving_second_cn
			,dst.idle_second_cn
			,CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.stop_second_cn END AS stop_second_cn
			,CASE WHEN dev.plcy_ratd_st_cd = 'CA' THEN 0 ELSE dst.night_time_driving_second_cn END AS night_time_driving_second_cn			  
			,dst.plausible_second_cn 
			,dst.centroid_nb 
			,dst.scrubbed_field_nb
			,dst.latitude_nb
			,dst.longitude_nb
			,dst.garbage_flag_in
			,dst.source_cd 
			,dst.batch_nb
	FROM ~>work_db.smartmiles_wk_trip_detail_second_temp dst
	JOIN ~>work_db.smartmiles_wk_device dev
	ON 	dst.enrolled_vin_nb = dev.vhcl_id_nbr;
	


