CREATE EXTERNAL TABLE telematics_db.smartmiles_garbage_trip_detail_second(
  enrolled_vin_nb varchar(128), 
  trip_summary_id varchar(128), 
  device_id varchar(128), 
  position_ts timestamp, 
  position_offset_ts timestamp, 
  time_zone_offset_nb int, 
  speed_mph_rt decimal(8,5), 
  speed_kph_rt decimal(8,5), 
  engine_rpm_rt decimal(8,3), 
  mile_cn decimal(8,5), 
  kilometer_cn decimal(8,5), 
  fast_acceleration_cn int, 
  hard_brake_cn int, 
  driving_second_cn int, 
  idle_second_cn int, 
  stop_second_cn int, 
  night_time_driving_second_cn int, 
  plausible_second_cn int, 
  centroid_nb bigint, 
  scrubbed_field_nb int, 
  latitude_nb decimal(9,6), 
  longitude_nb decimal(9,6), 
  source_cd string, 
  load_event_id decimal(18,0))
PARTITIONED BY ( 
  batch_nb string)
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_db/smartmiles_garbage_trip_detail_second'
;