CREATE EXTERNAL TABLE telematics_staging_db.smartmiles_trip_event(
  vehicle struct<enrolled_vin_nb:string,detected_vin_nb:string> COMMENT 'from deserializer', 
  trip_summary_id string COMMENT 'from deserializer', 
  telemetryevents array<struct<driving_second_cn:string,acceleration_rt:string,average_speed_rt:string,speed_rt:string,event_type_ds:string,event_ts:string,latitude_nb:string,longitude_nb:string,heading_degree_nb:string>> COMMENT 'from deserializer')
PARTITIONED BY ( 
  source_cd string, 
  batch_nb string)
ROW FORMAT SERDE 
  'org.openx.data.jsonserde.JsonSerDe' 
WITH SERDEPROPERTIES ( 
  'case.insensitive'='true', 
  'mapping.acceleration_rt'='acceleration', 
  'mapping.average_speed_rt'='avgSpeed', 
  'mapping.detected_vin_nb'='detectedVin', 
  'mapping.driving_second_cn'='secondsOfDriving', 
  'mapping.enrolled_vin_nb'='enrolledVin', 
  'mapping.event_ts'='utcDateTime', 
  'mapping.event_type_ds'='telemetryEventType', 
  'mapping.heading_degree_nb'='headingDegrees', 
  'mapping.latitude_nb'='degreesLatitude', 
  'mapping.longitude_nb'='degreesLongitude', 
  'mapping.speed_rt'='speed', 
  'mapping.trip_summary_id'='tripSummaryId') 
STORED AS TEXTFILE
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_staging_db/smartmiles_staging_json'
 ;