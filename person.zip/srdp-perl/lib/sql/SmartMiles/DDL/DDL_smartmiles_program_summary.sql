CREATE EXTERNAL TABLE telematics_db.smartmiles_program_summary(
  enrolled_vin_nb varchar(128), 
  period_cd string, 
  period_start_ts timestamp, 
  period_end_ts timestamp, 
  trip_cn int, 
  mile_cn decimal(24,16), 
  kilometer_cn decimal(24,16), 
  fast_acceleration_cn int, 
  hard_brake_cn int, 
  driving_second_cn int, 
  idle_second_cn int, 
  night_time_driving_second_cn int, 
  idle_second_pc double, 
  trip_report_json_tt string, 
  source_cd string)
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_db/smartmiles_program_summary'
 ;