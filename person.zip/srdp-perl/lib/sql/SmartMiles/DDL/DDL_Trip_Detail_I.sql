DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Db.Trip_Detail;

CREATE EXTERNAL  TABLE Pcdw_Telematics_Fnd_Db.Trip_Detail
(
enrolled_vin_nb VARCHAR(128)
,trip_summary_id VARCHAR(128)
,period_start_ts TIMESTAMP
,period_end_ts TIMESTAMP
,mile_cn DECIMAL(8,5)
,adjusted_mile_cn DECIMAL(8,5)
,plausible_mile_cn DECIMAL(8,5)
,kilometer_cn	DECIMAL(8,5)
,fast_acceleration_cn INT
,hard_brake_cn INT
,driving_second_cn INT
,idle_second_cn INT
,stop_second_cn INT
,night_time_driving_second_cn INT
,plausible_drive_second_cn INT
,plausible_idle_second_cn INT
,idle_second_pc DOUBLE
,trip_report_json_tt	STRING
,source_cd STRING
,load_event_id DECIMAL(18,0)
)
PARTITIONED BY (batch_nb STRING)
STORED AS ORC;