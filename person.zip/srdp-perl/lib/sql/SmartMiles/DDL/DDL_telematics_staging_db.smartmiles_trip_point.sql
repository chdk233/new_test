CREATE EXTERNAL TABLE telematics_staging_db.smartmiles_trip_point(
  trip_summary_id string COMMENT 'from deserializer', 
  telemetrypoints array<struct<engine_rpm_rt:string,acceleration_rt:string,latitude_nb:string,longitude_nb:string,heading_degree_nb:string,position_ts:string,speed_rt:string,accelerometer_data_tt:string,average_hdop_nb:string,horizontal_accuracy_nb:string,vertical_accuracy_nb:string,ambient_temperature_cn:string,barometric_pressure_cn:string,coolant_temperature_cn:string,fuel_level_qt:string,throttle_position_nb:string,accelerometer_data_long_nb:string>> COMMENT 'from deserializer')
PARTITIONED BY ( 
  source_cd string, 
  batch_nb string)
ROW FORMAT SERDE 
  'org.openx.data.jsonserde.JsonSerDe' 
WITH SERDEPROPERTIES ( 
  'case.insensitive'='true', 
  'mapping.acceleration_rt'='acceleration', 
  'mapping.accelerometer_data_lat_nb'='accelerometerDataLat', 
  'mapping.accelerometer_data_long_nb'='accelerometerDataLong', 
  'mapping.accelerometer_data_tt'='accelerometerData', 
  'mapping.ambient_temperature_cn'='ambientTemperature', 
  'mapping.average_hdop_nb'='hdop', 
  'mapping.barometric_pressure_cn'='barometricPressure', 
  'mapping.coolant_temperature_cn'='coolantTemperature', 
  'mapping.engine_rpm_rt'='engineRPM', 
  'mapping.fuel_level_qt'='fuelLevel', 
  'mapping.heading_degree_nb'='headingDegrees', 
  'mapping.horizontal_accuracy_nb'='horizontalAccuracy', 
  'mapping.latitude_nb'='degreesLatitude', 
  'mapping.longitude_nb'='degreesLongitude', 
  'mapping.position_ts'='utcDateTime', 
  'mapping.speed_rt'='speed', 
  'mapping.throttle_position_nb'='throttlePosition', 
  'mapping.trip_summary_id'='tripSummaryId', 
  'mapping.vertical_accuracy_nb'='verticalAccuracy') 
STORED AS TEXTFILE
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_staging_db/smartmiles_staging_json'
 ;