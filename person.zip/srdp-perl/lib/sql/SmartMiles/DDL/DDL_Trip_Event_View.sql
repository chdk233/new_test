DROP VIEW IF EXISTS Pcdw_Telematics_Rpt_Db.Trip_Event;
CREATE VIEW Pcdw_Telematics_Rpt_Db.Trip_Event
AS
SELECT 
CAST(Vehicle.Enrolled_Vin_Nb AS VARCHAR(128)) AS Enrolled_Vin_Nb,
CAST(Trip_Summary_Id AS VARCHAR(128)) AS Trip_Summary_Id,
CAST(Telemetryevents_Ts.Event_Type_Ds AS VARCHAR(500)) AS Event_Type_Ds,
From_Unixtime(Unix_Timestamp(Telemetryevents_Ts.Event_Ts, "yyyy-mm-dd'T'HH:MM:ss.SSS")) AS Event_Ts,
CAST(Telemetryevents_Ts.Speed_Rt AS DECIMAL(8,5)) AS Speed_Rt,
CAST(Telemetryevents_Ts.Acceleration_Rt AS DECIMAL(8,5)) AS Acceleration_Rt,
CAST(Telemetryevents_Ts.Driving_Second_Cn AS BIGINT) AS Driving_Second_Cn,
CAST(Telemetryevents_Ts.Latitude_Nb AS DECIMAL(24,16)) AS Latitude_Nb,
CAST(Telemetryevents_Ts.Longitude_Nb AS DECIMAL(24,16)) AS Longitude_Nb,
CAST(Telemetryevents_Ts.Heading_Degree_Nb AS INT) AS Heading_Degree_Nb,
Batch_Nb
FROM Pcdw_Telematics_Stg_Db.Trip_Event
LATERAL VIEW EXPLODE(Telemetryevents) EXPLODED_TABLE AS Telemetryevents_Ts;
