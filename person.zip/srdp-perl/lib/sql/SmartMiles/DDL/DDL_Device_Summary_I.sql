DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Db.Device_Summary;

CREATE TABLE Pcdw_Telematics_Fnd_Db.Device_Summary(
    Device_Id VARCHAR(128),
    Sr_Pgm_Instnc_Id BIGINT,
    Enrolled_Vin_Nb VARCHAR(128),
    Start_Ts TIMESTAMP,
    End_Ts TIMESTAMP,
    Lifetime_Second_Cn BIGINT,
    Connected_Second_Cn	BIGINT,
    Connected_Status_Cn	INT,
    Disconnected_Second_Cn BIGINT,
    Disconnected_Status_Cn INT,
    Lifetime_Day_Cn INT,
    Connected_Day_Cn INT,
    Device_Unavailable_Cn INT,
    Device_Connected_Pc	DOUBLE,
    Device_Disconnected_Pc DOUBLE)
STORED AS ORC;
