DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Workdb.Wk_Trip_Detail_Second;

CREATE TABLE Pcdw_Telematics_Fnd_Workdb.Wk_Trip_Detail_Second(
 enrolled_vin_nb	VARCHAR(128)
,trip_summary_id	VARCHAR(128)
,device_id	VARCHAR(128)
,position_ts	TIMESTAMP
,position_offset_ts	TIMESTAMP
,time_zone_offset_nb	INT
,speed_mph_rt	DECIMAL(8,5)
,engine_rpm_rt	DECIMAL(8,5)
,mile_cn	DECIMAL(8,5)
,fast_acceleration_cn	INT
,hard_brake_cn	INT
,driving_second_cn	INT
,idle_second_cn	INT
,stop_second_cn INT
,night_time_driving_second_cn INT
,plausible_second_cn	INT
,centroid_nb BIGINT
,scrubbed_field_nb	INT
,latitude_nb	DECIMAL(9,6)
,longitude_nb	DECIMAL(9,6)
,garbage_flag_in	INT
,source_cd	STRING   
,batch_nb	STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' 
STORED AS TEXTFILE;