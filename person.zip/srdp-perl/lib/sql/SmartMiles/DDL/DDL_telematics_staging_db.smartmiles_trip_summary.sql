 CREATE EXTERNAL TABLE telematics_staging_db.smartmiles_trip_summary(
  vehicle struct<enrolled_vin_nb:string,detected_vin_nb:string> COMMENT 'from deserializer', 
  trip_summary_id string COMMENT 'from deserializer', 
  device struct<device_identifier_type_nm:string,device_id:string,device_type_nm:string,device_serial_nb:string> COMMENT 'from deserializer', 
  trip_start_ts string COMMENT 'from deserializer', 
  trip_end_ts string COMMENT 'from deserializer', 
  time_zone_offset_nb string COMMENT 'from deserializer', 
  average_speed_rt string COMMENT 'from deserializer', 
  maximum_speed_rt string COMMENT 'from deserializer', 
  driving_distance_cn string COMMENT 'from deserializer', 
  trip_second_cn string COMMENT 'from deserializer', 
  trip_idling_second_cn string COMMENT 'from deserializer', 
  fuel_consumption_qt string COMMENT 'from deserializer', 
  average_hdop_rt string COMMENT 'from deserializer', 
  acceleration_quality_in string COMMENT 'from deserializer', 
  malfunction_status_in string COMMENT 'from deserializer', 
  measurementunit struct<measurement_unit_ds:string> COMMENT 'from deserializer', 
  transport_mode_change_ds string COMMENT 'from deserializer', 
  transport_mode_change_reason_ds string COMMENT 'from deserializer')
PARTITIONED BY ( 
  source_cd string, 
  batch_nb string)
ROW FORMAT SERDE 
  'org.openx.data.jsonserde.JsonSerDe' 
WITH SERDEPROPERTIES ( 
  'case.insensitive'='true', 
  'mapping.acceleration_quality_in'='accelQuality', 
  'mapping.average_hdop_rt'='hdopAverage', 
  'mapping.average_speed_rt'='avgSpeed', 
  'mapping.detected_vin_nb'='detectedVin', 
  'mapping.device_id'='deviceIdentifier', 
  'mapping.device_identifier_type_nm'='deviceIdentifierType', 
  'mapping.device_serial_nb'='deviceSerialNumber', 
  'mapping.device_type_nm'='deviceType', 
  'mapping.driving_distance_cn'='drivingDistance', 
  'mapping.enrolled_vin_nb'='enrolledVin', 
  'mapping.fuel_consumption_qt'='fuelConsumption', 
  'mapping.malfunction_status_in'='milStatus', 
  'mapping.maximum_speed_rt'='maxSpeed', 
  'mapping.measurement_unit_ds'='system', 
  'mapping.time_zone_offset_nb'='timeZoneOffset', 
  'mapping.transport_mode_change_ds'='transportMode', 
  'mapping.transport_mode_change_reason_ds'='transportModeReason', 
  'mapping.trip_end_ts'='utcEndDateTime', 
  'mapping.trip_idling_second_cn'='secondsOfIdling', 
  'mapping.trip_second_cn'='totalTripSeconds', 
  'mapping.trip_start_ts'='utcStartDateTime', 
  'mapping.trip_summary_id'='tripSummaryId') 
STORED AS TEXTFILE
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_staging_db/smartmiles_staging_json'
 ;
 