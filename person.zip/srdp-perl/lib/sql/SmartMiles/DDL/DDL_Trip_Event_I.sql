DROP TABLE IF EXISTS pcdw_telematics_fnd_db.Trip_Event;

CREATE TABLE pcdw_telematics_fnd_db.Trip_Event (
enrolled_vin_nb VARCHAR(128),
trip_summary_id VARCHAR(128),
average_speed_rt DECIMAL(8,5),
trip_event_type_ds VARCHAR(500),
trip_event_ts TIMESTAMP,
driving_seconds_cn BIGINT,
acceleration_rt DECIMAL(8,5),
speed_rt DECIMAL(8,5),
latitude_nb DECIMAL(24,16),
longitude_nb DECIMAL(24,16),
heading_degree_nb INT,
load_event_id DECIMAL(18,0))
PARTITIONED BY (batch_nb string)
STORED AS ORC;