
CREATE TABLE pcdw_telematics_fnd_workdb.Daily_Mileage_Export(
Enrolled_vin_nb VARCHAR(128), 
Mile_cn DECIMAL(8,5), 
Device_unavailable_in TINYINT,
Disconnected_status_in TINYINT, 
Trip_dt DATE, 
Load_dt DATE)
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY ',' 
STORED AS TEXTFILE;