DROP TABLE IF EXISTS Pcdw_Telematics_Stg_Db.Trip_Summary;

CREATE EXTERNAL TABLE Pcdw_Telematics_Stg_Db.Trip_Summary (
vehicle STRUCT<
Enrolled_Vin_Nb: STRING,
Detected_Vin_Nb: STRING >,
Trip_Summary_Id STRING,
device STRUCT<
Device_Identifier_Type_Nm: STRING,
Device_Id: STRING,
Device_Type_Nm: STRING,
Device_Serial_Nb : STRING >,
Trip_Start_Ts STRING,
Trip_End_Ts STRING,
Time_Zone_Offset_Nb STRING,
Average_Speed_Rt STRING,
Maximum_Speed_Rt STRING,
Driving_Distance_Cn STRING,
Trip_Second_Cn STRING,
Trip_Idling_Second_Cn STRING,
Fuel_Consumption_Qt STRING,
Average_Hdop_Rt STRING,
Acceleration_Quality_In STRING,
Malfunction_Status_In STRING,
measurementUnit STRUCT<
Measure_Unit_Ds: STRING>,
Transport_Mode_Change_Ds STRING,
Transport_Mode_Change_Reason_Ds STRING)
PARTITIONED BY (Batch_Nb STRING)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES(
"case.insensitive" = "false",
"mapping.trip_summary_id" = "tripSummaryId",
"mapping.device_identifier_type_nm" = "deviceIdentifierType",
"mapping.device_type_nm" = "deviceType",
"mapping.device_id" = "deviceIdentifier",
"mapping.device_serial_nb" = "deviceSerialNumber",
"mapping.enrolled_vin_nb" = "enrolledVin",
"mapping.detected_vin_nb" = "detectedVin",
"mapping.average_speed_rt"="avgSpeed",
"mapping.driving_distance_cn"="drivingDistance",
"mapping.fuel_consumption_qt"="fuelConsumption",
"mapping.malfunction_status_in"="milStatus",
"mapping.maximum_speed_rt"="maxSpeed",
"mapping.measure_unit_ds"="system",
"mapping.trip_second_cn"="totalTripSeconds",
"mapping.time_zone_offset_nb"="timeZoneOffset",
"mapping.trip_start_ts"="utcStartDateTime",
"mapping.trip_end_ts"="utcEndDateTime",
"mapping.acceleration_quality_in"="accelQuality",
"mapping.average_hdop_rt"="hdopAverage",
"mapping.trip_idling_second_cn"="secondsOfIdling",
"mapping.transport_mode_change_ds"="transportMode",
"mapping.transport_mode_change_reason_ds"="transportModeReason"
)
LOCATION '/Programs/SmartRide/SmartMiles';


--alter table pcdw_telematics_stg_db.Trip_Summary add partition(batch_nb='201803290000');   
   
   