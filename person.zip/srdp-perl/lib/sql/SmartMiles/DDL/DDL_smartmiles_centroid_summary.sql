CREATE EXTERNAL TABLE telematics_db.smartmiles_centroid_summary(
  enrolled_vin_nb varchar(128), 
  trip_summary_id varchar(128), 
  centroid_start_ts timestamp, 
  centroid_end_ts timestamp, 
  centroid_rpm_rt decimal(8,5), 
  min_scrubbed_speed_rt decimal(8,5), 
  max_scrubbed_speed_rt decimal(8,5), 
  min_delta_scrubbed_speed_rt decimal(8,5), 
  max_delta_scrubbed_speed_rt decimal(8,5), 
  absolute_speed_change_rt decimal(8,5), 
  scrubbed_speed_decreasing_cn int, 
  scrubbed_speed_increasing_cn int, 
  scrubbed_speed_steady_cn int, 
  end_scrubbed_speed_bump_in int, 
  plausible_in int, 
  plausibile_reason_ds string, 
  centroid_nb bigint, 
  source_cd string, 
  load_event_id decimal(18,0))
PARTITIONED BY ( 
  batch_nb string)
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_db/smartmiles_centroid_summary'
  ;
