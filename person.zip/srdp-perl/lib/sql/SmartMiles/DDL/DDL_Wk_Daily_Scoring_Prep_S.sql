DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Workdb.Wk_Daily_Scoring_Prep;

CREATE  TABLE pcdw_telematics_fnd_workdb.Wk_Daily_Scoring_Prep(
  sr_pgm_instnc_id BIGINT 
  ,device_id VARCHAR(128) 
  ,enrolled_vin_nb VARCHAR(128) 
  ,score_dt TIMESTAMP 
  ,fast_acceleration_cn INT 
  ,hard_brake_cn INT 
  ,stop_second_cn INT
  ,plausible_mile_cn DECIMAL(24,16)
  ,adjusted_mile_cn DECIMAL(24,16)
  ,plausible_drive_second_cn INT 
  ,plausible_idle_second_cn INT 
  ,plausible_no_idle_second_cn INT 
  ,plausible_pc DOUBLE 
  ,weighted_time_of_day_rt DECIMAL(8,5)
  ,stop_per_kilometer_rt DECIMAL(10,9)
  ,brake_per_kilometer_rt DECIMAL(10,9)
  )
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

