DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Workdb.WK_Daily_Mileage;

CREATE TABLE Pcdw_Telematics_Fnd_Workdb.WK_Daily_Mileage(
Enrolled_Vin_Nb VARCHAR(128)
,Mile_Cn DECIMAL(8,5)
,Device_Unavailable_Cn INT
,Disconnected_Status_Cn INT
,Trip_Dt Date
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE;
