DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_WorkDb.Wk_Centroid_Summary;

CREATE TABLE Pcdw_Telematics_Fnd_WorkDb.Wk_Centroid_Summary(
Enrolled_Vin_Nb VARCHAR(128)
,Trip_Summary_Id VARCHAR(128)
,Centroid_Start_Ts TIMESTAMP
,Centroid_End_Ts TIMESTAMP
,Centroid_Rpm_Rt  DECIMAL(8,5)
,Min_Scrubbed_Speed_Rt  DECIMAL(8,5)
,Max_Scrubbed_Speed_Rt DECIMAL(8,5)
,Min_Delta_Scrubbed_Speed_Rt DECIMAL(8,5)
,Max_Delta_Scrubbed_Speed_Rt DECIMAL(8,5)
,Absolute_Speed_Change_Rt DECIMAL(8,5)
,Scrubbed_Speed_Decreasing_Cn INT
,Scrubbed_Speed_Increasing_Cn INT
,Scrubbed_Speed_Steady_Cn INT
,End_Scrubbed_Speed_Bump_In INT
,Plausible_In INT
,Plausibile_Reason_Ds STRING
,Centroid_Nb BIGINT
,Batch_Nb STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

