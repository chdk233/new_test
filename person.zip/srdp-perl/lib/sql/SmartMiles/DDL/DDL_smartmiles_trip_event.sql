CREATE EXTERNAL TABLE telematics_db.smartmiles_trip_event(
  enrolled_vin_nb varchar(128), 
  trip_summary_id varchar(128), 
  average_speed_rt decimal(8,5), 
  trip_event_type_ds varchar(500), 
  trip_event_ts timestamp, 
  driving_seconds_cn bigint, 
  acceleration_rt decimal(8,5), 
  speed_rt decimal(8,5), 
  latitude_nb decimal(24,16), 
  longitude_nb decimal(24,16), 
  heading_degree_nb int, 
  load_event_id decimal(18,0), 
  source_cd string)
PARTITIONED BY ( 
  batch_nb string)
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_db/smartmiles_trip_event'
  ;