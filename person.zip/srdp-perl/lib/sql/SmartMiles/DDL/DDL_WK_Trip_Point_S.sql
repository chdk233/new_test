DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Workdb.Wk_Trip_Point;

CREATE TABLE Pcdw_Telematics_Fnd_Workdb.Wk_Trip_Point (
Trip_Summary_Id VARCHAR(128),
Engine_Rpm_Rt DECIMAL(8,5),
Position_Ts TIMESTAMP,
Speed_Kph_Rt DECIMAL(8,5),
Latitude_Nb DECIMAL(24,16),
Longitude_Nb DECIMAL(24,16),
Batch_Nb STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE;
