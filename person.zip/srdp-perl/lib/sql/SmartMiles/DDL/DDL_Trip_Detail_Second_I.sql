DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Db.Trip_Detail_Second;

CREATE EXTERNAL TABLE Pcdw_Telematics_Fnd_Db.Trip_Detail_Second(
  enrolled_vin_nb varchar(128), 
  trip_summary_id varchar(128), 
  device_id varchar(128), 
  position_ts timestamp, 
  position_offset_ts timestamp, 
  time_zone_offset_nb int, 
  speed_mph_rt decimal(8,5), 
  speed_kph_rt decimal(8,5), 
  engine_rpm_rt decimal(8,5), 
  mile_cn decimal(8,5), 
  kilometer_cn decimal(8,5), 
  fast_acceleration_cn INT, 
  hard_brake_cn INT, 
  driving_second_cn INT, 
  idle_second_cn INT, 
  stop_second_cn INT, 
  night_time_driving_second_cn INT, 
  plausible_second_cn INT, 
  centroid_nb bigint, 
  scrubbed_field_nb int, 
  latitude_nb decimal(9,6), 
  longitude_nb decimal(9,6), 
  source_cd string, 
  load_event_id decimal(18,0))
PARTITIONED BY ( 
  batch_nb string)
STORED AS ORC;