DROP TABLE IF EXISTS pcdw_telematics_fnd_workdb.WK_Trip_Summary;

CREATE TABLE pcdw_telematics_fnd_workdb.WK_Trip_Summary(
Enrolled_Vin_Nb VARCHAR(128),
Trip_Summary_Id VARCHAR(128),
Device_Id VARCHAR(128),
Time_Zone_Offset_Nb INT,
Batch_Nb STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE;
