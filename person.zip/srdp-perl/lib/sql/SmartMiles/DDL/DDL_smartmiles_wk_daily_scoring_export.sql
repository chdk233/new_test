CREATE EXTERNAL TABLE telematics_work_db.smartmiles_wk_daily_scoring_export(
`col1` string)
STORED AS TEXTFILE
LOCATION
's3://dw-telematics-dev/warehouse/telematics_work_db/smartmiles_wk_daily_scoring_export';