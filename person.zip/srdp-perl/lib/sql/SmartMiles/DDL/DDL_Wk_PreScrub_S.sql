DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Workdb.Wk_Prescrub;

CREATE TABLE Pcdw_Telematics_Fnd_Workdb.Wk_Prescrub(
Enrolled_Vin_Nb VARCHAR(128),
Trip_Summary_Id VARCHAR(128),
Device_Id VARCHAR(128),
Position_Ts TIMESTAMP,
Time_Zone_Offset_Nb BIGINT,
Speed_Kph_Rt DECIMAL(8,5),
Engine_Rpm_Rt DECIMAL(8,5),
Latitude_Nb DECIMAL(24,16),
Longitude_Nb DECIMAL(24,16),
Source_Cd STRING,
Batch_Nb STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE;