CREATE EXTERNAL TABLE telematics_provide_db.smartmiles_annual_mileage(
  sr_pgm_instnc_id bigint, 
  device_id bigint, 
  enrolled_vin_nb string, 
  plcy_ratd_st_cd string, 
  start_ts timestamp, 
  end_ts timestamp, 
  connected_day_cn bigint, 
  device_connected_pc double, 
  device_disconnected_pc double, 
  plausible_speed_pcnt double, 
  tier1_10avg decimal(10,0), 
  tier11_30avg decimal(10,0), 
  tier31_70avg decimal(10,0), 
  tier71_90avg decimal(10,0), 
  tier91_100avg decimal(10,0), 
  estimatedkilometers double, 
  estimatedmileage double)
PARTITIONED BY ( 
  load_date string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ',' 
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_provide_db/smartmiles_annual_mileage'
 ;