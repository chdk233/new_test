CREATE EXTERNAL TABLE telematics_db.smartmiles_device_status(
  device_id varchar(128), 
  sr_pgm_instnc_id bigint, 
  enrolled_vin_nb varchar(128), 
  connected_status_in char(1), 
  status_start_ts timestamp, 
  status_end_ts timestamp, 
  last_device_activity_ts timestamp, 
  device_unavailable_in char(1))
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ',' 
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_db/smartmiles_device_status'
  ;