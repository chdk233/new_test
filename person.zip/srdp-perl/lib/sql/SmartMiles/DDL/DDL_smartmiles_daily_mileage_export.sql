CREATE EXTERNAL TABLE telematics_provide_db.smartmiles_daily_mileage_export(
  enrolled_vin_nb varchar(128), 
  mile_cn decimal(18,5), 
  device_unavailable_in int, 
  disconnected_status_in int, 
  trip_dt date)
PARTITIONED BY ( 
  load_dt date)
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_provide_db/smartmiles_daily_mileage_export'
  ;