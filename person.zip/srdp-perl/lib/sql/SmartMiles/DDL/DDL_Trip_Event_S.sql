ADD JAR hdfs://BIGIDEV/user/mehtrs1/json-serde-1.3.7-jar-with-dependencies.jar;

DROP TABLE IF EXISTS Pcdw_Telematics_Stg_Db.Trip_Event;

CREATE EXTERNAL TABLE Pcdw_Telematics_Stg_Db.Trip_Event(
vehicle STRUCT<
Enrolled_Vin_Nb: STRING>,
Trip_Summary_Id STRING,
telemetryEvents ARRAY < STRUCT <
Driving_Second_Cn: STRING,
Acceleration_Rt: STRING,
Average_Speed_Rt: STRING,
Speed_Rt: STRING,
Event_Type_Ds: STRING,
Event_Ts: STRING ,
Latitude_Nb: STRING,
Longitude_Nb: STRING,
Heading_Degree_Nb: STRING>>
)
PARTITIONED BY (Batch_Nb STRING)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES(
"case.insensitive" = "false",
"mapping.trip_summary_id" = "tripSummaryId",
"mapping.enrolled_vin_nb" = "enrolledVin",
"mapping.acceleration_rt" = "acceleration",
"mapping.average_speed_rt" = "avgSpeed",
"mapping.driving_second_cn" = "secondsOfDriving",
"mapping.event_type_ds" = "telemetryEventType",
"mapping.event_ts" = "utcDateTime",
"mapping.speed_rt"="speed",
"mapping.latitude_nb"="degreesLatitude",
"mapping.longitude_nb"="degreesLongitude",
"mapping.heading_degree_nb"="headingDegrees"
)
LOCATION '/Programs/SmartRide/SmartMiles';
