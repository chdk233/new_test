DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Workdb.Wk_Trip_Detail_Hourly;

CREATE TABLE Pcdw_Telematics_Fnd_Workdb.Wk_Trip_Detail_Hourly(
  Enrolled_Vin_Nb varchar(128), 
  Trip_Summary_Id varchar(128), 
  Device_Id varchar(128), 
  Period_Start_Ts timestamp, 
  Period_End_Ts timestamp, 
  Period_Start_Hour_Ts timestamp, 
  Period_End_Hour_Ts timestamp, 
  Mile_Cn decimal(8,5), 
  Adjusted_Mile_Cn decimal(8,5), 
  Plausible_Mile_Cn decimal(8,5), 
  Kilometer_Cn decimal(8,5), 
  Adjusted_Kilometer_Cn decimal(8,5), 
  Plausible_Kilometer_Cn decimal(8,5), 
  Fast_Acceleration_Cn int, 
  Hard_Brake_Cn int, 
  Driving_Second_Cn int, 
  Idle_Second_Cn int, 
  Stop_Second_Cn int, 
  Night_Time_Driving_Second_Cn int, 
  Plausible_Second_Cn int, 
  Plausible_Drive_Second_Cn int, 
  Plausible_Idle_Second_Cn int, 
  Speed_Mph_Json_Tt array<decimal(8,5)>, 
  Fast_Acceleration_Json_Tt string, 
  Hard_Brake_Json_Tt string,
  Stop_Second_Json_Tt string, 
  Latitude_Longitude_Json_Tt string, 
  Source_Cd string, 
  Batch_Nb string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY  ',' 
STORED AS TEXTFILE;