DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Db.Daily_Mileage_Export;

CREATE EXTERNAL TABLE Pcdw_Telematics_Fnd_Db.Daily_Mileage_Export(
Enrolled_Vin_Nb VARCHAR(128)
,Mile_Cn DECIMAL(8,5)
,Device_Unavailable_In INT
,Disconnected_Status_In INT
,Trip_Dt DATE)
PARTITIONED BY (Load_Dt DATE)
STORED AS ORC;