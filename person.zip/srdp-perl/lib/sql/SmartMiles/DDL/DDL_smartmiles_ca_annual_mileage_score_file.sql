CREATE EXTERNAL TABLE  telematics_provide_db.smartmiles_ca_annual_mileage_score_file(
`col1` string)
STORED AS TEXTFILE
LOCATION
's3://dw-telematics-dev/warehouse/telematics_provide_db/smartmiles_ca_annual_mileage_score_file';