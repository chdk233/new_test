DROP TABLE IF EXISTS Pcdw_Telematics_Fnd_Db.Device_Status;

CREATE TABLE Pcdw_Telematics_Fnd_Db.Device_Status(
  Device_Id VARCHAR(128), 
  Sr_Pgm_Instnc_Id BIGINT, 
  Enrolled_Vin_Nb VARCHAR(128), 
  Connected_Status_In CHAR(1),
  status_start_ts TIMESTAMP, 
  status_end_ts TIMESTAMP, 
  last_device_activity_ts TIMESTAMP,
  device_unavailable_in CHAR(1))
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY ',' 
STORED AS TEXTFILE;