DROP VIEW IF EXISTS Pcdw_Telematics_Rpt_Db.Trip_Summary;
CREATE VIEW Pcdw_Telematics_Rpt_Db.Trip_Summary
AS
SELECT
CAST(Vehicle.Enrolled_Vin_Nb AS VARCHAR(128)) AS Enrolled_Vin_Nb,
CAST(Vehicle.Detected_Vin_Nb AS VARCHAR(128)) AS Detected_Vin_Nb,
CAST(Trip_Summary_Id AS VARCHAR(128)) AS Trip_Summary_Id,
CAST(Device.Device_Id AS VARCHAR(128)) AS Device_Id,
CAST(Device.Device_Identifier_Type_Nm AS VARCHAR(100)) AS Device_Identifier_Type_Nm,
CAST(Device.Device_Type_Nm AS VARCHAR(100)) AS Device_Type_Nm,
CAST(Device.Device_Serial_Nb AS VARCHAR(128)) AS Device_Serial_Nb,
From_Unixtime(Unix_Timestamp(Trip_Start_Ts, "yyyy-mm-dd'T'HH:MM:ss.SSS")) AS Trip_Start_Ts,
From_Unixtime(Unix_Timestamp(Trip_End_Ts, "yyyy-mm-dd'T'HH:MM:ss.SSS")) AS Trip_End_Ts,
CAST(Time_Zone_Offset_Nb AS BIGINT) AS Time_Zone_Offset_Nb,
CAST(Average_Speed_Rt AS DECIMAL(8,5)) AS Average_Speed_Rt,
CAST(Maximum_Speed_Rt AS DECIMAL(8,5)) AS Maximum_Speed_Rt,
CAST(Driving_Distance_Cn AS DECIMAL(8,5)) AS Driving_Distance_Qt,
CAST(Trip_Second_Cn AS BIGINT) AS Trip_Second_Cn,
CAST(Trip_Idling_Second_Cn AS BIGINT) AS Trip_Idling_Second_Cn,
Fuel_Consumption_Qt,
CAST(Average_Hdop_Rt AS DECIMAL(8,5)) AS Average_Hdop_Rt,
CAST(Acceleration_Quality_In AS VARCHAR(5)) AS Acceleration_Quality_In,
Malfunction_Status_In,
CAST(Measurementunit.Measure_Unit_Ds AS VARCHAR(20)) AS Measure_Unit_Ds,
CAST(Transport_Mode_Change_Ds AS VARCHAR(20)) AS Transport_Mode_Change_Ds,
CAST(Transport_Mode_Change_Reason_Ds AS VARCHAR(20)) AS Transport_Mode_Change_Reason_Ds,
Batch_Nb
FROM Pcdw_Telematics_Stg_Db.Trip_Summary;
