DROP TABLE IF EXISTS pcdw_telematics_fnd_workdb.Wk_Daily_Scoring_Export;

CREATE TABLE pcdw_telematics_fnd_workdb.Wk_Daily_Scoring_Export (
col1 string)
STORED AS TEXTFILE;