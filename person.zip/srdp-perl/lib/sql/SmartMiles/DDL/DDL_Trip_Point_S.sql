DROP TABLE IF EXISTS Pcdw_Telematics_Stg_Db.Trip_Point;

CREATE EXTERNAL TABLE Pcdw_Telematics_Stg_Db.Trip_Point(
Trip_Summary_Id STRING,
Engine_Rpm_Rt STRING,
telemetryPoints ARRAY <STRUCT <
Acceleration_Rt: STRING,
Latitude_Nb:  STRING,
Longitude_Nb: STRING,
Heading_Degree_Nb: STRING,
Position_Ts: STRING,
Speed_Rt: STRING,
Accelerometer_Data_Tt: STRING,
Average_Hdop_Nb: STRING,
Horizontal_Accuracy_Nb: STRING,
Vertical_Accuracy_Nb: STRING,
Ambient_Temperature_Cn: STRING,
Barometric_Pressure_Cn: STRING,
Coolant_Temperature_Cn: STRING,
Fuel_Level_Qt: STRING,
Throttle_Position_Nb : STRING>>
)
PARTITIONED BY (Batch_Nb STRING)
ROW FORMAT SERDE 'org.openx.data.jsonserde.JsonSerDe'
WITH SERDEPROPERTIES(
"case.insensitive" = "false",
"mapping.trip_summary_id" = "tripSummaryId",
"mapping.engine_rpm_rt" = "engineRPM",
"mapping.acceleration_rt" = "acceleration",
"mapping.latitude_nb" = "degreesLatitude",
"mapping.longitude_nb" = "degreesLongitude",
"mapping.heading_degree_nb" = "headingDegrees",
"mapping.position_ts"="utcDateTime",
"mapping.speed_rt"="speed",
"mapping.accelerometer_data_tt"="accelerometerData",
"mapping.average_hdop_nb"="hdop",
"mapping.horizontal_accuracy_nb"="horizontalAccuracy",
"mapping.vertical_accuracy_nb"="verticalAccuracy",
"mapping.ambient_temperature_cn"="ambientTemperature",
"mapping.barometric_pressure_cn"="barometricPressure",
"mapping.coolant_temperature_cn"="coolantTemperature",
"mapping.fuel_level_qt"="fuelLevel",
"mapping.throttle_position_nb"="throttlePosition"
)
LOCATION '/Programs/SmartRide/SmartMiles';


--alter table pcdw_telematics_stg_db.Trip_Point add partition(batch_nb='201803290000');   