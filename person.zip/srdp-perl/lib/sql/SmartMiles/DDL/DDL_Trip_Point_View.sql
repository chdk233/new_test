DROP VIEW IF EXISTS Pcdw_Telematics_Rpt_Db.Trip_Point;
CREATE VIEW Pcdw_Telematics_Rpt_Db.Trip_Point
AS
SELECT CAST(Trip_Summary_Id AS VARCHAR(128)) AS Trip_Summary_Id,
CAST(Telemetrypoints_Ts.Acceleration_Rt AS DECIMAL(8,5)) AS Acceleration_Rt,
CAST(Telemetrypoints_Ts.Latitude_Nb AS DECIMAL(24,16)) AS Latitude_Nb,
CAST(Telemetrypoints_Ts.Longitude_Nb AS DECIMAL(24,16)) AS Longitude_Nb,
CAST(Telemetrypoints_Ts.Heading_Degree_Nb AS INT) AS Heading_Degree_Nb,
From_Unixtime(Unix_Timestamp(Telemetrypoints_Ts.Position_Ts, "yyyy-mm-dd'T'HH:MM:ss.SSS")) AS Position_Ts,
CAST(Telemetrypoints_Ts.Speed_Rt AS DECIMAL(24,16)) AS Speed_Rt,
CAST(Telemetrypoints_Ts.Engine_Rpm_Rt AS DECIMAL(8,5)) AS Engine_Rpm_Rt,
CAST(Telemetrypoints_Ts.Accelerometer_Data_Tt AS VARCHAR(100)) AS Accelerometer_Data_Tt,
CAST(Telemetrypoints_Ts.Average_Hdop_Nb AS DECIMAL(8,5)) AS Average_Hdop_Nb,
CAST(Telemetrypoints_Ts.Horizontal_Accuracy_Nb AS DECIMAL(8,5)) AS Horizontal_Accuracy_Nb,
CAST(Telemetrypoints_Ts.Vertical_Accuracy_Nb AS DECIMAL(8,5)) AS Vertical_Accuracy_Nb,
Telemetrypoints_Ts.Ambient_Temperature_Cn AS Ambient_Temperature_Cn,
Telemetrypoints_Ts.Barometric_Pressure_Cn AS Barometric_Pressure_Cn,
Telemetrypoints_Ts.Coolant_Temperature_Cn AS Coolant_Temperature_Cn,
Telemetrypoints_Ts.Fuel_Level_Qt AS Fuel_Level_Qt,
Telemetrypoints_Ts.Throttle_Position_Nb AS Throttle_Position_Nb,
Batch_Nb
FROM Pcdw_Telematics_Stg_Db.Trip_Point
LATERAL VIEW EXPLODE(Telemetrypoints) EXPLODED_TABLE AS Telemetrypoints_Ts;
