 CREATE EXTERNAL TABLE telematics_db.smartmiles_trip_detail_hourly(
  enrolled_vin_nb varchar(128), 
  trip_summary_id varchar(128), 
  device_id varchar(128), 
  period_start_ts timestamp, 
  period_end_ts timestamp, 
  period_start_hour_ts timestamp, 
  period_end_hour_ts timestamp, 
  mile_cn decimal(8,5), 
  adjusted_mile_cn decimal(8,5), 
  plausible_mile_cn decimal(8,5), 
  kilometer_cn decimal(8,5), 
  adjusted_kilometer_cn decimal(8,5), 
  plausible_kilometer_cn decimal(8,5), 
  fast_acceleration_cn int, 
  hard_brake_cn int, 
  driving_second_cn int, 
  idle_second_cn int, 
  stop_second_cn int, 
  night_time_driving_second_cn int, 
  plausible_second_cn int, 
  plausible_drive_second_cn int, 
  plausible_idle_second_cn int, 
  speed_mph_json_tt array<double>, 
  fast_acceleration_json_tt string, 
  hard_brake_json_tt string, 
  stop_second_json_tt string, 
  latitude_longitude_json_tt string, 
  source_cd string, 
  load_event_id decimal(18,0))
PARTITIONED BY ( 
  batch_nb string)
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_db/smartmiles_trip_detail_hourly'
 ;