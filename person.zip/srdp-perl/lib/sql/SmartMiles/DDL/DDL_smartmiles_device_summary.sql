CREATE EXTERNAL TABLE telematics_db.smartmiles_device_summary(
  device_id varchar(128), 
  sr_pgm_instnc_id bigint, 
  enrolled_vin_nb varchar(128), 
  start_ts timestamp, 
  end_ts timestamp, 
  lifetime_second_cn bigint, 
  connected_second_cn bigint, 
  connected_status_cn int, 
  disconnected_second_cn bigint, 
  disconnected_status_cn int, 
  lifetime_day_cn int, 
  connected_day_cn int, 
  device_unavailable_cn int, 
  device_connected_pc double, 
  device_disconnected_pc double)
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_db/smartmiles_device_summary'
  ;