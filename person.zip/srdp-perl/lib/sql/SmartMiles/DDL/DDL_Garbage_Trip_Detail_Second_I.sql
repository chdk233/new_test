DROP TABLE IF EXISTS pcdw_telematics_fnd_db.garbage_trip_detail_second;

CREATE EXTERNAL TABLE pcdw_telematics_fnd_db.garbage_trip_detail_second 
(
enrolled_vin_nb	VARCHAR(128) 
,trip_summary_id	VARCHAR(128)
,device_id	VARCHAR(128)     
,position_ts	TIMESTAMP      
,position_offset_ts	TIMESTAMP
,time_zone_offset_nb	INT 
,speed_mph_rt	DECIMAL(8,5)   
,speed_kph_rt	DECIMAL(8,5)
,engine_rpm_rt	DECIMAL(8,5) 
,mile_cn	DECIMAL(8,5)    
,kilometer_cn DECIMAL(8,5)
,fast_acceleration_cn	INT
,hard_brake_cn	INT      
,driving_second_cn	INT  
,idle_second_cn	INT      
,stop_second_cn	INT      
,night_time_driving_second_cn INT
,plausible_second_cn	INT
,centroid_nb	BIGINT         
,scrubbed_field_nb	INT  
,latitude_nb	DECIMAL(9,6)   
,longitude_nb	DECIMAL(9,6)   
,source_cd	STRING           
,load_event_id	DECIMAL(18,0)
)	  
PARTITIONED BY ( 
batch_nb STRING)
STORED AS ORC;