CREATE EXTERNAL TABLE telematics_provide_db.smartmiles_annual_mileage_score(
  deviceserial_nb string, 
  policy_nb string, 
  enrolledvin_nb string, 
  score_dt string, 
  tripstart_dt string, 
  tripend_dt string, 
  score_days string, 
  percenttime_disconnected string, 
  score_1 string, 
  score_2 string, 
  score_3 string, 
  score_4 string, 
  score_5 string, 
  score_6 string, 
  score_7 string, 
  score_8 string, 
  score_9 string, 
  score_10 string, 
  floor_estimatedkilometers string, 
  filler string)
PARTITIONED BY ( 
  score_date string)
ROW FORMAT DELIMITED 
  FIELDS TERMINATED BY '\u0001' 
STORED AS PARQUET
LOCATION
  's3://dw-telematics-dev/warehouse/telematics_provide_db/smartmiles_annual_mileage_score'
  ;