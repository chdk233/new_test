SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_device_vin from smartride_smt_ods_bigin_pgm_instnc_orc";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_device_vin;

CREATE TABLE ~>work_db.smartmiles_wk_device_vin(
  sr_pgm_instnc_id string, 
  vhcl_id_nbr string, 
  device_id bigint, 
  plcy_ratd_st_cd string,
  active_end_dt timestamp,
  active_start_dt timestamp)  
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_device_vin';

INSERT INTO TABLE ~>work_db.smartmiles_wk_device_vin
  SELECT DISTINCT
                 sr_pgm_instnc_id  
                 ,vhcl_id_nbr
                 ,dev_id_nbr as device_id
                 ,plcy_ratd_st_cd
                 ,active_end_dt
                 ,active_start_dt
  FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc
  WHERE  plcy_ratd_st_cd = 'CA'
  AND    date(active_end_dt) = date('3500-01-01');

INSERT INTO TABLE ~>work_db.smartmiles_wk_device_vin   
  SELECT DISTINCT
                 pe.DATA_CLCTN_ID as sr_pgm_instnc_id  
                 ,pe.VIN_NB as vhcl_id_nbr
                 ,pe.DEVC_ID as device_id
                 ,pe.PLCY_ST_CD as plcy_ratd_st_cd
                 ,pe.PRGRM_TERM_END_DT as active_end_dt
                 ,pe.PRGRM_TERM_BEG_DT as active_start_dt
  FROM (select distinct(p.VIN_NB), p.EVNT_SYS_TS, p.PRGRM_TERM_BEG_DT, p.PRGRM_TERM_END_DT, p.PRGRM_STTS_CD, p.DATA_CLCTN_STTS, p.DATA_CLCTN_ID, p.DEVC_ID, p.PLCY_ST_CD
        from ~>staging_db.program_enrollment p
		inner join
		(select max(EVNT_SYS_TS) as max_time, VIN_NB 
		from  ~>staging_db.program_enrollment pe
		where PRGRM_STTS_CD = 'Active' and DATA_CLCTN_STTS = 'Active'
		GROUP BY VIN_NB
		) p2  
		on p.VIN_NB = p2.VIN_NB
		and p.EVNT_SYS_TS = p2.max_time) pe

WHERE  pe.PRGRM_STTS_CD = 'Active'
AND pe.DATA_CLCTN_STTS = 'Active'
AND pe.PLCY_ST_CD = 'CA'
AND pe.VIN_NB NOT IN 
(SELECT DISTINCT vhcl_id_nbr
  FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc
  WHERE  plcy_ratd_st_cd = 'CA'
  AND    date(active_end_dt) = date('3500-01-01'));

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_hive_sre_daily;

CREATE TABLE ~>work_db.smartmiles_wk_hive_sre_daily(
  sr_pgm_instnc_id string, 
  enrolled_vin_nb varchar(128), 
  device_id bigint, 
  plcy_ratd_st_cd string, 
  trip_date varchar(10), 
  miles decimal(18,5), 
  kilometer_cn decimal(18,5), 
  adjusted_miles decimal(18,5), 
  adjusted_kilometer_cn decimal(18,5), 
  plausible_miles decimal(18,5), 
  plausible_kilometer_cn decimal(18,5), 
  idle_second_cn bigint, 
  plausible_idle_second_cn bigint, 
  driving_second_cn bigint, 
  plausible_drive_second_cn bigint)
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_hive_sre_daily';

SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_hive_sre_daily from smartmiles_wk_trip_detail_hourly";

INSERT INTO TABLE ~>work_db.smartmiles_wk_hive_sre_daily
  SELECT wdv.sr_pgm_instnc_id,
         wtd.enrolled_vin_nb,
         wdv.device_id,
         wdv.plcy_ratd_st_cd,
         CAST(wtd.period_start_ts AS VARCHAR(10)) AS trip_date,
         SUM(wtd.mile_cn) AS miles,   
         SUM(wtd.kilometer_cn) as kilometer_cn,
         SUM(wtd.adjusted_mile_cn) AS adjusted_miles,
         SUM(wtd.adjusted_kilometer_cn) as adjusted_kilometer_cn,
         SUM(wtd.plausible_mile_cn) AS plausible_miles,
         SUM(wtd.plausible_kilometer_cn) as plausible_kilometer_cn,
         SUM(wtd.idle_second_cn) AS idle_second_cn,
         SUM(wtd.plausible_idle_second_cn) AS plausible_idle_second_cn,
         SUM(wtd.driving_second_cn) AS driving_second_cn,
         SUM(wtd.plausible_drive_second_cn) AS plausible_drive_second_cn

  FROM  ~>foundation_db.smartmiles_trip_detail_hourly  wtd
  JOIN ~>work_db.smartmiles_wk_device_vin   wdv
  ON wtd.enrolled_vin_nb = wdv.vhcl_id_nbr
      AND    wtd.period_start_ts >= wdv.active_start_dt
      AND    wtd.period_start_ts < wdv.active_end_dt
      AND    date(wdv.active_start_dt) >= add_months(current_date,-18)

  GROUP  BY wdv.sr_pgm_instnc_id,
            wdv.device_id,
            wtd.enrolled_vin_nb,
            wdv.plcy_ratd_st_cd,
            CAST(wtd.period_start_ts AS VARCHAR(10)) ; 
      
DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_device_summary; 

CREATE TABLE ~>work_db.smartmiles_wk_device_summary(
  sr_pgm_instnc_id string, 
  device_id bigint, 
  enrolled_vin_nb varchar(128), 
  start_ts timestamp, 
  end_ts timestamp, 
  lifetime_day_cn int, 
  connected_day_cn int, 
  device_connected_pc double, 
  device_disconnected_pc double, 
  plcy_ratd_st_cd string)
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_device_summary';

SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_device_summary from smartmiles_device_summary, smartmiles_wk_device_vin";

INSERT INTO TABLE ~>work_db.smartmiles_wk_device_summary
SELECT cdv.sr_pgm_instnc_id
,cdv.device_id
,ds.enrolled_vin_nb
,ds.start_ts
,ds.end_ts
,ds.lifetime_day_cn
,ds.connected_day_cn
,ds.device_connected_pc
,ds.device_disconnected_pc
,cdv.plcy_ratd_st_cd
  FROM  ~>foundation_db.smartmiles_device_summary   ds
         INNER JOIN ~>work_db.smartmiles_wk_device_vin  cdv
                 ON ds.enrolled_vin_nb = cdv.vhcl_id_nbr
                AND	ds.start_ts >= cdv.active_start_dt 
                AND	ds.start_ts < cdv.active_end_dt 
                AND	date(cdv.active_start_dt) >= add_months(current_date,-18);

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_device_active_days;

CREATE TABLE ~>work_db.smartmiles_wk_device_active_days(
  sr_pgm_instnc_id string, 
  device_id bigint, 
  enrolled_vin_nb varchar(128), 
  trip_dt string, 
  start_ts timestamp, 
  end_ts timestamp, 
  lifetime_day_cn int, 
  connected_day_cn int, 
  device_connected_pc double, 
  device_disconnected_pc double, 
  plcy_ratd_st_cd string)
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_device_active_days';

SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_device_active_days from smartmiles_wk_device_summary ";

INSERT INTO TABLE ~>work_db.smartmiles_wk_device_active_days
SELECT sr_pgm_instnc_id,
       device_id,
       enrolled_vin_nb,
       Date_add(Cast(Cast(start_ts AS VARCHAR(10)) AS DATE), Cast(day_id AS INT)) AS trip_dt,
       start_ts,
       end_ts,
       lifetime_day_cn,
       connected_day_cn,
       device_connected_pc,
       device_disconnected_pc,
       plcy_ratd_st_cd 
FROM  ~>work_db.smartmiles_wk_device_summary
JOIN ~>provide_db.days d
WHERE d.day_id <= lifetime_day_cn ;

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_annual_mileage;

CREATE TABLE ~>work_db.smartmiles_wk_annual_mileage(
  sr_pgm_instnc_id string, 
  device_id bigint, 
  enrolled_vin_nb varchar(128), 
  plcy_ratd_st_cd string, 
  start_ts timestamp, 
  end_ts timestamp, 
  connected_day_cn int, 
  device_connected_pc double, 
  device_disconnected_pc double, 
  plausible_speed_pcnt double, 
  tier1_10avg decimal(10,0), 
  tier11_30avg decimal(10,0), 
  tier31_70avg decimal(10,0), 
  tier71_90avg decimal(10,0), 
  tier91_100avg decimal(10,0), 
  estimatedkilometers double, 
  estimatedmileage double, 
  floor_estimatedkilometers bigint, 
  rate_in string, 
  load_date varchar(10))
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_annual_mileage';

SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_annual_mileage from smartmiles_wk_device_active_days, smartmiles_wk_hive_sre_daily";

INSERT INTO TABLE ~>work_db.smartmiles_wk_annual_mileage
SELECT
 S4.sr_pgm_instnc_id
,S4.device_id
,S4.enrolled_vin_nb
,S4.plcy_ratd_st_cd
,S4.start_ts
,S4.end_ts
,S4.connected_day_cn
,S4.device_connected_pc
,S4.device_disconnected_pc
,S4.plausible_speed_pcnt
,S4.Tier1_10Avg
,S4.Tier11_30Avg
,S4.Tier31_70Avg
,S4.Tier71_90Avg
,S4.Tier91_100Avg
,(365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) ) AS EstimatedKilometers
,((365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) ) /1.609344) AS EstimatedMileage
,FLOOR((365*(8.4703+ (S4.Tier1_10Avg  * 0.0248)+ (S4.Tier11_30Avg * 0.2034)+ (S4.Tier31_70Avg * 0.3278)+ (S4.Tier71_90Avg * 0.2210) + (S4.Tier91_100Avg * 0.0678)) )) AS Floor_EstimatedKilometers
,CASE WHEN (S4.device_disconnected_pc > 5 OR S4.plausible_speed_pcnt < 97) THEN 'N' ELSE 'Y' END AS RATE_IN
,CAST (from_unixtime(unix_timestamp()) AS varchar(10)) AS load_date
FROM
(
SELECT
 S3.sr_pgm_instnc_id
,S3.device_id
,S3.enrolled_vin_nb
,S3.start_ts
,S3.end_ts
,S3.connected_day_cn
,S3.device_connected_pc
,S3.device_disconnected_pc
,S3.plausible_speed_pcnt
,CASE WHEN S3.Tier00_10Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier1_10Dist / S3.Tier00_10Obs_Ct) AS DECIMAL) END AS Tier1_10Avg
,CASE WHEN S3.Tier11_30Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier11_30Dist / S3.Tier11_30Obs_Ct) AS DECIMAL) END AS Tier11_30Avg
,CASE WHEN S3.Tier31_70Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier31_70Dist / S3.Tier31_70Obs_Ct) AS DECIMAL) END AS Tier31_70Avg
,CASE WHEN S3.Tier71_90Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL)  ELSE CAST((S3.Tier71_90Dist / S3.Tier71_90Obs_Ct) AS DECIMAL) END AS Tier71_90Avg
,CASE WHEN S3.Tier91_100Obs_Ct = 0.00 THEN CAST(0.00 AS DECIMAL) ELSE CAST((S3.Tier91_100Dist / S3.Tier91_100Obs_Ct) AS DECIMAL) END AS Tier91_100Avg
--,EstimatedKilometers/1.609344 AS EstimatedMileage
,s3.plcy_ratd_st_cd
FROM
(
SELECT
 s2.sr_pgm_instnc_id
,s2.device_id
,s2.enrolled_vin_nb
,s2.start_ts
,s2.end_ts
,s2.connected_day_cn
,s2.device_connected_pc
,s2.device_disconnected_pc
,CASE WHEN (SUM(s2.idle_second_cn) + SUM(s2.driving_second_cn)) = 0 THEN 0.00
     ELSE (((SUM(s2.plausible_idle_second_cn)  + SUM(s2.plausible_drive_second_cn))/(SUM(s2.idle_second_cn) + SUM(s2.driving_second_cn))) * 100)
     END AS plausible_speed_pcnt
,SUM(CASE WHEN S2.PctRank < 0.10 THEN 1.00 ELSE 0.00 END)   AS Tier00_10Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.10 AND S2.PctRank < 0.30 THEN 1.00 ELSE 0.00 END)  AS Tier11_30Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.30  AND S2.PctRank < 0.70 THEN 1.00 ELSE 0.00 END)  AS Tier31_70Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.70 AND S2.PctRank < 0.90 THEN 1.00 ELSE 0.00 END)  AS Tier71_90Obs_Ct
,SUM(CASE WHEN S2.PctRank >= 0.90  THEN 1.00 ELSE 0.00 END)  AS Tier91_100Obs_Ct
,SUM(CASE WHEN S2.PctRank < 0.10 THEN S2.Distance_kms ELSE 0.00 END)  AS Tier1_10Dist
,SUM(CASE WHEN S2.PctRank >= 0.10 AND S2.PctRank < 0.30 THEN S2.Distance_kms ELSE 0.00 END)  AS  Tier11_30Dist
,SUM(CASE WHEN S2.PctRank >= 0.30  AND S2.PctRank < 0.70 THEN S2.Distance_kms ELSE 0.00 END) AS  Tier31_70Dist
,SUM(CASE WHEN  S2.PctRank >= 0.70 AND S2.PctRank < 0.90 THEN S2.Distance_kms ELSE 0.00 END) AS  Tier71_90Dist
,SUM(CASE WHEN S2.PctRank >= 0.90 THEN S2.Distance_kms ELSE 0.00 END)  AS Tier91_100Dist
,s2.plcy_ratd_st_cd
FROM
(
SELECT
s1.sr_pgm_instnc_id,
s1.device_id ,
s1.enrolled_vin_nb,
s1.Distance_kms,
s1.start_ts,
s1.end_ts,
s1.lifetime_day_cn,
s1.connected_day_cn,
s1.device_connected_pc,
s1.device_disconnected_pc,
s1.plausible_idle_second_cn,
s1.plausible_drive_second_cn,
s1.idle_second_cn,
s1.driving_second_cn,
s1.RankDistance,
s1.Obs_Ct,
CAST((s1.RankDistance / s1.Obs_Ct ) AS DECIMAL ) AS PctRank,
s1.plcy_ratd_st_cd
FROM
(
SELECT
dad.sr_pgm_instnc_id,
dad.device_id ,
dad.enrolled_vin_nb,
CASE WHEN (kilometer_cn IS NULL) THEN 0.00 ELSE kilometer_cn END AS Distance_kms,
start_ts,
end_ts,
lifetime_day_cn,
(connected_day_cn + 1) AS connected_day_cn,
device_connected_pc,
device_disconnected_pc,
CASE WHEN (idle_second_cn IS NULL) THEN CAST(0 AS BIGINT) ELSE idle_second_cn END AS idle_second_cn,
CASE WHEN (plausible_idle_second_cn IS NULL) THEN CAST(0 AS BIGINT) ELSE plausible_idle_second_cn END AS plausible_idle_second_cn,
CASE WHEN (driving_second_cn IS NULL) THEN CAST(0 AS BIGINT) ELSE driving_second_cn END AS driving_second_cn,
CASE WHEN (plausible_drive_second_cn IS NULL) THEN CAST(0 AS BIGINT) ELSE plausible_drive_second_cn END AS plausible_drive_second_cn,
ROW_NUMBER() OVER(PARTITION BY dad.sr_pgm_instnc_id, dad.device_id, dad.enrolled_vin_nb ORDER BY kilometer_cn) AS RankDistance,
COUNT(*) OVER(PARTITION BY dad.sr_pgm_instnc_id, dad.device_id, dad.enrolled_vin_nb) AS Obs_Ct,
dad.plcy_ratd_st_cd
FROM
~>work_db.smartmiles_wk_device_active_days dad
JOIN
~>work_db.smartmiles_wk_hive_sre_daily hsd
ON dad.enrolled_vin_nb = hsd.enrolled_vin_nb
AND dad.Trip_Dt = hsd.trip_date
) s1 )s2
GROUP BY
s2.sr_pgm_instnc_id
,s2.device_id
,s2.enrolled_vin_nb
,s2.start_ts
,s2.end_ts
,s2.connected_day_cn
,s2.device_connected_pc
,s2.device_disconnected_pc
,s2.plcy_ratd_st_cd
)S3
)S4
;


SET mapred.job.name = "~>job_cd Insert Overwrite smartmiles_annual_mileage from smartmiles_wk_annual_mileage";

INSERT OVERWRITE TABLE ~>provide_db.smartmiles_annual_mileage partition (load_date)    --new DDL change, make piid string
SELECT
 sr_pgm_instnc_id
,device_id
,enrolled_vin_nb
,plcy_ratd_st_cd
,start_ts
,end_ts
,connected_day_cn
,device_connected_pc
,device_disconnected_pc
,plausible_speed_pcnt
,tier1_10avg
,tier11_30avg
,tier31_70avg
,tier71_90avg
,tier91_100avg
,estimatedkilometers
,estimatedmileage
,load_date
FROM ~>work_db.smartmiles_wk_annual_mileage;

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_ca_annual_mileage_score;

CREATE TABLE ~>work_db.smartmiles_wk_ca_annual_mileage_score(
  deviceserial_nb string, 
  policy_nb string, 
  enrolled_vin_nb varchar(128), 
  score_dt string, 
  tripstart_dt string, 
  tripend_dt string, 
  score_days string, 
  percenttime_disconnected string, 
  score_1 string, 
  score_2 string, 
  score_3 string, 
  score_4 string, 
  score_5 string, 
  score_6 string, 
  score_7 string, 
  score_8 string, 
  score_9 string, 
  score_10 string, 
  floor_estimatedkilometers string, 
  filler string, 
  score_date varchar(10))
STORED AS PARQUET 
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_ca_annual_mileage_score';

SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_ca_annual_mileage_score from smartmiles_wk_annual_mileage";

INSERT INTO TABLE ~>work_db.smartmiles_wk_ca_annual_mileage_score
SELECT
LPAD(TRIM(CAST( device_id AS VARCHAR(19))),20,' ') AS DeviceSerial_Nb
,'                    ' AS Policy_Nb
,enrolled_vin_nb
,translate(load_date, '-', '') AS Score_Dt
,translate(CAST(start_ts AS varchar(10)),'-','') AS TripStart_Dt
,translate(CAST(end_ts AS varchar(10)),'-','') AS TripEnd_Dt
,LPAD(cast(connected_day_cn AS varchar(3)),3,' ') AS Score_Days
,concat(lpad(floor(CAST (device_disconnected_pc AS decimal(5,2))),2,' '),'.',rpad(((abs(CAST (device_disconnected_pc AS decimal(5,2))) - floor(abs(CAST (device_disconnected_pc AS decimal(5,2)))))*100),2,'0')) AS PercentTime_Disconnected
,' -1' AS  Score_1
,CASE WHEN device_disconnected_pc > 5 AND floor(plausible_speed_pcnt) < 97 THEN '998'
     WHEN device_disconnected_pc > 5 THEN '998'
     WHEN device_disconnected_pc < 5 AND floor(plausible_speed_pcnt) < 97  THEN '997'
     ELSE ' -1'  END AS Score_2
,' -1' AS  Score_3
,' -1' AS  Score_4
,' -1' AS  Score_5
,' -1' AS  Score_6
,' -1' AS  Score_7
,' -1' AS  Score_8
,' -1' AS  Score_9
,' -1' AS  Score_10
,LPAD(CAST(floor_estimatedkilometers AS varchar(6)),6,' ') AS floor_estimatedkilometers
,RPAD('',128,' ') AS filler
,CAST (from_unixtime(unix_timestamp()) AS varchar(10) ) AS Score_Date
FROM ~>work_db.smartmiles_wk_annual_mileage;

SET hive.merge.tezfiles=TRUE;
SET hive.merge.smallfiles.avgsize= ~>hive_merge_smallfiles_avgsize;
SET hive.merge.size.per.task= ~>hive_merge_size_per_task;
SET mapred.max.split.size= ~>mapred_max_split_size;
SET mapred.min.split.size= ~>mapred_min_split_size;

SET mapred.job.name = "~>job_cd Create Table smartmiles_wk_ca_annual_mileage_score_file from smartmiles_wk_ca_annual_mileage_score concatenation";

INSERT OVERWRITE TABLE ~>provide_db.smartmiles_ca_annual_mileage_score_file 
SELECT CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(CONCAT(deviceserial_nb,policy_nb),enrolled_vin_nb),score_dt),tripstart_dt),tripend_dt),score_days),percenttime_disconnected),score_1),score_2),score_3),score_4),score_5),score_6),score_7),score_8),score_9),score_10),floor_estimatedkilometers),filler) AS value 
FROM ~>work_db.smartmiles_wk_ca_annual_mileage_score;


SET mapred.job.name = "~>job_cd Insert Overwrite smartmiles_annual_mileage_score from smartmiles_wk_ca_annual_mileage_score";

INSERT overwrite TABLE ~>provide_db.smartmiles_annual_mileage_score partition(score_date)
SELECT
 deviceserial_nb
,policy_nb
,enrolled_vin_nb
,score_dt
,tripstart_dt
,tripend_dt
,score_days
,percenttime_disconnected
,score_1
,score_2
,score_3
,score_4
,score_5
,score_6
,score_7
,score_8
,score_9
,score_10
,floor_estimatedkilometers
,filler
,score_date
FROM ~>work_db.smartmiles_wk_ca_annual_mileage_score;



