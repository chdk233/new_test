
DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_device_status;                                                                            
                                                                                                                                                                                                                                                                                
CREATE TABLE ~>work_db.smartmiles_wk_device_status (
	device_id varchar(128),
	sr_pgm_instnc_id varchar(36),
	enrolled_vin_nb varchar(128),
	connected_status_in char(1),
	status_start_ts timestamp,
	status_end_ts timestamp,
	last_device_activity_ts timestamp,
	device_unavailable_in char(1)
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' STORED AS TEXTFILE
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_device_status'; 

                                                                                                                                                                                                                                                                                
set mapred.job.name = "~>job_cd Load data and Overwrite ~>work_db.smartmiles_wk_device_status";                                         
                                                                                                                                                                                                                                                                                  
load data inpath '~>Device_Status_map_reduce_output_path~>Device_Status_map_reduce_output_file/part*' OVERWRITE INTO TABLE ~>work_db.smartmiles_wk_device_status; 

INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_device_status
SELECT device_id, 
sr_pgm_instnc_id, 
enrolled_vin_nb, 
connected_status_in, 
status_start_ts, 
status_end_ts, 
last_device_activity_ts, 
device_unavailable_in
FROM  ~>work_db.smartmiles_wk_device_status;

set mapred.job.name = "~>job_cd Insert Table ~>foundation_db.smartmiles_Device_Summary from ~>foundation_db.smartmiles_device_status"; 

INSERT OVERWRITE TABLE ~>foundation_db.smartmiles_device_summary
SELECT   
 device_id
,sr_pgm_instnc_id
,enrolled_vin_nb 
,start_ts
,end_ts
,lifetime_second_cn
,connected_second_cn
,connected_status_cn
,disconnected_second_cn
,disconnected_status_cn 
,ceil(lifetime_second_cn/86400) AS lifetime_day_cn
,ceil(connected_second_cn/86400) AS connected_day_cn
,device_unavailable_cn
,(connected_second_cn/lifetime_second_cn)*100 AS device_connected_pc
,(disconnected_second_cn/lifetime_second_cn)*100 AS device_disconnected_pc 
FROM 
	(
		SELECT 
		sr_pgm_instnc_id, 
		device_id, 
		enrolled_vin_nb,
		SUM(device_unavailable_in) AS device_unavailable_cn,
		
		CASE WHEN (MAX(final_loststatus_flg) = 'Y'  AND MAX(MAX_status) <> 'N') THEN ((UNIX_TIMESTAMP(MAX(MAX_lastactivity_ts))- UNIX_TIMESTAMP(MIN(status_start_ts)))+ 8*(24*60*60))
		ELSE (UNIX_TIMESTAMP(MAX(status_end_ts))+1-UNIX_TIMESTAMP(MIN(status_start_ts)))  END  AS lifetime_second_cn,
		
		(CASE WHEN MAX(final_loststatus_flg) = 'Y' AND MAX(MAX_status) <> 'N' THEN ((UNIX_TIMESTAMP(MAX(MAX_lastactivity_ts))- UNIX_TIMESTAMP(MIN(status_start_ts)))+ 8*(24*60*60))
		       ELSE (UNIX_TIMESTAMP(MAX(status_end_ts))+1-UNIX_TIMESTAMP(MIN(status_start_ts)))  
		END - SUM(uninstall_time)) AS connected_second_cn,
		
		SUM(uninstall_time) AS disconnected_second_cn,
		MIN(status_start_ts) start_ts,
		MAX(last_device_activity_ts) end_ts,
    SUM(CASE WHEN connected_status_in ='Y' THEN 1 ELSE 0 END ) AS connected_status_cn,
		(count(*) - SUM(CASE WHEN connected_status_in ='Y' THEN 1 ELSE 0 END)) AS disconnected_status_cn
		FROM 
				(SELECT d.*, 
				CASE WHEN connected_status_in = 'Y'
				THEN (UNIX_TIMESTAMP(status_end_ts)+1 - UNIX_TIMESTAMP(status_start_ts))
				  ELSE CAST ( 0 AS bigint)
				END AS install_time,  
				
				CASE WHEN connected_status_in = 'N'  
				THEN
				   CASE WHEN last_device_activity_ts = first_value(last_device_activity_ts) over  (partition  BY sr_pgm_instnc_id ORDER BY status_end_ts  DESC  rows unbounded preceding) AND  device_unavailable_in = 'Y' AND connected_status_in <> 'N'
				   THEN (UNIX_TIMESTAMP(last_device_activity_ts) - UNIX_TIMESTAMP(status_start_ts)) 
				   ELSE (UNIX_TIMESTAMP(status_end_ts)+1 - UNIX_TIMESTAMP(status_start_ts))
				   END
				ELSE CAST ( 0 AS bigint)
				END AS uninstall_time,  
				first_value(device_unavailable_in) over  (partition  BY sr_pgm_instnc_id ORDER BY status_end_ts  DESC  rows unbounded preceding) AS final_loststatus_flg,
				first_value(last_device_activity_ts) over  (partition  BY sr_pgm_instnc_id ORDER BY status_end_ts  DESC  rows unbounded preceding) AS max_lastactivity_ts,
				first_value(connected_status_in) over  (partition  BY sr_pgm_instnc_id ORDER BY status_end_ts  DESC  rows unbounded preceding) AS MAX_status
				from ~>foundation_db.smartmiles_device_status d where sr_pgm_instnc_id <> -1 
				) temp  
		group BY sr_pgm_instnc_id, device_id, enrolled_vin_nb
	) temp2;