SET mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.smartmiles_Wk_Trip_Detail from ~>work_db.smartmiles_WK_Trip_Detail_Hourly";

DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_trip_detail;

CREATE TABLE ~>work_db.smartmiles_wk_trip_detail(
enrolled_vin_nb varchar(128), 
trip_summary_id varchar(128), 
period_start_ts timestamp, 
period_end_ts timestamp, 
mile_cn decimal(8,5), 
adjusted_mile_cn decimal(8,5), 
plausible_mile_cn decimal(8,5), 
kilometer_cn decimal(8,5), 
fast_acceleration_cn int, 
hard_brake_cn int, 
driving_second_cn int, 
idle_second_cn int, 
stop_second_cn int, 
night_time_driving_second_cn int, 
plausible_drive_second_cn int, 
plausible_idle_second_cn int, 
idle_second_pc double, 
trip_report_json_tt string, 
source_cd string, 
batch_nb string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_trip_detail';

INSERT INTO TABLE ~>work_db.smartmiles_Wk_Trip_Detail
SELECT
Enrolled_Vin_Nb
,Trip_Summary_Id
,CAST (MIN(Period_Start_Ts) AS TIMESTAMP)
,CAST(MAX(Period_End_Ts) AS TIMESTAMP)
,CAST(SUM(mile_cn) AS DOUBLE) AS mile_cn
,CAST(SUM(adjusted_mile_cn) AS DOUBLE)
,CAST(SUM(plausible_mile_cn) AS DOUBLE)
,CAST(SUM(kilometer_cn) AS DOUBLE)
,CAST(SUM(Fast_Acceleration_Cn) AS INT)
,CAST(SUM(Hard_Brake_Cn) AS INT)
,CAST(SUM(Driving_Second_Cn) AS INT)
,CAST(SUM(idle_second_cn) AS INT)
,CAST(SUM(stop_second_cn) AS INT)
,CAST(SUM(Night_Time_Driving_Second_Cn) AS INT)
,CAST(SUM(plausible_drive_second_cn) AS INT)
,CAST(SUM(plausible_idle_second_cn) AS INT)
,IF(SUM(Driving_Second_Cn) = 0,0,(SUM(idle_second_cn)/SUM(Driving_Second_Cn)) * 100 ) AS idle_second_pc
,CONCAT('{"start":', UNIX_TIMESTAMP(MIN(Period_Start_Ts)) + (case
when MIN(Period_Start_Ts) between date_format( cast(extract(year from MIN(Period_Start_Ts)) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(MIN(Period_Start_Ts) as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(MIN(Period_Start_Ts) as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from MIN(Period_Start_Ts)) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(MIN(Period_Start_Ts) as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(MIN(Period_Start_Ts) as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600,
', "end":', UNIX_TIMESTAMP(MAX(Period_End_Ts)) + (case
when MAX(Period_End_Ts) between date_format( cast(extract(year from MAX(Period_End_Ts)) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(MAX(Period_End_Ts) as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(MAX(Period_End_Ts) as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from MAX(Period_End_Ts)) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(MAX(Period_End_Ts) as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(MAX(Period_End_Ts) as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600,
', "mph":', DEFAULT.sre_concat_miles(speed_mph_json_tt,Period_Start_Ts),
', "latlong":[',CONCAT_WS(',',COLLECT_LIST(latitude_longitude_json_tt)), ']',
', "acceleration":', DEFAULT.sre_concat_factor(fast_acceleration_json_tt, Period_Start_Ts),
', "braking":', DEFAULT.sre_concat_factor(hard_brake_json_tt, Period_Start_Ts),
', "stop":', DEFAULT.sre_concat_factor(stop_second_json_tt, Period_Start_Ts),
', "scale":1}') AS  trip_report_json_tt
,source_cd
,batch_nb
FROM   ~>work_db.smartmiles_Wk_Trip_Detail_Hourly
GROUP BY enrolled_vin_nb,Trip_Summary_Id, source_cd, batch_nb