--NOTE:  Job will run 1 am every day

-- STEP 1: For yesterdays 24 hr batch cycle, get all VINs and their trip-dates, and calculate daily-mileage by going to TripHourlyDetail
DROP TABLE IF EXISTS ~>work_db.smartmiles_wk_daily_mileage;

CREATE TABLE ~>work_db.smartmiles_wk_daily_mileage(
enrolled_vin_nb varchar(128), 
mile_cn decimal(18,5), 
device_unavailable_in tinyint, 
disconnected_status_in tinyint, 
trip_dt date)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/smartmiles_wk_daily_mileage';

INSERT INTO TABLE ~>work_db.smartmiles_WK_Daily_Mileage
SELECT
hr.Enrolled_Vin_Nb
,SUM(hr.Mile_Cn) AS Mile_Cn
,0 AS Device_Unavailable_In
,CASE connected_status_in
	WHEN 'Y' THEN 0
	WHEN 'N' THEN 1
	ELSE -1
END AS Disconnected_Status_In
,SUBSTR(hr.Period_Start_Ts, 0,10) AS Trip_Dt
FROM ~>foundation_db.smartmiles_Trip_Detail_Hourly hr

INNER JOIN
(
	SELECT
	inner_hr.enrolled_vin_nb
	,SUBSTR(inner_hr.Period_Start_Ts, 0,10) AS Trip_Dt
	,MIN(connected_status_in) AS connected_status_in

	FROM ~>foundation_db.smartmiles_device_status inner_ds

	INNER JOIN ~>foundation_db.smartmiles_Trip_Detail_Hourly inner_hr
	ON TRIM(inner_hr.Enrolled_Vin_Nb) = TRIM(inner_ds.Enrolled_Vin_Nb)

	WHERE  inner_hr.Batch_Nb LIKE '~>daily_mileage_batch_nb%'
	AND SUBSTR(inner_hr.Period_Start_Ts, 0,10) BETWEEN date(inner_ds.status_start_ts) AND date(inner_ds.status_end_ts)
	AND inner_hr.source_cd = 'IMS'
	GROUP BY inner_hr.enrolled_vin_nb, SUBSTR(inner_hr.Period_Start_Ts, 0,10)
) ds

ON  TRIM(hr.Enrolled_Vin_Nb) = TRIM(ds.Enrolled_Vin_Nb)
AND SUBSTR(hr.Period_Start_Ts, 0,10) = ds.Trip_Dt


GROUP BY hr.Enrolled_Vin_Nb, 0
	,CASE connected_status_in
		WHEN 'Y' THEN 0
		WHEN 'N' THEN 1
		ELSE -1
	END
	,SUBSTR(hr.Period_Start_Ts, 0,10);


-- STEP 2: join to ods and get any vins that didnt take a trip for the day.
-- Everytime we build daily mileage we need to send all active drivers for yesterdays trip-dt, whether they took a trip or not
INSERT INTO TABLE ~>work_db.smartmiles_WK_Daily_Mileage
SELECT
ods.vhcl_id_nbr AS Enrolled_Vin_Nb
,0 AS Mile_Cn
,CASE
    WHEN ds.last_device_activity_ts <> date_sub(CURRENT_DATE,~>subtraction_factor) and te.enrolled_vin_nb is null THEN 1
    WHEN ds.last_device_activity_ts = date_sub(CURRENT_DATE,~>subtraction_factor) or te.enrolled_vin_nb is not null THEN 0
    ELSE -1
END AS Device_Unavailable_In --if there was a trip/heartbeat within the day then 0, else 1
,CASE connected_status_in
		WHEN 'Y' THEN 0
		WHEN 'N' THEN 1
		ELSE -1
END AS Disconnected_Status_In --if device was disconnected within the day then 1, else 0
,date_sub(CURRENT_DATE,~>subtraction_factor) AS Trip_Dt
FROM ~>foundation_db.smartride_Smt_Ods_Bigin_Pgm_Instnc_Orc ods

LEFT OUTER JOIN ~>work_db.smartmiles_WK_Daily_Mileage wk
ON trim(wk.Enrolled_Vin_Nb) = trim(ods.vhcl_id_nbr)
AND trip_dt = date_sub(CURRENT_DATE,~>subtraction_factor)

--look in trip event to see if VIN had a heartbeat within the day
LEFT OUTER JOIN
(
    select enrolled_vin_nb
    from ~>foundation_db.smartmiles_trip_event
    where trip_event_type_ds = 'HEARTBEAT'
    and date_sub(CURRENT_DATE,~>subtraction_factor) = date(trip_event_ts)
    group by enrolled_vin_nb
) te
on trim(te.enrolled_vin_nb) = trim(ods.vhcl_id_nbr)

INNER JOIN
	(
	SELECT
		Enrolled_Vin_Nb
		,MIN(connected_status_in) AS connected_status_in
		,MAX(date(last_device_activity_ts)) AS last_device_activity_ts
	FROM ~>foundation_db.smartmiles_device_status
	WHERE date_sub(CURRENT_DATE,~>subtraction_factor) BETWEEN date(status_start_ts) AND date(status_end_ts)
	GROUP BY enrolled_vin_nb
	) ds

ON ods.vhcl_id_nbr = ds.Enrolled_Vin_Nb

WHERE wk.Enrolled_Vin_Nb IS NULL
AND ods.dev_id_nbr <> crc32(ods.vhcl_id_nbr)
;

SET hive.merge.tezfiles=true;

--- Step 3: Insert into work export table.  This tables data is what will be sent to SRP.

INSERT OVERWRITE TABLE ~>provide_db.smartmiles_Daily_Mileage_Export
SELECT
Enrolled_Vin_Nb
,Mile_Cn
,Device_Unavailable_In
,Disconnected_Status_In
,Trip_Dt
,CURRENT_DATE AS Load_Dt
FROM ~>work_db.smartmiles_WK_Daily_Mileage
WHERE Trip_Dt not between '2020-12-14' and '2021-01-08' and Trip_Dt not between '2022-04-24' and '2022-04-27' and Trip_Dt not between '2022-06-25' and '2022-06-27'; --temporary filter for late trips catch-up, to be removed when loads are complete.

--- Step 4: Insert data into foundation export table.  This is so we have a historical record of what daily-mileage we sent for which day
INSERT OVERWRITE TABLE ~>provide_db.smartmiles_Daily_Mileage PARTITION(Load_Dt)
SELECT
Enrolled_Vin_Nb
,Mile_Cn
,Device_Unavailable_In
,Disconnected_Status_In
,Trip_Dt
,CURRENT_DATE AS Load_Dt
FROM ~>work_db.smartmiles_WK_Daily_Mileage;
