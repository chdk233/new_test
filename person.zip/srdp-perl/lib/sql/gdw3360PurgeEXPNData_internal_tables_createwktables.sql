set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

drop table if exists ~>expn_wk_db.wk_purge_Vehicle;
set mapred.job.name = "~>job_cd Create Table experian_work_hive_db.wk_purge_Vehicle from experian_canonical_hive_db.Vehicle";
create table ~>expn_wk_db.wk_purge_Vehicle as select * from ~>expn_cncl_db.Vehicle where sourcefile_dt >= ~>max_date and sourcefile_dt <= ~>min_date;

drop table if exists ~>expn_wk_db.wk_purge_TripSummary;
set mapred.job.name = "~>job_cd Create Table experian_work_hive_db.wk_purge_TripSummary from experian_canonical_hive_db.TripSummary";
create table ~>expn_wk_db.wk_purge_TripSummary as select * from ~>expn_cncl_db.TripSummary where sourcefile_dt >= ~>max_date and sourcefile_dt <= ~>min_date;

drop table if exists ~>expn_wk_db.wk_purge_TripEvent;
set mapred.job.name = "~>job_cd Create Table experian_work_hive_db.wk_purge_TripEvent from experian_canonical_hive_db.TripEvent";
create table ~>expn_wk_db.wk_purge_TripEvent as select * from ~>expn_cncl_db.TripEvent where sourcefile_dt >= ~>max_date and sourcefile_dt <= ~>min_date;

drop table if exists ~>expn_wk_db.wk_purge_VehiclePartition;
set mapred.job.name = "~>job_cd Create Table experian_work_hive_db.wk_purge_VehiclePartition from experian_reporting_hive_db.VehiclePartition";
create table ~>expn_wk_db.wk_purge_VehiclePartition as select * from ~>expn_rpt_db.VehiclePartition where sourcefile_dt >= ~>max_date and sourcefile_dt <= ~>min_date;

drop table if exists ~>expn_wk_db.wk_purge_TelematicsScore;
set mapred.job.name = "~>job_cd Create Table  experian_work_hive_db.wk_purge_TelematicsScore from experian_reporting_hive_db.TelematicsScore";
create table ~>expn_wk_db.wk_purge_TelematicsScore as select * from ~>expn_rpt_db.TelematicsScore where sourcefile_dt >= ~>max_date and sourcefile_dt <= ~>min_date;