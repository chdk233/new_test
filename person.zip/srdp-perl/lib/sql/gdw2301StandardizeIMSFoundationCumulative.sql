--------------------------------------------------------------------------------------------------------
--Step1-- Standardize IMS Canonical Cumulative DropRecreate
--------------------------------------------------------------------------------------------------------

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripcumulative_temp;

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripcumulative_temp(
DataLoad_Dt TIMESTAMP COMMENT 'Load date',
SourceFileName_Ts TIMESTAMP COMMENT 'Source file datestamp',
LoadEvent_Id BIGINT COMMENT 'Unique  Identifier to indicate the load', 
DeviceType_Cd BIGINT COMMENT 'To Indicate data record from Octo vendor',
Voucher_Nb BIGINT COMMENT 'IP Address of the User',
DeviceSerial_Nb BIGINT COMMENT 'Device serial number of the device',
EnrolledVIN_Nb STRING COMMENT 'Enrolled Vehicle Indentification number',
DetectedVIN_Nb STRING COMMENT 'Detected Vehicle Indentification number',
CumulativeTrips_Qt DOUBLE,
CumulativeDistance_Qt DOUBLE,
CumulativeEngineOn_Qt DOUBLE,
FirstTripStart_Ts TIMESTAMP,
LastTripEnd_Ts TIMESTAMP,
LastProcessing_Ts TIMESTAMP,
source_cd string, 
batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripcumulative_temp';

set mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.smartride_WK_IMS_TSP_TripCumulative_Temp from ~>staging_db.smartride_ims_cumulative";

--------------------------------------------------------------------------------------------------------
--Step2-- Standardize IMS Canonical Cumulative Wk Table Load
--------------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripcumulative_temp
select 
from_unixtime(unix_timestamp())as DataLoad_Dt,
CONCAT(substr(batch,1,4),'-',substr(batch,5,2),'-',substr(batch,7,2),' ',CASE substr(batch,9,2) WHEN '24' THEN '00' ELSE substr(batch,9,2) END,':',substr(batch,11,2),':00','.000000')as SourceFileName_Ts,
loadevent, 
'',
'',
DeviceSerial_Nb,
EnrolledVIN_Nb,
DetectedVIN_Nb,
CumulativeTrips_Qt,
CumulativeDistance_Qt,
CumulativeEngineOn_Qt,
FirstTripStart_Ts,
LastTripEnd_Ts,
LastProcessing_Ts,
'IMS' as source_cd,
batch
from  ~>staging_db.smartride_ims_cumulative WHERE
loadevent in (~>load_event_id_list);

--------------------------------------------------------------------------------------------------------
--Step3-- Standardize IMS Canonical Cumulative Load TSP Trip Cumulative
--------------------------------------------------------------------------------------------------------

DROP TABLE IF EXISTS ~>work_db.smartride_wk_ims_tsp_tripcumulative;

set mapred.job.name = "~>job_cd Load data into work tsp trip cumulative table from WK_IMS_TSP_TripCumulative table";

CREATE TABLE ~>work_db.smartride_wk_ims_tsp_tripcumulative(
  dataload_dt timestamp, 
  sourcefilename_ts timestamp, 
  loadevent_id bigint, 
  devicetype_cd bigint, 
  voucher_nb bigint, 
  deviceserial_nb bigint, 
  enrolledvin_nb string, 
  detectedvin_nb string, 
  cumulativetrips_qt double, 
  cumulativedistance_qt double, 
  cumulativeengineon_qt double, 
  firsttripstart_ts timestamp, 
  lasttripend_ts timestamp, 
  lastprocessing_ts timestamp, 
  source_cd string, 
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_ims_tsp_tripcumulative';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_ims_tsp_tripcumulative
Select DataLoad_Dt ,
SourceFileName_Ts ,
LoadEvent_Id , 
DeviceType_Cd ,
Voucher_Nb ,
DeviceSerial_Nb ,
EnrolledVIN_Nb ,
'' as DetectedVIN_Nb,
CumulativeTrips_Qt,
CumulativeDistance_Qt ,
CumulativeEngineOn_Qt ,
FirstTripStart_Ts ,
LastTripEnd_Ts ,
LastProcessing_Ts , 
source_cd , 
batch 
from
~>work_db.smartride_wk_ims_tsp_tripcumulative_temp;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartride_tsp_tripcumulative from ~>work_db.smartride_WK_IMS_TSP_TripCumulative";

INSERT OVERWRITE TABLE ~>foundation_db.smartride_tsp_tripcumulative
PARTITION (source_cd='IMS', batch)
SELECT 
DataLoad_Dt  ,
SourceFileName_Ts ,
LoadEvent_Id, 
DeviceType_Cd ,
Voucher_Nb,
DeviceSerial_Nb,
EnrolledVIN_Nb,
DetectedVIN_Nb,
CumulativeTrips_Qt,
CumulativeDistance_Qt,
CumulativeEngineOn_Qt,
FirstTripStart_Ts,
LastTripEnd_Ts,
LastProcessing_Ts,
batch 
from ~>work_db.smartride_wk_ims_tsp_tripcumulative;