-- Step 1-- Standardize OCTO Foundation Summary Drop Recreate
--------------------------------------------------------------------------------------------------------
-- DESCRIPTION This script is used for loading TSP_TripSummary table from HDFS vendor Summary file
---------------------------------------------------------------------------------------------------------

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tsp_tripsummary_temp;

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_temp(
DataLoad_Dt  TIMESTAMP COMMENT 'Load date',
SourceFileName_Ts TIMESTAMP COMMENT 'Source file datestamp',
LoadEvent_Id BIGINT COMMENT 'Unique  Identifier to indicate the load', 
DeviceType_Cd BIGINT  COMMENT 'To Indicate data record from Octo vendor',
FullPolicy_Nb STRING COMMENT 'Full Policy Number',
Voucher_Nb BIGINT,
sr_pgm_instnc_id BIGINT,
DeviceSerial_Nb BIGINT COMMENT 'Device serial number of the device',
EnrolledVIN_Nb STRING COMMENT 'Enrolled Vehicle Indentification number',
Trip_Nb STRING COMMENT 'Trip number',
DetectedVIN_Nb STRING COMMENT 'Detected Vehicle Indentification number',
TripStart_Ts TIMESTAMP COMMENT 'Start time of the trip',
TripEnd_Ts  TIMESTAMP COMMENT 'End time of the trip',
Plcy_Ratd_St_Cd STRING,
TripDistance_Qt DOUBLE,
AverageSpeed_Qt DOUBLE,
MaximumSpeed_Qt DOUBLE,
FuelConsumption_Qt DOUBLE,
MILStatus_Cd STRING,
TripZoneOffset_AM STRING,
IdleTime_Ts INT,
TripPositionalQuality_Qt DOUBLE,
AccelerometerQuality_Qt DOUBLE,
DistanceMotorways_Qt DOUBLE,
DistanceUrbanAreas_Qt DOUBLE,
DistanceOtherRoad_Qt DOUBLE,
DistanceUnknownRoad_Qt DOUBLE,
TimeTravelled_Qt DOUBLE,
TimeMotorways_Qt DOUBLE,
TimeUrbanAreas_Qt DOUBLE,
TimeOtherRoad_Qt DOUBLE,
TimeUnknownRoad_Qt DOUBLE,
SpeedingDistanceMotorways_Qt DOUBLE,
SpeedingDistanceUrbanAreas_Qt DOUBLE,
SpeedingDistanceOtherRoad_Qt DOUBLE,
SpeedingDistanceUnknownRoad_Qt DOUBLE,
SpeedingTimeMotorways_Qt DOUBLE,
SpeedingTimeUrbanAreas_Qt DOUBLE,
SpeedingTimeOtherRoad_Qt DOUBLE,
SpeedingTimeUnknownRoad_Qt DOUBLE,
source_cd string,
batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripsummary_temp';  



set mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.smartride_wk_octo_tsp_tripsummary_temp from ~>staging_db.smartride_octo_tripsummary";

-- Step 2-- Standardize OCTO Foundation Summary Wk Table Load
--------------------------------------------------------------------------------------------------------
-- DESCRIPTION This script is used for loading TSP_TripSummary table from HDFS vendor Summary file
---------------------------------------------------------------------------------------------------------

-- Load data into table WK_OCTO_TSP_TripSummary from external table OCTO_TripSummary_Ext

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_temp
select
from_unixtime(unix_timestamp())as DataLoad_Dt,
CONCAT(substr(batch,1,4),'-',substr(batch,5,2),'-',substr(batch,7,2),' ',CASE substr(batch,9,2) WHEN '24' THEN '00' ELSE substr(batch,9,2) END,':',substr(batch,11,2),':00','.000000')as SourceFileName_Ts,
loadevent,
Type_Cd as DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
-1 as sr_pgm_instnc_id,
deviceserial_nb,
enrolledvin_nb,
trip_nb,
detectedvin_nb,
tripstart_ts,
tripend_ts,
'' as plcy_ratd_st_cd,
tripdistance_qt,
averagespeed_qt,
maximumspeed_qt,
fuelconsumption_qt,
milstatus_cd,
( case when instr(tripzoneoffset_am,':') > 0
then
case when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) > 0
then concat(' ',Substr('00' , 1 ,2-length(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)))),Trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) < 0 
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
case when instr(tripzoneoffset_am,'-') > 1
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
concat(' 00',substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
end
end
else concat(Substr('     ',1,5-length(tripzoneoffset_am)),trim(tripzoneoffset_am))
end ) as tripzoneoffset_am, 
idletime_ts,
trippositionalquality_qt,
accelerometerquality_qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
'OCTO' as source_cd,
batch
from ~>staging_db.smartride_octo_tripsummary
where loadevent in (~>load_event_id_list);


set mapred.job.name = "~>job_cd load all historical data without dups into ims_tsp_tripsummary_dups";



-- Step 3-- Standardize OCTO Foundation Summary Load TSP Trip Summary
-------------------------------------------------------------------------------------------------------
-- DESCRIPTION This script is used for loading TSP_TripSummary table from HDFS vendor Summary file
---------------------------------------------------------------------------------------------------------


INSERT OVERWRITE TABLE ~>foundation_db.smartride_octo_tsp_tripsummary_dups 
PARTITION (source_cd='OCTO',batch,flag) 
Select 
temp.dataload_dt
,temp.sourcefilename_ts
,temp.loadevent_id
,temp.devicetype_cd
,temp.fullpolicy_nb
,temp.voucher_nb
,temp.sr_pgm_instnc_id
,temp.deviceserial_nb
,temp.enrolledvin_nb
,temp.trip_nb
,temp.detectedvin_nb
,temp.tripstart_ts
,temp.tripend_ts
,temp.plcy_ratd_st_cd
,temp.tripdistance_qt
,temp.averagespeed_qt
,temp.maximumspeed_qt
,temp.fuelconsumption_qt
,temp.milstatus_cd
,temp.tripzoneoffset_am
,temp.idletime_ts
,temp.trippositionalquality_qt
,temp.accelerometerquality_qt
,temp.distancemotorways_qt
,temp.distanceurbanareas_qt
,temp.distanceotherroad_qt
,temp.distanceunknownroad_qt
,temp.timetravelled_qt
,temp.timemotorways_qt
,temp.timeurbanareas_qt
,temp.timeotherroad_qt
,temp.timeunknownroad_qt
,temp.speedingdistancemotorways_qt
,temp.speedingdistanceurbanareas_qt
,temp.speedingdistanceotherroad_qt
,temp.speedingdistanceunknownroad_qt
,temp.speedingtimemotorways_qt
,temp.speedingtimeurbanareas_qt
,temp.speedingtimeotherroad_qt
,temp.speedingtimeunknownroad_qt
,temp.batch
,'H' as flag 
from ~>work_db.smartride_WK_OCTO_TSP_TripSummary_Temp temp 
left outer join ~>foundation_db.smartride_TSP_TripSummary tsp_ts 
on tsp_ts.trip_nb = temp.trip_nb and 
tsp_ts.source_cd = temp.source_cd 
where  tsp_ts.trip_nb is not null and 
tsp_ts.batch <> temp.batch and
tsp_ts.source_cd='OCTO' and
tsp_ts.batch >= '~>batch_filter_3_mo_ago';

---Drop work table of trip summary where there are no duplicates 

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_2;

set mapred.job.name = "~>job_cd Create work table of trip summary where there are no duplicates";

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_2(
dataload_dt timestamp, 
sourcefilename_ts timestamp, 
loadevent_id bigint, 
devicetype_cd bigint, 
fullpolicy_nb string, 
voucher_nb bigint, 
sr_pgm_instnc_id bigint, 
deviceserial_nb bigint, 
enrolledvin_nb string, 
trip_nb string, 
detectedvin_nb string, 
tripstart_ts timestamp, 
tripend_ts timestamp, 
plcy_ratd_st_cd string, 
tripdistance_qt double, 
averagespeed_qt double, 
maximumspeed_qt double, 
fuelconsumption_qt double, 
milstatus_cd string, 
tripzoneoffset_am string, 
idletime_ts int, 
trippositionalquality_qt double, 
accelerometerquality_qt double, 
distancemotorways_qt double, 
distanceurbanareas_qt double, 
distanceotherroad_qt double, 
distanceunknownroad_qt double, 
timetravelled_qt double, 
timemotorways_qt double, 
timeurbanareas_qt double, 
timeotherroad_qt double, 
timeunknownroad_qt double, 
speedingdistancemotorways_qt double, 
speedingdistanceurbanareas_qt double, 
speedingdistanceotherroad_qt double, 
speedingdistanceunknownroad_qt double, 
speedingtimemotorways_qt double, 
speedingtimeurbanareas_qt double, 
speedingtimeotherroad_qt double, 
speedingtimeunknownroad_qt double, 
source_cd string, 
batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripsummary_temp_2';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_2
Select 
temp.dataload_dt,
temp.sourcefilename_ts,
temp.loadevent_id,
temp.devicetype_cd,
temp.fullpolicy_nb,
temp.voucher_nb,
temp.sr_pgm_instnc_id,
temp.deviceserial_nb,
temp.enrolledvin_nb,
temp.trip_nb,
temp.detectedvin_nb,
temp.tripstart_ts,
temp.tripend_ts,
temp.plcy_ratd_st_cd,
temp.tripdistance_qt,
temp.averagespeed_qt,
temp.maximumspeed_qt,
temp.fuelconsumption_qt,
temp.milstatus_cd,
temp.tripzoneoffset_am,
temp.idletime_ts,
temp.trippositionalquality_qt,
temp.accelerometerquality_qt,
temp.distancemotorways_qt,
temp.distanceurbanareas_qt,
temp.distanceotherroad_qt,
temp.distanceunknownroad_qt,
temp.timetravelled_qt,
temp.timemotorways_qt,
temp.timeurbanareas_qt,
temp.timeotherroad_qt,
temp.timeunknownroad_qt,
temp.speedingdistancemotorways_qt,
temp.speedingdistanceurbanareas_qt,
temp.speedingdistanceotherroad_qt,
temp.speedingdistanceunknownroad_qt,
temp.speedingtimemotorways_qt,
temp.speedingtimeurbanareas_qt,
temp.speedingtimeotherroad_qt,
temp.speedingtimeunknownroad_qt,
temp.source_cd,
temp.batch from ~>work_db.smartride_wk_octo_tsp_tripsummary_temp temp 
left outer join ~>foundation_db.smartride_octo_tsp_tripsummary_dups dups
 on dups.trip_nb = temp.trip_nb
 and dups.source_cd = temp.source_cd
 and dups.batch = temp.batch
 where dups.trip_nb is null;

--- Phase 2 Audit check for identifying dups within the incremental batch

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tsp_tripsummary_dups;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_wk_octo_tsp_tripsummary_dups from smartride_wk_octo_tsp_tripsummary_temp & smartride_wk_octo_dup_ctrl";

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_dups(
  dataload_dt timestamp,
  sourcefilename_ts timestamp,
  loadevent_id bigint,
  devicetype_cd bigint,
  fullpolicy_nb string,
  voucher_nb bigint,
  sr_pgm_instnc_id bigint,
  deviceserial_nb bigint,
  enrolledvin_nb string,
  trip_nb string,
  detectedvin_nb string,
  tripstart_ts timestamp,
  tripend_ts timestamp,
  plcy_ratd_st_cd string,
  tripdistance_qt double,
  averagespeed_qt double,
  maximumspeed_qt double,
  fuelconsumption_qt double,
  milstatus_cd string,
  tripzoneoffset_am string,
  idletime_ts int,
  trippositionalquality_qt double,
  accelerometerquality_qt double,
  distancemotorways_qt double,
  distanceurbanareas_qt double,
  distanceotherroad_qt double,
  distanceunknownroad_qt double,
  timetravelled_qt double,
  timemotorways_qt double,
  timeurbanareas_qt double,
  timeotherroad_qt double,
  timeunknownroad_qt double,
  speedingdistancemotorways_qt double,
  speedingdistanceurbanareas_qt double,
  speedingdistanceotherroad_qt double,
  speedingdistanceunknownroad_qt double,
  speedingtimemotorways_qt double,
  speedingtimeurbanareas_qt double,
  speedingtimeotherroad_qt double,
  speedingtimeunknownroad_qt double,
  source_cd string,
  batch string,
  flag string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripsummary_dups';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_dups
SELECT 
temp.dataload_dt,
temp.sourcefilename_ts,
temp.loadevent_id,
temp.devicetype_cd,
temp.fullpolicy_nb,
temp.voucher_nb,
temp.sr_pgm_instnc_id,
temp.deviceserial_nb,
temp.enrolledvin_nb,
temp.trip_nb,
temp.detectedvin_nb,
temp.tripstart_ts,
temp.tripend_ts,
temp.plcy_ratd_st_cd,
temp.tripdistance_qt,
temp.averagespeed_qt,
temp.maximumspeed_qt,
temp.fuelconsumption_qt,
temp.milstatus_cd,
temp.tripzoneoffset_am,
temp.idletime_ts,
temp.trippositionalquality_qt,
temp.accelerometerquality_qt,
temp.distancemotorways_qt,
temp.distanceurbanareas_qt,
temp.distanceotherroad_qt,
temp.distanceunknownroad_qt,
temp.timetravelled_qt,
temp.timemotorways_qt,
temp.timeurbanareas_qt,
temp.timeotherroad_qt,
temp.timeunknownroad_qt,
temp.speedingdistancemotorways_qt,
temp.speedingdistanceurbanareas_qt,
temp.speedingdistanceotherroad_qt,
temp.speedingdistanceunknownroad_qt,
temp.speedingtimemotorways_qt,
temp.speedingtimeurbanareas_qt,
temp.speedingtimeotherroad_qt,
temp.speedingtimeunknownroad_qt,
temp.source_cd,
temp.batch,
'I' as flag 
from ~>work_db.smartride_wk_octo_tsp_tripsummary_temp temp 
 left outer join ~>work_db.smartride_wk_octo_dup_ctrl dup
 on dup.trip_nb = temp.trip_nb
 where dup.trip_nb is not null;
  
set mapred.job.name = "~>job_cd load data from work dups to foundation dup table";

INSERT OVERWRITE TABLE ~>foundation_db.smartride_octo_tsp_tripsummary_dups 
PARTITION (source_cd='OCTO',batch,flag) 
Select 
dataload_dt
,sourcefilename_ts
,loadevent_id
,devicetype_cd
,fullpolicy_nb
,voucher_nb
,sr_pgm_instnc_id
,deviceserial_nb
,enrolledvin_nb
,trip_nb
,detectedvin_nb
,tripstart_ts
,tripend_ts
,plcy_ratd_st_cd
,tripdistance_qt
,averagespeed_qt
,maximumspeed_qt
,fuelconsumption_qt
,milstatus_cd
,tripzoneoffset_am
,idletime_ts
,trippositionalquality_qt
,accelerometerquality_qt
,distancemotorways_qt
,distanceurbanareas_qt
,distanceotherroad_qt
,distanceunknownroad_qt
,timetravelled_qt
,timemotorways_qt
,timeurbanareas_qt
,timeotherroad_qt
,timeunknownroad_qt
,speedingdistancemotorways_qt
,speedingdistanceurbanareas_qt
,speedingdistanceotherroad_qt
,speedingdistanceunknownroad_qt
,speedingtimemotorways_qt
,speedingtimeurbanareas_qt
,speedingtimeotherroad_qt
,speedingtimeunknownroad_qt
,batch
,flag
from ~>work_db.smartride_wk_octo_tsp_tripsummary_dups;


---Drop work table that consists of non-dups of incremental batch

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_3;

set mapred.job.name = "~>job_cd create work table that consists of non-dups of incremental batch";

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_3(
  dataload_dt timestamp,
  sourcefilename_ts timestamp,
  loadevent_id bigint,
  devicetype_cd bigint,
  fullpolicy_nb string,
  voucher_nb bigint,
  sr_pgm_instnc_id bigint,
  deviceserial_nb bigint,
  enrolledvin_nb string,
  trip_nb string,
  detectedvin_nb string,
  tripstart_ts timestamp,
  tripend_ts timestamp,
  plcy_ratd_st_cd string,
  tripdistance_qt double,
  averagespeed_qt double,
  maximumspeed_qt double,
  fuelconsumption_qt double,
  milstatus_cd string,
  tripzoneoffset_am string,
  idletime_ts int,
  trippositionalquality_qt double,
  accelerometerquality_qt double,
  distancemotorways_qt double,
  distanceurbanareas_qt double,
  distanceotherroad_qt double,
  distanceunknownroad_qt double,
  timetravelled_qt double,
  timemotorways_qt double,
  timeurbanareas_qt double,
  timeotherroad_qt double,
  timeunknownroad_qt double,
  speedingdistancemotorways_qt double,
  speedingdistanceurbanareas_qt double,
  speedingdistanceotherroad_qt double,
  speedingdistanceunknownroad_qt double,
  speedingtimemotorways_qt double,
  speedingtimeurbanareas_qt double,
  speedingtimeotherroad_qt double,
  speedingtimeunknownroad_qt double,
  source_cd string,
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripsummary_temp_3';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_3
SELECT 
temp.dataload_dt,
temp.sourcefilename_ts,
temp.loadevent_id,
temp.devicetype_cd,
temp.fullpolicy_nb,
temp.voucher_nb,
temp.sr_pgm_instnc_id,
temp.deviceserial_nb,
temp.enrolledvin_nb,
temp.trip_nb,
temp.detectedvin_nb,
temp.tripstart_ts,
temp.tripend_ts,
temp.plcy_ratd_st_cd,
temp.tripdistance_qt,
temp.averagespeed_qt,
temp.maximumspeed_qt,
temp.fuelconsumption_qt,
temp.milstatus_cd,
temp.tripzoneoffset_am,
temp.idletime_ts,
temp.trippositionalquality_qt,
temp.accelerometerquality_qt,
temp.distancemotorways_qt,
temp.distanceurbanareas_qt,
temp.distanceotherroad_qt,
temp.distanceunknownroad_qt,
temp.timetravelled_qt,
temp.timemotorways_qt,
temp.timeurbanareas_qt,
temp.timeotherroad_qt,
temp.timeunknownroad_qt,
temp.speedingdistancemotorways_qt,
temp.speedingdistanceurbanareas_qt,
temp.speedingdistanceotherroad_qt,
temp.speedingdistanceunknownroad_qt,
temp.speedingtimemotorways_qt,
temp.speedingtimeurbanareas_qt,
temp.speedingtimeotherroad_qt,
temp.speedingtimeunknownroad_qt,
temp.source_cd,
temp.batch
 from ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_2 temp 
 left outer join ~>work_db.smartride_wk_octo_dup_ctrl dup
 on dup.trip_nb = temp.trip_nb
 where dup.trip_nb is null;
 

DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tsp_tripsummary_mis;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_wk_octo_tsp_tripsummary_mis from smartride_WK_OCTO_TSP_TripSummary_Temp_3 & smartride_WK_OCTO_Missing_Trip_Ctrl";

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_mis(
  dataload_dt timestamp,
  sourcefilename_ts timestamp,
  loadevent_id bigint,
  devicetype_cd bigint,
  fullpolicy_nb string,
  voucher_nb bigint,
  sr_pgm_instnc_id bigint,
  deviceserial_nb bigint,
  enrolledvin_nb string,
  trip_nb string,
  detectedvin_nb string,
  tripstart_ts timestamp,
  tripend_ts timestamp,
  plcy_ratd_st_cd string,
  tripdistance_qt double,
  averagespeed_qt double,
  maximumspeed_qt double,
  fuelconsumption_qt double,
  milstatus_cd string,
  tripzoneoffset_am string,
  idletime_ts int,
  trippositionalquality_qt double,
  accelerometerquality_qt double,
  distancemotorways_qt double,
  distanceurbanareas_qt double,
  distanceotherroad_qt double,
  distanceunknownroad_qt double,
  timetravelled_qt double,
  timemotorways_qt double,
  timeurbanareas_qt double,
  timeotherroad_qt double,
  timeunknownroad_qt double,
  speedingdistancemotorways_qt double,
  speedingdistanceurbanareas_qt double,
  speedingdistanceotherroad_qt double,
  speedingdistanceunknownroad_qt double,
  speedingtimemotorways_qt double,
  speedingtimeurbanareas_qt double,
  speedingtimeotherroad_qt double,
  speedingtimeunknownroad_qt double,
  source_cd string,
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripsummary_mis';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_mis
SELECT
temp.dataload_dt,
temp.sourcefilename_ts,
temp.loadevent_id,
temp.devicetype_cd,
temp.fullpolicy_nb,
temp.voucher_nb,
temp.sr_pgm_instnc_id,
temp.deviceserial_nb,
temp.enrolledvin_nb,
temp.trip_nb,
temp.detectedvin_nb,
temp.tripstart_ts,
temp.tripend_ts,
temp.plcy_ratd_st_cd,
temp.tripdistance_qt,
temp.averagespeed_qt,
temp.maximumspeed_qt,
temp.fuelconsumption_qt,
temp.milstatus_cd,
temp.tripzoneoffset_am,
temp.idletime_ts,
temp.trippositionalquality_qt,
temp.accelerometerquality_qt,
temp.distancemotorways_qt,
temp.distanceurbanareas_qt,
temp.distanceotherroad_qt,
temp.distanceunknownroad_qt,
temp.timetravelled_qt,
temp.timemotorways_qt,
temp.timeurbanareas_qt,
temp.timeotherroad_qt,
temp.timeunknownroad_qt,
temp.speedingdistancemotorways_qt,
temp.speedingdistanceurbanareas_qt,
temp.speedingdistanceotherroad_qt,
temp.speedingdistanceunknownroad_qt,
temp.speedingtimemotorways_qt,
temp.speedingtimeurbanareas_qt,
temp.speedingtimeotherroad_qt,
temp.speedingtimeunknownroad_qt,
temp.source_cd,
temp.batch
from ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_3 temp 
left outer join ~>work_db.smartride_wk_octo_missing_trip_ctrl mis
on mis.trip_nb = temp.trip_nb
where mis.trip_nb is null; 
 
 
set mapred.job.name = "~>job_cd load data in to table ~>foundation_db.smartride_octo_tsp_tripsummary_mis from work missing table";
 
INSERT OVERWRITE TABLE ~>foundation_db.smartride_octo_tsp_tripsummary_mis PARTITION (source_cd='OCTO',batch) 
select 
dataload_dt,
sourcefilename_ts,
loadevent_id,
devicetype_cd,
fullpolicy_nb,
voucher_nb,
sr_pgm_instnc_id,
deviceserial_nb,
enrolledvin_nb,
trip_nb,
detectedvin_nb,
tripstart_ts,
tripend_ts,
plcy_ratd_st_cd,
tripdistance_qt,
averagespeed_qt,
maximumspeed_qt,
fuelconsumption_qt,
milstatus_cd,
tripzoneoffset_am,
idletime_ts,
trippositionalquality_qt,
accelerometerquality_qt,
distancemotorways_qt,
distanceurbanareas_qt, 
distanceotherroad_qt, 
distanceunknownroad_qt, 
timetravelled_qt, 
timemotorways_qt, 
timeurbanareas_qt, 
timeotherroad_qt, 
timeunknownroad_qt, 
speedingdistancemotorways_qt, 
speedingdistanceurbanareas_qt, 
speedingdistanceotherroad_qt, 
speedingdistanceunknownroad_qt, 
speedingtimemotorways_qt, 
speedingtimeurbanareas_qt, 
speedingtimeotherroad_qt, 
speedingtimeunknownroad_qt, 
batch 
from ~>work_db.smartride_wk_octo_tsp_tripsummary_mis;


DROP TABLE IF EXISTS ~>work_db.smartride_wk_octo_tsp_tripsummary_final;

set mapred.job.name = "~>job_cd Create Table ~>work_db.smartride_WK_OCTO_TSP_TripSummary_final from smartride_WK_OCTO_TSP_TripSummary_Temp_3 & smartride_WK_OCTO_Missing_Trip_Ctrl";

CREATE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_final(
  dataload_dt timestamp, 
  sourcefilename_ts timestamp, 
  loadevent_id bigint, 
  devicetype_cd bigint, 
  fullpolicy_nb string, 
  voucher_nb bigint, 
  sr_pgm_instnc_id int, 
  deviceserial_nb bigint, 
  enrolledvin_nb string, 
  trip_nb string, 
  detectedvin_nb string, 
  tripstart_ts timestamp, 
  tripend_ts timestamp, 
  plcy_ratd_st_cd string, 
  tripdistance_qt double, 
  averagespeed_qt double, 
  maximumspeed_qt double, 
  fuelconsumption_qt double, 
  milstatus_cd string, 
  tripzoneoffset_am string, 
  idletime_ts int, 
  trippositionalquality_qt double, 
  accelerometerquality_qt double, 
  distancemotorways_qt double, 
  distanceurbanareas_qt double, 
  distanceotherroad_qt double, 
  distanceunknownroad_qt double, 
  timetravelled_qt double, 
  timemotorways_qt double, 
  timeurbanareas_qt double, 
  timeotherroad_qt double, 
  timeunknownroad_qt double, 
  speedingdistancemotorways_qt double, 
  speedingdistanceurbanareas_qt double, 
  speedingdistanceotherroad_qt double, 
  speedingdistanceunknownroad_qt double, 
  speedingtimemotorways_qt double, 
  speedingtimeurbanareas_qt double, 
  speedingtimeotherroad_qt double, 
  speedingtimeunknownroad_qt double, 
  source_cd string, 
  batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripsummary_final';

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary_final
SELECT
temp.dataload_dt,
temp.sourcefilename_ts,
temp.loadevent_id,
temp.devicetype_cd,
temp.fullpolicy_nb,
temp.voucher_nb,
temp.sr_pgm_instnc_id,
temp.deviceserial_nb,
temp.enrolledvin_nb,
temp.trip_nb,
temp.detectedvin_nb,
temp.tripstart_ts,
temp.tripend_ts,
temp.plcy_ratd_st_cd,
temp.tripdistance_qt,
temp.averagespeed_qt,
temp.maximumspeed_qt,
temp.fuelconsumption_qt,
temp.milstatus_cd,
temp.tripzoneoffset_am,
temp.idletime_ts,
temp.trippositionalquality_qt,
temp.accelerometerquality_qt,
temp.distancemotorways_qt,
temp.distanceurbanareas_qt,
temp.distanceotherroad_qt,
temp.distanceunknownroad_qt,
temp.timetravelled_qt,
temp.timemotorways_qt,
temp.timeurbanareas_qt,
temp.timeotherroad_qt,
temp.timeunknownroad_qt,
temp.speedingdistancemotorways_qt,
temp.speedingdistanceurbanareas_qt,
temp.speedingdistanceotherroad_qt,
temp.speedingdistanceunknownroad_qt,
temp.speedingtimemotorways_qt,
temp.speedingtimeurbanareas_qt,
temp.speedingtimeotherroad_qt,
temp.speedingtimeunknownroad_qt,
temp.source_cd,
temp.batch
 from ~>work_db.smartride_wk_octo_tsp_tripsummary_temp_3 temp 
 left outer join ~>work_db.smartride_wk_octo_missing_trip_ctrl mis
 on mis.trip_nb = temp.trip_nb
 where mis.trip_nb is not null; 

drop table ~>work_db.smartride_wk_octo_tsp_tripsummary;

create table ~>work_db.smartride_wk_octo_tsp_tripsummary
(
dataload_dt timestamp
,sourcefilename_ts timestamp
,loadevent_id bigint
,devicetype_cd string
,fullpolicy_nb string
,voucher_nb string
,sr_pgm_instnc_id int
,deviceserial_nb bigint
,enrolledvin_nb string
,trip_nb string
,detectedvin_nb string
,tripstart_ts timestamp
,tripend_ts timestamp
,plcy_ratd_st_cd string
,tripdistance_qt double
,averagespeed_qt double
,maximumspeed_qt double
,fuelconsumption_qt double
,milstatus_cd string
,tripzoneoffset_am string
,idletime_ts int
,trippositionalquality_qt double
,accelerometerquality_qt double
,distancemotorways_qt string
,distanceurbanareas_qt string
,distanceotherroad_qt string
,distanceunknownroad_qt string
,timetravelled_qt string
,timemotorways_qt string
,timeurbanareas_qt string
,timeotherroad_qt string
,timeunknownroad_qt string
,speedingdistancemotorways_qt string
,speedingdistanceurbanareas_qt string
,speedingdistanceotherroad_qt string
,speedingdistanceunknownroad_qt string
,speedingtimemotorways_qt string
,speedingtimeurbanareas_qt string
,speedingtimeotherroad_qt string
,speedingtimeunknownroad_qt string
,source_cd string
,batch string)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/smartride_wk_octo_tsp_tripsummary';  

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.smartride_TSP_TripSummary & ~>work_db.smartride_WK_OCTO_TSP_TripSummary from ~>work_db.smartride_WK_OCTO_TSP_TripSummary_final";

FROM ~>work_db.smartride_wk_octo_tsp_tripsummary_final
INSERT OVERWRITE TABLE ~>foundation_db.smartride_tsp_tripsummary
PARTITION (source_cd='OCTO',batch)
select
dataload_dt
,sourcefilename_ts
,loadevent_id
,devicetype_cd
,fullpolicy_nb
,voucher_nb
,sr_pgm_instnc_id
,deviceserial_nb
,enrolledvin_nb
,trip_nb
,detectedvin_nb
,tripstart_ts
,tripend_ts
,plcy_ratd_st_cd
,tripdistance_qt
,averagespeed_qt
,maximumspeed_qt
,fuelconsumption_qt
,milstatus_cd
,tripzoneoffset_am
,idletime_ts
,trippositionalquality_qt
,accelerometerquality_qt
,distancemotorways_qt
,distanceurbanareas_qt
,distanceotherroad_qt
,distanceunknownroad_qt
,timetravelled_qt
,timemotorways_qt
,timeurbanareas_qt
,timeotherroad_qt
,timeunknownroad_qt
,speedingdistancemotorways_qt
,speedingdistanceurbanareas_qt
,speedingdistanceotherroad_qt
,speedingdistanceunknownroad_qt
,speedingtimemotorways_qt
,speedingtimeurbanareas_qt
,speedingtimeotherroad_qt
,speedingtimeunknownroad_qt
,batch

INSERT OVERWRITE TABLE ~>work_db.smartride_wk_octo_tsp_tripsummary
select 
dataload_dt
,sourcefilename_ts
,loadevent_id
,devicetype_cd
,fullpolicy_nb
,voucher_nb
,sr_pgm_instnc_id
,deviceserial_nb
,enrolledvin_nb
,trip_nb
,detectedvin_nb
,tripstart_ts
,tripend_ts
,plcy_ratd_st_cd
,tripdistance_qt
,averagespeed_qt
,maximumspeed_qt
,fuelconsumption_qt
,milstatus_cd
,tripzoneoffset_am
,idletime_ts
,trippositionalquality_qt
,accelerometerquality_qt
,distancemotorways_qt
,distanceurbanareas_qt
,distanceotherroad_qt
,distanceunknownroad_qt
,timetravelled_qt
,timemotorways_qt
,timeurbanareas_qt
,timeotherroad_qt
,timeunknownroad_qt
,speedingdistancemotorways_qt
,speedingdistanceurbanareas_qt
,speedingdistanceotherroad_qt
,speedingdistanceunknownroad_qt
,speedingtimemotorways_qt
,speedingtimeurbanareas_qt
,speedingtimeotherroad_qt
,speedingtimeunknownroad_qt
,source_cd
,batch;

