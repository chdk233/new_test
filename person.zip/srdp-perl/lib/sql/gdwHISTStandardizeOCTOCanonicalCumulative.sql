use ~>smartride_raw_hive_db;

alter table OCTO_TripCumulative_Ext_h add IF NOT EXISTS partition (batch='~>batch_id');

-- Drop and recreate work table WK_OCTO_TSP_TripCumulative_h from external table OCTO_TripCumulative_Ext_h

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_OCTO_TSP_TripCumulative_h;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_OCTO_TSP_TripCumulative_h from smartride_raw_hive_db.OCTO_TripCumulative_Ext_h";

CREATE TABLE ~>smartride_work_hive_db.WK_OCTO_TSP_TripCumulative_h 
as
select DataLoad_Dt,
     DataLoad_Dt AS sourcefilename_ts,
     ~>load_event_id as LoadEvent_Id, 
     DeviceType_Cd,
    Voucher_Nb,
    DeviceSerial_ID,
    EnrolledVIN_Nb,
    '' AS DetectedVIN_Nb,
    CumulativeTrips_Qt,
    CumulativeDistance_Qt,
    CumulativeEngineOn_Qt,
    FirstTripStart_Ts,
    LastTripEnd_Ts,
    LastProcessing_Ts,
'OCTO' as Source_cd,
batch
 from  ~>smartride_raw_hive_db.OCTO_TripCumulative_Ext_h WHERE
    batch='~>batch_id';

	
use smartride_canonical_hive_db;
SET hive.exec.dynamic.partition=true;
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.map.aggr=true;
SET hive.exec.parallel=true;


set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.tsp_tripcumulative from smartride_work_hive_db.WK_OCTO_TSP_TripCumulative_h";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.tsp_tripcumulative
PARTITION (source_cd, batch)
SELECT 
cast(cast(dataload_dt as date) as timestamp)  ,
cast(cast(SourceFileName_Ts as date) as timestamp),
loadevent_id,
DeviceType_Cd ,
Voucher_Nb,
DeviceSerial_ID,
EnrolledVIN_Nb,
DetectedVIN_Nb,
CumulativeTrips_Qt,
CumulativeDistance_Qt,
CumulativeEngineOn_Qt,
FirstTripStart_Ts,
LastTripEnd_Ts,
LastProcessing_Ts, 
source_cd,
batch
from ~>smartride_work_hive_db.WK_OCTO_TSP_TripCumulative_h;
