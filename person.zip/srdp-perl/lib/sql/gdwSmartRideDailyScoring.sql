SET mapred.job.name = "~>job_cd Create Table wk_daily_record from hive_sre_hourly";

DROP TABLE IF EXISTS ~>work_db.wk_daily_record;

CREATE TABLE  ~>work_db.wk_daily_record (
     sr_pgm_instnc_id    bigint, 
     source_cd    string, 
     deviceserial_nb    bigint, 
     enrolledvin_nb    string, 
     score_date    string, 
     fast_acceleration_ct    bigint, 
     hard_brake_ct    bigint, 
     scrub_miles    double, 
     adjust_miles    double, 
     drive_time    bigint, 
     idle_time    bigint, 
     no_idle_time    bigint, 
     plausible_percentage    double, 
     plcy_ratd_st_cd    string, 
     weighted_time_of_day    double, 
     stop_per_kilometer    double, 
     brake_per_kilometer    double)
STORED AS PARQUET
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_daily_record';
  
INSERT INTO TABLE  ~>work_db.wk_daily_record
SELECT
b.sr_pgm_instnc_id
,source_cd
,deviceserial_nb
,enrolledvin_nb
,from_unixtime(unix_timestamp()) AS score_date
,sum(fast_acceleration_ct) AS fast_acceleration_ct
,sum(hard_brake_ct) AS hard_brake_ct
,sum(plausible_miles) AS scrub_miles
,sum(adjusted_miles) AS adjust_miles
,sum(plausible_drive_time_sec_count) AS drive_time
,sum(plausible_idle_time_sec_count) AS idle_time
,(sum(plausible_drive_time_sec_count) - sum(plausible_idle_time_sec_count)) AS no_idle_time
,CASE WHEN sum(drive_time_sec_count)= 0 THEN 0.0 ELSE CAST (round((sum(plausible_drive_time_sec_count)/sum(drive_time_sec_count)) * 100,2) AS double) END  AS plausible_percentage
,b.plcy_ratd_st_cd
,least(cast((sum(adjusted_km)/sum(kilometers)) as double),1.5) as weighted_time_of_day
,greatest(0.000000001,least(2.0,cast(sum(stop_second_cn)/sum(kilometers) as double))) as stop_per_kilometer
,greatest(0.000000001,least(2.0,cast(sum(hard_brake_ct)/sum(kilometers) as double))) as brake_per_kilometer
from  ~>foundation_db.smartride_hive_sre_hourly a

inner join
(
    select
    vhcl_id_nbr,
    sr_pgm_instnc_id,
    sr_enrlmnt_dt,
    active_end_dt,
    plcy_ratd_st_cd
    from ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc
    where sr_enrlmnt_dt >= '~>date_filter_18_mo_ago'
) b
on a.enrolledvin_nb = b.vhcl_id_nbr

where batch >= '~>batch_filter_18_mo_ago'
and b.plcy_ratd_st_cd <> 'CA'
and a.periodstart_ts between b.sr_enrlmnt_dt and b.active_end_dt
group by b.sr_pgm_instnc_id,source_cd,deviceserial_nb,enrolledvin_nb,b.plcy_ratd_st_cd;


SET mapred.job.name = "~>job_cd Create Table wk_sre_scoring_daily from device_install_pcnt & ~>work_db.wk_daily_record";

DROP TABLE IF EXISTS ~>work_db.wk_sre_scoring_daily;

CREATE TABLE  ~>work_db.wk_sre_scoring_daily  (
     device_serial_number    bigint, 
     policy_number    string, 
     enrolled_vin    string, 
     sr_pgm_instnc_id    bigint, 
     score_start_date    timestamp, 
     score_end_date    timestamp, 
     score_days    bigint, 
     score_model_1    string, 
     pure_score_1    int, 
     rated_score_1    int, 
     filler_1    string, 
     score_model_2    string, 
     pure_score_2    bigint, 
     rated_score_2    bigint, 
     filler_2    string, 
     score_model_3    string, 
     pure_score_3    string, 
     rated_score_3    string, 
     filler_3    string, 
     score_model_4    string, 
     pure_score_4    string, 
     rated_score_4    string, 
     filler_4    string, 
     score_model_5    string, 
     pure_score_5    string, 
     rated_score_5    string, 
     filler_5    string, 
     score_model_6    string, 
     pure_score_6    string, 
     rated_score_6    string, 
     filler_6    string, 
     score_model_7    string, 
     pure_score_7    string, 
     rated_score_7    string, 
     filler_7    string, 
     score_model_8    string, 
     pure_score_8    string, 
     rated_score_8    string, 
     filler_8    string, 
     score_model_9    string, 
     pure_score_9    string, 
     rated_score_9    string, 
     filler_9    string, 
     score_model_10    string, 
     pure_score_10    string, 
     rated_score_10    string, 
     filler_10    string, 
     percent_time_disconnected    double, 
     calculated_annual_mileage    double, 
     uninstalled_time    bigint, 
     filler    string, 
     model_id    string, 
     hard_brake_ct    int, 
     fast_acceleration_ct    int, 
     scrub_miles    double, 
     adjust_miles    double, 
     no_idle_time    bigint, 
     idle_time    bigint, 
     install_percentage    double, 
     plausible_percentage    double, 
     score_date    varchar(10), 
     number_of_connect_disconect    string)
STORED AS PARQUET 
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_sre_scoring_daily'; 

INSERT OVERWRITE TABLE  ~>work_db.wk_sre_scoring_daily
SELECT
Device_Serial_Number
,' ' AS Policy_Number
,Enrolled_VIN
,sr_pgm_instnc_id
, Score_Start_Date
,Score_End_Date
,Score_Days
,'ND1' as Score_Model_1
,case
when Pure_Score_1 < 1  then 1
when Pure_Score_1 > 995  then 995
else Pure_Score_1 end as Pure_Score_1
,case
when install_percentage < 95 then 998
when (plausible_percentage < 97 or plausible_percentage is null) then 997
else case
when Pure_Score_1 < 1  then 1
when Pure_Score_1 > 995  then 995
else Pure_Score_1 end
end
as rated_score_1
,' ' as Filler_1
,'SM1' as Score_Model_2
,case
when Pure_Score_2 < 1  then 1
when Pure_Score_2 > 995  then 995
else Pure_Score_2 end Pure_Score_2
,case
when install_percentage < 95 then 998
when (plausible_percentage < 97 or plausible_percentage is null) then 997
else case
when Pure_Score_2 < 1  then 1
when Pure_Score_2 > 995  then 995
else Pure_Score_2 end
end
as rated_score_2
,' ' as Filler_2
,' ' as Score_Model_3
,' ' as Pure_Score_3
,' ' as Rated_Score_3
,' ' as Filler_3
,' ' as Score_Model_4
,' ' as Pure_Score_4
,' ' as Rated_Score_4
,' ' as Filler_4
,' ' as Score_Model_5
,' ' as Pure_Score_5
,' ' as Rated_Score_5
,' ' as Filler_5
,' ' as Score_Model_6
,' ' as Pure_Score_6
,' ' as Rated_Score_6
,' ' as Filler_6
,' ' as Score_Model_7
,' ' as Pure_Score_7
,' ' as Rated_Score_7
,' ' as Filler_7
,' ' as Score_Model_8
,' ' as Pure_Score_8
,' ' as Rated_Score_8
,' ' as Filler_8
,' ' as Score_Model_9
,' ' as Pure_Score_9
,' ' as Rated_Score_9
,' ' as Filler_9
,' ' as Score_Model_10
,' ' as Pure_Score_10
,' ' as Rated_Score_10
,' ' as Filler_10
,Percent_Time_Disconnected
,CASE WHEN (days_installed IS NULL OR days_installed = 0.0) THEN 0.0 ELSE ((scrub_miles/days_installed) * 365) END AS Calculated_Annual_Mileage
,Uninstalled_Time
,' ' AS Filler
,' ' AS Model_ID
,hard_brake_ct
,fast_acceleration_ct
,scrub_miles
,adjust_miles
,no_idle_time
,idle_time
,install_percentage
,plausible_percentage
,Score_Date
,Number_of_Connect_Disconect
FROM (
SELECT
days_installed
,( case
when (days_installed is null or days_installed = 0.0 or adjust_miles is null or  HBPD is null or  fapd is null or  itpct  is null) then 995
when (avg_distnace*1.60934) <= 8.82 then                             cast(floor(100*(0.0+(HBPD)*0.1604    + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 8.82   and (avg_distnace*1.60934) <= 17.64  then  cast(floor(100*(0.2399+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 17.64  and (avg_distnace*1.60934) <= 26.45  then  cast(floor(100*(0.6353+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 26.45  and (avg_distnace*1.60934) <= 35.27  then  cast(floor(100*(0.7423+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 35.27  and (avg_distnace*1.60934) <= 44.09  then  cast(floor(100*(0.8572+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 44.09  and (avg_distnace*1.60934) <= 52.91  then  cast(floor(100*(0.9678+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 52.91  and (avg_distnace*1.60934) <= 61.73  then  cast(floor(100*(1.0059+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 61.73  and (avg_distnace*1.60934) <= 70.55  then  cast(floor(100*(1.0440+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 70.55  and (avg_distnace*1.60934) <= 79.36  then  cast(floor(100*(1.0835+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 79.36  and (avg_distnace*1.60934) <= 88.18  then  cast(floor(100*(1.1261+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 88.18  and (avg_distnace*1.60934) <= 97.00  then  cast(floor(100*(1.1686+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 97.00  and (avg_distnace*1.60934) <= 105.82 then  cast(floor(100*(1.2111+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 105.82 and (avg_distnace*1.60934) <= 114.64 then  cast(floor(100*(1.2537+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 114.64 and (avg_distnace*1.60934) <= 123.46 then  cast(floor(100*(1.2962+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 123.46 and (avg_distnace*1.60934) <= 132.27 then  cast(floor(100*(1.3388+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
when (avg_distnace*1.60934) > 132.27                                      then  cast(floor(100*(1.3813+(HBPD)*0.1604 + (fapd)*0.1184 + (itpct)*4.2432)) as int)
 end ) as Pure_Score_1
,ceil(200 * (1.4416 + (0.2869) * ln(brake_per_kilometer) + (0.7234) * ln(stop_per_kilometer) + (2.0016) * weighted_time_of_day)) as Pure_Score_2
,Device_Serial_Number
,Enrolled_VIN
,sr_pgm_instnc_id
,Score_Start_Date
,Score_End_Date
,Score_Days
,Percent_Time_Disconnected
,Uninstalled_Time
,hard_brake_ct
,fast_acceleration_ct
,scrub_miles
,no_idle_time
,idle_time
,install_percentage
,plausible_percentage
,Score_Date
,adjust_miles
,Number_of_Connect_Disconect
FROM
(SELECT
 days_installed
,CASE WHEN trip.adjust_miles IS NULL THEN 0.0 ELSE trip.adjust_miles END AS adjust_miles
,(CASE WHEN trip.adjust_miles IS NULL THEN 0.0 ELSE trip.adjust_miles END/days_installed) AS avg_distnace
,CASE WHEN days_installed = 0 THEN 0.0 WHEN ( CASE WHEN trip.hard_brake_ct IS NULL THEN 0 ELSE CAST(trip.hard_brake_ct AS INT) END /days_installed)> 7.0 THEN 7.0 ELSE (CASE WHEN trip.hard_brake_ct IS NULL THEN 0 ELSE CAST(trip.hard_brake_ct AS INT) END/days_installed) END HBPD
,CASE WHEN days_installed = 0 THEN 0.0 WHEN (CASE WHEN trip.fast_acceleration_ct IS NULL THEN 0 ELSE CAST(trip.fast_acceleration_ct AS int) END/days_installed)> 4.0 THEN 4.0 ELSE (CASE WHEN trip.fast_acceleration_ct IS NULL THEN 0 ELSE CAST(trip.fast_acceleration_ct AS int) END/days_installed) END fapd
,CASE WHEN (trip.idle_time IS NULL OR trip.no_idle_time IS NULL) THEN 0.0 ELSE (trip.idle_time/(trip.idle_time+trip.no_idle_time)) END AS itpct
,device.deviceserial_id AS Device_Serial_Number
,device.enrolledvin_nb AS Enrolled_VIN
,device.sr_pgm_instnc_id AS sr_pgm_instnc_id
,device.first_activity_date AS Score_Start_Date
,device.last_activity_date AS Score_End_Date
,device.total_days AS Score_Days
,device.uninstall_percentage AS Percent_Time_Disconnected
,device.total_uninstall_time AS Uninstalled_Time
,CASE WHEN trip.hard_brake_ct IS NULL THEN 0 ELSE CAST(trip.hard_brake_ct AS int) END AS hard_brake_ct
,CASE WHEN trip.fast_acceleration_ct IS NULL THEN 0 ELSE CAST(trip.fast_acceleration_ct AS int) END AS fast_acceleration_ct
,CASE WHEN trip.scrub_miles IS NULL THEN 0.0 ELSE trip.scrub_miles END AS scrub_miles
,CASE WHEN trip.no_idle_time IS NULL THEN CAST(0 AS bigint)  ELSE trip.no_idle_time END AS no_idle_time
,CASE WHEN trip.idle_time IS NULL THEN CAST (0 AS bigint) ELSE trip.idle_time END AS idle_time
,device.install_percentage
,case when trip.plausible_percentage is null then 100.00 else trip.plausible_percentage end as plausible_percentage
,CAST (from_unixtime(unix_timestamp()) as varchar(10) ) as Score_Date
,concat(concat(LPAD(trim(cast(if (connection_ct is null,' ',connection_ct) as varchar(3))),3,'000'),'_'),LPAD(trim(cast(if (disconnection_ct is null,' ',disconnection_ct) as varchar(3))),3,'000'))  as Number_of_Connect_Disconect
,trip.weighted_time_of_day
,trip.stop_per_kilometer
,trip.brake_per_kilometer
from ~>foundation_db.smartride_device_install_pcnt device
inner join ~>work_db.wk_daily_record trip
ON device.sr_pgm_instnc_id = trip.sr_pgm_instnc_id
AND device.deviceserial_id = trip.deviceserial_nb
AND device.enrolledvin_nb = trip.enrolledvin_nb
WHERE device.sr_pgm_instnc_id IS NOT NULL
AND device.sr_pgm_instnc_id != -1
AND CASE WHEN trip.plcy_ratd_st_cd IS NULL THEN 'Null State' ELSE trip.plcy_ratd_st_cd  END  <> 'CA'
) temp1) temp2
;

SET mapred.job.name = "~>job_cd Insert Overwrite hive_sre_scoring from wk_sre_scoring_daily";

FROM ~>work_db.wk_sre_scoring_daily
INSERT INTO TABLE ~>provide_db.smartride_hive_sre_scoring partition(score_date)
SELECT
device_serial_number
,policy_number
,enrolled_vin
,sr_pgm_instnc_id
,score_start_date
,score_end_date
,score_days
,score_model_1
,pure_score_1
,rated_score_1
,filler_1
,score_model_2
,pure_score_2
,rated_score_2
,filler_2
,score_model_3
,pure_score_3
,rated_score_3
,filler_3
,score_model_4
,pure_score_4
,rated_score_4
,filler_4
,score_model_5
,pure_score_5
,rated_score_5
,filler_5
,score_model_6
,pure_score_6
,rated_score_6
,filler_6
,score_model_7
,pure_score_7
,rated_score_7
,filler_7
,score_model_8
,pure_score_8
,rated_score_8
,filler_8
,score_model_9
,pure_score_9
,rated_score_9
,filler_9
,score_model_10
,pure_score_10
,rated_score_10
,filler_10
,percent_time_disconnected
,calculated_annual_mileage
,number_of_connect_disconect
,uninstalled_time
,filler
,model_id
,hard_brake_ct
,fast_acceleration_ct
,scrub_miles
,adjust_miles
,no_idle_time
,idle_time
,install_percentage
,plausible_percentage
,score_date;


INSERT OVERWRITE TABLE ~>provide_db.smartride_scoring_daily_file 
Select concat(device_serial_number,policy_number,enrolled_vin,sr_pgm_instnc_id, score_date,score_start_date,score_end_date,score_days,score_model_1,pure_score_1,rated_score_1,filler_1,score_model_2,pure_score_2,rated_score_2,filler_2,score_model_3,pure_score_3,rated_score_3,filler_3,score_model_4,pure_score_4,rated_score_4,filler_4,score_model_5,pure_score_5,rated_score_5,filler_5,score_model_6,pure_score_6,rated_score_6,filler_6,score_model_7,pure_score_7,rated_score_7,filler_7,score_model_8,pure_score_8,rated_score_8,filler_8,score_model_9,pure_score_9,rated_score_9,filler_9,score_model_10,pure_score_10,rated_score_10,filler_10,percent_time_disconnected,calculated_annual_mileage,number_of_connect_disconect,uninstalled_time,filler)
From
(select
  RPAD(trim(if(device_serial_number is null,' ', Cast(device_serial_number as varchar(25)))),25,' ')as device_serial_number
,RPAD(trim(if(policy_number is null,' ', Cast(policy_number as varchar(20)))),20,' ')as policy_number
,RPAD(trim(if(enrolled_vin is null,' ', Cast(enrolled_vin as varchar(17)))),17,' ')as enrolled_vin
,LPAD(trim(if(sr_pgm_instnc_id is null,' ', Cast(sr_pgm_instnc_id as varchar(36)))),36,'0')as sr_pgm_instnc_id
,RPAD(regexp_replace(if(score_date is null,' ', Cast(score_date as varchar(10))),'-',''),8,' ') as score_date
,RPAD(regexp_replace(if(score_start_date is null,' ', Cast(score_start_date as varchar(10))),'-',''),8,' ') as score_start_date
,RPAD(regexp_replace(if(score_end_date is null,' ', Cast(score_end_date as varchar(10))),'-',''),8,' ') as score_end_date
,LPAD(CAST(if(score_days is null,0,cast(score_days as int)) as varchar(5)),3,'0')as score_days
,RPAD(trim(if(score_model_1 is null,' ', Cast(score_model_1 as varchar(4)))),4,' ')as score_model_1
,LPAD(trim(if(pure_score_1 is null,' ', Cast(pure_score_1 as varchar(3)))),3,'0')as pure_score_1
,LPAD(trim(if(rated_score_1 is null,' ', Cast(rated_score_1 as varchar(3)))),3,'0')as rated_score_1
,RPAD(trim(if(filler_1 is null,' ', Cast(filler_1 as varchar(10)))),10,' ')as filler_1
,RPAD(trim(if(score_model_2 is null,' ', Cast(score_model_2 as varchar(4)))),4,' ')as score_model_2
,LPAD(trim(if(pure_score_2 is null,' ', Cast(pure_score_2 as varchar(3)))),3,'0')as pure_score_2
,LPAD(trim(if(rated_score_2 is null,' ', Cast(rated_score_2 as varchar(3)))),3,'0')as rated_score_2
,RPAD(trim(if(filler_2 is null,' ', Cast(filler_2 as varchar(10)))),10,' ')as filler_2
,RPAD(trim(if(score_model_3 is null,' ', Cast(score_model_3 as varchar(4)))),4,' ')as score_model_3
,LPAD(trim(if(pure_score_3 is null,' ', Cast(pure_score_3 as varchar(3)))),3,'0')as pure_score_3
,LPAD(trim(if(rated_score_3 is null,' ', Cast(rated_score_3 as varchar(3)))),3,'0')as rated_score_3
,RPAD(trim(if(filler_3 is null,' ', Cast(filler_3 as varchar(10)))),10,' ')as filler_3
,RPAD(trim(if(score_model_4 is null,' ', Cast(score_model_4 as varchar(4)))),4,' ')as score_model_4
,LPAD(trim(if(pure_score_4 is null,' ', Cast(pure_score_4 as varchar(3)))),3,'0')as pure_score_4
,LPAD(trim(if(rated_score_4 is null,' ', Cast(rated_score_4 as varchar(3)))),3,'0')as rated_score_4
,RPAD(trim(if(filler_4 is null,' ', Cast(filler_4 as varchar(10)))),10,' ')as filler_4
,RPAD(trim(if(score_model_5 is null,' ', Cast(score_model_5 as varchar(4)))),4,' ')as score_model_5
,LPAD(trim(if(pure_score_5 is null,' ', Cast(pure_score_5 as varchar(3)))),3,'0')as pure_score_5
,LPAD(trim(if(rated_score_5 is null,' ', Cast(rated_score_5 as varchar(3)))),3,'0')as rated_score_5
,RPAD(trim(if(filler_5 is null,' ', Cast(filler_5 as varchar(10)))),10,' ')as filler_5
,RPAD(trim(if(score_model_6 is null,' ', Cast(score_model_6 as varchar(4)))),4,' ')as score_model_6
,LPAD(trim(if(pure_score_6 is null,' ', Cast(pure_score_6 as varchar(3)))),3,'0')as pure_score_6
,LPAD(trim(if(rated_score_6 is null,' ', Cast(rated_score_6 as varchar(3)))),3,'0')as rated_score_6
,RPAD(trim(if(filler_6 is null,' ', Cast(filler_6 as varchar(10)))),10,' ')as filler_6
,RPAD(trim(if(score_model_7 is null,' ', Cast(score_model_7 as varchar(4)))),4,' ')as score_model_7
,LPAD(trim(if(pure_score_7 is null,' ', Cast(pure_score_7 as varchar(3)))),3,'0')as pure_score_7
,LPAD(trim(if(rated_score_7 is null,' ', Cast(rated_score_6 as varchar(3)))),3,'0')as rated_score_7
,RPAD(trim(if(filler_7 is null,' ', Cast(filler_7 as varchar(10)))),10,' ')as filler_7
,RPAD(trim(if(score_model_8 is null,' ', Cast(score_model_8 as varchar(4)))),4,' ')as score_model_8
,LPAD(trim(if(pure_score_8 is null,' ', Cast(pure_score_8 as varchar(3)))),3,'0')as pure_score_8
,LPAD(trim(if(rated_score_8 is null,' ', Cast(rated_score_6 as varchar(3)))),3,'0')as rated_score_8
,RPAD(trim(if(filler_8 is null,' ', Cast(filler_8 as varchar(10)))),10,' ')as filler_8
,RPAD(trim(if(score_model_9 is null,' ', Cast(score_model_9 as varchar(4)))),4,' ')as score_model_9
,LPAD(trim(if(pure_score_9 is null,' ', Cast(pure_score_9 as varchar(3)))),3,'0')as pure_score_9
,LPAD(trim(if(rated_score_9 is null,' ', Cast(rated_score_6 as varchar(3)))),3,'0')as rated_score_9
,RPAD(trim(if(filler_9 is null,' ', Cast(filler_9 as varchar(10)))),10,' ')as filler_9
,RPAD(trim(if(score_model_10 is null,' ', Cast(score_model_10 as varchar(4)))),4,' ')as score_model_10
,LPAD(trim(if(pure_score_10 is null,' ', Cast(pure_score_10 as varchar(3)))),3,'0')as pure_score_10
,LPAD(trim(if(rated_score_10 is null,' ', Cast(rated_score_6 as varchar(3)))),3,'0')as rated_score_10
,RPAD(trim(if(filler_10 is null,' ', Cast(filler_10 as varchar(10)))),10,' ')as filler_10
,LPAD(CAST(if(percent_time_disconnected is null,0,cast(percent_time_disconnected*100 as int)) as varchar(5)),5,'0')as percent_time_disconnected
,LPAD(trim(if(calculated_annual_mileage is null,' ', Cast(calculated_annual_mileage as varchar(6)))),6,'0')as calculated_annual_mileage
,RPAD(trim(if(number_of_connect_disconect is null,' ', Cast(number_of_connect_disconect as varchar(7)))),7,' ')as number_of_connect_disconect
,concat(concat(concat(concat (LPAD(trim(if(uninstalled_time is null,' ', Cast(cast(uninstalled_time/86400 as int) as varchar(3)))),3,'0') , ':'),
LPAD(trim(if(uninstalled_time is null,' ', Cast(cast((uninstalled_time%86400)/3600 as int) as varchar(3)))),2,'0') , ':'),
LPAD(trim(if(uninstalled_time is null,' ', Cast(CAST(((uninstalled_time%86400)%3600)/60 as INT)as varchar(3)))),2,'0') , ':'),
LPAD(trim(if(uninstalled_time is null,' ', Cast(((uninstalled_time%86400)%3600)%60 as varchar(3)))),2,'0')) as uninstalled_time
,RPAD(trim(if(filler is null,' ', Cast(filler as varchar(45)))),45,' ')as filler
 from ~>work_db.wk_sre_scoring_daily) temp;