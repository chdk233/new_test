use ~>smartride_raw_hive_db;

alter table IMS_TripPoint_Ext_H add IF NOT EXISTS partition (batch='~>batch_id');

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_IMS_TSP_TripPoint;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_IMS_TSP_TripPoint from smartride_raw_hive_db.IMS_TripPoint_Ext_H";

CREATE TABLE ~>smartride_work_hive_db.WK_IMS_TSP_TripPoint AS
select cast(cast(DataLoad_Dt as date) as timestamp) as DataLoad_Dt,
cast(cast(DataLoad_Dt as date) as timestamp) as sourcefilename_ts,
~>load_event_id as LoadEvent_Id, 
'' as DeviceType_Cd,
'' as FullPolicy_Nb,
'' as Voucher_Nb,
Trip_Nb,
Position_Ts,
Latitude_It,
Longitude_It,
VSSSpeed_Am,
VSSAcceleration_Pc,
enginerpm_am as enginerpm_qt,
ThrottlePosition_Pc,
AccelerationLateral_Nb as AccelerationLateral_qt,
Accelerationlongitudinal_Nb as Accelerationlongitudinal_qt,
AccelerationVertical_Nb as AccelerationVertical_qt,
GPSHeading_Nb,
PositionQuality_Nb,
'' as OdometerReading_Qt,
'' as EventAverageSpeed_Qt,
'' as EventAverageAcceleration_Qt,
'' as DistanceTravelled_Qt,
'' as TimeElapsed_Qt,
'' as GPSPointSpeed_Qt,
'' as Road_Tp,
'IMS' as source_cd,
batch  
from ~>smartride_raw_hive_db.IMS_TripPoint_Ext_H WHERE
batch='~>batch_id';

set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=100000; 
set hive.exec.max.dynamic.partitions.pernode=100000; 
set hive.exec.parallel=false;

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.TSP_TripPoint from smartride_work_hive_db.WK_IMS_TSP_TripPoint";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.TSP_TripPoint PARTITION(source_cd,batch)
SELECT
DataLoad_Dt,
sourcefilename_ts,
LoadEvent_Id,
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
Trip_Nb,
Position_Ts,
Latitude_It,
Longitude_It,
VSSSpeed_Am,
VSSAcceleration_Pc,
enginerpm_qt,
ThrottlePosition_Pc,
AccelerationLateral_qt,
AccelerationLongitudinal_qt,
AccelerationVertical_qt,
GPSHeading_Nb,
PositionQuality_Nb,
OdometerReading_Qt,
EventAverageSpeed_Qt,
EventAverageAcceleration_Qt,
DistanceTravelled_Qt,
TimeElapsed_Qt,
GPSPointSpeed_Qt,
Road_Tp,
source_cd,
batch
FROM ~>smartride_work_hive_db.WK_IMS_TSP_TripPoint;
