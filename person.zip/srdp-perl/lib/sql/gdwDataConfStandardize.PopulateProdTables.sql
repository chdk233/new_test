set hive.vectorized.execution.enabled=false;
set mapreduce.map.java.opts = -Xmx8000m ;
set mapreduce.map.memory.mb = 10000;

-------------------------------------------------------------
-- Project: Data Confidential                              --
-- Created On: 11/06/2017                                  --
-- Created By: Big Heroes Team                             --
-- Description: This script captures delta for Production  --
--              smartride canonical tables                 --
-- For Performance : 1. Hard coded source code in the      --
--                      partition & removed from Select    --
--                   2. Separated Inserts by each source cd--
--                   3. Used ods skinny table              --
--                   4. Removed batch to process join and  --
--                                 added as a filter       --
-------------------------------------------------------------

-------------------------------------- Table: dc_audit_bal_tripcumu_tripsumm --------------------------------------

--This is removed due to error SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_audit_bal_tripcumu_tripsumm from canonical table"

INSERT INTO TABLE ~>srdp_wk_db.dc_audit_bal_tripcumu_tripsumm
PARTITION (source_cd='~>source_cd', batch)
SELECT
c.dc_instance_id
,a.loadevent_id
,a.tripsummary_trip_ct
,a.cumulative_trip_ct
,a.batch
FROM ~>srdp_cncl_db.audit_bal_tripcumu_tripsumm a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list);


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_tsp_tripsummary from canonical table";

----------------------------------------- Table: dc_tsp_tripsummary --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_tsp_tripsummary
PARTITION (source_cd='~>source_cd',batch)
SELECT DISTINCT
c.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.fullpolicy_nb
,a.voucher_nb
,a.trip_nb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END
,a.tripstart_ts
,a.tripend_ts
,a.plcy_ratd_st_cd
,a.tripdistance_qt
,a.averagespeed_qt
,a.maximumspeed_qt
,a.fuelconsumption_qt
,a.milstatus_cd
,a.tripzoneoffset_am
,a.idletime_ts
,a.trippositionalquality_qt
,a.accelerometerquality_qt
,a.distancemotorways_qt
,a.distanceurbanareas_qt
,a.distanceotherroad_qt
,a.distanceunknownroad_qt
,a.timetravelled_qt
,a.timemotorways_qt
,a.timeurbanareas_qt
,a.timeotherroad_qt
,a.timeunknownroad_qt
,a.speedingdistancemotorways_qt
,a.speedingdistanceurbanareas_qt
,a.speedingdistanceotherroad_qt
,a.speedingdistanceunknownroad_qt
,a.speedingtimemotorways_qt
,a.speedingtimeurbanareas_qt
,a.speedingtimeotherroad_qt
,a.speedingtimeunknownroad_qt
,a.batch
FROM ~>srdp_cncl_db.tsp_tripsummary a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list);


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_centroid_summary from canonical table";

----------------------------------------- Table: dc_centroid_summary --------------------------------------
-----  NOTE: This table needs to run only after the dc_tsp_tripsummary is built --

INSERT INTO TABLE ~>srdp_wk_db.dc_centroid_summary
PARTITION (source_cd='~>source_cd', batch)
SELECT
b.dc_instance_id
,a.trip_nb
,a.centroid_rpm_start
,a.centroid_start_time
,a.centroid_end_time
,a.min_scrubbed_speed
,a.max_scrubbed_speed
,a.min_delta_scrubbed_speed
,a.max_delta_scrubbed_speed
,a.scrubbed_speed_decreasing_count
,a.scrubbed_speed_increasing_count
,a.scrubbed_speed_steady_count
,a.absolute_speed_change
,a.end_scrubbed_speed_bump
,a.plausible_indicator
,a.plausibility_reason
,a.centroid_number
,a.batch
FROM ~>srdp_cncl_db.centroid_summary a

LEFT OUTER JOIN ~>srdp_wk_db.dc_tsp_tripsummary b

ON a.source_cd = b.source_cd
AND a.batch = b.batch and a.trip_nb=b.trip_nb

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list);


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_tripdetail_seconds from canonical table";

----------------------------------------- Table: dc_tripdetail_seconds --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_tripdetail_seconds
PARTITION(source_cd='~>source_cd',batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.trip_nb
,a.position_ts
,a.position_offset_ts
,a.speed_mph
,a.speed_kph
,a.distance
,a.distance_kph
,a.nighttime_driving_ind
,a.eventcounter_fa
,a.eventcounter_hb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END
,a.tripzoneoffset_am
,a.plcy_ratd_st_cd
,a.enginerpm_qt
,a.time_driving_ind
,a.time_idle_ind
,a.plausible_ind
,a.centroid_nb
,a.scrubbed_fields
,a.loadevent_id
,case
        when a.plcy_ratd_st_cd in ('NY','null') THEN
                case
                        when sum(a.distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)<=1 then NULL
                        when sum(a.distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)>= (sum(a.distance) over (partition by a.trip_nb)-1) then NULL
                        else a.latitude_it
                end
        else a.latitude_it
end as latitude_it
,case
        when a.plcy_ratd_st_cd in ('NY','null') THEN
                case
                        when sum(a.distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)<=1 then NULL
                        when sum(a.distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)>= (sum(a.distance) over (partition by a.trip_nb)-1) then NULL
                        else a.longitude_it
                end
        else a.longitude_it
end as longitude_it
,a.batch
FROM ~>srdp_cncl_db.tripdetail_seconds a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list)
AND 'IMS' = '~>source_cd';

INSERT INTO TABLE ~>srdp_wk_db.dc_tripdetail_seconds
PARTITION(source_cd='~>source_cd',batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.trip_nb
,a.position_ts
,a.position_offset_ts
,a.speed_mph
,a.speed_kph
,a.distance
,a.distance_kph
,a.nighttime_driving_ind
,a.eventcounter_fa
,a.eventcounter_hb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END
,a.tripzoneoffset_am
,a.plcy_ratd_st_cd
,a.enginerpm_qt
,a.time_driving_ind
,a.time_idle_ind
,a.plausible_ind
,a.centroid_nb
,a.scrubbed_fields
,a.loadevent_id
,a.latitude_it
,a.longitude_it
,a.batch
FROM ~>srdp_cncl_db.tripdetail_seconds a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list)
AND 'OCTO' = '~>source_cd';


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_trip_details from canonical table";

----------------------------------------- Table: dc_trip_details --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_trip_details
PARTITION (source_cd='~>source_cd', batch)
SELECT
c.dc_instance_id
,a.period_type
,a.periodstart_ts
,a.periodend_ts
,a.miles
,a.kilometers
,a.night_time_driving_sec_ct
,a.fast_acceleration_ct
,a.hard_brake_ct
,a.idle_time_sec_ct
,a.drive_time_sec_ct
,a.idle_time_ratio
,a.trip_nb
,a.batch
FROM ~>srdp_cncl_db.trip_details a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc c
ON a.sr_pgm_instnc_id = c.sr_pgm_instnc_id

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list);


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_tsp_tripcumulative from canonical table";

----------------------------------------- Table: dc_tsp_tripcumulative --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_tsp_tripcumulative
PARTITION (source_cd='~>source_cd',batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.voucher_nb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END
,a.cumulativetrips_qt
,a.cumulativedistance_qt
,a.cumulativeengineon_qt
,a.firsttripstart_ts
,a.lasttripend_ts
,a.lastprocessing_ts
,a.batch
FROM ~>srdp_cncl_db.tsp_tripcumulative a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list);


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_garbage_tripdetail_seconds from canonical table";

----------------------------------------- Table: dc_garbage_tripdetail_seconds --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_garbage_tripdetail_seconds
PARTITION (source_cd='~>source_cd', batch)
SELECT
c.dc_instance_id,
a.dataload_dt,
a.trip_nb,
a.position_ts,
a.position_offset_ts,
a.speed_mph,
a.speed_kph,
a.distance,
a.distance_kph,
a.nighttime_driving_ind,
a.eventcounter_fa,
a.eventcounter_hb,
CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END,
a.tripzoneoffset_am,
a.plcy_ratd_st_cd,
a.enginerpm_qt,
a.time_driving_ind,
a.time_idle_ind,
a.plausible_ind,
a.centroid_nb,
a.scrubbed_fields,
a.loadevent_id,
case
        when a.plcy_ratd_st_cd in ('NY','null') THEN
                case
                        when sum(a.adjusted_distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)<=1 then NULL
                        when sum(a.adjusted_distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)>= (sum(a.adjusted_distance) over (partition by a.trip_nb)-1) then NULL
                        else a.latitude_it
                end
        else a.latitude_it
end as latitude_it,
case
        when a.plcy_ratd_st_cd in ('NY','null') THEN
                case
                        when sum(a.adjusted_distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)<=1 then NULL
                        when sum(a.adjusted_distance) over (partition by a.trip_nb order by a.position_offset_ts asc rows between unbounded preceding and current row)>= (sum(a.adjusted_distance) over (partition by a.trip_nb)-1) then NULL
                        else a.longitude_it
                end
        else a.longitude_it
end as longitude_it,
a.batch
FROM (SELECT
        dataload_dt,
        programinstance_id,
        trip_nb,
        position_ts,
        position_offset_ts,
        speed_mph,
        speed_kph,
        distance,
        greatest(0.00,distance) as adjusted_distance, 
        distance_kph,
        nighttime_driving_ind,
        eventcounter_fa,
        eventcounter_hb,
        deviceserial_nb,
        enrolledvin_nb,
        detectedvin_nb,
        tripzoneoffset_am,
        plcy_ratd_st_cd,
        enginerpm_qt,
        time_driving_ind,
        time_idle_ind,
        plausible_ind,
        centroid_nb,
        scrubbed_fields,
        loadevent_id,
        latitude_it,
        longitude_it,
        source_cd,
        batch
FROM  ~>srdp_cncl_db.garbage_tripdetail_seconds
WHERE source_cd = '~>source_cd'
AND batch IN (~>batch_list)
AND 'IMS' = '~>source_cd') a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr
;



INSERT INTO TABLE ~>srdp_wk_db.dc_garbage_tripdetail_seconds
PARTITION (source_cd='~>source_cd', batch)
SELECT
c.dc_instance_id,
a.dataload_dt,
a.trip_nb,
a.position_ts,
a.position_offset_ts,
a.speed_mph,
a.speed_kph,
a.distance,
a.distance_kph,
a.nighttime_driving_ind,
a.eventcounter_fa,
a.eventcounter_hb,
CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END,
a.tripzoneoffset_am,
a.plcy_ratd_st_cd,
a.enginerpm_qt,
a.time_driving_ind,
a.time_idle_ind,
a.plausible_ind,
a.centroid_nb,
a.scrubbed_fields,
a.loadevent_id,
a.latitude_it,
a.longitude_it,
a.batch
FROM ~>srdp_cncl_db.garbage_tripdetail_seconds a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.deviceserial_nb = c.dev_id_nbr
AND a.enrolledvin_nb = c.vhcl_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list)
AND 'OCTO' = '~>source_cd';


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_tsp_trippoint from canonical table";

----------------------------------------- Table: dc_tsp_trippoint --------------------------------------

INSERT INTO TABLE  ~>srdp_wk_db.dc_tsp_trippoint
PARTITION (source_cd='~>source_cd', batch)
SELECT  a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.fullpolicy_nb
,a.voucher_nb
,a.trip_nb
,a.position_ts
,case
        when b.plcy_ratd_st_cd in ('NY','') THEN
                case
                        when sum(coalesce((a.vssspeed_am/1.609334)/3600,0)) over (partition by a.trip_nb order by a.position_ts asc rows between unbounded preceding and current row)<=1 then NULL
                        when sum(coalesce((a.vssspeed_am/1.609334)/3600,0)) over (partition by a.trip_nb order by a.position_ts asc rows between unbounded preceding and current row)>= (sum(coalesce((a.vssspeed_am/1.609334)/3600,0)) over (partition by a.trip_nb)-1) then NULL
                        else a.latitude_it
                end
        else a.latitude_it
end as latitude_it
,case
        when b.plcy_ratd_st_cd in ('NY','') THEN
                case
                        when sum(coalesce((a.vssspeed_am/1.609334)/3600,0)) over (partition by a.trip_nb order by a.position_ts asc rows between unbounded preceding and current row)<=1 then NULL
                        when sum(coalesce((a.vssspeed_am/1.609334)/3600,0)) over (partition by a.trip_nb order by a.position_ts asc rows between unbounded preceding and current row)>= (sum(coalesce((a.vssspeed_am/1.609334)/3600,0)) over (partition by a.trip_nb)-1) then NULL
                        else a.longitude_it
                end
        else a.longitude_it
end as longitude_it
,a.vssspeed_am
,a.vssacceleration_pc
,a.enginerpm_qt
,a.throttleposition_pc
,a.accelerationlateral_qt
,a.accelerationlongitudinal_qt
,a.accelerationvertical_qt
,a.gpsheading_nb  small
,a.positionquality_nb
,a.odometerreading_qt
,a.eventaveragespeed_qt
,a.eventaverageacceleration_qt
,a.distancetravelled_qt
,a.timeelapsed_qt
,a.gpspointspeed_qt
,a.road_tp
,a.batch
FROM ~>srdp_cncl_db.tsp_trippoint a

JOIN ~>srdp_cncl_db.tsp_tripsummary b
ON a.batch=b.batch
AND a.trip_nb = b.trip_nb

WHERE a.source_cd = '~>source_cd'
AND b.source_cd= '~>source_cd'
AND a.batch IN (~>batch_list)
AND b.batch IN (~>batch_list)
AND 'IMS' = '~>source_cd';

INSERT INTO TABLE  ~>srdp_wk_db.dc_tsp_trippoint
PARTITION (source_cd='~>source_cd', batch)
SELECT  a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.fullpolicy_nb
,a.voucher_nb
,a.trip_nb
,a.position_ts
,a.latitude_it
,a.longitude_it
,a.vssspeed_am
,a.vssacceleration_pc
,a.enginerpm_qt
,a.throttleposition_pc
,a.accelerationlateral_qt
,a.accelerationlongitudinal_qt
,a.accelerationvertical_qt
,a.gpsheading_nb  small
,a.positionquality_nb
,a.odometerreading_qt
,a.eventaveragespeed_qt
,a.eventaverageacceleration_qt
,a.distancetravelled_qt
,a.timeelapsed_qt
,a.gpspointspeed_qt
,a.road_tp
,a.batch
FROM ~>srdp_cncl_db.tsp_trippoint a

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list)
AND 'OCTO' = '~>source_cd';


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_tsp_tripevent from canonical table";

-------------------------------------- Table: dc_tsp_tripevent --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_tsp_tripevent
PARTITION(source_cd='~>source_cd',batch)
SELECT
c.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.contract_nb
,a.voucher_nb
,a.trip_nb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END AS detectedvin_nb
,a.event_ts
,a.eventtimezoneoffset_nb
,CASE when c.plcy_ratd_st_cd in ('NY','@') THEN NULL ELSE a.latitude_it END as latitude_it
,CASE when c.plcy_ratd_st_cd in ('NY','@') THEN NULL ELSE a.longitude_it END as longitude_it
,a.eventtype_cd
,a.eventreferencevalue_ds
,a.eventstart_ts
,a.eventend_ts
,a.eventduration_am
,a.batch
FROM ~>srdp_cncl_db.tsp_tripevent a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc c
ON a.enrolledvin_nb = c.vhcl_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>batch_list)
AND from_unixtime(unix_timestamp(substr(a.batch,0,8) ,'yyyyMMdd'), 'yyyy-MM-dd') >= c.active_start_dt
AND from_unixtime(unix_timestamp(substr(a.batch,0,8) ,'yyyyMMdd'), 'yyyy-MM-dd') < c.active_end_dt;


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_hive_sre_hourly from canonical table";

---------------------------------------- Table: dc_hive_sre_hourly --------------------------------------

INSERT INTO ~>srdp_wk_db.dc_hive_sre_hourly
PARTITION (source_cd='~>source_cd', batch)
SELECT
c.dc_instance_id
,a.trip_nb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END AS detectedvin_nb
,a.plcy_ratd_st_cd
,a.periodstart_ts
,a.periodend_ts
,a.periodstart_hr
,a.periodend_hr
,a.fast_acceleration_ct
,a.hard_brake_ct
,a.miles
,a.kilometers
,a.adjusted_miles
,a.adjusted_km
,a.plausible_miles
,a.plausible_km
,a.nighttime_driving_sec_count
,a.idle_time_sec_count
,a.plausible_idle_time_sec_count
,a.drive_time_sec_count
,a.plausible_drive_time_sec_count
,a.batch

FROM ~>srdp_cncl_db.hive_sre_hourly a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny c
ON a.enrolledvin_nb = c.vhcl_id_nbr AND a.deviceserial_nb = c.dev_id_nbr

WHERE a.source_cd='~>source_cd' and a.batch in (~>batch_list);


SET mapred.job.name = "~>job_cd Load data into dc_annual_mileage from canonical table";

-------------------------------------- Table: dc_annual_mileage --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_annual_mileage
PARTITION (load_date)
SELECT
 b.dc_instance_id
,a.plcy_ratd_st_cd
,a.first_activity_date
,a.last_activity_date
,a.days_installed
,a.install_percentage
,a.uninstall_percentage
,a.plausible_speed_pcnt
,a.tier1_10avg
,a.tier11_30avg
,a.tier31_70avg
,a.tier71_90avg
,a.tier91_100avg
,a.estimatedkilometers
,a.estimatedmileage
,a.load_date

FROM ~>srdp_cncl_db.annual_mileage a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny  b
ON a.enrolledvin_nb = b.vhcl_id_nbr AND a.deviceserial_id = b.dev_id_nbr

WHERE cast(a.load_date as date) > cast('~>last_run_dt' as date)
and cast(a.load_date as date) <= '~>run_date'
and  '~>source_cd' ='IMS';


SET mapred.job.name = "~>job_cd Load data into dc_annual_mileage_score from canonical table";

-------------------------------------- Table: dc_annual_mileage_score --------------------------------------

INSERT INTO ~>srdp_wk_db.dc_annual_mileage_score
PARTITION (score_date)
SELECT
b.dc_instance_id,
a.policy_nb,
a.score_dt,
a.tripstart_dt,
a.tripend_dt,
a.score_days,
a.percenttime_disconnected,
a.score_1,
a.score_2,
a.score_3,
a.score_4,
a.score_5,
a.score_6,
a.score_7,
a.score_8,
a.score_9,
a.score_10,
a.floor_estimatedkilometers,
a.filler,
a.score_date
FROM ~>srdp_cncl_db.annual_mileage_score a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny b

ON a.deviceserial_nb = b.dev_id_nbr
AND a.enrolledvin_nb = b.vhcl_id_nbr

WHERE cast(a.score_date AS date) > cast('~>last_run_dt' AS date)
AND cast(a.score_date AS date) <= '~>run_date'
AND  '~>source_cd' ='IMS';


SET mapred.job.name = "~>job_cd Load data into dc_hive_sre_scoring from canonical table";

-------------------------------------- Table: dc_hive_sre_scoring --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_hive_sre_scoring
PARTITION (score_date)
SELECT
b.dc_instance_id
,a.policy_number
,a.score_start_date
,a.score_end_date
,a.score_days
,a.score_model_1
,a.pure_score_1
,a.rated_score_1
,a.filler_1
,a.score_model_2
,a.pure_score_2
,a.rated_score_2
,a.filler_2
,a.score_model_3
,a.pure_score_3
,a.rated_score_3
,a.filler_3
,a.score_model_4
,a.pure_score_4
,a.rated_score_4
,a.filler_4
,a.score_model_5
,a.pure_score_5
,a.rated_score_5
,a.filler_5
,a.score_model_6
,a.pure_score_6
,a.rated_score_6
,a.filler_6
,a.score_model_7
,a.pure_score_7
,a.rated_score_7
,a.filler_7
,a.score_model_8
,a.pure_score_8
,a.rated_score_8
,a.filler_8
,a.score_model_9
,a.pure_score_9
,a.rated_score_9
,a.filler_9
,a.score_model_10
,a.pure_score_10
,a.rated_score_10
,a.filler_10
,a.percent_time_disconnected
,a.calculated_annual_mileage
,a.number_of_connect_disconect
,a.uninstalled_time
,a.filler
,a.model_id
,a.hard_brake_ct
,a.fast_acceleration_ct
,a.scrub_miles
,a.adjust_miles
,a.no_idle_time
,a.idle_time
,a.install_percentage
,a.plausible_percentage
,a.score_date
FROM ~>srdp_cncl_db.hive_sre_scoring a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny b
ON a.enrolled_vin = b.vhcl_id_nbr AND a.device_serial_number = b.dev_id_nbr

WHERE cast(a.score_date AS date) > cast('~>last_run_dt' AS date)
AND cast(a.score_date AS date) <= '~>run_date'
AND '~>source_cd' ='IMS';


SET mapred.job.name = "~>job_cd Step 1: Load all data into dc_devicestatus from canonical table";

-------------------------------------- Table: dc_devicestatus --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_devicestatus
SELECT
b.dc_instance_id
,a.status
,a.statusstart_ts
,a.statusend_ts
,a.lastactivity_ts
,a.loststatus_flag
FROM ~>srdp_cncl_db.devicestatus a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny  b
ON a.enrolledvin_nb = b.vhcl_id_nbr AND a.deviceserial_id = b.dev_id_nbr

WHERE  '~>source_cd' ='IMS';


SET mapred.job.name = "~>job_cd Step 1: Load all data into dc_device_install_pcnt from canonical table";

-------------------------------------- Table: dc_device_install_pcnt --------------------------------------

-- Insert all rows from canonical to work table---
INSERT INTO ~>srdp_wk_db.dc_device_install_pcnt
SELECT
b.dc_instance_id
,a.loststatus_flag
,a.total_time
,a.total_install_time
,a.install_percentage
,a.total_uninstall_time
,a.uninstall_percentage
,a.first_activity_date
,a.last_activity_date
,a.total_days
,a.days_installed
,a.connection_ct
,a.disconnection_ct

FROM ~>srdp_cncl_db.device_install_pcnt a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny b
ON a.enrolledvin_nb = b.vhcl_id_nbr AND a.deviceserial_id = b.dev_id_nbr

WHERE '~>source_cd' ='IMS';


SET mapred.job.name = "~>job_cd ~>source_cd - Load data into dc_orphan_ts from canonical table";

-------------------------------------- Table: dc_orphan_ts --------------------------------------

INSERT INTO TABLE ~>srdp_wk_db.dc_orphan_ts
PARTITION (source_cd='~>source_cd', batch)
SELECT
b.dc_instance_id
,a.dataload_dt
,a.sourcefilename_ts
,a.loadevent_id
,a.devicetype_cd
,a.fullpolicy_nb
,a.voucher_nb
,CASE WHEN (UPPER(TRIM(a.detectedvin_nb))='NULL' OR TRIM(a.detectedvin_nb) IS NULL OR TRIM(a.detectedvin_nb)='')THEN NULL
ELSE CONCAT(SUBSTR(TRIM(a.detectedvin_nb),0,10),'*******') END AS detectedvin_nb
,a.trip_nb
,a.tripstart_ts
,a.tripend_ts
,a.plcy_ratd_st_cd
,a.tripdistance_qt
,a.averagespeed_qt
,a.maximumspeed_qt
,a.fuelconsumption_qt
,a.milstatus_cd
,a.tripzoneoffset_am
,a.idletime_ts
,a.trippositionalquality_qt
,a.accelerometerquality_qt
,a.distancemotorways_qt
,a.distanceurbanareas_qt
,a.distanceotherroad_qt
,a.distanceunknownroad_qt
,a.timetravelled_qt
,a.timemotorways_qt
,a.timeurbanareas_qt
,a.timeotherroad_qt
,a.timeunknownroad_qt
,a.speedingdistancemotorways_qt
,a.speedingdistanceurbanareas_qt
,a.speedingdistanceotherroad_qt
,a.speedingdistanceunknownroad_qt
,a.speedingtimemotorways_qt
,a.speedingtimeurbanareas_qt
,a.speedingtimeotherroad_qt
,a.speedingtimeunknownroad_qt
,a.batch
FROM  ~>srdp_cncl_db.orphan_ts a

INNER JOIN ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_skny b
ON a.enrolledvin_nb = b.vhcl_id_nbr
AND a.deviceserial_nb = b.dev_id_nbr

WHERE a.source_cd = '~>source_cd'
AND a.batch IN (~>orphan_batch_list);

