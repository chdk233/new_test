
drop table if exists ~>work_db.~>wk_hourly_trip_details;

set mapred.job.name = "~>job_cd Create Table wk_hourly_trip_details from wk_tripdetail_seconds";

CREATE TABLE ~>work_db.~>wk_hourly_trip_details 
 (
      sr_pgm_instnc_id     bigint, 
      trip_nb     string, 
      deviceserial_nb     bigint, 
      enrolledvin_nb     string, 
      detectedvin_nb     string, 
      plcy_ratd_st_cd     string, 
      periodstart_ts     timestamp, 
      periodend_ts     timestamp, 
      periodstart_hr     timestamp, 
      periodend_hr     timestamp, 
      fast_acceleration_ct     bigint, 
      hard_brake_ct     bigint, 
      miles     double, 
      kilometers     double, 
      adjusted_miles     double, 
      adjusted_km     double, 
      plausible_miles     double, 
      plausible_km     double, 
      nighttime_driving_sec_count     bigint, 
      idle_time_sec_count     bigint, 
      plausible_idle_time_sec_count     bigint, 
      drive_time_sec_count     bigint, 
      plausible_drive_time_sec_count     bigint, 
      mph_json     array<double>, 
      fa_json     string, 
      hb_json     string, 
      latlong_json     string, 
      source_cd     string, 
      batch     string, 
      stop_second_cn     bigint)
STORED AS PARQUET
LOCATION
   'hdfs:///user/hive/warehouse/~>work_db/~>wk_hourly_trip_details'; 

INSERT OVERWRITE TABLE ~>work_db.~>wk_hourly_trip_details 
SELECT 
sr_pgm_instnc_id 
,trip_nb
,deviceserial_nb
,enrolledvin_nb
,detectedvin_nb
,plcy_ratd_st_cd
,min(position_offset_ts) as periodstart_ts 
,max(position_offset_ts) as periodend_ts 
,cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp) as periodstart_hr 
,cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'59:59') as timestamp) as periodend_hr
,sum(eventcounter_fa) AS fast_acceleration_ct
,sum(eventcounter_hb) AS hard_brake_ct
,sum(distance) as miles
,sum(distance * 1.609334) as kilometers
,(case from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'E') 
when ('Sun') Then ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT ) 
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END ) 
when ('Sat') Then  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT ) 
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END )
Else  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT ) 
                    WHEN 0 THEN 1.6
                    WHEN 1 THEN 1.6
                    WHEN 2 THEN 1.6
                    WHEN 3 THEN 1.6
                    WHEN 4 THEN 1.6
                    WHEN 5 THEN 1.1
                    WHEN 6 THEN 1.1
                    WHEN 7 THEN 1.1
                    WHEN 8 THEN 1.1
                    WHEN 9 THEN 1.2
                    WHEN 10 THEN 1.2
                    WHEN 11 THEN 1.2
                    WHEN 12 THEN 1.2
                    WHEN 13 THEN 1.2
                    WHEN 14 THEN 1.2
                    WHEN 15 THEN 1.2
                    WHEN 16 THEN 1.4
                    WHEN 17 THEN 1.4
                    WHEN 18 THEN 1.4
                    ELSE 1.3
                    END 
       )
end) * sum((IF(plausible_ind = 1, distance,0))) as adjusted_miles
,(case from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'E') 
when ('Sun') Then ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT ) 
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END ) 
when ('Sat') Then  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT ) 
                    WHEN 0 THEN 2.7
                    WHEN 1 THEN 2.7
                    WHEN 2 THEN 2.7
                    WHEN 3 THEN 2.7
                    WHEN 4 THEN 2.7
                    WHEN 19 THEN 1.1
                    WHEN 20 THEN 1.1
                    WHEN 21 THEN 1.1
                    WHEN 22 THEN 1.1
                    WHEN 23 THEN 1.1
                    ELSE 1.0
                    END )
Else  ( case  cast(from_unixtime(unix_timestamp(cast(concat(SUBSTR(cast(min(position_offset_ts) as varchar(24)),1,14),'00:00') as timestamp)),'H') as INT ) 
                    WHEN 0 THEN 1.6
                    WHEN 1 THEN 1.6
                    WHEN 2 THEN 1.6
                    WHEN 3 THEN 1.6
                    WHEN 4 THEN 1.6
                    WHEN 5 THEN 1.1
                    WHEN 6 THEN 1.1
                    WHEN 7 THEN 1.1
                    WHEN 8 THEN 1.1
                    WHEN 9 THEN 1.2
                    WHEN 10 THEN 1.2
                    WHEN 11 THEN 1.2
                    WHEN 12 THEN 1.2
                    WHEN 13 THEN 1.2
                    WHEN 14 THEN 1.2
                    WHEN 15 THEN 1.2
                    WHEN 16 THEN 1.4
                    WHEN 17 THEN 1.4
                    WHEN 18 THEN 1.4
                    ELSE 1.3
                    END 
       )
end) * sum((IF(plausible_ind = 1, distance,0)) * 1.609334) as adjusted_km
,SUM(IF(plausible_ind = 1,distance,0)) as plausible_miles
,SUM(IF(plausible_ind = 1,(distance * 1.609334),0)) as plausible_km
,sum(nighttime_driving_ind) AS nighttime_driving_sec_count 
,sum(IF((time_driving_ind = 1 and time_idle_ind = 1 ), 1,0 )) as idle_time_sec_count  
,SUM(IF(plausible_ind = 1,IF((time_driving_ind = 1 and time_idle_ind = 1 ), 1,0 ),0)) as plausible_idle_time_sec_count
,sum(time_driving_ind) as drive_time_sec_count 
,SUM(IF(plausible_ind = 1,time_driving_ind,0)) as plausible_drive_time_sec_count
,default.sre_collect_list(speed_mph) as mph_json
,default.sre_index_list_v2(eventcounter_fa, cast(1 as smallint)) as fa_json 
,default.sre_index_list_v2(eventcounter_hb, cast(1 as smallint)) as hb_json
,case when (concat_ws(',',collect_list(coalesce(concat('[',latitude_it,',',longitude_it,']'),'null') ) ) ) like '%[%'
then (concat_ws(',',collect_list(coalesce(concat('[',latitude_it,',',longitude_it,']'),'null') ) ) )
else '' end as latlong_json
,source_cd
,batch
,sum(eventcounter_br) AS stop_second_cn
from (
SELECT
*
from ~>work_db.~>wk_tripdetail_seconds
where garbage_flag = 0 
distribute by trip_nb sort by trip_nb,position_ts
) query
group by trip_nb,sr_pgm_instnc_id,source_cd,date(position_offset_ts),hour(position_offset_ts),batch,
deviceserial_nb,enrolledvin_nb,detectedvin_nb,plcy_ratd_st_cd;

set mapred.job.name = "~>job_cd Insert Overwrite ~>foundation_db.hive_sre_hourly from ~>work_db.wk_hourly_trip_details";

Insert overwrite table ~>foundation_db.smartride_hive_sre_hourly 
partition(source_cd='~>source_cd',batch)
select 
 sr_pgm_instnc_id
,trip_nb
,deviceserial_nb
,enrolledvin_nb
,detectedvin_nb
,plcy_ratd_st_cd
,periodstart_ts
,periodend_ts
,periodstart_hr
,periodend_hr
,fast_acceleration_ct
,hard_brake_ct
,miles
,kilometers
,adjusted_miles
,adjusted_km
,plausible_miles
,plausible_km
,nighttime_driving_sec_count
,idle_time_sec_count
,plausible_idle_time_sec_count
,drive_time_sec_count
,plausible_drive_time_sec_count
,mph_json
,fa_json
,hb_json
,latlong_json
,stop_second_cn
,batch
from 
~>work_db.~>wk_hourly_trip_details;

-- Drop and create trip_details work table

DROP TABLE IF EXISTS ~>work_db.~>wk_trip_details; 

CREATE  TABLE ~>work_db.~>wk_trip_details(
 enrolledvin_nb string
,PERIOD_TYPE STRING
,PERIODSTART_TS TIMESTAMP
,PERIODEND_TS TIMESTAMP
,MILES DOUBLE
,KILOMETERS DOUBLE
,NIGHT_TIME_DRIVING_SEC_CT INT
,FAST_ACCELERATION_CT INT
,HARD_BRAKE_CT INT
,idle_time_sec_ct int
,DRIVE_TIME_sec_CT int
,idle_time_ratio double
,TRIP_SECONDS_JSON STRING
,TRIP_NB STRING
,source_cd string
,batch string)
STORED AS PARQUET
LOCATION
'hdfs:///user/hive/warehouse/~>work_db/~>wk_trip_details';


set mapred.job.name = "~>job_cd Insert Overwrite ~>work_db.wk_trip_details from wk_hourly_trip_details";

from (select * from ~>work_db.~>wk_hourly_trip_details 
distribute by trip_nb sort by trip_nb,periodstart_ts) query
Insert overwrite table ~>work_db.~>wk_trip_details
SELECT CAST(enrolledvin_nb AS string) AS enrolledvin_nb
,CAST('trip' AS VARCHAR(20)) AS PERIOD_TYPE
,CAST ( MIN(periodstart_ts) AS TIMESTAMP)AS PERIODSTART_TS
,CAST(MAX(periodend_ts) AS TIMESTAMP)AS PERIODEND_TS
,CAST(SUM(miles) AS DOUBLE) AS MILES
,CAST(SUM(kilometers) AS DOUBLE) AS KILOMETERS
,CAST(ROUND(SUM(nighttime_driving_sec_count)) AS INT) AS NIGHT_TIME_DRIVING_SEC_CT
,CAST(SUM(FAST_ACCELERATION_CT) AS INT) AS FAST_ACCELERATION_CT
,CAST(SUM(hard_brake_ct) AS INT) AS HARD_BRAKE_CT
,CAST(SUM(idle_time_sec_count) AS INT) AS IDLE_TIME_SEC_CT
,CAST(SUM(drive_time_sec_count) AS INT) AS DRIVE_TIME_sec_CT
,IF(SUM(drive_time_sec_count) = 0,0,SUM(idle_time_sec_count)/SUM(drive_time_sec_count)) as IDLE_TIME_RATIO
,CONCAT('{"start":', unix_timestamp(min(periodstart_ts)) + (case
when min(periodstart_ts) between date_format( cast(extract(year from min(periodstart_ts)) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(min(periodstart_ts) as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(min(periodstart_ts) as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from min(periodstart_ts)) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(min(periodstart_ts) as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(min(periodstart_ts) as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600,
', "end":', unix_timestamp(max(periodend_ts)) + (case
when max(periodend_ts) between date_format( cast(extract(year from max(periodend_ts)) as string) || '-03-' || 
                cast(
                                8 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(max(periodend_ts) as timestamp) ) as string) || '-03-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(max(periodend_ts) as timestamp) ) as string) || '-03-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) and date_format( cast(extract(year from max(periodend_ts)) as string) || '-11-' || 
                cast(
                                1 + case 
                                                 when extract(dayofweek from to_date(cast(extract(year from cast(max(periodend_ts) as timestamp) ) as string) || '-11-01')) = 1 then 0 
                                                 else 8 - extract(dayofweek from to_date(cast(extract(year from cast(max(periodend_ts) as timestamp) ) as string) || '-11-01')) 
                                                 end 
                                 as string
                                ) || ' 02:00:00' ,  'YYYY-MM-dd HH:mm:ss'
                ) then 4
else 5
end)*3600,
', "mph":', default.sre_concat_miles(mph_json,periodstart_ts),
', "latlong":[',concat_ws(',',collect_list(latlong_json)), ']',
', "acceleration":', default.sre_concat_factor(fa_json, periodstart_ts), 
', "braking":', default.sre_concat_factor(hb_json, periodstart_ts), 
', "scale":1}') as  TRIP_SECONDS_JSON
,TRIP_NB
,'~>source_cd' as source_cd
,BATCH
GROUP BY enrolledvin_nb, TRIP_NB, SOURCE_CD, BATCH;

set mapred.job.name = "~>job_cd Insert Overwrite foundation_db.trip_details from smartride_work_hive_db.wk_trip_details";

from ~>work_db.~>wk_trip_details 
Insert overwrite table ~>foundation_db.smartride_trip_details partition(source_cd='~>source_cd',batch)
 SELECT enrolledvin_nb
,PERIOD_TYPE
,PERIODSTART_TS
,PERIODEND_TS
,MILES
,KILOMETERS
,NIGHT_TIME_DRIVING_SEC_CT
,FAST_ACCELERATION_CT
,HARD_BRAKE_CT
,IDLE_TIME_sec_CT
,DRIVE_TIME_sec_CT
,IDLE_TIME_RATIO
,TRIP_SECONDS_JSON
,TRIP_NB
,BATCH;