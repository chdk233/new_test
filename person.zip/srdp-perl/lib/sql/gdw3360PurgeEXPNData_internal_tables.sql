set hive.enforce.bucketing = true;
set hive.enforce.sorting = true;
set hive.optimize.bucketmapjoin = true;
set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_canonical_hive_db.Vehicle from experian_work_hive_db.wk_purge_Vehicle, experian_canonical_hive_db.BindPolicy ";

INSERT OVERWRITE TABLE  ~>expn_cncl_db.Vehicle
PARTITION (sourcefile_dt)
SELECT
v.Vin10_Nb
,v.State_Cd
,v.Make_Ds
,v.Model_Ds
,v.ManufactureYear_Nb
,v.ProgramStart_Ts
,v.ProgramStartOffsetTime_Am
,v.ProgramEnd_Ts
,v.ProgramStartOffsetTime_Am
,v.loadevent_id
,v.PartnerNotification_Id
,v.sourcefile_dt
FROM ~>expn_wk_db.wk_purge_Vehicle v

LEFT OUTER JOIN ~>expn_cncl_db.BindPolicy bp
ON v.partnernotification_id = bp.partnernotification_id

WHERE bp.partnernotification_id IS NOT NULL;

set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_canonical_hive_db.TripSummary from experian_work_hive_db.wk_purge_TripSummary, experian_canonical_hive_db.BindPolicy";

INSERT OVERWRITE TABLE  ~>expn_cncl_db.TripSummary
PARTITION (sourcefile_dt)
SELECT
 ts.TripStart_Ts
,ts.TripStartOffsetTime_Am
,ts.TripEnd_Ts
,ts.TripEndtOffsetTime_Am
,ts.OdometerReadingStart_Qt
,ts.OdometerReadingEnd_Qt
,ts.IdleTime_Am
,ts.loadevent_id
,ts.PartnerNotification_Id
,ts.sourcefile_dt
FROM  ~>expn_wk_db.wk_purge_TripSummary ts

LEFT OUTER JOIN ~>expn_cncl_db.BindPolicy bp
ON ts.partnernotification_id = bp.partnernotification_id

WHERE bp.partnernotification_id IS NOT NULL;

set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_canonical_hive_db.TripEvent from experian_work_hive_db.wk_purge_TripEvent, experian_canonical_hive_db.BindPolicy ";

INSERT OVERWRITE TABLE  ~>expn_cncl_db.TripEvent
PARTITION (sourcefile_dt)
SELECT
 te.Event_Ts
,te.EventOffsetTime_Am
,te.VehicleSpeed_Am
,te.HardBrakesAcceleration_Am
,te.loadevent_id
,te.PartnerNotification_Id
,te.sourcefile_dt
FROM ~>expn_wk_db.wk_purge_TripEvent te

LEFT OUTER JOIN ~>expn_cncl_db.BindPolicy bp
ON te.partnernotification_id = bp.partnernotification_id

WHERE bp.partnernotification_id IS NOT NULL;


set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_reporting_hive_db.VehiclePartition from experian_work_hive_db.wk_purge_VehiclePartition, experian_canonical_hive_db.BindPolicy";

INSERT OVERWRITE TABLE  ~>expn_rpt_db.VehiclePartition
PARTITION (sourcefile_dt)
SELECT
 vp.partnernotification_id
,vp.vin10_nb
,vp.state_cd
,vp.make_ds
,vp.model_ds
,vp.manufactureyear_nb
,vp.programstart_ts
,vp.programstartoffsettime_am
,vp.programend_ts
,vp.programendoffsettime_am
,vp.totaltraveltime_am
,vp.totaltraveldistance_qt
,vp.totalidletime_am
,vp.totalidletime_pc
,vp.tripstart_ts
,vp.tripstartoffsettime_am
,vp.tripend_ts
,vp.tripendtoffsettime_am
,vp.odometerreadingstart_qt
,vp.odometerreadingend_qt
,vp.idletime_am
,vp.hardbrakes_ct
,vp.fastacceleration_ct
,vp.satsunpartition1time_am
,vp.satsunpartition2time_am
,vp.satsunpartition3time_am
,vp.monfripartition4time_am
,vp.monfripartition5time_am
,vp.monfripartition6time_am
,vp.monfripartition7time_am
,vp.monfripartition8time_am
,vp.satsunpartition1_pc
,vp.satsunpartition2_pc
,vp.satsunpartition3_pc
,vp.monfripartition4_pc
,vp.monfripartition5_pc
,vp.monfripartition6_pc
,vp.monfripartition7_pc
,vp.monfripartition8_pc
,vp.satsunpartition1adjdistance_qt
,vp.satsunpartition2adjdistance_qt
,vp.satsunpartition3adjdistance_qt
,vp.satsunpartition4adjdistance_qt
,vp.satsunpartition5adjdistance_qt
,vp.satsunpartition6adjdistance_qt
,vp.satsunpartition7adjdistance_qt
,vp.satsunpartition8adjdistance_qt
,vp.loadevent_id
,vp.sourcefile_dt
FROM ~>expn_wk_db.wk_purge_VehiclePartition vp

LEFT OUTER JOIN ~>expn_cncl_db.BindPolicy bp
ON vp.partnernotification_id = bp.partnernotification_id

WHERE bp.partnernotification_id IS NOT NULL;

set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_reporting_hive_db.TelematicsScore from experian_work_hive_db.wk_purge_TelematicsScore, experian_canonical_hive_db.BindPolicy";

INSERT OVERWRITE TABLE  ~>expn_rpt_db.TelematicsScore
PARTITION (sourcefile_dt)
select
 case when bp.partnernotification_id is null then ' ' else t.partnernotification_id end as partnernotification_id
,case when bp.partnernotification_id is null then ' ' else t.vin10_nb end as vin10_nb
,t.state_cd
,t.make_ds
,t.model_ds
,t.manufactureyear_nb
,t.installedday_ct
,t.totalhardbrakes_ct
,t.dailyhardbrakes_ct
,t.totalfastacceleration_ct
,t.dailyfastacceleration_ct
,t.totalidletime_am
,t.totaltraveltime_am
,t.idletime_pc
,t.totaltraveldistance_qt
,t.adjusteddistance_qt
,t.averagedailydistance_qt
,t.mileage_fr
,t.telematicsscore1_qt
,t.telematicsscore2_qt
,t.telematicsscore3_qt
,t.telematicsscore4_qt
,t.telematicsscore5_qt
,t.telematicsscore6_qt
,t.telematicsscore7_qt
,t.telematicsscore8_qt
,t.qualify_cd
,t.loadevent_id
,t.sourcefile_dt
from ~>expn_wk_db.wk_purge_TelematicsScore t

left outer join ~>expn_cncl_db.BindPolicy bp
on t.partnernotification_id = bp.partnernotification_id;