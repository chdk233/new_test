--------------------------------------------- Production  - mask/anonymize ods table---------------------------------------------

DROP TABLE IF EXISTS ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_bkp;

ALTER TABLE ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc RENAME TO ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_bkp;

CREATE TABLE ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc(                           
  dc_instance_id bigint,                                                                   
  sr_pgm_instnc_id bigint,                                                                 
  vhcl_id_nbr string,                                                                      
  sr_enrlmnt_dt timestamp,                                                                 
  dev_id_nbr bigint,                                                                       
  plcy_ratd_st_cd string,                                                                  
  active_end_dt timestamp,                                                                 
  active_start_dt timestamp,
  pid_md5 string,
  vindev_md5 string
  )                                                               
CLUSTERED BY (                                                                               
  sr_pgm_instnc_id,                                                                          
  vhcl_id_nbr,                                                                               
  dev_id_nbr)                                                                                
SORTED BY (                                                                                  
  sr_pgm_instnc_id ASC,                                                                      
  vhcl_id_nbr ASC,                                                                           
  dev_id_nbr ASC)                                                                            
INTO 256 BUCKETS                                                                             
ROW FORMAT DELIMITED                                                                         
  FIELDS TERMINATED BY ','                                                                   
STORED AS ORC;


set mapred.job.name = "~>job_cd Mask ods table";
INSERT INTO ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc
SELECT
dc_instance_id
,CASE WHEN TRIM(plcy_ratd_st_cd)='NY' AND sr_enrlmnt_dt<= date_add(CURRENT_DATE,-730) 
     THEN 0  
     ELSE sr_pgm_instnc_id
 END AS sr_pgm_instnc_id
,CASE WHEN TRIM(plcy_ratd_st_cd)='NY' AND sr_enrlmnt_dt<= date_add(CURRENT_DATE,-730) 
     THEN CONCAT(SUBSTR(TRIM(vhcl_id_nbr),0,10),'*******')  
	 WHEN sr_pgm_instnc_id = 0 AND sr_enrlmnt_dt = '1000-01-01 00:00:00' -- orphans 
	 THEN CONCAT(SUBSTR(TRIM(vhcl_id_nbr),0,10),'*******') 
     ELSE vhcl_id_nbr
 END AS vhcl_id_nbr
,sr_enrlmnt_dt
,CASE WHEN TRIM(plcy_ratd_st_cd)='NY' AND sr_enrlmnt_dt<= date_add(CURRENT_DATE,-730) 
     THEN 0  
	 WHEN sr_pgm_instnc_id = 0 AND sr_enrlmnt_dt = '1000-01-01 00:00:00' -- orphans 
	 THEN 0
     ELSE dev_id_nbr
 END AS dev_id_nbr
,plcy_ratd_st_cd 
,active_end_dt
,active_start_dt 
,pid_md5
,vindev_md5

FROM ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_bkp;

DROP TABLE ~>srdp_wk_db.dc_smt_ods_bigin_pgm_instnc_bkp;

