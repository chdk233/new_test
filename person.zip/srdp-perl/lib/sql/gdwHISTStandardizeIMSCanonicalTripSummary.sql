use ~>smartride_raw_hive_db;

alter table IMS_TripSummary_Ext_H add IF NOT EXISTS partition (batch='~>batch_id');

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_IMS_TSP_TripSummary_Temp_H;

CREATE TABLE ~>smartride_work_hive_db.WK_IMS_TSP_TripSummary_Temp_H(
 DataLoad_Dt  TIMESTAMP COMMENT 'Load date',
 SourceFileName_Ts TIMESTAMP COMMENT 'Source file datestamp',
 LoadEvent_ID BIGINT COMMENT 'Unique  Identifier to indicate the load',
 Trip_Nb STRING COMMENT 'Trip number',
 DeviceSerial_Nb BIGINT COMMENT 'Device serial number of the device',
 EnrolledVIN_Nb STRING COMMENT 'Enrolled Vehicle Indentification number',
 DetectedVIN_Nb STRING COMMENT 'Detected Vehicle Indentification number',
 TripStart_Ts TIMESTAMP COMMENT 'Start time of the trip',
 TripEnd_Ts  TIMESTAMP COMMENT 'End time of the trip',
 TripZoneOffset_AM STRING COMMENT 'Timezone offset',
 TripDistance_Qt DOUBLE,
 AverageSpeed_Qt DOUBLE,
 MaximumSpeed_Qt DOUBLE,
 FuelConsumption_Qt DOUBLE,
 MILStatus_Cd STRING,
 IdleTime_Ts INT,
 TripPositionalQuality_Qt DOUBLE,
 AccelerometerQuality_Qt DOUBLE
 )
 COMMENT 'TripSummary table structure for holding IMS raw files'
 partitioned by (source_cd string,batch string)
 ROW FORMAT DELIMITED FIELDS TERMINATED BY '\054' STORED AS TEXTFILE
 ;

use smartride_work_hive_db;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.dynamic.partitions.pernode=100000;
set hive.exec.parallel=false;
set hive.auto.convert.join=false;

set mapred.job.name = "~>job_cd Insert Overwrite smartride_work_hive_db.WK_IMS_TSP_TripSummary_Temp_H from smartride_raw_hive_db.IMS_TripSummary_Ext_H";

INSERT overwrite TABLE ~>smartride_work_hive_db.WK_IMS_TSP_TripSummary_Temp_H
PARTITION (source_cd, batch)
select
cast(cast(DataLoad_Dt as date)as timestamp) as DataLoad_Dt,
cast(cast(DataLoad_Dt as date)as timestamp) as SourceFileName_Ts,
~>load_event_id as loadevent,
trip_nb,
deviceserial_nb,
enrolledvin_nb,
detectedvin_nb,
tripstart_ts,
tripend_ts,
( case when instr(tripzoneoffset_am,':') > 0
then
case when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) > 0
then concat(' ',Substr('00' , 1 ,2-length(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)))),Trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) < 0 
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
case when instr(tripzoneoffset_am,'-') > 1
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
concat(' 00',substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
end
end
else concat(Substr('     ',1,5-length(tripzoneoffset_am)),trim(tripzoneoffset_am))
end )as tripzoneoffset_am,
tripdistance_qt,
averagespeed_qt,
maximumspeed_qt,
fuelconsumption_qt,
milstatus_cd,                 
idletime_ts,
trippositionalquality_qt,
accelerometerquality_qt,
'IMS' as source_cd,
batch
from ~>smartride_raw_hive_db.IMS_TripSummary_Ext_H WHERE
batch='~>batch_id';;

use smartride_canonical_hive_db;

 
DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_IMS_TSP_PID_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_IMS_TSP_PID_H from WK_IMS_TSP_TripSummary_Temp_H & WK_SMT_ODS_LKP";

CREATE TABLE ~>smartride_work_hive_db.WK_IMS_TSP_PID_H
AS 
select  
temp.DataLoad_Dt,
temp.SourceFileName_Ts,
temp.LoadEvent_Id,  
'' AS DeviceType_Cd,
'' AS FullPolicy_Nb,
'' AS Voucher_Nb,
'' AS sr_pgm_instnc_id,
temp.DeviceSerial_Nb,
temp.EnrolledVIN_Nb,
temp.Trip_Nb,
'' AS DetectedVIN_Nb,
temp.TripStart_Ts,
temp.TripEnd_Ts,
'' AS plcy_ratd_st_cd,
temp.TripDistance_Qt,
temp.AverageSpeed_Qt,
temp.MaximumSpeed_Qt,
temp.FuelConsumption_Qt,
temp.MILStatus_Cd,
temp.TripZoneOffset_AM,
temp.IdleTime_Ts,
temp.TripPositionalQuality_Qt,
temp.AccelerometerQuality_Qt,
'' AS DistanceMotorways_Qt,
'' AS DistanceUrbanAreas_Qt,
'' AS DistanceOtherRoad_Qt,
'' AS DistanceUnknownRoad_Qt,
'' AS TimeTravelled_Qt,
'' AS TimeMotorways_Qt,
'' AS TimeUrbanAreas_Qt,
'' AS TimeOtherRoad_Qt,
'' AS TimeUnknownRoad_Qt,
'' AS SpeedingDistanceMotorways_Qt,
'' AS SpeedingDistanceUrbanAreas_Qt,
'' AS SpeedingDistanceOtherRoad_Qt,
'' AS SpeedingDistanceUnknownRoad_Qt,
'' AS SpeedingTimeMotorways_Qt,
'' AS SpeedingTimeUrbanAreas_Qt,
'' AS SpeedingTimeOtherRoad_Qt,
'' AS SpeedingTimeUnknownRoad_Qt,
temp.batch,
lkp.dev_id_nbr,
lkp.vhcl_id_nbr
from ~>smartride_work_hive_db.WK_IMS_TSP_TripSummary_Temp_H temp
LEFT OUTER JOIN
~>smartride_work_hive_db.WK_SMT_ODS_LKP as lkp
on temp.DeviceSerial_Nb = lkp.dev_id_nbr 
and temp.EnrolledVIN_Nb = lkp.vhcl_id_nbr
;

-- Orphan records are loaded into WK_IMS_ORPHAN_PID_H work table

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_IMS_ORPHAN_TS_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_IMS_ORPHAN_TS_H from smartride_work_hive_db.WK_IMS_TSP_PID_H. Orphan records are loaded into WK_IMS_ORPHAN_PID_H work table";

CREATE TABLE ~>smartride_work_hive_db.WK_IMS_ORPHAN_TS_H
AS
SELECT 
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
'IMS' as source_cd,
batch
from ~>smartride_work_hive_db.WK_IMS_TSP_PID_H
WHERE dev_id_nbr IS NULL and vhcl_id_nbr IS NULL;

-- Work table WK_IMS_TSP_TripSummary will only consist of Non-Orphan records.

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_ims_non_orphans_non_bonus_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_ims_non_orphans_non_bonus_H from WK_IMS_TSP_PID_H & SMT_ODS_BIGIN_PGM_INSTNC. Work table WK_IMS_TSP_TripSummary will only consist of Non-Orphan records. ";

CREATE TABLE ~>smartride_work_hive_db.WK_ims_non_orphans_non_bonus_H
AS
SELECT 
tsp.DataLoad_Dt,
tsp.SourceFileName_Ts,
tsp.LoadEvent_Id,  
tsp.DeviceType_Cd,
tsp.FullPolicy_Nb,
tsp.Voucher_Nb,
lkp.sr_pgm_instnc_id as sr_pgm_instnc_id, 
tsp.DeviceSerial_Nb,
tsp.EnrolledVIN_Nb,
tsp.Trip_Nb,
tsp.DetectedVIN_Nb,
tsp.TripStart_Ts,
tsp.TripEnd_Ts,
lkp.plcy_ratd_st_cd,
tsp.TripDistance_Qt,
tsp.AverageSpeed_Qt,
tsp.MaximumSpeed_Qt,
tsp.FuelConsumption_Qt,
tsp.MILStatus_Cd,
tsp.TripZoneOffset_AM,
tsp.IdleTime_Ts,
tsp.TripPositionalQuality_Qt,
tsp.AccelerometerQuality_Qt,
tsp.DistanceMotorways_Qt,
tsp.DistanceUrbanAreas_Qt,
tsp.DistanceOtherRoad_Qt,
tsp.DistanceUnknownRoad_Qt,
tsp.TimeTravelled_Qt,
tsp.TimeMotorways_Qt,
tsp.TimeUrbanAreas_Qt,
tsp.TimeOtherRoad_Qt,
tsp.TimeUnknownRoad_Qt,
tsp.SpeedingDistanceMotorways_Qt,
tsp.SpeedingDistanceUrbanAreas_Qt,
tsp.SpeedingDistanceOtherRoad_Qt,
tsp.SpeedingDistanceUnknownRoad_Qt,
tsp.SpeedingTimeMotorways_Qt,
tsp.SpeedingTimeUrbanAreas_Qt,
tsp.SpeedingTimeOtherRoad_Qt,
tsp.SpeedingTimeUnknownRoad_Qt,
'IMS' as source_cd,
batch
from ~>smartride_work_hive_db.WK_IMS_TSP_PID_H tsp
LEFT OUTER JOIN
~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC as lkp
ON tsp.DeviceSerial_Nb = lkp.dev_id_nbr and 
tsp.EnrolledVIN_Nb = lkp.vhcl_id_nbr
WHERE tsp.dev_id_nbr IS NOT NULL and 
tsp.vhcl_id_nbr IS NOT NULL
AND tsp.tripstart_ts between lkp.sr_enrlmnt_dt and lkp.active_end_dt
;

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_IMS_TSP_TripSummary;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_IMS_TSP_TripSummary from WK_IMS_TSP_PID_H & WK_ims_non_orphans_non_bonus_H";

CREATE TABLE ~>smartride_work_hive_db.WK_IMS_TSP_TripSummary
AS
SELECT 
tsp.DataLoad_Dt,
tsp.SourceFileName_Ts,
tsp.LoadEvent_Id,  
tsp.DeviceType_Cd,
tsp.FullPolicy_Nb,
tsp.Voucher_Nb,
-1 as sr_pgm_instnc_id, 
tsp.DeviceSerial_Nb,
tsp.EnrolledVIN_Nb,
tsp.Trip_Nb,
tsp.DetectedVIN_Nb,
tsp.TripStart_Ts,
tsp.TripEnd_Ts,
tsp.plcy_ratd_st_cd,
tsp.TripDistance_Qt,
tsp.AverageSpeed_Qt,
tsp.MaximumSpeed_Qt,
tsp.FuelConsumption_Qt,
tsp.MILStatus_Cd,
tsp.TripZoneOffset_AM,
tsp.IdleTime_Ts,
tsp.TripPositionalQuality_Qt,
tsp.AccelerometerQuality_Qt,
tsp.DistanceMotorways_Qt,
tsp.DistanceUrbanAreas_Qt,
tsp.DistanceOtherRoad_Qt,
tsp.DistanceUnknownRoad_Qt,
tsp.TimeTravelled_Qt,
tsp.TimeMotorways_Qt,
tsp.TimeUrbanAreas_Qt,
tsp.TimeOtherRoad_Qt,
tsp.TimeUnknownRoad_Qt,
tsp.SpeedingDistanceMotorways_Qt,
tsp.SpeedingDistanceUrbanAreas_Qt,
tsp.SpeedingDistanceOtherRoad_Qt,
tsp.SpeedingDistanceUnknownRoad_Qt,
tsp.SpeedingTimeMotorways_Qt,
tsp.SpeedingTimeUrbanAreas_Qt,
tsp.SpeedingTimeOtherRoad_Qt,
tsp.SpeedingTimeUnknownRoad_Qt,
'IMS' as source_cd,
tsp.batch
from ~>smartride_work_hive_db.WK_IMS_TSP_PID_H tsp
left outer join 
~>smartride_work_hive_db.WK_ims_non_orphans_non_bonus_H nonb
ON tsp.Trip_Nb = nonb.Trip_Nb
WHERE tsp.dev_id_nbr IS NOT NULL and 
tsp.vhcl_id_nbr IS NOT NULL and
nonb.Trip_Nb is null;

-- Load data into TSP_TripSummary table from WK_IMS_TSP_TripSummary_H table

set mapred.job.name = "~>job_cd Insert Overwrite smartride_work_hive_db.WK_IMS_TSP_TripSummary from WK_ims_non_orphans_non_bonus_H";

INSERT INTO TABLE ~>smartride_work_hive_db.WK_IMS_TSP_TripSummary
select
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
source_cd,
batch
from  
~>smartride_work_hive_db.WK_ims_non_orphans_non_bonus_H;

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.TSP_TripSummary from smartride_work_hive_db.WK_IMS_TSP_TripSummary";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.TSP_TripSummary
PARTITION (source_cd,batch)
select
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
source_cd,
batch
from  
~>smartride_work_hive_db.WK_IMS_TSP_TripSummary;

-- Orphan records in Orphan_pid table is recycled and reloaded for every batch to check if records still remain Orphans.

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.ORPHAN_TS from smartride_work_hive_db.wk_ims_orphan_ts_H.Orphan records in Orphan_pid table is recycled and reloaded for every batch to check if records still remain Orphans.";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.ORPHAN_TS
PARTITION (source_cd, batch)
SELECT 
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
'IMS' as source_cd,
batch
from ~>smartride_work_hive_db.wk_ims_orphan_ts_H;






