-- Add current batch partition to external table(OCTO_TripEvent_Ext_h) if not exists 

use ~>smartride_raw_hive_db;

Alter table OCTO_TripEvent_Ext_h add IF NOT EXISTS partition (batch='~>batch_id');

-- Drop and recreate work table WK_OCTO_TSP_TripEvent_h from external table OCTO_TripEvent_Ext

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_OCTO_TSP_TripEvent_h;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_OCTO_TSP_TripEvent_h from smartride_raw_hive_db.OCTO_TripEvent_Ext_h";

CREATE TABLE ~>smartride_work_hive_db.WK_OCTO_TSP_TripEvent_h 
as
select  
cast(cast(dataload_dt as date) as timestamp)as DataLoad_Dt,
cast(cast(dataload_dt as date) as timestamp) AS sourcefilename_ts,
~>load_event_id as loadevent_id, 
DeviceType_Cd,
Contract_Nb,
Voucher_Nb,
Trip_Nb,
EnrolledVIN_Nb,
'' as detectedvin_nb,
Event_Ts,    
 EventTimeZoneOffSet_Nb,
 Latitude_It,
 Longitude_It,  
 EventType_Cd,
 EventReferenceValue_Ds,
 EventStart_Ts,
 EventEnd_Ts,
 EventDuration,
'OCTO' as Source_cd,
batch
from  ~>smartride_raw_hive_db.OCTO_TripEvent_Ext_h WHERE
batch='~>batch_id';




use ~>smartride_canonical_hive_db;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set  hive.exec.max.dynamic.partitions=100000;
set  hive.exec.max.dynamic.partitions.pernode=100000;
set  hive.exec.parallel=false;


-- Load data into TSP_TripEvent  table from WK_OCTO_TSP_TripEvent_h table

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.TSP_Tripevent from smartride_work_hive_db.WK_OCTO_TSP_TripEvent_h";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.TSP_Tripevent
PARTITION (source_cd , batch)
Select 
DataLoad_Dt,
sourcefilename_ts,
loadevent_id, 
DeviceType_Cd,
Contract_Nb,
Voucher_Nb,
Trip_Nb,
EnrolledVIN_Nb,
'' as detectedvin_nb,
Event_Ts,    
 EventTimeZoneOffSet_Nb,
 Latitude_It,
 Longitude_It,  
 EventType_Cd,
 EventReferenceValue_Ds,
 EventStart_Ts,
 EventEnd_Ts,
 EventDuration,
source_cd,
batch
from ~>smartride_work_hive_db.WK_OCTO_TSP_TripEvent_h;



