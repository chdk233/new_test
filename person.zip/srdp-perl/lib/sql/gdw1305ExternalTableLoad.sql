alter table ~>SmartPhoneExternalTable add if not exists partition (SourceFile_Dt='~>SourceFileDate');
