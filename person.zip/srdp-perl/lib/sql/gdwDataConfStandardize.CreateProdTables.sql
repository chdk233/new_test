-------------------------------------------------------------
-- Project: Data Confidential                              --
-- Created On: 11/06/2017                                  --
-- Created By: Big Heroes Team                             --
-- Description: This script drops and recreates the Prod   --
--              work tables.                               --
-------------------------------------------------------------

-------------------------------------- Table: dc_audit_bal_tripcumu_tripsumm --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_audit_bal_tripcumu_tripsumm;

CREATE TABLE  ~>srdp_wk_db.dc_audit_bal_tripcumu_tripsumm
(  dc_instance_id  bigint,
   loadevent_id  bigint,
   tripsummary_trip_ct  bigint,
   cumulative_trip_ct  double)
PARTITIONED BY (
   source_cd  string,
   batch  string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_tsp_tripsummary --------------------------------------

DROP TABLE IF EXISTS ~>srdp_wk_db.dc_tsp_tripsummary;

CREATE TABLE ~>srdp_wk_db.dc_tsp_tripsummary(
dc_instance_id bigint,
dataload_dt timestamp COMMENT 'Load date',
sourcefilename_ts timestamp COMMENT 'Source file datestamp',
loadevent_id bigint COMMENT 'Unique Identifier to indicate the load',
devicetype_cd bigint COMMENT 'To Indicate data record from Octo vendor',
fullpolicy_nb string COMMENT 'Full Policy Number',
voucher_nb bigint,
trip_nb string COMMENT 'Trip number',
detectedvin_nb STRING,
tripstart_ts timestamp COMMENT 'Start time of the trip',
tripend_ts timestamp COMMENT 'End time of the trip',
plcy_ratd_st_cd string,
tripdistance_qt double,
averagespeed_qt double,
maximumspeed_qt double,
fuelconsumption_qt double,
milstatus_cd string,
tripzoneoffset_am string,
idletime_ts int,
trippositionalquality_qt double,
accelerometerquality_qt double,
distancemotorways_qt double,
distanceurbanareas_qt double,
distanceotherroad_qt double,
distanceunknownroad_qt double,
timetravelled_qt double,
timemotorways_qt double,
timeurbanareas_qt double,
timeotherroad_qt double,
timeunknownroad_qt double,
speedingdistancemotorways_qt double,
speedingdistanceurbanareas_qt double,
speedingdistanceotherroad_qt double,
speedingdistanceunknownroad_qt double,
speedingtimemotorways_qt double,
speedingtimeurbanareas_qt double,
speedingtimeotherroad_qt double,
speedingtimeunknownroad_qt double)
PARTITIONED BY (source_cd string,batch string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_centroid_summary --------------------------------------

DROP TABLE IF EXISTS ~>srdp_wk_db.dc_centroid_summary;

CREATE TABLE ~>srdp_wk_db.dc_centroid_summary
(  dc_instance_id bigint,
   trip_nb  string,
   centroid_rpm_start  int,
   centroid_start_time  timestamp,
   centroid_end_time  timestamp,
   min_scrubbed_speed  double,
   max_scrubbed_speed  double,
   min_delta_scrubbed_speed  double,
   max_delta_scrubbed_speed  double,
   scrubbed_speed_decreasing_count  int,
   scrubbed_speed_increasing_count  int,
   scrubbed_speed_steady_count  int,
   absolute_speed_change  double,
   end_scrubbed_speed_bump  int,
   plausible_indicator  int,
   plausibility_reason  string,
   centroid_number  int)
PARTITIONED BY (
   source_cd  string,
   batch  string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_tripdetail_seconds --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_tripdetail_seconds;

CREATE TABLE ~>srdp_wk_db.dc_tripdetail_seconds(
  dc_instance_id bigint,
  dataload_dt timestamp COMMENT 'Load date',
  trip_nb string COMMENT 'Trip number',
  position_ts timestamp,
  position_offset_ts timestamp,
  speed_mph double,
  speed_kph double,
  distance double,
  distance_kph double,
  nighttime_driving_ind smallint,
  eventcounter_fa smallint,
  eventcounter_hb smallint,
  detectedvin_nb STRING,
  tripzoneoffset_am string,
  plcy_ratd_st_cd string,
  enginerpm_qt int,
  time_driving_ind smallint,
  time_idle_ind smallint,
  plausible_ind smallint,
  centroid_nb int,
  scrubbed_fields string,
  loadevent_id bigint,
  latitude_it	double,
  longitude_it double
)
PARTITIONED BY (
  source_cd string,
  batch string)
STORED AS ORC;

-------------------------------------- Table: dc_trip_details --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_trip_details;

CREATE TABLE ~>srdp_wk_db.dc_trip_details
(  dc_instance_id bigint,
   period_type  string,
   periodstart_ts  timestamp,
   periodend_ts  timestamp,
   miles  double,
   kilometers  double,
   night_time_driving_sec_ct  int,
   fast_acceleration_ct  int,
   hard_brake_ct  int,
   idle_time_sec_ct  int,
   drive_time_sec_ct  int,
   idle_time_ratio  double,
   trip_nb  string)
PARTITIONED BY (
   source_cd  string,
   batch  string)
CLUSTERED BY (
  dc_instance_id)
INTO 128 BUCKETS
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\;'
STORED AS ORC;

-------------------------------------- Table: dc_tsp_tripcumulative --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_tsp_tripcumulative;

CREATE TABLE ~>srdp_wk_db.dc_tsp_tripcumulative(
dc_instance_id bigint,
dataload_dt timestamp COMMENT 'Load date',
sourcefilename_ts timestamp COMMENT 'Source file datestamp',
loadevent_id bigint COMMENT 'Unique  Identifier to indicate the load',
devicetype_cd bigint COMMENT 'To Indicate data record from Octo vendor',
voucher_nb bigint COMMENT 'IP Address of the User',
detectedvin_nb STRING,
cumulativetrips_qt double,
cumulativedistance_qt double,
cumulativeengineon_qt double,
firsttripstart_ts timestamp,
lasttripend_ts timestamp,
lastprocessing_ts timestamp)
PARTITIONED BY (source_cd string,batch string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_garbage_tripdetail_seconds --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_garbage_tripdetail_seconds;

CREATE TABLE ~>srdp_wk_db.dc_garbage_tripdetail_seconds(
  dc_instance_id bigint,
  dataload_dt timestamp COMMENT 'Load date',
  trip_nb string COMMENT 'Trip number',
  position_ts timestamp,
  position_offset_ts timestamp,
  speed_mph double,
  speed_kph double,
  distance double,
  distance_kph double,
  nighttime_driving_ind smallint,
  eventcounter_fa smallint,
  eventcounter_hb smallint,
  detectedvin_nb STRING,
  tripzoneoffset_am string,
  plcy_ratd_st_cd string,
  enginerpm_qt int,
  time_driving_ind smallint,
  time_idle_ind smallint,
  plausible_ind smallint,
  centroid_nb int,
  scrubbed_fields string,
  loadevent_id bigint,
  latitude_it	double,
  longitude_it double
  )
PARTITIONED BY (
  source_cd string,
  batch string)
ROW FORMAT DELIMITED
   FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_tsp_trippoint --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_tsp_trippoint;

CREATE TABLE  ~>srdp_wk_db.dc_tsp_trippoint (
   dataload_dt  timestamp COMMENT 'Load date',
   sourcefilename_ts  timestamp COMMENT 'Source file datestamp',
   loadevent_id  bigint COMMENT 'Unique Identifier to indicate the load',
   devicetype_cd  int COMMENT 'To Indicate data record from Octo vendor',
   fullpolicy_nb  string COMMENT 'Full Policy Number',
   voucher_nb  bigint,
   trip_nb  string COMMENT 'Trip number',
   position_ts  timestamp COMMENT 'Trip position timestamp',
   latitude_it double,
   longitude_it double,
   vssspeed_am  double,
   vssacceleration_pc double,
   enginerpm_qt  int,
   throttleposition_pc double,
   accelerationlateral_qt  double,
   accelerationlongitudinal_qt  double,
   accelerationvertical_qt  double,
   gpsheading_nb  smallint,
   positionquality_nb  double,
   odometerreading_qt  double,
   eventaveragespeed_qt  double,
   eventaverageacceleration_qt  double,
   distancetravelled_qt  double,
   timeelapsed_qt  double,
   gpspointspeed_qt  double,
   road_tp  string)
PARTITIONED BY (
   source_cd  string,
   batch  string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_tsp_tripevent --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_tsp_tripevent;

CREATE TABLE ~>srdp_wk_db.dc_tsp_tripevent(
dc_instance_id BIGINT,
dataload_dt timestamp COMMENT 'Load date',
sourcefilename_ts timestamp COMMENT 'Source file datestamp',
loadevent_id bigint COMMENT 'Unique  Identifier to indicate the load',
devicetype_cd bigint COMMENT 'To Indicate data record from Octo vendor',
contract_nb string,
voucher_nb bigint,
trip_nb string COMMENT 'Trip number',
detectedvin_nb string,
event_ts timestamp,
eventtimezoneoffset_nb string,
latitude_it double,
longitude_it double,
eventtype_cd string,
eventreferencevalue_ds string,
eventstart_ts timestamp,
eventend_ts timestamp,
eventduration_am double)
PARTITIONED BY (source_cd string,batch string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_orphan_ts --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_orphan_ts;

CREATE TABLE ~>srdp_wk_db.dc_orphan_ts (
   dc_instance_id BIGINT,              
   dataload_dt  timestamp COMMENT 'Load date',
   sourcefilename_ts  timestamp COMMENT 'Source file datestamp',
   loadevent_id  bigint COMMENT 'Unique Identifier to indicate the load',
   devicetype_cd  bigint COMMENT 'To Indicate data record from Octo vendor',
   fullpolicy_nb  string COMMENT 'Full Policy Number',
   voucher_nb  bigint,
   detectedvin_nb STRING,
   trip_nb  string COMMENT 'Trip number',
   tripstart_ts  timestamp COMMENT 'Start time of the trip',
   tripend_ts  timestamp COMMENT 'End time of the trip',
   plcy_ratd_st_cd  string,
   tripdistance_qt  double,
   averagespeed_qt  double,
   maximumspeed_qt  double,
   fuelconsumption_qt  double,
   milstatus_cd  string,
   tripzoneoffset_am  string,
   idletime_ts  int,
   trippositionalquality_qt  double,
   accelerometerquality_qt  double,
   distancemotorways_qt  double,
   distanceurbanareas_qt  double,
   distanceotherroad_qt  double,
   distanceunknownroad_qt  double,
   timetravelled_qt  double,
   timemotorways_qt  double,
   timeurbanareas_qt  double,
   timeotherroad_qt  double,
   timeunknownroad_qt  double,
   speedingdistancemotorways_qt  double,
   speedingdistanceurbanareas_qt  double,
   speedingdistanceotherroad_qt  double,
   speedingdistanceunknownroad_qt  double,
   speedingtimemotorways_qt  double,
   speedingtimeurbanareas_qt  double,
   speedingtimeotherroad_qt  double,
   speedingtimeunknownroad_qt  double)
PARTITIONED BY (
   source_cd  string,
   batch  string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS ORC;


-------------------------------------- Table: dc_hive_sre_hourly --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_hive_sre_hourly;

CREATE TABLE ~>srdp_wk_db.dc_hive_sre_hourly(
  dc_instance_id bigint,
  trip_nb string,
  detectedvin_nb string,
  plcy_ratd_st_cd string,
  periodstart_ts timestamp,
  periodend_ts timestamp,
  periodstart_hr timestamp,
  periodend_hr timestamp,
  fast_acceleration_ct int,
  hard_brake_ct int,
  miles double,
  kilometers double,
  adjusted_miles double,
  adjusted_km double,
  plausible_miles double,
  plausible_km double,
  nighttime_driving_sec_count int,
  idle_time_sec_count int,
  plausible_idle_time_sec_count int,
  drive_time_sec_count int,
  plausible_drive_time_sec_count int)
PARTITIONED BY (
  source_cd string,
  batch string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\;'
STORED AS ORC;


-------------------------------------- Table: dc_annual_mileage --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_annual_mileage;

CREATE TABLE  ~>srdp_wk_db.dc_annual_mileage (
   dc_instance_id  bigint,
   plcy_ratd_st_cd  string,
   first_activity_date  timestamp,
   last_activity_date  timestamp,
   days_installed  bigint,
   install_percentage  double,
   uninstall_percentage  double,
   plausible_speed_pcnt  double,
   tier1_10avg  decimal(10,0),
   tier11_30avg  decimal(10,0),
   tier31_70avg  decimal(10,0),
   tier71_90avg  decimal(10,0),
   tier91_100avg  decimal(10,0),
   estimatedkilometers  double,
   estimatedmileage  double)
PARTITIONED BY (
   load_date  string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS ORC;

-------------------------------------- Table: dc_annual_mileage_score --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_annual_mileage_score;

CREATE TABLE ~>srdp_wk_db.dc_annual_mileage_score(
  dc_instance_id bigint,
  policy_nb string,
  score_dt string,
  tripstart_dt string,
  tripend_dt string,
  score_days string,
  percenttime_disconnected string,
  score_1 string,
  score_2 string,
  score_3 string,
  score_4 string,
  score_5 string,
  score_6 string,
  score_7 string,
  score_8 string,
  score_9 string,
  score_10 string,
  floor_estimatedkilometers string,
  filler string)
PARTITIONED BY (
  score_date string)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\u0001'
STORED AS ORC;

-------------------------------------- Table: dc_hive_sre_scoring --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_hive_sre_scoring;

CREATE TABLE ~>srdp_wk_db.dc_hive_sre_scoring(
dc_instance_id Bigint,
policy_number string,
score_start_date timestamp,
score_end_date timestamp,
score_days smallint,
score_model_1 string,
pure_score_1 smallint,
rated_score_1 smallint,
filler_1 string,
score_model_2 string,
pure_score_2 smallint,
rated_score_2 smallint,
filler_2 string,
score_model_3 string,
pure_score_3 smallint,
rated_score_3 smallint,
filler_3 string,
score_model_4 string,
pure_score_4 smallint,
rated_score_4 smallint,
filler_4 string,
score_model_5 string,
pure_score_5 smallint,
rated_score_5 smallint,
filler_5 string,
score_model_6 string,
pure_score_6 smallint,
rated_score_6 smallint,
filler_6 string,
score_model_7 string,
pure_score_7 smallint,
rated_score_7 smallint,
filler_7 string,
score_model_8 string,
pure_score_8 smallint,
rated_score_8 smallint,
filler_8 string,
score_model_9 string,
pure_score_9 smallint,
rated_score_9 smallint,
filler_9 string,
score_model_10 string,
pure_score_10 smallint,
rated_score_10 smallint,
filler_10 string,
percent_time_disconnected smallint,
calculated_annual_mileage int,
number_of_connect_disconect string,
uninstalled_time string,
filler string,
model_id string,
hard_brake_ct int,
fast_acceleration_ct int,
scrub_miles double,
adjust_miles double,
no_idle_time bigint,
idle_time bigint,
install_percentage double,
plausible_percentage double)
PARTITIONED BY (
score_date string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\;'
STORED AS ORC;

-------------------------------------- Table: dc_devicestatus --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_devicestatus;

CREATE TABLE ~>srdp_wk_db.dc_devicestatus(
dc_instance_id bigint,
status int,
statusstart_ts timestamp,
statusend_ts timestamp,
lastactivity_ts timestamp,
loststatus_flag int)
STORED AS ORC;

-------------------------------------- Table: dc_device_install_pcnt --------------------------------------
DROP TABLE IF EXISTS ~>srdp_wk_db.dc_device_install_pcnt;

CREATE TABLE ~>srdp_wk_db.dc_device_install_pcnt(
  dc_instance_id bigint,
  loststatus_flag bigint,
  total_time bigint,
  total_install_time bigint,
  install_percentage double,
  total_uninstall_time bigint,
  uninstall_percentage double,
  first_activity_date timestamp,
  last_activity_date timestamp,
  total_days bigint,
  days_installed bigint,
  connection_ct bigint,
  disconnection_ct bigint)
ROW FORMAT DELIMITED
  FIELDS TERMINATED BY ','
STORED AS ORC;