------ Add current batch partition to external table(OCTO_TripSummary_Ext_h) if not exists 

use ~>smartride_raw_hive_db;

alter table OCTO_TripSummary_Ext_H add IF NOT EXISTS partition (batch='~>batch_id');

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_OCTO_TSP_TripSummary_Temp_H;

CREATE TABLE ~>smartride_work_hive_db.WK_OCTO_TSP_TripSummary_Temp_H(
DataLoad_Dt TIMESTAMP COMMENT 'Load date',
SourceFileName_Ts TIMESTAMP COMMENT 'Source file datestamp',
LoadEvent_Id BIGINT COMMENT 'Unique  Identifier to indicate the load', 
DeviceType_Cd BIGINT  COMMENT 'To Indicate data record from Octo vendor',
FullPolicy_Nb STRING COMMENT 'Full Policy Number',
Voucher_Nb BIGINT,
sr_pgm_instnc_id BIGINT,
DeviceSerial_Nb BIGINT COMMENT 'Device serial number of the device',
EnrolledVIN_Nb STRING COMMENT 'Enrolled Vehicle Indentification number',
Trip_Nb STRING COMMENT 'Trip number',
DetectedVIN_Nb STRING COMMENT 'Detected Vehicle Indentification number',
TripStart_Ts TIMESTAMP COMMENT 'Start time of the trip',
TripEnd_Ts  TIMESTAMP COMMENT 'End time of the trip',
Plcy_Ratd_St_Cd STRING,
TripDistance_Qt DOUBLE,
AverageSpeed_Qt DOUBLE,
MaximumSpeed_Qt DOUBLE,
FuelConsumption_Qt DOUBLE,
MILStatus_Cd STRING,
TripZoneOffset_AM STRING,
IdleTime_Ts INT,
TripPositionalQuality_Qt DOUBLE,
AccelerometerQuality_Qt DOUBLE,
DistanceMotorways_Qt DOUBLE,
DistanceUrbanAreas_Qt DOUBLE,
DistanceOtherRoad_Qt DOUBLE,
DistanceUnknownRoad_Qt DOUBLE,
TimeTravelled_Qt DOUBLE,
TimeMotorways_Qt DOUBLE,
TimeUrbanAreas_Qt DOUBLE,
TimeOtherRoad_Qt DOUBLE,
TimeUnknownRoad_Qt DOUBLE,
SpeedingDistanceMotorways_Qt DOUBLE,
SpeedingDistanceUrbanAreas_Qt DOUBLE,
SpeedingDistanceOtherRoad_Qt DOUBLE,
SpeedingDistanceUnknownRoad_Qt DOUBLE,
SpeedingTimeMotorways_Qt DOUBLE,
SpeedingTimeUrbanAreas_Qt DOUBLE,
SpeedingTimeOtherRoad_Qt DOUBLE,
SpeedingTimeUnknownRoad_Qt DOUBLE
)
partitioned by (source_cd string, batch string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\054' STORED AS TEXTFILE
;

-- Drop and recreate work table WK_OCTO_TSP_TripSummary from external table OCTO_TripSummary_Ext

set mapred.job.name = "~>job_cd Insert Overwrite smartride_work_hive_db.WK_OCTO_TSP_TripSummary_Temp_H from smartride_raw_hive_db.OCTO_TripSummary_Ext_H";

INSERT OVERWRITE TABLE smartride_work_hive_db.WK_OCTO_TSP_TripSummary_Temp_H
PARTITION (source_cd,batch)
select
cast(cast(DataLoad_Dt as date)as timestamp) as DataLoad_Dt,
cast(cast(DataLoad_Dt as date)as timestamp) as SourceFileName_Ts,
~>load_event_id as loadevent,
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
'' as sr_pgm_instnc_id,
deviceserial_nb,
enrolledvin_nb,
trip_nb,
detectedvin_nb,
tripstart_ts,
tripend_ts,
'' as plcy_ratd_st_cd,
tripdistance_qt,
averagespeed_qt,
maximumspeed_qt,
fuelconsumption_qt,
milstatus_cd,
( case when instr(tripzoneoffset_am,':') > 0
then
case when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) > 0
then concat(' ',Substr('00' , 1 ,2-length(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)))),Trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
when cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) < 0 
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
case when instr(tripzoneoffset_am,'-') > 1
then concat('-',Substr('00' ,1,2-length(trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))))),trim( cast (-1 * cast(trim(substr(tripzoneoffset_am,1,instr(tripzoneoffset_am,':')-1)) as int) as varchar(2))),substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
else
concat(' 00',substr(tripzoneoffset_am,instr(tripzoneoffset_am,':')+1,2))
end
end
else concat(Substr('     ',1,5-length(tripzoneoffset_am)),trim(tripzoneoffset_am))
end ) as tripzoneoffset_am, 
idletime_ts,
trippositionalquality_qt,
accelerometerquality_qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
'OCTO' as Source_Cd,
batch
from smartride_raw_hive_db.OCTO_TripSummary_Ext_H;

use ~>smartride_canonical_hive_db;
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions=100000; 
set hive.exec.max.dynamic.partitions.pernode=100000; 
set hive.exec.parallel=false;
set hive.auto.convert.join=false;

--Drop and recreate work table WK_OCTO_TSP_PID. This table will have both Orphan and Non-Orphan PID records 

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_OCTO_TSP_PID_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_OCTO_TSP_PID_H from smartride_work_hive_db.WK_OCTO_TSP_TripSummary_Temp_H smartride_work_hive_db.WK_SMT_ODS_LKP. This table will have both Orphan and Non-Orphan PID records";

CREATE TABLE ~>smartride_work_hive_db.WK_OCTO_TSP_PID_H
AS 
select  
tmp.DataLoad_Dt,
tmp.SourceFileName_Ts,
tmp.LoadEvent_Id,  
tmp.DeviceType_Cd,
tmp.FullPolicy_Nb,
tmp.Voucher_Nb,
tmp.sr_pgm_instnc_id,
tmp.DeviceSerial_Nb,
tmp.EnrolledVIN_Nb,
tmp.Trip_Nb,
'' AS DetectedVIN_Nb,
tmp.TripStart_Ts,
tmp.TripEnd_Ts,
tmp.plcy_ratd_st_cd,
tmp.TripDistance_Qt,
tmp.AverageSpeed_Qt,
tmp.MaximumSpeed_Qt,
tmp.FuelConsumption_Qt,	
tmp.MILStatus_Cd,
tmp.TripZoneOffset_AM,
tmp.IdleTime_Ts,
tmp.TripPositionalQuality_Qt,
tmp.AccelerometerQuality_Qt,
tmp.DistanceMotorways_Qt,
tmp.DistanceUrbanAreas_Qt,
tmp.DistanceOtherRoad_Qt,
tmp.DistanceUnknownRoad_Qt,
tmp.TimeTravelled_Qt,
tmp.TimeMotorways_Qt,
tmp.TimeUrbanAreas_Qt,
tmp.TimeOtherRoad_Qt,
tmp.TimeUnknownRoad_Qt,
tmp.SpeedingDistanceMotorways_Qt,
tmp.SpeedingDistanceUrbanAreas_Qt,
tmp.SpeedingDistanceOtherRoad_Qt,
tmp.SpeedingDistanceUnknownRoad_Qt,
tmp.SpeedingTimeMotorways_Qt,
tmp.SpeedingTimeUrbanAreas_Qt,
tmp.SpeedingTimeOtherRoad_Qt,
tmp.SpeedingTimeUnknownRoad_Qt,
tmp.batch,
lkp.dev_id_nbr,
lkp.vhcl_id_nbr
FROM
~>smartride_work_hive_db.WK_OCTO_TSP_TripSummary_Temp_H tmp
LEFT OUTER JOIN
~>smartride_work_hive_db.WK_SMT_ODS_LKP as lkp
 on tmp.DeviceSerial_Nb = lkp.dev_id_nbr 
 and tmp.EnrolledVIN_Nb = lkp.vhcl_id_nbr
;

-- Orphan records are loaded into WK_OCTO_ORPHAN_PID work table

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_OCTO_ORPHAN_TS_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_OCTO_ORPHAN_TS_H from WK_OCTO_TSP_PID_H. Orphan records are loaded into WK_OCTO_ORPHAN_PID work table.";

CREATE TABLE ~>smartride_work_hive_db.WK_OCTO_ORPHAN_TS_H
AS
SELECT 
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
'OCTO' as source_cd,
batch
from ~>smartride_work_hive_db.WK_OCTO_TSP_PID_H
WHERE dev_id_nbr IS NULL and vhcl_id_nbr IS NULL;

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_octo_non_orphans_non_bonus_H;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_octo_non_orphans_non_bonus_H from smartride_work_hive_db.WK_OCTO_TSP_PID_H smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC";

CREATE TABLE ~>smartride_work_hive_db.WK_octo_non_orphans_non_bonus_H
AS
SELECT 
tsp.DataLoad_Dt,
tsp.SourceFileName_Ts,
tsp.LoadEvent_Id,  
tsp.DeviceType_Cd,
tsp.FullPolicy_Nb,
tsp.Voucher_Nb,
lkp.sr_pgm_instnc_id as sr_pgm_instnc_id, 
tsp.DeviceSerial_Nb,
tsp.EnrolledVIN_Nb,
tsp.Trip_Nb,
tsp.DetectedVIN_Nb,
tsp.TripStart_Ts,
tsp.TripEnd_Ts,
lkp.plcy_ratd_st_cd,
tsp.TripDistance_Qt,
tsp.AverageSpeed_Qt,
tsp.MaximumSpeed_Qt,
tsp.FuelConsumption_Qt,
tsp.MILStatus_Cd,
tsp.TripZoneOffset_AM,
tsp.IdleTime_Ts,
tsp.TripPositionalQuality_Qt,
tsp.AccelerometerQuality_Qt,
tsp.DistanceMotorways_Qt,
tsp.DistanceUrbanAreas_Qt,
tsp.DistanceOtherRoad_Qt,
tsp.DistanceUnknownRoad_Qt,
tsp.TimeTravelled_Qt,
tsp.TimeMotorways_Qt,
tsp.TimeUrbanAreas_Qt,
tsp.TimeOtherRoad_Qt,
tsp.TimeUnknownRoad_Qt,
tsp.SpeedingDistanceMotorways_Qt,
tsp.SpeedingDistanceUrbanAreas_Qt,
tsp.SpeedingDistanceOtherRoad_Qt,
tsp.SpeedingDistanceUnknownRoad_Qt,
tsp.SpeedingTimeMotorways_Qt,
tsp.SpeedingTimeUrbanAreas_Qt,
tsp.SpeedingTimeOtherRoad_Qt,
tsp.SpeedingTimeUnknownRoad_Qt,
'OCTO' as source_cd,
batch
from ~>smartride_work_hive_db.WK_OCTO_TSP_PID_H tsp
LEFT OUTER JOIN
~>smartride_canonical_hive_db.SMT_ODS_BIGIN_PGM_INSTNC as lkp
ON tsp.DeviceSerial_Nb = lkp.dev_id_nbr and 
tsp.EnrolledVIN_Nb = lkp.vhcl_id_nbr
WHERE tsp.dev_id_nbr IS NOT NULL and 
tsp.vhcl_id_nbr IS NOT NULL
AND tsp.tripstart_ts between lkp.sr_enrlmnt_dt and lkp.active_end_dt
;


-- Work table WK_OCTO_TSP_TripSummary will only consist of Non-Orphan records.

DROP TABLE IF EXISTS ~>smartride_work_hive_db.WK_OCTO_TSP_TripSummary;

set mapred.job.name = "~>job_cd Create Table smartride_work_hive_db.WK_OCTO_TSP_TripSummary from WK_OCTO_TSP_PID_H & WK_octo_non_orphans_non_bonus_H. Work table WK_OCTO_TSP_TripSummary will only consist of Non-Orphan records.";

CREATE TABLE ~>smartride_work_hive_db.WK_OCTO_TSP_TripSummary
as
SELECT 
tsp.DataLoad_Dt,
tsp.SourceFileName_Ts,
tsp.LoadEvent_Id,  
tsp.DeviceType_Cd,
tsp.FullPolicy_Nb,
tsp.Voucher_Nb,
-1 as sr_pgm_instnc_id,
tsp.DeviceSerial_Nb,
tsp.EnrolledVIN_Nb,
tsp.Trip_Nb,
tsp.DetectedVIN_Nb,
tsp.TripStart_Ts,
tsp.TripEnd_Ts,
tsp.plcy_ratd_st_cd,
tsp.TripDistance_Qt,
tsp.AverageSpeed_Qt,
tsp.MaximumSpeed_Qt,
tsp.FuelConsumption_Qt,
tsp.MILStatus_Cd,
tsp.TripZoneOffset_AM,
tsp.IdleTime_Ts,
tsp.TripPositionalQuality_Qt,
tsp.AccelerometerQuality_Qt,
tsp.DistanceMotorways_Qt,
tsp.DistanceUrbanAreas_Qt,
tsp.DistanceOtherRoad_Qt,
tsp.DistanceUnknownRoad_Qt,
tsp.TimeTravelled_Qt,
tsp.TimeMotorways_Qt,
tsp.TimeUrbanAreas_Qt,
tsp.TimeOtherRoad_Qt,
tsp.TimeUnknownRoad_Qt,
tsp.SpeedingDistanceMotorways_Qt,
tsp.SpeedingDistanceUrbanAreas_Qt,
tsp.SpeedingDistanceOtherRoad_Qt,
tsp.SpeedingDistanceUnknownRoad_Qt,
tsp.SpeedingTimeMotorways_Qt,
tsp.SpeedingTimeUrbanAreas_Qt,
tsp.SpeedingTimeOtherRoad_Qt,
tsp.SpeedingTimeUnknownRoad_Qt,
'OCTO' as source_cd,
tsp.batch
from ~>smartride_work_hive_db.WK_OCTO_TSP_PID_H tsp
LEFT OUTER JOIN
~>smartride_work_hive_db.WK_octo_non_orphans_non_bonus_H nonb
ON tsp.Trip_Nb = nonb.Trip_Nb
WHERE tsp.dev_id_nbr IS NOT NULL 
and tsp.vhcl_id_nbr IS NOT NULL
AND nonb.Trip_Nb is null;

set mapred.job.name = "~>job_cd Insert Overwrite smartride_work_hive_db.WK_OCTO_TSP_TripSummary from WK_octo_non_orphans_non_bonus_H";

INSERT INTO TABLE ~>smartride_work_hive_db.WK_OCTO_TSP_TripSummary
select
DataLoad_Dt,
SourceFileName_Ts,
LoadEvent_Id,  
DeviceType_Cd,
FullPolicy_Nb,
Voucher_Nb,
sr_pgm_instnc_id,
DeviceSerial_Nb,
EnrolledVIN_Nb,
Trip_Nb,
DetectedVIN_Nb,
TripStart_Ts,
TripEnd_Ts,
plcy_ratd_st_cd,
TripDistance_Qt,
AverageSpeed_Qt,
MaximumSpeed_Qt,
FuelConsumption_Qt,
MILStatus_Cd,
TripZoneOffset_AM,
IdleTime_Ts,
TripPositionalQuality_Qt,
AccelerometerQuality_Qt,
DistanceMotorways_Qt,
DistanceUrbanAreas_Qt,
DistanceOtherRoad_Qt,
DistanceUnknownRoad_Qt,
TimeTravelled_Qt,
TimeMotorways_Qt,
TimeUrbanAreas_Qt,
TimeOtherRoad_Qt,
TimeUnknownRoad_Qt,
SpeedingDistanceMotorways_Qt,
SpeedingDistanceUrbanAreas_Qt,
SpeedingDistanceOtherRoad_Qt,
SpeedingDistanceUnknownRoad_Qt,
SpeedingTimeMotorways_Qt,
SpeedingTimeUrbanAreas_Qt,
SpeedingTimeOtherRoad_Qt,
SpeedingTimeUnknownRoad_Qt,
source_cd,
batch
from  
~>smartride_work_hive_db.WK_octo_non_orphans_non_bonus_H;

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.TSP_TripSummary from smartride_work_hive_db.WK_OCTO_TSP_TripSummary";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.TSP_TripSummary 
PARTITION (source_cd,batch)
select 
dataload_dt
,sourcefilename_ts
,loadevent_id
,devicetype_cd
,fullpolicy_nb
,voucher_nb
,sr_pgm_instnc_id
,deviceserial_nb
,enrolledvin_nb
,trip_nb
,detectedvin_nb
,tripstart_ts
,tripend_ts
,plcy_ratd_st_cd
,tripdistance_qt
,averagespeed_qt
,maximumspeed_qt
,fuelconsumption_qt
,milstatus_cd
,tripzoneoffset_am
,idletime_ts
,trippositionalquality_qt
,accelerometerquality_qt
,distancemotorways_qt
,distanceurbanareas_qt
,distanceotherroad_qt
,distanceunknownroad_qt
,timetravelled_qt
,timemotorways_qt
,timeurbanareas_qt
,timeotherroad_qt
,timeunknownroad_qt
,speedingdistancemotorways_qt
,speedingdistanceurbanareas_qt
,speedingdistanceotherroad_qt
,speedingdistanceunknownroad_qt
,speedingtimemotorways_qt
,speedingtimeurbanareas_qt
,speedingtimeotherroad_qt
,speedingtimeunknownroad_qt
,source_cd
,batch
from ~>smartride_work_hive_db.WK_OCTO_TSP_TripSummary;
	

set mapred.job.name = "~>job_cd Insert Overwrite smartride_canonical_hive_db.ORPHAN_TS from smartride_work_hive_db.wk_octo_orphan_ts_H";

INSERT OVERWRITE TABLE ~>smartride_canonical_hive_db.ORPHAN_TS
PARTITION (source_cd, batch)
select 
dataload_dt
,sourcefilename_ts
,loadevent_id
,devicetype_cd
,fullpolicy_nb
,voucher_nb
,sr_pgm_instnc_id
,deviceserial_nb
,enrolledvin_nb
,trip_nb
,detectedvin_nb
,tripstart_ts
,tripend_ts
,plcy_ratd_st_cd
,tripdistance_qt
,averagespeed_qt
,maximumspeed_qt
,fuelconsumption_qt
,milstatus_cd
,tripzoneoffset_am
,idletime_ts
,trippositionalquality_qt
,accelerometerquality_qt
,distancemotorways_qt
,distanceurbanareas_qt
,distanceotherroad_qt
,distanceunknownroad_qt
,timetravelled_qt
,timemotorways_qt
,timeurbanareas_qt
,timeotherroad_qt
,timeunknownroad_qt
,speedingdistancemotorways_qt
,speedingdistanceurbanareas_qt
,speedingdistanceotherroad_qt
,speedingdistanceunknownroad_qt
,speedingtimemotorways_qt
,speedingtimeurbanareas_qt
,speedingtimeotherroad_qt
,speedingtimeunknownroad_qt
,'OCTO' as source_cd
,batch
from smartride_work_hive_db.wk_octo_orphan_ts_H;
