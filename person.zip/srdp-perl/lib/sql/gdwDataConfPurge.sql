drop table if exists ~>srdp_wk_db.sre_summary_pids;

set mapred.job.name = "~>job_cd create ~>srdp_wk_db.sre_summary_pids";

create table ~>srdp_wk_db.sre_summary_pids
stored as textfile as
select 
sr_pgm_instnc_id
from ~>srdp_cncl_db.hive_sre_summary 
where period_type = 'tp' and periodstart_ts <= date_format(add_months(current_timestamp,-~>months_old_or_more), 'yyyy-MM-dd 00:00:00')
group by sr_pgm_instnc_id;

drop table if exists ~>srdp_rchv_db.hive_sre_summary_purge;

drop table if exists ~>srdp_wk_db.hive_sre_summary_keep;

create table ~>srdp_rchv_db.hive_sre_summary_purge like ~>srdp_cncl_db.hive_sre_summary;

create table ~>srdp_wk_db.hive_sre_summary_keep like ~>srdp_cncl_db.hive_sre_summary;

set mapred.job.name = "~>job_cd create ~>srdp_wk_db.hive_sre_summary_keep and ~>srdp_rchv_db.hive_sre_summary_purge";

from ~>srdp_cncl_db.hive_sre_summary sre
left outer join ~>srdp_wk_db.sre_summary_pids pids
on sre.sr_pgm_instnc_id = pids.sr_pgm_instnc_id
insert overwrite table ~>srdp_wk_db.hive_sre_summary_keep partition (source_cd='IMS')
select
 sre.sr_pgm_instnc_id
,period_type
,periodstart_ts
,periodend_ts
,miles
,kilometers
,night_time_driving_sec_ct
,fast_acceleration_ct
,hard_brake_ct
,idle_time_sec_ct
,drive_time_sec_ct
,idle_time_ratio
,trip_seconds_json
where pids.sr_pgm_instnc_id is null
and sre.source_cd='IMS'
insert overwrite table ~>srdp_rchv_db.hive_sre_summary_purge partition (source_cd='IMS')
select
 sre.sr_pgm_instnc_id
,period_type
,periodstart_ts
,periodend_ts
,miles
,kilometers
,night_time_driving_sec_ct
,fast_acceleration_ct
,hard_brake_ct
,idle_time_sec_ct
,drive_time_sec_ct
,idle_time_ratio
,trip_seconds_json
where pids.sr_pgm_instnc_id is not null
and sre.source_cd='IMS'
insert overwrite table ~>srdp_wk_db.hive_sre_summary_keep partition (source_cd='OCTO')
select
 sre.sr_pgm_instnc_id
,period_type
,periodstart_ts
,periodend_ts
,miles
,kilometers
,night_time_driving_sec_ct
,fast_acceleration_ct
,hard_brake_ct
,idle_time_sec_ct
,drive_time_sec_ct
,idle_time_ratio
,trip_seconds_json
where pids.sr_pgm_instnc_id is null
and sre.source_cd='OCTO'
insert overwrite table ~>srdp_rchv_db.hive_sre_summary_purge partition (source_cd='OCTO')
select
 sre.sr_pgm_instnc_id
,period_type
,periodstart_ts
,periodend_ts
,miles
,kilometers
,night_time_driving_sec_ct
,fast_acceleration_ct
,hard_brake_ct
,idle_time_sec_ct
,drive_time_sec_ct
,idle_time_ratio
,trip_seconds_json
where pids.sr_pgm_instnc_id is not null
and sre.source_cd='OCTO';

load data inpath '~>hive_root_dir/~>srdp_wk_db.db/hive_sre_summary_keep/source_cd=IMS' overwrite into table ~>srdp_cncl_db.hive_sre_summary partition (source_cd='IMS');
load data inpath '~>hive_root_dir/~>srdp_wk_db.db/hive_sre_summary_keep/source_cd=OCTO' overwrite into table ~>srdp_cncl_db.hive_sre_summary partition (source_cd='OCTO');


--Hbase

drop table if exists ~>srdp_rchv_db.hbase_sre_summary_bkp;

CREATE TABLE ~>srdp_rchv_db.hbase_sre_summary_bkp(   
pid bigint,
ptp varchar(2),
psts bigint,
key string,
pets bigint ,
mls double ,
ntd int ,
fac int ,
hbc int ,
it int ,
dt int ,
itr double ,
tsj string )
STORED AS TEXTFILE;

set mapred.job.name = "~>job_cd create ~>srdp_rchv_db.hbase_sre_summary_bkp";

INSERT INTO ~>srdp_rchv_db.hbase_sre_summary_bkp
select 
regexp_extract(key, '\\d\\d_(.*?)_(.*)_(.*)', 1) as pid,
regexp_extract(key, '\\d\\d_(.*?)_(.*)_(.*)', 2) as ptp,
regexp_extract(key, '\\d\\d_(.*?)_(.*)_(.*)', 3) as psts,
key,pets,mls,ntd,fac,hbc,it,dt,itr,tsj from ~>srdp_rpt_db.sre_summary_ext;

use ~>srdp_wk_db;

drop table if exists ~>srdp_wk_db.hbase_sre_summary_pids;

set mapred.job.name = "~>job_cd create ~>srdp_wk_db.hbase_sre_summary_pids";

create table ~>srdp_wk_db.hbase_sre_summary_pids
stored as textfile as
select pid from ~>srdp_rchv_db.hbase_sre_summary_bkp
where ptp='tp'
group by pid
--(60 * 60 * 24 * 365.25) / 12 = 2629800 The average number of seconds in a month
having min(psts) <= unix_timestamp(current_timestamp) - (2629800 * ~>months_old_or_more);


DROP TABLE IF EXISTS ~>srdp_rchv_db.hbase_sre_summary_purge;

CREATE TABLE ~>srdp_rchv_db.hbase_sre_summary_purge(   
  key string ,
  pets bigint ,
  mls double ,
  ntd int ,
  fac int ,
  hbc int ,
  it int ,
  dt int ,
  itr double ,
  tsj string )
STORED AS TEXTFILE;

set mapred.job.name = "~>job_cd create ~>srdp_rchv_db.hbase_sre_summary_purge";

insert overwrite table ~>srdp_rchv_db.hbase_sre_summary_purge
select 
key,
pets,
mls,
ntd,
fac,
hbc,
it,
dt,
itr,
tsj 
from ~>srdp_rchv_db.hbase_sre_summary_bkp bkp
left outer join ~>srdp_wk_db.hbase_sre_summary_pids pids
on bkp.pid = pids.pid
where pids.pid is not null;

