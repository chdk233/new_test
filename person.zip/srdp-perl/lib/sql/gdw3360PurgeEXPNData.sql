set hive.enforce.bucketing = true;
set hive.enforce.sorting = true;
set hive.optimize.bucketmapjoin = true;
set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_canonical_hive_db.Vehicle from experian_work_hive_db.wk_Vehicle, experian_canonical_hive_db.BindPolicy";

INSERT OVERWRITE TABLE  ~>experian_canonical_hive_db.Vehicle
PARTITION (sourcefile_dt)
Select 
 v.Vin10_Nb 
,v.State_Cd 
,v.Make_Ds 
,v.Model_Ds 
,v.ManufactureYear_Nb 
,v.ProgramStart_Ts  
,v.ProgramStartOffsetTime_Am
,v.ProgramEnd_Ts 
,v.ProgramStartOffsetTime_Am
,v.loadevent_id
,v.PartnerNotification_Id
,v.sourcefile_dt
FROM experian_work_hive_db.wk_Vehicle v left outer join ~>experian_canonical_hive_db.BindPolicy bp
on v.partnernotification_id = bp.partnernotification_id
where
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(v.sourcefile_dt,1,4),'-',substr(v.sourcefile_dt,5,2),'-',substr(v.sourcefile_dt,7,2)) as date)) >= ~>min_days
and
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(v.sourcefile_dt,1,4),'-',substr(v.sourcefile_dt,5,2),'-',substr(v.sourcefile_dt,7,2)) as date)) <= ~>max_days
and bp.partnernotification_id is null;

set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_canonical_hive_db.TripSummary from experian_work_hive_db.wk_TripSummary, experian_canonical_hive_db.BindPolicy ";

INSERT OVERWRITE TABLE  ~>experian_canonical_hive_db.TripSummary
PARTITION (sourcefile_dt)
Select 	
 ts.TripStart_Ts 
,ts.TripStartOffsetTime_Am
,ts.TripEnd_Ts
,ts.TripEndtOffsetTime_Am
,ts.OdometerReadingStart_Qt  
,ts.OdometerReadingEnd_Qt
,ts.IdleTime_Am
,ts.loadevent_id
,ts.PartnerNotification_Id
,ts.sourcefile_dt
FROM  experian_work_hive_db.wk_TripSummary ts left outer join ~>experian_canonical_hive_db.BindPolicy bp
on ts.partnernotification_id = bp.partnernotification_id
where
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(ts.sourcefile_dt,1,4),'-',substr(ts.sourcefile_dt,5,2),'-',substr(ts.sourcefile_dt,7,2)) as date)) >= ~>min_days
and
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(ts.sourcefile_dt,1,4),'-',substr(ts.sourcefile_dt,5,2),'-',substr(ts.sourcefile_dt,7,2)) as date)) <= ~>max_days
and bp.partnernotification_id is null;

set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_canonical_hive_db.TripEvent from TripEvent, BindPolicy ";

INSERT OVERWRITE TABLE  ~>experian_canonical_hive_db.TripEvent
PARTITION (sourcefile_dt)
Select 
 te.Event_Ts 
,te.EventOffsetTime_Am
,te.VehicleSpeed_Am  
,te.HardBrakesAcceleration_Am
,te.loadevent_id
,te.PartnerNotification_Id
,te.sourcefile_dt
FROM ~>experian_canonical_hive_db.TripEvent te left outer join ~>experian_canonical_hive_db.BindPolicy bp
on te.partnernotification_id = bp.partnernotification_id
where
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(te.sourcefile_dt,1,4),'-',substr(te.sourcefile_dt,5,2),'-',substr(te.sourcefile_dt,7,2)) as date)) >= ~>min_days
and
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(te.sourcefile_dt,1,4),'-',substr(te.sourcefile_dt,5,2),'-',substr(te.sourcefile_dt,7,2)) as date)) <= ~>max_days
and bp.partnernotification_id is null;

set hive.exec.dynamic.partition.mode=nonstrict;

set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx13107m;
set tez.task.resource.memory.mb=8096;
set tez.am.resource.memory.mb=8096;

set mapred.job.name = "~>job_cd Insert Overwrite experian_reporting_hive_db.VehiclePartition from experian_reporting_hive_db.VehiclePartition, experian_canonical_hive_db.BindPolicy ";

INSERT OVERWRITE TABLE  experian_reporting_hive_db.VehiclePartition
PARTITION (sourcefile_dt)
Select 
 vp.partnernotification_id
,vp.vin10_nb
,vp.state_cd
,vp.make_ds
,vp.model_ds
,vp.manufactureyear_nb
,vp.programstart_ts
,vp.programstartoffsettime_am
,vp.programend_ts
,vp.programendoffsettime_am
,vp.totaltraveltime_am
,vp.totaltraveldistance_qt
,vp.totalidletime_am
,vp.totalidletime_pc
,vp.tripstart_ts
,vp.tripstartoffsettime_am
,vp.tripend_ts
,vp.tripendtoffsettime_am
,vp.odometerreadingstart_qt
,vp.odometerreadingend_qt
,vp.idletime_am
,vp.hardbrakes_ct
,vp.fastacceleration_ct
,vp.satsunpartition1time_am
,vp.satsunpartition2time_am
,vp.satsunpartition3time_am
,vp.monfripartition4time_am
,vp.monfripartition5time_am
,vp.monfripartition6time_am
,vp.monfripartition7time_am
,vp.monfripartition8time_am
,vp.satsunpartition1_pc
,vp.satsunpartition2_pc
,vp.satsunpartition3_pc
,vp.monfripartition4_pc
,vp.monfripartition5_pc
,vp.monfripartition6_pc
,vp.monfripartition7_pc
,vp.monfripartition8_pc
,vp.satsunpartition1adjdistance_qt
,vp.satsunpartition2adjdistance_qt
,vp.satsunpartition3adjdistance_qt
,vp.satsunpartition4adjdistance_qt
,vp.satsunpartition5adjdistance_qt
,vp.satsunpartition6adjdistance_qt
,vp.satsunpartition7adjdistance_qt
,vp.satsunpartition8adjdistance_qt
,vp.loadevent_id
,vp.sourcefile_dt
from experian_reporting_hive_db.VehiclePartition vp left outer join ~>experian_canonical_hive_db.BindPolicy bp
on vp.partnernotification_id = bp.partnernotification_id
where
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(vp.sourcefile_dt,1,4),'-',substr(vp.sourcefile_dt,5,2),'-',substr(vp.sourcefile_dt,7,2)) as date)) >= ~>min_days
and
datediff(cast(cast(from_unixtime(unix_timestamp()) as varchar(10)) as date),cast(concat(substr(vp.sourcefile_dt,1,4),'-',substr(vp.sourcefile_dt,5,2),'-',substr(vp.sourcefile_dt,7,2)) as date)) <= ~>max_days
and bp.partnernotification_id is null;
