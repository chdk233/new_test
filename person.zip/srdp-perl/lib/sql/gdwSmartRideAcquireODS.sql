DROP TABLE IF EXISTS ~>work_db.Wk_ODS_Sqooped;

SET mapred.job.name = "~>job_cd Load scooped DB2 ODS data to Wk_ODS_Sqooped table";

CREATE TABLE ~>work_db.wk_ods_sqooped(
  sr_pgm_instnc_id string, 
  vin_nbr string, 
  device_nbr string, 
  rated_state_cd string, 
  program_type string, 
  sr_enrlmnt_dt string, 
  vehicle_status_cd string, 
  req_rsn_cd string, 
  device_status_in string, 
  piid_transaction_dt string, 
  active_end_dt string, 
  active_start_dt string, 
  cntr bigint, 
  source_cd string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\054'
STORED AS TEXTFILE
LOCATION
  'hdfs:///user/hive/warehouse/~>work_db/wk_ods_sqooped'; 

LOAD DATA inpath '~>sqoop_target_dir/part*' OVERWRITE INTO TABLE ~>work_db.wk_ods_sqooped;

SET mapred.job.name = "~>job_cd Backup SMT_ODS_BIGIN_PGM_INSTNC to SMT_ODS_BIGIN_PGM_INSTNC_OLD";

INSERT OVERWRITE TABLE ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_old
SELECT sr_pgm_instnc_id
,vhcl_id_nbr
,sr_enrlmnt_dt
,dev_id_nbr
,plcy_ratd_st_cd
,active_end_dt
,active_start_dt
,source_cd
FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc;

SET mapred.job.name = "~>job_cd Move data from Wk_ODS_Sqooped to SMT_ODS_BIGIN_PGM_INSTNC";

INSERT OVERWRITE TABLE ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc
SELECT  cast(sr_pgm_instnc_id AS bigint) AS sr_pgm_instnc_id,
trim(vin_nbr) AS vhcl_id_nbr,
from_unixtime(unix_timestamp(sr_enrlmnt_dt, 'yyyy-MM-dd')) AS sr_enrlmnt_dt,
cast(trim(device_nbr) AS bigint) dev_id_nbr,
rated_state_cd AS plcy_ratd_st_cd,
from_unixtime(unix_timestamp(active_end_dt, 'yyyy-MM-dd')) AS active_end_dt,
from_unixtime(unix_timestamp(active_start_dt, 'yyyy-MM-dd')) AS active_start_dt,
'ODS' AS source_cd
FROM  ~>work_db.wk_ods_sqooped;

INSERT OVERWRITE TABLE ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_orc
SELECT * FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc;

INSERT OVERWRITE TABLE ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc_parquet
SELECT * FROM ~>foundation_db.smartride_smt_ods_bigin_pgm_instnc;