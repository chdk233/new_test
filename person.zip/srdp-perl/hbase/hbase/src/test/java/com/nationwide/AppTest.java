package com.nationwide;

import static org.junit.Assert.assertTrue;

import org.junit.Test;


/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldSetKeyProperlyOne()
    {
        String key = GetExample.generateKey("2011984");
        assertTrue( key.equals("00_2011984") );
    }

    @Test
    public void shouldSetKeyProperlyTwo()
    {
        String key = GetExample.generateKey("1997798");
        assertTrue( key.equals("06_1997798") );
    }
}
