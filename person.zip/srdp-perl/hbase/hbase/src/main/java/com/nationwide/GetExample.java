package com.nationwide;

import java.io.FileWriter; 
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.Filter;
import org.apache.hadoop.hbase.filter.PrefixFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;
import org.apache.commons.cli.*;
import org.json.*;
/**
 * Hello world!
 *
 */
public class GetExample 
{
    public static void main( String[] args ) throws IOException
    {

    final Logger log = Logger.getLogger(GetExample.class.getName());


    CommandLine cmd = parseCLI(args);

    String pid    = cmd.getOptionValue("p");
    String vin    = cmd.getOptionValue("v");
    String family = cmd.getOptionValue("f");
    String column = cmd.getOptionValue("c");
    String quorum = cmd.getOptionValue("q");
    String output = cmd.getOptionValue("o");
    String type = cmd.getOptionValue("t");
    String jsonQuery = cmd.getOptionValue("j");

    log.info(String.format("Output will be written to %s", output));

    FileWriter writer = new FileWriter(output);



        final ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        final String filePath = classLoader.getResource("jaas.conf").toExternalForm();
        System.setProperty("java.security.auth.login.config",filePath);
        
      // Instantiating Configuration class
      Configuration config = HBaseConfiguration.create();

      if(quorum != null){
        config.set("hbase.zookeeper.quorum",quorum);    
    }


      // Instantiating HTable class
      HTable table = new HTable(config, "smartride_reporting_hbase_db.SRE_SUMMARY");

      String generatedKey;

      if(pid == null){
        generatedKey = vin;
      } else{
        generatedKey = generateKey(pid);
      }

      if(type != null){
          generatedKey = generatedKey + "_" + type;
      }

      Filter filter = new PrefixFilter(Bytes.toBytes(generatedKey));
      Scan scan = new Scan().withStartRow(Bytes.toBytes(generatedKey)).addColumn(Bytes.toBytes(family), Bytes.toBytes(column));

      scan.setFilter(filter);

      log.info(String.format("Scanning table %s using prefix key %s and returning column %s in column family %s",
              "smartride_reporting_hbase_db.SRE_SUMMARY",
              generatedKey,
              column,
              family));

      ResultScanner scanner = table.getScanner(scan);
      
      for (Result result : scanner) {
        for (Cell cell : result.rawCells()) {


            String value;

            if(jsonQuery != null){

                value = Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength());
                value = value.replace(";",",");
                JSONObject obj = new JSONObject(value);
                value = Integer.toString(obj.getInt(jsonQuery));

            }else{
                value = Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength());
            }


            writer.write(String.format("%s,%s\n",
                Bytes.toString(cell.getRowArray(),cell.getRowOffset(),cell.getRowLength()),
                value));
        }
    }
    writer.close();
      scanner.close();
      table.close();
    }

    public static String generateKey(String piid){

        String pmod = Integer.toString(Integer.parseInt(piid) % 16);

        return "00".substring(0, 2 - pmod.length())+ pmod + "_" + piid;


    }

    public static CommandLine parseCLI(String[] args){

        Options options = new Options();

        Option p = new Option("p", "piid", true, "Program Instance Id");
        options.addOption(p);

        Option v = new Option("v", "vin", true, "Vehicle Identification Number, used for SmartMiles");
        options.addOption(v);

        Option f = new Option("f", "family", true, "Column Family Returned");
        f.setRequired(true);
        options.addOption(f);

        Option c = new Option("c", "column", true, "Column Qualifier");
        c.setRequired(true);
        options.addOption(c);

        Option o = new Option("o", "output", true, "Output file path");
        o.setRequired(true);
        options.addOption(o);

        Option q = new Option("q", "quorum", true, "Comma delimeted hbase zookeeper quorum");
        options.addOption(q);

        Option t = new Option("t", "type", true, "Period type");
        options.addOption(t);

        Option j = new Option("j", "jsonQuery", true, "Json Query");
        options.addOption(j);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
            if (cmd.getOptionValue("p") == null && cmd.getOptionValue("v") == null){
                throw new ParseException("Must provide a piid or vin");
            }
            if (cmd.getOptionValue("p") != null && cmd.getOptionValue("v") != null){
                throw new ParseException("Cannot provide a piid and vin at the same time");
            }
            return cmd;
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);

            System.exit(1);
        }

        return null;

    }
}
