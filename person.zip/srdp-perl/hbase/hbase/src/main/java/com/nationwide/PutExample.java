package com.nationwide;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;



import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.util.Bytes;
/**
 * Hello world!
 *
 */
public class PutExample 
{



    private static String columnFamily( int index){

        List<String> columns = new ArrayList<String>();

        columns.add("sre:pets");
        columns.add("sre:tc");
        columns.add("sre:mls");
        columns.add("sre:ntd");
        columns.add("sre:fac");
        columns.add("sre:hbc");
        columns.add("sre:it");
        columns.add("sre:dt");
        columns.add("sre:itr");
        columns.add("sjs:tsj");

        return columns.get(index);
    }
    @SuppressWarnings( "deprecation" )
    private static void insertRowToHbase(HTable table, ArrayList<String> row) throws IOException{

        Put p = new Put(Bytes.toBytes(row.remove(0)));
        
        for (int i=0; i < row.size();i++){

            String[] field = columnFamily(i).split(":");

            p.add(Bytes.toBytes(field[0]),
                  Bytes.toBytes(field[1]),
                  Bytes.toBytes(row.get(i)));
        }

        table.put(p);

    }

    @SuppressWarnings( "deprecation" )
    public static void main( String[] args ) throws IOException
    {

        String fileName = "C:\\Users\\roberd7\\hbase_hive_sre.csv";

      // Instantiating Configuration class
      Configuration config = HBaseConfiguration.create();

      // Instantiating HTable class
      HTable table = new HTable(config, "smartride_reporting_hbase_db.SRE_SUMMARY");

        

        //read file into stream, try-with-resources
        try (Stream<String> stream = Files.lines(Paths.get(fileName))) {

        stream.forEach(item -> {
            try {
                insertRowToHbase(table, new ArrayList<String>(Arrays.asList(item.split("\\|"))));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        } catch (IOException e) {
        e.printStackTrace();
        }

      

      table.close();
    }
}
 
